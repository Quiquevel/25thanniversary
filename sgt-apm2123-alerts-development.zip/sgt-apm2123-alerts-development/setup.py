import setuptools
from version import __version__

setuptools.setup(
    name = "alerts",
    version = __version__,
    author = "Pedro Alamilla, Juan Amores",
    author_email = "pedro.alamilla@gruposantander.com, juan.amores@servexternos.gruposantander.com",
    description = "Identification and processing of alerts",
    long_description = "Identification and processing of alerts",
    long_description_content_type = "text/markdown",
    url = "http://mypythonpackage.com",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
    ],
    python_requires = '>=3.11.0',
)
