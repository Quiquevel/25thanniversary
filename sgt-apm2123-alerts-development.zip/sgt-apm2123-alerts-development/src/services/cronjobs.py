from shuttlelib.db.mongo import MongoClient
from src.services.alerts import clusteralerts
from shuttlelib.utils.logger import logger
from fastapi import HTTPException
from src.services.alertshistorical import clusterhistoricalrestart, clusterhistorical_las15_alerts, clusterhistoricalalerts
from src.services.dynaOTHERsALL import dynatraceOTHERsBatchbyDay, dynatraceOTHERsBatchbyMonth
from datetime import datetime
import os

try:
    mg = MongoClient()
except HTTPException as e:            
    logger.error(f"Problems with mongo. ({e.status_code}-{e.detail}). Skipping...")
    mg = None
    pass
entity_id=(os.getenv("ENTITY_ID")).lower()
match entity_id:
    case "spain":
        entity_id = "sanes"

async def alerting_batch_cronjob():
    mongoalertdata = {}
    functional_environment = []
    functional_environment = os.getenv("ENVIRONMENT_ALERTING_BATCH") #set the environment where the information will be extracted
    if functional_environment:
        env = functional_environment.split(',')
        for envfunc in env:
            mg.change_collection(os.getenv("COLLECTION"))
            #mg.expiration_manager()
            logger.info("starting alerting batch process")
            alerts = await clusteralerts(envfunc)
            mongoalertdata.update(alerts)
        mongoalertdata_result = {functional_environment: mongoalertdata}
        mg.change_collection(os.getenv("COLLECTION"))
        mg.delete_all_data()
        mg.change_collection(os.getenv("COLLECTION"))
        mg.add_data(data=mongoalertdata_result)
        logger.info("batch alerting upload completed")
    else:
        pass

async def alerting_last_15_7_days_cronjob():
    functionalHistoricalAlertEnvironment = os.getenv("ENVIRONMENT_DYNATRACE_HISTORICAL_BATCH") #set the environment where the information will be extracted
    if functionalHistoricalAlertEnvironment:
        logger.info("starting dynatrace last 15 and 7 days batch process")
        historicaldaysalerts = await clusterhistorical_las15_alerts(functional_environment=functionalHistoricalAlertEnvironment,daystonow=True)
        logger.info("batch dynatrace last 15 and 7 days batch completed")
    else:
        pass

async def historical_alerting_restart_cronjob():
    mongohistoricalrestartdata = {}
    functionalHistoricalRestartEnvironment = os.getenv("ENVIRONMENT_HISTORICAL_RESTART_BATCH") #set the environment where the information will be extracted
    if functionalHistoricalRestartEnvironment:
        logger.info("starting historical_restart batch process")
        historicalrestart = await clusterhistoricalrestart(functional_environment=functionalHistoricalRestartEnvironment)
        mongohistoricalrestartdata.update(historicalrestart)
        mg.change_collection(entity_id + "_" + os.getenv("COLLECTION_HISTORICAL_RESTART"))
        #to delete previus data in COLLECTION_HISTORICAL_ALERT
        mg.delete_all_data()
        mg.change_collection(entity_id + "_" + os.getenv("COLLECTION_HISTORICAL_RESTART"))
        #add data in COLLECTION_HISTORICAL_ALERT
        mongohistoricalrestartdata_result = {functionalHistoricalRestartEnvironment: mongohistoricalrestartdata}
        mg.add_data(data=mongohistoricalrestartdata_result)
        logger.info("batch historical_restart upload completed")
    else:
        pass

async def alerting_dyna_core_byDay_cronjob():
    environment=(os.getenv("ENVIRONMENT")).lower()
    
    logger.info(f"Cronjob dynaOTHERsbyDay -> started")       
    await dynatraceOTHERsBatchbyDay(environment, None, None, None)
    logger.info(f"Cronjob dynaOTHERsbyDay -> completed")

async def alerting_dyna_core_byMonth_cronjob():
    environment=(os.getenv("ENVIRONMENT")).lower()
    
    logger.info(f"Cronjob dynaOTHERsbyMonth -> started")       
    await dynatraceOTHERsBatchbyMonth(environment, None, None, None)
    logger.info(f"Cronjob dynaOTHERsbyMonth -> completed")

async def alerting_dyna_top_byMonth_cronjob():
    environment=(os.getenv("ENVIRONMENT")).lower()
    logger.info("CronJob dynaTOP-> started")
    
    now = datetime.now()    
    month = now.strftime("%B").lower()    
    year = now.strftime("%Y")
    await clusterhistoricalalerts(environment, None, month, year)
    logger.info("CronJob dynaTOP-> completed")

async def testDynaCronjobCoreByDayTreatment():
    await alerting_dyna_core_byDay_cronjob()

async def testDynaCronjobCoreByMonthTreatment():
    await alerting_dyna_core_byMonth_cronjob()

async def testDynaCronjobTopTreatment():
    await alerting_dyna_top_byMonth_cronjob()

async def testDynaCronjobAlertsTreatment():
    await alerting_batch_cronjob()

async def testDynaCronjobAlerts715DaysTreatment():
    await alerting_last_15_7_days_cronjob()
    
async def testDynaCronjobHistoricalrestartTreatment():
    await historical_alerting_restart_cronjob()
    