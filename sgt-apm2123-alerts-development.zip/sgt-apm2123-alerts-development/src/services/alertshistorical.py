import os
import aiohttp
from src.services.clientunique import client
from shuttlelib.utils.logger import logger
from src.services.dynaTOPALL import dynatraceTOPALLTreatment
from src.services.clientunique import convert_timezone, whichMonth, daytoStarEndTime
from datetime import datetime
from shuttlelib.db.mongo import MongoClient
from fastapi import responses, status
from fastapi.encoders import jsonable_encoder
from fastapi import HTTPException
from dateutil.relativedelta import relativedelta

whitelist = []
input_format = "%Y-%m-%dT%H:%M:%SZ"
output_format = "%a %b %d %H:%M:%S %Y"

try:
    mg = MongoClient()
except HTTPException as e:            
    logger.error(f"Problems with mongo. ({e.status_code}-{e.detail}). Skipping...")
    mg = None
    pass

entity_id=(os.getenv("ENTITY_ID")).lower()
match entity_id:
    case "spain":
        entity_id = "sanes"

async def getAlerts(client,cluster,regionsList,functional_environment):
    alertlistTemp = []
    for region in regionsList:
        try:
            namespaceList = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {functional_environment + cluster + region}")
        except Exception as e:
            logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
            pass
        
        try:
            items = namespaceList[region]['items']
        except:
            items = None
                
        if items != None and len(items) > 0:
            namespaceList = items
            for namespace in namespaceList:
                namespaceName = namespace['metadata']['name']
                logger.debug(f"Get pods list -> Namespace: {namespaceName}")
                try:
                    podList = await client.get_resource(resource="pods", functional_environment=functional_environment, cluster=cluster, namespace=namespaceName, region=region)                    
                except aiohttp.client_exceptions.ServerTimeoutError:
                    logger.error(f"Timeout detected against get pods {functional_environment + namespaceName + cluster + region}")
                    continue
                except Exception as e:
                    logger.error(f"Pods of {cluster}-{region}-{namespaceName} could not be retrieved. Skipping... {e}")
                    continue  # Continúa con el siguiente namespace
                logger.debug(f"Get pods list -> completed -> Namespace: {namespaceName}")

                # GET RESTARTED PODS
                logger.debug(f"Get list of restarted pods -> Namespace: {namespaceName}")
                try:
                    restartedpodslist = await getRestartedPods(podList, cluster, region, functional_environment)
                    alertlistTemp.extend(restartedpodslist)
                except Exception as e:
                    logger.error(f"Failed to get restarted pods for {namespace['metadata']['name']}. {e}")
                logger.debug(f"Get list of restarted pods -> completed -> Namespace: {namespace}")

    return alertlistTemp

async def getRestartedPods(podsList,cluster,region,functional_environment):
    logger.debug("Searching for Pods with restarts")
    restartedpodslist = []

    for pod in podsList[region]["items"]:
        if "-deploy" in pod["metadata"]["name"]:
            pass
        elif any(p in pod["metadata"]["name"] for p in whitelist):
            pass
            #ESTO SERÍA PARA HACER QUE PASE POR AQUÍ SI QUIERO SEPARAR PROYECTOS VOSTOK Y SHUTTLE
        else:
            if pod["status"]["phase"] == "Running":
                podName = pod["metadata"]["name"]
                namespaceName = pod["metadata"]["namespace"]
                restartCount = pod["status"]["containerStatuses"][0]["restartCount"]
                
                restartsCountParam = 1 #(at least one restart)
                if restartCount > restartsCountParam:
                    try:
                        exitCode = pod["status"]["containerStatuses"][0]['lastState']['terminated']['exitCode']
                    except KeyError:
                        exitCode = ""                    

                    try:
                        reason = pod["status"]["containerStatuses"][0]['lastState']['terminated']['reason']
                    except KeyError:
                        reason = ""

                    try:
                        if "running" in pod["status"]["containerStatuses"][0]['state']:
                            startedAt = pod["status"]["containerStatuses"][0]['state']['running']['startedAt']
                            laststartPod_tz = convert_timezone(startedAt, input_format, output_format)
                            #################################

                        elif "waiting" in pod["status"]["containerStatuses"][0]['state']:
                            laststartPod_tz = "waiting"
                        else:
                            laststartPod_tz = ""
                    except:
                        laststartPod_tz = "NO-CONTAINER-STATUS"

                    '''if "startTime" in pod["status"]:
                        firststartPod = pod["status"]["startTime"]
                    else:
                        firststartPod = "Unknown_FirstStartPod"'''
                        
                    if exitCode == "" and reason == "":
                        codeAndReason = "NO-ERROR-CODE"
                    else:
                        codeAndReason = str(exitCode) + " - " + reason
                    
                    nodeName = pod["spec"]["nodeName"]

                    podinfo = {
                        "alertingType": "Restarts",
                        "incidentProvider": "Openshift",
                        "podName": podName,
                        "restarts": restartCount,
                        "description": codeAndReason,
                        "lastStart": laststartPod_tz,
                        "namespace": namespaceName,
                        "nodeName": nodeName,
                        "cluster": cluster,
                        "region": region,
                        "urlproblem": await getUrlPods(functional_environment,cluster,region,namespaceName,podName)
                    }
        
                    restartedpodslist.append(podinfo)
    
    return restartedpodslist

async def getUrlPods(functional_environment,cluster,region,namespace,podName):
    logger.debug(f"Find url {podName} in {cluster} {region} to {namespace}")
    match functional_environment:
        case 'dev':
            match cluster:
                case 'bks':
                    urlproblem = (f'https://console-openshift-console.apps.san01bks.san.{functional_environment}.{region}.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'azure':
                    urlproblem = (f'https://console-openshift-console.apps.ocp01.san.{functional_environment}.{region}.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'ohe':
                    urlproblem = (f'https://api.san01.san.{functional_environment}.{region}.paas.cloudcenter.corp:8443/console/project/{namespace}/browse/pods/{podName}?tab=details')
        case 'pre':
            match cluster:
                case 'bks':
                    urlproblem = (f'https://console-openshift-console.apps.san01bks.san.{functional_environment}.{region}.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'ohe':
                    urlproblem = (f'https://api.san01.san.{functional_environment}.{region}.paas.cloudcenter.corp:8443/console/project/{namespace}/browse/pods/{podName}?tab=details')
                case 'azure':
                    if region == 'weu1':
                        urlproblem = (f'https://console-openshift-console.apps.ocp01.san.{functional_environment}.{region}.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                    if region == 'weu2':
                        urlproblem = (f'https://console-openshift-console.apps.ocp02.san.{functional_environment}.{region}.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
        case 'pro':
            match cluster:
                case 'prodarwin':
                    urlproblem = (f'https://console-openshift-console.apps.san01darwin.san.{functional_environment}.{region}.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'dmzbdarwin':
                    urlproblem = (f'https://console-openshift-console.apps.san01darwin.san.dmzb.{region}.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'azure':
                    if region == 'weu1':
                        urlproblem = (f'https://console-openshift-console.apps.ocp01.san.{functional_environment}.{region}.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                    if region == 'weu2':
                        urlproblem = (f'https://console-openshift-console.apps.ocp02.san.{functional_environment}.{region}.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'confluent':
                    urlproblem = (f'https://console-openshift-console.apps.san01confluent.san.{functional_environment}.{region}.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'proohe':
                    urlproblem = (f'https://api.san01.san.{functional_environment}.{region}.paas.cloudcenter.corp:8443/console/project/{namespace}/browse/pods/{podName}?tab=details')
                case 'dmzbohe':
                    urlproblem = (f'https://api.san01.san.dmzb.{region}.paas.cloudcenter.corp:8443/console/project/{namespace}/browse/pods/{podName}?tab=details')
                case 'probks':
                    urlproblem = (f'https://console-openshift-console.apps.san01bks.san.{functional_environment}.{region}.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'dmzbbks':
                    urlproblem = (f'https://console-openshift-console.apps.san01bks.san.dmzb.{region}.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'dmz2bmov':
                    urlproblem = (f'https://console-openshift-console.apps.san01mov.san.dmz2b.{region}.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'ocp05azure':
                        urlproblem = (f'https://console-openshift-console.apps.ocp05.san.{functional_environment}.{region}.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'dmzbazure':
                    if region == 'weu1':
                        urlproblem = (f'https://console-openshift-console.apps.ocp03.san.{functional_environment}.{region}.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                    if region == 'weu2':
                        urlproblem = (f'https://console-openshift-console.apps.ocp04.san.{functional_environment}.{region}.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'sgt':
                    if region == 'cn1':
                        urlproblem = (f'https://console-openshift-console.apps.sgt01.sgt.pro.cn1.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                    if region == 'cn2':
                        urlproblem = (f'https://console-openshift-console.apps.sgt01.sgt.pro.cn2.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'gsc04':
                    if region == 'cn1':
                        urlproblem = (f'https://console-openshift-console.apps.gsc04.gsc.pro.cn1.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                    if region == 'cn2':
                        urlproblem = (f'https://console-openshift-console.apps.gsc04.gsc.pro.cn2.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'ocpgnr':
                    if region == 'weu1':
                        urlproblem = (f'https://console-openshift-console.apps.ocpgnr.gsc.pro.weu1.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case 'ocppro01':
                    if region == 'weu':
                        urlproblem = (f'https://console-openshift-console.apps.ocppro01.gsc.pro.weu.azure.paas.cloudcenter.corp/k8s/ns/{namespace}/pods/{podName}')
                case _:
                    urlproblem = None
    logger.debug(f"{podName} -> {urlproblem}")
    return urlproblem

async def get_year_based_on_month(month):
    now = datetime.now()
    current_month = now.strftime("%B").lower()

    # month parameter received is the previous month from now
    if month.lower() == 'december' or month.lower() == 'dec':
        if current_month == 'december':
            year = now.strftime('%Y')
        else:
            year = (now - relativedelta(years=1)).strftime('%Y')
    else:
        year = now.strftime("%Y")
    
    return year

async def clusterhistoricalalerts(functional_environment, daystonow=None, month=None, year=None):
    alertlist = []

    #GET DYNATRACE ALERTS
    if functional_environment == 'pro':      
        if year is None:
            now = datetime.now()
            year = now.strftime("%Y")
                    
        months = month.split(',')
        for month in months:
            month = month.strip()
            month = month.lower()
        
            logger.debug(f"Get Dynatrace Response -> {month}")

            monthNum, monthName = whichMonth(month)
            timedynafrom, timedynato = daytoStarEndTime(year, monthNum)
            alertlist = await dynatraceTOPALLTreatment(timedynaS=timedynafrom,timedynaE=timedynato)            
            logger.debug(f"Dynatrace Response completed -> {monthName}")
            if alertlist[0]['alertingType'] != None:
                #if mg.server_info():
                logger.info(f"starting mongoDB process -> {monthName}")
                #mg.change_collection(os.getenv("COLLECTION_DYNATRACE_HISTORICAL_ALERT"))
                mg.change_collection(f"{entity_id}_alerting_dynatop_{monthName}_{year}")
                #to delete previus data in COLLECTION
                mg.delete_all_data()
                #add data in COLLECTION
                result_data = {functional_environment: alertlist}
                result = {
                    functional_environment : result_data
                }
                mg.add_data(data=result)
                logger.info(f"stored in mongo -> {monthName}")
        
        if daystonow == True:
            ######last 7 day dynatrace report######
            logger.debug("Get Dynatrace Response -> 7 days report")
            timedynafrom = "now-7d"
            alertlist_daystonow = await dynatraceTOPALLTreatment(timedynaS=timedynafrom)
            logger.debug("Dynatrace Response completed -> 7 days report")

            #if mg.server_info():
            logger.info("starting mongoDB process -> 7 days report")
            #mg.change_collection(os.getenv("COLLECTION_DYNATRACE_HISTORICAL_ALERT"))
            mg.change_collection(f"{entity_id}_alerting_dynatop_last7_day")
            #to delete previus data in COLLECTION
            mg.delete_all_data()
            #add data in COLLECTION
            daystonow_result_data = {functional_environment: alertlist_daystonow}
            daystonow_result = {
                functional_environment : daystonow_result_data
            }
            mg.add_data(data=daystonow_result)
            logger.info("stored in mongo -> 7 days report")

            ######last 15 day dynatrace report######
            logger.debug("Get Dynatrace Response -> 15 days report")
            timedynafrom = "now-15d"
            alertlist_15daystonow = await dynatraceTOPALLTreatment(timedynaS=timedynafrom)
            logger.debug("Dynatrace Response completed -> 15 days report")

            #if mg.server_info():
            logger.info("starting mongoDB process -> 15 days report")
            #mg.change_collection(os.getenv("COLLECTION_DYNATRACE_HISTORICAL_ALERT"))
            mg.change_collection(f"{entity_id}_alerting_dynatop_last15_day")
            #to delete previus data in COLLECTION
            mg.delete_all_data()
            #add data in COLLECTION
            days15tonow_result_data = {functional_environment: alertlist_15daystonow}
            days15tonow_result = {
                functional_environment : days15tonow_result_data
            }
            mg.add_data(data=days15tonow_result)
            logger.info("stored in mongo -> 15 days report")

    return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": "ok"}))

async def clusterhistorical_las15_alerts(functional_environment,daystonow=None,cluster=None,region=None):

    #GET DYNATRACE ALERTS
    if functional_environment == 'pro':
        #mg = MongoClient()
        if daystonow == True:
            ######last 7 day dynatrace report######
            logger.debug("Get Dynatrace Response -> 7 days report")
            timedynafrom = "now-7d"
            alertlist_daystonow = await dynatraceTOPALLTreatment(timedynaS=timedynafrom,timedynaE=None)
            logger.debug("Dynatrace Response completed -> 7 days report")

            #if mg.server_info():
            logger.info("starting mongoDB process -> 7 days report")
            #mg.change_collection(os.getenv("COLLECTION_DYNATRACE_HISTORICAL_ALERT"))
            mg.change_collection(f"{entity_id}_alerting_dynatop_last7_day")
            #to delete previus data in COLLECTION
            mg.delete_all_data()
            #add data in COLLECTION
            daystonow_result_data = {functional_environment: alertlist_daystonow}
            daystonow_result = {
                functional_environment : daystonow_result_data
            }
            mg.add_data(data=daystonow_result)
            logger.info("stored in mongo -> 7 days report")

            ######last 15 day dynatrace report######
            logger.debug("Get Dynatrace Response -> 15 days report")
            timedynafrom = "now-15d"
            alertlist_15daystonow = await dynatraceTOPALLTreatment(timedynaS=timedynafrom,timedynaE=None)
            logger.debug("Dynatrace Response completed -> 15 days report")

            #if mg.server_info():
            logger.info("starting mongoDB process -> 15 days report")
            #mg.change_collection(os.getenv("COLLECTION_DYNATRACE_HISTORICAL_ALERT"))
            mg.change_collection(f"{entity_id}_alerting_dynatop_last15_day")
            #to delete previus data in COLLECTION
            mg.delete_all_data()
            #add data in COLLECTION
            days15tonow_result_data = {functional_environment: alertlist_15daystonow}
            days15tonow_result = {
                functional_environment : days15tonow_result_data
            }
            mg.add_data(data=days15tonow_result)
            logger.info("stored in mongo -> 15 days report")

    return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "ok"}))

async def clusterhistoricalrestart(functional_environment,cluster=None,region=None):
    alertlist = []
    
    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)
    match cluster:
        case None:
            for cluster in list(clusters.keys()):
                logger.debug(f"Analizando cluster {cluster}")
                regionsList=list(clusters[cluster].keys())
                alertlist.extend(await getAlerts(client=client,cluster=cluster,regionsList=regionsList,functional_environment=functional_environment))
        case _:
            regionsList=list(clusters[cluster].keys())
            alertlist.extend(await getAlerts(client=client,cluster=cluster,regionsList=regionsList,functional_environment=functional_environment))
    return {functional_environment: alertlist}
