import aiohttp
from src.services.clientunique import client
from shuttlelib.utils.logger import logger
from src.services.pods import getRestartedPods, getStatusPods, getNotReadyPods
from src.services.dyna import getDynaProblems
from src.services.switch import getSwitchStatus


async def getAlerts(client,cluster,regionsList,functional_environment,switchednamespaces,minutes):
    alertlistTemp = []
    for region in regionsList:
        try:
            namespaceList = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {functional_environment + cluster + region}")
            continue
        except:
            logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
            continue

        try:
            items = namespaceList[region]['items']
        except:
            items = None
                
        if items != None and len(items) > 0:
            namespaceList = items            
            for namespace in namespaceList:
                namespaceName = namespace['metadata']['name']
                logger.debug(f"Get pods list -> Namespace: {namespaceName}")
                try:
                    podList = await client.get_resource(resource="pods",functional_environment=functional_environment,cluster=cluster,namespace=namespaceName,region=region)
                except aiohttp.client_exceptions.ServerTimeoutError:
                    logger.error(f"Timeout detected against get pods {functional_environment + namespaceName + cluster+region}")
                    continue
                except:
                    logger.error(f"Pods of {cluster}-{region}-{namespaceName} could not be retrieved. Skipping...")
                    continue
                logger.debug(f"Get pods list -> completed -> Namespace: {namespaceName}")
                #GET RESTARTED PODS
                logger.debug(f"Get list of restarted pods -> Namespace: {namespaceName}")
                restartedpodslist = await getRestartedPods(podList,cluster,region,switchednamespaces,functional_environment)
                alertlistTemp.extend(restartedpodslist)
                logger.debug(f"Get list of restarted pods -> completed -> Namespace: {namespaceName}")
                #GET NO-RUNNING PODS
                logger.debug(f"Get list of failed pods -> Namespace: {namespaceName}")
                statuspodslist = await getStatusPods(podList,cluster,region,switchednamespaces,functional_environment)
                alertlistTemp.extend(statuspodslist)
                logger.debug(f"Get list of failed pods -> completed -> Namespace: {namespaceName}")
                #GET NOT READY PODS
                logger.debug(f"Get list of not ready pods -> Namespace: {namespaceName}")
                notreadypodslist = await getNotReadyPods(podList,cluster,region,switchednamespaces,minutes=minutes,functional_environment=functional_environment)
                alertlistTemp.extend(notreadypodslist) 
                logger.debug(f"Get list of not ready pods -> completed -> Namespace: {namespaceName}")

    return alertlistTemp

async def clusteralerts(functional_environment,cluster=None,region=None,minutes=5):
    alertlist = []
    timedyna = "now-30m"
    
    #env = os.getenv("ENVIRONMENT")
    switchednamespaces = await getSwitchStatus(functional_environment)
    #GET DYNATRACE ALERTS 
    if functional_environment == 'pro':
        logger.debug("Get Dynatrace Response")
        dynalertslist = await getDynaProblems(timedyna=timedyna,switchednamespaces=switchednamespaces)
        alertlist.extend(dynalertslist)
        logger.debug("Dynatrace Response completed")

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)
    match cluster:
        case None:
            for cluster in list(clusters.keys()):
                logger.debug(f"Analizando cluster {cluster}")
                regionsList=list(clusters[cluster].keys())
                alertlist.extend(await getAlerts(client=client,cluster=cluster,regionsList=regionsList,functional_environment=functional_environment,switchednamespaces=switchednamespaces,minutes=minutes))
        case _:
            regionsList=list(clusters[cluster].keys())
            alertlist.extend(await getAlerts(client=client,cluster=cluster,regionsList=regionsList,functional_environment=functional_environment,switchednamespaces=switchednamespaces,minutes=minutes))

                            
    return {functional_environment: alertlist}