from shuttlelib.openshift.client import OpenshiftClient
from datetime import datetime
from calendar import monthrange, month_name
from pytz import timezone
from sys import platform
import os

entity_id=(os.getenv("ENTITY_ID","spain")).lower()
client = OpenshiftClient(entity_id=entity_id)

to_tz=(os.getenv("TZ","Europe/Madrid")).lower()

if platform == "win32":
    ssl_verify = False
else:
    ssl_verify = True

MONTHS = {
    "enero": 1, "ene": 1, "january": 1, "jan": 1, "1": 1,
    "febrero": 2, "feb": 2, "february": 2, "febr": 2, "2": 2,
    "marzo": 3, "mar": 3, "march": 3, "marz": 3, "3": 3,
    "abril": 4, "abr": 4, "april": 4, "apr": 4, "4": 4,
    "mayo": 5, "may": 5, "5": 5,
    "junio": 6, "jun": 6, "june": 6, "6": 6,
    "julio": 7, "jul": 7, "july": 7, "7": 7,
    "agosto": 8, "ago": 8, "august": 8, "aug": 8, "8": 8,
    "septiembre": 9, "sep": 9, "september": 9, "sept": 9, "9": 9,
    "octubre": 10, "oct": 10, "october": 10, "10": 10,
    "noviembre": 11, "nov": 11, "november": 11, "11": 11,
    "diciembre": 12, "dic": 12, "december": 12, "dec": 12, "12": 12
}

def formatTimeDyna(dt):
    #to transform the time to the format used by Dynatrace
    # in --> '2025-06-01T00:00:00.000000+0200'
    # out --> '2025-06-01T00:00:00.000+02:00'
    formatTime ="%Y-%m-%dT%H:%M:%S.%f%z"
    dynaTime = dt.strftime(formatTime)
    dynaTime = dynaTime[:23] + dynaTime[26:] 
    offset = dynaTime[-5:]
    offsetFormatted = offset[:3] + ":" + offset[3:]
    
    dynaTimeFormatted = dynaTime[:-5] + offsetFormatted
    
    return dynaTimeFormatted

def whichMonth(month):
    monthKey = month.lower()
    
    if monthKey in MONTHS:
        monthNum = MONTHS[monthKey] 
    monthName = month_name[monthNum]
    
    return monthNum, monthName.lower()
    
def daytoStarEndTime(year, month, day=None):    
    tz = timezone(to_tz)
    
    if day != None:  #daily execution
        date = f"{day}-{month}-{year}"
        date = datetime.strptime(date, "%d-%m-%Y")
        timedynafrom = tz.localize(datetime(date.year, date.month, date.day, 0, 0, 0))
        timedynato = tz.localize(datetime(date.year, date.month, date.day, 23, 59, 59))
    else:   #monthly execution    
        date = f"1-{month}-{year}"
        date = datetime.strptime(date, "%d-%m-%Y")
        lastDayofMonth = monthrange(date.year, date.month)[1]
        timedynafrom = tz.localize(datetime(date.year, date.month, 1, 0, 0, 0, 0))
        timedynato = tz.localize(datetime(date.year, date.month, lastDayofMonth, 23, 59, 59, 999000))
            
    timedynafrom = formatTimeDyna(timedynafrom)
    timedynato = formatTimeDyna(timedynato)

    return (timedynafrom, timedynato)

def convert_timezone(startedAt, input_format, output_format):
    # Parse the input datetime string as UTC
    dt_utc = datetime.strptime(startedAt, input_format)
    dt_utc = timezone("UTC").localize(dt_utc)
    # Convert to target timezone
    dt_tz = dt_utc.astimezone(timezone(to_tz))
    return dt_tz.strftime(output_format)

def getClustersData(environment):    
    clusterDataListALL = []    
    clusterDataListSimplified = []
    clusterNames = set()
    
    clusters = list(client.clusters[environment])
    for cluster in clusters:
        clusterData = client.clusters[environment][cluster]
        regions = list(clusterData)
        for region in regions:
            clusterData = client.clusters[environment][cluster][region]
            url = clusterData['url']            
            clusterData = {'environment': environment,
                    'cluster': cluster,
                    'region': region,
                    'url': url
            }                                                
            if clusterData:
                clusterDataListALL.append(clusterData)
    
    for cluster in clusterDataListALL:
        if (cluster['cluster']).lower() == "azure":            
            clusterDataListSimplified.append(cluster)
        elif cluster['cluster'] not in clusterNames:
            clusterDataListSimplified.append(cluster)
            clusterNames.add(cluster['cluster'])           
    
    return clusterDataListALL, clusterDataListSimplified

def getEnvironmentsClustersList():
    environmentList = []
    clusterList = []

    environmentList = list(client.clusters.keys())
    for environment in environmentList:
        clusterList.extend(client.clusters[environment])
    
    environmentList.extend([x.upper() for x in environmentList])
    
    clusterList.extend([x.upper() for x in clusterList])
    clusterList = list(set(clusterList))
    clusterList.sort()
    
    return environmentList, clusterList


