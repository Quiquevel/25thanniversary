import urllib3
import aiohttp
import re
import os

from time import time
from datetime import datetime
from fastapi import responses, status
from dateutil.relativedelta import relativedelta
from fastapi.encoders import jsonable_encoder
from shuttlelib.utils.logger import logger

from src.services.dyna import matchProblemTime, matchProblemSNOW, paasProblemRegion, matchClusterName, matchExceptionsDYNA, cleanAlertCustomizeType
from src.services.dyna import mg, dynaVariables, dynaVariablesKeys, clusterDataListSimplified, timeoutDyna
from src.services.clientunique import whichMonth, daytoStarEndTime, ssl_verify
from src.services.switch import getSwitchStatus

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

entity=(os.getenv("ENTITY_ID")).lower()
if entity == "spain":
    entity = "esp"   

urlbaseproblem = urlbaseapiproblems = urlbaseapientities = headers = proxy = None

async def dynatracetoMongo(detailalert, mode):
    #logger.info(f"starting dynatracetoMongo process ({mode})")      
    try:
        if mode == "byDay":       
            mongoAlert = list(mg.find({"problemId": detailalert[0]['problemId']}))
            if len(mongoAlert) > 0:
                mg.update_one({'_id': mongoAlert[0]['_id'],}, {'$set': detailalert[0]})  # Update existing data            
            else:            
                mg.add_data(data=detailalert[0])
        elif mode == "byMonth":                        
            mg.add_data(data=detailalert[0])
        #logger.info(f"finished dynatracetoMongo process ({mode})")
    except Exception as e:
        logger.error(f"Error in dynatracetoMongo: {e}")        

async def filterMicroservicesPAASorBKS(microserviceList, hostdetectedList):
    platform = None
    platformList = []

    filteredMicroservicesBKS = []
    filteredMicroservicesPAAS = []
    separatedMicroservices = []

    filteredHostsPAAS = []
    filteredHostsBKS = []
    separatedHosts = []

    if microserviceList != None and len(microserviceList) >= 0:
        for microservice in microserviceList:
            separatedMicroservices.extend(microservice.split(", "))
            filteredMicroservicesBKS = [micro for micro in separatedMicroservices if "-ens" in micro]
            filteredMicroservicesPAAS = [micro for micro in separatedMicroservices if "-ens" not in micro]

    if hostdetectedList != None and len(hostdetectedList) >= 0:
        for hostdetected in hostdetectedList:
            separatedHosts.extend(hostdetected.split(", "))
            filteredHostsBKS = [hostdetected for hostdetected in separatedHosts if "san01bks" in hostdetected]
            filteredHostsPAAS = [hostdetected for hostdetected in separatedHosts if "san01bks" not in hostdetected]            
    
    if filteredMicroservicesBKS or filteredHostsBKS:
        platform = "BKS"
        if platform not in platformList:
            platformList.append(platform)
    elif filteredMicroservicesPAAS or filteredHostsPAAS:
        platform = "PaaS"
        if platform not in platformList:
            platformList.append(platform)

    return platformList

async def eliminateDuplicateMicroservices(microserviceList):
    blocks = ("-b", "-g", "-blue", "-green" )
    filteredMicroservicesBG = []
    filteredMicroservicesNoBG = []
    separatedMicroservices = []
    microserviceListOut = []    
    
    for microservice in microserviceList:
        separatedMicroservices.extend(microservice.split(", "))
    
    filteredMicroservicesBG = [micro for micro in separatedMicroservices if micro.endswith(blocks) and ("-*-" or "*") not in micro]
    
    if not filteredMicroservicesBG:
        filteredMicroservicesNoBG = [micro for micro in microserviceList if ("-*-" or "*") not in micro]
    else:
        filteredMicroservicesNoBG = []

    microserviceAuxList = filteredMicroservicesBG if filteredMicroservicesBG else filteredMicroservicesNoBG
    for microservice in microserviceAuxList:
        if "-*-" not in microservice and "*" not in microservice:
            microserviceListOut.append(microservice)            

    return microserviceListOut
    
async def isSwitchedNamespace(namespace, switchedNamespacesList):
    if switchedNamespacesList != None:
        switched = [x for x in switchedNamespacesList if x == namespace]
        if switched:
            switchStatus = True
        else:
            switchStatus = False
    else: 
        switchStatus = False
    
    return switchStatus

async def paasProblemPlatform(platformList, hostdetectedList):
    platformListOut = []

    if len(platformList) > 0:
        for value in platformList:
            if "paas" in value.lower() or "azure" in value.lower():
                if len(hostdetectedList) > 0:
                    for host in hostdetectedList:
                        if host and ("paas" in host.lower() and "bks" in host.lower()):
                            platform = "BKS"
                            if platform not in platformListOut:
                                platformListOut.append(platform)
                        else:               
                            platform = "PaaS"
                            if platform not in platformListOut:
                                platformListOut.append(platform)
            elif "unix" in value.lower() or "linux" in value.lower():
                platform = "IaaS (UNIX)"
                if platform not in platformListOut:
                    platformListOut.append(platform)
            elif "win" in value.lower():
                platform = "IaaS (WIN)"
                if platform not in platformListOut:
                    platformListOut.append(platform)

    if len(platformList) == 0 or len(platformListOut) == 0:
        if len(hostdetectedList) > 0:
            for host in hostdetectedList:
                if host and ("weu" in host.lower()):
                    platform = "PaaS"
                    if platform not in platformListOut:
                        platformListOut.append(platform)
                if host and ("bks" in host.lower()):
                    platform = "BKS"
                    if platform not in platformListOut:
                        platformListOut.append(platform)
                if host and ("paas" in host.lower() and "bks" not in host.lower()):
                    platform = "PaaS"
                    if platform not in platformListOut:
                        platformListOut.append(platform)
    
    if len(platformListOut) == 0:
        platformListOut = None        

    return platformListOut

async def paasProblemCluster(hostdetectedList):
    clusterListOut = []
    
    if len(hostdetectedList) == 0:
        return None
    else:   
        for hostnames in hostdetectedList:
            if hostnames.find(", ") != -1:        
                hostnames = hostnames.split(", ")                                  
                    
            for cluster in clusterDataListSimplified:
                clusterName = cluster['cluster']
                urlCluster = cluster['url']
                elementsSplit = urlCluster.split(".")
                cluster = elementsSplit[1]
                zone = elementsSplit[3]
                if cluster in hostnames and zone in hostnames:
                    if clusterName not in clusterListOut:
                        clusterListOut.append(clusterName)
    if len(clusterListOut) == 0:
        clusterListOut = None

    return clusterListOut

async def detailAlertFill(type, displayId, problemId, status, start, end, platformList, namespaceList, microserviceList, hostdetectedList, responsibleTeamList, resolutorTeamList, switchStatus):
    detailalertlist = []
    clusterList = []
    regionList = []
    
    type = await cleanAlertCustomizeType(type)

    urlproblem = urlbaseproblem + problemId
    idSNOW, urlSNOW = await matchProblemSNOW(problemId, urlbaseapiproblems, headers, proxy)      

    yesNamespace = namespaceList != None and len(namespaceList) > 0
    yesHostDetected = hostdetectedList != None and len(hostdetectedList) > 0
    yesPlatform = platformList != None and len(platformList) > 0    
    yesMicroservice = microserviceList != None and len(microserviceList) > 0
    
    #MX
    if yesNamespace and yesHostDetected and yesMicroservice and not yesPlatform:
        platformList = ['PaaS']
        yesPlatform = True      
        
    isPaaS = bool(yesNamespace and yesMicroservice)
    
    #MX
    if yesPlatform and yesHostDetected:            
        platformList = await paasProblemPlatform(platformList, hostdetectedList)        
    elif isPaaS:
        platformList = ['PaaS']
        yesPlatform = True
    
    if platformList:
        for platform in platformList:
            if platform == "PaaS" or platform == "BKS":
                if microserviceList != None and len(microserviceList) >= 2:
                    microserviceList = await eliminateDuplicateMicroservices(microserviceList)
                if yesMicroservice:
                    platformList = await filterMicroservicesPAASorBKS(microserviceList, hostdetectedList)                

                if yesHostDetected:
                    clusterList = await paasProblemCluster(hostdetectedList) 
                    regions = await paasProblemRegion(hostdetectedList)
                    if regions:
                        regionList = [regions]
                    else:
                        regionList = None    
                else:
                    regionList = None                
                
                if clusterList != None and len(clusterList) == 0:
                    clusterList = await matchClusterName(problemId, urlbaseapiproblems, headers, proxy)
        
        #SCQ for NODE alerts
        if len(platformList) == 1 and platformList[0] != "PaaS" and yesNamespace:
            platformList[0] = "PaaS"

       
    
    noPlatform = platformList != None and len(platformList) == 0    
    noNamespace = namespaceList != None and len(namespaceList) == 0
    noMicroservice = microserviceList != None and len(microserviceList) == 0
    noCluster = clusterList != None and len(clusterList) == 0
    noRegion = regionList != None and len(regionList) == 0
    noHostDetected = hostdetectedList != None and len(hostdetectedList) == 0
    noResponsibleTeam = responsibleTeamList != None and len(responsibleTeamList) == 0
    noResolutorTeam =  resolutorTeamList != None and len(resolutorTeamList) == 0
    
    if noPlatform:
        platformList = None
    if noNamespace:
        namespaceList = None
    if noMicroservice:
        microserviceList = None
    if noCluster:
        clusterList = None
    if noRegion:
        regionList = None
    if noHostDetected:
        hostdetectedList = None
    if noResponsibleTeam:
        responsibleTeamList = None
    if noResolutorTeam:
        resolutorTeamList = None
    
    #MX
    #if None in (platformList, namespaceList) or [] in (platformList, namespaceList):
    if None in (platformList, namespaceList) or [] in (platformList, namespaceList):
        microserviceList = None    
    #MX
    #if yesHostDetected:            
    if hostdetectedList != None and len(hostdetectedList) > 0:
        # Fix: remove ".paas." only if it is at the end of the host string
        hostdetectedList = [host[:-6] if host.endswith(".paas.") else host for host in hostdetectedList]
        
        #SCQ
        for host in hostdetectedList:
            if ".dev." in host or ".pre." in host:                
                detailalertlist = []
                return detailalertlist
        
    infodetailalert = {
        'alertingType': type,
        'problemId': displayId,
        'urlproblem': urlproblem,
        'snowId': idSNOW,
        'urlsnow': urlSNOW,
        'incidentProvider': 'Dynatrace',
        'status': status,
        'start': start,
        'end': end,
        'platform': platformList,
        'namespace': namespaceList,
        'microservice': microserviceList,
        'cluster': clusterList,
        'region': regionList,
        'hosts': hostdetectedList,
        'responsibleTeam': responsibleTeamList,
        'resolutorTeam': resolutorTeamList,
        'switchStatus': switchStatus
    }
    
    detailalertlist.append(infodetailalert)

    return detailalertlist
    
async def loopDynaProblems(Ps, Vars, switchednamespaces, mode):
    detailalert = []
    detailalertlist = []
    switchStatus = None
    
    patternResponsible = re.compile(r'GrupoResponsable\d{3,}')
    patternResolutor = re.compile(r'GrupoResolutor:')
    
    for p in range(len(Ps)):
        platformList = []
        namespaceList = []
        microserviceList = []
        hostdetectedList = []
        responsibleTeamList = []
        resolutorTeamList = []
        responsibleTeam = resolutorTeam = namespace = microservice = platform = hostdetected = None
        
        paasproblem = Ps[p]
        problemtags = paasproblem["entityTags"]
        dateS, dateE = await matchProblemTime(paasproblem["startTime"], paasproblem["endTime"])
        displayId = paasproblem["displayId"]
        problemId = paasproblem["problemId"]
        title = paasproblem["title"]
        status = paasproblem["status"]
        
        #if displayId == "P-250746878":
        #    pass
                
        #logger.info(displayId)
        
        for t in range(len(problemtags)):
            value = problemtags[t].get("value", None)
            key = problemtags[t]['key']
            if value:
                if "GrupoResponsable" in key:
                    if patternResponsible.search(key):
                        responsibleTeam = value                            
                        if responsibleTeam != None and "WS_ABBYY" in responsibleTeam:
                                responsibleTeam = "SGT_IN_PR_ES_DOCUMENT_MNGMT"
                        if responsibleTeam != None and "WS_BTS" in responsibleTeam:
                                responsibleTeam = "SGT_IN_PR_ES_PROCESS_MNGMT"
                        if responsibleTeam and responsibleTeam not in responsibleTeamList:
                            responsibleTeamList.append(responsibleTeam)
                if "GrupoResolutor" in key:
                    if patternResolutor.search(key):
                        resolutorTeam = value
                        if resolutorTeam and resolutorTeam not in resolutorTeamList:
                            resolutorTeamList.append(resolutorTeam)
                match key:
                    case Vars.platformKey:
                        platform = value
                        if platform and platform not in platformList:
                            platformList.append(platform)
                    #case tag if tag in [pk.strip() for pk in Vars.projectKey.split(",")]:
                    case tag if tag in [pk.strip() for pk in Vars.projectKey.split(",")] if Vars.projectKey else []:
                        namespace = value
                        if namespace and namespace not in namespaceList:
                            namespaceList.append(namespace)
                    #case tag if tag in [pk.strip() for pk in Vars.containerKey.split(",")]:
                    case tag if tag in [pk.strip() for pk in Vars.containerKey.split(",")] if Vars.containerKey else []:
                        microservice = value
                        if microservice and microservice not in microserviceList:
                            microserviceList.append(microservice)
                    #case Vars.hostKey:
                    case tag if tag in [pk.strip() for pk in Vars.hostKey.split(",")] if Vars.hostKey else []:
                        hostdetected = value
                        if hostdetected != None and hostdetected.find(", ") != -1:
                            hostdetected = hostdetected.split(", ") 
                            for host in hostdetected:
                                if host not in hostdetectedList:
                                    hostdetectedList.append(host)
                        else: 
                            hostdetectedList.append(hostdetected)
                

        if None in (platformList, namespaceList) or len(hostdetectedList) == 0:
            platformOut, namespaceOut, microserviceOut, hostdetectedOut = await matchExceptionsDYNA(paasproblem, urlbaseapiproblems, headers, proxy, namespaceList, microserviceList, hostdetectedList, platformList)
            platformList = [platformOut] if type(platformOut) == str else platformOut                
            namespaceList = [namespaceOut] if type(namespaceOut) == str else namespaceOut                
            microserviceList = [microserviceOut] if type(microserviceOut) == str else microserviceOut      
            hostdetectedList = [hostdetectedOut] if type(hostdetectedOut) == str else hostdetectedOut                  

        #COR,P-250624067,host without paas configuration 
        if all(x is not None for x in [platformList, namespaceList, microserviceList, hostdetectedList]):
            if len(platformList) > 0 and len(namespaceList) > 0 and len(microserviceList) > 0 and len(hostdetectedList) > 0:
                for hostname in hostdetectedList:
                    if not ".paas." in hostname:
                        clusters = paasproblem.get('k8s.cluster.name', [])
                        for cluster in clusters:                
                            hostdetectedList.append(cluster + ".paas.")
                    elif ".paas." in hostname:
                        #platform = ['PaaS2.0']
                        platformList = ['PaaS']


        if namespaceList != None and len(namespaceList) > 0:
            for namespace in namespaceList:
                switchStatus = await isSwitchedNamespace(namespace, switchednamespaces)                            
                if "-dev" not in namespace and "-pre" not in namespace:
                    #MX
                    if title.endswith("-pro"):
                        title = paasproblem["severityLevel"]
                    detailalert = await detailAlertFill(title, displayId, problemId, status, dateS, dateE, platformList, namespaceList, microserviceList, hostdetectedList, responsibleTeamList, resolutorTeamList, switchStatus)
                else:
                    detailalert = []
        else:                          
            #MX
            if title.endswith("-pro"):
                title = paasproblem["severityLevel"]
            
            detailalert = await detailAlertFill(title, displayId, problemId, status, dateS, dateE, platformList, namespaceList, microserviceList, hostdetectedList, responsibleTeamList, resolutorTeamList, switchStatus)
           
        if len(detailalert) != 0:
            detailalertlist.extend(detailalert)
            if mode:
                await dynatracetoMongo(detailalert, mode)
        
        responsibleTeam = resolutorTeam = namespace = microservice = platform = hostdetected = None        

    return detailalertlist

async def DynaProblemsOTHERs(urlbaseapiproblems, urlbasepagesize, headers, params, proxy, Vars, switchednamespaces, mode):
    detailalertlist = []
    detailalertlistCurrent = []
    detailalertlistNext = []
    nextpagekey = ""

    async with aiohttp.ClientSession(timeout=timeoutDyna) as session:
        try:            
            #logger.info(f"Dynatrace GetProblems Proxy: {proxy}")
            async with session.get(urlbaseapiproblems, headers = headers, params = params, ssl = ssl_verify, proxy = proxy) as res:
                res_json = await res.json()
                Ps = res_json['problems']
                #logger.info(f"Dynatrace # alerts Ps: {len(Ps)}")
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {urlbaseapiproblems}")
            detailalertlist = {}
            return detailalertlist
        except:            
            logger.error(f"{urlbaseapiproblems} could not be retrieved. Skipping...") 
            detailalertlist = {}
            return detailalertlist            
        
        detailalertlistCurrent = await loopDynaProblems(Ps, Vars, switchednamespaces, mode)
        detailalertlist.extend(detailalertlistCurrent)            
        #loop for nextPageKey
        try:
            nextpagekey = res_json['nextPageKey']
        except:
            nextpagekey = None
        while nextpagekey is not None:
            #logger.info(f"Dynatrace alerts nextpagekey")
            async with session.get(urlbasepagesize + nextpagekey, headers = headers, ssl = ssl_verify, proxy = proxy) as resnextpagekey:
                resnextpagekey_json = await resnextpagekey.json()
                try:
                    nextpagekey = resnextpagekey_json['nextPageKey']
                except:
                    nextpagekey = None
                PsNext = resnextpagekey_json['problems']
                #logger.info(f"Dynatrace # alerts PsNext: {len(PsNext)}")
                detailalertlistNext = await loopDynaProblems(PsNext, Vars, switchednamespaces, mode)
                detailalertlist.extend(detailalertlistNext)
        #logger.info(f"Dynatrace alerts intermediate: {len(detailalertlist)}")
        
    return detailalertlist

async def getDynaProblemsOTHERs(entity, timedynaS = None, timedynaE = None, switchednamespaces = None, mode = None):
    global urlbaseproblem
    global urlbaseapiproblems
    global headers    
    global proxy
    
    #platformKey = projectKey = containerKey = hostKey = None
    detailalertlist = []
    
    class Vars:
        platformKey = None
        projectKey = None
        containerKey = None
        hostKey = None

    if timedynaS == None:
        timedynaS = "now"
    if timedynaE == None:
        params = {"from":timedynaS, "pageSize":"500"}
    else:        
        #timedynaS = "2024-08-01T00:00:00.000+02:00"       
        #timedynaE = "2024-08-01T23:59:00.000+02:00"
        params = {"from":timedynaS, "to":timedynaE, "pageSize":"500"}    

    entity=(os.getenv("ENTITY_ID")).upper()      

    for key in dynaVariablesKeys:            
        headers = dynaVariables[key]["headers"]                
        urlbaseapiproblems = dynaVariables[key]["urlbaseapiproblems"]
        urlbasepagesize = dynaVariables[key]["urlbasepagesize"]
        urlbaseproblem = dynaVariables[key]["urlbaseproblem"]
        proxy = dynaVariables[key]["proxy"]
    
        Vars.platformKey = dynaVariables['platformKey']
        Vars.projectKey = dynaVariables['projectKey']
        Vars.containerKey = dynaVariables['containerKey']
        Vars.hostKey = dynaVariables['hostKey']
    
        logger.info(f"Dynatrace getDynaProblemsOTHERs ({entity}-{key})")
        detailalertlistCurrent = await DynaProblemsOTHERs(urlbaseapiproblems, urlbasepagesize, headers, params, proxy, Vars, switchednamespaces, mode)
        detailalertlist.extend(detailalertlistCurrent)
        logger.info(f"Dynatrace alerts getDynaProblemsOTHERs ({entity}-{key}) Total: {len(detailalertlistCurrent)}")            
    
    return detailalertlist

async def dynatraceOTHERsBatchbyDay(functional_environment, day = None, month = None, year = None):
    startTime = time()
    now = datetime.now()
    logger.info(f'Time start dynatraceOTHERsBatchbyDay: {now}')
    
    if None in (day, month, year):
        now = datetime.now()
        yesterday = now - relativedelta(days = 1)
        year = yesterday.strftime("%Y")
        month = yesterday.strftime("%B").lower()
        day = yesterday.strftime("%d")
        
    monthNum, monthName = whichMonth(month)
    timedynaS, timedynaE = daytoStarEndTime(year, monthNum, day)
    
    mg.change_collection(f"{entity.lower()}_alerting_dyna_{monthName}_{year}")
    
    logger.info(f"starting dynatraceOTHERsBatchbyDay process in {entity}-> {day}-{monthName}-{year}")

    switchednamespaces = await getSwitchStatus(functional_environment)
    await getDynaProblemsOTHERs(entity, timedynaS, timedynaE, switchednamespaces, "byDay")
    logger.info(f"finished dynatraceOTHERsBatchbyDay process in {entity}-> {day}-{monthName}-{year}")
    
    now = datetime.now()    
    logger.info(f'Time finish dynatraceOTHERsBatchbyDay: {now}')
  
    endTime = time() 
    executionTime = endTime - startTime 
    m, s = divmod(executionTime, 60)
    h, m = divmod(m, 60)
    executionTimeFormat = "{:02.0f}:{:02.0f}:{:02.0f}".format(h, m, s)
    logger.info(f'Time execution dynatraceOTHERsBatchbyDay: {executionTimeFormat}')
    
    return responses.JSONResponse(status_code = status.HTTP_200_OK, content = jsonable_encoder({"detail": "ok"}))

async def dynatraceOTHERsBatchbyMonth(functional_environment, months, year=None):
    startTime = time()
    now = datetime.now()
    logger.info(f'Time start dynatraceOTHERsBatchbyMonth: {now}')
        
    if year is None:
        now = datetime.now()
        year = now.strftime("%Y")
    
    months = months.split(',')
    for month in months:
        month = month.strip()
        month = month.lower()
        
        monthNum, monthName = whichMonth(month)
        timedynaS, timedynaE =daytoStarEndTime(year, monthNum)
        mg.change_collection(f"{entity.lower()}_alerting_dyna_{monthName}_{year}")
        mg.delete_all_data() 

        logger.info(f"starting dynatraceOTHERsBatchbyMonth process in {entity}-> {monthName}-{year}")
        switchednamespaces = await getSwitchStatus(functional_environment)
        await getDynaProblemsOTHERs(entity, timedynaS, timedynaE, switchednamespaces, "byMonth")
        logger.info(f"finished dynatraceOTHERsBatchbyMonth process in {entity}-> {monthName}-{year}")

    now = datetime.now()    
    logger.info(f'Time finish dynatraceOTHERsBatchbyMonth: {now}')
    
    endTime = time() 
    executionTime = endTime - startTime 
    m, s = divmod(executionTime, 60)
    h, m = divmod(m, 60)
    executionTimeFormat = "{:02.0f}:{:02.0f}:{:02.0f}".format(h, m, s)
    logger.info(f'Time execution dynatraceOTHERsBatchbyMonth: {executionTimeFormat}')

    return responses.JSONResponse(status_code = status.HTTP_200_OK, content = jsonable_encoder({"detail": "ok"}))


async def dynatraceOTHERsTreatment(functional_environment, timedynaS, timedynaE):    
    entity=(os.getenv("ENTITY_ID")).lower()
    
    startTime = time()
   
    logger.info(f"starting getDynaProblemsOTHERs process in {entity}")    
    switchednamespaces = await getSwitchStatus(functional_environment)
    detailalertlist = await getDynaProblemsOTHERs(entity, timedynaS, timedynaE, switchednamespaces)
        
    endTime = time() 
    executionTime = endTime - startTime 
    m, s = divmod(executionTime, 60)
    h, m = divmod(m, 60)
    executionTimeFormat = "{:02.0f}:{:02.0f}:{:02.0f}".format(h, m, s)
    logger.info(f'Time execution: {executionTimeFormat}')
    logger.error(f'Time execution: {executionTimeFormat}')
        
    logger.info(f"finished getDynaProblemsOTHERs process in {entity}")

    return detailalertlist
