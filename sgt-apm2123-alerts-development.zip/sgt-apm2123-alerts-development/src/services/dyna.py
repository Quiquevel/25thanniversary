import aiohttp
import os

from datetime import datetime, timedelta
from fastapi import HTTPException
from urllib3 import disable_warnings, exceptions
from sys import platform
from src.services.switch import getSwitchStatus
from shuttlelib.utils.logger import logger
from shuttlelib.db.mongo import MongoClient
from src.services.clientunique import getClustersData, ssl_verify

disable_warnings(exceptions.InsecureRequestWarning)

try:
    mg = MongoClient()
except HTTPException as e:
    logger.error(f"Problems with mongo. ({e.status_code}-{e.detail}). Skipping...")
    mg = None
    pass

def envToList(envVar):
    return [item.strip() for item in envVar.split(",")] if envVar else []

DYNATRACE_TIMEOUT_CONNECT = int(os.getenv("CONNECTION_DYNATRACE_TIMEOUT", "5"))
DYNATRACE_TIMEOUT_TOTAL = int(os.getenv("TOTAL_DYNATRACE_TIMEOUT", "60"))
timeoutDyna = aiohttp.ClientTimeout(connect=DYNATRACE_TIMEOUT_CONNECT, total=DYNATRACE_TIMEOUT_TOTAL)

dynaVariables = {
    "nonSaaS": {
        "urlbaseproblem": os.getenv("DYNA_URI_BASEPROBLEM", None),
        "urlbaseapi": os.getenv("DYNA_URI_BASEAPI", None),
        "token": os.getenv("TOKEN_DYNA", None),
        "proxy": None,
    },
    "yesSaaS": {
        "urlbaseproblem": os.getenv("DYNA_URI_BASEPROBLEM_SaaS", None),
        "urlbaseapi": os.getenv("DYNA_URI_BASEAPI_SaaS", None),
        "token": os.getenv("TOKEN_DYNA_SaaS", None),
        "proxy": os.getenv("PROXY_DYNA", None)
    },
    "platformKey": os.getenv("PLATFORM_KEY", None),
    "platformValue": os.getenv("PLATFORM_VALUE", None),
    "projectKey": os.getenv("PROJECT_KEY", None),
    "containerKey": os.getenv("CONTAINER_KEY", None),
    "hostKey": os.getenv("HOST_KEY", None),
    "taskKey": os.getenv("TASK_KEY", None),
    "namespaceStartWith": envToList(os.getenv("DYNA_NAMESPACES", "")),
    "alertType": envToList(os.getenv("DYNA_TYPE_ALERTS", "")),
    "alertTypeMemory": envToList(os.getenv("DYNA_TYPE_MEMORY", "")),
    "statusMemory": os.getenv("DYNA_STATUS_MEMORY", None)
}

dynaVariablesKeys = ["nonSaaS", "yesSaaS"]
for key in dynaVariablesKeys:
    dynaVariables[key]["urlbaseapiproblems"] = dynaVariables[key]["urlbaseapi"] + "/problems"
    dynaVariables[key]["urlbaseapientities"] = dynaVariables[key]["urlbaseapi"] + "/entities"
    dynaVariables[key]["urlbasepagesize"] = dynaVariables[key]["urlbaseapiproblems"] + "?nextPageKey="
    dynaVariables[key]["headers"] = {"Authorization": "Api-Token " + dynaVariables[key]["token"], "Accept": "application/json; charset=utf-8"}

environment=(os.getenv("ENVIRONMENT")).lower()
clusterDataListALL, clusterDataListSimplified = getClustersData(environment)

platformOS = platform
if platformOS == "win32":
    dynaVariables["yesSaaS"]['proxy'] = None
   
urlbaseproblem = urlbaseapiproblems = urlbaseapientities = token = headers = proxy = platformKey = projectKey = containerKey = hostKey = None
platform = namespace = microservice = None
hostdetectedlist = []

async def cleanAlertCustomizeType(type):
    if type and "CUSTOMIZADOS" in type:
        if " - " in type:
            type = type.split(" - ")[0]
        elif " Servicio:" in type:
            type = type.split(" Servicio:")[0]
    return type

async def paasProblemCluster(hostdetectedlist):
    if len(hostdetectedlist) == 0:
        return None
    else:
        for hostname in hostdetectedlist:
            for cluster in clusterDataListSimplified:
                clusterName = cluster['cluster']
                urlCluster = cluster['url']
                elementsSplit = urlCluster.split(".")
                cluster = elementsSplit[1]
                zone = elementsSplit[3]
                if cluster in hostname and zone in hostname:
                    return clusterName
        else:
            return None

async def paasProblemRegion(hostdetectedlist):
    region = set()
    
    if len(hostdetectedlist) > 0: 
        for hostname in hostdetectedlist[:]:
            if not ".paas." in hostname:
                hostdetectedlist.remove(hostname)

    if len(hostdetectedlist) == 0: 
        return None
    
    for hostnames in hostdetectedlist:        
        if hostnames.find(", ") != -1:        
            hostnames = hostnames.split(", ")            
            regions = [nodo.split(".")[4] for nodo in hostnames if "." in nodo]            
            if len(regions) > 0:
                region = set()
                region.update(regions)                
            else:
                region = None        
        elif hostnames.find(".") != -1:
            if hostnames.find("corp") != -1:
                regions = [hostnames.split(".")[4]]
            else:
                try:
                    regions = [hostnames.split(".")[3]]            
                except:
                    return None
            if len(regions) > 0:
                region.update(regions)            
        else:
            region = None
        
    if region:
        region = ", ".join(str(item) for item in region)

    return region

async def detailAlertFill(displayId, problemId, type, status, start, end, namespace, microservice, hostdetectedlist, switchednamespaces):    
    detailalertlist = []
    cluster = None

    type = await cleanAlertCustomizeType(type)
    
    isPaaS = bool(namespace and microservice)
     
    if isPaaS:
        if switchednamespaces != None:
            switched = [x for x in switchednamespaces if x == namespace]
            if switched:
                switchStatus = True
            else:
                switchStatus = False
        else: 
            switchStatus = False

        urlproblem = urlbaseproblem + problemId
        inforegion = await paasProblemRegion(hostdetectedlist)
        cluster = await paasProblemCluster(hostdetectedlist) 
        idSNOW, urlSNOW = await matchProblemSNOW(problemId, urlbaseapiproblems, headers, proxy)    

        if not cluster and namespace and microservice:
            cluster = await matchClusterName(problemId, urlbaseapiproblems, headers, proxy)

        if not inforegion and namespace and microservice:
            hostdetectedlist = await matchRegionName(problemId, urlbaseapiproblems, headers, proxy)
            inforegion = await paasProblemRegion(hostdetectedlist)

        if cluster != None and cluster == "Azure" and "weu" not in inforegion:
            inforegion = None

        if microservice != None and "-ens-" in microservice and cluster !=None and not ("bks" in cluster or "dmz2bmov" in cluster):
            for hostname in hostdetectedlist:            
                if "san01bks.san.pro" in hostname:
                    cluster = "probks"                
                elif "san01bks.san.dmzb" in hostname:
                    cluster = "dmzbbks"        

        if microservice:
            if microservice and ", " in microservice:    
                microservice = microservice.split(", ")
                microservice = ''.join(microservice[1])

            if " " in microservice:
                microservice = microservice.split(" ")
                microservice = ''.join(microservice[0])

            if ":" in microservice:
                microservice = microservice.split(":")
                microservice = ''.join(microservice[0])

        if namespace == None:
            namespace = "**Revisar**"
        if microservice == None:
            microservice = "**Revisar**"
        if cluster == None:
            cluster = "**Revisar**"

        #logger.info(displayId)

        if inforegion != None:
            validateregion = inforegion.split(", ")
            if validateregion:
                for region in validateregion:
                    infodetailalert = {
                        'alertingType': type,
                        'problemId': displayId,
                        'urlproblem': urlproblem,
                        'snowId': idSNOW,
                        'urlsnow': urlSNOW,
                        'incidentProvider': 'Dynatrace',
                        'status': status,
                        'start': start,
                        'end': end,
                        'namespace': namespace,
                        'microservice': microservice,
                        'cluster': cluster,
                        'region': region,
                        'switchStatus': switchStatus
                    } 
                    detailalertlist.append(infodetailalert)
        else:        
            infodetailalert = {
                'alertingType': type,
                'problemId': displayId,
                'urlproblem': urlproblem,
                'snowId': idSNOW,
                'urlsnow': urlSNOW,
                'incidentProvider': 'Dynatrace',
                'status': status,
                'start': start,
                'end': end,
                'namespace': namespace,
                'microservice': microservice,
                'cluster': cluster,
                'region': None,
                'switchStatus': switchStatus
            } 
            detailalertlist.append(infodetailalert)

    return detailalertlist

async def matchProblemTime(starttime, endtime):
    dateE = None
    delta = 0
   
    dateDyna = int(starttime)/1000
    dateS = datetime.fromtimestamp(dateDyna)
    dateS = dateS + timedelta(hours = delta)
    dateS = dateS.strftime('%Y-%m-%d %H:%M:%S')

    if int(endtime) != -1:
        dateDyna = int(endtime)/1000
        dateE = datetime.fromtimestamp(dateDyna)
        dateE = dateE + timedelta(hours = delta)
        dateE = dateE.strftime('%Y-%m-%d %H:%M:%S')

    return (dateS, dateE)

async def matchProblemSNOW(problemId, urlbaseapiproblems, headers, proxy):
    idSNOW = urlSNOW = params = None
    urlrequestproblem = urlbaseapiproblems + '/' + problemId

    async with aiohttp.ClientSession(timeout=timeoutDyna) as session:
        try:            
            async with session.get(urlrequestproblem, headers = headers, params = params, ssl = ssl_verify, proxy = proxy) as res:
                Ps = await res.json()                
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {urlrequestproblem} ")            
            return None, None
        except:
            logger.error(f"{urlrequestproblem} could not be retrieved. Skipping...")
            return None, None

    try:
        comments = Ps["recentComments"]
    except:
        return None, None
    
    for comment in comments['comments']:
        if comment['content'].startswith("Incidencia creada en ServiceNow"):
            datos = comment['content'].split("\n")            
            try:
                urlSNOW = datos[3].lstrip('\n') 
            except:
                return None, None
            if datos[0].find(":") != -1:
                idSNOW = datos[0].split(":")
                idSNOW = str(idSNOW[1].strip()).rstrip('\\')
            else:
                return "revisar", "revisar"

    return idSNOW, urlSNOW

async def matchMicroserviceName(problemId, urlbaseapiproblems, headers, proxy):
    params = microservice = None
    urlrequestproblem = urlbaseapiproblems + '/' + problemId

    async with aiohttp.ClientSession(timeout=timeoutDyna) as session:
        try:            
            async with session.get(urlrequestproblem, headers = headers, params = params, ssl = ssl_verify, proxy = proxy) as res:
                Ps = await res.json()
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {urlrequestproblem} ")            
            return None
        except:
            logger.error(f"{urlrequestproblem} could not be retrieved. Skipping...")            
            return None

    try:
        evidenceDetails = Ps['evidenceDetails']['details']
    except:
        return None
    try:
        affectedEntities =  Ps['affectedEntities']
    except:
        return None
    
    for t in range(len(evidenceDetails)):
        evidence = evidenceDetails[t]
        if evidence['evidenceType'] == 'METRIC':
            try:
                microserviceAux = evidence['entity']['name']
            except:
                microserviceAux = None
            
            if microserviceAux and "-pro" in microserviceAux:
                microserviceAux = microserviceAux.split(" (")
                microserviceAux = ''.join(microserviceAux[1][0:-1])
                microservice = microserviceAux
            elif microserviceAux and ", " in microserviceAux:
                microserviceAux = microserviceAux.split(", ")
                microserviceAux = ''.join(microserviceAux[1])
                microservice = microserviceAux
    
    if not microservice:
        for t in range(len(affectedEntities)):
            affectedEntity = affectedEntities[t]
            if affectedEntity['entityId']['type'] == 'SERVICE':
                try:
                    microserviceAux = affectedEntity['name']
                except:
                    microserviceAux = None
                
                if microserviceAux and "_ENS" in microserviceAux:
                    microserviceAux = microserviceAux.split(" (")
                    microserviceAux = ''.join(microserviceAux[1][1:-1])
                    microservice = microserviceAux

    return microservice

async def matchClusterName(problemId, urlbaseapiproblems, headers, proxy):
    params = cluster = None
    urlrequestproblem = urlbaseapiproblems + '/' + problemId
    
    async with aiohttp.ClientSession(timeout=timeoutDyna) as session:
        try:            
            async with session.get(urlrequestproblem, headers = headers, params = params, ssl = ssl_verify, proxy = proxy) as res:
                Ps = await res.json()
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {urlrequestproblem} ")            
            return None
        except:
            logger.error(f"{urlrequestproblem} could not be retrieved. Skipping...") 
            return None

    try:
        evidenceDetails = Ps['evidenceDetails']['details']
    except:
        return None
    for t in range(len(evidenceDetails)):
        evidence = evidenceDetails[t]
        if evidence['evidenceType'] == 'EVENT':
            properties = evidence['data']['properties']
            if evidence['displayName'] == "Memory resources exhausted":
                for t in range(len(properties)):                    
                    key = properties[t]['key']                   
                    if key == 'host.name':
                        host = properties[t].get("value", None)
                        cluster = await paasProblemCluster([host])
                        return cluster
            elif evidence['displayName'] == "Long garbage-collection time":
                for t in range(len(properties)):                    
                    key = properties[t]['key']                   
                    if key == 'dt.event.description':
                        host = properties[t].get("value", None)
                        if "on host" in host:
                            hostPart = host.split("on host ")
                            cluster = await paasProblemCluster([hostPart[1]])
                            return cluster    

async def matchRegionName(problemId, urlbaseapiproblems, headers, proxy):
    params = host = None
    urlrequestproblem = urlbaseapiproblems + '/' + problemId
    hostList = []
    
    async with aiohttp.ClientSession(timeout=timeoutDyna) as session:
        try:            
            async with session.get(urlrequestproblem, headers = headers, params = params, ssl = ssl_verify, proxy = proxy) as res:
                Ps = await res.json()
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {urlrequestproblem} ")            
            return None
        except:
            logger.error(f"{urlrequestproblem} could not be retrieved. Skipping...") 
            return None

    try:
        evidenceDetails = Ps['evidenceDetails']['details']
    except:
        return None
    for t in range(len(evidenceDetails)):
        evidence = evidenceDetails[t]
        if evidence['evidenceType'] == 'EVENT':
            properties = evidence['data']['properties']
            if evidence['displayName'] == "Memory resources exhausted":
                for t in range(len(properties)):                    
                    key = properties[t]['key']                   
                    if key == 'host.name':
                        host = properties[t].get("value", None)
                        if host != None:
                            hostList.append(host)                           
            elif evidence['displayName'] == "Long garbage-collection time":
                for t in range(len(properties)):                    
                    key = properties[t]['key']                   
                    if key == 'dt.event.description':
                        host = properties[t].get("value", None)
                        if "on host" in host:
                            hostPart = host.split("on host ")
                            host=hostPart[1]
                            if host != None:
                                hostList.append(host)
    
    return hostList

async def matchExceptionsDYNA(paasproblem, urlbaseapiproblems, headers, proxy, namespace, microservice, hostdetectedlist, platform):    
    namespaceAux = microserviceAux = None
    
    if not namespace:
        try:
            namespaceAux = paasproblem['affectedEntities'][0]['name']
        except:
            namespaceAux = None
            
        if namespaceAux and "-pro" in namespaceAux:
            namespaceAux = namespaceAux.split("-")
            x = slice(3)
            namespaceAux = namespaceAux[x]
            namespaceAux = '-'.join(namespaceAux)
            namespace = namespaceAux
            if "-pro" not in namespace:
                namespace = None
        else:
            try:
                managementZones = paasproblem['managementZones']
            except:
                managementZones = []
            
            for t in range(len(managementZones)):
                managementZone = managementZones[t]
                nameMZ = managementZone.get('name', None)
                if nameMZ and "-pro" in nameMZ:
                    namespaceAux = nameMZ
                    namespaceAux = namespaceAux.split("- ")
                    namespace = ''.join(namespaceAux[-1:])
                    #if namespace.startswith(tuple(namespaceStartWith)):
                    if namespace.startswith(tuple(dynaVariables['namespaceStartWith'])):
                       break
    #MX
    if not namespace:
        namespace = paasproblem.get('k8s.namespace.name', None)
    
        if namespace and len(namespace) > 0:
            namespace = namespace[0]        
    
    if not microservice:
        try:
            microserviceAux = paasproblem['affectedEntities'][0]['name']
        except:
            microserviceAux = None
        
        if microserviceAux and "-pro" in microserviceAux:
            if " (" in microserviceAux:
                if microserviceAux.find("-pro-") != -1:  
                    microserviceAux = microserviceAux.split("-pro-")
                    microserviceAux = microserviceAux[1].split(" (")
                    microserviceAux = ''.join(microserviceAux[0])
                    microservice = microserviceAux
                else:
                    microservice = microserviceAux
            elif "_" in microserviceAux:
                if microserviceAux.find("_") != -1:
                    microserviceAux = microserviceAux.split("_")
                    microserviceAux = ''.join(microserviceAux[1])
                    microservice = microserviceAux
                else:
                    microservice = microserviceAux
            elif "-" in microserviceAux:
                if microserviceAux.find("-pro-") != -1:  
                    microserviceAux = microserviceAux.split("-pro-")
                    microserviceAux = ''.join(microserviceAux[1])
                    microservice = microserviceAux
                else:
                    microservice = microserviceAux
        elif microserviceAux and ", " in microserviceAux:
            microserviceAux = microserviceAux.split(", ")
            microserviceAux = ''.join(microserviceAux[1])
            microservice = microserviceAux
        elif microserviceAux and "-" in microserviceAux:            
            microservice = microserviceAux
        else:
            microservice = microserviceAux

        if not microservice:
            problemId = paasproblem["problemId"]
            microservice = await matchMicroserviceName(problemId, urlbaseapiproblems, headers, proxy)
        elif "," in microservice:
            microserviceAux = microserviceAux.split(", ")
            microserviceAux = ''.join(microserviceAux[0])
            microservice = microserviceAux

    if len(hostdetectedlist) == 0:
        try:
            managementZones = paasproblem['managementZones']
        except:
            managementZones = []
        
        for t in range(len(managementZones)):
            managementZone = managementZones[t]
            nameMZ = managementZone.get('name', None)
            if nameMZ and "OCP -" in nameMZ:
                hostdetectedlistAux = nameMZ
                hostdetectedlistAux = hostdetectedlistAux.split(" - ")                        
                hostdetectedlist.append(hostdetectedlistAux[1] + ".paas.")
                
    if len(hostdetectedlist) > 0 and not platform: 
        for hostname in hostdetectedlist[:]:
            if not ".paas." in hostname:
                hostdetectedlist.remove(hostname)
            elif ".paas." in hostname:
                platform = "PaaS"

    if len(hostdetectedlist) == 0:
        clusters = paasproblem.get('k8s.cluster.name', [])
        for cluster in clusters:                
            hostdetectedlist.append(cluster + ".paas.")
            
    #cambio por COR, alertas con host sin paas y platform PaaS
    #if len(hostdetectedlist) > 0 and ("paas" in platform.lower() or "azure" in platform.lower()): 
    '''
    if len(hostdetectedlist) > 0 and platform: 
        for hostname in hostdetectedlist:
            if not ".paas." in hostname:
                clusters = paasproblem.get('k8s.cluster.name', [])
                for cluster in clusters:                
                    hostdetectedlist.append(cluster + ".paas.")
            elif ".paas." in hostname:
                platform = "PaaS"
    '''            
    return platform, namespace, microservice, hostdetectedlist

async def loopDynaProblems(Ps, Vars, switchednamespaces):
    detailalert = []
    detailalertlist = []

    for p in range(len(Ps)):
        hostdetectedlist = []
        namespace = microservice = platform = hostdetected = None   
        
        paasproblem = Ps[p]
        problemtags = paasproblem["entityTags"]
        dateS, dateE = await matchProblemTime(paasproblem["startTime"], paasproblem["endTime"])
        displayId = paasproblem["displayId"]
        problemId = paasproblem["problemId"]
        title = paasproblem["title"]
        status = paasproblem["status"]
        
        #if displayId == "P-250733628":
        #    pass  
                
        #if paasproblem["title"] in dynaVariables['alertType']:
        if any(alert_pattern in paasproblem["title"] for alert_pattern in dynaVariables['alertType']):
            for t in range(len(problemtags)):
                value = problemtags[t].get("value", None)
                key = problemtags[t]['key']
                
                if value:
                    match key:
                        case Vars.platformKey:
                            platform = value
                        #case tag if tag in [pk.strip() for pk in Vars.projectKey.split(",") if Vars.projectKey != None]:
                        case tag if tag in [pk.strip() for pk in Vars.projectKey.split(",")] if Vars.projectKey else []:
                            namespace = value
                        #case tag if tag in [pk.strip() for pk in Vars.containerKey.split(",") if Vars.containerKey != None]:
                        case tag if tag in [pk.strip() for pk in Vars.containerKey.split(",")] if Vars.containerKey else []:
                            microservice = value
                        #case Vars.hostKey:
                        case tag if tag in [pk.strip() for pk in Vars.hostKey.split(",")] if Vars.hostKey else []:
                            hostdetected = value
                            hostdetectedlist.append(hostdetected)

            if None in (platform, namespace, microservice) or len(hostdetectedlist) == 0:
                platform, namespace, microservice, hostdetectedlist = await matchExceptionsDYNA(paasproblem, urlbaseapiproblems, headers, proxy, namespace, microservice, hostdetectedlist, platform)
            
            #alertas COR,P-250624067, host sin nada de paas
            if all(x is not None for x in [platform, namespace, microservice, hostdetectedlist]):
                if platform and namespace and microservice and len(hostdetectedlist) > 0:
                    if ("paas" in platform.lower() or "azure" in platform.lower()): 
                        for hostname in hostdetectedlist:
                            if not ".paas." in hostname:
                                clusters = paasproblem.get('k8s.cluster.name', [])
                                for cluster in clusters:
                                    hostdetectedlist.append(cluster + ".paas.")
                            elif ".paas." in hostname:
                                platform = "PaaS2.0"
            
            if namespace != None and ("-dev" not in namespace and "-pre" not in namespace):
                detailalert = await detailAlertFill(displayId, problemId, title, status, dateS, dateE, namespace, microservice, hostdetectedlist, switchednamespaces)
                  
                if len(detailalert) != 0:
                    detailalertlist.extend(detailalert)
            
        namespace = microservice = platform = hostdetected = None

    return detailalertlist

async def paasProblemPlatform(platform, hostdetectedlist):
    if "paas" in platform.lower() or "azure" in platform.lower():
        if len(hostdetectedlist) > 0:
            for host in hostdetectedlist:
                if host and ("paas" in host.lower() and "bks" in host.lower()):
                    platform = "BKS"
                else:
                    platform = "PaaS"
    elif "unix" in platform.lower():
        platform = "IaaS (UNIX)"
    elif "win" in platform.lower():
        platform = "IaaS (WIN)"

    if platform == None: 
        if len(hostdetectedlist) > 0:
            for host in hostdetectedlist:
                if host and ("weu" in host.lower()):
                    platform = "PaaS"
                if host and ("bks" in host.lower()):
                    platform = "BKS"
                if host and ("paas" in host.lower() and "bks" not in host.lower()):
                    platform = "PaaS"
    return platform

async def DynaProblems(urlbaseapiproblems, urlbasepagesize, headers, params, proxy, Vars, switchednamespaces):
    detailalertlist = []
    detailalertlistCurrent = []
    detailalertlistNext = []
    nextpagekey = ""

    async with aiohttp.ClientSession(timeout=timeoutDyna) as session:
        try:            
            #logger.info(f"Dynatrace GetProblems Proxy: {proxy}")
            async with session.get(urlbaseapiproblems, headers = headers, params = params, ssl = ssl_verify, proxy = proxy) as res:
                res_json = await res.json()
                Ps = res_json['problems']
                #logger.info(f"Dynatrace # alerts Ps: {len(Ps)}")
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {urlbaseapiproblems}")
            detailalertlist = {}
            return detailalertlist
        except:
            logger.error(f"{urlbaseapiproblems} could not be retrieved. Skipping...")
            detailalertlist = {}
            return detailalertlist
        
        detailalertlistCurrent = await loopDynaProblems(Ps, Vars, switchednamespaces)
        detailalertlist.extend(detailalertlistCurrent)
        #loop for nextPageKey
        try:
            nextpagekey = res_json['nextPageKey']
        except:
            nextpagekey = None
        while nextpagekey is not None:
            #logger.info(f"Dynatrace alerts nextpagekey")
            async with session.get(urlbasepagesize + nextpagekey, headers = headers, ssl = False, proxy = proxy) as resnextpagekey:
                resnextpagekey_json = await resnextpagekey.json()
                try:
                    nextpagekey = resnextpagekey_json['nextPageKey']
                except:
                    nextpagekey = None
                PsNext = resnextpagekey_json['problems']
                #logger.info(f"Dynatrace # alerts PsNext: {len(PsNext)}")
                detailalertlistNext = await loopDynaProblems(PsNext, Vars, switchednamespaces)
                detailalertlist.extend(detailalertlistNext)
        #logger.info(f"Dynatrace alerts intermediate: {len(detailalertlist)}")
        
    return detailalertlist

async def getDynaProblems(timedyna, switchednamespaces):    
    global urlbaseproblem
    global urlbaseapiproblems
    #global urlbaseapientities
    global headers
    global proxy
    
    #platformKey = projectKey = containerKey = hostKey = None
    detailalertlist = []
    class Vars:
        platformKey = None
        projectKey = None
        containerKey = None
        hostKey = None

    if timedyna == None:
        timedyna = "now"
        
    params = {"from":timedyna, "pageSize":"500"}
    #params = {"from":timedyna, "problemSelector":dynaVariables[entity][key]["managementZone"], "pageSize":"500"}
    #params = {"from":timedyna, "pageSize":"500"}                                
    #params = {"from":timedyna, "to":"now-3d", "problemSelector":dynaVariables[key]["managementZone"], "pageSize":"500"}
    #timedynaS = "2025-02-27T00:00:00.000+02:00"       
    #timedynaE = "2025-02-27T23:59:00.000+02:00"                                                    
    #params = {"from":timedynaS, "to":timedynaE, "pageSize":"500"}
    
    entity=(os.getenv("ENTITY_ID")).upper()

    for key in dynaVariablesKeys:
        headers = dynaVariables[key]["headers"]
        urlbaseapiproblems = dynaVariables[key]["urlbaseapiproblems"]
        #urlbaseapientities = dynaVariables[key]["urlbaseapientities"]
        urlbasepagesize = dynaVariables[key]["urlbasepagesize"]
        urlbaseproblem = dynaVariables[key]["urlbaseproblem"]
        proxy = dynaVariables[key]["proxy"]
    
        Vars.platformKey = dynaVariables['platformKey']
        Vars.projectKey = dynaVariables['projectKey']
        Vars.containerKey = dynaVariables['containerKey']
        Vars.hostKey = dynaVariables['hostKey']
    
        logger.info(f"Dynatrace getDynaProblems ({entity}-{key})")
        detailalertlistCurrent = await DynaProblems(urlbaseapiproblems, urlbasepagesize, headers, params, proxy, Vars, switchednamespaces)
        detailalertlist.extend(detailalertlistCurrent)
        logger.info(f"Dynatrace alerts getDynaProblems ({entity}-{key}) Total: {len(detailalertlistCurrent)}")            
    
    return detailalertlist

async def dynatraceTreatment(functional_environment, timedyna = None):
    logger.info(f"starting getDynaProblems process")
    
    switchednamespaces = await getSwitchStatus(functional_environment)
    detailalertlist = await getDynaProblems(timedyna, switchednamespaces)
    
    logger.info(f"finished getDynaProblems process")

    return detailalertlist