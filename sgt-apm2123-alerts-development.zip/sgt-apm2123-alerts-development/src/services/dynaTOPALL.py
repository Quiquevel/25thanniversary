import urllib3
import aiohttp
import os

from shuttlelib.utils.logger import logger
from src.services.clientunique import ssl_verify
from src.services.dyna import matchProblemTime, matchClusterName, paasProblemCluster, matchExceptionsDYNA, paasProblemPlatform, cleanAlertCustomizeType
from src.services.dyna import dynaVariables, dynaVariablesKeys, timeoutDyna


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

urlbaseproblem = urlbaseapiproblems = urlbaseapientities = headers = proxy = None

async def detailAlertFillTOPALL(displayId, problemId, type, start, end, namespace, microservice, platform, hostdetectedlist):
    detailalertlist = []
    cluster = None
    
    type = await cleanAlertCustomizeType(type)
    
    yesHostDetected = hostdetectedlist != None and len(hostdetectedlist) > 0
    
    isPaaS = bool(namespace and microservice)
    if isPaaS:      
        if platform:
            if yesHostDetected:
                platform = await paasProblemPlatform(platform, hostdetectedlist)

            if "paas" in platform.lower() or platform == "BKS":
                if len(hostdetectedlist) > 0: 
                    for hostname in hostdetectedlist[:]:
                        if not ".paas." in hostname:
                            hostdetectedlist.remove(hostname)

                if yesHostDetected: 
                    cluster = await paasProblemCluster(hostdetectedlist)

                if cluster == None:
                    cluster = await matchClusterName(problemId, urlbaseapiproblems, headers, proxy)

                if microservice:
                    if ", " in microservice:
                        microservice = microservice.split(", ")
                        microservice = ''.join(microservice[1])

                    if " " in microservice:
                        microservice = microservice.split(" ")
                        microservice = ''.join(microservice[0])

                    if ":" in microservice:
                        microservice = microservice.split(":")
                        microservice = ''.join(microservice[0])

                if namespace == None:
                    namespace = "**Revisar**"
                if microservice == None:
                    microservice = "**Revisar**"
                if cluster == None:
                    cluster = "**Revisar**"

                infodetailalert = {'problemId': displayId,
                                    'alertingType': type,
                                    'incidentProvider': 'Dynatrace',
                                    'start': start,
                                    'end': end,
                                    'namespace': namespace,
                                    'microservice': microservice,
                                    'cluster': cluster
                                    }    
                detailalertlist.append(infodetailalert)
                return detailalertlist
        elif namespace and microservice:
            cluster = await matchClusterName(problemId, urlbaseapiproblems, headers, proxy)
            infodetailalert = {'problemId': displayId,
                                    'alertingType': type,
                                    'incidentProvider': 'Dynatrace',
                                    'start': start,
                                    'end': end,
                                    'namespace': namespace,
                                    'microservice': microservice,
                                    'cluster': cluster
                                    }    
            detailalertlist.append(infodetailalert)
            return detailalertlist
        else:
            return []
    else:
        return []

async def loopDynaProblemsTOPALL(Ps, Vars):
    detailalert = []
    detailalertlist = []

    for p in range(len(Ps)):
        hostdetectedlist = []
        namespace = microservice = platform = hostdetected = None
        
        paasproblem = Ps[p]
        problemtags = paasproblem["entityTags"]
        dateS, dateE = await matchProblemTime(paasproblem["startTime"], paasproblem["endTime"])
        displayId = paasproblem["displayId"]
        problemId = paasproblem["problemId"]
        title = paasproblem["title"]

        #if displayId == "P-250970361":
        #    pass

        #if paasproblem["title"] in dynaVariables['alertType']: # and len(problemtags) > 0:
        if any(alert_pattern in paasproblem["title"] for alert_pattern in dynaVariables['alertType']):
            #hostdetected = ""
            for t in range(len(problemtags)):
                value = problemtags[t].get("value", None)
                key = problemtags[t]['key']
                if value:
                    match key:
                        case Vars.platformKey:
                            platform = value
                        #case tag if tag in [pk.strip() for pk in Vars.projectKey.split(",")]:
                        case tag if tag in [pk.strip() for pk in Vars.projectKey.split(",")] if Vars.projectKey else []:
                            namespace = value
                        #case tag if tag in [pk.strip() for pk in Vars.containerKey.split(",")]:
                        case tag if tag in [pk.strip() for pk in Vars.containerKey.split(",")] if Vars.containerKey else []:
                            microservice = value
                        #case Vars.hostKey:
                        case tag if tag in [pk.strip() for pk in Vars.hostKey.split(",")] if Vars.hostKey else []:
                            hostdetected = value
                            hostdetectedlist.append(hostdetected)
            
            if None in (platform, namespace, microservice) or len(hostdetectedlist) == 0:
                platform, namespace, microservice, hostdetectedlist = await matchExceptionsDYNA(paasproblem, urlbaseapiproblems, headers, proxy, namespace, microservice, hostdetectedlist, platform)
            
            #alertas COR,P-250624067, host sin nada de paas
            if all(x is not None for x in [platform, namespace, microservice, hostdetectedlist]):
                if platform and namespace and microservice and len(hostdetectedlist) > 0:
                    if ("paas" in platform.lower() or "azure" in platform.lower()): 
                        for hostname in hostdetectedlist:
                            if not ".paas." in hostname:
                                clusters = paasproblem.get('k8s.cluster.name', [])
                                for cluster in clusters:
                                    hostdetectedlist.append(cluster + ".paas.")
                            elif ".paas." in hostname:
                                platform = "PaaS"
            
            if namespace != None and ("-dev" not in namespace and "-pre" not in namespace):
                detailalert = await detailAlertFillTOPALL(displayId, problemId, title, dateS, dateE, namespace, microservice, platform, hostdetectedlist)
                       
                if detailalert != None and len(detailalert) != 0:
                    detailalertlist.extend(detailalert)

        namespace = microservice = platform = hostdetected = None

    return detailalertlist

async def DynaProblemsTOPALL(urlbaseapiproblems, urlbasepagesize, headers, params, proxy, Vars):
    detailalertlist = []
    detailalertlistCurrent = []
    detailalertlistNext = []
    nextpagekey = ""

    async with aiohttp.ClientSession(timeout=timeoutDyna) as session:
        try:            
            #logger.info(f"Dynatrace GetProblems Proxy: {proxy}")
            async with session.get(urlbaseapiproblems, headers = headers, params = params, ssl = ssl_verify, proxy = proxy) as res:
                res_json = await res.json()
                Ps = res_json['problems']
                #logger.info(f"Dynatrace # alerts Ps: {len(Ps)}")
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {urlbaseapiproblems}")
            detailalertlist = {}
            return detailalertlist
        except:            
            logger.error(f"{urlbaseapiproblems} could not be retrieved. Skipping...") 
            detailalertlist = {}
            return detailalertlist            
        
        detailalertlistCurrent = await loopDynaProblemsTOPALL(Ps, Vars)
        detailalertlist.extend(detailalertlistCurrent)            
        #loop for nextPageKey
        try:
            nextpagekey = res_json['nextPageKey']
        except:
            nextpagekey = None
        while nextpagekey is not None:
            #logger.info(f"Dynatrace alerts nextpagekey")
            async with session.get(urlbasepagesize + nextpagekey, headers = headers, ssl = ssl_verify, proxy = proxy) as resnextpagekey:
                resnextpagekey_json = await resnextpagekey.json()
                try:
                    nextpagekey = resnextpagekey_json['nextPageKey']
                except:
                    nextpagekey = None
                PsNext = resnextpagekey_json['problems']
                #logger.info(f"Dynatrace # alerts PsNext: {len(PsNext)}")
                detailalertlistNext = await loopDynaProblemsTOPALL(PsNext, Vars)
                detailalertlist.extend(detailalertlistNext)
        #logger.info(f"Dynatrace alerts intermediate: {len(detailalertlist)}")
        
    return detailalertlist

async def getDynaProblemsTOPALL(entity, timedynaS = None, timedynaE = None):
    global urlbaseproblem
    global urlbaseapiproblems
    global headers
    global proxy

    #platformKey = projectKey = containerKey = hostKey = None
    detailalertlist = []
    
    if timedynaS == None:
        timedynaS = "now"
    if timedynaE == None:
        params = {"from":timedynaS, "pageSize":"500"}
    else:
        #timedynaS = "2025-02-24T00:00:00.000+02:00"       
        #timedynaE = "2025-02-26T23:59:00.000+02:00"        
        params = {"from":timedynaS, "to":timedynaE, "pageSize":"500"}    

    class Vars:
        platformKey = None
        projectKey = None
        containerKey = None
        hostKey = None
    
    for key in dynaVariablesKeys:
        headers = dynaVariables[key]["headers"]
        urlbaseapiproblems = dynaVariables[key]["urlbaseapiproblems"]
        urlbasepagesize = dynaVariables[key]["urlbasepagesize"]
        urlbaseproblem = dynaVariables[key]["urlbaseproblem"]
        proxy = dynaVariables[key]["proxy"]
    
        Vars.platformKey = dynaVariables['platformKey']
        Vars.projectKey = dynaVariables['projectKey']
        Vars.containerKey = dynaVariables['containerKey']
        Vars.hostKey = dynaVariables['hostKey']
    
        logger.info(f"Dynatrace getDynaProblemsOTHERs ({entity}-{key})")
        detailalertlistCurrent = await DynaProblemsTOPALL(urlbaseapiproblems, urlbasepagesize, headers, params, proxy, Vars)
        detailalertlist.extend(detailalertlistCurrent)
        logger.info(f"Dynatrace alerts getDynaProblemsOTHERs ({entity}-{key}) Total: {len(detailalertlistCurrent)}")            
    
    return detailalertlist

async def dynatraceTOPALLTreatment(timedynaS, timedynaE):    
    entity=(os.getenv("ENTITY_ID")).lower()

    logger.info(f"starting getDynaProblemsTOPALL process in {entity}")
    detailalertlistTOP = await getDynaProblemsTOPALL(entity, timedynaS, timedynaE)
    logger.info(f"finished getDynaProblemsTOPALL process in {entity}")

    return detailalertlistTOP

