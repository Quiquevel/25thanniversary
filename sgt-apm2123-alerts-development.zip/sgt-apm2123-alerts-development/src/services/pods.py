from datetime import datetime
from shuttlelib.utils.logger import logger
from src.services.clientunique import client, convert_timezone
from src.services.switch import getSwitchStatus
import aiohttp

whitelist = []
input_format = "%Y-%m-%dT%H:%M:%SZ"
output_format = "%a %b %d %H:%M:%S %Y"

async def createNotReadyDict(targetcluster,region,namespace,podName,nodeName,podStartTime,dataextractionTime,difference,podState,reason,switchednamespaces,functional_environment):
    #find switchednamespaces
    switched = [x for x in switchednamespaces if x == namespace]
    if switched:
        switchStatus = True
    else:
        switchStatus = False
    
    result = {
        "alertingType": "NotReady",
        "incidentProvider": "Openshift",        
        "cluster": targetcluster,
        "region": region,
        "namespace": namespace,
        "podName": podName,
        "nodeName": nodeName,
        "podStartTime": podStartTime,
        "dataextractionTime": dataextractionTime,
        "difference": difference,
        "podState": podState,
        "reason": reason,
        "switchStatus": switchStatus,
        "urlproblem": await getUrlPods(functional_environment,cluster=targetcluster,region=region,namespace=namespace,podName=podName)
    }
    return result

async def getRestartedPods(podsList,cluster,region,switchednamespaces,functional_environment):
    logger.debug("Searching for Pods with restarts")
    restartedpodslist = []

    for pod in podsList[region]["items"]:
        if "-deploy" in pod["metadata"]["name"]:
            pass
        elif any(p in pod["metadata"]["name"] for p in whitelist):
            pass
            #ESTO SERÍA PARA HACER QUE PASE POR AQUÍ SI QUIERO SEPARAR PROYECTOS VOSTOK Y SHUTTLE
        else:
            if pod["status"]["phase"] == "Running":
                podName = pod["metadata"]["name"]
                namespace = pod["metadata"]["namespace"]
                restartCount = pod["status"]["containerStatuses"][0]["restartCount"]
                
                restartsCountParam = 1 #(at least one restart)
                if restartCount > restartsCountParam:
                    try:
                        exitCode = pod["status"]["containerStatuses"][0]['lastState']['terminated']['exitCode']
                    except KeyError:
                        exitCode = ""                    

                    try:
                        reason = pod["status"]["containerStatuses"][0]['lastState']['terminated']['reason']
                    except KeyError:
                        reason = ""

                    try:
                        if "running" in pod["status"]["containerStatuses"][0]['state']:
                            startedAt = pod["status"]["containerStatuses"][0]['state']['running']['startedAt']                                                                                                            
                            laststartPod_tz = convert_timezone(startedAt, input_format, output_format)
                            #################################

                        elif "waiting" in pod["status"]["containerStatuses"][0]['state']:
                            laststartPod_tz = "waiting"
                        else:
                            laststartPod_tz = ""
                    except:
                        laststartPod_tz = "NO-CONTAINER-STATUS"

                    '''if "startTime" in pod["status"]:
                        firststartPod = pod["status"]["startTime"]
                    else:
                        firststartPod = "Unknown_FirstStartPod"'''
                        
                    if exitCode == "" and reason == "":
                        codeAndReason = "NO-ERROR-CODE"
                    else:
                        codeAndReason = str(exitCode) + " - " + reason
                    
                    nodeName = pod["spec"]["nodeName"]

                    #find switchednamespaces
                    switched = [x for x in switchednamespaces if x == namespace]
                    if switched:
                        switchStatus = True
                    else:
                        switchStatus = False

                    podinfo = {
                        "alertingType": "Restarts",
                        "incidentProvider": "Openshift",
                        "podName": podName,
                        "restarts": restartCount,
                        "description": codeAndReason,
                        "lastStart": laststartPod_tz,
                        "namespace": namespace,
                        "nodeName": nodeName,
                        "switchStatus": switchStatus,
                        "cluster": cluster,
                        "region": region,
                        "urlproblem": await getUrlPods(functional_environment,cluster,region,namespace,podName)
                    }
        
                    restartedpodslist.append(podinfo)
    
    return restartedpodslist

async def getStatusPods(podsList,cluster,region,switchednamespaces,functional_environment):
    logger.debug("Searching for Pods with NO Running status")
    statuspodslist = []
    itemspodslist = []
    for pod in podsList[region]["items"]:
        if pod["status"]["phase"] != 'Running' and pod["status"]["phase"] != 'Completed' and pod["status"]["phase"] != 'Succeeded':
            try:
                podswrong = {}
                podswrong['cluster'] = cluster
                namespace = pod["metadata"]["namespace"]
                validationNamepod = pod["metadata"]["name"] if pod["metadata"].get("name") is not None else 'pod name not found'
                podswrong['pod'] = validationNamepod
                podswrong['status'] = pod["status"]["phase"]
                
                if pod["status"].get("startTime"):
                    validationage = datetime.strptime(pod["status"]["startTime"], '%Y-%m-%dT%H:%M:%SZ')
                    now = datetime.now()
                    #formatting and date calculation
                    datetimeage = validationage.strftime('%Y%m%d %H:%M:%S')
                    datetimenow = now.strftime('%Y%m%d %H:%M:%S')
                    diffage = (datetime.strptime(datetimenow, '%Y%m%d %H:%M:%S') - datetime.strptime(datetimeage, '%Y%m%d %H:%M:%S')).days
                else:
                    diffage = None
                podswrong['startTime(day)'] = diffage

                validationnodeName = pod["spec"]["nodeName"] if pod["spec"].get("nodeName") is not None else 'node not found'
                podswrong['nodo'] = validationnodeName

            except KeyError:
                podswrong[namespace] = []
        
            #find switchednamespaces
            switched = [x for x in switchednamespaces if x == namespace]
            if switched:
                switchStatus = True
            else:
                switchStatus = False

            podinfostatus = {
                "alertingType": "Status",
                "podName": podswrong['pod'],
                "incidentProvider": "Openshift",
                "description": podswrong['status'],
                "lastStart": podswrong['startTime(day)'],
                "namespace": namespace,
                "nodeName": podswrong['nodo'],
                "switchStatus": switchStatus,
                "cluster": cluster,
                "region": region,
                "urlproblem": await getUrlPods(functional_environment,cluster,region,namespace,podName=podswrong['pod'])
            }
            itemspodslist.append(podinfostatus)
    statuspodslist = [r for r in itemspodslist if r['lastStart'] is None or r['lastStart'] > 0]
    return statuspodslist

async def getNotReadyPods(podsList,cluster,region,switchednamespaces,minutes,functional_environment):
    today = datetime.today()
    notreadypodslist = []

    for pod in podsList[region]["items"]:
        infoNotReady = {}
        podPhase = pod["status"]["phase"]
        
        if podPhase == "Running":
            podReady =  pod["status"]["containerStatuses"][0]["ready"]
            
            if podReady == False:
                podState = list(pod["status"]["containerStatuses"][0]["state"].keys())[0]
                podName = pod["metadata"]["name"]
                nodeName = pod["spec"]["nodeName"]
                namespace=pod["metadata"]["namespace"]
                extractiondate=datetime.strftime(today, "%Y-%m-%d %H:%M:%S")            
                
                if podState == "running":
                    podStartedAt = pod["status"]["containerStatuses"][0]["state"]["running"]["startedAt"]
                    startTimedt = datetime.strptime(podStartedAt,"%Y-%m-%dT%H:%M:%SZ")
                    startingsince = (today - startTimedt).total_seconds()/60

                    if startingsince > int(minutes):
                        podStartTime=datetime.strftime(startTimedt, "%Y-%m-%d %H:%M:%S")
                        difference=str(int(startingsince))+" minutes"
                        reason="Pod has not started in 5min"
                        infoNotReady=await createNotReadyDict(targetcluster=cluster,region=region,namespace=namespace,podName=podName,nodeName=nodeName,podStartTime=podStartTime,dataextractionTime=extractiondate,difference=difference,podState=podState,reason=reason,switchednamespaces=switchednamespaces,functional_environment=functional_environment)
                elif podState == "waiting":
                    podStartTime = None
                    difference = None
                    reason = pod["status"]["containerStatuses"][0]["state"]["waiting"]["reason"]
                    infoNotReady=await createNotReadyDict(targetcluster=cluster,region=region,namespace=namespace,podName=podName,nodeName=nodeName,podStartTime=podStartTime,dataextractionTime=extractiondate,difference=difference,podState=podState,reason=reason,switchednamespaces=switchednamespaces,functional_environment=functional_environment)
                else:
                    podStartTime = None
                    difference = None
                    reason = "not running nor waiting"
                    infoNotReady=await createNotReadyDict(targetcluster=cluster,region=region,namespace=namespace,podName=podName,nodeName=nodeName,podStartTime=podStartTime,dataextractionTime=extractiondate,difference=difference,podState=podState,reason=reason,switchednamespaces=switchednamespaces,functional_environment=functional_environment)

        if any(infoNotReady):
            notreadypodslist.append(infoNotReady)
            
    return notreadypodslist

async def getUrlPods(functional_environment,cluster,region,namespace,podName):

    clusters = await client.get_resource(resource="clusters", functional_environment=functional_environment, cluster=cluster)
    cluster_api_url = clusters[cluster][region]['url']
    urlproblem = cluster_api_url.replace("api", "console-openshift-console.apps").replace(":6443", "/k8s/ns/") + namespace + "/pods/" + podName
    return urlproblem

async def podsrestartedTreatment(functional_environment,cluster=None,region=None):
    restartedpodslist = []
    switchednamespaces = await getSwitchStatus(functional_environment)

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)
    match cluster:
        case None:
            for cluster in list(clusters.keys()):
                for region in list(clusters[cluster].keys()):
                    try:
                        namespaceList = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {functional_environment + cluster + region}")
                        continue
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        continue
                    
                    try:
                        items = namespaceList[region]['items']
                    except:
                        items = None
                
                    if items != None and len(items) > 0:
                        namespaceList = items                        
                        for namespace in namespaceList:
                            namespaceName = namespace['metadata']['name']
                            try:
                                podList = await client.get_resource(resource="pods",functional_environment=functional_environment,cluster=cluster,namespace=namespaceName,region=region)
                            except aiohttp.client_exceptions.ServerTimeoutError:
                                logger.error(f"Timeout detected against get pods {functional_environment}-{namespaceName}-{cluster}-{region}")
                                continue
                            except:
                                logger.error(f"Pods of {cluster}-{region}-{namespaceName} could not be retrieved. Skipping...")
                                continue
                            tmplist = await getRestartedPods(podsList=podList,cluster=cluster,region=region,functional_environment=functional_environment,switchednamespaces=switchednamespaces)
                            restartedpodslist.extend(tmplist)
        case _:
            for region in list(clusters[cluster].keys()):
                try:
                    namespaceList = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
                except aiohttp.client_exceptions.ServerTimeoutError:
                    logger.error(f"Timeout detected against {functional_environment + cluster + region}")
                    continue
                except:
                    logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                    continue
                
                try:
                    items = namespaceList[region]['items']
                except:
                    items = None
                
                if items != None and len(items) > 0:
                    namespaceList = items
                    for namespace in namespaceList:
                        namespaceName = namespace['metadata']['name']
                        try:
                            podList = await client.get_resource(resource="pods",functional_environment=functional_environment,cluster=cluster,namespace=namespaceName,region=region)
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against get pods {functional_environment + namespaceName + cluster + region}")
                            continue
                        except:
                            logger.error(f"Pods of {cluster}-{region}-{namespaceName} could not be retrieved. Skipping...")
                            continue
                        tmplist = await getRestartedPods(podsList=podList,cluster=cluster,region=region,functional_environment=functional_environment,switchednamespaces=switchednamespaces)
                        restartedpodslist.extend(tmplist)
    return restartedpodslist

async def podsStatusTreatment(functional_environment,cluster=None,region=None):
    statuspodslist = []
    switchednamespaces = await getSwitchStatus(functional_environment)

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)  
    match cluster:
        case None:
            for cluster in list(clusters.keys()):
                for region in list(clusters[cluster].keys()):
                    try:
                        namespaceList = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {functional_environment + cluster + region}")
                        continue
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        continue
                    
                    try:
                        items = namespaceList[region]['items']
                    except:
                        items = None
                
                    if items != None and len(items) > 0:
                        namespaceList = items
                        for namespace in namespaceList:
                            namespaceName = namespace['metadata']['name']
                            try:
                                podList = await client.get_resource(resource="pods",functional_environment=functional_environment,cluster=cluster,namespace=namespaceName,region=region)
                            except aiohttp.client_exceptions.ServerTimeoutError:
                                logger.error(f"Timeout detected against get pods {functional_environment + namespaceName + cluster + region}")
                                continue
                            except:
                                logger.error(f"Pods of {cluster}-{region}-{namespaceName} could not be retrieved. Skipping...")
                                continue
                            tmplist1 = await getStatusPods(podList,cluster,region,functional_environment=functional_environment,switchednamespaces=switchednamespaces)
                            statuspodslist.extend(tmplist1)
        case _:
            for region in list(clusters[cluster].keys()):
                try:
                    namespaceList = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
                except aiohttp.client_exceptions.ServerTimeoutError:
                    logger.error(f"Timeout detected against {functional_environment + cluster + region}")
                    continue
                except:
                    logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                    continue
                    
                try:
                    items = namespaceList[region]['items']
                except:
                    items = None
                
                if items != None and len(items) > 0:
                    namespaceList = items
                    for namespace in namespaceList:
                        namespaceName = namespace['metadata']['name']
                        try:
                            podList = await client.get_resource(resource="pods",functional_environment=functional_environment,cluster=cluster,namespace=namespaceName,region=region)
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against get pods {functional_environment + namespaceName + cluster + region}")
                            continue
                        except:
                            logger.error(f"Pods of {cluster}-{region}-{namespaceName} could not be retrieved. Skipping...")
                            continue
                        tmplist1 = await getStatusPods(podList,cluster,region,functional_environment=functional_environment,switchednamespaces=switchednamespaces)
                        statuspodslist.extend(tmplist1) 
    return statuspodslist

async def podsNotReadyTreatment(functional_environment,cluster=None,region=None,minutes=5):
    notreadypodslist = []
    switchednamespaces = await getSwitchStatus(functional_environment)

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)
    match cluster:
        case None:
            for cluster in list(clusters.keys()):
                for region in list(clusters[cluster].keys()):
                    try:
                        namespaceList = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {functional_environment + cluster + region}")
                        continue
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        continue
                    
                    try:
                        items = namespaceList[region]['items']
                    except:
                        items = None
                
                    if items != None and len(items) > 0:
                        namespaceList = items
                        for namespace in namespaceList:
                            namespaceName = namespace['metadata']['name']
                            try:
                                podList = await client.get_resource(resource="pods",functional_environment=functional_environment,cluster=cluster,namespace=namespaceName,region=region)
                            except aiohttp.client_exceptions.ServerTimeoutError:
                                logger.error(f"Timeout detected against get pods {functional_environment + namespaceName + cluster + region}")
                                continue
                            except:
                                logger.error(f"Pods of {cluster}-{region}-{namespaceName} could not be retrieved. Skipping...")
                                continue
                            tmplist = await getNotReadyPods(podsList=podList,cluster=cluster,region=region,functional_environment=functional_environment,switchednamespaces=switchednamespaces,minutes=minutes)
                            notreadypodslist.extend(tmplist)
        case _:
            for region in list(clusters[cluster].keys()):
                try:
                    namespaceList = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
                except aiohttp.client_exceptions.ServerTimeoutError:
                    logger.error(f"Timeout detected against {functional_environment + cluster + region}")
                    continue
                except:
                    logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                    continue
                    
                try:
                    items = namespaceList[region]['items']
                except:
                    items = None
                
                if items != None and len(items) > 0:
                    namespaceList = items
                    for namespace in namespaceList:
                        namespaceName = namespace['metadata']['name']
                        try:
                            podList = await client.get_resource(resource="pods",functional_environment=functional_environment,cluster=cluster,namespace=namespaceName,region=region)
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against get pods {functional_environment + namespaceName + cluster + region}")
                            continue
                        except:
                            logger.error(f"Pods of {cluster}-{region}-{namespaceName} could not be retrieved. Skipping...")
                            continue
                        tmplist = await getNotReadyPods(podsList=podList,cluster=cluster,region=region,functional_environment=functional_environment,switchednamespaces=switchednamespaces,minutes=minutes)
                        notreadypodslist.extend(tmplist)
    return notreadypodslist