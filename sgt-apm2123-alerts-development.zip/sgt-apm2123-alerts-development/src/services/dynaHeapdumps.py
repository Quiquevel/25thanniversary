import aiohttp
import os

from urllib3 import disable_warnings, exceptions
from shuttlelib.utils.logger import logger
from src.services.clientunique import ssl_verify
from src.services.dyna import matchProblemTime, paasProblemCluster, paasProblemRegion, matchMicroserviceName
from src.services.dyna import dynaVariables, dynaVariablesKeys, timeoutDyna

disable_warnings(exceptions.InsecureRequestWarning)

urlbaseproblem = urlbaseapiproblems = urlbaseapientities = headers = proxy = None

async def matchPODs(paasproblem):
    try:
        affectedEntities =  paasproblem['affectedEntities']
    except:
        return None
   
    for t in range(len(affectedEntities)):
        affectedEntity = affectedEntities[t]
        if affectedEntity['entityId']['type'] == 'PROCESS_GROUP_INSTANCE':
            try:
                podsAux = affectedEntity['name']
            except:
                podsAux = None
            
            if podsAux and "-pro" in podsAux:
                podsAux = podsAux.split(" (")
                podsAux = ''.join(podsAux[1][0:-1])
                pods = podsAux
            else:
                pods = podsAux.split('(')[-1].replace(')', '').strip()
    return [pods]

async def matchMicroservice(paasproblem):
    microservice = microserviceAux = None
    
    try:
        microserviceAux = paasproblem['affectedEntities'][0]['name']
    except:
        microserviceAux = None
    
    if microserviceAux and "-pro" in microserviceAux:
        if " (" in microserviceAux:
            if microserviceAux.find("-pro-") != -1:  
                microserviceAux = microserviceAux.split("-pro-")
                microserviceAux = microserviceAux[1].split(" (")
                microserviceAux = ''.join(microserviceAux[0])
                microservice = microserviceAux
            else:
                microservice = microserviceAux
        elif "_" in microserviceAux:
            if microserviceAux.find("_") != -1:
                microserviceAux = microserviceAux.split("_")
                microserviceAux = ''.join(microserviceAux[1])
                microservice = microserviceAux
            else:
                microservice = microserviceAux
        elif "-" in microserviceAux:
            if microserviceAux.find("-pro-") != -1:  
                microserviceAux = microserviceAux.split("-pro-")
                microserviceAux = ''.join(microserviceAux[1])
                microservice = microserviceAux
            else:
                microservice = microserviceAux

    if not microservice:
        problemId = paasproblem["problemId"]
        microservice = await matchMicroserviceName(problemId, urlbaseapiproblems, headers, proxy)

    if "," in microservice:        
        microservice = [item.strip() for item in microservice.split(',') if '*' not in item][0]

    return microservice

async def mapPODstoRegionCluster(paasproblem, session, urlbaseapientities, headers):    
    entities = paasproblem.get('affectedEntities', [])
    tasks = []

    for entity in entities:
        name = entity.get('name', '')
        entity_id = entity.get('entityId', {}).get('id', '')
        
        if '(' in name and ')' in name and entity_id.startswith("PROCESS_GROUP_INSTANCE"):
            pod = name.split('(')[-1].replace(')', '').strip()
            url = f"{urlbaseapientities}/{entity_id}"
            tasks.append((pod, url))

    results = []
    for pod, url in tasks:
        try:
            async with session.get(url, headers = headers, ssl = ssl_verify, proxy = proxy) as res:
                entity_data = await res.json()

                if 'error' in entity_data:
                    error_code = entity_data['error'].get('code')
                    error_message = entity_data['error'].get('message', '')
                    
                    if error_code == 403:
                        logger.warning(f"Token missing 'entities.read' scope for {url}. Skipping entity enrichment.")
                        results.append({'pod': pod, 'region': None, 'cluster': None})
                        continue
                    else:
                        logger.error(f"API error {error_code}: {error_message} for {url}")
                        results.append({'pod': pod, 'region': None, 'cluster': None})
                        continue

                tags = entity_data.get('tags', [])
                hostdetected = next((tag.get('value') for tag in tags if tag.get('key') == 'HostDetectedName'), None)
                
                region = await paasProblemRegion([hostdetected])
                cluster = await paasProblemCluster([hostdetected])
                
                results.append({'pod': pod, 'region': region, 'cluster': cluster})
        except Exception as e:
            logger.error(f"Error fetching entity {url}: {e}")
            results.append({'pod': pod, 'region': None, 'cluster': None})

    return results
        

async def loopDynaProblemsMemory(Ps, Vars):
    detailalertlist = []
    
    for p in range(len(Ps)):
        namespace = microservice = pods = None
        detailalert = {}
        hostdetectedlist = []
        podlist = []
        
        paasproblem = Ps[p]
        problemtags = paasproblem["entityTags"]
        dateS, dateE = await matchProblemTime(paasproblem["startTime"], paasproblem["endTime"])
        displayId = paasproblem["displayId"]
        status = paasproblem["status"]
        
        #if displayId == "P-25076835":
        #    pass  


        if paasproblem["title"] in dynaVariables['alertTypeMemory']:
            for t in range(len(problemtags)):
                value = problemtags[t].get("value", None)
                key = problemtags[t]['key']
                type = paasproblem["title"]
                
                if value:
                    match key:
                        case tag if tag in [pk.strip() for pk in Vars.projectKey.split(",")] if Vars.projectKey else []:
                            namespace = value
                        case tag if tag in [pk.strip() for pk in Vars.containerKey.split(",")] if Vars.containerKey else []:
                            microservice = value
                        case tag if tag in [pk.strip() for pk in Vars.hostKey.split(",")] if Vars.hostKey else []:
                            hostdetected = value
                            if hostdetected != None and hostdetected.find(", ") != -1:
                                hostdetected = hostdetected.split(", ") 
                                for host in hostdetected:
                                    if host not in hostdetectedlist:
                                        if ".paas." not in host:
                                            host = host + ".paas."
                                        hostdetectedlist.append(host)
                            else: 
                                hostdetectedlist.append(hostdetected)
                        case Vars.taskKey:
                            pod = value
                            podlist.append(pod)

            if namespace and "-dev" not in namespace and "-pre" not in namespace:

                if microservice and microservice.find(", ") != -1:
                    microserviceList = microservice.split(", ")
                    for microservice in microserviceList[:]:
                        if "-*-" in microservice:
                            microserviceList.remove(microservice)
                elif not microservice:
                    microservice = await matchMicroservice(paasproblem)


                async with aiohttp.ClientSession(timeout=timeoutDyna) as session:
                    pods = await mapPODstoRegionCluster(
                        paasproblem,
                        session,
                        urlbaseapientities=urlbaseapientities,
                        headers=headers
                    )

                should_include_alert = False

                if Vars.namespace and Vars.microservice:
                    if namespace == Vars.namespace and microservice == Vars.microservice:
                        should_include_alert = True
                elif Vars.namespace and not Vars.microservice:
                    if namespace == Vars.namespace:
                        should_include_alert = True
                elif not Vars.namespace and not Vars.microservice:
                    should_include_alert = True

                if not pods or all(p.get('pod') in [None, 'unknown'] for p in pods) or any(p.get('region') is None or p.get('cluster') is None for p in pods if p.get('pod') not in [None, 'unknown']):
                    if len(podlist) == 0:
                        podlist = await matchPODs(paasproblem)

                    if podlist:
                        cluster = await paasProblemCluster(hostdetectedlist)
                        regions = await paasProblemRegion(hostdetectedlist)

                        pods = []
                        for pod in podlist:
                            if pod and pod not in [p.get('pod') for p in pods]:
                                pods.append({'pod': pod, 'region': regions, 'cluster': cluster})

                if namespace and microservice and pods and should_include_alert:
                    detailalert = {
                        'alertingType': type,
                        'problemId': displayId,
                        'status': status,
                        'start': dateS,
                        'end': dateE,
                        'namespace': namespace,
                        'microservice': microservice,
                        'pods': pods
                    }

                if detailalert:
                    detailalertlist.append(detailalert)

        namespace = microservice = pods = None

    return detailalertlist

async def DynaProblemsMemory(urlbaseapiproblems, urlbasepagesize, headers, params, proxy, Vars):
    detailalertlist = []
    detailalertlistCurrent = []
    detailalertlistNext = []
    nextpagekey = ""

    async with aiohttp.ClientSession(timeout=timeoutDyna) as session:
        try:
            async with session.get(urlbaseapiproblems, headers = headers, params = params, ssl = ssl_verify, proxy = proxy) as res:
                res_json = await res.json()
                Ps = res_json['problems']
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {urlbaseapiproblems}")
            detailalertlist = {}
            return detailalertlist
        except:
            logger.error(f"{urlbaseapiproblems} could not be retrieved. Skipping...")
            detailalertlist = {}
            return detailalertlist
        
        detailalertlistCurrent = await loopDynaProblemsMemory(Ps, Vars)
        detailalertlist.extend(detailalertlistCurrent)
        #loop for nextPageKey
        try:
            nextpagekey = res_json['nextPageKey']
        except:
            nextpagekey = None
        while nextpagekey is not None:
            async with session.get(urlbasepagesize + nextpagekey, headers = headers, ssl = False, proxy = proxy) as resnextpagekey:
                resnextpagekey_json = await resnextpagekey.json()
                try:
                    nextpagekey = resnextpagekey_json['nextPageKey']
                except:
                    nextpagekey = None
                PsNext = resnextpagekey_json['problems']
                detailalertlistNext = await loopDynaProblemsMemory(PsNext, Vars)
                detailalertlist.extend(detailalertlistNext)
        
    return detailalertlist

async def getDynaMemoryProblems(timedyna, namespace, microservice):
    global urlbaseproblem
    global urlbaseapiproblems
    global urlbaseapientities
    global headers
    global proxy

    #platformKey = projectKey = containerKey = hostKey = None
    detailalertlist = []
    class Vars:
        platformKey = None
        projectKey = None
        containerKey = None
        namespace = None
        microservice = None
        hostKey = None
        taskKey = None

    if timedyna == None:
        timedyna = "now"

    platformValues = [v.strip() for v in dynaVariables["platformValue"].split(",")]
    status = dynaVariables["statusMemory"].lower()
    if status not in ["open", "closed"]:
        status = None
    
    #entityTagsFilters = ",".join([f'entityTags("{dynaVariables["platformKey"]}:{val}")' for val in platformValues])
    #params = {"from":timedyna, "pageSize":"500", "problemSelector": "status(\"open\")"}
    #params = {"from":timedyna, "pageSize":"500", "problemSelector": f'status("open"),entityTags("{dynaVariables["platformKey"]}")'}
    #params = {"from":timedyna, "pageSize":"500", "problemSelector": f'status("closed"),entityTags("{dynaVariables["platformKey"]}")'}
    #params = {"from":timedyna, "pageSize":"500", "problemSelector": f'status("closed"),entityTags("{dynaVariables["platformKey"]}":"{dynaVariables["platformValue"]}")'}
    #params = {"from":timedyna, "pageSize":"500", "problemSelector": f'entityTags("{dynaVariables["platformKey"]}:{dynaVariables["platformValue"]}")'}
    #params = {"from":timedyna, "pageSize":"500", "problemSelector": f'status("open"),entityTags("{dynaVariables["platformKey"]}:{dynaVariables["platformValue"]}")'}
    #params = {"from":timedyna, "pageSize":"500", "problemSelector": f'status("closed"),entityTags("{dynaVariables["platformKey"]}:{dynaVariables["platformValue"]}")'}
    '''
    params = {"from":timedyna, 
              "pageSize":"500", 
              "problemSelector": f'status("closed"),{entityTagsFilters}'
    }
    '''
    
    entity=(os.getenv("ENTITY_ID")).upper()

    for val in platformValues:
        '''
        if status is None:
            params = {
                "from": timedyna,
                "pageSize": "500"
            }
        
        elif dynaVariables["platformValue"] == "" or dynaVariables["platformValue"] is None:
            params = {
                "from": timedyna,
                "pageSize": "500",
                "problemSelector": f'status("{status}")'
            }
        else:
            params = {
                "from": timedyna,
                "pageSize": "500",
                "problemSelector": f'status("{status}"),entityTags("{dynaVariables["platformKey"]}:{val}")'
            }
        '''        
        
        params = {
            "from": timedyna,
            "pageSize": "500"
        }

        selectors = []
        if status is not None:
            selectors.append(f'status("{status}")')

        if dynaVariables["platformValue"] and dynaVariables["platformValue"] != "":
            selectors.append(f'entityTags("{dynaVariables["platformKey"]}:{val}")')

        if selectors:
            params["problemSelector"] = ",".join(selectors)
        
        for key in dynaVariablesKeys:
            headers = dynaVariables[key]["headers"]
            urlbaseapiproblems = dynaVariables[key]["urlbaseapiproblems"]
            urlbaseapientities = dynaVariables[key]["urlbaseapientities"]
            urlbasepagesize = dynaVariables[key]["urlbasepagesize"]
            urlbaseproblem = dynaVariables[key]["urlbaseproblem"]
            proxy = dynaVariables[key]["proxy"]
        
            Vars.platformKey = dynaVariables['platformKey']
            Vars.projectKey = dynaVariables['projectKey']
            Vars.containerKey = dynaVariables['containerKey']
            Vars.namespace = namespace
            Vars.microservice = microservice
            Vars.hostKey = dynaVariables['hostKey']
            Vars.taskKey = dynaVariables['taskKey']

            logger.info(f"Dynatrace getDynaProblems Memory ({entity}-{key}-{val}-{status})")
            detailalertlistCurrent = await DynaProblemsMemory(urlbaseapiproblems, urlbasepagesize, headers, params, proxy, Vars)
            detailalertlist.extend(detailalertlistCurrent)
            logger.info(f"Dynatrace alerts getDynaProblems Memory ({entity}-{key}-{val}-{status}) Total: {len(detailalertlistCurrent)}")
    
    return detailalertlist

async def dynatraceMemoryTreatment(functional_environment, timedyna = None, namespace = None, microservice = None):
    logger.info(f"starting getDynaProblems Memory process")    
    
    detailalertlist = await getDynaMemoryProblems(timedyna, namespace, microservice)
    
    logger.info(f"finished getDynaProblems Memory process")

    return detailalertlist
