"""
This module contains the main FastAPI application for the microservice.
"""
from fastapi import FastAPI
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers
from src.app.config.composer_config import config as composer_config

app = FastAPI()

description = """
sgt-apm2123-alerts

### SUMMARY
Microservice for obtaining several alerts to analyze:

- Dynatrace Alerts
- Restarted pods
- No-running pods
- Not ready pods

### ENDPOINTS
* **/all:** Gets Dynatrace alerts, pods with some restarts and pods with status phase not running or complete.
* **/dynatrace:** Gets Dynatrace PaaS alerts.
* **/dynatraceTOPALL:** Gets TOP Dynatrace PaaS alerts.
* **/dynatraceOTHERsALL:** Gets ALL Dynatrace alerts(PaaS or IaaS).
* **/dynatraceOTHERsALLbyMonth:** Gets ALL Dynatrace alerts(PaaS or IaaS) by month to Mongo.
* **/dynatraceOTHERsALLbyDay:** Gets ALL Dynatrace alerts(PaaS or IaaS) by day previously (yestarday) to Mongo.
* **/restarts:** Gets the pods with some restarts (>1).
* **/failedPods:** Gets the pods with status phase not running or complete (with more than 1 day).
* **/notreadypods** Gets the pods with phase Running but ready:False more than X minutes (default: 5). If the status is "waiting" the 'minutes' starting is not relevant.
* **/clusterhistoricalalertsbymonth** Get the cluster historical TOP Dynatrace alerts by month -> follow the following format -> "january,february,march,april,may,june,july,august,september,october,november,december".
* **/alertingAuthorization:** Validate user UID - Authorization

### PARAMETERS
* **functionalEnvironment:** dev, pre, pro
* **minutes:** Optional parameter for /notreadypods and /all (default: 5). It should be a string --> "minutes": "1"
* **cluster:** bks, ocp05azure, azure, dmzbazure, prodarwin, dmzbdarwin, confluent, probks, dmzbbks, dmz2bmov, ..
* **region:** bo1, bo2, weu1, weu2
* **timedyna:** now-1h, now-30m, now-1d (only dynatrace)
* **timedynafrom:** relative time, human-readable and timestamps (dynatraceTOPALL and dynatraceOTHERsALL)
* **timedynato**: relative time, human-readable and timestamps (dynatraceTOPALL and dynatraceOTHERsALL)
* **year**: Optional parameter for dynatraceOTHERsALLbyMonth
* **months**: jan, ene, january, enero, etc. Can be a list of months. Parameter for dynatraceOTHERsALLbyMonth

### DETAILS
* **functionalEnvironment/cluster/region:**\n
    "dev":\n
        "bks": {"bo1"}
        "ocp05azure": {"weu1"}
        "azure": {"weu1"}
    "pre":\n
        "bks": {"bo1","bo2"}
        "ocp05azure": {"weu1","weu2"}
        "azure": {"weu1","weu2"}
    "pro":\n
        "prodarwin": {"bo1","bo2"}
        "dmzbdarwin": {"bo1","bo2"}
        "azure": {"weu1","weu2"}
        "dmzbazure": {"weu1","weu2"}
        "ocp05azure": {"weu1","weu2"}
        "confluent": {"bo1","bo2"}
        "probks": {"bo1","bo2"}
        "dmzbbks": {"bo1","bo2"}
        "dmz2bmov": {"bo1","bo2"}

* **Detail by timedynafrom and timedynato:**\n
    "relative time": format is now-NU/A, where N is the amount of time, U is the unit of time, and A is an alignment.
        now-1w --> one week before now, same time-of-day as now
        now/w --> the beginning of the current week (Monday, 00:00:00.00)
        now/w-d --> also beginning of the week, depending on who you ask (Sunday, 00:00:00.00)
        now/M+5m --> Five minutes into the current month

        Example (alerts from yestarday):
            "timedynafrom": "now-2d",
            "timedynato": "now-1d"                 

        Example (alerts from an hour ago):
            "timedynafrom": "now-2h",
            "timedynato": "now-1h"
        
    "human-readable": format of 2021-01-25T05:57:01.123+01:00.
        Note: in summer period --> +02:00, in winter period --> +01:00

        Example (2023-05-10T09:00 to 2023-05-10T13:00):
            "timedynafrom": "2023-05-10T09:00:00.000+02:00",
            "timedynato": "2023-05-10T13:00:00.000+02:00"


    "Timestamp": timestamp in UTC milliseconds. More info --> https://www.epochconverter.com/

        Example (2023-05-10T09:00 to 2023-05-10T13:00):
            "timedynafrom": "1683702000000",
            "timedynato": "1683716400000"

    timedynafrom --> if not set, the relative timeframe of two hours is used (now-2h).\n
    timedynato --> If not set, the current timestamp is used.

"""

app = FastAPI(
                docs_url="/docs",
                title="sgt-apm2123-alerts",
                description=description,version="1.0",
                openapi_url="/api/v1/openapi.json",
                contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"},
              )

DarwinComposer(app, config=composer_config, routers=routers)


