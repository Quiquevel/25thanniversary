"""
This module contains the routers application for the microservice.
"""
from src.handler.external_requests import alerting_openshift_dynatrace, alerting_dynatrace, alerting_openshift, alerting_test_cronjobs, alerting_authorization
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(alerting_openshift_dynatrace),
    RouteClass(alerting_dynatrace),    
    RouteClass(alerting_openshift),
    RouteClass(alerting_test_cronjobs),
    RouteClass(alerting_authorization)
]

