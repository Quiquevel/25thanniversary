"""
This module handles external requests for the microservice.
"""
from fastapi import APIRouter, Depends
from fastapi.security import HTTPBearer
from src.services.pods import podsStatusTreatment, podsrestartedTreatment, podsNotReadyTreatment
from src.services.dyna import dynatraceTreatment
from src.services.dynaOTHERsALL import dynatraceOTHERsTreatment, dynatraceOTHERsBatchbyMonth, dynatraceOTHERsBatchbyDay
from src.services.dynaTOPALL import dynatraceTOPALLTreatment
from src.services.dynaHeapdumps import dynatraceMemoryTreatment
from src.services.cronjobs import testDynaCronjobCoreByDayTreatment, testDynaCronjobCoreByMonthTreatment, testDynaCronjobTopTreatment, testDynaCronjobAlertsTreatment, testDynaCronjobAlerts715DaysTreatment, testDynaCronjobHistoricalrestartTreatment
from src.services.authorization import authorizationTreatment
from src.models.alerts_models import AlertingModel, DynaModel, DynaTOPModel, DynaOTHERsALLModel, DynaOTHERsALLMonthModel, DynaOTHERsALLDayModel, clusterhistoricalalertsModel, alertingAuthorization, DynaMemoryModel
from src.services.alerts import clusteralerts
from src.services.alertshistorical import clusterhistoricalalerts
import urllib3

urllib3.disable_warnings()

bearer = HTTPBearer()

#contant
API_ALERTING = "/api/v1/alerting/data"

alerting_openshift_dynatrace = APIRouter(tags=["Alerts ALL(DYNA y OPENSHIFT)"], prefix=API_ALERTING)
alerting_dynatrace = APIRouter(tags=["Alerts DYNATRACE"], prefix=API_ALERTING)
alerting_openshift = APIRouter(tags=["Alerts OPENSHIFT"], prefix=API_ALERTING)
alerting_test_cronjobs = APIRouter(tags=["Alerts DYNA&OCP TEST CRONJOBs"], prefix=API_ALERTING)
alerting_authorization = APIRouter(tags=["Alerts AUTHORIZATION"], prefix=API_ALERTING)

# Alerts ALL(DYNA y OPENSHIFT)
@alerting_openshift_dynatrace.post("/all", tags=["Alerts ALL(DYNA y OPENSHIFT)"], description = "GET ALERTING STATUS", response_description="JSON", status_code = 200)
async def get_alerting_status(target: AlertingModel):
    """
    Asynchronously retrieves Dynatrace alerts, pods with some restarts and pods with status phase not running or complete.

    Parameters:
    - target: The target AlertingModel object containing the functionalEnvironment y cluster to retrieve data for.

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await clusteralerts(functional_environment=target.functionalEnvironment, cluster=target.cluster)

# Alerts OPENSHIFT
@alerting_openshift.post("/restarts", tags = ["Alerts OPENSHIFT"], description = "GET RESTARTED PODS", response_description = "JSON", status_code = 200)
async def get_restarted_pods(target: AlertingModel):
    """
    Asynchronously retrieves the pods with some restarts (>1). 

    Parameters:
    - target: The target AlertingModel object containing the functionalEnvironment and cluster to retrieve data for.

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """    
    return await podsrestartedTreatment(functional_environment = target.functionalEnvironment, cluster = target.cluster)

@alerting_openshift.post("/failedPods", tags = ["Alerts OPENSHIFT"], description = "GET STATUS PODS", response_description = "JSON", status_code = 200)
async def get_status_pods(target: AlertingModel):
    """
    Asynchronously retrieves the pods with status phase not running or complete (with more than 1 day). 

    Parameters:
    - target: The target AlertingModel object containing the functionalEnvironment and cluster to retrieve data for.

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """ 
    return await podsStatusTreatment(functional_environment = target.functionalEnvironment, cluster = target.cluster)

@alerting_openshift.post("/notreadypods", tags = ["Alerts OPENSHIFT"], description = "GET NOT READY PODS", response_description = "JSON", status_code = 200)
async def get_notready_pods(target: AlertingModel):
    """
    Asynchronously retrieves the pods with phase Running but ready:False more than X minutes (default: 5). If the status is "waiting" the 'minutes' starting is not relevant. 

    Parameters:
    - target: The target AlertingModel object containing the functionalEnvironment and cluster to retrieve data for.

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """ 
    return await podsNotReadyTreatment(functional_environment = target.functionalEnvironment, cluster = target.cluster)

# Alerts DYNATRACE
@alerting_dynatrace.post("/dynatrace", tags = ["Alerts DYNATRACE"], description = "GET DYNATRACE ALERT", response_description = "JSON", status_code = 200)
async def get_dynatrace_alert(target: DynaModel):
    """
    Asynchronously retrieves Dynatrace PaaS alerts.    

    Parameters:
    - target: The target DynaModel object containing the functionalEnvironment and time to retrieve data for.

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await dynatraceTreatment(functional_environment = target.functionalEnvironment, timedyna = target.timedyna)

@alerting_dynatrace.post("/dynatraceTOP", tags = ["Alerts DYNATRACE"], description = "GET DYNATRACE ALERT TOP", response_description = "JSON", status_code = 200)
async def get_dynatrace_alert_TOP(target: DynaTOPModel):
    """
    Asynchronously retrieves TOP Dynatrace PaaS alerts.    

    Parameters:
    - target: The target DynaTOPModel object containing the start and end time to retrieve data for.

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await dynatraceTOPALLTreatment(timedynaS =target.timedynafrom, timedynaE = target.timedynato)

@alerting_dynatrace.post("/dynatraceCORE", tags = ["Alerts DYNATRACE"], description = "GET DYNATRACE ALERTs CORE", response_description = "JSON", status_code = 200)
async def get_dynatrace_alert_OTHERs(target: DynaOTHERsALLModel):
    """
    Asynchronously retrieves ALL Dynatrace alerts(PaaS or IaaS).    

    Parameters:
    - target: The target DynaOTHERsALLModel object containing the functionalEnvironment, start and end time to retrieve data for.

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await dynatraceOTHERsTreatment(functional_environment = target.functionalEnvironment, timedynaS = target.timedynafrom, timedynaE = target.timedynato)

@alerting_dynatrace.post("/dynatraceCOREbyMonth", tags = ["Alerts DYNATRACE"], description = "GET DYNATRACE ALERTs CORE BY MOUNTH TO MONGO", response_description = "JSON", status_code = 200)
async def get_dynatrace_alert_OTHERs_by_month(target: DynaOTHERsALLMonthModel):
    """
    Asynchronously retrieves ALL Dynatrace alerts(PaaS or IaaS) by month to Mongo.    

    Parameters:
    - target: The target DynaOTHERsALLMonthModel object containing the functionalEnvironment, month and year to retrieve data for.

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await dynatraceOTHERsBatchbyMonth(functional_environment = target.functionalEnvironment, months = target.months, year = target.year)

@alerting_dynatrace.post("/dynatraceCOREbyDay", tags = ["Alerts DYNATRACE"], description = "GET DYNATRACE ALERTs CORE BY DAY TO MONGO", response_description = "JSON", status_code = 200)
async def get_dynatrace_alert_OTHERs_by_day(target: DynaOTHERsALLDayModel):
    """
    Asynchronously retrieves ALL Dynatrace alerts(PaaS or IaaS) by day to Mongo.     

    Parameters:
    - target: The target DynaOTHERsALLDayModel object containing the functionalEnvironment and date to retrieve data for (If no date is set, the reference day will be yesterday).

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await dynatraceOTHERsBatchbyDay(functional_environment = target.functionalEnvironment, day = target.day, month = target.month, year = target.year)

@alerting_dynatrace.post("/clusterhistoricalalertsbymonth", tags = ["Alerts DYNATRACE"], description = "GET CLUSTER HISTORICAL DYNATRACE ALERTs BY MONTH", response_description = "JSON", status_code = 200)
async def get_cluster_historical_alerts_by_month(target: clusterhistoricalalertsModel):
    """
    Asynchronously retrieves cluster historical TOP Dynatrace alerts by month.     

    Parameters:
    - target: The target clusterhistoricalalertsModel object containing the functionalEnvironment and month to retrieve data for.

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """    
    return await clusterhistoricalalerts(functional_environment = target.functionalEnvironment, month = target.month, year = target.year)

@alerting_dynatrace.post("/dynatracealertsmemory", tags = ["Alerts DYNATRACE"], description = "GET DYNATRACE MEMORIA ALERTs IN OPEN STATE (ALL or by namespace/microservices)", response_description = "JSON", status_code = 200)
async def get_dynatrace_alert_memory(target: DynaMemoryModel):
    """
    Asynchronously retrieves Dynatrace PaaS Memory alerts (Long garbage-collection time and Memory resources exhausted).    

    Parameters:
    - target: The target DynaModel object containing the functionalEnvironment, time to retrieve data for and namespace or microservices (boths optionals).

    Returns:
    - The retrieved alerts data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await dynatraceMemoryTreatment(functional_environment = target.functionalEnvironment, timedyna = target.timedyna, namespace = target.namespace, microservice = target.microservice)

# Cronjobs TEST
@alerting_test_cronjobs.post("/testDynaCOREbyDaycronjob", tags = ["Alerts DYNA&OCP TEST CRONJOBs"], description = "TEST DYNATRACE CRONJOB ALERTs CORE BY DAY TO MONGO", response_description = "JSON", status_code = 200)
async def test_cronjob_core_dynatrace():    
    """
    Asynchronously test cronjob to retrieves ALL Dynatrace alerts(PaaS or IaaS) by day to Mongo.     

    Parameters:
    - target: N/A


    Returns:
    - The retrieved alerts data in mongo.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await testDynaCronjobCoreByDayTreatment()

@alerting_test_cronjobs.post("/testDynaCOREbyMonthcronjob", tags = ["Alerts DYNA&OCP TEST CRONJOBs"], description = "TEST DYNATRACE CRONJOB ALERTs CORE BY MONTH TO MONGO", response_description = "JSON", status_code = 200)
async def test_cronjob_core_dynatrace():    
    """
    Asynchronously test cronjob to retrieves ALL Dynatrace alerts(PaaS or IaaS) by month to Mongo.     

    Parameters:
    - target: N/A

    Returns:
    - The retrieved alerts data in mongo.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await testDynaCronjobCoreByMonthTreatment()

@alerting_test_cronjobs.post("/testDynaTOPbyMonthcronjob", tags = ["Alerts DYNA&OCP TEST CRONJOBs"], description = "TEST DYNATRACE CRONJOB ALERTs TOP BY MONTH TO MONGO", response_description = "JSON", status_code = 200)
async def test_cronjob_top_dynatrace():
    """
     Asynchronously test cronjob to retrieves TOP Dynatrace PaaS alerts to Mongo.     

    Parameters:    
    - target: N/A
    
    Returns:
    - The retrieved alerts data in mongo.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await testDynaCronjobTopTreatment()

@alerting_test_cronjobs.post("/testDynaAlertscronjob", tags = ["Alerts DYNA&OCP TEST CRONJOBs"], description = "TEST DYNATRACE CRONJOB ALERTs(DYNA&OPENSHIFT PODs events) TO MONGO", response_description = "JSON", status_code = 200)
async def test_cronjob_alerts():
    """
     Asynchronously test cronjob to retrieves Dynatrace PaaS and pods with some restarts and pods with status phase not running or complete to Mongo.     

    Parameters:    
    - target: N/A
    
    Returns:
    - The retrieved alerts data in mongo.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await testDynaCronjobAlertsTreatment()

@alerting_test_cronjobs.post("/testDynaCronjobAlerts715DaysTreatment", tags = ["Alerts DYNA&OCP TEST CRONJOBs"], description = "TEST DYNATRACE CRONJOB ALERTs 7&15 DAYS TO MONGO", response_description = "JSON", status_code = 200)
async def test_cronjob_715days_dynatrace():
    """
     Asynchronously test cronjob to retrieves Dynatrace PaaS Dynatrace PaaS 7&15 days alerts to Mongo.   

    Parameters:    
    - target: N/A
    
    Returns:
    - The retrieved alerts data in mongo.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await testDynaCronjobAlerts715DaysTreatment()

@alerting_test_cronjobs.post("/testDynaHistoricalrestartcronjob", tags = ["Alerts DYNA&OCP TEST CRONJOBs"], description = "TEST DYNATRACE CRONJOB ALERTs(OPENSHIFT PODs events) TO MONGO", response_description = "JSON", status_code = 200)
async def test_cronjob_alerts():
    """
     Asynchronously test cronjob to retrieves Openshift eventswith some restarts and pods with status phase not running or complete to Mongo.     

    Parameters:    
    - target: N/A
    
    Returns:
    - The retrieved alerts data in mongo.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await testDynaCronjobHistoricalrestartTreatment()



# Alerts AUTHORIZATION
@alerting_authorization.post("/authorizationuser", tags=["Alerts AUTHORIZATION"], description="VALIDATE USER UID - AUTHORIZATION", response_description="JSON", status_code=200)
async def get_alerting_authorization(target: alertingAuthorization, Authorization: str = Depends(bearer)):
    """
    Asynchronously retrieves authorization for user.     

    Parameters:
    - target: The target alertingAuthorization object containing the ldap user to retrieve data for.

    Returns:
    - The retrieved authorization token.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """   
    return await authorizationTreatment(auth=Authorization, ldap=target.ldap)

