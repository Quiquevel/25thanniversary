
from fastapi import HTTPException
from pydantic import BaseModel, validator
from src.services.clientunique import getEnvironmentsClustersList

environmentList, clusterList = getEnvironmentsClustersList()

class AlertingModel(BaseModel):
    functionalEnvironment: str
    cluster: str = None
    #to activate the region parameter -> region: str = None

    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):        
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
class DynaModel(BaseModel):
    functionalEnvironment: str
    timedyna: str = None
 
    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v
class DynaTOPModel(BaseModel):    
    timedynafrom: str = None
    timedynato: str = None
    
class clusterhistoricalalertsModel(BaseModel):    
    functionalEnvironment: str
    month: str
    year: str = None

    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v        
class DynaOTHERsALLModel(BaseModel):    
    functionalEnvironment: str
    timedynafrom: str = None
    timedynato: str = None

    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

class DynaOTHERsALLMonthModel(BaseModel):    
    functionalEnvironment: str
    months: str
    year: str = None

    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

class DynaOTHERsALLDayModel(BaseModel):    
    functionalEnvironment: str    
    day: str = None
    month: str = None
    year: str = None
    
    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

class DynaMemoryModel(BaseModel):
    functionalEnvironment: str
    timedyna: str = None
    namespace: str = None
    microservice: str = None
 
    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

class alertingAuthorization(BaseModel):
    ldap: str