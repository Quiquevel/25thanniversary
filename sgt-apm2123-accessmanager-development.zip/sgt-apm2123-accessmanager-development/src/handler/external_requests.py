"""
This module handles external requests for the microservice, including user onboarding, access control, maintenance, and auditing operations.

Routers:
    onboarding: Handles user onboarding-related endpoints.
    access_control: Manages access control and role-based access control (RBAC).
    maintenance: Provides endpoints for administrative maintenance operations.
    audit: Handles auditing-related endpoints.

Functions:
    onboarding_user():
        Endpoint for onboarding a user.

    get_user_roles():
        Retrieves a list of authorized users.

    get_authorized_users_access():
        Retrieves authorized users along with their effective access.

    get_user_menu(user_id: str):
        Retrieves the personalized menu for a specific user.

    get_authorized_user_details(user_id: str):
        Retrieves details of a specific authorized user.

    view_user_roles():
        Endpoint to view user roles.

    user_roles():
        Endpoint to assign roles to a user.

    user_maintenance():
        Endpoint for user maintenance operations (e.g., suspend, delete, deactivate, activate).

    get_audit_logs():
        Endpoint to retrieve audit logs.

    get_authorized_user():
        Retrieves user/role privileges.

    get_app_map():
        Retrieves the application map (menu structure).
"""

from fastapi import APIRouter, Query
from fastapi.security import HTTPBearer
from src.models.access_models import onboardingModel, accessModel, maintenanceModel, auditModel
from fastapi import HTTPException
from src.services.access_control import authorized_user, user_level, enrich_menu_with_access_full, strip_minrole, is_member_of, load_menu_from_env

bearer = HTTPBearer()

API_ACCESS_MANAGER = "/api/v1/security/access"

onboarding = APIRouter(tags=["User Onboarding"], prefix=API_ACCESS_MANAGER)
access_control = APIRouter(tags=["Access Control (RBAC)"], prefix=API_ACCESS_MANAGER)
maintenance = APIRouter(tags=["Maintenance / Admin Ops"], prefix=API_ACCESS_MANAGER)
audit = APIRouter(tags=["Audit"], prefix=API_ACCESS_MANAGER)

@onboarding.post("/onboarding/users", description="Onboarding User", response_description="JSON with responses")
async def onboarding_user():
    """
    Endpoint for onboarding a user.

    Returns:
        str: A placeholder response indicating success.
    """
    return "ok"

@access_control.get("/users/authorized/{user_id}", summary="Get details of a specific authorized user", description="Returns the user object `{id, name, email, status, roles}` for the specified `user_id`", response_description="Authorized user details returned")
async def get_authorized_user_details(user_id: str):
    """
    Retrieves details of a specific authorized user.

    Args:
        user_id (str): The ID of the user.

    Returns:
        Dict[str, Any]: The user details.

    Raises:
        HTTPException: If the user is not found or not authorized.
    """
    users = await authorized_user()
    user = next((u for u in users if u.get("id") == user_id), None)
    if not user:
        raise HTTPException(status_code=204, detail="User not found or not authorized")
    return user

@access_control.get("/users/{user_id}/menu", summary="Get the personalized menu for a user", description="Returns the menu filtered and enriched for the given user, including a `rol` field on each item/submodule indicating the user's effective authorization. Items with no access are omitted.", response_description="JSON with authorization responses")
async def get_user_menu_full(
    user_id: str,
    group: str | None = Query(None, description="Optional group filter")
):
    # Carga AUTH_MENU directamente desde env
    try:
        menu = await load_menu_from_env()
    except Exception as e:
        # Config incorrecta → 500 explícito
        raise HTTPException(status_code=500, detail=str(e))

    # Usuario autorizado (y, si se indica, miembro del grupo)
    users = await authorized_user(required_group=group)
    user = next((u for u in users if u.get("id") == user_id), None)
    if not user:
        raise HTTPException(status_code=204, detail="User not found or not authorized")

    lvl = await user_level(user.get("roles", []))
    enriched_full = await enrich_menu_with_access_full(menu, lvl)
    sanitized = await strip_minrole(enriched_full)
    return sanitized

@access_control.get("/users/{user_id}/is-member")
async def is_user_member(user_id: str, group: str = Query(..., description="Group to check")):
    """
    Returns whether the given authorized user belongs to the given group.
    """
    users = await authorized_user()  # primero validamos que sea 'authorized'
    user = next((u for u in users if u.get("id") == user_id), None)
    if not user:
        raise HTTPException(status_code=204, detail="User not found or not authorized")
    return {"user_id": user_id, "group": group, "is_member": await is_member_of(user, group)}

@access_control.get("/users/authorized", summary="List authorized users", description="Returns all users whose `status` is `authorized`. Each item includes `id`, `name`, `email`, `status`, and `roles`", response_description="Authorized users retrieved")
async def get_user_roles(group: str | None = Query(None, description="Optional group filter")):
    """
    Retrieves a list of authorized users.

    Returns:
        List[Dict[str, Any]]: A list of authorized users.
    """
    return await authorized_user(required_group=group)

@access_control.post("/roles", description="View user roles", response_description="JSON with responses")
async def view_user_roles():
    """
    Endpoint to view user roles.

    Returns:
        str: A placeholder response indicating success.
    """
    return "ok"

@access_control.post("/roles/user", description="Assignments user rol", response_description="JSON with responses")
async def user_roles():
    """
    Endpoint to assign roles to a user.

    Returns:
        str: A placeholder response indicating success.
    """
    return "ok"

@maintenance.post("/user/maintenance", description="Maintenance", response_description="JSON with responses")
async def user_maintenance():
    # -> suspend, delete, desactivate, activate
    """
    Endpoint for user maintenance operations (e.g., suspend, delete, deactivate, activate).

    Returns:
        str: A placeholder response indicating success.
    """
    return "ok"

@audit.post("/audit/logs", description="Audit user logs", response_description="JSON with responses")
async def get_audit_logs():
    """
    Endpoint to retrieve audit logs.

    Returns:
        str: A placeholder response indicating success.
    """
    return "ok"

@audit.post("/user/authorized", description="Get user/rol Privileges", response_description="JSON with responses")
async def get_authorized_user():
    """
    Retrieves user/role privileges.

    Returns:
        List[Dict[str, Any]]: A list of authorized users.
    """
    return await authorized_user()

@audit.get("/app-map", description="Get app-map", response_description="JSON with app-map")
async def get_app_map():
    """
    Asynchronously retrieves the application menu map.

    This function attempts to load the application menu map from the environment
    using the `load_menu_from_env` function. If an error occurs during the process,
    it raises an HTTPException with a status code of 500 and includes the error details.

    Returns:
        dict: The application menu map loaded from the environment.

    Raises:
        HTTPException: If an error occurs while loading the menu map, an HTTPException
        with a status code of 500 is raised, containing the error details.
    """
    try:
        menu = await load_menu_from_env()
        return menu
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))