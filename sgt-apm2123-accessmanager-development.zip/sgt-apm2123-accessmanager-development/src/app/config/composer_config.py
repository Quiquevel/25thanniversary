from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "sgt-apm2123-accessmanager",
          "description": "Microservice that centralizes user onboarding and permissions management, streamlining access control across systems and reducing operational overhead",
          "contact": {
               "name": "Pedro Alamilla",
               "url": "https://github.com/santander-group-sds-gln/sgt-apm2123-accessmanager"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
