"""
This module contains the main FastAPI application for the microservice.
"""
from src.app.config.composer_config import config
from fastapi import FastAPI
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers


app = FastAPI(
        docs_url="/docs",
        title="sgt-apm2123-accessmanager",
        openapi_url="/api/v1/openapi.json",
        contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"},
)

DarwinComposer(app, config=config, routers=routers)
