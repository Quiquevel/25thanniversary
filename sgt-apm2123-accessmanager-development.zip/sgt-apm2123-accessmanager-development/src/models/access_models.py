from pydantic import BaseModel
from typing import Optional

class onboardingModel(BaseModel):
    uid: str
    user_group: str

class accessModel(BaseModel):
    uid: str

class maintenanceModel(BaseModel):
    uid: str
    namespace: Optional[str] = None

class auditModel(BaseModel):
    uid: Optional[str] = None