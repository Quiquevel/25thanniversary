"""
This module contains the routers application for the microservice.
"""
from src.handler.external_requests import onboarding,access_control,maintenance,audit
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(onboarding),
    RouteClass(access_control),
    RouteClass(maintenance),
    RouteClass(audit),
]