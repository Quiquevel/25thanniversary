"""
This module provides utilities for managing user authentication mappings, menu enrichment, and role-based access control (RBAC).

Functions:
    load_auth_mappings() -> List[Dict[str, Any]]:
        Loads user authentication mappings from the environment variable `AUTH_USER`.

    is_member_of(user: Dict[str, Any], group: str) -> bool:
        Checks if a user belongs to a specific group.

    authorized_user(required_group: Optional[str] = None) -> List[Dict[str, Any]]:
        Retrieves a list of authorized users, optionally filtered by group membership.

    load_menu_from_env() -> Dict[str, Any]:
        Loads the menu structure from the environment variable `AUTH_MENU`.

    user_level(roles: List[str]) -> int:
        Calculates the maximum user level based on their roles.

    enrich_menu_with_access_full(menu: Dict[str, Any], level: int) -> Dict[str, Any]:
        Enriches the menu structure with access levels based on user roles.

    strip_minrole(obj):
        Recursively removes all `minRole` keys from dictionaries and lists.

Constants:
    ALLOWED_ROLES_USER: Set[str]:
        Valid user roles.

    ALLOWED_MINROLES: Set[str]:
        Valid minimum roles for menu nodes.

    ROLE_POWER: Dict[str, int]:
        Mapping of user roles to their power levels.

    POWER: Dict[str, int]:
        Mapping of minimum roles to their required power levels.
"""

import os
import json
#import logging
from typing import Any, Dict, List, Optional
from shuttlelib.utils.logger import logger
#logger = logging.getLogger(__name__)

# ================== Users (AUTH_USER) ==================
async def load_auth_mappings() -> List[Dict[str, Any]]:
    """
    Loads user authentication mappings from the environment variable `AUTH_USER`.

    Returns:
        List[Dict[str, Any]]: A list of user authentication mappings.

    Raises:
        json.JSONDecodeError: If the `AUTH_USER` environment variable contains invalid JSON.
    """
    raw = os.getenv("AUTH_USER")
    if not raw:
        return []
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        logger.debug("Invalid AUTH_USER JSON")
        raise

async def is_member_of(user: Dict[str, Any], group: str) -> bool:
    """
    Checks if a user belongs to a specific group.

    Args:
        user (Dict[str, Any]): The user object.
        group (str): The group to check membership for.

    Returns:
        bool: True if the user belongs to the group, False otherwise.
    """
    groups = user.get("groups") or []
    return isinstance(groups, list) and group in groups

async def authorized_user(required_group: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Retrieves a list of authorized users, optionally filtered by group membership.

    Args:
        required_group (Optional[str]): The group to filter users by. Defaults to None.

    Returns:
        List[Dict[str, Any]]: A list of authorized users.
    """
    all_users = await load_auth_mappings()
    authorized = [u for u in all_users if u.get("status") == "authorized"]
    if required_group:
        authorized = [u for u in authorized if await is_member_of(u, required_group)]
    return authorized

# ================== Menu (AUTH_MENU) ==================
async def load_menu_from_env() -> Dict[str, Any]:
    """
    Loads the menu structure from the environment variable `AUTH_MENU`.

    Returns:
        Dict[str, Any]: The menu structure.

    Raises:
        RuntimeError: If the `AUTH_MENU` environment variable is not set.
        json.JSONDecodeError: If the `AUTH_MENU` environment variable contains invalid JSON.
        ValueError: If the menu structure is invalid.
    """
    raw = os.getenv("AUTH_MENU")
    if not raw:
        raise RuntimeError("AUTH_MENU env var is not set")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        logger.debug("Invalid AUTH_MENU JSON")
        raise
    if "menu" not in data or not isinstance(data["menu"], list):
        raise ValueError("AUTH_MENU must contain a top-level 'menu' list")
    return data

# ================== RBAC (nombres exactos, sin alias) ==================
ALLOWED_ROLES_USER = {"view", "privileged read", "devops", "admin"}
ALLOWED_MINROLES   = {"none", "view", "privileged read", "devops", "admin"}

ROLE_POWER = {
    "view": 1,
    "privileged read": 2,
    "devops": 3,
    "admin": 4,
}
POWER = {
    "none": 0,
    "view": 1,
    "privileged read": 2,
    "devops": 3,
    "admin": 4,
}

async def user_level(roles: List[str]) -> int:
    """
    Calculates the maximum user level based on their roles.

    Args:
        roles (List[str]): A list of user roles.

    Returns:
        int: The maximum user level.

    Logs:
        Logs an error for unknown roles.
    """
    levels: List[int] = []
    for r in roles:
        if r not in ALLOWED_ROLES_USER:
            logger.error("Unknown user role '%s'. Allowed: %s", r, sorted(ALLOWED_ROLES_USER))
            continue
        levels.append(ROLE_POWER[r])
    return max(levels or [0])

# ================== Enrich Menu ==================
async def enrich_menu_with_access_full(menu: Dict[str, Any], level: int) -> Dict[str, Any]:
    """
    Enriches the menu structure with access levels based on user roles.

    Args:
        menu (Dict[str, Any]): The menu structure.
        level (int): The user's access level.

    Returns:
        Dict[str, Any]: The enriched menu structure.

    Raises:
        ValueError: If a menu node contains an invalid `minRole`.
    """
    def max_role(r1: str, r2: str) -> str:
        return r1 if POWER[r1] >= POWER[r2] else r2

    def required_key_from_node(node: Dict[str, Any], parent_req: Optional[str]) -> str:
        raw = node.get("minRole", parent_req or "view")
        if raw not in ALLOWED_MINROLES:
            raise ValueError(
                f"Invalid minRole '{raw}' in menu node '{node.get('title')}'. "
                f"Allowed: {sorted(ALLOWED_MINROLES)}"
            )
        return raw

    def role_for_node(node: Dict[str, Any], parent_req: Optional[str]) -> str:
        req_key = required_key_from_node(node, parent_req)
        return req_key if level >= POWER[req_key] else "none"

    def walk(n: Dict[str, Any], inherited_req: Optional[str] = None) -> Dict[str, Any]:
        node_req = required_key_from_node(n, inherited_req)
        route = n.get("route")
        items = n.get("items")
        subs = n.get("submodules")

        # Node's own role (if it has a route)
        rol_self = role_for_node(n, inherited_req) if route else "none"

        agg = rol_self

        # Submodules (always keep)
        if subs:
            new_subs = []
            for s in subs:
                sub_req = required_key_from_node(s, node_req)
                sub_role = sub_req if level >= POWER[sub_req] else "none"
                new_subs.append({**s, "rol": sub_role})
                agg = max_role(agg, sub_role)
            n = {**n, "rol": agg, "submodules": new_subs}
        else:
            n = {**n, "rol": agg}

        # Items (always keep)
        if items:
            new_items = [walk(it, node_req) for it in items]
            for it2 in new_items:
                agg = max_role(agg, it2.get("rol", "none"))
            n["rol"] = agg
            n["items"] = new_items

        # Leaf
        if not items and not subs and route:
            n["rol"] = rol_self

        return n

    return {"menu": [walk(x) for x in menu.get("menu", [])]}

# ================== Strip minRole ==================
async def strip_minrole(obj):
    """
    Recursively removes all `minRole` keys from dictionaries and lists.

    Args:
        obj: The object to process.

    Returns:
        The object with `minRole` keys removed.
    """
    if isinstance(obj, dict):
        return {k: await strip_minrole(v) for k, v in obj.items() if k != "minRole"}
    if isinstance(obj, list):
        return [await strip_minrole(x) for x in obj]
    return obj
