"""
This module provides middleware functions for user authorization in a FastAPI application.
It includes functions to verify user tokens and check user membership in various ALM teams.
Functions:
    is_authorized_user(token: HTTPBearer, uid: str, almteam: str) -> bool:
        Checks if a user is authorized based on their token and ALM team membership.
    is_devops(token: str, uid: str) -> bool:
        Checks if a user is part of the DevOps team based on their token and ALM team membership.
    is_devops_knowledge(token: HTTPBearer, uid: str) -> bool:
        Checks if a user has DevOps knowledge based on their token and ALM team membership.
    is_sre_coe_devsecops(token: str, uid: str) -> bool:
        Checks if a user is part of the SRE CoE DevSecOps team based on their token and ALM team membership.
    is_devops_manager_capacity(token: str, uid: str) -> bool:
        Checks if a user is a DevOps manager based on their token and ALM team membership.
    is_cambios_estructurales_searchpattern(token: str, uid: str) -> bool:
        Checks if a user is part of the Cambios Estructurales team based on their token and ALM team membership.
    verify_token(token: str, uid: str) -> bool:
        Verifies the given token by making a request to an external service.
    get_alm_teams(groupname: str, uid: str) -> bool:
        Retrieves the ALM teams for a user and checks if they belong to a specified group.
    is_user_in_almteam(groupname: str, uid: str) -> bool:
        Checks if a user is in a specified ALM team.
"""

import aiohttp
from fastapi import HTTPException
from fastapi.security import HTTPBearer
from shuttlelib.utils.logger import logger


async def is_authorized_user(token: HTTPBearer, uid: str, almteam: str) -> bool:
    """
    Check if the user is authorized based on the provided token, user ID, and ALM team.
    Args:
        token (HTTPBearer): The authentication token to be validated.
        uid (str): The user ID to be checked.
        almteam (str): The ALM team name to verify the user's membership.
    Returns:
        bool: True if the user is authorized, False otherwise.
    """

    # Validate if given token
    if await verify_token(token=token, uid=uid):
        return await is_user_in_almteam(groupname=almteam, uid=uid)

    #uid == "x021096"
    return uid


async def verify_token(token, uid):
    """
    Verify the provided token by making a request to the user details service.
    Args:
        token (str): The token to be verified.
        uid (str): The user ID to be matched against the token.
    Returns:
        dict: The response from the user details service if the token is valid and the uid matches.
        bool: False if the token is invalid or the uid does not match.
    Raises:
        HTTPException: If the uid does not match the one in the response.
    """

    url = "https://srvnuarintra.santander.corp.bsch/uds/v1/users/self"
    header = {"Authorization": f"Bearer {token}"}

    logger.debug("Verifying token")
    logger.debug(f"url: {url}")
    async with aiohttp.ClientSession() as session:
        async with session.get(
            url, headers=header, verify_ssl=True, timeout=aiohttp.ClientTimeout(total=5, connect=3)
        ) as r:
            logger.debug(f"Response status: {r.status}")
            if r.status != 200:
                return False

            response = await r.json()
            if "uid" not in response:
                return False

            if uid != response["uid"]:
                raise HTTPException(status_code=422, detail="ldap value doesn't match with the given token")

            return response


async def is_user_in_almteam(groupname, uid):
    """
    Check if a user is part of a specific ALM team.
    This function sends an asynchronous HTTP GET request to the ALM API to
    retrieve the teams associated with a given user ID. It then checks if the
    specified group name is present in the user's teams.
    Args:
        groupname (str): The name of the group to check for.
        uid (str): The user ID to check the teams for.
    Returns:
        bool: True if the user is part of the specified group, False otherwise.
    Raises:
        aiohttp.ClientError: If there is an issue with the HTTP request.
        asyncio.TimeoutError: If the request times out.
    """

    url = f"https://api-onboarding.alm.europe.cloudcenter.corp/almmc/users/{uid}/teams"

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, verify_ssl=True, timeout=aiohttp.ClientTimeout(total=10, connect=5)) as r:
                if r.status == 200:
                    response = await r.json()
                    return any(groupname == team for role in response["almteams"].values() for team in role)
                else:
                    return False
    except Exception as e:
        logger.error(f"Error checking in ALM team: {e}")
        return False
