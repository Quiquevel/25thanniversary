import setuptools
from version import __version__

setuptools.setup(
    name = "sgt-apm2123-knowledge",
    version = __version__,
    author = "Pedro Alamilla",
    author_email = "pedro.alamilla@gruposantander.com",
    description = "sgt-apm2123-knowledge",
    long_description = "Main core of SHUTTLE data, from where all the technical and functional relationship logic between the different elements is applied to generate specific Dashboards based on those relationships",
    long_description_content_type = "text/markdown",
    url = "sgt-apm2123-knowledge",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
    ],
    python_requires = '>=3.13.0',
)
