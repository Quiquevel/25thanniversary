from pydantic import BaseModel

class ReadModel(BaseModel):
    """
    Represents a read model.

    Attributes:
        namespace (str): The namespace of the read model.
    """
    namespace: str
class ReadModeldevops(BaseModel):
    """
    Represents a model for reading devops data.

    Attributes:
        uiddevops (str): The unique identifier for devops.
    """
    uiddevops: str
class ReadModeldomain(BaseModel):
    """
    ReadModeldomain class represents a base model for reading a domain.

    Attributes:
        domain (str): The domain to be read.
    """
    domain: str
class ReadModelupdate(BaseModel):
    """
    Represents a model for updating the read model.

    Attributes:
        updatemongoinfo (dict): The update information for MongoDB.
        ldap (str): The LDAP information.
    """
    updatemongoinfo: dict
    ldap: str
class ReadModeluid(BaseModel):
    """
    Represents a model for reading a specific uid.

    Attributes:
        uid (str): The unique identifier for the model.
    """
    uid: str
class ReadModelinsert(BaseModel):
    """
    Represents a model for inserting data into the read model.

    Attributes:
        insertinfo (dict): A dictionary containing the information to be inserted.
        ldap (str): The LDAP (Lightweight Directory Access Protocol) associated with the data.
    """
    insertinfo: dict
    insertinfo : dict
    ldap: str
class ReadNamespaceCluster(BaseModel):
    """
    Represents a request to read a namespace cluster.

    Attributes:
        namespace (str): The namespace to read.
    """
    namespace : str

class UpdateUid(BaseModel):
    """
    Represents a request to update a user's UID.

    Attributes:
        uid (str): The current UID of the user.
        newuid (str): The new UID to be assigned to the user.
        ldap (str): The LDAP server to be used for the update.

    """
    uid: str
    newuid: str
    ldap: str

class Updatedomain(BaseModel):
    """
    Represents the updated domain information.

    Attributes:
        domain (str): The current domain.
        newdomain (str): The new domain.
        ldap (str): The LDAP information.
    """
    domain: str
    newdomain: str
    ldap: str
class Findservicegroup(BaseModel):
    """
    Represents a request to find a service group.

    Attributes:
        servicegroup (str): The name of the service group to find.
    """
    servicegroup: str

class Authorizationuser(BaseModel):
    """
    Represents an authorization user.

    Attributes:
        ldap (str): The LDAP of the user.
    """
    ldap: str = None

class Changevaluemodel(BaseModel):
    """
    Represents a model for changing values.

    Attributes:
        uid (str): The unique identifier.
        domainlist (list): The list of domains.
        ldap (str): The LDAP string.
    """
    uid: str
    domainlist: list
    ldap: str

class Findtower(BaseModel):
    """
    Represents a request to find a tower.

    Attributes:
        tower (str): The tower to find.
    """
    tower: str

class SwitchUid(BaseModel):
    """
    SwitchUid is a data model that represents a structure for handling user identification switches.
    Attributes:
        uid1 (str): The first user identifier.
        uid2 (str): The second user identifier.
        ldap (str): The LDAP (Lightweight Directory Access Protocol) identifier associated with the user.
    """
    uid1: str
    uid2: str
    ldap: str

class SwitchRoleResponsible(BaseModel):
    """
    SwitchRoleResponsible is a data model that represents the information required
    to switch roles between two users.
    Attributes:
        uid1 (str): The unique identifier of the first user.
        uid2 (str): The unique identifier of the second user.
        role (str): The role to be switched or assigned.
        ldap (str): The LDAP (Lightweight Directory Access Protocol) information 
            associated with the users.
    """

    uid_current: str
    new_uid: str
    role: str
    ldap: str

class RoleAppList(BaseModel):
    """
    RoleAppList is a data model representing a list of roles associated with an application.
    Attributes:
        role (str): The name of the role associated with the application.
    """
    role: str
