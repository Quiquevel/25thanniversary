import aiohttp, requests, os, json, re
from shuttlelib.utils.logger import logger
from shuttlelib.db.mongo import MongoClient
from shuttlelib.openshift.client import OpenshiftClient
from fastapi import responses, status, HTTPException
from fastapi.encoders import jsonable_encoder
from fastapi import HTTPException
from datetime import datetime
from shuttlelib.middleware.authorization import is_authorized_user
from shuttlelib.middleware.emailnotification import send_mail
import base64
from src.services.external_endpoint import getaksnamespace

mg = MongoClient()

entity_id=(os.getenv("ENTITY_ID")).lower()
client = OpenshiftClient(entity_id=entity_id)

#contant
PROJECT_NOT_FOUND = "Project not found"
USER_NOT_AUTHORIZED = "User not authorized"
SUCCESS_MESSAGE = "Project updated successfully"
TOKEN_NOT_EXIST = "Token not exist"
CONTENT_TYPE = "application/json"
SUCCESS_BATCH = "Batch completed"
STATUS_BATCH = "Batch starting"
STATUS_EMPTY = "Error: The value of key 'name' is null or empty"
DATE_FORMAT = "%Y-%m-%d-%H:%M"
AUTHORIZED_USER = "Authorized User"

async def readnamespacedata(namespace):
    """
    Retrieves data from a MongoDB collection based on the provided namespace.

    Args:
        namespace (str): The namespace to search for in the MongoDB collection.

    Returns:
        list: A list of namespace data retrieved from the MongoDB collection.

    Raises:
        JSONResponse: If no data is found for the provided namespace, a JSONResponse with status code 204 and a detail message will be returned.
    """
    #get namespace data
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    list_namespace_db = []
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    match namespace:
        case _:
            list_namespace = set(namespace.split(','))
            for namespacetmp_data in list_namespace:
                namespacetmp = (namespacetmp_data).lower()
                querydbresult = mg.find({f"{functional_environment}.namespace": {"$regex": f".*{namespacetmp}.*"}})
                findnamespace = [x[functional_environment] for x in querydbresult]
                if len(findnamespace) != 0:
                    list_namespace_db.extend(findnamespace)

            if len(list_namespace_db) != 0:
                return list_namespace_db
            else:
                return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": PROJECT_NOT_FOUND}))

async def snowgroup(namespace):
    """
    Retrieves the 'SNOW' field values for a given namespace or list of namespaces.

    Args:
        namespace (str): A comma-separated string of namespaces.

    Returns:
        list: A list of dictionaries containing the namespace and the corresponding 'SNOW' field values or an empty list.
    """
    # Get namespace data
    functional_environment = os.getenv("ENVIRONMENT")  # Set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    # Map original namespaces to processed namespaces
    namespace_map = {ns.replace('-pro', '').replace('-dmz', ''): ns for ns in namespace.split(',')}

    results = []

    for processed_namespace, original_namespace in namespace_map.items():
        namespacetmp = processed_namespace.lower()
        querydbresult = mg.find({f"{functional_environment}.namespace": {"$regex": f".*{namespacetmp}.*"}})
        findnamespace = [x[functional_environment] for x in querydbresult]
        if findnamespace:
            # Extract the 'SNOW' field value
            snow_values = [x.get("SNOW") for x in findnamespace if "SNOW" in x]
            results.append({
                "namespace": original_namespace,  # Use the original namespace with the suffix
                "snow_group": snow_values if snow_values else []
            })
        else:
            results.append({
                "namespace": original_namespace,  # Use the original namespace with the suffix
                "snow_group": []
            })

    return results

async def get_all_namespaces_with_snow():
    """
    Retrieves all namespaces with their respective 'SNOW' field values directly from the database.

    Returns:
        list: A list of dictionaries containing the namespace and its corresponding 'SNOW' field value.
    """
    # Set the environment where the information will be extracted
    functional_environment = os.getenv("ENVIRONMENT")
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    # Query the database with projection to fetch only the required fields
    query_filter = {f"{functional_environment}.namespace": {"$exists": True}}
    projection = {
        f"{functional_environment}.namespace": 1,
        f"{functional_environment}.SNOW": 1,
        "_id": 0  # Exclude the MongoDB document ID
    }

    # Perform the query
    query_result = mg._collection.find(query_filter, projection)

    # Format the results
    namespaces_with_snow = [
        {
            "namespace": doc[functional_environment].get("namespace"),
            "SNOW": doc[functional_environment].get("SNOW")
        }
        for doc in query_result
    ]

    return namespaces_with_snow

async def get_namespaces_by_snow(snow_value):
    """
    Retrieves a list of all namespaces related to a given SNOW value.

    Args:
        snow_value (str): The SNOW value to search for.

    Returns:
        list: A list of namespaces related to the given SNOW value.
    """
    # Set the environment where the information will be extracted
    functional_environment = os.getenv("ENVIRONMENT")
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    # Query the database for documents with the given SNOW value
    query_filter = {f"{functional_environment}.SNOW": snow_value}
    projection = {f"{functional_environment}.namespace": 1, "_id": 0}  # Only fetch the namespace field

    # Perform the query
    query_result = mg._collection.find(query_filter, projection)

    # Extract the namespaces from the query result
    namespaces = [doc[functional_environment].get("namespace") for doc in query_result if functional_environment in doc]

    return namespaces

async def readdevopsdata(uiddevops):
    """
    Retrieves devops data from the database based on the provided UID.

    Parameters:
    - uiddevops (str): The UID of the devops data to retrieve.

    Returns:
    - list: A list of devops data matching the provided UID.

    Raises:
    - JSONResponse: If the devops data is not found, a JSON response with status code 204 and a detail message will be returned.
    """
    #get devops data
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    match uiddevops:
        case _:
            querydbresult = mg.find({f"{functional_environment}.devops.uid": uiddevops})
            if querydbresult is None:
                return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Devops not found"}))
            else:
                finddevops = [x[functional_environment] for x in querydbresult]
                if len(finddevops) != 0:
                    return finddevops
                else:
                    return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Devops not found"}))

async def readdomaindata(domain):
    """
    Retrieves domain data from a MongoDB collection based on the provided domain.

    Args:
        domain (str): The domain to search for in the MongoDB collection.

    Returns:
        list or JSONResponse: The domain data if found, or a JSONResponse with a "Domain not found" detail if not found.
    """

    #get domain data
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    match domain:
        case _:
            querydbresult = mg.find({f"{functional_environment}.domain": domain})
            if querydbresult is None:
                return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Domain not found"}))
            else:
                finddomain = [x[functional_environment] for x in querydbresult]
                if len(finddomain) != 0:
                    return finddomain
                else:
                    return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Domain not found"}))

async def readdomainlist():
    """
    Retrieves the domain list from the MongoDB collection based on the specified environment.

    Returns:
        list: A list of unique domain names extracted from the MongoDB collection.

    Raises:
        JSONResponse: If the domain list is not found, returns a JSON response with status code 204 (No Content).
    """
    
    #functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    #get domain list
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    #get tower lead list
    filtered_towert_lead = mg._collection.distinct(f"{functional_environment}.domain")
    resultdomainlist = list(set([total for total in filtered_towert_lead if total != None]))
    
    if len(resultdomainlist) != 0:
        return resultdomainlist
    else:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Domain list not found"}))

async def readdevopslist():
    """
    Reads the devops list from MongoDB and returns a list of unique devops entries.

    Returns:
        list: A list of dictionaries containing the unique devops entries.
        
    Raises:
        JSONResponse: If the devops list is not found, returns a JSON response with status code 204 (No Content).
    """
    #get devops list
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    #get tower lead list
    filtered_towert_lead = mg._collection.distinct(f"{functional_environment}.devops")
    view = set()
    new_list = []

    for dicc in filtered_towert_lead:
        if isinstance(dicc, dict) and 'uid' in dicc and 'name' in dicc and dicc['uid'] and dicc['name']:
            identifier = (dicc['uid'],dicc['name'])
            if identifier not in view:
                view.add(identifier)
                new_list.append({'uid':dicc['uid'], 'name': dicc['name']})

    if len(new_list) != 0:
        return new_list
    else:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Devops list not found"}))

async def domaindevopslist(uiddevops):
    """
    Retrieves a list of unique domains associated with a specific DevOps user.

    Args:
        uiddevops (str): The UID of the DevOps user.

    Returns:
        list: A list of unique domains associated with the DevOps user. If no domains are found, an empty list is returned.

    Notes:
        - The function queries the MongoDB collection for documents where the specified DevOps UID is present.
        - It extracts the "domain" field from the results and removes duplicates.
        - If the "domain" field is None, it is excluded from the results.
    """
    # Set the environment where the information will be extracted
    functional_environment = os.getenv("ENVIRONMENT")
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    # Query the database for documents containing the specified DevOps UID
    querydbresult = mg.find({f"{functional_environment}.devops.uid": uiddevops})
    finddevops = [x[functional_environment] for x in querydbresult]

    # Extract unique domains, excluding None values
    devops_domains = [element["domain"] for element in finddevops if element["domain"] is not None]
    devops_domains = list(set(devops_domains))

    # Return the list of unique domains or an empty list if none are found
    if len(devops_domains) != 0:
        return devops_domains
    else:
        return []


async def validate_name(data):
    """
    Validate the 'name' field in the given data.

    Parameters:
    - data (dict or list): The data to be validated.

    Returns:
    - bool: True if the 'name' field is valid in all elements of the data, False otherwise.
    """
    if isinstance(data, dict):
        for key, value in data.items():
            if key == 'name' and (value is None or value == ''):
                return False
    elif isinstance(data, list):
        for item in data:
            if not validate_name(item):
                return False
    return True

async def updatefield(updatemongoinfo, auth, ldap):
    """
    Update a field in the MongoDB collection.

    Args:
        updatemongoinfo (dict): The information to update in the MongoDB collection.
        auth (str): The authentication token.
        ldap (str): The LDAP user identifier.

    Raises:
        HTTPException: If the user is not authorized.

    Returns:
        JSONResponse: The response indicating the success or failure of the update operation.
    """
    match entity_id:
        case "spain":
            # Authorization check for devops user
            devops_list = await readdevopslist()
            if any(devops.get("uid") == ldap for devops in devops_list):
                logger.info(f"Devops find in knowledge: OK, {ldap}")
            else:
                is_devops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if is_devops == False:
                    raise HTTPException(status_code=403, detail=USER_NOT_AUTHORIZED)

            # Update field in bbdd
            functional_environment = os.getenv("ENVIRONMENT")  # set the environment where the information will be extracted
            namespace = updatemongoinfo['namespace']
            mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

            if not await validate_name(updatemongoinfo):
                return responses.JSONResponse(status_code=status.HTTP_400_BAD_REQUEST,
                                            content=jsonable_encoder({"detail": STATUS_EMPTY}))

            current_time = datetime.now().strftime(DATE_FORMAT)
            updatemongoinfo['lastUpdate'] = current_time

            querydbresult = mg.find({f"{functional_environment}.namespace": namespace})
            findnamespace = [x[functional_environment]['namespace'] for x in querydbresult if x[functional_environment]['namespace'] == namespace]

            if len(findnamespace) == 0:
                return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,
                                            content=jsonable_encoder({"detail": PROJECT_NOT_FOUND}))
            if len(findnamespace) != 0:
                mg.update_one(
                    {f"{functional_environment}.namespace": namespace},
                    {'$set': {f"{functional_environment}": updatemongoinfo}}
                )
            
                return responses.JSONResponse(status_code=status.HTTP_200_OK,
                                            content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))
            if len(findnamespace) == 0:
                return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,
                                            content=jsonable_encoder({"detail": PROJECT_NOT_FOUND}))
        case _:
            await entity_updatefield(updatemongoinfo=updatemongoinfo)

async def entity_updatefield(updatemongoinfo):
    """
    Update a field in the MongoDB collection based on the provided information.

    Args:
        updatemongoinfo (dict): The information used to update the field.

    Returns:
        JSONResponse: The response containing the status code and content.

    Raises:
        None
    """
    
    # Update field in bbdd
    functional_environment = os.getenv("ENVIRONMENT")  # set the environment where the information will be extracted
    namespace = updatemongoinfo['namespace']
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    if not await validate_name(updatemongoinfo):
        return responses.JSONResponse(status_code=status.HTTP_400_BAD_REQUEST,
                                    content=jsonable_encoder({"detail": STATUS_EMPTY}))

    current_time = datetime.now().strftime(DATE_FORMAT)
    updatemongoinfo['lastUpdate'] = current_time

    querydbresult = mg.find({f"{functional_environment}.namespace": namespace})
    findnamespace = [x[functional_environment]['namespace'] for x in querydbresult if x[functional_environment]['namespace'] == namespace]

    if len(findnamespace) == 0:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,
                                    content=jsonable_encoder({"detail": PROJECT_NOT_FOUND}))
    if len(findnamespace) != 0:
        mg.update_one(
            {f"{functional_environment}.namespace": namespace},
            {'$set': {f"{functional_environment}": updatemongoinfo}}
        )
    
        return responses.JSONResponse(status_code=status.HTTP_200_OK,
                                    content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))
    if len(findnamespace) == 0:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,
                                    content=jsonable_encoder({"detail": PROJECT_NOT_FOUND}))
            
async def update_uid_name(uid, newuid, auth, ldap):
    """
    Update the uid and name fields in the database for the documents where uid appears.

    Args:
        uid (str): The current uid to be updated.
        newuid (str): The new uid to replace the current uid.
        auth: The authentication credentials.
        ldap: The LDAP information.

    Raises:
        HTTPException: If the user is not authorized.

    Returns:
        JSONResponse: The response indicating the success of the update.
    """
    match entity_id:
        case "spain":
            # Authorization check for devops user
            devops_list = await readdevopslist()
            if any(devops.get("uid") == ldap for devops in devops_list):
                logger.info(f"Devops find in knowledge: OK, {ldap}")
            else:
                is_devops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if is_devops == False:
                    raise HTTPException(status_code=403, detail=USER_NOT_AUTHORIZED)

            # Convert newuid to lowercase
            newuid = newuid.lower()

            # extract the data for last update date and uid
            doc_date_last_update = datetime.now().strftime(DATE_FORMAT)
            last_update_by_uid_name = await alm_teams_user(ldap)
            doc_lastupdateby = {
                "uid": last_update_by_uid_name[0]['userID'],
                "name": last_update_by_uid_name[0]['name']
            }

            # Update uid and name fields in bbdd
            functional_environment = os.getenv("ENVIRONMENT")  # set the environment where the information will be extracted
            result_newuid = await alm_teams_user(newuid)
            newname = result_newuid[0]['name']
            devops = result_newuid[0]['devops']

            # Check if devops is True or true
            if devops not in [True, "true"]:
                return responses.JSONResponse(status_code=status.HTTP_400_BAD_REQUEST,
                                            content=jsonable_encoder(
                                                {"detail": f"The user {newuid}/{newname} is not devops"}))

            # Find all documents where uid appears
            existing_docs = await find_documents_by_uid(uid, functional_environment)

            for doc in existing_docs:
                await update_document_with_new_uid(doc=doc, uid=uid, newuid=newuid, newname=newname, functional_environment=functional_environment, doc_date_last_update=doc_date_last_update, doc_lastupdateby=doc_lastupdateby)

            existing_docs_with_newuid = await find_documents_by_uid(newuid, functional_environment)

            for doc in existing_docs_with_newuid:
                remove_duplicate_uids(doc=doc, newuid=newuid, functional_environment=functional_environment, doc_date_last_update=doc_date_last_update, doc_lastupdateby=doc_lastupdateby)

            return responses.JSONResponse(status_code=status.HTTP_200_OK,
                                        content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))
        case _:
            
            # extract the data for last update date and uid
            doc_date_last_update = datetime.now().strftime(DATE_FORMAT)
            last_update_by_uid_name = await alm_teams_user(ldap)
            doc_lastupdateby = {
                "uid": last_update_by_uid_name[0]['userID'],
                "name": last_update_by_uid_name[0]['name']
            }

            await entity_update_uid_name(uid=uid, newuid=newuid, doc_date_last_update=doc_date_last_update, doc_lastupdateby=doc_lastupdateby)

async def entity_update_uid_name(uid, newuid, doc_date_last_update, doc_lastupdateby):
    """
    Update the uid and name fields in the database for a given uid.

    Args:
        uid (str): The original uid to be updated.
        newuid (str): The new uid to replace the original uid.

    Returns:
        JSONResponse: A JSON response indicating the status of the update operation.

    Raises:
        HTTPException: If the user is not a devops user.

    """
    
    # Convert newuid to lowercase
    newuid = newuid.lower()

    # Update uid and name fields in bbdd
    functional_environment = os.getenv("ENVIRONMENT")  # set the environment where the information will be extracted
    result_newuid = await alm_teams_user(newuid)
    newname = result_newuid[0]['name']
    devops = result_newuid[0]['devops']

    # Check if devops is True or true
    if devops not in [True, "true"]:
        return responses.JSONResponse(status_code=status.HTTP_400_BAD_REQUEST,
                                    content=jsonable_encoder(
                                        {"detail": f"The user {newuid}/{newname} is not devops"}))

    # Find all documents where uid appears
    existing_docs = await find_documents_by_uid(uid, functional_environment)

    for doc in existing_docs:
        await update_document_with_new_uid(doc=doc, uid=uid, newuid=newuid, newname=newname, functional_environment=functional_environment, doc_date_last_update=doc_date_last_update, doc_lastupdateby=doc_lastupdateby)

    existing_docs_with_newuid = await find_documents_by_uid(newuid, functional_environment)

    for doc in existing_docs_with_newuid:
        remove_duplicate_uids(doc=doc, newuid=newuid, functional_environment=functional_environment, doc_date_last_update=doc_date_last_update, doc_lastupdateby=doc_lastupdateby)

    return responses.JSONResponse(status_code=status.HTTP_200_OK,
                                content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))

async def   find_documents_by_uid(uid, functional_environment):
    """
    Find all documents where uid appears.

    Args:
        uid (str): The uid to search for.
        functional_environment (str): The environment where the information is extracted.

    Returns:
        list: A list of documents where uid appears.
    """
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    return list(mg.find({f"{functional_environment}.devops.uid": uid}))


async def update_document_with_new_uid(doc, uid, newuid, newname, functional_environment, doc_date_last_update, doc_lastupdateby):
    """
    Update the document with the new uid and name.

    Args:
        doc (dict): The document to update.
        uid (str): The current uid to be updated.
        newuid (str): The new uid to replace the current uid.
        newname (str): The new name to replace the current name.
        functional_environment (str): The environment where the information is extracted.
    """
    for devop in doc[functional_environment]['devops']:
        if devop['uid'] == uid:
            devop['uid'] = newuid
            devop['name'] = newname

    uids = [devop['uid'] for devop in doc[functional_environment]['devops']]
    if newuid in uids:
        doc[functional_environment]['devops'] = [
                                                devop for devop in doc[functional_environment]['devops'] if devop['uid'] != uid
                                                ]

    # Save the updated document to the database
    mg.update_one(
        {'_id': doc['_id']},
        {
            '$set': {
                f"{functional_environment}.devops": doc[functional_environment]['devops'],
                f"{functional_environment}.lastUpdate": doc_date_last_update,
                f"{functional_environment}.lastUpdateBy": doc_lastupdateby
            }
        }
    )


def remove_duplicate_uids(doc, newuid, functional_environment, doc_date_last_update, doc_lastupdateby):
    """
    Remove duplicate occurrences of newuid in the document.

    Args:
        doc (dict): The document to update.
        newuid (str): The new uid to check for duplicates.
        functional_environment (str): The environment where the information is extracted.
    """
    uids = [devop['uid'] for devop in doc[functional_environment]['devops']]
    if uids.count(newuid) > 1:
        first_occurrence = True
        updated_devops = []
        for devop in doc[functional_environment]['devops']:
            if devop['uid'] == newuid and first_occurrence:
                updated_devops.append(devop)
                first_occurrence = False
            elif devop['uid'] != newuid:
                updated_devops.append(devop)
        doc[functional_environment]['devops'] = updated_devops


    # Actualizar las claves lastUpdate y lastUpdateBy
    doc[functional_environment]['lastUpdate'] = doc_date_last_update
    doc[functional_environment]['lastUpdateBy'] = doc_lastupdateby

    #mg.update_one({'_id': doc['_id']}, {'$set': doc})
    mg.update_one(
        {'_id': doc['_id']},
        {
            '$set': {
                f"{functional_environment}.devops": doc[functional_environment]['devops'],
                f"{functional_environment}.lastUpdate": doc[functional_environment]['lastUpdate'],
                f"{functional_environment}.lastUpdateBy": doc[functional_environment]['lastUpdateBy']
            }
        }
    )

async def update_domain_knowledge(domain, newdomain, auth, ldap):
    """
    Update the domain name in multiple collections based on the given parameters.

    Args:
        domain (str): The current domain name to be updated.
        newdomain (str): The new domain name to replace the current domain.
        auth: The authentication credentials.
        ldap: The user's LDAP.

    Raises:
        HTTPException: If the user is not authorized.
        HTTPException: If the token does not exist.

    Returns:
        JSONResponse: A JSON response indicating the success of the update.
    """
    match entity_id:
        case "spain":
            #Authorization check for devops user
            devops_list = await readdevopslist()
            if any(devops.get("uid") == ldap for devops in devops_list):
                logger.info(f"Devops find in knowledge: OK, {ldap}")
            else:
                is_devops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops") 
                if is_devops == False:
                    raise HTTPException(status_code=403, detail=USER_NOT_AUTHORIZED)

            newdomain = newdomain.strip ()

            functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
            mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
            # Find all documents where uid appears
            existing_docs = list(mg.find({f"{functional_environment}.domain": domain}))
            # Update all documents with new domain
            for doc in existing_docs:

                # Save the updated document to the database
                doc_date_last_update = datetime.now().strftime(DATE_FORMAT)
                last_update_by_uid_name = await alm_teams_user(ldap)
                doc_lastupdateby = {
                    "uid": last_update_by_uid_name[0]['userID'],
                    "name": last_update_by_uid_name[0]['name']
                }

                mg.update_one({"_id": doc["_id"]}, {"$set": {
                                                            f"{functional_environment}.domain": newdomain,
                                                            f"{functional_environment}.lastUpdate": doc_date_last_update,
                                                            f"{functional_environment}.lastUpdateBy": doc_lastupdateby
                                                            }})
                logger.debug(f"SUCCESSFUL. -> Change domain name-> '{domain}' in namespace-> {doc[functional_environment]['namespace']} to new domain name-> '{newdomain}' in 'knowledge_spain' collection")
        
            await update_domain_in_collection(collection=os.getenv("COLLECTION_CAPACITY_SRE_DOMAIN_SCORE"), domain=domain, newdomain=newdomain, functional_environment=functional_environment)
            await update_domain_in_collection(collection=entity_id + "_" + os.getenv("COLLECTION_DASHBOARD_TOP_NAMESPACE_ALERTING"), domain=domain, newdomain=newdomain, functional_environment=functional_environment)
            await update_domain_in_collection(collection=os.getenv("COLLECTION_TECHNICALDEBT_HISTORICAL"), domain=domain, newdomain=newdomain, functional_environment=functional_environment)
            await update_domain_in_collection(collection=os.getenv("COLLECTION_TECHNICALDEBT_NUEVO"), domain=domain, newdomain=newdomain, functional_environment=functional_environment)
            
            return responses.JSONResponse(status_code=status.HTTP_200_OK, content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))
        case _:
            newdomain = newdomain.strip ()

            functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
            mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
            # Find all documents where uid appears
            existing_docs = list(mg.find({f"{functional_environment}.domain": domain}))
            # Update all documents with new domain
            for doc in existing_docs:
                # Save the updated document to the database
                doc_date_last_update = datetime.now().strftime(DATE_FORMAT)
                last_update_by_uid_name = await alm_teams_user(ldap)
                doc_lastupdateby = {
                    "uid": last_update_by_uid_name[0]['userID'],
                    "name": last_update_by_uid_name[0]['name']
                }

                mg.update_one({"_id": doc["_id"]}, {"$set": {
                                                            f"{functional_environment}.domain": newdomain,
                                                            f"{functional_environment}.lastUpdate": doc_date_last_update,
                                                            f"{functional_environment}.lastUpdateBy": doc_lastupdateby
                                                            }})
                logger.debug(f"SUCCESSFUL. -> Change domain name-> '{domain}' in namespace-> {doc[functional_environment]['namespace']} to new domain name-> '{newdomain}' in 'knowledge_spain' collection")

            await update_domain_in_collection(collection=os.getenv("COLLECTION_CAPACITY_SRE_DOMAIN_SCORE"), domain=domain, newdomain=newdomain, functional_environment=functional_environment)
            await update_domain_in_collection(collection=entity_id + "_" + os.getenv("COLLECTION_DASHBOARD_TOP_NAMESPACE_ALERTING"), domain=domain, newdomain=newdomain, functional_environment=functional_environment)
            await update_domain_in_collection(collection=os.getenv("COLLECTION_TECHNICALDEBT_HISTORICAL"), domain=domain, newdomain=newdomain, functional_environment=functional_environment)
            await update_domain_in_collection(collection=os.getenv("COLLECTION_TECHNICALDEBT_NUEVO"), domain=domain, newdomain=newdomain, functional_environment=functional_environment)
            
            return responses.JSONResponse(status_code=status.HTTP_200_OK, content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))
    
async def update_domain_in_collection(collection, domain, newdomain, functional_environment):
    """
    Update the domain name in a collection for a specific functional environment.

    Args:
        collection (str): The name of the collection to update.
        domain (str): The current domain name to be replaced.
        newdomain (str): The new domain name to replace the current domain.
        functional_environment (str): The functional environment to update the domain in.

    Raises:
        Exception: If an error occurs while updating the domain name.

    Returns:
        None
    """
    try:
        mg.change_collection(collection)
        existing_docs = list(mg.find({f"{functional_environment}.domain": domain}))
        for doc in existing_docs:
            mg.update_one({"_id": doc["_id"]}, {"$set": {
                                                        f"{functional_environment}.domain": newdomain
                                                        }})
            logger.debug(f"SUCCESSFUL. -> Change domain name-> '{domain}' to new domain name-> '{newdomain}' in '{collection}' collection")
    except Exception:
        logger.debug(f"FAILED. -> Change domain name-> '{domain}' to new domain name-> '{newdomain}' in '{collection}' collection")
    
async def insertfield(insertinfo, auth, ldap):
    """
    Insert a field into the database.

    Args:
        insertinfo (dict): The information to be inserted.
        auth (str): The authorization token.
        ldap (str): The LDAP user.

    Raises:
        HTTPException: If the user is not authorized or if there is an error with the input data.

    Returns:
        JSONResponse: The response indicating the success of the operation.
    """
    match entity_id:
        case "spain":
            #Authorization check for devops user
            devops_list = await readdevopslist()
            if any(devops.get("uid") == ldap for devops in devops_list):
                logger.info(f"Devops find in knowledge: OK, {ldap}")
            else:
                is_devops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                match is_devops:
                    case False:
                        raise HTTPException(status_code=403, detail=USER_NOT_AUTHORIZED)
            
            #Insert field in bbdd
            functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
            mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
            namespace = insertinfo['namespace']
            
            if not await validate_name(insertinfo):
                raise HTTPException(status_code=400, detail=STATUS_EMPTY)
            
            current_time = datetime.now().strftime(DATE_FORMAT)
            insertinfo['lastUpdate'] = current_time
            
            if namespace != None and namespace != '':
                if not await is_namespace_exists(namespace, functional_environment):
                    await insert_data(insertinfo, functional_environment)
                    return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))
                else:
                    raise HTTPException(status_code=400, detail=f"Project {namespace} exists in bbdd")
            else:
                raise HTTPException(status_code=400, detail="Project name is required")
        case _:
            await entity_insertfield(insertinfo=insertinfo)

async def entity_insertfield(insertinfo):
    """
    Insert a field in the database for a specific entity.

    Parameters:
        insertinfo (dict): Information about the field to be inserted.

    Raises:
        HTTPException: If the field name is empty or if the project name is required.

    Returns:
        JSONResponse: A JSON response indicating the success of the operation.
    """
    
    #Insert field in bbdd
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    namespace = insertinfo['namespace']
    
    if not await validate_name(insertinfo):
        raise HTTPException(status_code=400, detail=STATUS_EMPTY)
    
    current_time = datetime.now().strftime(DATE_FORMAT)
    insertinfo['lastUpdate'] = current_time
    
    if namespace != None and namespace != '':
        if not await is_namespace_exists(namespace, functional_environment):
            await insert_data(insertinfo, functional_environment)
            return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))
        else:
            raise HTTPException(status_code=400, detail=f"Project {namespace} exists in bbdd")
    else:
        raise HTTPException(status_code=400, detail="Project name is required")
                
async def is_namespace_exists(namespace, functional_environment):
    """
    Check if a namespace exists in the specified functional environment.

    Parameters:
        namespace (str): The namespace to check.
        functional_environment (str): The functional environment to search in.

    Returns:
        bool: True if the namespace exists, False otherwise.
    """
    
    querydbresult = mg.find({f"{functional_environment}.namespace": namespace})
    findnamespace = [x[functional_environment]['namespace'] for x in querydbresult if x[functional_environment]['namespace'] == namespace]
    return len(findnamespace) != 0

async def insert_data(insertinfo, functional_environment):
    """
    Inserts data into MongoDB.

    Parameters:
        insertinfo (any): The data to be inserted.
        functional_environment (str): The functional environment.

    Returns:
        None
    """
    insertinfo_add_result = {
        functional_environment : insertinfo
    }
    mg.add_data(data=insertinfo_add_result)
    
async def deletefield(namespacetodelete):
    """
    Delete a namespace in the "knowledge_discovery" collection.

    Parameters:
    - namespacetodelete (str): The namespace to be deleted.

    Returns:
    - JSONResponse: A JSON response indicating the status of the deletion.

    Raises:
    - HTTPException: If the project is not found.
    """
    #Delete namespace in "knowledge_discovery" collection
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION_DISCOVERY"))
    querydbresult = mg.find({f"{functional_environment}.namespace": namespacetodelete})
    if querydbresult is None:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": PROJECT_NOT_FOUND}))
    else:
        find_object_id = [x['_id'] for x in querydbresult if x[functional_environment]['namespace'] == namespacetodelete]
        if len(find_object_id) != 0:
            #template to delete document in mongodb
            mg.delete_one(
            { f"{functional_environment}.namespace": namespacetodelete }
            )
            return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": "Namespace deleted successfully"}))
        else:
                raise HTTPException(status_code=500, detail=PROJECT_NOT_FOUND)

async def alm_teams_user(uid):
    """
    Retrieves user data from the LDAP API based on the given user ID.

    Args:
        uid (str): The user ID.

    Returns:
        list: A list containing a dictionary with the user information. The dictionary has the following keys:
            - "userID" (str): The user ID.
            - "name" (str): The user's name.
            - "mail" (str): The user's email.
            - "devops" (bool): Indicates whether the user is a devops user or not.

    Raises:
        HTTPException: If the user ID is invalid or not found, or if there is an error connecting to the LDAP API.
    """
    userinforesult = []

    async def get_user_info(uid):
        """
        Retrieves user information from the LDAP API based on the provided user ID.

        Args:
            uid (str): The user ID to retrieve information for.

        Returns:
            dict: A dictionary containing the user information.

        Raises:
            HTTPException: If the user ID is invalid or not found, or if there is an error connecting to the host.
        """
        
        api_url = os.getenv("URL_ALM_API_LDAP")
        url_ldap = f"{api_url}/ldap/user/{uid}?details=ALL"
        ssl_status = os.getenv("SSL_FLAG_URL_ALM_API_LDAP")
        match ssl_status:
            case "True":
                ssl_status = True
            case _:
                ssl_status = False
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url_ldap, verify_ssl=ssl_status, timeout=aiohttp.ClientTimeout(total=5, connect=2)) as r:
                    if r.status == 200:
                        response = await r.json()
                        return response
                    else:
                        logger.error(f"Invalid userID: {uid} or not found: {r.status}, {r.reason}")
                        return None
            except aiohttp.client_exceptions.ClientConnectorError:
                logger.error(f"Cannot connect to host {url_ldap}")
                raise HTTPException(status_code=500, detail=f"Cannot connect to host {url_ldap}")

    async def check_devops_user(response):
        """
        Check if the user is a member of the 'sanes_devops' group or if their UID is in the exception list.

        Parameters:
        - response: A dictionary containing user information.

        Returns:
        - True if the user is a member of the 'sanes_devops' group or if their UID is in the exception list.
        - False otherwise.
        """

        exception_rol_user_devops = os.getenv("EXCEPTION_ROL_USER_DEVOPS")
        user_exception = exception_rol_user_devops.split(',')
        groupname = "sanes_devops"
        for rol in response["teamsV2"].keys():
            for team in response["teamsV2"][rol]:
                if groupname == team:
                    return True
        return uid in user_exception

    response = await get_user_info(uid)
    if response:
        userfoundflag = await check_devops_user(response)
        match entity_id:
            case "spain":
                userinfo = {
                    "userID": response['userID'],
                    "name": response['name'],
                    "mail": response['mail'],
                    "devops": userfoundflag
                }
                userinforesult.append(userinfo)
            case _:
                userinfo = {
                    "userID": response['userID'],
                    "name": response['name'],
                    "mail": response['mail'],
                    "devops": True
                }
                userinforesult.append(userinfo)
    return userinforesult

async def getnamespacecluster(namespace):
    """
    Asynchronously retrieves the namespace cluster information for a given namespace.

    Parameters:
    - namespace (str): The name of the namespace to search for.

    Returns:
    - list: A list of dictionaries containing the cluster information for the given namespace. Each dictionary includes the following keys:
        - namespace (str): The name of the namespace.
        - name (str): The name of the cluster and region.
        - cluster (str): The name of the cluster.
        - region (str): The name of the region.
        - projectstatus (str): The status of the project (e.g., "Active" or "Deleted").
        - url (str): The URL associated with the namespace cluster.

    Note:
    - The function assumes the existence of a client object for making asynchronous requests.
    - The functional_environment variable is set to 'pro' by default.
    - The excluded_keys list contains cluster names to be excluded from the search.
    - The function uses the get_resource method of the client object to retrieve cluster and namespace information.
    - If the namespace is not found in any cluster, a dictionary with "Deleted" values is returned.
    """
    clusterlist = await find_namespace_clusters(namespace)
    if len(clusterlist) >= 1:
        return clusterlist
    else:
        return [{
            "namespace": namespace,
            "name": "Deleted",
            "cluster": None,
            "region": None,
            "projectstatus": "Deleted",
            "url": None
        }]

async def find_namespace_clusters(namespace):
    """
    Finds clusters that contain a given namespace.

    Args:
        namespace (str): The namespace to search for.

    Returns:
        list: A list of clusters that contain the given namespace.

    Raises:
        aiohttp.client_exceptions.ServerTimeoutError: If a timeout occurs while retrieving namespaces.
        Exception: If namespaces for a cluster and region cannot be retrieved.

    """
    
    clusterlist = []
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    clusters = await client.get_resource(resource="clusters", functional_environment=functional_environment, cluster=None)
    excluded_keys = ["proohe", "dmzbohe", "azure"]
    for cluster, regions in clusters.items():
        if cluster not in excluded_keys:
            for region in regions:
                cluster_api_url = regions[region]['url']
                try:
                    namespaces = await client.get_resource(resource="namespaces", functional_environment=functional_environment, cluster=cluster, region=region)
                    clusterlist.extend(await find_namespace_in_cluster(namespaces=namespaces, namespace=namespace, cluster=cluster, region=region, cluster_api_url=cluster_api_url))
                except aiohttp.client_exceptions.ServerTimeoutError:
                    logger.error(f"Timeout detected against {functional_environment+cluster+region} ")
                except Exception:
                    logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
    return clusterlist

async def find_namespace_in_cluster(namespaces, namespace, cluster, region, cluster_api_url):
    """
    Find the specified namespace in the given cluster and region.

    Args:
        namespaces (dict): A dictionary containing namespaces information.
        namespace (str): The name of the namespace to find.
        cluster (str): The name of the cluster.
        region (str): The name of the region.

    Returns:
        list: A list of dictionaries representing the found namespaces in the cluster.

    """
    
    clusterlist = []
    functional_environment = os.getenv("ENVIRONMENT", os.getenv("ENV", "")).lower()
    if functional_environment == "dev" or functional_environment == "pre":
        environment = f"-{functional_environment}"
    else:
        environment = '-pro'
    environments = [environment, '-dmz']
    for env in environments:
        r = [x for x in namespaces[region]['items'] if x['metadata']['name'] == namespace + env]
        if len(r) >= 1:
            logger.info(f"namespace {r[0]['metadata']['name']} found in {cluster} {region}")
            tmpcluster = {
                "namespace": namespace,
                "name": cluster + region,
                "cluster": cluster,
                "region": region,
                "projectstatus": 'Active',
                "url": cluster_api_url.replace("api", "console-openshift-console.apps").replace(":6443", "/k8s/cluster/projects/") + namespace + env
            }
            logger.info(f"namespace cluster URL -> {tmpcluster}")
            clusterlist.append(tmpcluster)
            break
    return clusterlist
        
async def getopenshiftnamespace_bybatch():
    """
    Asynchronously retrieves the list of OpenShift namespaces in batches and performs various operations on them.

    Returns:
        list: A list of dictionaries representing the namespaces and their associated information.

    Raises:
        aiohttp.client_exceptions.ServerTimeoutError: If a timeout is detected while retrieving namespaces.
        Exception: If the namespaces for a specific cluster and region cannot be retrieved.

    """
    logger.info("openshift namespace batch mongo-> starting")
    projectlist = await get_project_list()
    resultbatchproject = await get_result_batch_project(projectlist)
    resultbatchlist_dicovery = await get_result_batch_discovery(resultbatchproject)
    knowledgedb = await insert_namespaces(resultbatchlist_dicovery)
    
    # AKS namespaces
    try:
        resultakslist = await getaksnamespace()
        logger.debug(f"Total number of AKS namespaces retrieved: {len(resultakslist)}")
        # Define a dynamic list of exceptions
        exceptions = [exception.strip() for exception in os.getenv("AKS_EXCEPTIONS", "").split(",")]
        # Filter out namespaces starting with any of the prefixes in the exceptions list
        resultakslist = [namespace for namespace in resultakslist if not any(namespace.startswith(prefix) for prefix in exceptions)]
        if len(resultakslist) >= 1:
            resultaksproject = await get_result_batch_project(resultakslist)
            resultakslist_dicovery = await get_result_batch_discovery(resultaksproject)
            knowledgedb = await insert_namespaces(resultbatchlist_dicovery=resultakslist_dicovery, aks=True)
    except Exception as e:
        logger.error(f"Error retrieving AKS namespaces: {e}")


    return knowledgedb


async def get_project_list():
    """
    Asynchronously retrieves the list of projects from MongoDB.

    Returns:
        list: A list of unique project names.

    Raises:
        aiohttp.client_exceptions.ServerTimeoutError: If a timeout is detected while retrieving namespaces.
        Exception: If namespaces for a specific cluster and region could not be retrieved.
    """
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    clusters = await client.get_resource(resource="clusters", functional_environment=functional_environment, cluster=None)
    projectlist = []
    for cluster in clusters:
        if cluster not in ['proohe', 'dmzbohe']:
            for region in clusters[cluster]:
                try:
                    namespaces = await client.get_resource(resource="namespaces", functional_environment=functional_environment, cluster=cluster, region=region)
                    projectlist.extend([x['metadata']['name'][:-4] for x in namespaces[region]['items']])
                except aiohttp.client_exceptions.ServerTimeoutError:
                    logger.error(f"Timeout detected against {functional_environment+cluster+region} ")
                    continue
                except Exception:
                    logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                    continue
    return list(set(projectlist))


async def get_result_batch_project(projectlist):
    """
    Retrieves a list of projects that are not present in the knowledge database.

    Parameters:
    projectlist (list): A list of project names.

    Returns:
    list: A list of project names that are not present in the knowledge database.
    """
    namespaceknowledgelist = await getnamespace_bbdd_knowledge()
    resultbatchproject = [x for x in projectlist if x not in namespaceknowledgelist]
    return resultbatchproject

async def get_result_batch_discovery(resultbatchproject):
    """
    Retrieves a list of results from a batch project, excluding certain namespaces.

    Args:
        resultbatchproject (list): A list of project results.

    Returns:
        list: A filtered list of project results, excluding specific namespaces.
    """
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION_DISCOVERY"))
    querynamespacelist = mg.find({})
    namespaceknowledgelistbd_batch = [total[functional_environment]['namespace'] for total in querynamespacelist]
    resultbatchlist_dicovery = [x for x in resultbatchproject if not re.search("sanes-autoz|sanes-zzz|knative", x) and x not in namespaceknowledgelistbd_batch]
    return resultbatchlist_dicovery

async def insert_namespaces(resultbatchlist_dicovery,aks=None):
    """
    Inserts namespaces into the knowledge database.

    Args:
        resultbatchlist_dicovery (list): A list of namespaces to be inserted.

    Returns:
        list: The knowledge database after inserting the namespaces.
    """
    today = datetime.now().strftime("%Y-%m-%d-%H:%M")
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    knowledgedb = []
    for namespacebatch in resultbatchlist_dicovery:
        if aks:  # Check if aks is True
            tmpcluster = [{
                "namespace": namespacebatch,
                "name": "AKS",
                "cluster":"AKS",
                "region": None,
                "projectstatus": "Active",
                "url": None
            }]
        else:
            tmpcluster = await getnamespacecluster(namespacebatch)
        tmpknowledgedb = {
            'namespace': namespacebatch,
            'devops': None,
            'application': None,
            'domain': None,
            'tower': None,
            'towerLead': None,
            'technicalLead': None,
            'AppResponsible': None,
            'DomainResponsible': None,
            'cluster': tmpcluster,
            'SNOW': None,
            'insertionDate': today,
            'lastUpdate': today,
            'lastUpdateBy': {"uid": "SRE DevSecOps", "name": "SRE DevSecOps"},
            'serviceGroup': None
        }
        knowledgedb.append(tmpknowledgedb)

        mg.change_collection(os.getenv("COLLECTION_DISCOVERY"))
        tmpknowledgedb_add_result = {
            functional_environment: tmpknowledgedb
        }
        mg.add_data(data=tmpknowledgedb_add_result)
        logger.info(f"openshift namespace batch {namespacebatch} -> completed")
    return knowledgedb


async def getopenshiftnamespace_by_discovery():
    """
    Retrieves a list of namespaces from the "knowledge_discovery" collection in MongoDB.

    Returns:
        list: A list of namespaces excluding 'sanes-sredevsecops'.
    """
    #get the namespace list in "knowledge_discovery" collection
    mg.change_collection(os.getenv("COLLECTION_DISCOVERY"))
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    querynamespacelist = mg.find({})
    #sanes-sredevsecops
    namespaceknowledgelist = [total[functional_environment] for total in querynamespacelist if total[functional_environment]['namespace'] != 'sanes-sredevsecops']
    return namespaceknowledgelist

async def get_alldata_namespace_in_knowledge():
    """
    Retrieves all namespace data from MongoDB based on the specified environment.

    Returns:
        list: A list of namespace data.
    """
    # connect to MongoDB
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    querynamespacelist = mg.find({})
    namespaceknowledgelist = [total[functional_environment] for total in querynamespacelist if total[functional_environment]['namespace'] != 'sanes-sredevsecops']

    return namespaceknowledgelist

async def getnamespace_bbdd_knowledge():
    """
    Retrieves the namespace in the MongoDB knowledge database.

    Returns:
        list: A list of namespaces extracted from the database.
    """
    #get namespace in mongodb knowledge
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    querynamespacelist = mg.find({})
    namespaceknowledgelist = [total[functional_environment]['namespace'] for total in querynamespacelist]
    return namespaceknowledgelist

async def getatlasnamespace(namespace):
    """
    Retrieves the Atlas namespace information from the ARQ API.

    Args:
        namespace (str): The namespace of the Atlas project.

    Returns:
        dict: A dictionary containing the Atlas namespace information, including the following keys:
            - funcAppDomain (str): The functional application domain.
            - funcAppName (str): The functional application name.
            - funcAppId (str): The functional application ID.
            - tecAppId (str): The technical application ID.
            - tecAppName (str): The technical application name.
            - tecAppAppKeyValue (str): The technical application app key value.
            - tecAppWhatAmI (str): The technical application description.
            - ocpProject (str): The OpenShift project.
    """
    #Get Atlas info from ARQ API
    
    ##Get token JWT
    user=(os.getenv("USERSHUTTLE"))
    login_pswrd=(os.getenv("USERSHUTTLEPASSWD"))
    tokenbks= await gettokenbks(user,login_pswrd)
    headers= {
        "Content-Type": CONTENT_TYPE,
        "x-clientId" : "crasto",
        "Authorization" : f" Bearer {tokenbks}"      
              }
    #You need to pass the    data as json in the request body -> data=json.dumps(body), not in the request headers
   
    try:
        url = "https://crasto.corp.bsch/graphql" 
        #Standard GraphQL query
        query = 'query ocpToCatalog { tempwhatamidarwin{funcAppDomain funcAppName funcAppId tecAppId tecAppName tecAppAppKeyValue tecAppWhatAmI ocpProject ocpEnvironment}}'
        headers = {"Accept": CONTENT_TYPE,"Authorization":'Bearer '+str(tokenbks),"x-clientid":"crasto"}
        #test in local env
        #ca = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + 'santander-ca-root.crt'
        answer = requests.post(url=url,json={"query": query}, headers=headers,verify=True)
        atlasnamespacelist = []
        if answer.status_code == 200:
            switchedanswer = answer.json()

            atlasresult = [x for x in switchedanswer['data']['tempwhatamidarwin'] if x['ocpProject'] == namespace]
            if len(atlasresult) != 0:
                atlasnamespacelist = {
                        'funcAppDomain' : atlasresult[0]['funcAppDomain'],
                        'funcAppName' : atlasresult[0]['funcAppName'],
                        'funcAppId' : atlasresult[0]['funcAppId'],
                        'tecAppId' : atlasresult[0]['tecAppId'],
                        'tecAppName' : atlasresult[0]['tecAppName'],
                        'tecAppAppKeyValue' : atlasresult[0]['tecAppAppKeyValue'],
                        'tecAppWhatAmI' : atlasresult[0]['tecAppWhatAmI'],
                        'ocpProject' : atlasresult[0]['ocpProject'][:-4],
                        #'ocpEnvironment' : atlasresult[0]['ocpEnvironment']
                        }
                return atlasnamespacelist
            else:
                return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": PROJECT_NOT_FOUND}))
        else:
            respcode = answer.status_code
            raise HTTPException(status_code=respcode, detail=f"{answer.reason}")
    except aiohttp.client_exceptions.ServerTimeoutError:
        logger.error(f"Timeout detected against {url} ")
                    
#shuttle-knowledge-housekeep-cronjob
async def getbatchhousekeep():
    """
    Batch process that removes deprecated clusters in the collection knowledge_spain
    """
    logger.info(STATUS_BATCH)
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    funcional_enviroment=(os.getenv("ENVIRONMENT")).lower()
    #get Cluster deprecated and removed the database
    mg._collection.update_many({f"{funcional_enviroment}.cluster.projectstatus": "Deprecated"},{"$pull": {f"{funcional_enviroment}.cluster": {"projectstatus":"Deprecated"}}})
    #get Cluster with size 0 and set null
    mg._collection.update_many({f"{funcional_enviroment}.cluster": {"$size":0}},{"$set": {f"{funcional_enviroment}.cluster": None}})
    logger.info("Cluster clean-> completed")
    

            
#shuttle-mialm-cronjob
async def getbatchmialm():
    """
    Batch process that update users with role technical-lead in the collection knowledge_discovery
    """
    logger.debug(STATUS_BATCH)
    mg.change_collection(os.getenv("COLLECTION_DISCOVERY"))
    funcional_enviroment=(os.getenv("ENVIRONMENT")).lower()
    #get namespace database
    logger.debug("Get acronym...")
    project=mg._collection.distinct(f"{funcional_enviroment}.namespace")
    #get acronym
    for i in range(len(project)):
        acronym = project[i].split("san-")
        project[i] = "".join(acronym)
        acronym = project[i].split("sanes-")
        project[i] = "".join(acronym)
    

    #get tokenBks
    logger.debug("Get token...")
    user=(os.getenv("USERSHUTTLE"))
    passwd=(os.getenv("USERSHUTTLEPASSWD"))
    tokenbks= await gettokenbks(user,passwd)
    headers= {
        "Content-Type": CONTENT_TYPE,
        "x-clientId" : "MIALM",
        "Authorization" : f" Bearer {tokenbks}"      
              }
    #get content the project
    for i in range(len(project)):
        url=f'https://mialm.santander.gs.corp/api/v1/projects/{project[i]}'   
        async with aiohttp.ClientSession() as session:
            async with session.get(url,headers=headers,verify_ssl=True) as response:
                try:
                    logger.debug("Get content the project...")
                    content = await response.json()
                    #get user the project
                    
                    users=content["identity"]["users"]
                    list_users=[]
                   
                   #Create listuser, uid-user and name with role technical-lead
                    for k in range(len(users)):
                        logger.debug("Get technical-lead...")
                        if users[k]["role"]=="technical-lead":
                            try:
                                dict_users={}
                                user=await alm_teams_user(users[k]["userId"])
                                dict_users["uid"]=user[0]["userID"]
                                dict_users["name"]=user[0]["name"]
                                
                                list_users.append(dict_users)
                            except Exception as e:
                                logger.error(f"An error occurred: {e}")
                                logger.debug(f"User {users[k]['userId']} name not found, project:{project[i]}")
                                logger.info(f"User {users[k]['userId']} name not found, project:{project[i]}")
                    #Get namespace the database                
                    namespace=mg._collection.distinct(f"{funcional_enviroment}.namespace")
                    #Update project with the technical-lead
                    logger.debug("Update...")    
                    mg._collection.update_many({f"{funcional_enviroment}.namespace":namespace[i]},{"$set" : {f"{funcional_enviroment}.technicalLead": list_users}})
                except Exception:
                    logger.info(f"{project[i]}: Not authorized")
    logger.info(SUCCESS_BATCH)

async def gettoken(uid,login_pswrd):
    """
    Obtains the token jwt
    Args:
        uid: User.
        login_pswrd: Password the user.
    Returns:
        String: Token jwt
    """   
    # get the token for the user
    url = "https://srvnuarintra.santander.corp.bsch/sas/authenticate/credentials"
    header = {"Content-type": CONTENT_TYPE}

    body = {
        "credentialType": [
        "JWT"
    ],
        "idAttributes": {
            "uid": uid
        },
        "password": login_pswrd,
        "realm": "CorpIntranet"
    }

    async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=header,data=json.dumps(body) ,verify_ssl=True,timeout=aiohttp.ClientTimeout(total=15,connect=10)) as r:
                response = await r.json()
                if "jwt" in str(response):    
                    return response['jwt']
                else:
                    return False
                
async def gettokenbks(user,login_pswrd):
    """
    Obtains the token bks
    Args:
        uid: User.
        login_pswrd: Password the user.
    Returns:
        String: Token bks
    """  
    # get the tokenBKS for the user
    token=await gettoken(user,login_pswrd)
    url="https://srvnuarintra.santander.corp.bsch/sts/tokens/bks/personal"
    headers={
        "credentialType": "TOKEN",
        "Content-Type":CONTENT_TYPE
    }
    body={
        "token": f"{token}"
    }
    
    async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers,data=json.dumps(body) ,verify_ssl=True,timeout=aiohttp.ClientTimeout(total=15,connect=10)) as r:
                response = await r.json()
                return response["token"]

#shuttle-discovery-cronjob
async def getbatchdiscovery():
    """
    Batch process that update cluster in the collection knowledge_discovery and knowledge_spain
    """
    enviroment=(os.getenv("ENVIRONMENT")).lower()
    logger.debug(STATUS_BATCH)
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    namespaces=mg._collection.distinct(f"{enviroment}.namespace")
    logger.debug(f"COLLECTION: knowledge_{entity_id}")
    for namespace in namespaces:
        await updatecluster(enviroment,mg,namespace)
   
    logger.debug("COLLECTION_DISCOVERY")
    mg.change_collection(os.getenv("COLLECTION_DISCOVERY"))
    namespaces=mg._collection.distinct(f"{enviroment}.namespace")
    for namespace in namespaces:
        logger.debug(f"{namespace} search")
        await updatecluster(enviroment,mg,namespace)
    logger.info(SUCCESS_BATCH)
    
async def updatecluster(enviroment,mg:MongoClient,namespace):
    """
    Update the information the cluster the namespace in the database 
    Args:
        enviroment: Enviroment the cluster.
        db: Object the class MongoClient.
        namespace: Namespace a update
    """  
    logger.debug("Search cluster...")
    cluster=await getnamespacecluster(namespace=namespace)
    logger.debug("Cluster obtained...")
    
    #Save  clusters name deprecated
    cluster_deprecated_name={"name":[]}
    query={f"{enviroment}.namespace":namespace,f"{enviroment}.cluster.projectstatus": "Deprecated"}
    if mg._collection.count_documents(query)!=0:
        objects=mg._collection.find_one(query)
        cluster_deprecated=objects.get(f"{enviroment}",{}).get("cluster",{})
        for deprecated in range(len(cluster_deprecated)):
            if cluster_deprecated[deprecated]["projectstatus"] == "Deprecated":
                cluster_deprecated_name["name"].append(cluster_deprecated[deprecated]["name"])

    #Find namespace
    query={f"{enviroment}.namespace":namespace}
    
    #Deleted cluster namespace
    mg._collection.update_one(query,{"$set": {f"{enviroment}.cluster": None}})
    clusterlist_openshift=[]

    #Update cluster Active and Deprecated
    try:
        for region in range(len(cluster)):
                    clusterlist_openshift.append(cluster[region])
        listupdate=[]
        for i in clusterlist_openshift:
            name=i["name"]
            if name not in cluster_deprecated_name["name"]:
                listupdate.append(i)
            else:
                i["projectstatus"]="Deprecated"
                listupdate.append(i)
        mg._collection.update_one(query,{"$set": {f"{enviroment}.cluster": listupdate}})
    except Exception as e:
    #Update cluster None
        clusterlist_openshift.append(cluster)
        mg._collection.update_one(query,{"$set": {f"{enviroment}.cluster": clusterlist_openshift}})
        logger.error(f"Error: {e}")

async def batchinsert():
    """
    Batch process that update application and domain in the collection knowledge_discovery
    """
    enviroment=(os.getenv("ENVIRONMENT")).lower()
    mg.change_collection(os.getenv("COLLECTION_DISCOVERY"))
    logger.debug("COLLECTION_DISCOVERY")
    namespaces=mg._collection.distinct(f"{enviroment}.namespace")
    for namespace in namespaces:
        logger.debug(f"Get namespace {namespace}")
        atlasnamespacelist=await getatlasnamespace(namespace+"-pro")
        if isinstance(atlasnamespacelist, dict):
            query={f"{enviroment}.namespace":namespace}
            logger.debug(f"Update namespace {namespace}")
            mg._collection.update_one(query,{"$set": {f"{enviroment}.application": atlasnamespacelist['tecAppName']}})
            mg._collection.update_one(query,{"$set": {f"{enviroment}.domain": atlasnamespacelist['funcAppDomain']}})
    logger.debug(SUCCESS_BATCH)


async def addkey_service_group():
    """
    This function allows you to add the "serviceGroup" key with 'null' value.
    """
    #This function allows you to add the "serviceGroup" key with 'null' value
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    mg.update_many({}, {"$set": {f"{functional_environment}.serviceGroup": None}})
    querydbresult = mg.find({})
    return querydbresult

async def findservicegroup(servicegroup):
    """
    Retrieves documents from the MongoDB collection based on the provided service group.

    Args:
        servicegroup (str): The service group to search for.

    Returns:
        list: A list of documents matching the provided service group.
    """
    #This function allows you to add the "serviceGroup" key with 'null' value
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    querydbresult = [doc[functional_environment] for doc in mg.find({f"{functional_environment}.serviceGroup": servicegroup}) if functional_environment in doc]
    return querydbresult

async def servicegrouplist():
    """
    This function allows you to get a unique list of all "serviceGroup" values.

    Returns:
        - If serviceGroup values are found, it returns a set of unique serviceGroup values.
        - If no serviceGroup values are found, it returns a JSON response with status code 204 and a detail message.
    """
    #This function allows you to get a unique list of all "serviceGroup" values
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    # Get all documents
    all_documents = mg.find({})
    # Extract 'serviceGroup' values and remove duplicates by converting the list to a set
    service_group_values = set(doc[functional_environment]['serviceGroup'] for doc in all_documents if functional_environment in doc and 'serviceGroup' in doc[functional_environment] and doc[functional_environment]['serviceGroup'] is not None)
    if len(service_group_values) == 0:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "serviceGroup not found"}))
    return service_group_values
    
async def authorization_user_uid(auth, ldap):
    """
    Authorization check for user with specified credentials and LDAP UID.

    Args:
        auth (Auth): The authentication credentials.
        ldap (str): The LDAP UID of the user.

    Raises:
        HTTPException: If the user is not authorized or if the token does not exist.

    Returns:
        JSONResponse: A JSON response indicating whether the user is authorized or not.
    """
    match entity_id:
        case "spain":
            #Authorization check for devops user
            if auth:
                devops_list = await readdevopslist()
                if any(devops.get("uid") == ldap for devops in devops_list):
                    return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": AUTHORIZED_USER}))
                else:
                    is_devops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                    if is_devops == False:
                        raise HTTPException(status_code=403, detail=USER_NOT_AUTHORIZED)
                    return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": AUTHORIZED_USER}))
            else:
                raise HTTPException(status_code=400, detail=TOKEN_NOT_EXIST)
        case _:
            return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": AUTHORIZED_USER}))

################################################################################################################################################################################################################
# Domain mappings

def load_domain_mappings():
    domain_mappings_json = os.getenv('DOMAIN_MAPPINGS')
    if domain_mappings_json:
        return json.loads(domain_mappings_json)
    return {}

DOMAIN_MAPPINGS = load_domain_mappings()

def map_domain(getdomain):
    """
    Maps the department to the corresponding domain.
    """
    return DOMAIN_MAPPINGS.get(getdomain, getdomain)

async def fetch_project_content(project, headers):
    """
    Fetches the content of a project from the Atlas API.
    """
    url = f'https://atlas.isban.gs.corp/atlas/catalog/api/v1/functionalApplications?acronym={project}&page=1&per_page=10'
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers, verify_ssl=True) as response:
            logger.debug(f"Get namespace/acronym content: {project} in Atlas. Response status from Atlas API: {response.status}")
            if response.status == 200:
                content = await response.json()
                return content, response.status
            else:
                logger.debug(f"Acronym: {project} Not found in Atlas. Response status from Atlas API: {response.status}")
                return None, response.status

async def update_field_if_none(mg, functional_environment, namespace, field, value, field_name):
    """
    Updates a specific field in the database if it is None.
    """
    if field is None:
        mg._collection.update_one({f"{functional_environment}.namespace": namespace}, {"$set": {f"{functional_environment}.{field_name}": value}})
        logger.debug(f"Update {namespace} {field_name} data in BBDD...")

async def update_devops_field(mg, functional_environment, namespace, domain):
    """
    Updates the devops field in the database.
    """
    original_collection = mg._collection.name
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    try:
        find_domain = await readdomaindata(domain)
        detail_domain = [x['devops'] for x in find_domain if x['devops'] is not None]
        if len(detail_domain) != 0:
            unique_devops = {}
            for sublist in detail_domain:
                for item in sublist:
                    if item['uid'] not in unique_devops:
                        unique_devops[item['uid']] = item
            result_devops = list(unique_devops.values())
            mg.change_collection(original_collection)
            mg._collection.update_one({f"{functional_environment}.namespace": namespace}, {"$set": {f"{functional_environment}.devops": result_devops}})
            logger.debug(f"Update {namespace} devops data in BBDD...")
        else:
            mg.change_collection(original_collection)
    except Exception as e:
        mg.change_collection(original_collection)
        logger.error(f"An error occurred: {e}")
        logger.debug(f"Domain: {domain} -> No Content to update devops list")

async def find_namespace_db(mg, functional_environment, namespace):
    """
    Find documents in the MongoDB collection based on the given namespace.

    Parameters:
    - mg: The MongoDB collection object.
    - functional_environment: The functional environment to search in.
    - namespace: The namespace to search for.

    Returns:
    - A cursor object containing the matching documents.
    """
    # find with 'sanes-'
    query = {f"{functional_environment}.namespace": f"sanes-{namespace}"}
    result = list(mg.find(query))
    if len(result) != 0:
        return result,f"sanes-{namespace}"

    # find with 'san-'
    query = {f"{functional_environment}.namespace": f"san-{namespace}"}
    result = list(mg.find(query))
    if len(result) != 0:
        return result,f"san-{namespace}"

    query = {f"{functional_environment}.namespace": namespace}
    result = list(mg.find(query))
    return result,namespace

async def update_namespace_data(mg, functional_environment, namespace, app_responsible, domain, application, description):
    """
    Updates the namespace data in the database.
    """
    querydbresult,namespace = await find_namespace_db(mg, functional_environment, namespace)
    if len(querydbresult) != 0:
        await update_field_if_none(mg, functional_environment, namespace, querydbresult[0][functional_environment].get('AppResponsible'), app_responsible, 'AppResponsible')
        await update_field_if_none(mg, functional_environment, namespace, querydbresult[0][functional_environment].get('domain'), domain, 'domain')
        await update_field_if_none(mg, functional_environment, namespace, querydbresult[0][functional_environment].get('application'), application, 'application')
        #await update_field_if_none(mg, functional_environment, namespace, querydbresult[0][functional_environment].get('description'), description, 'description')

        if querydbresult[0][functional_environment].get('devops') is None:
            if querydbresult[0][functional_environment].get('domain') is not None:
                domain = querydbresult[0][functional_environment]['domain']
            await update_devops_field(mg, functional_environment, namespace, domain)

async def process_project(mg, functional_environment, project, headers):
    """
    Processes a single project and updates the database with the retrieved information.
    """
    content, status = await fetch_project_content(project, headers)
    if status == 200:
        logger.info(f"############ Namespace: {project} found in ATLAS ############")
        await update_namespace_data_from_content(mg=mg, functional_environment=functional_environment, project=project, content=content)

async def update_namespace_data_from_content(mg, functional_environment, project, content):
    """
    Updates the namespace data in the database based on the content retrieved from ATLAS.
    """
    application = content[0].get('name') if content[0].get('name') is not None else None
    description = content[0].get('description') if content[0].get('description') is not None else None
    getdomain = content[0].get('department') if content[0].get('department') is not None else None
    appresponsible_uid = content[0]['responsible'].get('id') if content[0].get('responsible') and content[0]['responsible'].get('id') is not None else None
    appresponsible_name = content[0]['responsible'].get('name') if content[0].get('responsible') and content[0]['responsible'].get('name') is not None else None
    app_responsible = [{"uid": appresponsible_uid, "name": appresponsible_name}] if appresponsible_uid and appresponsible_name else None
    domain = map_domain(getdomain)
    await update_namespace_data(mg, functional_environment, project, app_responsible, domain, application, description)

async def getcronjobofficialatlascatalog():
    """
    This function allows complete the data of the "AppResponsible,domain,application,description" fields in "knowledge_spain" and "knowledge_discovery" collection with the information obtained from ATLAS.
    """
    logger.debug("Batch starting")
    
    collection_list = ['COLLECTION_DISCOVERY', 'COLLECTION']

    total_domain = 0
    total_appresponsible = 0
    total_application = 0
    total_devop = 0

    for collection in collection_list:
        mg.change_collection(os.getenv(collection))
        functional_environment = (os.getenv("ENVIRONMENT")).lower()
        logger.debug("Get acronym...")
        project_list = mg._collection.distinct(f"{functional_environment}.namespace")
        #get acronym
        for i in range(len(project_list)):
            acronym = project_list[i].split("san-")
            project_list[i] = "".join(acronym)
            acronym = project_list[i].split("sanes-")
            project_list[i] = "".join(acronym)

        logger.debug("User authentication with Atlas API")
        user = os.getenv("USERSHUTTLE")
        passwd = os.getenv("USERSHUTTLEPASSWD")
        auth = base64.b64encode(f"{user}:{passwd}".encode()).decode()
        headers = {
            "Content-Type": CONTENT_TYPE,
            "Authorization": f"Basic {auth}"
        }

        for project in project_list:
            await process_project(mg, functional_environment, project, headers)

        logger.info("#############################################################")
        logger.info(f"Collection updated: {collection}")
        logger.info(f"TOTAL field domain updated: {total_domain}")
        logger.info(f"TOTAL field AppResponsible updated: {total_appresponsible}")
        logger.info(f"TOTAL field application updated: {total_application}")
        logger.info(f"TOTAL field devops updated: {total_devop}")
        logger.info("#############################################################")

    tower_lead_tower_field = (os.getenv("TOWERLEAD_TOWER_FIELD_CRONJOB_UPDATE")).lower()
    if tower_lead_tower_field == 'true':
        logger.info("Tower Lead and Tower field Update Batch starting")
        await cronjob_towerinfo_towerlead_domain()
        logger.info("Tower Lead and Tower field Update Batch completed")
    else:
        logger.info("skip.. Tower Lead and Tower field Batch Update")

    logger.info("Batch completed")



################################################################################################################################################################################################################

async def cronjob_towerinfo_towerlead_domain():
    """
    Asynchronous function that performs a cron job to update tower lead and tower name fields in a MongoDB collection.

    The function iterates over a range of numbers and retrieves environment variables related to tower fields, domain lists, and UID tower fields.
    It then checks if the UID tower field exists and retrieves the tower lead data from LDAP.
    If the user is a devops, the tower lead information is stored in a temporary dictionary and appended to the tower lead list.
    If the user is not a devops, a JSON response with a 204 status code is returned.

    The function then updates the tower lead field and tower data in the MongoDB collection.
    It handles different formats of the domain list tower field and splits it into a list of domains.
    It also iterates over two collection names and performs operations for each domain in the domain list.

    For each domain, the function filters the MongoDB collection based on the domain and tower field conditions.
    If there are matching documents, it updates the tower field with the provided tower field value and increments the total tower name field counter.

    The function then queries the MongoDB collection for documents with a null tower lead field and retrieves the namespace and other relevant fields.
    If there are matching documents, it updates the tower lead field with the tower lead list and increments the total tower lead counter.

    Finally, the function logs the total number of tower lead and tower name field updates.

    Note: This function assumes the presence of certain environment variables and uses a MongoDB client for database operations.
    """
    total_tower_lead = 0
    total_tower_name_field = 0

    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted

    for num in range(10):
        await process_tower_lead_and_field(num, functional_environment, total_tower_lead, total_tower_name_field)

    logger.info(f"TOTAL field Tower Lead updated: {total_tower_lead}")
    logger.info(f"TOTAL field Tower name field updated: {total_tower_name_field}")


async def process_tower_lead_and_field(num, functional_environment, total_tower_lead, total_tower_name_field):
    """
    Process the tower lead and field for a given number.

    Args:
        num (int): The number.
        functional_environment (str): The functional environment.
        total_tower_lead (str): The total tower lead.
        total_tower_name_field (str): The total tower name field.

    Returns:
        None
    """
    
    uid_tower_field = os.getenv(f"UID_TOWER_FIELD_{num}")
    tower_field = os.getenv(f"TOWER_FIELD_{num}")
    domain_list_tower_field = os.getenv(f"DOMAIN_LIST_TOWER_FIELD_{num}")

    if uid_tower_field:
        tower_lead = await get_tower_lead(uid_tower_field)
        if tower_lead:
            tower_lead_list = [tower_lead]
            domain_split_list = await get_domain_split_list(domain_list_tower_field)

            collection_list = ['COLLECTION_DISCOVERY', 'COLLECTION']
            for collection in collection_list:
                mg.change_collection(os.getenv(collection))

                for domain in domain_split_list:
                    await update_tower_field(domain, tower_field, functional_environment, collection, total_tower_name_field)
                    await update_tower_lead(domain, tower_lead_list, functional_environment, collection, total_tower_lead)


async def get_tower_lead(uid_tower_field):
    """
    Retrieves the tower lead information based on the provided UID.

    Parameters:
    uid_tower_field (str): The UID of the tower field.

    Returns:
    dict or None: A dictionary containing the UID and name of the tower lead if they are a devops, 
    otherwise None.

    """
    
    uid_name = await alm_teams_user(uid_tower_field)
    if uid_name[0]['devops'] == True:
        logger.debug(f"Get user NAME -> {uid_name[0]['name']}")
        return {
            "uid": uid_name[0]['userID'],
            "name": uid_name[0]['name']
        }
    else:
        logger.debug(f"User -> {uid_name[0]['name']} is not a devops")
        return None


async def get_domain_split_list(domain_list_tower_field):
    """
    Returns a list of domain splits from the given domain_list_tower_field.

    Parameters:
    - domain_list_tower_field (str or list): The domain list or tower field.

    Returns:
    - list: A list of domain splits.

    Example:
    >>> domain_list_tower_field = "['domain1', 'domain2', 'domain3']"
    >>> get_domain_split_list(domain_list_tower_field)
    ['domain1', 'domain2', 'domain3']
    """
    
    if isinstance(domain_list_tower_field, list):
        logger.debug("update Tower Lead field and Tower Data")
        return domain_list_tower_field
    elif domain_list_tower_field.startswith("''") and domain_list_tower_field.endswith("''"):
        domain_list_tower_field = domain_list_tower_field[2:2]
    elif domain_list_tower_field.startswith("'") and domain_list_tower_field.endswith("'"):
        domain_list_tower_field = domain_list_tower_field[1:-1]
    return [s.strip() for s in domain_list_tower_field.split("', '") if s.strip()]


async def update_tower_field(domain, tower_field, functional_environment, collection, total_tower_name_field):
    """
    Updates the tower field in the specified collection for documents that match the given domain and have a different tower field value.

    Args:
        domain (str): The domain to filter documents by.
        tower_field (str): The new tower field value to update documents with.
        functional_environment (str): The name of the functional environment field in the documents.
        collection (str): The name of the collection to update.
        total_tower_name_field (int): The current value of the total tower name field.

    Returns:
        int: The updated value of the total tower name field after updating the documents.
    """
    
    filterlist = mg.find(
        {
            f"{functional_environment}.domain": domain,
            f"{functional_environment}.tower": {'$ne': tower_field}
        }
    )
    result_filter = [x for x in filterlist]
    if len(result_filter) != 0:
        mg.update_many({f"{functional_environment}.domain": domain}, {"$set": {f"{functional_environment}.tower": tower_field}})
        logger.debug(f"successfully updated: {domain} with Tower: {tower_field}. Collection: {os.getenv(collection)}")
        total_tower_name_field += len(result_filter) #increment counter
        return total_tower_name_field


async def update_tower_lead(domain, tower_lead_list, functional_environment, collection, total_tower_lead):
    """
    Update the tower lead for a given domain in the MongoDB collection.

    Parameters:
    - domain (str): The domain for which the tower lead needs to be updated.
    - tower_lead_list (list): The list of tower leads to be assigned.
    - functional_environment (str): The functional environment in which the tower lead needs to be updated.
    - collection (str): The name of the MongoDB collection.
    - total_tower_lead (int): The current count of tower leads.

    Returns:
    - int: The updated count of tower leads.

    Raises:
    - None

    """

    dbquery_towerlead = mg._collection.find(
        {
            f"{functional_environment}.domain": domain,
            f"{functional_environment}.towerLead": None
        },
        {
            f"{functional_environment}.namespace": 1,
            f"{functional_environment}.towerLead": 1,
            f"{functional_environment}.domain": 1,
            f"{functional_environment}.tower": 1,
        }
    )
    namespacelist = [x[functional_environment]['namespace'] for x in dbquery_towerlead]
    if len(namespacelist) != 0:
        for namespace in namespacelist:
            mg.update_one({f"{functional_environment}.namespace": namespace}, {"$set": {f"{functional_environment}.towerLead": tower_lead_list}})
            logger.debug(f"successfully updated: {domain} with Tower Lead: {tower_lead_list} in {namespace}. Collection: {os.getenv(collection)}")
            total_tower_lead += 1 #increment counter
            return total_tower_lead


async def get_tower_field_list():
    """
    Retrieves the list of tower fields from the MongoDB collection based on the specified environment.

    Returns:
        list: The list of tower fields.
        
    Raises:
        JSONResponse: If the tower list is not found in the collection.
    """
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    #get tower lead list
    filter_towert_lead = mg._collection.distinct(f"{functional_environment}.tower")
    
    result = [element for element in filter_towert_lead if element is not None]

    if len(result) != 0:
        return result
    else:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Tower list not found"}))


async def get_tower_detail(tower):
    """
    Retrieves the tower details based on the provided tower name.

    Args:
        tower (str): The name of the tower.

    Returns:
        list: A list of tower details if found, otherwise returns a JSON response with a status code of 204 and a detail message.

    """
    
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    #get tower lead list
    filter_towert_lead = mg.find({f"{functional_environment}.tower": tower})

    result = [x[functional_environment] for x in filter_towert_lead]
    if len(result) != 0:
        return result
    else:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Tower data not found"}))

async def emailnotification_sre(functional_environment,collection):
    """
    Asynchronously sends an email notification to SRECoEDevSecOps if certain conditions are met.

    Parameters:
    - functional_environment (str): The functional environment.
    - collection (str): The collection name.

    Returns:
    None

    Raises:
    None
    """
    ############ SRECoEDevSecOps Email notification ############
    emailsrenotification=(os.getenv("EMAIL_SRECOEDEVSECOPS_NOTIFICATION")).lower()
    if collection == 'COLLECTION_DISCOVERY' and emailsrenotification == 'true':
        #query to search for namespaces that has devops and is delete in the cluster
        dbquery_namespace_clusterdelete=mg._collection.find(
            {
                f"{functional_environment}.cluster.name": 'Deleted'
            },
            {
                f"{functional_environment}.namespace":1,
                f"{functional_environment}.application":1,
                f"{functional_environment}.domain":1,
                f"{functional_environment}.devops":1,
                f"{functional_environment}.cluster": 1
            }
        )
        cluster_delete_namespace_list = [x for x in dbquery_namespace_clusterdelete if x[functional_environment]['namespace'] != 'sanes-sredevsecops']
        if len(cluster_delete_namespace_list) != 0:
                logger.debug("Email SRECoEDevSecOps notification -> In progress")
            
                from_user = 'SRECoEDevSecOps@gruposantander.com'
                env_cc_user=(os.getenv("EMAIL_CC_USER_SRECOEDEVSECOPS_NOTIFICATION_DELETE_NAMESPACE")).lower()
                cc_user = list(set(env_cc_user.replace(' ', '').split(',')))

                env_email_list = (os.getenv("EMAIL_TO_USER_SRECOEDEVSECOPS_NOTIFICATION_DELETE_NAMESPACE")).lower()
                email_list = list(set(env_email_list.replace(' ', '').split(',')))

                #enable to perform tests with the chosen email, for example: email_list = ['pedro.alamilla@gruposantander.com']
                userlist = email_list
                subject = f'[Shuttle-Knowledge-{entity_id}] - Acción Requerida - Namespace a Revisar'

                #get content email in HTML format
                element_recovery = []
                for doc in cluster_delete_namespace_list:
                    namespace = doc.get(f"{functional_environment}",{}).get('namespace')
                    application = doc.get(f"{functional_environment}",{}).get('application')
                    domain = doc.get(f"{functional_environment}",{}).get('domain')

                    element_dict = {'namespace':namespace, 'application':application, 'domain': domain}
                    element_recovery.append(element_dict)

                #build html table
                table_html = '<table border="1"><tr><th>Namespace</th><th>Application<th>Domain</th>'
                for element in element_recovery:
                    table_html += f"<tr><td>{element['namespace']}</td><td>{element['application']}</td><td>{element['domain']}</td></tr>"
                table_html += '</table>'

                content = f"""
                <html>
                    <head></head>
                    <body>
                        <p>Hola,</p>
                        <p>Reciben este correo ya que se han identificado namespace con Cluster->Status: "Deleted" dentro de "Shuttle -> Knowledge -> Insert":</p>
                        <p><b> </b></p>
                        <p style="color: red;"><b>Listado de Namespace:</b></p>
                        {table_html}
                        <p style="color: red;">Validar que es correcta esta información desde Insert de Shuttle -> realiza las modificaciones oportunas y guarda el cambio: <a href="url">https://shuttle.santander.corp/knowledge</a></p>
                        <br>
                        <br>
                        <p><b></b></p>
                        <p>Un saludo</p>
                    </body>
                </html>
                """
                await send_mail(msg_from=from_user,msg_to_user=userlist,msg_cc_user=cc_user, msg_subject=subject,msg_content=content)
                #logger.debug(f"msg[CC] email notification -> {cc_user}")
                logger.debug("Email SRECoEDevSecOps notification -> Complete")
        else:
            logger.debug("No namespace with cluster status Deleted found in: Knowledge->INSERT.. Skip email notification")
        logger.info("############## Email Batch completed ##############")

async def querydevops_cluster(dbquery_devops_clusteractive,functional_environment):
    """
    Asynchronously queries the devops_clusteractive collection in the MongoDB database and sends email notifications to the devops assigned in the Shuttle-Knowledge-Insert namespace.

    Parameters:
    - dbquery_devops_clusteractive (list): A list of documents from the devops_clusteractive collection.
    - functional_environment (str): The functional environment to query.

    Returns:
    None

    Raises:
    None
    """
    uids_list = {devop['uid'] for item in dbquery_devops_clusteractive for devop in item[functional_environment]['devops']}
    uids_unique = list(uids_list)

    if len(uids_unique) != 0:
            logger.debug("Email Devops notification -> In progress")
            email_list = []
            for uid in uids_unique:
                email_uid = await alm_teams_user(uid)
                if email_uid and len(email_uid) > 0 and email_uid[0].get('mail'):  # Check if email is present
                    logger.debug(f"Get email user -> {email_uid[0]['mail']}")
                    email_list.append(email_uid[0]['mail'])
                else:
                    logger.debug(f"Email not found for user -> {uid}, skipping...")
            
            from_user = 'SRECoEDevSecOps@gruposantander.com'
            env_cc_user=(os.getenv("EMAIL_CC_USER_SRECOEDEVSECOPS_NOTIFICATION_ACTIVE_NAMESPACE")).lower()
            cc_user = list(set(env_cc_user.replace(' ', '').split(',')))                    
            #enable to perform tests with the chosen email, for example: email_list = ['pedro.alamilla@gruposantander.com']
            userlist = email_list
            subject = f'[Shuttle-Knowledge-{entity_id}] - Acción Requerida'

            """
            ################ GET TOWER LEADS UID TO EMAIL NOTIFICATIONS ################
            ############################################################################
            emailTowerLeadnotification = (os.getenv("EMAIL_CC_TOWER_LEAD")).lower()
            if emailTowerLeadnotification == 'true':
                collection = 'COLLECTION'
                mg.change_collection(os.getenv(collection))

                #query to search for namespaces that has Tower Lead and is active in the cluster
                DBquery_towerlead_clusterActive=mg._collection.distinct(f"{functional_environment}.towerLead")
                uids_towelist =  list({dicc.get('uid') for dicc in DBquery_towerlead_clusterActive if dicc and 'uid' in dicc and dicc.get('uid') != ''})

                towerLeadList = []
                for item_uid in uids_towelist:
                    email_uid = await alm_teams_user(item_uid)
                    if email_uid[0]['devops'] == True:
                        logger.debug(f"Get email user -> {email_uid[0]['mail']}")
                        towerLeadList.append(email_uid[0]['mail'])
                    else:
                        logger.debug(f"User -> {email_uid[0]['name']} is no devops")

                cc_towerList = set(towerLeadList)
                collection = 'COLLECTION_DISCOVERY'
                mg.change_collection(os.getenv(collection))
            else:
                collection = 'COLLECTION_DISCOVERY'
                mg.change_collection(os.getenv(collection))
                pass
            ############################################################################
            """
            
            #get content email in HTML format
            dbquery_devops_clusteractive=mg._collection.find(
                {
                    f"{functional_environment}.devops":{'$ne': None},
                    f"{functional_environment}.cluster.name":{'$ne': 'Deleted'}
                },
                {
                    f"{functional_environment}.namespace":1,
                    f"{functional_environment}.application":1,
                    f"{functional_environment}.domain":1,
                    f"{functional_environment}.devops":1,
                    #f"{functional_environment}.cluster": 1
                }
            )
            element_recovery = []
            for doc in dbquery_devops_clusteractive:
                namespace = doc.get(f"{functional_environment}",{}).get('namespace')
                application = doc.get(f"{functional_environment}",{}).get('application')
                domain = doc.get(f"{functional_environment}",{}).get('domain')

                element_dict = {'namespace':namespace, 'application':application, 'domain': domain}
                element_recovery.append(element_dict)

            #build html table
            table_html = '<table border="1"><tr><th>Namespace</th><th>Application<th>Domain</th>'
            for element in element_recovery:
                table_html += f"<tr><td>{element['namespace']}</td><td>{element['application']}</td><td>{element['domain']}</td></tr>"
            table_html += '</table>'

            content = f"""
            <html>
                <head></head>
                <body>
                    <p>Hola,</p>
                    <p>Reciben este correo ya que se encuentran como devops asignado dentro de "Shuttle -> Knowledge -> Insert" en alguno de los siguientes namespace:</p>
                    <p><b> </b></p>
                    <p style="color: red;"><b>Listado de Namespace:</b></p>
                    {table_html}
                    <p style="color: red;">Confirma que sí es correcta desde Insert de Shuttle -> realiza las modificaciones oportunas y guarda el cambio: <a href="url">https://shuttle.santander.corp/knowledge</a></p>
                    <br>
                    <br>
                    <p><b></b></p>
                    <p>Un saludo</p>
                </body>
            </html>
            """
            await send_mail(msg_from=from_user,msg_to_user=userlist,msg_cc_user=cc_user, msg_subject=subject,msg_content=content)
            logger.debug(f"msg[CC] email notification -> {cc_user}")
            logger.debug("Email notification -> Complete")
    else:
        logger.debug("No devops found in: Knowledge->INSERT.. Skip email notification")


async def cronjob_email_notification():
    """
    This function allows sending email notifications to devops/sre found in Knowledge -> INSERT.

    Parameters:
        None

    Returns:
        None

    Raises:
        None

    Example usage:
        await getcronjobEmailNotification()
    """

    logger.info(STATUS_BATCH)

    collection = 'COLLECTION_DISCOVERY'

    mg.change_collection(os.getenv(collection))
    functional_environment=(os.getenv("ENVIRONMENT")).lower()
    logger.info("############## Start Batch ##############")

    ############ Devops email notification ############
    emailnotification=(os.getenv("EMAIL_DEVOPS_NOTIFICATION")).lower()
    if collection == 'COLLECTION_DISCOVERY' and emailnotification == 'true':
        #query to search for namespaces that has devops and is active in the cluster
        dbquery_devops_clusteractive=mg._collection.find(
            {
                f"{functional_environment}.devops":{'$ne': None},
                f"{functional_environment}.cluster.name":{'$ne': 'Deleted'}
            },
            {
                f"{functional_environment}.namespace":1,
                f"{functional_environment}.application":1,
                f"{functional_environment}.domain":1,
                f"{functional_environment}.devops":1,
                #f"{functional_environment}.cluster": 1
            }
        )
        await querydevops_cluster(dbquery_devops_clusteractive=dbquery_devops_clusteractive,functional_environment=functional_environment)

        logger.info("Email Devops notification completed")

    await emailnotification_sre(functional_environment=functional_environment,collection=collection)


async def change_value_in_knowledge(uid, domainlist, auth, ldap):
    """
    This function allows you to change a Tower Lead value in a domain list.

    Parameters:
    - uid (str): The user ID.
    - domain_list (list): A list of domain names.
    - auth: The authorization credentials.
    - ldap: The LDAP information.

    Returns:
    - JSONResponse: A JSON response indicating the status of the update.

    Raises:
    - HTTPException: If the user is not authorized or the token does not exist.
    """
    match entity_id:
        case "spain":
            #Authorization check for devops user
            devops_list = await readdevopslist()
            functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
            if (ldap == "x021096" and functional_environment == "dev") or any(devops.get("uid") == ldap for devops in devops_list):
                logger.info(f"Devops find in knowledge: OK, {ldap}")
            else:
                is_devops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops") 
                if is_devops == False:
                    raise HTTPException(status_code=403, detail=USER_NOT_AUTHORIZED)
        
            tower_lead = await get_tower_lead(uid)
            if not tower_lead:
                return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "User is not a devops"}))

            domain_not_update, domain_updated = await update_domains(domainlist=domainlist, functional_environment=functional_environment, tower_lead=tower_lead, ldap=ldap)

            if len(domain_not_update) != 0:
                if len(domain_updated) != 0:
                    return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": f"Tower Lead: {tower_lead['uid']}/{tower_lead['name']}. domain UPDATED : {domain_updated}.. We also have non-updated domains: {domain_not_update} -> not exist in knowledge DB"}))
                else:
                    return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": f"Tower Lead: {tower_lead['uid']}/{tower_lead['name']}. domain NOT UPDATED : {domain_not_update} -> not exist in Knowledge DB"}))
            else:
                return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": f"Tower Lead: {tower_lead['uid']}/{tower_lead['name']}. domain UPDATED : {domain_updated}"}))
        case _:
            await entity_change_value_in_knowledge(uid=uid, domainlist=domainlist, ldap=ldap)

async def entity_change_value_in_knowledge(uid, domainlist, ldap):
    """
    Updates the domains in the knowledge database for a given user.

    Args:
        uid (str): The user ID.
        domainlist (list): A list of domains to update.

    Returns:
        JSONResponse: A JSON response indicating the status of the update.

    Raises:
        None
    """

    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    tower_lead = await get_tower_lead(uid)
    if not tower_lead:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "User is not a devops"}))

    domain_not_update, domain_updated = await update_domains(domainlist=domainlist, functional_environment=functional_environment, tower_lead=tower_lead, ldap=ldap)

    if len(domain_not_update) != 0:
        if len(domain_updated) != 0:
            return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": f"Tower Lead: {tower_lead['uid']}/{tower_lead['name']}. domain UPDATED : {domain_updated}.. We also have non-updated domains: {domain_not_update} -> not exist in knowledge DB"}))
        else:
            return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": f"Tower Lead: {tower_lead['uid']}/{tower_lead['name']}. domain NOT UPDATED : {domain_not_update} -> not exist in Knowledge DB"}))
    else:
        return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": f"Tower Lead: {tower_lead['uid']}/{tower_lead['name']}. domain UPDATED : {domain_updated}"}))

async def update_domains(domainlist, functional_environment, tower_lead, ldap):
    """
    Updates the domains in the knowledge database.

    Parameters:
    - domain_list (list): A list of domain names.
    - functional_environment (str): The functional environment.
    - tower_lead (dict): A dictionary containing the tower lead information with keys 'uid' and 'name'.

    Returns:
    - tuple: A tuple containing two lists - domain_not_update and domain_updated.
    """
    domain_not_update = []
    domain_updated = []
    for domain in domainlist:
        if await domain_exists(domain):
            await update_domain_tower_lead(domain=domain, functional_environment=functional_environment, tower_lead=tower_lead, ldap=ldap)
            domain_updated.append(domain)
        else:
            domain_not_update.append(domain)
    return domain_not_update, domain_updated


async def get_tower_lead(uid):
    """
    Retrieves the tower lead information for the given user ID.

    Parameters:
    - uid (str): The user ID.

    Returns:
    - dict: A dictionary containing the tower lead information with keys 'uid' and 'name'.
    """
    uid_name = await alm_teams_user(uid)
    if uid_name[0]['devops'] == True:
        return {
            "uid": uid_name[0]['userID'],
            "name": uid_name[0]['name']
        }
    else:
        return None


async def domain_exists(domain):
    """
    Checks if the given domain exists in the knowledge database.

    Parameters:
    - domain (str): The domain name.

    Returns:
    - bool: True if the domain exists, False otherwise.
    """
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
    filterlist = mg.find({f"{functional_environment}.domain": domain})
    result_filter = [x for x in filterlist]
    return len(result_filter) != 0


async def update_domain_tower_lead(domain, functional_environment, tower_lead, ldap):
    """
    Updates the tower lead for the given domain in the knowledge database.

    Parameters:
    - domain (str): The domain name.
    - functional_environment (str): The functional environment.
    - tower_lead (dict): A dictionary containing the tower lead information with keys 'uid' and 'name'.
    """
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    datelastupdate = datetime.now().strftime(DATE_FORMAT)
    if ldap == "x021096" and functional_environment == "dev":
        lastupdatebyuidname = [{'name': 'x021096', 'userID': 'x021096'}]
    else:
        lastupdatebyuidname = await alm_teams_user(ldap)
    uidnamelastupdateby = {
        "uid": lastupdatebyuidname[0]['userID'],
        "name": lastupdatebyuidname[0]['name']
    }

    # Save changes to the database
    mg.update_many({f"{functional_environment}.domain": domain}, {"$set": {
                                                                            f"{functional_environment}.towerLead": [tower_lead],
                                                                            f"{functional_environment}.lastUpdate": datelastupdate,
                                                                            f"{functional_environment}.lastUpdateBy": uidnamelastupdateby
                                                                            }})
    logger.debug(f"successfully updated: {domain} with TowerLead: {tower_lead}")
    
async def get_towerlead_list():
    """
    Retrieves the list of tower leads from the specified collection based on the functional environment.

    Returns:
        list: A list of dictionaries containing the tower lead information. Each dictionary has the keys 'uid' and 'name'.
        
    Raises:
        JSONResponse: If the tower lead list is not found, a JSONResponse with status code 204 and a detail message will be returned.
    """
    
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    #get tower lead list
    filter_tower_lead = mg._collection.distinct(f"{functional_environment}.towerLead")
    view = set()
    new_list = []

    for dicc in filter_tower_lead:
        if isinstance(dicc, dict) and 'uid' in dicc and 'name' in dicc and dicc['uid'] and dicc['name']:
            identifier = (dicc['uid'],dicc['name'])
            if identifier not in view:
                view.add(identifier)
                new_list.append({'uid':dicc['uid'], 'name': dicc['name']})

    if len(new_list) != 0:
        return new_list
    else:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Tower Lead list not found"}))

async def update_document_with_new_uid_and_name(doc, old_uid, new_uid, new_name, functional_environment,ldap):
    """
    Asynchronously updates a document in the database by replacing an old UID and name with a new UID and name 
    within a specified functional environment. If the new UID and name already exist, the old UID is removed 
    from the list. The function also updates metadata such as the last update timestamp and the user who 
    performed the update.
    Args:
        doc (dict): The document to be updated, typically retrieved from the database.
        old_uid (str): The UID to be replaced in the document.
        new_uid (str): The new UID to replace the old UID.
        new_name (str): The new name to replace the old name.
        functional_environment (str): The key representing the functional environment in the document.
        ldap (str): The LDAP identifier of the user performing the update.
    Returns:
        None: The function updates the document in the database and does not return a value.
    Raises:
        Exception: If there are issues with database operations or data structure inconsistencies.
    Notes:
        - The function checks if the new UID and name already exist in the document's 'devops' list.
        - If the new UID and name exist, the old UID is removed, and metadata is updated.
        - If the old UID exists, it is replaced with the new UID and name, and metadata is updated.
        - The function uses asynchronous calls to retrieve user information and update the database.
    """

    updated = False

    # Check the data structure
    devops_list = doc.get(functional_environment, {}).get("devops", [])

    # Check if the new_uid and new_name already exist in the list
    uid_exists = any(devops.get("uid") == new_uid and devops.get("name") == new_name for devops in devops_list)

    if uid_exists:
        devops_list_result = [devops for devops in devops_list if devops.get("uid") != old_uid]
        updated = True

        # Save the updated document to the database
        doc[functional_environment]['lastUpdate'] = datetime.now().strftime(DATE_FORMAT)
        if ldap == "x021096" and functional_environment == "dev":
            last_update_by_uid_name = [{'name': 'x021096', 'userID': 'x021096'}]
        else:
            last_update_by_uid_name = await alm_teams_user(new_uid)
        doc[functional_environment]['lastUpdateBy'] = {
            "uid": last_update_by_uid_name[0]['userID'],
            "name": last_update_by_uid_name[0]['name']
        }

        # Save changes to the database
        mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
        mg.update_one({"_id": doc["_id"]},
                      {
                          "$set": {
                                f"{functional_environment}.devops": devops_list_result,
                                f"{functional_environment}.lastUpdate": doc[functional_environment]['lastUpdate'],
                                f"{functional_environment}.lastUpdateBy": doc[functional_environment]['lastUpdateBy']
                              }
                        }
                    )
    else:
        # Iterate over the 'devops' list and update the corresponding values
        for devops in devops_list:
            if devops.get("uid") == old_uid:
                devops["uid"] = new_uid
                devops["name"] = new_name
                updated = True

        if updated:
            doc[functional_environment]['lastUpdate'] = datetime.now().strftime(DATE_FORMAT)
            if ldap == "x021096" and functional_environment == "dev":
                last_update_by_uid_name = [{'name': 'x021096', 'userID': 'x021096'}]
            else:
                last_update_by_uid_name = await alm_teams_user(ldap)
            doc[functional_environment]['lastUpdateBy'] = {
                "uid": last_update_by_uid_name[0]['userID'],
                "name": last_update_by_uid_name[0]['name']
            }

            # Save the updated document to the database
            mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)
            #mg.update_one({"_id": doc["_id"]}, {"$set": doc})
            mg.update_one(
                {"_id": doc["_id"]},
                {
                    "$set": {
                        f"{functional_environment}.devops": devops_list,
                        f"{functional_environment}.lastUpdate": doc[functional_environment]['lastUpdate'],
                        f"{functional_environment}.lastUpdateBy": doc[functional_environment]['lastUpdateBy']
                    }
                }
            )
        else:
            logger.debug(f"No matches found for UID '{old_uid}' in the document.")

async def swap_uids_and_names(uid1, uid2, auth, ldap):
    """
    Asynchronously swaps UIDs and associated names between two users in a MongoDB collection.
    This function handles the swapping of UIDs and names for documents in a MongoDB collection
    based on the provided UIDs. It includes authorization checks for DevOps users and ensures
    that the operation is performed only if both UIDs are found in the DevOps list. The function
    is specific to the "spain" entity and delegates to another function for other entities.
    Args:
        uid1 (str): The first UID to be swapped.
        uid2 (str): The second UID to be swapped.
        auth (Auth): The authentication object containing user credentials.
        ldap (str): The LDAP identifier of the user performing the operation.
    Raises:
        HTTPException: If the user is not authorized to perform the operation.
        HTTPException: If one or both UIDs are not found in the DevOps list.
    Returns:
        JSONResponse: A response object indicating the success or failure of the operation.
            - HTTP 200: If the swap operation is successful.
            - HTTP 204: If one or both UIDs are not found in the DevOps list.
    """


    match entity_id:
        case "spain":
            #Authorization check for devops user
            devops_list = await readdevopslist()
            functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
            if (ldap == "x021096" and functional_environment == "dev") or any(devops.get("uid") == ldap for devops in devops_list):
                logger.info(f"Devops find in knowledge: OK, {ldap}")
            else:
                is_devops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops") 
                if is_devops == False:
                    raise HTTPException(status_code=403, detail=USER_NOT_AUTHORIZED)
            devops_list = await readdevopslist()
            # Find all documents where uid1 and uid2 appear
            existing_docs_uid1 = await find_documents_by_uid(uid1, functional_environment)
            existing_docs_uid2 = await find_documents_by_uid(uid2, functional_environment)

            # Find the names associated with uid1 and uid2
            name1 = next((item["name"] for item in devops_list if item["uid"] == uid1), None)
            name2 = next((item["name"] for item in devops_list if item["uid"] == uid2), None)

            # Check if any of the names are missing
            if not name1 or not name2:
                return responses.JSONResponse(
                    status_code=status.HTTP_204_NO_CONTENT,
                    content=jsonable_encoder({"detail": "One or both UIDs not found in devops list."})
                )
            
            # Swap UIDs and names in documents
            for doc in existing_docs_uid1:
                await update_document_with_new_uid_and_name(doc=doc, old_uid=uid1, new_uid=uid2, new_name=name2, functional_environment=functional_environment, ldap=ldap)

            # Filter documents from existing_docs_uid2 that have already been updated
            updated_namespaces = [doc[functional_environment]['namespace'] for doc in existing_docs_uid1]
            existing_docs_uid2 = [doc for doc in existing_docs_uid2 if doc[functional_environment]['namespace'] not in updated_namespaces]

            for doc in existing_docs_uid2:
                await update_document_with_new_uid_and_name(doc=doc, old_uid=uid2, new_uid=uid1, new_name=name1, functional_environment=functional_environment, ldap=ldap)

            return responses.JSONResponse(status_code=status.HTTP_200_OK,
                                        content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))
        
        case _:
            await swap_uids_and_names_entity(uid1=uid1, uid2=uid2, ldap=ldap)

async def swap_uids_and_names_entity(uid1, uid2, ldap):
    """
    Asynchronously swaps UIDs and associated names between two entities in a MongoDB collection.
    This function identifies all documents in the database where the specified UIDs appear, 
    retrieves the names associated with those UIDs from a DevOps list, and swaps the UIDs 
    and names in the relevant documents. The operation ensures that no duplicate updates 
    occur for documents in overlapping namespaces.
    Args:
        uid1 (str): The first UID to be swapped.
        uid2 (str): The second UID to be swapped.
        ldap (str): The LDAP identifier of the user performing the operation.
    Returns:
        JSONResponse: A JSON response indicating the result of the operation. 
                      - HTTP 200 OK if the swap is successful.
                      - HTTP 204 NO CONTENT if one or both UIDs are not found in the DevOps list.
    Raises:
        None: The function handles all exceptions internally and returns appropriate HTTP responses.
    Notes:
        - The function operates in the "pro" functional environment.
        - Documents are updated using the `update_document_with_new_uid_and_name` function.
        - The DevOps list is retrieved using the `readdevopslist` function.
    """

    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    devops_list = await readdevopslist()
    # Find all documents where uid1 and uid2 appear
    existing_docs_uid1 = await find_documents_by_uid(uid1, functional_environment)
    existing_docs_uid2 = await find_documents_by_uid(uid2, functional_environment)

    # Find the names associated with uid1 and uid2
    name1 = next((item["name"] for item in devops_list if item["uid"] == uid1), None)
    name2 = next((item["name"] for item in devops_list if item["uid"] == uid2), None)

    # Check if any of the names are missing
    if not name1 or not name2:
        return responses.JSONResponse(
            status_code=status.HTTP_204_NO_CONTENT,
            content=jsonable_encoder({"detail": "One or both UIDs not found in devops list."})
        )
    
    # Swap UIDs and names in documents
    for doc in existing_docs_uid1:
        await update_document_with_new_uid_and_name(doc=doc, old_uid=uid1, new_uid=uid2, new_name=name2, functional_environment=functional_environment, ldap=ldap)

    # Filter documents from existing_docs_uid2 that have already been updated
    updated_namespaces = [doc[functional_environment]['namespace'] for doc in existing_docs_uid1]
    existing_docs_uid2 = [doc for doc in existing_docs_uid2 if doc[functional_environment]['namespace'] not in updated_namespaces]

    for doc in existing_docs_uid2:
        await update_document_with_new_uid_and_name(doc=doc, old_uid=uid2, new_uid=uid1, new_name=name1, functional_environment=functional_environment, ldap=ldap)

    return responses.JSONResponse(status_code=status.HTTP_200_OK,
                                content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))

async def switch_role_responsible(uid_old, new_uid, role, auth, ldap):
    """
    Asynchronously switches the responsible role from one user to another in a MongoDB collection.
    This function updates all documents in the specified MongoDB collection where the old user ID (`uid_old`) 
    is associated with a given role. It replaces the old user ID with the new user ID (`new_uid`) and updates 
    the corresponding name. Additionally, it ensures that the `lastUpdate` and `lastUpdateBy` fields are updated 
    to reflect the changes.
    Args:
        uid_old (str): The user ID of the current responsible user to be replaced.
        new_uid (str): The user ID of the new responsible user.
        role (str): The role to be updated (e.g., "AppResponsible").
        auth (Any): Authentication object or token for accessing external services.
        ldap (str): The LDAP identifier of the user making the change.
    Environment Variables:
        ENVIRONMENT (str): The functional environment (e.g., "dev", "prod") used to extract information.
        COLLECTION (str): The base name of the MongoDB collection to be modified.
    Returns:
        JSONResponse: A JSON response with HTTP status 200 if the operation is successful.
    Raises:
        Exception: If any error occurs during the database operation or external service calls.
    Notes:
        - The function retrieves the new user's details (e.g., `userID` and `name`) using the `alm_teams_user` function.
        - If the new user ID (`new_uid`) already exists in the role, the old user ID (`uid_old`) is simply removed.
        - If the new user ID does not exist, the old user ID is updated to the new user ID along with the name.
        - The `lastUpdate` and `lastUpdateBy` fields are updated with the current timestamp and the details of the user 
          making the change.
        - Changes are saved back to the MongoDB collection using the `update_one` method.
    """

    match entity_id:
        case "spain":
            #Authorization check for devops user
            devops_list = await readdevopslist()
            functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
            if (ldap == "x021096" and functional_environment == "dev") or any(devops.get("uid") == ldap for devops in devops_list):
                logger.info(f"Devops find in knowledge: OK, {ldap}")
            else:
                is_devops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops") 
                if is_devops == False:
                    raise HTTPException(status_code=403, detail=USER_NOT_AUTHORIZED)
                
            mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

            # Obtener todos los documentos donde aparece uid_old en AppResponsible
            existing_docs = list(mg.find({f"{functional_environment}.{role}.uid": uid_old}))

            # Obtener los datos del nuevo UID
            uid_data = await alm_teams_user(new_uid)
            uid = uid_data[0]['userID']
            name = uid_data[0]['name']

            # Actualizar todos los documentos encontrados
            for doc in existing_docs:
                app_responsible_list = doc[functional_environment].get(role, [])

                # Actualizar o eliminar uid_old según corresponda
                app_responsible_list = [
                    {"uid": uid, "name": name} if app_responsible.get("uid") == uid_old else app_responsible
                    for app_responsible in app_responsible_list
                    if app_responsible.get("uid") != uid_old or not any(ar.get("uid") == uid for ar in app_responsible_list)
                ]

                logger.debug(f"Procesado UID {uid_old} -> Actualizado a {uid} con nombre {name} si corresponde.")

                # Actualizar las claves lastUpdate y lastUpdateBy bajo functional_environment
                doc[functional_environment]['lastUpdate'] = datetime.now().strftime(DATE_FORMAT)
                if ldap == "x021096" and functional_environment == "dev":
                    last_update_by_uid_name = [{'name': 'x021096', 'userID': 'x021096'}]
                else:
                    last_update_by_uid_name = await alm_teams_user(ldap)
                doc[functional_environment]['lastUpdateBy'] = {
                    "uid": last_update_by_uid_name[0]['userID'],
                    "name": last_update_by_uid_name[0]['name']
                }

                # Guardar los cambios en la base de datos
                mg.update_one(
                    {"_id": doc["_id"]},
                    {
                        "$set": {
                            f"{functional_environment}.{role}": app_responsible_list,
                            f"{functional_environment}.lastUpdate": doc[functional_environment]['lastUpdate'],
                            f"{functional_environment}.lastUpdateBy": doc[functional_environment]['lastUpdateBy']
                        }
                    }
                )
                logger.debug(f"SUCCESSFUL. -> Updated {role} UID: {uid_old} to {uid}, Name: {name}")
            return responses.JSONResponse(status_code=status.HTTP_200_OK, content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))

        case _:
            await switch_role_responsible_entity(uid_old=uid_old, new_uid=new_uid, role=role, ldap=ldap)

async def switch_role_responsible_entity(uid_old, new_uid, role, ldap):
    """
    Asynchronously switches the responsible entity for a specific role in a MongoDB collection.
    This function updates all documents in a MongoDB collection where a specific user ID (`uid_old`) 
    is associated with a given role. It replaces the old user ID with a new user ID (`new_uid`) 
    and updates metadata fields such as `lastUpdate` and `lastUpdateBy`.
    Args:
        uid_old (str): The old user ID to be replaced.
        new_uid (str): The new user ID to replace the old one.
        role (str): The role under which the user ID is associated (e.g., "AppResponsible").
        ldap (str): The LDAP of the user performing the update, used to populate `lastUpdateBy`.
    Environment Variables:
        ENVIRONMENT (str): Specifies the functional environment (e.g., "dev", "prod").
        COLLECTION (str): The base name of the MongoDB collection to be used.
    Returns:
        JSONResponse: A JSON response with HTTP status 200 and a success message if the operation is successful.
    Raises:
        Exception: If any error occurs during the database operations or user data retrieval.
    Notes:
        - The function retrieves user data for the new user ID (`new_uid`) and the LDAP user 
          performing the update using the `alm_teams_user` function.
        - It ensures that duplicate entries for the new user ID are not created in the role's list.
        - The `lastUpdate` and `lastUpdateBy` fields are updated with the current timestamp 
          and the details of the user performing the update, respectively.
        - The MongoDB collection is dynamically selected based on the `COLLECTION` environment 
          variable and an `entity_id` suffix.
    Logging:
        - Logs debug messages for each processed document, including details of the update.
        - Logs a success message after each document is successfully updated.
    """

    functional_environment = os.getenv("ENVIRONMENT")  # Entorno funcional donde se extraerá la información
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    # Obtener todos los documentos donde aparece uid_old en AppResponsible
    existing_docs = list(mg.find({f"{functional_environment}.{role}.uid": uid_old}))

    # Obtener los datos del nuevo UID
    uid_data = await alm_teams_user(new_uid)
    uid = uid_data[0]['userID']
    name = uid_data[0]['name']

    # Actualizar todos los documentos encontrados
    for doc in existing_docs:
        app_responsible_list = doc[functional_environment].get(role, [])

        # Actualizar o eliminar uid_old según corresponda
        app_responsible_list = [
            {"uid": uid, "name": name} if app_responsible.get("uid") == uid_old else app_responsible
            for app_responsible in app_responsible_list
            if app_responsible.get("uid") != uid_old or not any(ar.get("uid") == uid for ar in app_responsible_list)
        ]

        logger.debug(f"Procesado UID {uid_old} -> Actualizado a {uid} con nombre {name} si corresponde.")

        # Actualizar las claves lastUpdate y lastUpdateBy bajo functional_environment
        doc[functional_environment]['lastUpdate'] = datetime.now().strftime(DATE_FORMAT)
        last_update_by_uid_name = await alm_teams_user(ldap)
        doc[functional_environment]['lastUpdateBy'] = {
            "uid": last_update_by_uid_name[0]['userID'],
            "name": last_update_by_uid_name[0]['name']
        }

        # Guardar los cambios en la base de datos
        mg.update_one(
            {"_id": doc["_id"]},
            {
                "$set": {
                    f"{functional_environment}.{role}": app_responsible_list,
                    f"{functional_environment}.lastUpdate": doc[functional_environment]['lastUpdate'],
                    f"{functional_environment}.lastUpdateBy": doc[functional_environment]['lastUpdateBy']
                }
            }
        )
        logger.debug(f"SUCCESSFUL. -> Updated {role} UID: {uid_old} to {uid}, Name: {name}")
    return responses.JSONResponse(status_code=status.HTTP_200_OK, content=jsonable_encoder({"detail": SUCCESS_MESSAGE}))

async def read_app_role_list(role):
    """
    Asynchronously retrieves a list of application roles based on the specified role.
    Args:
        role (str): The role to filter the application roles.
    Returns:
        list[dict]: A list of dictionaries containing 'uid' and 'name' of the roles, 
                    if roles are found.
        JSONResponse: A JSON response with a 204 status code and a message indicating 
                      that the role list was not found, if no roles are available.
    Raises:
        None
    Environment Variables:
        ENVIRONMENT (str): Specifies the functional environment to extract information from.
        COLLECTION (str): The base name of the MongoDB collection to query.
    Notes:
        - The function filters out duplicate roles based on the combination of 'uid' 
          and 'name'.
        - Only roles that are dictionaries and contain non-empty 'uid' and 'name' 
          fields are included in the result.
    """

    #get app role list
    functional_environment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    mg.change_collection(os.getenv("COLLECTION") + "_" + entity_id)

    #get tower lead list
    filtered_role = mg._collection.distinct(f"{functional_environment}.{role}")
    view = set()
    new_list = []

    for dicc in filtered_role:
        if isinstance(dicc, dict) and 'uid' in dicc and 'name' in dicc and dicc['uid'] and dicc['name']:
            identifier = (dicc['uid'],dicc['name'])
            if identifier not in view:
                view.add(identifier)
                new_list.append({'uid':dicc['uid'], 'name': dicc['name']})

    if len(new_list) != 0:
        return new_list
    else:
        return responses.JSONResponse(status_code=status.HTTP_204_NO_CONTENT,content=jsonable_encoder({"detail": "Role list not found"}))
