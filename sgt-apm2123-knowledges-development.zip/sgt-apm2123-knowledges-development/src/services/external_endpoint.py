import aiohttp
import json
import os
         
async def getaksnamespace():
    token = ''
    urlapi = os.getenv("API_AKS_URL") #set api url where the information will be extracted
    path = os.getenv("API_AKS_PATH") #set api path

    request_url = f"{urlapi}{path}"
    headers = {"Accept": "application/json","Authorization":'Bearer '+str(token),"x-clientid":"darwin"}
    body = {
    }

    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
        async with session.post(url=request_url, headers=headers, json=body, ssl=False) as resp:
            if resp.status == 200:
                datos = await resp.text()
                return json.loads(datos)
            else:
                return None