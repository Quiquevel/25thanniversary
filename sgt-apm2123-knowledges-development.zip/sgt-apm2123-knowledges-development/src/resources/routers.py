"""
This module contains the routers application for the microservice.
"""
from src.handler.external_requests import knowledge_namespace_management,knowledge_devops_management,knowledge_domain_management,knowledge_user_management,knowledge_tower_management,knowledge_service_group_management,knowledge_database_operations
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(knowledge_namespace_management),
    RouteClass(knowledge_devops_management),
    RouteClass(knowledge_domain_management),
    RouteClass(knowledge_user_management),
    RouteClass(knowledge_tower_management),
    RouteClass(knowledge_service_group_management),
    RouteClass(knowledge_database_operations),
]