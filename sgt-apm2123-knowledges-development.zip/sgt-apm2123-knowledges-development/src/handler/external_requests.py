from fastapi import APIRouter, Depends, responses, status
from fastapi.security import HTTPBearer
from fastapi.encoders import jsonable_encoder
from src.services.readmongo import readnamespacedata, readdevopsdata, readdomaindata, readdomainlist, readdevopslist,updatefield,insertfield,alm_teams_user,getnamespacecluster,getatlasnamespace,getopenshiftnamespace_by_discovery,getnamespace_bbdd_knowledge,deletefield,update_uid_name,update_domain_knowledge,get_alldata_namespace_in_knowledge,findservicegroup,servicegrouplist,authorization_user_uid,change_value_in_knowledge,get_towerlead_list,get_tower_field_list,get_tower_detail,swap_uids_and_names,switch_role_responsible,read_app_role_list,domaindevopslist, snowgroup, get_all_namespaces_with_snow, get_namespaces_by_snow
import urllib3
from src.models.knowledge_model import ReadModel, ReadModeldevops, ReadModeldomain, ReadModelupdate, ReadModeluid, ReadModelinsert, ReadNamespaceCluster, UpdateUid, Updatedomain, Findservicegroup, Authorizationuser, Changevaluemodel, Findtower, SwitchUid, SwitchRoleResponsible, RoleAppList
from src.services.readmongo import entity_id
bearer = HTTPBearer()

urllib3.disable_warnings()

#contant
API_KNOWLEDGE = "/api/v1/knowledge"

knowledge_namespace_management = APIRouter(tags=["Namespace Management"], prefix=API_KNOWLEDGE)
knowledge_devops_management = APIRouter(tags=["DevOps Management"], prefix=API_KNOWLEDGE)
knowledge_domain_management = APIRouter(tags=["Domain Management"], prefix=API_KNOWLEDGE)
knowledge_user_management = APIRouter(tags=["User Management"], prefix=API_KNOWLEDGE)
knowledge_tower_management = APIRouter(tags=["Tower Management"], prefix=API_KNOWLEDGE)
knowledge_service_group_management = APIRouter(tags=["Service Group Management"], prefix=API_KNOWLEDGE)
knowledge_database_operations = APIRouter(tags=["Database Operations"], prefix=API_KNOWLEDGE)

# Namespace Management
@knowledge_namespace_management.post("/detailnamespace", tags=["Namespace Management"], description="GET NAMESPACE DATA IN BBDD", response_description="JSON", status_code=200)
async def get_knowledge_namespace(target: ReadModel):
    """
    Asynchronously retrieves knowledge namespace data for a given target.

    Parameters:
    - target: The target ReadModel object containing the namespace to retrieve data for.

    Returns:
    - The retrieved knowledge namespace data.

    Raises:
    - Any exceptions raised by the readnamespacedata function.
    """
    return await readnamespacedata(namespace=target.namespace)

@knowledge_namespace_management.get("/snow/group/{namespace}", tags=["Namespace Management"], description="Get service now group for namespace", response_description="JSON", status_code=200)
async def get_snow_group(namespace: str):
    """
    Asynchronously retrieves information about a Snow group for the given namespace.
    Args:
        namespace (str): The namespace identifier for which the Snow group information is requested.
    Returns:
        Any: The result of the `snowgroup` function, which contains the Snow group information.
    Raises:
        Exception: If an error occurs during the retrieval process.
    """

    return await snowgroup(namespace=namespace)

@knowledge_namespace_management.get("/snow/{snow_value}", tags=["Namespace Management"], description="Get namespaces based on the provided ServiceNow (SNOW) value", response_description="JSON", status_code=200)
async def get_namespaces_by_snow_group(snow_value: str):
    """
    Asynchronously retrieves namespaces based on the provided ServiceNow (SNOW) value.
    Args:
        snow_value (str): The ServiceNow value used to query namespaces.
    Returns:
        Coroutine: A coroutine that resolves to the namespaces associated with the given SNOW value.
    """

    return await get_namespaces_by_snow(snow_value=snow_value)

@knowledge_namespace_management.get("/snow/list/namespace", tags=["Namespace Management"], description="Get all namespace with your service now group", response_description="JSON", status_code=200)
async def get_all_namespaces_with_snow_group():
    """
    Asynchronously retrieves all namespaces associated with a Snow group.
    This function acts as a wrapper for the `get_all_namespaces_with_snow` function,
    providing a clear and descriptive name for retrieving namespaces linked to a Snow group.
    Returns:
        list: A list of namespaces retrieved from the Snow group.
    """

    return await get_all_namespaces_with_snow()

@knowledge_namespace_management.post("/getnamespacecluster", tags=["Namespace Management"], description="GET CLUSTER/REGION NAMESPACE URL", response_description="JSON", status_code=200)
async def get_namespace_cluster(target: ReadNamespaceCluster):
    """
    Asynchronously retrieves the namespace cluster for the given target.

    Parameters:
    - target (ReadNamespaceCluster): The target containing the namespace.

    Returns:
    - The namespace cluster for the given target.
    """
    return await getnamespacecluster(namespace=target.namespace)

@knowledge_namespace_management.post("/getatlasnamespace", tags=["Namespace Management"], description="GET ATLAS NAMESPACE INFO", response_description="JSON", status_code=200)
async def get_atlas_namespace_info(target: ReadNamespaceCluster):
    """
    Get information about an Atlas namespace.

    Parameters:
    - target (ReadNamespaceCluster): The target namespace to retrieve information for.

    Returns:
    - The information about the Atlas namespace.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await getatlasnamespace(namespace=target.namespace)

@knowledge_namespace_management.post("/getnamespacebybatch", tags=["Namespace Management"], description="GET NAMESPACE LIST IN OPENSHIFT CLUSTER NOT FOUND IN KNOWLEDGE (knowledge_discovery DB)", response_description="JSON", status_code=200)
async def get_namespace_by_batch():
    """
    Retrieves the namespace by batch using the getopenshiftnamespace_by_discovery function.

    Returns:
        The namespace retrieved by the getopenshiftnamespace_by_discovery function.
    """
    return await getopenshiftnamespace_by_discovery()

@knowledge_namespace_management.post("/getnamespaceinknowledge", tags=["Namespace Management"], description="GET NAMESPACE LIST DATA IN KNOWLEDGE", response_description="JSON", status_code=200)
async def get_namespace_in_knowlegde():
    """
    Retrieves the namespace from the knowledge database.

    Returns:
        The namespace from the knowledge database.
    """
    return await getnamespace_bbdd_knowledge()

@knowledge_namespace_management.post("/get_alldata_namespace_in_knowledge", tags=["Namespace Management"], description="GET ALL KNOWLEDGE DATA IN A JSON FILE", response_description="JSON", status_code=200)
async def get_all_data_namespace_knowledge_json():
    """
    Retrieves all data in the knowledge namespace as JSON.

    Returns:
        The data in the knowledge namespace as JSON.
    """
    return await get_alldata_namespace_in_knowledge()

# DevOps Management
@knowledge_devops_management.post("/detaildevops", tags=["DevOps Management"], description="GET DEVOPS DATA IN BBDD", response_description="JSON", status_code=200)
async def get_knowledge_devops(target: ReadModeldevops):
    """
    Asynchronously retrieves knowledge about DevOps for a given target.

    Parameters:
    - target (ReadModeldevops): The target for which to retrieve knowledge.

    Returns:
    - The knowledge data retrieved from the DevOps read model.
    """
    return await readdevopsdata(uiddevops=target.uiddevops)

@knowledge_devops_management.post("/detaildevopslist", tags=["DevOps Management"], description="GET DEVOPS LIST DATA IN BBDD", response_description="JSON", status_code=200)
async def get_knowledge_devopslist():
    """
    Retrieves the devops list from the knowledge source.

    Returns:
        The devops list.
    """
    return await readdevopslist()

@knowledge_devops_management.post("/devopsdomain", tags=["DevOps Management"], description="GET ALL DOMAINS ASSOCIATED WITH A DEVOPS", response_description="JSON", status_code=200)
async def get_knowledge_devops_domain(target: ReadModeldevops):
    """
    Retrieves the devops domain list from the knowledge source.

    Returns:
        The devops domain list.
    """
    return await domaindevopslist(uiddevops=target.uiddevops)

# Domain Management
@knowledge_domain_management.post("/detaildomain", tags=["Domain Management"], description="GET DOMAIN DATA IN BBDD", response_description="JSON", status_code=200)
async def get_knowledge_domain(target: ReadModeldomain):
    """
    Asynchronously retrieves knowledge domain data for the given target domain.

    Parameters:
    - target (ReadModeldomain): The target domain for which to retrieve knowledge data.

    Returns:
    - The knowledge domain data for the target domain.

    Raises:
    - Any exceptions raised by the `readdomaindata` function.
    """
    return await readdomaindata(domain=target.domain)

@knowledge_domain_management.post("/detaildomainlist", tags=["Domain Management"], description="GET DOMAIN LIST DATA IN BBDD", response_description="JSON", status_code=200)
async def get_knowledge_domainlist():
    """
    Retrieves the knowledge domain list.

    Returns:
        The knowledge domain list.
    """
    return await readdomainlist()

@knowledge_domain_management.post("/updatedomain", tags=["Domain Management"], description="UPDATE DOMAIN TO OTHER IN BBDD", response_description="JSON", status_code=200)
async def update_domain_by_other(target: Updatedomain, authorization: str = Depends(bearer)):
    """
    Update a domain by using another domain.

    Args:
        target (Updatedomain): The target domain to be updated.
        authorization (str, optional): The authorization token. Defaults to Depends(bearer).

    Returns:
        The result of updating the domain.
    """
    return await update_domain_knowledge(domain=target.domain,newdomain=target.newdomain,auth=authorization, ldap=target.ldap)

# User Management
@knowledge_user_management.post("/roluser", tags=["User Management"], description="GET USER DATA AND TEAM ROL", response_description="JSON", status_code=200)
async def get_rol_user_data(target: ReadModeluid):
    """
    Retrieves the role user data for a given target.

    Parameters:
        target (ReadModeluid): The target user ID.

    Returns:
        The role user data for the given target.
    """
    return await alm_teams_user(uid=target.uid)

@knowledge_user_management.post("/updateuid", tags=["User Management"], description="UPDATE USER UID TO OTHER IN BBDD", response_description="JSON", status_code=200)
async def update_uid_by_other(target: UpdateUid, authorization: str = Depends(bearer)):
    """
    Update the UID by another UID.

    Args:
        target (UpdateUid): The target UID to be updated.
        authorization (str, optional): The authorization token. Defaults to Depends(bearer).

    Returns:
        The result of updating the UID.
    """
    return await update_uid_name(uid=target.uid,newuid=target.newuid,auth=authorization, ldap=target.ldap)

@knowledge_user_management.put("/updateresponsiblerole", tags=["User Management"], description="UPDATE RESPONSIBLE ROLE", response_description="JSON", status_code=200)
async def update_switch_uid_by_other(target: SwitchRoleResponsible, authorization: str = Depends(bearer)):
    """
    Asynchronously updates the UID of a switch role responsible entity by replacing it with another UID.
    Args:
        target (SwitchRoleResponsible): An object containing the old UID (`uid1`), 
            the new UID (`uid2`), and the role associated with the switch.
        authorization (str, optional): The bearer token for authorization. 
            Defaults to being injected via the `Depends` function.
    Returns:
        Any: The result of the `update_app_domain_responsible` function, 
            which performs the actual update operation.
    """

    return await switch_role_responsible(uid_old=target.uid_current,new_uid=target.new_uid,role=target.role,auth=authorization, ldap=target.ldap)

@knowledge_user_management.post("/roleuserapplist", tags=["User Management"], description="GET ROLE USER APP LIST DATA IN BBDD", response_description="JSON", status_code=200)
async def get_app_role_user_list(target:RoleAppList):
    """
    Asynchronously retrieves a list of knowledge domains based on the specified role.
    Args:
        target (RoleAppList): An object containing the role information for which the knowledge domain list is to be retrieved.
    Returns:
        list: A list of knowledge domains associated with the specified role.
    """
    return await read_app_role_list(role=target.role)

@knowledge_user_management.post("/authorizationuser", tags=["User Management"], description="VALIDATE USER UID - AUTHORIZATION", response_description="JSON", status_code=200)
async def authorization_uid(target: Authorizationuser, authorization: str = Depends(bearer)):
    """
    Retrieves the user ID for the given authorization and target user.

    Parameters:
        target (Authorizationuser): The target user for which to retrieve the user ID.
        authorization (str, optional): The authorization string. Defaults to Depends(bearer).

    Returns:
        The user ID for the given authorization and target user.
    """

    match entity_id:
        case "spain":
            return await authorization_user_uid(auth=authorization, ldap=target.ldap)
        case _:
            return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": "Authorized User"}))

@knowledge_user_management.post("/update_switch_uid", tags=["User Management"], description="updates the switch UID by swapping UIDs and names", response_description="JSON", status_code=200)
async def update_switch_uid_by_other(target: SwitchUid, authorization: str = Depends(bearer)):
    """
    Asynchronously updates the switch UID by swapping UIDs and names.
    This function swaps the UIDs and names of two entities based on the provided target object. 
    It requires an authorization token and optionally uses LDAP information from the target.
    Args:
        target (SwitchUid): An object containing the UIDs and LDAP information required for the swap.
        authorization (str, optional): The bearer token for authorization. Defaults to being injected via Depends.
    Returns:
        Any: The result of the `swap_uids_and_names` operation.
    Raises:
        HTTPException: If the authorization token is invalid or the operation fails.
    """

    return await swap_uids_and_names(uid1=target.uid1,uid2=target.uid2,auth=authorization, ldap=target.ldap)

# Tower Management
@knowledge_tower_management.post("/changetowerlead", tags=["Tower Management"], description="UPDATE TOWER LEAD IN A DOMAIN", response_description="JSON", status_code=200)
async def change_value_in_knowledge_db(target: Changevaluemodel, authorization: str = Depends(bearer)):
    """
    Change the value in the knowledge database.

    Parameters:
    - target: The target object containing the UID, domain list, and LDAP information.
    - authorization: The authorization token.

    Returns:
    - The result of changing the value in the knowledge database.
    """
    return await change_value_in_knowledge(uid=target.uid,domainlist=target.domainlist,auth=authorization,ldap=target.ldap)

@knowledge_tower_management.post("/towerleadlist", tags=["Tower Management"], description="GET TOWER LEAD LIST IN KNOWLEDGE", response_description="JSON", status_code=200)
async def towerlead_list_knowledge():
    """
    Retrieves the towerlead list of knowledge.

    Returns:
        The towerlead list of knowledge.
    """
    return await get_towerlead_list()

@knowledge_tower_management.post("/towerfieldlist", tags=["Tower Management"], description="GET TOWER FIELD LIST IN KNOWLEDGE", response_description="JSON", status_code=200)
async def towerlead_fieldlist_knowledge():
    """
    Asynchronous function that retrieves the field list for the tower lead knowledge.

    Returns:
        The field list for the tower lead knowledge.

    """
    return await get_tower_field_list()

@knowledge_tower_management.post("/towerdetail", tags=["Tower Management"], description="GET TOWER FIELD NAMESPACE DETAIL IN KNOWLEDGE", response_description="JSON", status_code=200)
async def towerlead_list_knowledge(target:Findtower):
    """
    Retrieves the tower detail for the given target tower.

    Args:
        target (Findtower): The target tower for which to retrieve the detail.

    Returns:
        The tower detail for the given target tower.

    """
    return await get_tower_detail(tower=target.tower)

# Service Group Management
@knowledge_service_group_management.post("/findservicegroup", tags=["Service Group Management"], description="ALLOW FIND SERVICE GROUP VALUE", response_description="JSON", status_code=200)
async def find_service_group(target:Findservicegroup):
    """
    Find a service group based on the provided target.

    Parameters:
    - target (Findservicegroup): The target service group to find.

    Returns:
    - The found service group.

    Raises:
    - None.
    """
    return await findservicegroup(servicegroup=target.servicegroup)

@knowledge_service_group_management.post("/servicegrouplist", tags=["Service Group Management"], description="GET SERVICE GROUP LIST", response_description="JSON", status_code=200)
async def service_group_list():
    """
    Asynchronous function that retrieves a list of service groups.

    Returns:
        List: A list of service groups.
    """
    return await servicegrouplist()

# Database Operations
@knowledge_database_operations.put("/updatefield", tags=["Database Operations"], description="UPDATE FIELD IN BBDD", response_description="JSON", status_code=200)
async def put_knowledge_update_field(target: ReadModelupdate, authorization: str = Depends(bearer)):
    """
    Updates a field in the knowledge database.

    Parameters:
    - target: The target ReadModelupdate object containing the information for the update.
    - authorization: The authorization token for the request.

    Returns:
    - The result of the update operation.

    Raises:
    - Any exceptions that occur during the update operation.
    """
    return await updatefield(updatemongoinfo=target.updatemongoinfo,auth=authorization, ldap=target.ldap)

@knowledge_database_operations.put("/insertfield", tags=["Database Operations"], description="INSERT DATA IN BBDD", response_description="JSON", status_code=200)
async def put_knowledge_insert_field(target: ReadModelinsert, authorization: str = Depends(bearer)):
    """
    Inserts a field into the knowledge database.

    Parameters:
    - target: ReadModelinsert - The target insert model.
    - authorization: str - The authorization token.

    Returns:
    - The result of the insert operation.
    """
    return await insertfield(insertinfo=target.insertinfo,auth=authorization, ldap=target.ldap)

@knowledge_database_operations.put("/deletefieldinDBbatch", tags=["Database Operations"], description="DELETE NAMESPACE IN 'knowledge_discovery' COLLECTION", response_description="JSON", status_code=200)
async def delete_namespace_knowledge_discoverydb(target: ReadNamespaceCluster):
    """
    Deletes a namespace from the knowledge discovery database.

    Parameters:
    - target (ReadNamespaceCluster): The target namespace to delete.

    Returns:
    - The result of the delete operation.
    """
    return await deletefield(namespacetodelete=target.namespace)

#uncomment to enable an endpoint to run the cronjob (GET Atlas info)
#@knowledge_read.post("/cronjobatlasofficialcatalog", tags=["v1"], description="ATLAS OFFICIAL CATALOG", response_description="JSON", status_code=200)
#async def atlas_official_catalog():
#    return await getcronjobofficialAtlasCatalog()

#uncomment to enable an endpoint to run the cronjob (UPDATE Tower Lead / Tower)
#@knowledge_read.post("/cronjobupdatetower", tags=["v1"], description="UPDATE TOWER AND TOWER LEAD", response_description="JSON", status_code=200)
#async def get_cronjob_towerInfo_towerLead_domain():
#    return await cronjob_towerInfo_towerLead_domain()

