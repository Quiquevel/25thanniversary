"""
This module contains the main FastAPI application for the microservice.
"""
from fastapi import FastAPI
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers
from src.app.config.composer_config import config as composer_config

app = FastAPI()

description = """
sgt-apm2123-knowledge

### SUMMARY
Microservice to get the project data info

### ENDPOINTS
* **/detailnamespace:** Get detail of project managers and devops by namespace
* **/detaildevops:** Get detail of project by devops
* **/detaildomain:** Get detail of project by domain
* **/detaildomainlist:** Get list of domain
* **/detaildevopslist:** Get list of devops
* **/updatefield:** Update field in bbdd
* **/insertfield:** Insert data in bbdd
* **/roluser:** Get user data and team rol
* **/getnamespacecluster:** Get cluster/region namespace URL
* **/getatlasnamespace:** Get Atlas namespace info
* **/getnamespacebybatch:** Get namespace list in openshift cluster not found in knowledge
* **/getnamespaceinknowledge:** Get namespace list data in knowledge
* **/get_alldata_namespace_in_knowledge:** Get all Knowledge data in a JSON file
* **/deletefieldinDBbatch:** Delete namespace in 'knowledge_discovery' collection
* **/updateuid:** Update a devops by replacing it with another in all found projects
* **/updatedomain:** Update a domain by replacing it with another in all found projects
* **/findservicegroup:** Allow find service group value
* **/servicegrouplist:** Get service group list
* **/authorizationuser** Validate user UID - Authorization
* **/changetowerlead** Change Tower Lead in a domain
* **/towerleadlist** Get Tower Lead list
* **/towerfieldlist** Get Tower field list in knowledge
* **/towerdetail** Get Tower field namespace detail in knowledge

### PARAMETERS
* **namespace:** example -> [entity]-aiops
"""

app = FastAPI(
                docs_url="/docs",
                title="sgt-apm2123-knowledge",
                description=description,version="1.0",
                openapi_url="/api/v1/openapi.json",
                contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"},
              )

DarwinComposer(app, config=composer_config, routers=routers)

