from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "sgt-apm2123-knowledge",
          "description": "Main core of SHUTTLE data, from where all the technical and functional relationship logic between the different elements is applied to generate specific Dashboards based on those relationships",
          "contact": {
               "name": "Pedro Alamilla",
               "url": "https://github.com/santander-group-sds-gln/sgt-apm2123-knowledges"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
