""" Change labels (add or delete) on a namespace given for a micro or list of micros (deployments or deploymentconfigs) """

from pydantic import BaseModel, Field
from typing import Optional


class MicrosRequest(BaseModel):
    functionalEnvironment: str = Field(json_schema_extra={"description":"Environment where the cluster-namespace-micro to label is in.",'examples': ['pro']})
    cluster: str = Field(json_schema_extra={"description":"Cluster where the namespace to update is in.",'examples': ['prodarwin']})
    region: Optional[str] = Field(default=None, json_schema_extra={"description":"Region to update. It could be empty for updating both.",'examples': ['bo1']})
    namespace: str = Field(json_schema_extra={"description":"Namespaces where the microservice is in.",'examples': ['namespace1']})
    microslist: list = Field(json_schema_extra={"description":"Microservices list to add or delete label with the label dict parameter.",'examples': [['micro1','micro2']]}) 
    microskind: str = Field(json_schema_extra={"description":"Kind of microservices. It could be deployments of deploymentconfigs.",'examples': ['deployments']})
    labels: dict = Field(json_schema_extra={"description":"Label to set in key:value dictionary format (value must be a string). You can set several labels at the same time. Values could be empty for deleting the label/s.", 'examples': [{'critical': 'true', 'domain': 'Devops'}]})
    action: str = Field(json_schema_extra={"description":"Action to do with the label: add or delete.",'examples': ['add']})
    ldap_user: Optional[str] = Field(default=None, json_schema_extra={"description":"LDAP user making the request.",'examples': ['nxxxxx']})


class MicrosResponse(BaseModel):
    label_list_status: dict = Field(json_schema_extra={"description":"List of labels changed",'examples': [{
        "result": {
            "labels": [
            {
                "project": "Namespace",
                "region": "bo1",
                "cluster": "bks",
                "micro": "micro1",
                "kind": "deployments",
                "labels": {
                "critical": "true",
                "domain": "Devops"
                },
                "action": "add",
                "Response Code": 200
            },
            {
                "project": "Namespace",
                "region": "bo1",
                "cluster": "bks",
                "micro": "micro2",
                "kind": "deployments",
                "labels": {
                "critical": "true",
                "domain": "Devops"
                },
                "action": "add",
                "Response Code": 200
            }
            ]
        }
        }] 
    })   
