""" Namespace Selector for aplying logic to relabel microservices in a namespace """

from pydantic import BaseModel, Field
from typing import Optional


class NamespaceSelector(BaseModel):
    label_dict: dict = Field(json_schema_extra={"description":"Dictionary with ONLY one labels to apply to the namespace microservice.",'examples': [{'key1': 'value1'}]})
    cluster: Optional[str] = Field(json_schema_extra={"description":"Cluster where the namespace to update is in.",'examples': ['prodarwin']})
    region: Optional[str] = Field(default=None, json_schema_extra={"description":"Region to update. It could be empty for updating both.",'examples': ['bo1']})
    namespace: Optional[str] = Field(json_schema_extra={"description":"Namespaces where the microservice is in.",'examples': ['namespace1']})

