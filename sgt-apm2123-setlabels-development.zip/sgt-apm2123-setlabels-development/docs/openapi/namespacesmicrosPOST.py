""" Change labels (add or delete) on a namespace list given for every micro (deployments, deploymentconfigs or both) """

from pydantic import BaseModel, Field
from typing import Optional

class NamespacesmicrosRequest(BaseModel):
    functionalEnvironment: str = Field(json_schema_extra={"description":"Environment where the cluster-namespace-micro to label is in.",'examples': ['pro']})
    cluster: str = Field(json_schema_extra={"description":"Cluster where the namespace to update is in.",'examples': ['prodarwin']})
    region: Optional[str]  = Field(default=None, json_schema_extra={"description":"Region to update. It could be empty for updating both.",'examples': ['bo1']})
    namespacesList: list = Field(json_schema_extra={"description":"List of namespaces where the microservice is in.",'examples': [['namespace1','namespace2']]})
    microskind: str = Field(json_schema_extra={"description":"Kind of microservices. It could be deployments of deploymentconfigs.",'examples': ['deployments']})
    labels: dict = Field(json_schema_extra={"description":"Label to set in key:value dictionary format (value must be a string). You can set several labels at the same time. Values could be empty for deleting the label/s.", 'examples': [{'critical': 'true', 'domain': 'Devops'}]})
    action: str = Field(json_schema_extra={"description":"Action to do with the label: add or delete.",'examples': ['add']})
    ldap_user: Optional[str] = Field(default=None, json_schema_extra={"description":"LDAP user making the request.",'examples': ['nxxxxx']})

class NamespacesmicrosResponse(BaseModel):
    label_list_status: dict = Field(json_schema_extra={"description":"List of labels changed",'examples': [{
        "result": {
            "labels": [
            {
                "project": "Namespace1",
                "region": "bo1",
                "cluster": "bks",
                "micro": "micro1",
                "kind": "deployments",
                "labels": {
                "critical": "true",
                "domain": "Devops"
                },
                "action": "add",
                "Response Code": 200
            },
            {
                "project": "Namespace2",
                "region": "bo1",
                "cluster": "bks",
                "micro": "micro2",
                "kind": "deployments",
                "labels": {
                "critical": "true",
                "domain": "Devops"
                },
                "action": "add",
                "Response Code": 200
            }
            ]
        }
        }] 
    })  
