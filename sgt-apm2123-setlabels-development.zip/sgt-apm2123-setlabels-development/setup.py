import setuptools
from version import __version__

setuptools.setup(
    name = "setlabels",
    version = __version__,
    author = "Juan Fernandez Diaz",
    author_email = "juan.fernandezdiaz@gruposantander.com",
    description = "Change labels (add or delete) on a namespace given for a micro or list of micros (deployments or deploymentconfigs)",
    long_description = "Microservice that allows creating, deleting, and modifying labels on PaaS microservices",
    long_description_content_type = "text/markdown",
    url = "http://mypythonpackage.com",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
    ],
    python_requires = '>=3.13.0',
)
