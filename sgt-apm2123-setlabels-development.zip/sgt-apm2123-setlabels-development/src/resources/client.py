"""
This module contains entity clients functions.
"""

from shuttlelib.openshift.client import OpenshiftClient
import os
 
entity = (os.getenv("ENTITY_ID")).lower()
client = OpenshiftClient(entity_id=entity)

def get_environments_clusters_list():    
    """
    Retrieves and processes the list of environments and clusters.
    This function extracts the environments and their associated clusters 
    from the `client.clusters` dictionary. It performs the following steps:
    1. Retrieves the list of environments (keys of `client.clusters`).
    2. Collects all clusters associated with each environment.
    3. Converts the environment and cluster names to uppercase and appends them 
       to their respective lists.
    4. Removes duplicate cluster names, sorts the cluster list, and returns 
       both the environment and cluster lists.
    Returns:
        tuple: A tuple containing:
            - environment_list (list): A list of environment names, including 
              their uppercase versions.
            - cluster_list (list): A sorted list of unique cluster names, 
              including their uppercase versions.
    """
    environment_list = []
    cluster_list = []
 
    environment_list = list(client.clusters.keys())
    for environment in environment_list:
        cluster_list.extend(client.clusters[environment])
   
    environment_list.extend([x.upper() for x in environment_list])    
    cluster_list.extend([x.upper() for x in cluster_list])
    cluster_list = list(set(cluster_list))
    cluster_list.sort()    
 
    return environment_list, cluster_list