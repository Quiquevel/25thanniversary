"""
This module contains commons functions.
"""
import os
from shuttlelib.utils.logger import logger
from src.resources.client import client

historical_trace_url = os.getenv("API_HISTORICAL_TRACE", "http://sgt-apm2123-historicaltrace:8080")
historical_trace_add_trace_api = os.getenv("API_HISTORICAL_TRACE_PATH", "/api/v1/historical_trace/add_trace")

async def get_namespace_objects(functional_environment,cluster,region,namespace,resource):
    """
    Asynchronously retrieves objects from a specified namespace within a Kubernetes cluster.
    Args:
        functional_environment (str): The functional environment (e.g., dev, prod) to query.
        cluster (str): The name of the Kubernetes cluster.
        region (str): The region where the cluster is located.  
        namespace (str): The namespace within the cluster to retrieve objects from.
        resource (str): The type of resource to retrieve (e.g., pods, services).
    Returns:
        list: A list of items retrieved from the specified namespace. If an error occurs, an empty list is returned.
    Raises:
        Exception: Logs an error message if the resource cannot be obtained.
    """

    try:
        resuorce = await client.get_resource(resource=resource,functional_environment=functional_environment,cluster=cluster,region=region,namespace=namespace)
        objectitems = resuorce[region]["items"]
    except Exception as e:
        logger.error(f"{resource} couldn't be obtained: {e}")
        objectitems = []

    return objectitems

async def send_trace_to_historical_trace(dic):
    """
    Asynchronously sends a trace dictionary to the historical trace microservice.

    Args:
        dic (dict): The trace information to be sent.

    Returns:
        None
    """
    import requests
    urlapi = historical_trace_url
    endpoint = historical_trace_add_trace_api
    try:
        answer = requests.post(urlapi+endpoint, json=dic, verify=False)
        logger.info(f"Response from historical_trace API {answer.status_code} - {answer.text}")
    except Exception as e:
        logger.error(f"Error sending trace to historical_trace API: {e}")