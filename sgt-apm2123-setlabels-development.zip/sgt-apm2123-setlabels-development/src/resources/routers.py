"""
This module contains routers resource.
"""
from src.handler.external_requests import set_labels
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(set_labels, ["v1"])
]