import json, os, requests
import shuttlelib.db.mongo as mongolib
from shuttlelib.utils.logger import logger
from fastapi import  HTTPException, status
from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder
from src.services.setLabels import set_micros_label_api

mg = mongolib.MongoClient()
mongocollection = os.getenv("COLLECTION")
mg.change_collection(collection=mongocollection)

exceptions = os.getenv("FIX_LABEL_EXCEPTIONS","[]")
exceptions = json.loads(exceptions)

getinfoall_url = os.getenv("GETINFOALL_URL", "http://sgt-apm2123-getinfoall:8080")
update_namespaces_api = os.getenv("GETINFOALL_API", "/v1/update_namespaces")
cronjob_name = os.getenv("CRONJOB_NAME", "sgt-apm2123-getinfoall-fixactivelabels")
environment = os.getenv("ENVIRONMENT", "pro")

async def build_mongo_query(cluster=None, region=None, namespace=None):
    """
    Builds a MongoDB query dictionary based on the provided filter parameters.

    Args:
        cluster (str, optional): The cluster name to filter by. Defaults to None.
        region (str, optional): The region to filter by. Defaults to None.
        namespace (str, optional): The namespace to filter by. Defaults to None.

    Returns:
        dict: A dictionary representing the MongoDB query with the specified filters.
    """
    query = {}
    if cluster is not None:
        query["cluster"] = cluster
    if region is not None:
        query["region"] = region
    if namespace is not None:
        query["namespace"] = namespace
    return query

async def set_label_update_db_api(label_dict, cluster=None, region=None, namespace=None):
    """
    Asynchronously sets or updates a label in the database and via an API for specified Kubernetes/OpenShift namespaces.
    This function performs the following steps:
    1. Builds a MongoDB query based on the provided cluster, region, and namespace.
    2. Retrieves matching objects from MongoDB.
    3. Validates that `label_dict` is a dictionary with exactly one key-value pair.
    4. For each matching object:
        - Splits deployments and deployment configs.
        - Applies label changes to both deployments and deployment configs.
        - Collects responses for updating the database.
    5. Updates the database with the new labels if changes were made.
    6. Returns a JSON response with the appropriate status code and detail message.
    Args:
        label_dict (dict): Dictionary containing a single label key-value pair to set.
        cluster (str, optional): Cluster name to filter the query. Defaults to None.
        region (str, optional): Region name to filter the query. Defaults to None.
        namespace (str, optional): Namespace to filter the query. Defaults to None.
    Raises:
        HTTPException: If `label_dict` is not a dictionary with exactly one key-value pair.
    Returns:
        JSONResponse: A response object containing the status code and a detail message about the operation outcome.
    """

    query = await build_mongo_query(cluster=cluster, region=region, namespace=namespace)
    logger.debug(f'[INFO] - Querying MongoDB with: {query}')
    
    allmongoobjects = mg.find(query)
    if (not isinstance(label_dict, dict) or len(label_dict) !=1):
        logger.error('[ERROR] - label_dict must be a dictionary with one key-value pair.')
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail={"message": "label_dict must be a dictionary with one key-value pair."})

    listforupdatingdb = []
    for mongoobject in allmongoobjects:
        namespace = mongoobject["namespace"]
        cluster = mongoobject["cluster"]
        region = mongoobject["region"]

        listforupdatingdb = []

        logger.info(f'[INFO] - Setting critical:false label  of {cluster}{region}-{namespace}')

        deployments, deployment_configs = await split_deployment_types(mongoobject, label_dict = label_dict)
        response, deployment_response_code = await handle_label_changes(labeldict=label_dict, cluster=cluster, region=region, namespace=namespace, microskind="deployments", microslist=deployments)
        listforupdatingdb.extend(response)
        response, deploymentconfigs_response_code = await handle_label_changes(labeldict=label_dict, cluster=cluster, region=region, namespace=namespace, microskind="deploymentconfigs", microslist=deployment_configs)
        listforupdatingdb.extend(response)

        response_update_label = max(deployment_response_code, deploymentconfigs_response_code)
    

    if listforupdatingdb != []:
        logger.debug('[DEBUG] - Labels checked and changed on Openshift')
        response_update_ddbb = await go_update_namespaces(listforupdatingdb)
        if response_update_ddbb != 200:
            logger.error(f'[ERROR] - There was an error updating DDBB, namespaces on {cluster}{region}-{namespace} after labeling micros')

    if response_update_label != 200:
        final_response = response_update_label
        detail_text = f'[ERROR] - There was an error labeling micros on {cluster}{region}-{namespace}'
        logger.error(detail_text)
        logger.error(f'[ERROR] - Response code: {response_update_label}')
        
    elif listforupdatingdb == [] and response_update_label == 200:
        final_response = 200
        detail_text = f'[INFO] - No micros to label on {cluster}{region}-{namespace}. Nothing to do.'
        logger.debug(detail_text)
    else:
        final_response = response_update_ddbb
        if response_update_ddbb != 200:
            detail_text = f'[ERROR] - There was an error updating DDBB, namespaces on {cluster}{region}-{namespace} after labeling micros'
            logger.error(detail_text)
            logger.error(f'[ERROR] - Response code: {response_update_ddbb}')
        else:
            detail_text = f'[INFO] - Labels checked and changed on Openshift and DDBB updated on {cluster}{region}-{namespace}'
            logger.info(detail_text)


    return JSONResponse(
        status_code=final_response,
        content=jsonable_encoder({
            "detail": detail_text
        })
    )


async def check_active_labels_api(cluster=None, region=None, namespace=None):
    """
    Asynchronously checks active labels in a MongoDB collection for the specified cluster, region, and namespace.
    Builds a MongoDB query based on the provided parameters, retrieves matching documents, and processes each document to determine which deployments and deployment configs need to be set online or offline. Logs relevant information during processing.
    Args:
        cluster (str, optional): The name of the cluster to filter by. Defaults to None.
        region (str, optional): The region to filter by. Defaults to None.
        namespace (str, optional): The namespace to filter by. Defaults to None.
    Returns:
        list: A list of formatted strings, each summarizing the actions to be taken for a specific (cluster, region, namespace) combination, including deployments/configs to be set online/offline and any exceptions encountered.
    """

    query = await build_mongo_query(cluster=cluster, region=region, namespace=namespace)
    logger.debug(f'[INFO] - Querying MongoDB with: {query}')
    allmongoobjects = mg.find(query)

    final_dic = []

    for mongoobject in allmongoobjects:
        namespace = mongoobject["namespace"]
        cluster = mongoobject["cluster"]
        region = mongoobject["region"]


        logger.info(f'[INFO] - Fixing active label of {cluster}{region}-{namespace}')

        deployments_to_online, deployment_configs_to_online, deployments_to_offline, deployment_configs_to_offline, exceptions_list = await check_wrong_active_labels(mongoobject)
        namespace_dic = (f'Cluster: {cluster}, Region: {region}, Namespace: {namespace}, '
                     f'Deployments to online: {deployments_to_online}, '    
                     f'DeploymentConfigs to online: {deployment_configs_to_online}, '
                     f'Deployments to offline: {deployments_to_offline}, '
                     f'DeploymentConfigs to offline: {deployment_configs_to_offline}, '
                     f'Exceptions: {exceptions_list}')
        logger.debug(f'[DEBUG] - {namespace_dic}')
        final_dic.append(namespace_dic)
    return final_dic
        
        


async def fix_active_labels_api(cluster=None, region=None, namespace=None):
    """
    Asynchronously fixes the 'active' labels for deployments and deploymentconfigs in a given cluster, region, and namespace by querying MongoDB, checking for incorrect labels, updating them as needed, and reflecting changes in the database.
    Args:
        cluster (str, optional): The name of the cluster to filter by. Defaults to None.
        region (str, optional): The region to filter by. Defaults to None.
        namespace (str, optional): The namespace to filter by. Defaults to None.
    Returns:
        JSONResponse: A response object containing the status code and a detail message about the operation outcome.
    Process:
        - Builds a MongoDB query based on the provided filters.
        - Iterates over matching MongoDB objects.
        - For each object, checks for deployments and deploymentconfigs with incorrect 'active' labels.
        - Updates labels to 'online' or 'offline' as appropriate.
        - Updates the database if any changes were made.
        - Logs relevant information and errors throughout the process.
        - Returns a JSON response with the result of the operation.
    """

    query = await build_mongo_query(cluster=cluster, region=region, namespace=namespace)
    logger.debug(f'[INFO] - Querying MongoDB with: {query}')

    
    allmongoobjects = mg.find(query)

    LABELONLINEDICT = {"active": "online"}
    LABELOFFLINEDICT = {"active": "offline"}
    
    listforupdatingdb = []
    for mongoobject in allmongoobjects:
        namespace = mongoobject["namespace"]
        cluster = mongoobject["cluster"]
        region = mongoobject["region"]

        final_response = 200
        listforupdatingdb = []

        logger.info(f'[INFO] - Fixing active label of {cluster}{region}-{namespace}')



        deployments_to_online, deployment_configs_to_online, deployments_to_offline, deployment_configs_to_offline, exceptions_list = await check_wrong_active_labels(mongoobject)
        response = await handle_label_changes(cluster=cluster, region=region, namespace=namespace, microskind="deployments", microslist=deployments_to_online, labeldict=LABELONLINEDICT)
        final_response, listforupdatingdb = await check_answers(response=response, listforupdatingdb=listforupdatingdb,final_response=final_response)

        response = await handle_label_changes(cluster=cluster, region=region, namespace=namespace, microskind="deployments", microslist=deployments_to_offline, labeldict=LABELOFFLINEDICT)
        final_response, listforupdatingdb = await check_answers(response=response, listforupdatingdb=listforupdatingdb,final_response=final_response)

        response = await handle_label_changes(cluster=cluster, region=region, namespace=namespace, microskind="deploymentconfigs", microslist=deployment_configs_to_online, labeldict=LABELONLINEDICT)
        final_response, listforupdatingdb = await check_answers(response=response, listforupdatingdb=listforupdatingdb,final_response=final_response)

        response = await handle_label_changes(cluster=cluster, region=region, namespace=namespace, microskind="deploymentconfigs", microslist=deployment_configs_to_offline, labeldict=LABELOFFLINEDICT)
        final_response, listforupdatingdb = await check_answers(response=response, listforupdatingdb=listforupdatingdb,final_response=final_response)


    if listforupdatingdb != []:
        logger.debug('[DEBUG] - Labels checked and changed on Openshift')
        response_update_ddbb = await go_update_namespaces(listforupdatingdb)
        if response_update_ddbb != 200:
            logger.error(f'[ERROR] - There was an error updating namespaces on {cluster}{region}-{namespace} after labeling micros')

    if final_response != 200:
        detail_text = f'[ERROR] - There was an error labeling micros on {cluster}{region}-{namespace}'
        logger.error(detail_text)
        logger.error(f'[ERROR] - Response code: {final_response}')
    elif listforupdatingdb == [] and final_response == 200:
        detail_text = f'[INFO] - No micros to label on {cluster}{region}-{namespace}. Nothing to do.'
        logger.debug(detail_text)
    else:
        if response_update_ddbb != 200:
            detail_text = f'[ERROR] - There was an error updating namespaces on {cluster}{region}-{namespace} after labeling micros'
        else:
            detail_text = f'[INFO] - Labels checked and changed on Openshift and DDBB updated on {cluster}{region}-{namespace}'
            logger.info(detail_text)
    
    return JSONResponse(
        status_code=final_response,
        content=jsonable_encoder({
            "detail": detail_text
        })
    )

async def check_answers(response, listforupdatingdb, final_response):
    """
    Processes the response and updates the provided list and final response value accordingly.

    Args:
        response (Any): The response to check. Can be a list or a value (e.g., status code).
        listforupdatingdb (list): The list to be updated if the response is a list.
        final_response (Any): The current final response value to be potentially updated.

    Returns:
        tuple: A tuple containing the updated final_response and listforupdatingdb.
    """
    if isinstance(response, list):
        listforupdatingdb.extend(response)
    else:
        if response != 200:
            final_response = max(response, final_response)
    return final_response, listforupdatingdb


async def handle_label_changes(cluster, region, namespace, microskind, microslist, labeldict):
    """
    Handles the process of updating labels for a list of microservices and collects results.

    Args:
        cluster (str): The name of the cluster where the microservices are located.
        region (str): The region of the cluster.
        namespace (str): The Kubernetes namespace of the microservices.
        microskind (str): The kind/type of the microservices to be labeled.
        microslist (list): A list of microservice identifiers to update labels for.
        labeldict (dict): A dictionary of labels to apply to the microservices.

    Returns:
        tuple: A tuple containing:
            - listforupdatingdb (list): A list of dictionaries with information about successfully updated microservices, each containing 'id', 'cluster', 'region', and 'namespace'.
            - response_code (int): The highest response code encountered during the labeling process (200 if all succeeded, otherwise the highest error code).
    """
    listforupdatingdb = []
    list_error = []
    response_code = 200
    if microslist:
        answer = await change_labels(functional_environment=environment,cluster=cluster, region=region, namespace=namespace, microskind=microskind, microslist=microslist, label=labeldict)
        for item in answer:
            if item.get("Response Code") != 200:
                logger.error(f'[ERROR] - There was an error labeling {microskind} to {labeldict} on {cluster}{region}-{namespace}-{item.get("Namespace")}')
                logger.error(f'[ERROR] - Response code: {answer}')
                response_code = max(item.get("Response Code"), response_code)
                #monto el diccionario de error para devolverlo y que se vea en la respuesta
                error_dict = {"cluster": cluster, "region": region, "namespace": namespace, "micro": item.get("Micro"), "kind": microskind, "labels": labeldict, "api_response": item.get("Response Code"), "Reason": item.get("Reason")}
                list_error.append(error_dict)
            else:
                dicttoadd = {"id": cluster + region + namespace, "cluster": cluster, "region": region, "namespace": namespace}
                if dicttoadd["id"] not in str(listforupdatingdb):
                    listforupdatingdb.append(dicttoadd)
    return listforupdatingdb, response_code

async def split_deployment_types(mongoobject, label_dict):
    """
    Splits microservices into 'Deployment' and 'DeploymentConfig' types based on a label value.
    Args:
        mongoobject (dict): A dictionary containing microservices data, expected to have a "microservices" key with a list of microservice dicts.
        label_dict (dict): A dictionary with a single key-value pair representing the label and its expected value.
    Returns:
        tuple: A tuple containing two lists:
            - deployments (list): Names of microservices of kind "Deployment" whose label value does not match the specified value.
            - deployment_configs (list): Names of microservices of kind "DeploymentConfig" whose label value does not match the specified value.
    Logs:
        - Information and debug messages about the processing of microservices and their types.
    """

    deployments = []
    deployment_configs = []

    logger.info('[INFO] - Looping micros...')
    label, value = next(iter(label_dict.items()))

    for micro in mongoobject["microservices"]:
        logger.debug(f'[DEBUG]- Checking label {label} : {value} of {micro["microservice"]}')
        current_value = None
 #       if micro["labels"] != None:
        try:
            current_value = micro["labels"][label]
        except KeyError:
            current_value = None

        if current_value != value:
            match micro["kind"]:
                case "Deployment":
                    logger.debug(f'[DEBUG] - {micro["microservice"]} is a Deployment.')
                    deployments.append(micro["microservice"]) 
                case "DeploymentConfig":
                    logger.debug(f'[DEBUG] - {micro["microservice"]} is a DeploymentConfig.')
                    deployment_configs.append(micro["microservice"])              

    return deployments, deployment_configs

async def check_wrong_active_labels(mongoobject):
    """
    Checks the 'active' label status of microservices in the provided MongoDB object and categorizes them based on their production block and kind.
    Args:
        mongoobject (dict): A dictionary representing the MongoDB object containing microservices information. 
            Expected to have a "microservices" key with a list of microservice dicts, each containing:
                - "microservice" (str): The name of the microservice.
                - "labels" (dict): A dictionary of labels, expected to contain an "active" key.
                - "productionBlock" (str): The production block status, e.g., "production" or "ocu".
                - "kind" (str): The type of deployment, e.g., "Deployment" or "DeploymentConfig".
    Returns:
        tuple: A tuple containing five lists:
            - deployments_to_online (list): Names of Deployment microservices in "production" block without "online" label.
            - deployment_configs_to_online (list): Names of DeploymentConfig microservices in "production" block without "online" label.
            - deployments_to_offline (list): Names of Deployment microservices in "ocu" block without "offline" label.
            - deployment_configs_to_offline (list): Names of DeploymentConfig microservices in "ocu" block without "offline" label.
            - exceptions_list (list): Names of microservices whose "active" label is in the exceptions list and were skipped.
    Notes:
        - The function uses a global 'exceptions' list and a 'logger' for logging debug and info messages.
        - Microservices with missing or exceptional "active" labels are added to the exceptions_list and skipped from other checks.
    """

    deployments_to_online = []
    deployment_configs_to_online = []
    deployments_to_offline = []
    deployment_configs_to_offline = []
    exceptions_list = []


    logger.info('[INFO] - Looping micros...')

    for micro in mongoobject["microservices"]:
        logger.debug(f'[DEBUG]- Checking labels of {micro["microservice"]}')

        label_active = None
 #       if micro["labels"] != None:
        try:
            label_active = micro["labels"]["active"]
        except KeyError:
            label_active = None


        if label_active in exceptions:
            logger.debug(f'[DEBUG] - {micro["microservice"]} with label active = {label_active} is in exceptions. Skipping...')
            exceptions_list.append(micro["microservice"])

        elif micro["productionBlock"] == "production" and label_active != "online":
            match micro["kind"]:
                case "Deployment":
                    logger.debug(f'[DEBUG] - {micro["microservice"]} is a Deployment. It does not have label online but its block is "production"')
                    deployments_to_online.append(micro["microservice"]) 
                case "DeploymentConfig":
                    logger.debug(f'[DEBUG] - {micro["microservice"]} is a DeploymentConfig. It does not have label online but its block is "production"')
                    deployment_configs_to_online.append(micro["microservice"])              

        elif micro["productionBlock"] == "ocu" and label_active != "offline":
            match micro["kind"]:
                case "Deployment":
                    logger.debug(f'[DEBUG] - {micro["microservice"]} is a Deployment. It does not have label offline but its block is "ocu"')
                    deployments_to_offline.append(micro["microservice"])
                case "DeploymentConfig":
                    logger.debug(f'[DEBUG] - {micro["microservice"]} is a DeploymentConfig. It does not have label offline but its block is "ocu"')
                    deployment_configs_to_offline.append(micro["microservice"])

    return deployments_to_online, deployment_configs_to_online, deployments_to_offline, deployment_configs_to_offline, exceptions_list

async def change_labels(functional_environment,cluster,region,namespace,microskind,microslist,label):
    """
    Asynchronously adds labels to a list of microservices in a specified environment.

    Parameters:
        functional_environment (str): The target functional environment.
        cluster (str): The Kubernetes cluster name.
        region (str or None): The region identifier. If "bo1-bo2", "weu1-weu2", or None, region is not passed to the API.
        namespace (str): The Kubernetes namespace.
        microskind (str): The kind of microservices to label.
        microslist (list): The list of microservices to label.
        label (dict): The labels to add.

    Returns:
        Any: The response from the set_micros_label_api function.

    Notes:
        - Uses a global variable 'cronjob_name' as the LDAP user for the API call.
        - Calls set_micros_label_api with appropriate parameters based on the region.
    """
    if region == "bo1-bo2" or region == "weu1-weu2" or region == None:
        answer = await set_micros_label_api (functional_environment, cluster=cluster, namespace=namespace, microslist=microslist, microskind=microskind, labels=label, action="add", regionparam=None, ldap_user=cronjob_name)
    else:
        answer = await set_micros_label_api (functional_environment, cluster=cluster, namespace=namespace, microslist=microslist, microskind=microskind, labels=label, action="add", regionparam=region, ldap_user=cronjob_name)
    return answer


async def go_update_namespaces(listforupdatingdb):
    """
    Asynchronously updates namespaces in the database, grouping them by cluster and region.
    Args:
        listforupdatingdb (list): A list of dictionaries, each containing 'cluster', 'region', and 'namespace' keys.
    Returns:
        int: The final response code. Returns 200 if all updates succeed, or the highest error code encountered.
    Logs:
        - Debug messages for the start of the update and for each group being updated.
        - Error messages if any update fails.
    Note:
        Requires the existence of the `call_update_namespaces` async function and the `environment` variable in scope.
    """
    logger.debug('[DEBUG] - Let\'s update database...')
    group_by_cluster_region = {}
    for  minidict in listforupdatingdb:
        clusterkey = minidict["cluster"]
        regionkey = minidict["region"]
        namespace = minidict["namespace"]

        singlekey = (clusterkey, regionkey)

        if singlekey not in group_by_cluster_region:
            group_by_cluster_region[singlekey] = {'cluster': clusterkey, 'region': regionkey, "namespacesList": []}
        
        group_by_cluster_region[singlekey]["namespacesList"].append(namespace)

    final_list = list(group_by_cluster_region.values())
    final_response = 200

    for elem in final_list:
        logger.info(f'[DEBUG] - Updating database for {elem["cluster"]}{elem["region"]}-{elem["namespacesList"]}')

        response = await call_update_namespaces(cluster=elem["cluster"],namespaces_list=elem["namespacesList"],functional_environment=environment,regionparam=elem["region"],objects_to_update=["labels"])
        if response != 200:
            logger.error(f'[ERROR] - There was an error updating namespaces on {elem["cluster"]}{elem["region"]}-{elem["namespacesList"]} after labeling micros')
            final_response = max(final_response, response)
    return final_response

async def call_update_namespaces(cluster, namespaces_list, regionparam ,objects_to_update,functional_environment):
    """
    Asynchronously calls an external API to update namespaces with provided parameters.
    Args:
        cluster (str): The name of the cluster to update.
        namespaces_list (list): A list of namespaces to be updated.
        regionparam (str): The region parameter for the update.
        objects_to_update (list): A list of objects to update within the namespaces.
        functional_environment (str): The functional environment context for the update.
    Returns:
        int: The HTTP status code returned by the API call.
    Raises:
        requests.RequestException: If the API request fails.
    """
    logger.debug('[DEBUG] - Let\'s call getinfoall updateinfoAPI...')


    body= {
        "functional_environment": functional_environment,
        "cluster": cluster,
        "region": regionparam,
        "namespacesList": namespaces_list,
        "objectsList": objects_to_update
    }


    answer = requests.post(getinfoall_url+update_namespaces_api, json=body, verify=False)
    
    return answer.status_code