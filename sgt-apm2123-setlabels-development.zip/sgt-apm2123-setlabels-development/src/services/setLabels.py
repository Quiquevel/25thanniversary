"""
This module contains the main function to set or delete labels.
"""
import requests
from requests.exceptions import ConnectTimeout, Timeout
import urllib3
from src.resources.client import client
import asyncio
from shuttlelib.utils.logger import logger
from src.resources.commonfunctions import get_namespace_objects, send_trace_to_historical_trace

loop = asyncio.get_event_loop()

urllib3.disable_warnings()

def oc_patch(url_api, token, label, namespace, apigroup=None, endpoint=None, micro=None, action="add"):
    """
    Patches labels on a specified OpenShift resource (namespace or microservice).
    Args:
        url_api (str): The base URL of the OpenShift API.
        token (str): The authorization token for the API.
        label (dict): A dictionary of labels to add or delete.
        namespace (str): The namespace of the resource.
        apigroup (str, optional): The API group of the resource. Required if patching a microservice.
        endpoint (str, optional): The endpoint of the resource. Required if patching a microservice.
        micro (str, optional): The name of the microservice to patch. If None, the namespace will be patched.
        action (str, optional): The action to perform, either "add" or "delete". Defaults to "add".
    Returns:
        requests.Response: The response from the API patch request.
    Raises:
        ConnectTimeout: If the connection to the API times out.
        Timeout: If the request times out.
    """
    
    if micro: #Label micro 
        request_url=url_api+"/apis/"+apigroup+"/namespaces/"+namespace+"/"+endpoint+"/"+micro
        headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close", "Content-Type": "application/merge-patch+json"}

        if action == "add":
            logger.debug(f'Changing label/s {list(label.keys())} on microservice {micro} of {namespace}. Action: {action} label/s')            
            body = {
                "metadata": {
                    "labels": label
                }
            }
        elif action == "delete":
            labels_to_remove = [labeltodelete for labeltodelete in label]
            logger.debug(f'Changing label/s on microservice {micro} of {namespace}. Action: {action} label/s') 
            body = {
                "metadata": {
                    "labels": {
                        label: None for label in labels_to_remove
                    }
                }
            }

    else: #Label namespace
        logger.debug(f'Changing label/s {list(label.keys())} on namespace {namespace}. Action: {action} label/s')
        request_url=url_api+"/apis/project.openshift.io/v1/projects/"+namespace
        headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close", "Content-Type": "application/merge-patch+json"}
        body = {
            "metadata": {
                "labels": label

            }
        }
    
    try:
        answer = requests.patch(request_url, headers=headers, json=body, verify=False, timeout=5)
    except ConnectTimeout:
        logger.error(f'Connection timeout. Cannot connect to {url_api}')
        answer = f'Cannot connect to {url_api}'
    except Timeout:
        try:
            answer = requests.patch(request_url, headers=headers, json=body, verify=False, timeout=10)
        except ConnectTimeout:
            logger.error(f'Connection timeout. Cannot connect to {url_api}')
            answer = f'Cannot connect to {url_api}'
        except Timeout:
            logger.error(f'Timeout labeling micro {micro} on namespace {namespace}')
            answer = f'Timeout labeling micro {micro} on namespace {namespace}'
    
    return answer


async def set_namespace_micros_label_api(functional_environment, cluster, namespaces_list, labels, microskind, action="add", regionparam=None, ldap_user=None):
    """
    Asynchronously sets or deletes labels for namespaces and their associated micros in a specified cluster and functional environment.
    Args:
        functional_environment (str): The functional environment to target (e.g., "dev", "prod").
        cluster (str): The name of the cluster to operate on.
        namespaces_list (list): A list of namespaces to process.
        labels (dict): A dictionary of labels to add or delete.
        microskind (str): The type of micros to filter and process.
        action (str, optional): The action to perform, either "add" or "delete". Defaults to "add".
        regionparam (str, optional): A specific region to target. If not provided, all regions in the cluster will be processed.
        ldap_user (str, optional): The LDAP user making the request. Defaults to None.
    Returns:
        dict: A dictionary containing the status of label operations with the key "labels" mapping to a list of statuses.
    Raises:
        Exception: If there are issues retrieving cluster information or processing labels.
    """
    if ldap_user is None:
        ldap_user = "no user info"

    label_list_status = []
    trace_list_dic = []
    status = 200

    clusters = await client.get_resource(resource="clusters", functional_environment=functional_environment, cluster=None)
    regionlist = [regionparam] if regionparam else list(clusters[cluster].keys())

    for region in regionlist:
        url = client.clusters[functional_environment][cluster][region]["url"]
        token = client.clusters[functional_environment][cluster][region]["token"]
        region_data_list = []

        for namespace in namespaces_list:
            micros = await get_micros(functional_environment=functional_environment, cluster=cluster, region=region, namespace=namespace, microskind=microskind)
            labelstatus, trace_list = await process_micros_namespaces(url=url, token=token, namespace=namespace, region=region, cluster=cluster, micros=micros, labels=labels, action=action, microskind=microskind)
            label_list_status.extend(labelstatus)
            region_data_list.extend(trace_list)

            max_status = max((item.get("Response Code", 200) for item in labelstatus), default=200)
            if max_status != 200:
                status = max_status
        region_list_dic = {"region": region, "data":region_data_list}
        trace_list_dic.append(region_list_dic)
        
    trace_dic = {
            "environment": functional_environment,
            "ldap": ldap_user, 
            "cluster": cluster,
            "namespace": namespace,
            "application": "SetLabels",
            "operation": action,
            "http_status": str(status),
            "detail_text": microskind + " " + str(labels),
            "openshift_detail": trace_list_dic
    }
    await send_trace_to_historical_trace(trace_dic)

    return {"labels": label_list_status}

async def process_micros_namespaces(url, token, namespace, region, cluster, micros, labels, action, microskind=None):
    """
    Asynchronously processes a list of microservices to set or delete labels.
    Args:
        url (str): The base URL of the API server.
        token (str): The authentication token for the API server.
        namespace (str): The namespace of the microservices.
        region (str): The region where the cluster is located.
        cluster (str): The name of the cluster.
        micros (list): A list of dictionaries representing the microservices.
        microkind (str, optional): The kind of microservices to label (e.g., 'deployments', 'deploymentconfigs').
        labels (dict): A dictionary of labels to be set or deleted.
        action (str): The action to perform, either 'set' or 'delete'.
        ldap_user (str, optional): The LDAP user making the request. Defaults to None.
    Returns:
        list: A list of dictionaries containing the status of label operations for each microservice.
    Each dictionary in the returned list contains:
        - project (str): The namespace of the microservice.
        - region (str): The region where the cluster is located.
        - cluster (str): The name of the cluster.
        - micro (str): The name of the microservice.
        - kind (str): The kind of the microservice (e.g., 'deployments', 'deploymentconfigs', 'both').
        - labels (dict): The labels that were set or deleted.
        - action (str): The action performed ('set' or 'delete').
        - Response Code (int, optional): The HTTP response code from the API server.
        - Reason (str, optional): The error message if the label operation failed.
        - Response (str, optional): A message if the microservice could not be labeled.
    """
    label_list_status = []
    trace_list_dic = []
    if microskind is None or microskind == "both":
        dynamic_microkind = True
    else:
        kind = microskind
        dynamic_microkind = False
    
    for micro in micros:
        if dynamic_microkind:
            kind = micro["kind"]
        match kind:
            case "deployments":
                apigroup = "apps/v1"
                endpoint = "deployments"
            case _:
                apigroup = "apps.openshift.io/v1"
                endpoint = "deploymentconfigs"

        labelstatus = {
            "project": namespace,
            "region": region,
            "cluster": cluster,
            "micro": micro["metadata"]["name"],
            "kind": micro["kind"],
            "labels": labels,
            "action": action
        }
        trace_dic = {
            "microservice": micro["metadata"]["name"],
            "api_response": 200
        }
        answer = oc_patch(url_api=url, apigroup=apigroup, endpoint=endpoint, token=token, namespace=namespace, micro=micro["metadata"]["name"], label=labels, action=action)
        if type(answer) == requests.models.Response:
            labelstatus["Response Code"] = answer.status_code
            if answer.status_code != 200:
                logger.error(f'Label could not be set on project {namespace} of {cluster}-{region} for {micro["kind"]} {micro["metadata"]["name"]}. Error message: {answer.json()["message"]}')
                labelstatus["Reason"] = answer.json()["message"]
                trace_dic["api_response"] = answer.status_code
            else:
                logger.debug(f'Label set on project {namespace} of {cluster}-{region} for {micro["kind"]} {micro["metadata"]["name"]}.')
        else:
            labelstatus["Response"] = f'Micro could not be labeled: {answer}'
            trace_dic["api_response"] = 500
        
        trace_list_dic.append(trace_dic)
        label_list_status.append(labelstatus)
    return label_list_status, trace_list_dic


async def get_micros(functional_environment, cluster, region, namespace, microskind):
    """
    Asynchronously retrieves microservice objects from a specified namespace based on the provided kind.

    Args:
        functional_environment (str): The functional environment to query.
        cluster (str): The cluster to query.
        region (str): The region to query.
        namespace (str): The namespace to query.
        microskind (str): The kind of microservice objects to retrieve. 
                          Can be "deployments", "deploymentconfigs", or "both".

    Returns:
        list: A list of microservice objects with an added "kind" key indicating their type.

    Raises:
        ValueError: If an unsupported microskind is provided.
    """
    match microskind:
        case "deployments":
            micros = await get_namespace_objects(functional_environment, cluster, region, namespace, "deployments")
            for item in micros:
                item["kind"] = "deployments"
        case "deploymentconfigs":
            micros = await get_namespace_objects(functional_environment, cluster, region, namespace, "deploymentconfigs")
            for item in micros:
                item["kind"] = "deploymentconfigs"
        case "both":
            deployments = await get_namespace_objects(functional_environment, cluster, region, namespace, "deployments")
            deploymentconfigs = await get_namespace_objects(functional_environment, cluster, region, namespace, "deploymentconfigs")
            for item in deployments:
                item["kind"] = "deployments"
            for item in deploymentconfigs:
                item["kind"] = "deploymentconfigs"
            micros = deployments + deploymentconfigs
    return micros

async def process_micros(url, token, namespace, region, cluster, micros, labels, action, microskind=None):
    """
    Asynchronously processes a list of microservices to set or delete labels.
    Args:
        url (str): The base URL of the API server.
        token (str): The authentication token for the API server.
        namespace (str): The namespace of the microservices.
        region (str): The region where the cluster is located.
        cluster (str): The name of the cluster.
        micros (list): A list of microservices.
        microkind (str, optional): The kind of microservices to label (e.g., 'deployments', 'deploymentconfigs').
        labels (dict): A dictionary of labels to be set or deleted.
        action (str): The action to perform, either 'set' or 'delete'.
    Returns:
        list: A list of dictionaries containing the status of label operations for each microservice.
    Each dictionary in the returned list contains:
        - project (str): The namespace of the microservice.
        - region (str): The region where the cluster is located.
        - cluster (str): The name of the cluster.
        - micro (str): The name of the microservice.
        - kind (str): The kind of the microservice (e.g., 'deployments', 'deploymentconfigs').
        - labels (dict): The labels that were set or deleted.
        - action (str): The action performed ('set' or 'delete').
        - Response Code (int, optional): The HTTP response code from the API server.
        - Reason (str, optional): The error message if the label operation failed.
        - Response (str, optional): A message if the microservice could not be labeled.
    """
    label_list_status = []
    trace_list_dic = []
    if microskind is None:
        dynamic_microkind = True
    else:
        kind = microskind
        dynamic_microkind = False
    
    for micro in micros:
        if dynamic_microkind:
            kind = micro["kind"]
        match kind:
            case "deployments":
                apigroup = "apps/v1"
                endpoint = "deployments"
            case _:
                apigroup = "apps.openshift.io/v1"
                endpoint = "deploymentconfigs"

        labelstatus = {
            "project": namespace,
            "region": region,
            "cluster": cluster,
            "micro": micro,
            "kind": kind,
            "labels": labels,
            "action": action
        }
        trace_dic = {
            "microservice": micro,
            "api_response": 200
        }
        answer = oc_patch(url_api=url, apigroup=apigroup, endpoint=endpoint, token=token, namespace=namespace, micro=micro, label=labels, action=action)
        if type(answer) == requests.models.Response:
            labelstatus["Response Code"] = answer.status_code
            if answer.status_code != 200:
                logger.error(f'Label could not be set on project {namespace} of {cluster}-{region} for {kind} {micro}. Error message: {answer.json()["message"]}')
                labelstatus["Reason"] = answer.json()["message"]
                trace_dic["api_response"] = answer.status_code
            else:
                logger.debug(f'Label set on project {namespace} of {cluster}-{region} for {kind} {micro}.')
        else:
            labelstatus["Response"] = f'Micro could not be labeled: {answer}'
            trace_dic["api_response"] = 500
        trace_list_dic.append(trace_dic)
        label_list_status.append(labelstatus)
    return label_list_status, trace_list_dic

async def set_micros_label_api(functional_environment,cluster,namespace,microslist,labels,microskind,action="add",regionparam=None,ldap_user=None):
    """
    Set labels for a list of microservices in a specified namespace and cluster.
    Args:
        functional_environment (str): The functional environment to use.
        cluster (str): The cluster name.
        namespace (str): The namespace where the microservices are located.
        microslist (list): A list of microservices to label.
        labels (dict): A dictionary of labels to set.
        microskind (str): The kind of microservices (e.g., "deployments", "deploymentconfigs").
        action (str, optional): The action to perform on the labels ("add" or "delete"). Defaults to "add".
        regionparam (str, optional): A specific region to target. If None, all regions in the cluster will be targeted. Defaults to None. You can set several labels at the same time. ie:
            {
                "critical": "true",
                "domain": "Devops"
            }
            Values could be empty for deleting the label/s. ie:
                {
                "critical": "",
                "domain": ""
            }   
    Returns:
        dict: A dictionary containing the status of label operations for each microservice.
    """

    label_list_status = []
    trace_list_dic = []

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)
    
    if regionparam != None:
        regionlist = [regionparam]
    else:
        regionlist = list(clusters[cluster].keys())

    if ldap_user is None:
        ldap_user = "no user info"

    status = 200
    for region in regionlist:

        url = client.clusters[functional_environment][cluster][region]["url"]
        token =  client.clusters[functional_environment][cluster][region]["token"]
        region_data_list = []

        for micro in microslist:
            labelstatus, trace_list= await process_micros(url=url, token=token, namespace=namespace, region=region, cluster=cluster, micros=[micro], labels=labels, action=action, microskind=microskind)
            label_list_status.extend(labelstatus)
            region_data_list.extend(trace_list)

            max_status = max((item.get("Response Code", 200) for item in labelstatus), default=200)
            if max_status != 200:
                status = max_status

        region_list_dic = {"region": region, "data":region_data_list}
        trace_list_dic.append(region_list_dic)
    trace_dic = {
            "environment": functional_environment,
            "ldap": ldap_user, # no se como sacarlo en este momento
            "cluster": cluster,
            "namespace": namespace,
            "application": "SetLabels",
            "operation": action,
            "http_status": str(status),
            "detail_text": microskind + " " + str(labels),
            "openshift_detail": trace_list_dic
    }
    await send_trace_to_historical_trace(trace_dic)

    return {"labels": label_list_status}

