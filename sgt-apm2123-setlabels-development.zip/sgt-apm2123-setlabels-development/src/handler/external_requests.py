"""
This module handles external requests for the microservice.
"""
from shuttlelib.utils.logger import logger
from fastapi import APIRouter
from fastapi.responses import JSONResponse
import urllib3
from src.services.setLabels import set_micros_label_api, set_namespace_micros_label_api
from src.services.label_logics import set_label_update_db_api, fix_active_labels_api, check_active_labels_api
from docs.openapi.microsPOST import MicrosRequest, MicrosResponse
from docs.openapi.namespacesmicrosPOST import NamespacesmicrosRequest, NamespacesmicrosResponse 
from docs.openapi.namespace_selector import NamespaceSelector




urllib3.disable_warnings()

set_labels = APIRouter(tags=["v1"], prefix="/api/v1/label")

@set_labels.post("/micros", response_model=MicrosResponse)
async def set_micros_label(target: MicrosRequest):
    """
    Asynchronously routes the main request to set micros labels.

    Args:
        target (MicrosRequest): The model containing the necessary parameters for setting micros labels.

    Returns:
       
        The result of the set_micros_label_api function call.
    """
    logger.info("Calling to micros set labels")
    result = await set_micros_label_api(functional_environment=target.functionalEnvironment,cluster=target.cluster,namespace=target.namespace,microslist=target.microslist,microskind=target.microskind,labels=target.labels,action=target.action,regionparam=target.region, ldap_user=target.ldap_user)
    return  JSONResponse(content={
                                    "result": result
                                }, status_code=200)
@set_labels.post("/namespacesmicros", response_model=NamespacesmicrosResponse)
async def set_namespace_micros_label(target: NamespacesmicrosRequest):
    """
    Asynchronously routes the main request to set namespace microservice labels.

    Args:
        target (NamespacesmicrosRequest): The model containing the necessary parameters for setting the namespace microservice labels.

    Returns:
        The result of the set_namespace_micros_label_api function call.
    """
    logger.info("Calling to namespace set labels")
    result = await set_namespace_micros_label_api(functional_environment=target.functionalEnvironment,cluster=target.cluster,namespaces_list=target.namespacesList,microskind=target.microskind,labels=target.labels,action=target.action,regionparam=target.region, ldap_user=target.ldap_user)
    return  JSONResponse(content={
                                "result": result
                            }, status_code=200)

@set_labels.post("/setlabel_update_DB", response_description="JSON")
async def set_label_update_db(target: NamespaceSelector):
    """
    Asynchronously updates labels in the database for a given namespace.
    Args:
        target (NamespaceSelector): An object containing the label dictionary, cluster, namespace, and region information.
    Returns:
        JSONResponse: A JSON response containing the result of the label update operation with HTTP status code 200.
    Logs:
        Logs an info message indicating the start of the label update process.
    """

    logger.info("Calling to set_label_update_db_api")
    result = await set_label_update_db_api(label_dict=target.label_dict, cluster=target.cluster,namespace=target.namespace,region=target.region)
    return  JSONResponse(content={
                                    "result": result
                                }, status_code=200)

@set_labels.post("/fix_active_labels", response_description="JSON")
async def fix_active_labels(target: NamespaceSelector):
    """
    Asynchronously routes the main request to check the value of the label active and fix it if it's wrong.

    Args:
        target (NamespaceSelector): The model containing the necessary parameters for setting the namespace microservice labels.

    Returns:
        The result of the fix_active_labels_api function call.
    """
    logger.info("Calling fix_active_labels_api")
    result = await fix_active_labels_api(cluster=target.cluster,namespace=target.namespace,region=target.region)
    return  JSONResponse(content={
                                    "result": result
                                }, status_code=200)

@set_labels.post("/check_active_labels", response_description="JSON")
async def check_active_labels(target: NamespaceSelector):
    """
    Asynchronously routes the main request to check the value of the label active and fix it if it's wrong.

    Args:
        target (NamespaceSelector): The model containing the necessary parameters for setting the namespace microservice labels.

    Returns:
        The result of the check_active_labels_api function call.
    """
    logger.info("Calling check_active_labels")
    result = await check_active_labels_api(cluster=target.cluster,namespace=target.namespace,region=target.region)
    return  JSONResponse(content={
                                    "result": result
                                }, status_code=200)


