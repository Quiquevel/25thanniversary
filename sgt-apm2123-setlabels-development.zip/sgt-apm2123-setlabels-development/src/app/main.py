"""
This module contains the main FastAPI application for the microservice.
"""
from fastapi import FastAPI, responses
from src.handler import external_requests
from darwin_composer.DarwinComposer import DarwinComposer  
from src.app.config.composer_config import config as composer_config
from src.resources.routers import routers


app = FastAPI(
                docs_url="/api/v1/docs",
                redoc_url= "/api/v1/redocs",
                title="SET LABELS",
                version="1.0",
                openapi_url="/api/v1/openapi.json",
                contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"},
              )

DarwinComposer(app, config=composer_config, routers=routers)
