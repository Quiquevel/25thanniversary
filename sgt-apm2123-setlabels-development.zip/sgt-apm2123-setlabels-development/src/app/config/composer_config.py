"""
This module contains darwin composer configration.
"""

from version import __version__
from ..config import global_config

description = """

### SUMMARY
Microservice for setting labels on deployments or namespace

### ENDPOINTS
* **micros:** Change labels (add or delete) on a namespace given for a micro or list of micros (deployments or deploymentconfigs).
* **namespacesmicros** Change labels (add or delete) on a namespace list given for every micro (deployments, deploymentconfigs or both).


### PARAMETERS
* **functionalEnvironment**: dev, pre, pro
* **cluster**: ohe (only for dev & pre), bks (only for dev & pre), probks, dmzbbks, azure, prodarwin, dmzbdarwin, confluent, proohe, dmzbohe
* **region (optional)**: bo1, bo2, weu1, weu2
* **namespace/namespacesList**: namespace or namespaces list to add or delete label/ss (depending on the endpoint)
* **microslist**: List of microservices (only for micros endpoint). This field should be according the microskind for labeling them properly
* **action**: add or delete label/s. 
* **labels**: Label to set in key:value dictionary format (value must be a string). You can set several labels at the same time. ie:
            {
                "critical": "true",
                "domain": "Devops"
            }
    
    Values could be empty for deleting the label/s. ie:
                {
                "critical": "",
                "domain": ""
            }

### REPO 
* [FASTAPI-BASE](https://github.com/santander-group-sds-gln/sgt-apm2123-setlabels)
"""


config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "Set Labels",
          "description": description,
          "contact": {
               "name": "Juan Fernandez Diaz",
               "url": "juan.fernandezdiaz@gruposantander.com"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
