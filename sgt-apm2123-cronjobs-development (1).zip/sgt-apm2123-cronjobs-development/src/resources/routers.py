from src.handler.external_requests import cronjobs_operative
from src.handler.external_requests import jobs_operative
from src.handler.external_requests import cronjobs_backups_pvc_operative, cronjobs_backups_mongo_operative, cronjobs_backups_all_operative
from src.handler.external_requests import cronjobs_restores_operative 
from src.handler.external_requests import cronjobs_searchpattern_operative, audit_operative, authorization
from src.handler.external_requests import audit_operative
from src.handler.external_requests import authorization
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(cronjobs_operative),
    RouteClass(jobs_operative),
    RouteClass(cronjobs_backups_pvc_operative),
    RouteClass(cronjobs_backups_mongo_operative),
    RouteClass(cronjobs_backups_all_operative),
    RouteClass(cronjobs_restores_operative),
    RouteClass(cronjobs_searchpattern_operative),
    RouteClass(audit_operative),
    RouteClass(authorization),
]
