"""
This module contains the implementation of the FastAPI resources for the helloWorld and helloMoon endpoints.
"""
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from src.services.hello_world_business_logic import hello_world_message, hello_world_sum
from src.services.hello_moon_business_logic import hello_moon_message, hello_moon_sum
from docs.openapi.hellomoonGET import  MoonResponse
from docs.openapi.helloworldGET import HelloResponse
from docs.openapi.helloPOST import SumRequest, SumResponse

HelloWorldRouter = APIRouter()
HelloMoonRouter = APIRouter()

@HelloWorldRouter.post("/v1/regards/hello_world",response_model=SumResponse)
async def sum_numbers(Sumrequest:SumRequest, request:Request):
    """
    Resource class for the helloWorld endpoint.
    POST method for the helloWorld endpoint.
    """
    request.app.logger.info("Calling to Hello World Sum Service")
    result = hello_world_sum(Sumrequest.number_a, Sumrequest.number_b)

    return JSONResponse(content={
                                    "operation": "sum",
                                    "number_a": Sumrequest.number_a,
                                    "number_b": Sumrequest.number_b,
                                    "result": result
                                }, status_code=200)

@HelloWorldRouter.get("/v1/regards/hello_world",response_model=HelloResponse)
async def get_message(request: Request):
    """
    GET method for the helloWorld endpoint.
    """

    message = hello_world_message(request)
    request.app.logger.info("In hello_world get method")
    return JSONResponse(content={
                                    "status": "OK", 
                                    "message": message
                                }, status_code=200)

@HelloMoonRouter.post("/v1/regards/hello_moon",response_model=SumResponse)
async def sum_numbers(Sumrequest:SumRequest, request: Request):
    """
    Resource class for the helloMoon endpoint.
    POST method for the helloMoon endpoint.
    """
    request.app.logger.info("Calling to Hello Moon Sum Service")
    result = hello_moon_sum(Sumrequest.number_a, Sumrequest.number_b)

    return JSONResponse(content={
                                    "operation": "sum",
                                    "number_a": Sumrequest.number_a,
                                    "number_b": Sumrequest.number_b,
                                    "result": result
                                }, status_code=200)

@HelloMoonRouter.get("/v1/regards/hello_moon",response_model=MoonResponse)
async def get_message(request: Request):
    """
    GET method for the helloMoon endpoint.
    """
    message = hello_moon_message(request)
    request.app.logger.info("In hello_moon get method")
    return JSONResponse(content={
                                    "status": "OK",
                                    "message": message
                                }, status_code=200)
