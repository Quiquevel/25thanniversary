"""
This module contains the main FastAPI application for the microservice.
"""
from fastapi import FastAPI
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers
from src.app.config.composer_config import config as composer_config

app = FastAPI()

description = """
LISTs & ACTIONs & BACKUPs CRONJOB and JOBs

### SUMMARY
Microservice for list and operate with cronjobs(start/stop/image/schedule/jobhistory and backups) and jobs reports(mail)

### ENDPOINTS
* **/cronjobsList:** List cronjobs by environment, cluster, region, namespaces, etc
* **/cronjobsAction:** Actions (start, stop, image, schedule and jobhistory) of cronjobs
* **/cronjobsAudit:** Search users in start/stop/imagen/schedule and jobhistory cronjobs action
* **/jobsList:** List jobs and the execution data by environment, cluster, region, namespaces, etc
* **/jobsAudit:** Search jobs execution data
* **/testjobscron:** Test the jobs report execution by email(defined by cronjob element in OCP)
* **/cronjobsbackup:** Lauch a backup of cronjobs
* **/cronjobslistbackup:** List backups of cronjobs
* **/cronjobsrestore:** Lauch a restore of cronjobs
* **/testbackupscron:** Test the backups proccess(defined by cronjob element in OCP)
* **/authorizationuser:** Validate user UID - Authorization

### PARAMETERS
* **Environment:** dev, pre, pro
* **cluster:** bks, ocp05azure, azure, dmzbazure, prodarwin, dmzbdarwin, confluent, probks, dmzbbks, dmz2bmov, ..
* **region:** bo1, bo2, weu1, weu2 or both
* **namespace:** name of the project PaaS to list or apply an action
* **cronjobs:** name or list of cronjobs to operate to apply an action. Opcion "All" is supported.
* **action:** action (start, stop, image, schedule or jobhistory) to apply to the cronjobs
* **paramAction::** depend of "action" param.\n
    In **start** or **stop** case, this param is not necesary\n
    In **image** case is necesary to indicate all data (FQN) of cronjob image.\n
    Example: registry.global.ccc.srvb.bo.paas.cloudcenter.corp/shuttle-san/shuttle-backup-healthcheck:202310111323\n
    In **schedule** case is necesary to indicate the programme execution\n
    Example: 0 2 * * 1-5, 00 7 * * *, etc
    In **jobhistory** case is necesary to indicate the value of parameter to update successfulJobsHistoryLimit y failedJobsHistoryLimit
    Recommended: 1 (this causes both parameters to be set to 1)
* **ldap:** uid devops team to lauch enpoints

### DETAILS
* **functional_environment/cluster/region:**\n
    "dev":\n
        "bks": {"bo1"}
        "ocp05azure": {"weu1"}
        "azure": {"weu1"}
    "pre":\n
        "bks": {"bo1","bo2"}
        "ocp05azure": {"weu1","weu2"}
        "azure": {"weu1","weu2"}
    "pro":\n
        "prodarwin": {"bo1","bo2"}
        "dmzbdarwin": {"bo1","bo2"}
        "azure": {"weu1","weu2"}
        "dmzbazure": {"weu1","weu2"}
        "ocp05azure": {"weu1","weu2"}
        "confluent": {"bo1","bo2"}
        "probks": {"bo1","bo2"}
        "dmzbbks": {"bo1","bo2"}
        "dmz2bmov": {"bo1","bo2"}

### REPO 
* [shuttle-cronjob](https://github.com/santander-group-sds-gln/sgt-apm2123-shuttle-cronjobs)
"""

app = FastAPI(
                docs_url="/docs",
                title="cronjobs",
                description=description,version="1.0",
                openapi_url="/api/v1/openapi.json",
                contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"}
              )

DarwinComposer(app, config=composer_config, routers=routers)