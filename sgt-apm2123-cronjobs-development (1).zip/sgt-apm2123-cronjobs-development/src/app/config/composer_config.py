from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "sgt-apm2123-cronjobs",
          "description": "list and operate with cronjobs(start/stop/image/schedule/jobhistory and backups) and jobs reports(mail)",
          "contact": {
               "name": "SRECoEDevSecOps",
               "url": "SRECoEDevSecOps@gruposantander.com"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
