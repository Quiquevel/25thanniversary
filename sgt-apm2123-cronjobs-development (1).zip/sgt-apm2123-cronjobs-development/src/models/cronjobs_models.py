
from fastapi import HTTPException
from pydantic import BaseModel, validator
from src.services.clientunique import getEnvironmentsClustersRegionsList
from typing import Optional, Union
from os import getenv

environmentList, clusterList, regionList = getEnvironmentsClustersRegionsList()

def envToList(envVar):
    return [item.strip() for item in envVar.split(",")] if envVar else []

CRONJOB_ACTIONS = envToList(getenv("CRONJOB_ACTIONS", "stop,start,image,schedule,history,environment,patch"))
JOB_STATES = envToList(getenv("JOB_STATES", "completed,failed,inprogress,failed+hung,hung,deleted,all"))
AUDIT_TYPES = envToList(getenv("AUDIT_TYPES", "cronjobs,jobs,backups,restores"))

    
class cronjobsListModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: Optional[str] = None
    namespace: Optional[str] = None
    cronjobs: Optional[str] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v

    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v
    
class cronjobsActionModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: str
    namespace: str
    cronjobs: str
    action: str
    paramAction: Optional[Union[str, dict]] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v

    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

    @validator("action")
    def validate_action(cls, v):
        if v not in CRONJOB_ACTIONS:
            raise HTTPException(status_code=400, detail=f"'{v}' is not valid. Valid actions: {CRONJOB_ACTIONS}")
        return v    


class cronjobsDownloadModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: str
    namespace: str
    cronjobs: Optional[str] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

class jobsListModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: Optional[str] = None
    namespace: Optional[str] = None
    state: Optional[str] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

    @validator("state")
    def validate_state(cls, v):
        if v is not None and v not in JOB_STATES:
            raise HTTPException(status_code=400, detail=f"'{v}' is not valid. Valid states: {JOB_STATES}")
        return v

class jobsDeleteModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: Optional[str] = None
    namespace: Optional[str] = None
    jobs: Optional[str] = None
    state: Optional[str] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v

    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

    @validator("state")
    def validate_state(cls, v):
        if v is not None and v not in JOB_STATES:
            raise HTTPException(status_code=400, detail=f"'{v}' is not valid. Valid states: {JOB_STATES}")
        return v

class cronjobsBackupListModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: Optional[str] = None
    namespace: Optional[str] = None
    cronjobs: Optional[str] = None
    date: Optional[str] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

class cronjobsBackupModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: Optional[str] = None
    namespace: Optional[str] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

class cronjobsModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: str
    namespace: str
    date: str
    cronjobs: Optional[str] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

class AuditBaseModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: Optional[str] = None
    namespace: Optional[str] = None
    date: Optional[str] = None
    user: Optional[str] = None
    type: str
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v
    
    @validator("type")
    def validate_type(cls, v):
        if v not in AUDIT_TYPES:
            raise HTTPException(status_code=400, detail=f"'{v}' is not valid. Valid types: {AUDIT_TYPES}")
        return v

class AuditOLDBaseModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: Optional[str] = None
    namespace: Optional[str] = None
    date: Optional[str] = None
    user: Optional[str] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

class jobsAuditModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: Optional[str] = None
    namespace: Optional[str] = None
    cronjobs: Optional[str] = None
    date: Optional[str] = None
    state: Optional[str] = None
    user: Optional[str] = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

    @validator("state")
    def validate_state(cls, v):
        if v is not None and v not in JOB_STATES:
            raise HTTPException(status_code=400, detail=f"'{v}' is not valid. Valid states: {JOB_STATES}")
        return v

class cronjobsSearchpattern(cronjobsListModel):
    pattern: str

class cronjobsAuthorizationModel(BaseModel):
    ldap: str


# AÑADIR al final del archivo, después de cronjobsAuthorizationModel
# Modelado para BCKs y RESTOREs de CRONJOBS en MONGO
'''
class cronjobsRestoreMongoModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: str
    namespace: str
    date: str
    cronjobs: str = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

class cronjobsBackupMongoModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: str = None
    namespace: str = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

class cronjobsBackupListMongoModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: str = None
    namespace: str = None
    cronjobs: str = None
    date: str
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

class cronjobsBackupDownloadMongoModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    region: str
    namespace: str
    cronjobName: str
    date: str = None
    backupId: str = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for cluster")
        return v
    
    @validator("region")
    def validate_region(cls, v):
        if not any(x == v for x in regionList):
            raise HTTPException(status_code = 400, detail=f"{v} value is not valid for region")
        return v

'''