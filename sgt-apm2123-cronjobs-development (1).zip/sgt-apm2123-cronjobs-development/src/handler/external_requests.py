"""
This module handles external requests for the microservice.
"""
from fastapi import APIRouter, Depends
from fastapi.security import HTTPBearer
from src.services.cronjobs import cronjobsListTreatment, cronjobsActionTreatment, cronjobsDownloadTreatment, cronjobsAuditTreatment
from src.services.jobs import jobsListTreatment, jobsDeleteTreatment, jobsAuditTreatment, testJobsCronTreatment
from src.services.backups import cronjobsBackupPvcTreatment, cronjobsBackupListPvcTreatment, cronjobsBackupDownloadPvcTreatment, cronjobsBackupRetentionPvcTreatment, cronjobsBackupsAuditPvcTreatment, testBackupsCronTreatment
from src.services.backups import cronjobsBackupMongoTreatment, cronjobsBackupListMongoTreatment, cronjobsBackupDownloadMongoTreatment
from src.services.restores import cronjobsRestorePvcTreatment, cronjobsRestoreMongoTreatment, cronjobsRestoresAuditPvTreatment
from src.services.searchpattern import cronjobsSearchPatternTreatment
from src.services.audit import AuditAllPvcTreatment, AuditAllMongoTreatment
from src.services.authorization import authorizationTreatment
from src.models.cronjobs_models import cronjobsModel
from src.models.cronjobs_models import cronjobsListModel, cronjobsActionModel, cronjobsDownloadModel
from src.models.cronjobs_models import jobsListModel, jobsDeleteModel, jobsAuditModel
from src.models.cronjobs_models import cronjobsBackupModel, cronjobsBackupListModel
from src.models.cronjobs_models import AuditOLDBaseModel
from src.models.cronjobs_models import AuditBaseModel
from src.models.cronjobs_models import cronjobsSearchpattern
from src.models.cronjobs_models import cronjobsAuthorizationModel
import urllib3

urllib3.disable_warnings()
bearer = HTTPBearer()

#constant
API_CRONJOBS = "/api/v1/cronjob"

cronjobs_operative = APIRouter(tags=["CRONJOBs operative(List, Actions, Audits, View, Download, etc)"], prefix=API_CRONJOBS)
jobs_operative = APIRouter(tags=["JOBs operative(List, Reports, Audits, etc)"], prefix=API_CRONJOBS)
cronjobs_backups_pvc_operative = APIRouter(tags=["CRONJOBs BACKUPs PVC operative(BCKs, List, View, Download, Audits, etc)"], prefix=API_CRONJOBS)
cronjobs_backups_mongo_operative = APIRouter(tags=["CRONJOBs BACKUPs MONGO operative(BCKs, List, View, Download, Audits, etc)"], prefix=API_CRONJOBS)
cronjobs_backups_all_operative = APIRouter(tags=["CRONJOBs BACKUPs PVC y MONGO operative(BCKs)"], prefix=API_CRONJOBS)
cronjobs_restores_operative = APIRouter(tags=["CRONJOBs RESTOREs PVC y MONGO operative(RESTORE, Audits, etc)"], prefix=API_CRONJOBS)
cronjobs_searchpattern_operative = APIRouter(tags=["CRONJOBs SEARCHPATTERN operative(search, etc)"], prefix=API_CRONJOBS)
audit_operative = APIRouter(tags=["CRONJOBs AUDIT operative(search, etc)"], prefix=API_CRONJOBS)
authorization = APIRouter(tags=["CRONJOBs AUTHORIZATION"], prefix=API_CRONJOBS)


@cronjobs_operative.post("/cronjobslist", tags=["CRONJOBs operative(List, Actions, Audits, View, Download, etc)"], description="LIST CRONJOBs IN SHUTTLE", response_description="JSON", status_code=200)
async def get_cronjobs_list(target: cronjobsListModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously cronjobs list.

    Parameters:
    - target: The target cronjobsListModel object containing the functionalEnvironment, cluster, region, namespace, cronjobs and user to retrieve data for.

    Returns:
    - The retrieved cronjobs data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsListTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, cronjobs=target.cronjobs)

@cronjobs_operative.post("/cronjobsaction", tags=["CRONJOBs operative(List, Actions, Audits, View, Download, etc)"], description="ACTIONs (START/STOP/IMAGE/SCHEDULE/HISTORY) CRONJOBs IN SHUTTLE", response_description="JSON", status_code=200)
async def execute_cronjobs_action(target: cronjobsActionModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously cronjobs action.

    Parameters:
    - target: The target cronjobsActionModel object containing the functionalEnvironment, cluster, region, namespace, cronjobs, action, param action and user to execute action for.

    Returns:
    - The retrieved cronjobs action data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsActionTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, region=target.region, namespace=target.namespace, action=target.action, auth=Authorization, ldap=target.ldap, cronjobs=target.cronjobs, paramAction=target.paramAction)

@cronjobs_operative.post("/cronjobsdownload", tags=["CRONJOBs operative(List, Actions, Audits, View, Download, etc)"], description="VIEW & DOWNLOAD CRONJOBS IN SHUTTLE", response_description="JSON", status_code=200)
async def get_cronjobs_download(target: cronjobsDownloadModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously cronjobs download.

    Parameters:
    - target: The target cronjobsDownloadModel object containing the functionalEnvironment, cluster, region, namespace, cronjob and user to retrieve data for.

    Returns:
    - The retrieved cronjobs data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsDownloadTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, cronjobs=target.cronjobs)

@cronjobs_operative.post("/cronjobsaudit", tags=["CRONJOBs operative(List, Actions, Audits, View, Download, etc)"], description="SEARCH DATE&USERs IN START/STOP/IMAGE/SCHEDULE/HISTORY CRONJOBs ACTIONs IN SHUTTLE", response_description="JSON", status_code=200)
async def get_cronjobs_audit(target: AuditOLDBaseModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously cronjobs audit.

    Parameters:
    - target: The target AuditBaseModel object containing the functionalEnvironment, cluster, namespace, date and user to retrive audit for.

    Returns:
    - The retrieved cronjobs audit data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsAuditTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, date=target.date, user=target.user)




@jobs_operative.post("/jobslist", tags=["JOBs operative(List, Reports, Audits, etc)"], description="LIST JOBs IN SEVERAL STATEs IN SHUTTLE", response_description="JSON", status_code=200)
async def get_jobs_list(target: jobsListModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously jobs list.

    Parameters:
    - target: The target jobsListModel object containing the functionalEnvironment, cluster, region, namespace, state and user to retrieve data for.

    Returns:
    - The retrieved jobs data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await jobsListTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, state=target.state, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace)

@jobs_operative.post("/jobsaudit", tags=["JOBs operative(List, Reports, Audits, etc)"], description="SEARCH JOBs IN CRONJOBS EXECUTIONs(REPORTs) IN SHUTTLE", response_description="JSON", status_code=200)
async def get_jobs_audit(target: jobsAuditModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously jobs audit.

    Parameters:
    - target: The target jobsAuditModel object containing the functionalEnvironment, cluster, region, namespace, state, date, user and cronjobs to retrive audit for.

    Returns:
    - The retrieved jobs audit data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await jobsAuditTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, cronjobs=target.cronjobs, date=target.date, state=target.state, user=target.user)

@jobs_operative.post("/jobsdelete", tags=["JOBs operative(List, Reports, Audits, etc)"], description="DELETE JOBs IN SHUTTLE", response_description="JSON", status_code=200)
async def execute_delete_jobs(target: jobsDeleteModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously delete jobs.

    Parameters:
    - target: The target jobsDeleteModel object containing the functionalEnvironment, cluster, region, namespace, jobs and user to delete jobs for.

    Returns:
    - The deletion results data.

    Raises:
    - Any exceptions that occur during the deletion process.
    """
    return await jobsDeleteTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, jobs=target.jobs, state=target.state)

@jobs_operative.post("/testreportjobscron", tags=["JOBs operative(List, Reports, Audits, etc)"], description="TEST CRONJOBS LIST JOBs (REPORT WITH MAIL NOTIFICATION) IN SHUTTLE", response_description="JSON", status_code=200)
async def test_cron_jobs(target: cronjobsAuthorizationModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously test cronjobs.

    Parameters:
    - target: The target cronjobsAuthorizationModel object containing the user to execute audit for.

    Returns:
    - http status code of the operation.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await testJobsCronTreatment(auth=Authorization, ldap=target.ldap)




@cronjobs_backups_pvc_operative.post("/cronjobsbackuptofile", tags=["CRONJOBs BACKUPs PVC operative(BCKs, List, View, Download, Audits, etc)"], description="BACKUP CRONJOBS IN SHUTTLE TO FILE", response_description="JSON", status_code=200)
async def execute_cronjobs_backup_pvc(target: cronjobsBackupModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously cronjobs backups to file.

    Parameters:
    - target: The target cronjobsBackupModel object containing the functionalEnvironment, cluster, region, namespace and user to execute backups for.

    Returns:
    - The retrieved jobs audit data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsBackupPvcTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace)

@cronjobs_backups_pvc_operative.post("/cronjobsbackuplistfile", tags=["CRONJOBs BACKUPs PVC operative(BCKs, List, View, Download, Audits, etc)"], description="LIST BACKUP CRONJOBS IN SHUTTLE FROM FILE", response_description="JSON", status_code=200)
async def get_cronjobs_backup_list_pvc(target: cronjobsBackupListModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously backups cronjobs list PVC.

    Parameters:
    - target: The target cronjobsBackupListModel object containing the functionalEnvironment, cluster, region, namespace, date and user to retrieve data for.


    Returns:
    - The retrieved backups cronjobs data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsBackupListPvcTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, cronjobs=target.cronjobs, date=target.date)

@cronjobs_backups_pvc_operative.post("/cronjobsbackupdownloadfile", tags=["CRONJOBs BACKUPs PVC operative(BCKs, List, View, Download, Audits, etc)"], description="VIEW & DOWNLOAD BACKUP CRONJOBS IN SHUTTLE FROM FILE", response_description="JSON", status_code=200)
async def get_cronjobs_backup_download_pvc(target: cronjobsModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously backups cronjobs download.

    Parameters:
    - target: The target cronjobsModel object containing the functionalEnvironment, cluster, region, namespace, cronjob, date and user to retrieve data for.


    Returns:
    - The retrieved backups cronjobs data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsBackupDownloadPvcTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, date=target.date, cronjobs=target.cronjobs)

@cronjobs_backups_pvc_operative.post("/cronjobsbackupaudit", tags=["CRONJOBs BACKUPs PVC operative(BCKs, List, View, Download, Audits, etc)"], description="SEARCH BACKUP EXECUTIONs CRONJOBS IN SHUTTLE FROM FILE", response_description="JSON", status_code=200)
async def get_backups_audit_pvc(target: AuditOLDBaseModel, Authorization: str=Depends(bearer)):    
    """
    Asynchronously backups audit to file.

    Parameters:
    - target: The target AuditBaseModel object containing the functionalEnvironment, cluster, namespace, date and user to retrive audit for.
     
    Returns:
    - The retrieved backups cronjobs audit data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsBackupsAuditPvcTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, date=target.date, user=target.user)

@cronjobs_backups_pvc_operative.post("/cronjobsbackupretention", tags=["CRONJOBs BACKUPs PVC operative(BCKs, List, View, Download, Audits, etc)"], description="EXECUTE BACKUP RETENTION PROCESS (MONTHLY CONSOLIDATION) IN SHUTTLE FROM FILE", response_description="JSON", status_code=200)
async def execute_backup_retention_pvc(target: cronjobsAuthorizationModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously execute backup retention process to file.

    Parameters:
    - target: The target cronjobsAuthorizationModel object containing the user to execute retention for.

    Returns:
    - The retention process results.

    Raises:
    - Any exceptions that occur during the retention process.
    """
    return await cronjobsBackupRetentionPvcTreatment(auth=Authorization, ldap=target.ldap)




@cronjobs_backups_mongo_operative.post("/cronjobsbackuptomongo", tags=["CRONJOBs BACKUPs MONGO operative(BCKs, List, View, Download, Audits, etc)"], description="BACKUP CRONJOBS IN SHUTTLE TO MONGO", response_description="JSON", status_code=200)
async def execute_cronjobs_backup_mongo(target: cronjobsBackupModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously cronjobs backups to mongo.

    Parameters:
    - target: The target cronjobsBackupModel object containing the functionalEnvironment, cluster, region, namespace and user to execute backups for.

    Returns:
    - The retrieved jobs audit data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsBackupMongoTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace)

@cronjobs_backups_mongo_operative.post("/cronjobsbackuplistmongo", tags=["CRONJOBs BACKUPs MONGO operative(BCKs, List, View, Download, Audits, etc)"], description="LIST BACKUP CRONJOBS IN SHUTTLE FROM MONGO", response_description="JSON", status_code=200)
async def get_cronjobs_backup_list_mongo(target: cronjobsBackupListModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously backups cronjobs list from mongo.

    Parameters:
    - target: The target cronjobsBackupListModel object containing the functionalEnvironment, cluster, region, namespace, date and user to retrieve data for.


    Returns:
    - The retrieved backups cronjobs data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsBackupListMongoTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, cronjobs=target.cronjobs, date=target.date)

@cronjobs_backups_mongo_operative.post("/cronjobsbackupdownloadmongo", tags=["CRONJOBs BACKUPs MONGO operative(BCKs, List, View, Download, Audits, etc)"], description="VIEW & DOWNLOAD BACKUP CRONJOBS IN SHUTTLE FROM MONGO", response_description="JSON", status_code=200)
async def get_cronjobs_backup_download_mongo(target: cronjobsModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously backups cronjobs download from mongo.

    Parameters:
    - target: The target cronjobsModel object containing the functionalEnvironment, cluster, region, namespace, cronjob, date and user to retrieve data for.


    Returns:
    - The retrieved backups cronjobs data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsBackupDownloadMongoTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, date=target.date, cronjobs=target.cronjobs)




@cronjobs_backups_all_operative.post("/testbackupscron", tags=["CRONJOBs BACKUPs PVC y MONGO operative(BCKs)"], description="TEST CRONJOBS BACKUPs CRONJOBs IN SHUTTLE TO FILE&MONGO", response_description="JSON", status_code=200)
async def test_cronjobs_backup_pvc_and_mongo(target: cronjobsBackupModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously test backups cronjobs.

    Parameters:
    - target: The target cronjobsBackupModel object containing functionalEnvironment, cluster, region, namespace and user to execute backups cronjob for.

    Returns:
    - http status code of the operation.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await testBackupsCronTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, region=target.region, namespace=target.namespace, auth=Authorization, ldap=target.ldap)




@cronjobs_restores_operative.post("/cronjobsrestorefromfile", tags=["CRONJOBs RESTOREs PVC y MONGO operative(RESTORE, Audits, etc)"], description="RESTORE CRONJOBS IN SHUTTLE FROM FILE ", response_description="JSON", status_code=200)
async def execute_cronjobs_restore_pvc(target: cronjobsModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously cronjobs restores from file.

    Parameters:
    - target: The target cronjobsRestoreModel object containing the functionalEnvironment, cluster, region, namespace, date, cronjobs and user to execute restores for.

    Returns:
    - The retrieved cronjobs restores data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsRestorePvcTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, date=target.date, cronjobsRestore=target.cronjobs)

@cronjobs_restores_operative.post("/cronjobsrestorefrommongo", tags=["CRONJOBs RESTOREs PVC y MONGO operative(RESTORE, Audits, etc)"], description="RESTORE CRONJOBS IN SHUTTLE FROM MONGO", response_description="JSON", status_code=200)
async def execute_cronjobs_restore_mongo(target: cronjobsModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously cronjobs restores from mongo.

    Parameters:
    - target: The target cronjobsRestoreModel object containing the functionalEnvironment, cluster, region, namespace, date, cronjobs and user to execute restores for.

    Returns:
    - The retrieved cronjobs restores data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsRestoreMongoTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, date=target.date, cronjobsRestore=target.cronjobs)

@cronjobs_restores_operative.post("/cronjobsrestoreaudit", tags=["CRONJOBs RESTOREs PVC y MONGO operative(RESTORE, Audits, etc)"], description="SEARCH RESTORES EXECUTIONs CRONJOBS IN SHUTTLE FROM FILE", response_description="JSON", status_code=200)
async def get_restores_audit_pvc(target: AuditOLDBaseModel, Authorization: str=Depends(bearer)):    
    """
    Asynchronously restores cronjobs audit to file.

    Parameters:
    - target: The target AuditBaseModel object containing the functionalEnvironment, cluster, namespace, date and user to retrive audit for.    
     
    Returns:
    - The retrieved restores cronjobs audit data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsRestoresAuditPvTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, region=target.region, namespace=target.namespace, date=target.date, user=target.user)




@cronjobs_searchpattern_operative.post("/cronjobssearchpattern", tags=["CRONJOBs SEARCHPATTERN operative(search, etc)"], description="SEARCH PATTERNS IN CRONJOBS IN SHUTTLE", response_description="JSON", status_code=200)
async def get_cronjobs_search_pattern(target: cronjobsSearchpattern, Authorization: str = Depends(bearer)):
    """
    Asynchronously search patterns in repositories.

    Parameters:
    - target: The target cronjobsSearchpattern object containing the functionalEnvironment, cluster, pattern and user to retrieve data for.

    Returns:
    - The retrieved matchs of the pattern data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await cronjobsSearchPatternTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, pattern=target.pattern, region=target.region, namespace=target.namespace, cronjobs=target.cronjobs)




@audit_operative.post("/auditFile", tags=["CRONJOBs AUDIT operative(search, etc)"], description="SEARCH AUDIT ALL IN SHUTTLE FROM FILE", response_description="JSON", status_code=200)
async def get_audit_all_pvc(target: AuditBaseModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously audit from file.

    Parameters:
    - target: The target AuditBaseModel object containing the functionalEnvironment, cluster, namespace, date and user to retrive audit for.
     
    Returns:
    - The retrieved audit data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await AuditAllPvcTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, typeAudit=target.type, region=target.region, namespace=target.namespace, date=target.date, user=target.user)

@audit_operative.post("/auditMongo", tags=["CRONJOBs AUDIT operative(search, etc)"], description="SEARCH AUDIT ALL IN SHUTTLE FROM MONGO", response_description="JSON", status_code=200)
async def get_audit_all_mongo(target: AuditBaseModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously audit from mongo.

    Parameters:
    - target: The target AuditBaseModel object containing the functionalEnvironment, cluster, namespace, date and user to retrive audit for.
     
    Returns:
    - The retrieved audit data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await AuditAllMongoTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, typeAudit=target.type, region=target.region, namespace=target.namespace, date=target.date, user=target.user)




@authorization.post("/authorizationuser", tags=["CRONJOBs AUTHORIZATION"], description="VALIDATE USER UID - AUTHORIZATION", response_description="JSON", status_code=200)
async def cronjobs_authorization(target: cronjobsAuthorizationModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously retrieves authorization for user.     

    Parameters:
    - target: The target cronjobsAuthorizationModel object containing the ldap user to retrieve data for.

    Returns:
    - The retrieved authorization token.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await authorizationTreatment(auth=Authorization, ldap=target.ldap)
