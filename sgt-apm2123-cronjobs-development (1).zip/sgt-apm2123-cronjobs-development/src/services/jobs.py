from shuttlelib.utils.logger import logger
from shuttlelib.middleware.authorization import is_authorized_user
from aiohttp import client_exceptions
from fastapi import HTTPException
from src.services.clientunique import client, entity_id, ssl_verify
from src.models.cronjobs_models import JOB_STATES
from src.services.sendmail import sendeMailNotification
from sys import platform
from datetime import datetime, timedelta, timezone
from time import time
from json import dump as jsonDump, load
from os import path, chdir, mkdir, getenv

import pandas as pd
import aiohttp

auditJobsFile = "jobsAudit.json"

if platform == "win32":
    separator = "\\"
    repositoryAudit = r"C:\Temp\jobsAudit"
else:
    separator = "/"
    repositoryAudit = r"/tmp/jobsAudit"

async def filterJobsbyState(jobList, state):
    if state is None or state.lower() == "all":
        return jobList
    
    state_lower = state.lower()
    
    if state_lower not in JOB_STATES or state_lower == "deleted":
        valid_states = [s for s in JOB_STATES if s not in ["deleted", "all"]]
        logger.warning(f"State filter '{state}' not valid for filtering. Valid states: {valid_states}")
        return []
    
    state_mapping = {
        "completed": ["completed"],
        "failed": ["failed"],
        "inprogress": ["inprogress"],
        "failed+hung": ["failed", "hung"],
        "hung": ["hung"]
    }
    
    allowed_states = state_mapping.get(state_lower, [])
    
    jobList = [job for job in jobList if job.get('state') in allowed_states]
    
    return jobList

async def checkTimeinProgress(startTime):
    dateFormat = '%Y-%m-%dT%H:%M:%SZ'

    startTime = datetime.strptime(startTime, dateFormat)
    startTime = startTime.replace(tzinfo=timezone.utc)
    now = datetime.now(timezone.utc)
    timeDifference = now - startTime    
    if timeDifference > timedelta(days=1):
        return True
    else:
        return False

def markJobStateCountColors(df):
    colorMap = {
        'jobsCompletedCount':'color: green',
        'jobsFailedCount':'color: red',
        'jobsInProgressCount':'color: blue',
        'jobsInProgressHungCount':'color: red'
    }

    styles = pd.DataFrame('', index=df.index, columns=df.columns)
    for col in df.columns:
        styles[col] = colorMap.get(col, '')

    return styles

def markJobStateColors(row, df):
    styles = [''] * len(row)
    if row['state'] == "failed":
        styles[df.columns.get_loc('state')] = 'color: red'
    if row['state'] == "completed":
        styles[df.columns.get_loc('state')] = 'color: green'
    if row['state'] == "in progress":
        styles[df.columns.get_loc('state')] = 'color: blue'
    if row['state'] == "hung":
        styles[df.columns.get_loc('state')] = 'color: red'

    return styles

async def fillReportDataHead(jobList, stateENV):
    countJobsStateDic = {}
    countCompleted = countFailed = countInProgress = countInProgressHung = 0

    stateENV = stateENV.lower()

    for headerData in jobList:
        for job in headerData['jobs']:
            state = job['state']
            match state:
                case "completed":
                    countCompleted += 1
                case "failed":
                    countFailed += 1
                case "inprogress":
                    countInProgress += 1
                case "hung":
                    countInProgressHung += 1
                case _:
                    pass
    match stateENV:
        case "all":
            countJobsStateDic = {
                'jobsCompletedCount': countCompleted,
                'jobsFailedCount': countFailed,
                'jobsInProgressCount': countInProgress,
                'jobsInProgressHungCount': countInProgressHung
            }
        case "completed":
            countJobsStateDic = {
                'jobsCompletedCount': countCompleted
            }
        case "failed":
            countJobsStateDic = {
                'jobsFailedCount': countFailed
            }
        case "inprogress":
            countJobsStateDic = {
                'jobsInProgressCount': countInProgress
            }
        case "failed+hung":
            countJobsStateDic = {
                'jobsFailedCount': countFailed,
                'jobsInProgressHungCount': countInProgressHung
            }
        case "hung":
            countJobsStateDic = {
                'jobsInProgressHungCount': countInProgressHung
            }
        case _:
            pass

    return countJobsStateDic

async def fillReportDataBody(jobList):
    jobListResult = []

    for headerData in jobList:
        for job in headerData['jobs']:
            jobData = {
                'environment': headerData['environment'],
                'cluster': headerData['cluster'],
                'region': job['region'],
                'namespace': headerData['namespace'],
                'cronjob': job['parent'],
                'job': job['name'],
                'startTime': job['startTime'],
                'completionTime': job['completionTime'],
                'state': job['state'],
                'reason': job['reason'],
                'message': job['message']
            }
            if jobData:
                jobListResult.append(jobData)

    return jobListResult

async def processAndSendEmailReport(jobList, stateENV, environmentENV, clusterENV, emailEnabled):
    try:
        jobDataHead = await fillReportDataHead(jobList, stateENV)
        jobDataBody = await fillReportDataBody(jobList)

        if not emailEnabled or not jobDataHead or not jobDataBody:
            reason = "disabled" if not emailEnabled else "no_data"
            logger.info(f"Email sending notification {reason} - email: {emailEnabled}, head: {bool(jobDataHead)}, body: {bool(jobDataBody)}")
            return {
                "email_sent": False,
                "status": "skipped",
                "reason": reason,
                "status_code": None
            }

        dfHead = pd.DataFrame([jobDataHead])
        dfHeadColor = dfHead.style.apply(markJobStateCountColors, axis=None)
        dfHeadColor = dfHeadColor.set_table_styles([
            {'selector': 'table', 'props': [('border', '1px solid black')]},
            {'selector': 'th', 'props': [('border', '1px solid black')]},
            {'selector': 'td', 'props': [('border', '1px solid black')]}
        ])
        dfHeadColor.hide()

        dfBody = pd.json_normalize(jobDataBody)
        dfBody.fillna("N/A", inplace=True)
        dfBodyColor = dfBody.style.apply(lambda row: markJobStateColors(row, dfBody), axis=1)
        dfBodyColor = dfBodyColor.set_table_styles([
            {'selector': 'table', 'props': [('border', '1px solid black')]},
            {'selector': 'th', 'props': [('border', '1px solid black')]},
            {'selector': 'td', 'props': [('border', '1px solid black')]}
        ])
        dfBodyColor.hide()

        htmlcontent = f'''Hi! Here is a list of jobs in {stateENV} state
            <br><br>
            {dfHeadColor.to_html(index=False, escape=False)}  
            <br><br>
            {dfBodyColor.to_html(index=False, escape=False)}'''

        subject = f"List of JOBs in {environmentENV.upper()}({clusterENV.upper()}) and \"{stateENV}\" state"
        answer = await sendeMailNotification(subject=subject, htmlcontent=htmlcontent)
        
        logger.info(f"Email notification response -> {answer.status_code}")
        
        return {
            "email_sent": answer.status_code == 200,
            "status": "sent" if answer.status_code == 200 else "failed",
            "reason": "success" if answer.status_code == 200 else f"smtp_error_{answer.status_code}",
            "status_code": answer.status_code
        }
    except Exception as e:
        logger.error(f"Error processing email report: {str(e)}")
        return {
            "email_sent": False,
            "status": "error", 
            "reason": f"processing_error: {str(e)}",
            "status_code": None
        }

async def getcronJobList():
    environmentENV = (getenv("ENVIRONMENT")).lower()
    clusterENV = (getenv("CLUSTER")).lower()
    regionENV = (getenv("REGION")).lower()
    namespaceENV = (getenv("NAMESPACE")).lower()
    stateENV = (getenv("STATE")).lower()
    emailEnabled = (getenv("EMAIL_NOTIFICATION")).lower() == "true"

    logger.info(f"Cronjob getJobsList -> started")
    logger.info(f"Working to list job in state {stateENV}")
    
    email_result = None
    
    for state in JOB_STATES:
        if state != stateENV:
            try:
                jobList = await getJobsListReport(environmentENV, clusterENV, regionENV, namespaceENV, state)
                if jobList and len(jobList) > 0:
                    await jobExecutionAuditRecord(jobList, "shuttlecronjob")
                    logger.info(f"Audit saved for state '{state}' with {sum(len(element.get('jobs', [])) for element in jobList)} jobs")
            except Exception as e:
                logger.error(f"Error processing state '{state}' for audit: {e}")
                continue
        else:
            try:
                jobList = await getJobsListReport(environmentENV, clusterENV, regionENV, namespaceENV, stateENV)
                if jobList and len(jobList) > 0:
                    await jobExecutionAuditRecord(jobList, "shuttlecronjob")
                    jobs_count = sum(len(element.get('jobs', [])) for element in jobList)
                    logger.info(f"Audit saved for state '{stateENV}' with {jobs_count} jobs")
                    
                    email_result = await processAndSendEmailReport(jobList,stateENV, environmentENV, clusterENV, emailEnabled)
                else:
                    logger.info(f"No jobs found in state '{stateENV}' for email notification")
                    email_result = {
                        "email_sent": False,
                        "status": "no_jobs",
                        "reason": "no_jobs_found",
                        "status_code": None
                    }
            except Exception as e:
                logger.error(f"Error processing state '{stateENV}' for email notification: {e}")
                raise HTTPException(status_code=500, detail=f"Failed to process jobs for email notification: {str(e)}")

    logger.info(f"Cronjob getJobsList -> completed")    

    response = {
        "status": "success", 
        "detail": "Cronjob process completed successfully"
    }

    if email_result:
        response.update({
            "email_sent": email_result["email_sent"],
            "email_status": email_result["status"],
            "email_reason": email_result["reason"]
        })

    return response

async def jobExecutionAuditRecord(jobList, ldap):
    timeJobAction = time()
    dtTime = datetime.fromtimestamp(timeJobAction)

    dateAudit = dtTime.date().isoformat()
    timeAudit = dtTime.time().isoformat()
    id = dateAudit + timeAudit.replace(":", "-").replace(".", "-") 
    timeAudit = dtTime.time().isoformat("seconds")
 
    for record in jobList:
        record['date'] = dateAudit
        record['time'] = timeAudit
        record['id'] = id
        
        if ldap:
            record['user'] = ldap
    
    dataListAudit = jobList
    
    if path.isdir(repositoryAudit):
        chdir(repositoryAudit)
    else:
        mkdir(repositoryAudit)
        chdir(repositoryAudit)

    if path.isfile(auditJobsFile):
        with open (auditJobsFile, "r") as file:
            try:
                dataListAudit = load(file)
            except:
                dataListAudit = []
        dataListAudit.extend(jobList)

    with open(auditJobsFile, "w") as file:
        jsonDump(dataListAudit, file, indent=4)

async def searchAuditLog(environment, cluster, region, namespace, date, cronjobs, state, user):
    matchResult = []

    params = {
        'environment': environment,
        'cluster': cluster,
        'region': region,
        'namespace': namespace,
        'state': state,
        'date': date,
        'parent': cronjobs,
        'user': user
    }
    
    filteredParams = {key: value for key, value in params.items() if value is not None}
         
    if path.isdir(repositoryAudit):
        chdir(repositoryAudit)
        if path.isfile(auditJobsFile):
            try:
                file = open(auditJobsFile, "r")
            except OSError: 
                logger.error(f"audit log does not exists or is inaccessible in path {repositoryAudit}")
            
            contentAuditFile = load(file)
            
            match = []
            
            if cronjobs:
                if "," in cronjobs:
                    cronjobs = [entry.strip() for entry in cronjobs.split(",")]
                    for entry in contentAuditFile:
                        for cronjob in cronjobs:
                            filteredParams['parent'] = cronjob
                            if all((entry.get(param) == value) for param, value in filteredParams.items() if param != "parent"):
                                matchedJobs = [job for job in entry.get("jobs", []) if filteredParams.get("parent") in job.get("parent")]
                                if matchedJobs:
                                    match.extend(matchedJobs)
                        if match:
                            entryCopy = entry.copy()
                            entryCopy['jobs'] = match
                            matchResult.append(entryCopy)
                            match = []
                else:
                    for entry in contentAuditFile:
                        if all((entry.get(param) == value) for param, value in filteredParams.items() if param != "parent"):                                                              
                            matchedJobs = [job for job in entry.get("jobs", []) if filteredParams.get("parent") in job.get("parent")]
                            if matchedJobs:
                                entryCopy = entry.copy()
                                entryCopy['jobs'] = matchedJobs
                                matchResult.append(entryCopy)
            else:
                for entry in contentAuditFile:
                    if all((entry.get(param) == value) for param, value in filteredParams.items()):
                        matchedJobs = [job for job in entry.get("jobs", [])]
                        if matchedJobs:
                            entryCopy = entry.copy()
                            entryCopy['jobs'] = matchedJobs
                            matchResult.append(entryCopy)
        else:
            logger.error(f"audit log does not exists or is inaccessible in path {repositoryAudit}")
            return []
    else:
        logger.error(f"audit log does not exists or is inaccessible in path {repositoryAudit}")
        return []

    if matchResult:
        return matchResult
    else: 
        return []

async def getJobsListReport(functional_environment, cluster, region = None, namespace = None, state = None):
    jobList = []
    namespaceList = []
    jobDataList = []
    jobResultList = []

    if state is None:
        state = "all"

    if region is None:
        region = "both"
        regionParam = "both"
    else:
        regionParam = region
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]

    if namespace is None:
        for region in regionList:
            try:
                namespaceList = await client.get_resource(resource = "namespaces", functional_environment = functional_environment.lower(), cluster = cluster.lower(), region = region.lower())
            except client_exceptions.ClientConnectorError:
                logger.error(f"Timeout detected....")
                continue
            except:
                logger.error(f"namespaces could not be retrieved. Skipping...")
                continue

            try:
                items = namespaceList[region]['items']
            except:
                items = None
            if items and len(items) > 0:
                namespaceList = items
                for namespace in namespaceList:
                    namespaceName = namespace['metadata']['name']
                    try:
                        jobList = await client.get_resource(resource = "jobs", functional_environment = functional_environment.lower(), cluster = cluster.lower(), region = region.lower(), namespace = namespaceName.lower())
                    except client_exceptions.ClientConnectorError:
                        logger.error(f"Timeout detected....")
                        continue
                    except:
                        logger.error(f"jobs could not be retrieved. Skipping...")
                        continue

                    try:
                        items = jobList[region]['items']
                    except:
                        items = None
                    if items and len(items) > 0:
                        jobList = items
                        for job in jobList:
                            metadata = job['metadata']
                            name = metadata.get('name', None)
                            namespace = metadata.get('namespace', None)
                            if (metadata.get('ownerReferences', None)):
                                parent = metadata['ownerReferences'][0].get('name', None)
                            else:
                                parent = None
                            
                            status = job['status']
                            startTime = status.get('startTime', None)
                            completionTime = status.get('completionTime', None)
                            inProgress = status.get('active', None)
                            podSucceeded = status.get('succeeded', None)
                            podFailed = status.get('failed', None)

                            if not inProgress:
                                type = job.get('status', {}).get('conditions', {})[0].get('type', None)
                                status = job.get('status', {}).get('conditions', {})[0].get('status', None)
                                reason = job.get('status', {}).get('conditions', {})[0].get('reason', None)
                                message = job.get('status', {}).get('conditions', {})[0].get('message', None)
                            else:
                                type = reason = message = status = None 

                            if inProgress:
                                hungJob = await checkTimeinProgress(startTime)
                                if hungJob:
                                    stateJob = "hung"
                                    reason = "PotentialHungJob"
                                    message = "This job is in progress state for more than a day (review asap..)"
                                else:
                                    stateJob = "inprogress"
                            elif type == "Failed" and podFailed:
                                stateJob = "failed"
                            elif type == "Complete" and podSucceeded:
                                stateJob = "completed"
                            else:
                                stateJob = None

                            jobData = {
                                'name': name, 
                                'parent': parent,
                                'region': region,
                                'startTime': startTime, 
                                'completionTime': completionTime, 
                                'state': stateJob,
                                'reason': reason,
                                'message': message,
                            }

                            if jobData:
                                jobDataList.append(jobData)
                    
                    if jobDataList and len(jobDataList) > 0:
                        headerData = {
                            'environment': functional_environment,
                            'cluster': cluster,
                            'region': regionParam,
                            'namespace': namespace,
                            'state': state
                        }
                        jobDataAll = {
                            **headerData,
                            "jobs": jobDataList
                            }
                        jobResultList.append(jobDataAll)
                        jobDataList = []
    else:       
        for region in regionList:
            try:
                jobList = await client.get_resource(resource = "jobs", functional_environment = functional_environment.lower(), cluster = cluster.lower(), region = region.lower(), namespace = namespace.lower())
            except client_exceptions.ClientConnectorError:
                logger.error(f"Timeout detected....")
                continue
            except:
                logger.error(f"jobs could not be retrieved. Skipping...")
                continue
            
            try:
                items = jobList[region]['items']
            except:
                items = None
                
            if items and len(items) > 0:
                jobList = items
                for job in jobList:
                    metadata = job['metadata']
                    name = metadata.get('name', None)
                    namespace = metadata.get('namespace', None)
                    if (metadata.get('ownerReferences', None)):
                        parent = metadata['ownerReferences'][0].get('name', None)
                    else:
                        parent = None

                    status = job['status']
                    startTime = status.get('startTime', None)
                    completionTime = status.get('completionTime', None)
                    inProgress = status.get('active', None)
                    podSucceeded = status.get('succeeded', None)
                    podFailed = status.get('failed', None)

                    if not inProgress:
                        type = job.get('status', {}).get('conditions', {})[0].get('type', None)
                        status = job.get('status', {}).get('conditions', {})[0].get('status', None)
                        reason = job.get('status', {}).get('conditions', {})[0].get('reason', None)
                        message = job.get('status', {}).get('conditions', {})[0].get('message', None)
                    else:
                        type = reason = message = status = None

                    if inProgress:
                        hungJob = await checkTimeinProgress(startTime)
                        if hungJob:
                            stateJob = "hung"
                            reason = "PotentialHungJob"
                            message = "This job is in progress state for more than a day (review asap..)"
                        else:
                            stateJob = "inprogress"
                    elif type == "Failed" and podFailed:
                        stateJob = "failed"
                    elif type == "Complete" and podSucceeded:
                        stateJob = "completed"
                    else:
                        stateJob = None

                    jobData = {
                        'name': name,
                        'parent': parent,
                        'region': region,
                        'startTime': startTime, 
                        'completionTime': completionTime,
                        'state': stateJob,
                        'reason': reason,
                        'message': message,
                    }

                    if jobData:
                        jobDataList.append(jobData) 

            if jobDataList and len(jobDataList) > 0:
                headerData = {
                    'environment': functional_environment,
                    'cluster': cluster,
                    'region': regionParam,
                    'namespace': namespace,
                    'state': state
                }
                jobDataAll = {
                    **headerData,
                    "jobs": jobDataList
                    }
                jobResultList.append(jobDataAll)
                jobDataList = []
    
    '''
    if state.lower() != "all":
        for element in jobResultList:
            jobList = element['jobs']
            jobListAux = jobList[:]
            if state.lower() == "completed":
                for job in jobListAux:
                    if job['state'] != "completed":
                        jobList.remove(job)
            elif state.lower() == "failed":
                for job in jobListAux:
                    if job['state'] != "failed":
                        jobList.remove(job)
            elif state.lower() == "inprogress":
                for job in jobListAux:
                    if job['state'] != "inprogress":
                        jobList.remove(job)
            elif state.lower() == "failed+hung":
                for job in jobListAux:
                    if (job['state'] != "failed" and job['state'] != "hung"):
                        jobList.remove(job)
            elif state.lower() == "hung":
                for job in jobListAux:
                    if job['state'] != "hung":
                        jobList.remove(job)
            else:
                logger.warning(f"State filter {state} not recognized")
                return []
    '''
    
    filteredResults = []
    for element in jobResultList:
        filteredJobs = await filterJobsbyState(element['jobs'], state)
        if filteredJobs:
            elementFiltered = element.copy()
            elementFiltered['jobs'] = filteredJobs
            filteredResults.append(elementFiltered)
    
    return filteredResults

async def analyzeJobRealState(job_data, functional_environment, cluster, region, namespace):
    POD_ERROR_STATES = [
        "ImagePullBackOff", "ErrImagePull", "CrashLoopBackOff",
        "RunContainerError", "CreateContainerError", "InvalidImageName", 
        "CreateContainerConfigError", "PreStartHookError", "PostStartHookError",
        "ContainerCannotRun", "DeadlineExceeded", "Error", "Evicted",
        "ImageInspectError", "ErrImageNeverPull", "RegistryUnavailable"
    ]

    POD_ERROR_MESSAGES = {
        "ImagePullBackOff": "Cannot pull container image - check image name and registry access",
        "ErrImagePull": "Failed to pull container image - verify image exists and is accessible", 
        "CrashLoopBackOff": "Container keeps crashing - check application logs and configuration",
        "RunContainerError": "Cannot run container - verify container configuration",
        "CreateContainerError": "Cannot create container - check resource limits and permissions",
        "InvalidImageName": "Container image name is invalid - verify image name format",
        "CreateContainerConfigError": "Container configuration error - check environment variables and volumes",
        "DeadlineExceeded": "Job execution timeout exceeded - job took too long to complete",
        "Error": "General container error - check container logs for details",
        "Evicted": "Pod was evicted from node - insufficient resources or node issues",
        "ImageInspectError": "Cannot inspect container image - verify image registry access",
        "ErrImageNeverPull": "Image never pull policy error - check pull policy configuration",
        "RegistryUnavailable": "Container registry unavailable - check network connectivity"
    }
    
    original_state = job_data.get('state', 'unknown')
    job_name = job_data.get('name')
    
    if original_state != 'inprogress' or not job_name:
        return job_data

    try:
        pods_response = await client.get_resource(
            resource="pods", 
            functional_environment=functional_environment.lower(), 
            cluster=cluster.lower(), 
            region=region.lower(), 
            namespace=namespace.lower()
        )
        
        pod_items = pods_response.get(region, {}).get('items', [])
        
        for pod in pod_items:
            pod_metadata = pod.get('metadata', {})
            pod_name = pod_metadata.get('name', '')
            
            if pod_name.startswith(job_name + '-'):
                pod_status = pod.get('status', {})
                pod_phase = pod_status.get('phase', '')
                if pod_phase in POD_ERROR_STATES:
                    logger.warning(f"Job {job_name} detected with pod phase error: {pod_phase} in pod {pod_name}")
                    job_data['state'] = 'failed'
                    job_data['reason'] = pod_phase
                    job_data['message'] = POD_ERROR_MESSAGES.get(pod_phase, f'Pod error: {pod_phase}')
                    return job_data
                
                container_statuses = pod_status.get('containerStatuses', [])
                for container in container_statuses:
                    container_name = container.get('name', '')
                    waiting_state = container.get('state', {}).get('waiting', {})
                    terminated_state = container.get('state', {}).get('terminated', {})
                    if waiting_state:
                        waiting_reason = waiting_state.get('reason', '')
                        if waiting_reason in POD_ERROR_STATES:
                            logger.warning(f"Job {job_name} detected with container waiting error: {waiting_reason} in container {container_name} of pod {pod_name}")
                            job_data['state'] = 'failed'
                            job_data['reason'] = waiting_reason
                            job_data['message'] = POD_ERROR_MESSAGES.get(waiting_reason, f'Container error: {waiting_reason}')
                            return job_data
                    if terminated_state:
                        terminated_reason = terminated_state.get('reason', '')
                        exit_code = terminated_state.get('exitCode', 0)
                        if terminated_reason in POD_ERROR_STATES or exit_code != 0:
                            logger.warning(f"Job {job_name} detected with container terminated error: {terminated_reason} (exit code: {exit_code}) in container {container_name} of pod {pod_name}")
                            job_data['state'] = 'failed'
                            job_data['reason'] = terminated_reason if terminated_reason in POD_ERROR_STATES else f'ExitCode{exit_code}'
                            job_data['message'] = POD_ERROR_MESSAGES.get(terminated_reason, f'Container terminated with exit code {exit_code}')
                            return job_data
    except Exception as e:
        logger.error(f"Error analyzing pods for job {job_name}: {e}")
        return job_data
    
    return job_data

async def getJobsList(functional_environment, cluster, region, namespace, state):
    jobList = []
    namespaceList = []
    jobResultList = []
        
    if state is None:
        state = "all"
        
    if region is None:
        region = "both"
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]
       
    if namespace is None:
        for region in regionList:
            try:
                namespaceList = await client.get_resource(resource = "namespaces", functional_environment = functional_environment.lower(), cluster = cluster.lower(), region = region.lower())
            except client_exceptions.ClientConnectorError:
                logger.error(f"Timeout detected....")
                continue
            except:
                logger.error(f"namespaces could not be retrieved. Skipping...")
                continue

            try:
                items = namespaceList[region]['items']
            except:
                items = None
            if items and len(items) > 0:
                namespaceList = items
                for namespace in namespaceList:
                    namespaceName = namespace['metadata']['name']
                    try:
                        jobList = await client.get_resource(resource = "jobs", functional_environment = functional_environment.lower(), cluster = cluster.lower(), region = region.lower(), namespace = namespaceName.lower())
                    except client_exceptions.ClientConnectorError:
                        logger.error(f"Timeout detected....")
                        continue
                    except:
                        logger.error(f"jobs could not be retrieved. Skipping...")
                        continue
    
                    try:
                        items = jobList[region]['items']
                    except:
                        items = None
                    if items and len(items) > 0:
                        jobList = items
                        for job in jobList:
                            metadata = job['metadata']
                            name = metadata.get('name', None)
                            namespace = metadata.get('namespace', None) 
                            if (metadata.get('ownerReferences', None)):
                                parent = metadata['ownerReferences'][0].get('name', None)
                            else:
                                parent = None
                            
                            status = job['status']
                            startTime = status.get('startTime', None)
                            completionTime = status.get('completionTime', None)
                            inProgress = status.get('active', None)
                            podSucceeded = status.get('succeeded', None)
                            podFailed = status.get('failed', None)

                            if not inProgress:
                                type = job.get('status', {}).get('conditions', {})[0].get('type', None)
                                status = job.get('status', {}).get('conditions', {})[0].get('status', None)
                                reason = job.get('status', {}).get('conditions', {})[0].get('reason', None)
                                message = job.get('status', {}).get('conditions', {})[0].get('message', None)
                            else:
                                type = reason = message = status = None

                            if inProgress:
                                hungJob = await checkTimeinProgress(startTime)
                                if hungJob:
                                    stateJob = "hung"
                                    reason = "PotentialHungJob"
                                    message = "This job is in progress state for more than a day (review asap..)"
                                else:
                                    stateJob = "inprogress"
                            elif type == "Failed" and podFailed:
                                stateJob = "failed"
                            elif type == "Complete" and podSucceeded:
                                stateJob = "completed"
                            else:
                                stateJob = None

                            jobData = {
                                'environment': functional_environment, 
                                'cluster': cluster,
                                'region': region,
                                'namespace': namespace,
                                'name': name,
                                'parent': parent,
                                'startTime': startTime,
                                'completionTime': completionTime,
                                'state': stateJob,
                                'reason': reason,
                                'message': message,
                            }

                            if jobData:
                                jobDataAnalyzed = await analyzeJobRealState(jobData, functional_environment, cluster, region, namespace)
                                jobResultList.append(jobDataAnalyzed)
    else:
        for region in regionList:
            try:
                jobList = await client.get_resource(resource = "jobs", functional_environment = functional_environment.lower(), cluster = cluster.lower(), region = region.lower(), namespace = namespace.lower())
            except client_exceptions.ClientConnectorError:
                logger.error(f"Timeout detected....")
                continue
            except:
                logger.error(f"jobs could not be retrieved. Skipping...")
                continue
            
            try:
                items = jobList[region]['items']
            except:
                items = None
            if items and len(items) > 0:
                jobList = items
                for job in jobList:
                    metadata = job['metadata']
                    name = metadata.get('name', None)
                    namespace = metadata.get('namespace', None)
                    if (metadata.get('ownerReferences', None)):
                        parent = metadata['ownerReferences'][0].get('name', None)
                    else:
                        parent = None

                    status = job['status']
                    startTime = status.get('startTime', None)
                    completionTime = status.get('completionTime', None)
                    inProgress = status.get('active', None)
                    podSucceeded = status.get('succeeded', None)
                    podFailed = status.get('failed', None)

                    if not inProgress:
                        type = job.get('status', {}).get('conditions', {})[0].get('type', None)
                        status = job.get('status', {}).get('conditions', {})[0].get('status', None)
                        reason = job.get('status', {}).get('conditions', {})[0].get('reason', None)
                        message = job.get('status', {}).get('conditions', {})[0].get('message', None)
                    else:
                        type = reason = message = status = None
                    
                    if inProgress:
                        hungJob = await checkTimeinProgress(startTime)
                        if hungJob:
                            stateJob = "hung"
                            reason = "PotentialHungJob"
                            message = "This job is in progress state for more than a day (review asap..)"
                        else:
                            stateJob = "inprogress"
                    elif type == "Failed" and podFailed:
                        stateJob = "failed"
                    elif type == "Complete" and podSucceeded:
                        stateJob = "completed"
                    else:
                        stateJob = None
                    
                    jobData = {
                        'environment': functional_environment, 
                        'cluster': cluster, 
                        'region': region, 
                        'namespace': namespace,
                        'name': name,
                        'parent': parent,
                        'startTime': startTime, 
                        'completionTime': completionTime, 
                        'state': stateJob,
                        'reason': reason,
                        'message': message,
                    }

                    if jobData:
                        jobDataAnalyzed = await analyzeJobRealState(jobData, functional_environment, cluster, region, namespace)
                        jobResultList.append(jobDataAnalyzed)
    '''
    if state.lower() != "all":
        jobResultListAux = jobResultList[:]
        for job in jobResultListAux:
            if state.lower() == "completed":
                if job['state'] != "completed":
                    jobResultList.remove(job)
            elif state.lower() == "failed":
                if job['state'] != "failed":
                    jobResultList.remove(job)
            elif state.lower() == "inprogress":
                if job['state'] != "inprogress":
                    jobResultList.remove(job)
            elif state.lower() == "failed+hung":
                if (job['state'] != "failed" and job['state'] != "hung"):
                    jobResultList.remove(job)
            elif state.lower() == "hung":
                if job['state'] != "hung":
                    jobResultList.remove(job)
            else:
                logger.warning(f"State filter {state} not recognized")
                return []
    '''
    
    jobResultList = await filterJobsbyState(jobResultList, state)
    logger.info(f"Returning {len(jobResultList)} jobs after pod analysis and state filtering")

    return jobResultList

async def deleteJobs(functional_environment, cluster, region, namespace, jobs=None, jobList=None):
    jobResultList = []

    if jobList is not None:
        logger.info(f"Using provided job list with {len(jobList)} jobs")
        jobsToProcess = jobList
    else:
        logger.info(f"No job list provided, fetching all jobs")
        jobsToProcess = await getJobsList(functional_environment, cluster, region, namespace, "all")

    if not jobsToProcess or len(jobsToProcess) == 0:
        logger.info(f"No jobs found for delete process")
        return []
    
    if jobs and jobs.lower() != "all":
        jobNames = [job.strip() for job in jobs.split(",")]
        originalCount = len(jobsToProcess)
        jobsToProcess = [job for job in jobsToProcess if job.get('name') in jobNames]
        logger.info(f"Filtered from {originalCount} to {len(jobsToProcess)} jobs by names: {jobNames}")
        
        if len(jobsToProcess) == 0:
            logger.warning(f"No jobs found with specified names: {jobNames}")
            return []
    else:
        logger.info(f"Processing all {len(jobsToProcess)} jobs (jobs parameter: {jobs})")
    
    if region is None:
        region = "both"
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]

    logger.info(f"Processing {len(jobsToProcess)} jobs for deletion across regions: {regionList}")

    for region in regionList:
        clientData = client.clusters[functional_environment][cluster].get(region, None)
        
        if clientData is None:
            logger.warning(f"No client data found for region {region}")
            continue

        urlApi = clientData.get("url", None)
        token = clientData.get("token", None)

        jobsInRegion = [job for job in jobsToProcess if job.get('region') == region]
        
        if not jobsInRegion:
            logger.info(f"No jobs found in region {region}")
            continue
            
        logger.info(f"Processing {len(jobsInRegion)} jobs in region {region}")

        namespaces = {}
        for job in jobsInRegion:
            job_namespace = job.get('namespace', namespace)
            if job_namespace not in namespaces:
                namespaces[job_namespace] = []
            namespaces[job_namespace].append(job)

        for current_namespace, namespace_jobs in namespaces.items():
            jobDataList = []  # ✅ NUEVA LISTA POR NAMESPACE
            
            for job in namespace_jobs:
                name = job.get('name')
                
                if not name:
                    logger.warning(f"Job without name found, skipping: {job}")
                    continue

                requestUrl = urlApi + "/apis/batch/v1/namespaces/" + current_namespace + "/jobs/" + name
                headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close"}

                delete_options = {
                    "propagationPolicy": "Foreground"
                }

                logger.info(f'Deleting job {name} in {region}/{current_namespace}')

                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.delete(requestUrl, headers=headers, json=delete_options, ssl=ssl_verify, timeout=aiohttp.ClientTimeout(total=30)) as answer: 
                            status_code = answer.status
                            reason = answer.reason
                except aiohttp.ClientConnectorError:
                    logger.error(f'Connection error deleting job {name}. Cannot connect to {urlApi}')
                    status_code = 408
                    reason = 'Connection error'
                except aiohttp.ServerTimeoutError:
                    logger.error(f'Timeout deleting job {name}')
                    status_code = 408
                    reason = 'Timeout'
                except Exception as e:
                    logger.error(f'Error deleting job {name}: {e}')
                    status_code = 500
                    reason = f'Error: {str(e)}'

                parent = name.rsplit("-", 1)[0]
                jobData = {
                    'name': name, 
                    'parent': parent,
                    'region': region,
                    'state': "deleted",
                    'reason': status_code,
                    'message': reason
                }
                
                if jobData:
                    jobDataList.append(jobData)
                
                logger.info(f"answer {status_code}({reason}) in job delete action process ({current_namespace} > {name})")

            if len(jobDataList) > 0:
                headerData = {
                    "environment": functional_environment, 
                    "cluster": cluster, 
                    "region": region, 
                    "namespace": current_namespace, 
                    "state": "deleted"
                }
                jobDataAll = {
                    **headerData,
                    "jobs": jobDataList
                }
                jobResultList.append(jobDataAll)

    logger.info(f"Finished delete process with {len(jobResultList)} namespace groups")
    return jobResultList

async def jobsListTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None, state = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"starting jobList process")
                jobList = await getJobsList(functional_environment, cluster, region, namespace, state)
                logger.info(f"finished jobList process")
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting jobList process")
            jobList = await getJobsList(functional_environment, cluster, region, namespace, state)
            logger.info(f"finished jobList process")
    
    return jobList

async def jobsAuditTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None, cronjobs = None, date = None, state = None, user = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                return await searchAuditLog(functional_environment, cluster, region, namespace, date, cronjobs, state, user)
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await searchAuditLog(functional_environment, cluster, region, namespace, date, cronjobs, state, user)

async def jobsDeleteTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None, jobs = None, state = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"Starting job deletion process")
                jobList = await getJobsList(functional_environment, cluster, region, namespace, state)
                if jobList and len(jobList) > 0:
                    resultDelete = await deleteJobs(functional_environment, cluster, region, namespace, jobs=jobs, jobList=jobList)
                else:
                    logger.info("No jobs found matching criteria")
                    resultDelete = []
                if resultDelete and len(resultDelete) > 0:
                    await jobExecutionAuditRecord(resultDelete, ldap)
                logger.info(f"Finished job deletion process")
                return resultDelete
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"Starting job deletion process")
            jobList = await getJobsList(functional_environment, cluster, region, namespace, state)
            if jobList and len(jobList) > 0:
                resultDelete = await deleteJobs(functional_environment, cluster, region, namespace, jobs=jobs, jobList=jobList)
            else:
                logger.info("No jobs found matching criteria")
                resultDelete = []
            if resultDelete and len(resultDelete) > 0:
                await jobExecutionAuditRecord(resultDelete, ldap)
            logger.info(f"Finished job deletion process")
            return resultDelete

async def testJobsCronTreatment(auth, ldap):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                return await getcronJobList()
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await getcronJobList()
