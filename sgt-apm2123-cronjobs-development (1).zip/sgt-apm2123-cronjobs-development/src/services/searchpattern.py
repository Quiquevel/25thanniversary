from json import dump as jsonDump
from os import path, chdir, listdir, walk, remove, getcwd
from re import match
from fnmatch import translate
from datetime import datetime
from pandas import json_normalize
from sys import platform
from fastapi import HTTPException
from shuttlelib.utils.logger import logger
from shuttlelib.middleware.authorization import is_authorized_user
from src.services.clientunique import client, entity_id

idnamespaces = None

if platform == "win32":
    separator = "\\"
    repositories = r"C:\Temp\cronjobsBackups"
else:
    separator = "/"
    repositories = r"/tmp/cronjobsBackups"

def getRecentDateDirectory(basePath):
    try:
        items = listdir(basePath)
        dateDirs = []
        for item in items:
            itemPath = path.join(basePath, item)
            if path.isdir(itemPath):
                try:
                    datetime.strptime(item, '%Y-%m-%d')
                    dateDirs.append(item)
                except ValueError:
                    continue

        if not dateDirs:
            return None

        dateDirs.sort()
        mostRecentDir = dateDirs[-1]
        return mostRecentDir
    except OSError as e:
        logger.error(f"Error accessing directory {basePath}: {e}")
        return None

async def fileLoop(i, lines, regex):
    result = ""

    for pattern in regex:
        if pattern.upper() in lines.upper():
            if lines.strip().startswith("#"):
                pass
            elif "allowedorigins" in lines.lower():
                pass
            else:
                result += "- " + str(i + 1) + " " + lines

    if result and len(result) > 0 and result[-1] == "\n":
        return result[:-1]
    else:
        return result

async def searchConfigEnv(environment, cluster, region, namespace, cronjobs, patternsplit):
    listResult = []
    statusUmbrellaList = []
    matchtUmbrellaList = []
    locationList = []
    appendResult = {}
    statusUmbrella = {}
    location = {}
    
    global idnamespaces 

    workdir = getcwd()

    if cronjobs:
        if "," in cronjobs:
            cronjobs = [entry.strip() for entry in cronjobs.split(",")]
            for i, cronjob in enumerate(cronjobs):
                if not cronjob.endswith(".yaml"):
                    cronjobs[i] = cronjob + ".yaml"
        else:
            cronjob_input = cronjobs.strip()
            if cronjob_input.endswith(".yaml"):
                cronjobs = [cronjob_input]
            else:
                cronjobs = [f"{cronjob_input}*.yaml"]
            
    for root, dirs, files in walk(workdir):
        if cronjobs:
            files = [file for file in files if any(file==cronjob or match(translate(cronjob),file) for cronjob in cronjobs)]
        
        for file in files:
            workingfile = path.join(root, file)
            if platform == "win32":
                directory = (workingfile.split("\\")[-2])
            else:
                directory = (workingfile.split("/")[-2])
            
            with open(workingfile, "r", encoding="utf-8", errors='replace') as workfile:
                targetline = workfile.readlines()
                for i, lines in enumerate(targetline):
                    matchtUmbrella = await fileLoop(i, lines, patternsplit)
                    if matchtUmbrella:
                        if matchtUmbrella[-1] == ",":
                            matchtUmbrella = matchtUmbrella[:-1]
                        matchtUmbrellaList.append(matchtUmbrella)
                        
            if matchtUmbrellaList and len(matchtUmbrellaList) > 0:
                location = {'file': directory + ">" + file, 'match': matchtUmbrellaList}
                locationList.append(location)
                matchtUmbrellaList = []
                location = {}


    if locationList and len(locationList) > 0:
        statusUmbrella = {'files': locationList}
        statusUmbrellaList.append(statusUmbrella)
    else:
        statusUmbrellaList = []

    if statusUmbrellaList and len(statusUmbrellaList) > 0:
        for result in statusUmbrellaList:
            idnamespaces += 1
            appendResult = {"id": idnamespaces, "environment": environment, "cluster": cluster, "region": region, "namespace": namespace}
            appendResult.update(result)
            listResult.append(appendResult)
            appendResult = {}
        else:
            appendResult = {}
    else:
        listResult = [] 
    
    appendResult = statusUmbrella = location = None
    matchtUmbrellaList = []
    statusUmbrellaList = []
    locationList = []

    return listResult

async def searchPattern(environment, cluster, region, namespace, cronjobs, pattern):
    listResult = []
    clusters = []
    regions = []
    dictResult = {}
    
    global idnamespaces
    idnamespaces = 0

    patternsplit = [p.strip() for p in pattern.split(",") if p.strip()]
  
    if cluster.lower() == "all":
        clusters = list(client.clusters[environment].keys())
    else:
        clusters = [cluster.lower()]

    logger.info(f'STARTING search in {environment.upper()}')

    for cluster in clusters: 
        logger.info(f'STARTING search for cluster repositories {cluster.upper()} in {environment.upper()}')

        if region is None:
            regions = list(client.clusters[environment][cluster])
        else:
            regions = [region]
        
        workdir = path.join(repositories, environment, cluster)
        if path.isdir(workdir):
            chdir(workdir)
        
            for region in regions:
                if namespace is None:
                    workdir = path.join(workdir, region)
                else:
                    workdir = path.join(workdir, region, namespace)
                
                if path.isdir(workdir):
                    chdir(workdir)
                else:
                    logger.error(f"cronjobs data does not exists or is inaccessible in path {workdir}")
                    continue

                if namespace is not None:
                    mostRecentDate = getRecentDateDirectory(workdir)

                    if mostRecentDate:
                        workdir = path.join(workdir, mostRecentDate)
                        logger.info(f"Using most recent backup date: {mostRecentDate}")

                        if path.isdir(workdir):
                            chdir(workdir)

                            listResultENV = await searchConfigEnv(environment, cluster, region, namespace, cronjobs, patternsplit)

                            if listResultENV and len(listResultENV) > 0:
                                listResult.extend(listResultENV) 
                                listResultENV = None
                            else:
                                pass
                        else:
                            logger.error(f"Date directory does not exist: {workdir}")
                    else:
                        logger.error(f"No date directories found in {workdir}")
                    workdir = path.join(repositories, environment, cluster)
                else:
                    try:
                        all_namespaces = [item for item in listdir(workdir) if path.isdir(path.join(workdir, item))]

                        if not all_namespaces:
                            logger.warning(f"No namespaces found in {workdir}")
                        else:
                            logger.info(f"Found {len(all_namespaces)} namespaces in region {region}")

                            for current_namespace in all_namespaces:
                                namespace_path = path.join(workdir, current_namespace)
                                logger.info(f"Processing namespace: {current_namespace}")

                                if path.isdir(namespace_path):
                                    mostRecentDate = getRecentDateDirectory(namespace_path)

                                    if mostRecentDate:
                                        date_workdir = path.join(namespace_path, mostRecentDate)
                                        logger.info(f"Using most recent backup date for {current_namespace}: {mostRecentDate}")

                                        if path.isdir(date_workdir):
                                            chdir(date_workdir)
                                            
                                            listResultENV = await searchConfigEnv(environment, cluster, region, current_namespace, cronjobs, patternsplit)

                                            if listResultENV and len(listResultENV) > 0:
                                                listResult.extend(listResultENV)
                                                logger.info(f"Found {len(listResultENV)} results in namespace {current_namespace}")
                                            else:
                                                logger.info(f"No results found in namespace {current_namespace}")

                                            listResultENV = None
                                        else:
                                            logger.error(f"Date directory does not exist: {date_workdir}")
                                    else:
                                        logger.warning(f"No date directories found in namespace {current_namespace}")
                                else:
                                    logger.error(f"Namespace directory does not exist: {namespace_path}")

                        workdir = path.join(repositories, environment, cluster)
                    except OSError as e:
                        logger.error(f"Error accessing directory {workdir}: {e}")
                        return []
            region = None
        else:
            logger.error(f"cronjobs data does not exists or is inaccessible in path {workdir}")
                
        logger.info(f'FINISHED search for cluster repositories {cluster.upper()} in {environment.upper()}')
    if listResult and len(listResult) == 0:
        dictResult["result"] = []
    else:
        dictResult["result"] = listResult
        
        now = datetime.now()
        now = now.strftime('%Y%m%d-%H%M')
        outputfile = repositories + separator + environment + separator + "resultSearch." + now + ".json"
        try:
            remove(outputfile)
        except OSError:
            pass
        with open(outputfile, "a") as fileresult:
            jsonDump(dictResult, fileresult)

        df = json_normalize(listResult)
        outputfile = repositories + separator + environment + separator + "resultSearch." + now + ".csv"
        df = df.fillna(value="Not informed")
        df.to_csv(outputfile, index = False, encoding = "utf-8")
    
    logger.info(f'FINISHED search in {environment.upper()}')

    return dictResult["result"]

async def cronjobsSearchPatternTreatment(functional_environment, cluster, auth, ldap, pattern, region=None, namespace=None, cronjobs=None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                resultSearch = await searchPattern(functional_environment, cluster, region, namespace, cronjobs, pattern)
                return resultSearch
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            resultSearch = await searchPattern(functional_environment, cluster, region, namespace, cronjobs, pattern)
            return resultSearch