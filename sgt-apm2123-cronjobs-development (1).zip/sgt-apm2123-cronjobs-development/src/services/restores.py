from shuttlelib.utils.logger import logger
from shuttlelib.middleware.authorization import is_authorized_user
from fastapi import HTTPException
from src.services.clientunique import client, entity_id, mg, ssl_verify
from src.services.backups import getCronjobsBackupListPvc, getCronjobsBackupListMongo
from src.services.audit import cronjobAuditRecordMongo, cronjobAuditRecordPvc, searchAuditPvc
from sys import platform
from os import path, getenv
from yaml import safe_load

import aiohttp

mongoCollectionBackups = (getenv("COLLECTION", "cronjobs_backups")).lower()

if mg is None:
    logger.warning("MongoDB client not available - MongoDB restore features will be disabled")
else:    
    logger.info(f"MongoDB restore collection will use: {mongoCollectionBackups}")

if platform == "win32":
    repositoryBackup = r"C:\Temp\cronjobsBackups"
else:
    repositoryBackup = r"/tmp/cronjobsBackups"

async def getCronjobsRestorePvc(functional_environment, cluster, region, namespace, date, cronjobsRestore, cronjobsBackup):
    resultRestoreCronjobList = []
    id = 0
  
    if cronjobsRestore is None:
        cronjobsRestore = "all"
    
    if region is None:
        region = "both"
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]

    for region in regionList:
        clientData = client.clusters[functional_environment][cluster].get(region, None)
        
        if clientData is None:
            break
        
        urlApi = clientData.get("url", None)
        token =  clientData.get("token", None)
        
        baseDir = path.join(repositoryBackup, functional_environment, cluster, region, namespace, date)

        cronjobsBackupName = [entry for entry in cronjobsBackup if entry['region'] == region for entry in entry['cronjobs']]
        
        if cronjobsRestore and "," in cronjobsRestore:
            cronjobsRestoreName = [entry.strip() for entry in cronjobsRestore.split(",")]
        elif cronjobsRestore.lower() == "all":
            cronjobsRestoreName = cronjobsBackupName
        else:
            cronjobsRestoreName = [entry for entry in cronjobsBackupName if entry.startswith(cronjobsRestore)]
        
        if cronjobsRestoreName and len(cronjobsRestoreName) > 0 and cronjobsBackupName and len(cronjobsBackupName) > 0:
            for cronjobRestoreName in cronjobsRestoreName:
                if ".yaml" not in cronjobRestoreName:
                    cronjobRestoreName = cronjobRestoreName + ".yaml"
                if cronjobRestoreName in cronjobsBackupName:
                    CronjobFileToRestore = cronjobRestoreName
                    CronjobNameToRestore = cronjobRestoreName.split(".")[0]
                    CronjobFileToRestore = path.join(baseDir, cronjobRestoreName)

                    if path.isfile(CronjobFileToRestore):
                        with open (CronjobFileToRestore, "r") as file:
                            try:
                                cronjobData = safe_load(file)
                            except:
                                cronjobData = []
        
                    if cronjobData != []:
                        requestUrl = urlApi + "/apis/batch/v1/namespaces/" + namespace + "/cronjobs/" + CronjobNameToRestore
                        headers = {"Authorization": "Bearer " + token, "Content-Type": "application/json"}
                        body = cronjobData

                        try:
                            async with aiohttp.ClientSession() as session:
                                async with session.put(requestUrl, headers=headers, json=body, ssl=ssl_verify, timeout=aiohttp.ClientTimeout(total=10)) as answer:
                                    status_code = answer.status
                                    reason = answer.reason
                                    
                                    # ✅ Si cronjob no existe (404), crearlo con POST
                                    if status_code == 404:
                                        requestUrl = urlApi + "/apis/batch/v1/namespaces/" + namespace + "/cronjobs/"
                                        async with session.post(requestUrl, headers=headers, json=body, ssl=ssl_verify, timeout=aiohttp.ClientTimeout(total=10)) as create_answer:
                                            status_code = create_answer.status
                                            reason = create_answer.reason
                        except aiohttp.ClientConnectorError:
                            logger.error(f'Connection error. Cannot connect to {urlApi}')
                            status_code = 408
                            reason = 'Connection error'
                        except aiohttp.ServerTimeoutError:
                            logger.error(f'Timeout restoring cronjob {CronjobNameToRestore}')
                            status_code = 408
                            reason = 'Timeout'
                        except Exception as e:
                            logger.error(f'Error restoring cronjob {CronjobNameToRestore}: {e}')
                            status_code = 500
                            reason = f'Error: {str(e)}'


                        id += 1
                        resultRestoreCronjob = {
                                                'id': id,
                                                'cluster': cluster,
                                                'region': region,
                                                'namespace': namespace,
                                                'cronjob': CronjobNameToRestore,
                                                'status': status_code,
                                                'reason': "OK" if status_code == 200 else reason
                                                }
                        resultRestoreCronjobList.append(resultRestoreCronjob)

                        logger.info(f"answer {status_code} in restore process ({namespace} > {region} > {CronjobNameToRestore})")
            logger.info(f"finish in {region} > restore process ({namespace} > {cronjobsRestore})")
        else:
            logger.info(f"no match in restore process ({namespace} > {region} with {cronjobsRestore})")

    return resultRestoreCronjobList

async def getCronjobsRestoreMongo(functional_environment, cluster, region, namespace, date, cronjobsRestore, cronjobsBackup):
    resultRestoreCronjobList = []
    id = 0

    try:
        if mg is not None:
            mg.change_collection(mongoCollectionBackups)
            logger.debug(f"Switched to MongoDB backups collection: {mongoCollectionBackups}")
        else:
            logger.error("MongoDB client not available")
            return []
    
        if cronjobsRestore is None:
            cronjobsRestore = "all"

        if region is None:
            region = "both"
        if "both" in region:
            regionList = list(client.clusters[functional_environment][cluster])
        else:
            regionList = [region]

        for backup_entry in cronjobsBackup:
            entry_region = backup_entry.get('region')
            cronjobs_list = backup_entry.get('cronjobs', [])

            if entry_region not in regionList:
                continue
            
            if cronjobsRestore and "," in cronjobsRestore:
                cronjobsRestoreList = [entry.strip() for entry in cronjobsRestore.split(",")]
                cronjobsRestoreList = [cj if cj.endswith('.yaml') else f"{cj}.yaml" for cj in cronjobsRestoreList]
            elif cronjobsRestore.lower() == "all":
                cronjobsRestoreList = cronjobs_list
            else:
                cronjobsRestoreList = [cj for cj in cronjobs_list if cj.startswith(cronjobsRestore)]

            for cronjob_filename in cronjobsRestoreList:
                if cronjob_filename not in cronjobs_list:
                    continue
                cronjob_name = cronjob_filename.replace('.yaml', '')

                try:
                    query_filter = {
                        "environment": functional_environment,
                        "cluster": cluster,
                        "region": entry_region,
                        "namespace": namespace,
                        "date": date,
                        "cronjob_name": cronjob_name
                    }

                    backup = mg._collection.find_one(query_filter)

                    if not backup:
                        logger.warning(f"No MongoDB backup found for cronjob {cronjob_name}")
                        continue
                    
                    yaml_content = backup.get('yaml_content', '')
                    if not yaml_content:
                        logger.error(f"Empty YAML content for cronjob {cronjob_name}")
                        continue
                    
                    cronjobData = safe_load(yaml_content)
                    if not cronjobData:
                        logger.error(f"Invalid YAML content for cronjob {cronjob_name}")
                        continue
                    
                    clientData = client.clusters[functional_environment][cluster].get(entry_region, None)
                    if clientData is None:
                        logger.warning(f"No client data found for {functional_environment}/{cluster}/{entry_region}")
                        continue
                    
                    urlApi = clientData.get("url", None)
                    token = clientData.get("token", None)

                    requestUrl = f"{urlApi}/apis/batch/v1/namespaces/{namespace}/cronjobs/{cronjob_name}"
                    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

                    try:
                        async with aiohttp.ClientSession() as session:
                            async with session.put(requestUrl, headers=headers, json=cronjobData, ssl=ssl_verify, timeout=aiohttp.ClientTimeout(total=10)) as answer:
                                status_code = answer.status
                                reason = answer.reason

                                # ✅ Si cronjob no existe (404), crearlo con POST
                                if status_code == 404:
                                    requestUrl = f"{urlApi}/apis/batch/v1/namespaces/{namespace}/cronjobs/"
                                    async with session.post(requestUrl, headers=headers, json=cronjobData, ssl=ssl_verify, timeout=aiohttp.ClientTimeout(total=10)) as create_response:                                
                                        status_code = create_response.status
                                        reason = create_response.reason

                                reason = "OK" if status_code == 200 else reason
                    except aiohttp.ClientConnectorError:
                        logger.error(f'Connection error restoring {cronjob_name}. Cannot connect to {urlApi}')
                        status_code = 408
                        reason = f"Connection error to {urlApi}"
                    except aiohttp.ServerTimeoutError:
                        logger.error(f'Timeout restoring {cronjob_name}')
                        status_code = 408
                        reason = "Timeout"
                    except Exception as e:
                        logger.error(f'Error restoring {cronjob_name}: {e}')
                        status_code = 500
                        reason = f"Restore error: {str(e)}"

                    id += 1
                    resultRestoreCronjob = {
                        'id': id,
                        'cluster': cluster,
                        'region': entry_region,
                        'namespace': namespace,
                        'cronjob': cronjob_name,
                        'status': status_code,
                        'reason': reason,
                        'repository': None
                    }
                    resultRestoreCronjobList.append(resultRestoreCronjob)                
                    logger.info(f"Restore completed for {cronjob_name} in {namespace}/{entry_region} with status {status_code}")

                except Exception as e:
                    logger.error(f"Error processing backup for {cronjob_name}: {e}")
                    id += 1
                    resultRestoreCronjob = {
                        'id': id,
                        'cluster': cluster,
                        'region': entry_region,
                        'namespace': namespace,
                        'cronjob': cronjob_name,
                        'status': 500,
                        'reason': f"Processing error: {str(e)}",
                        'repository': None
                    }
                    resultRestoreCronjobList.append(resultRestoreCronjob)
            logger.info(f"Completed MongoDB restore for region {entry_region}: {len(resultRestoreCronjobList)} cronjobs processed")
    except Exception as e:
        logger.error(f"Error retrieving MongoDB restore: {e}")
        return None
    
    return resultRestoreCronjobList

async def cronjobsRestorePvcTreatment(functional_environment, cluster, auth, ldap, region, namespace, date, cronjobsRestore = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                
                logger.info(f"starting cronjobRestore PVC process (backup date to restore: {date})")
                cronjobsBackups = await getCronjobsBackupListPvc(functional_environment, cluster, region, namespace, cronjobsRestore, date)
                if cronjobsBackups and len(cronjobsBackups) > 0:
                    resultRestore = await getCronjobsRestorePvc(functional_environment, cluster, region, namespace, date, cronjobsRestore, cronjobsBackups)
                    if resultRestore and len(resultRestore) > 0:
                        await cronjobAuditRecordPvc(ldap, functional_environment, cluster, resultRestore, "restores", date, region)
                        #await cronjobAuditRecordMongo(ldap, functional_environment, cluster, resultRestore, "restores", date)
                    else:
                        logger.error(f"Cronjob backup file not found")
                        raise HTTPException(status_code=404, detail="cronjobs not exist")
                else:
                    logger.error(f"Cronjob backup file not found")
                    raise HTTPException(status_code=404, detail="cronjobs not exist")
                logger.info(f"finished cronjobRestore PVC process (backup date to restore: {date})")
                return resultRestore
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:            
            logger.info(f"starting cronjobRestore PVC process")
            cronjobsBackups = await getCronjobsBackupListPvc(functional_environment, cluster, region, namespace, cronjobsRestore, date)
            if cronjobsBackups and len(cronjobsBackups) > 0:
                resultRestore = await getCronjobsRestorePvc(functional_environment, cluster, region, namespace, date, cronjobsRestore, cronjobsBackups)
                if resultRestore and len(resultRestore) > 0:
                    await cronjobAuditRecordPvc(ldap, functional_environment, cluster, resultRestore, "restores", date, region)
                    #await cronjobAuditRecordMongo(ldap, functional_environment, cluster, resultRestore, "restores", date)
                else:
                    logger.error(f"Cronjob backup file not found")
                    raise HTTPException(status_code=404, detail="cronjobs not exist")
            else:
                logger.error(f"Cronjob backup file not found")
                raise HTTPException(status_code=404, detail="cronjobs not exist")
            logger.info(f"finished cronjobRestore PVC process") 
            return resultRestore

async def cronjobsRestoreMongoTreatment(functional_environment, cluster, auth, ldap, region, namespace, date, cronjobsRestore = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                
                logger.info(f"starting cronjobRestore MONGO process (backup date to restore: {date})")
                cronjobsBackups = await getCronjobsBackupListMongo(functional_environment, cluster, region, namespace, cronjobsRestore, date)
                if cronjobsBackups and len(cronjobsBackups) > 0:
                    resultRestore = await getCronjobsRestoreMongo(functional_environment, cluster, region, namespace, date, cronjobsRestore, cronjobsBackups)
                    if resultRestore and len(resultRestore) > 0:
                        #await cronjobAuditRecordPvc(ldap, functional_environment, cluster, resultRestore, "restores", date, region)
                        await cronjobAuditRecordMongo(ldap, functional_environment, cluster, resultRestore, "restores", date)
                    else:
                        logger.error(f"Cronjob backup MONGO not found")
                        raise HTTPException(status_code=404, detail="cronjobs not exist")
                else:
                    logger.error(f"Cronjob backup MONGO not found")
                    raise HTTPException(status_code=404, detail="cronjobs not exist")
                logger.info(f"finished cronjobRestore MONGO process (backup date to restore: {date})")
                return resultRestore
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:            
            logger.info(f"starting cronjobRestore MONGO process")
            cronjobsBackups = await getCronjobsBackupListMongo(functional_environment, cluster, region, namespace, cronjobsRestore, date)
            if cronjobsBackups and len(cronjobsBackups) > 0:
                resultRestore = await getCronjobsRestoreMongo(functional_environment, cluster, region, namespace, date, cronjobsRestore, cronjobsBackups)
                if resultRestore and len(resultRestore) > 0:
                    #await cronjobAuditRecordPvc(ldap, functional_environment, cluster, resultRestore, "restores", date, region)
                    await cronjobAuditRecordMongo(ldap, functional_environment, cluster, resultRestore, "restores", date)
                else:
                    logger.error(f"Cronjob backup MONGO not found")
                    raise HTTPException(status_code=404, detail="cronjobs not exist")
            else:
                logger.error(f"Cronjob backup MONGO not found")
                raise HTTPException(status_code=404, detail="cronjobs not exist")
            logger.info(f"finished cronjobRestore MONGO process")
            return resultRestore

async def cronjobsRestoresAuditPvTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None, date= None, user= None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                return await searchAuditPvc(functional_environment, cluster, region, namespace, date, user, "restores")
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await searchAuditPvc(functional_environment, cluster, region, namespace, date, user, "restores")
