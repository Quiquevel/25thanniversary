from shuttlelib.utils.logger import logger
from shuttlelib.middleware.authorization import is_authorized_user
from aiohttp import client_exceptions
from fastapi import HTTPException, Response
from src.services.clientunique import client, entity_id, mg
from src.services.audit import cronjobAuditRecordMongo, cronjobAuditRecordPvc, searchAuditPvc
from sys import platform
from os import path, makedirs, listdir, getenv, remove, walk, replace
from datetime import datetime, timedelta
from io import BytesIO
from shutil import rmtree
from yaml import dump as yamlDump, YAMLError
from zipfile import ZipFile, ZIP_DEFLATED
from re import fullmatch
from bson import ObjectId

retentionDays = int((getenv("RETENTION_BCKS_DAYS","30")))
mongoCollectionBackups = (getenv("COLLECTION", "cronjobs_backups")).lower()

if mg is None:
    logger.warning("MongoDB client not available - MongoDB backup features will be disabled")
else:    
    logger.info(f"MongoDB backup collection will use: {mongoCollectionBackups}")

if platform == "win32":
    repositoryBackup = r"C:\Temp\cronjobsBackups"
else:
    repositoryBackup = r"/tmp/cronjobsBackups"

async def isValidENV(environment):
    regex = r"^[a-zA-Z0-9-]+$"
    
    if fullmatch(regex, environment):
        return True
    else:
        return False

async def getcronjobBackup(functional_environment, cluster, region, namespace):
    resultBackupPVC = []
    resultBackupMongo = []
    pvc_success = False
    mongo_success = False
    errors = []
    
    logger.info(f"Cronjob backup process started for {functional_environment}/{cluster}/{namespace}")
    logger.info(f"Cronjob backup PVC-> started")
    resultBackupPVC = await getCronjobsBackupPvc(functional_environment, cluster, region, namespace)
    if resultBackupPVC and len(resultBackupPVC) > 0:
        failed_pvc = [item for item in resultBackupPVC if item.get('status', 500) != 200]
    
        if not failed_pvc:
            pvc_success = True
            logger.info(f"PVC backup completed successfully: {len(resultBackupPVC)} cronjobs backed up")
        else:
            errors.append(f"PVC backup had {len(failed_pvc)}/{len(resultBackupPVC)} failures")
            logger.error(f"PVC backup had failures: {len(failed_pvc)}/{len(resultBackupPVC)}")

        await cronjobAuditRecordPvc("shuttlecronjob", functional_environment, cluster, resultBackupPVC, "backups", None, region)
        #await cronjobAuditRecordMongo("shuttlecronjob", functional_environment, cluster, resultBackupPVC, "backups", None)
    logger.info(f"Cronjob backup PVC-> completed")
    

    logger.info(f"Cronjob backup Mongo-> started")
    resultBackupMongo = await getCronjobsBackupMongo(functional_environment, cluster, region, namespace)
    if resultBackupMongo and len(resultBackupMongo) > 0:
        failed_mongo = [item for item in resultBackupMongo if item.get('status', 500) != 200]
        
        if not failed_mongo:
            mongo_success = True
            logger.info(f"MongoDB backup completed successfully: {len(resultBackupMongo)} cronjobs backed up")
        else:
            errors.append(f"MongoDB backup had {len(failed_mongo)}/{len(resultBackupMongo)} failures")
            logger.error(f"MongoDB backup had failures: {len(failed_mongo)}/{len(resultBackupMongo)}")

        await cronjobAuditRecordMongo("shuttlecronjob", functional_environment, cluster, resultBackupMongo, "backups", None)
        #await cronjobAuditRecordPvc("shuttlecronjob", functional_environment, cluster, resultBackupPVC, "backups", None, region)
    logger.info(f"Cronjob backup Mongo-> completed")

    combined_results = resultBackupPVC + resultBackupMongo

    if pvc_success and mongo_success:
        if combined_results and len(combined_results) == 0:
            http_status = 200
            message = "No cronjobs found to backup"
        else:
            http_status = 200
            message = f"Backup completed successfully: {len(resultBackupPVC)} PVC + {len(resultBackupMongo)} MongoDB"
    elif pvc_success or mongo_success:
        http_status = 207
        message = f"Partial success - PVC: {'✓' if pvc_success else '✗'}, MongoDB: {'✓' if mongo_success else '✗'}"
    else:
        http_status = 500
        message = "Both PVC and MongoDB backups failed"

    result = {
        "http_status": http_status,
        "message": message,
        "summary": {
            "pvc_backup": {
                "success": pvc_success,
                "count": len(resultBackupPVC),
                "failed": len([item for item in resultBackupPVC if item.get('status', 500) != 200])
            },
            "mongodb_backup": {
                "success": mongo_success,
                "count": len(resultBackupMongo),
                "failed": len([item for item in resultBackupMongo if item.get('status', 500) != 200])
            }
        },
        "errors": errors,
        "results": combined_results,
        "timestamp": datetime.now().isoformat()
    }
    
    try:
        logger.info(f"Starting automatic backup retention process after PVC backup completion")
        await processBackupRetentionPvc()
        logger.info(f"Automatic backup retention process completed successfully")
    except Exception as e:
        logger.error(f"Warning: Backup retention process failed after backup: {e}")
        logger.warning(f"Backup was successful, but retention process encountered an error")

    logger.info(f"Backup process for {functional_environment}/{cluster}/{namespace} completed with status {http_status}: {message}")
    return result

async def getCronjobsBackupPvc(functional_environment, cluster, region, namespace):
    cronjobList = []
    namespaceList = []
    resultBackupCronjobList = []
    
    fieldsToRemove = ['status']
    fieldsToRemoveMetadata = ['uid', 'generation', 'resourceVersion', 'creationTimestamp', 'managedFields']
         
    baseDir = path.join(repositoryBackup, functional_environment, cluster)
    makedirs(baseDir, exist_ok=True)
    
    if region is None:
        region = "both"
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]

    if namespace is None:
        for region in regionList:
            try:
                namespaceList = await client.get_resource(resource = "namespaces", functional_environment = functional_environment, cluster = cluster, region = region)
            except client_exceptions.ClientConnectorError:
                logger.error(f"Timeout detected....")
                continue
            except:
                logger.error(f"namespaces could not be retrieved. Skipping...")
                continue
            
            try:
                items = namespaceList[region]['items']
            except:
                items = None
                
            if items and len(items) > 0:
                namespaceList = items
                for namespace in namespaceList:
                    namespaceName = namespace['metadata']['name']
                    try:
                        cronjobList = await client.get_resource(resource = "cronjobs", functional_environment = functional_environment, cluster = cluster, region = region, namespace = namespaceName)
                    except client_exceptions.ClientConnectorError:
                        logger.error(f"Timeout detected....")
                        continue
                    except:
                        logger.error(f"cronjobs could not be retrieved. Skipping...")
                        continue
    
                    try:
                        items = cronjobList[region]['items']
                    except:
                        items = None
                    if items and len(items) > 0:
                        cronjobList = items
                        
                        namespaceDir = path.join(baseDir, region, namespaceName)
                        makedirs(namespaceDir, exist_ok=True)
                        currentDate = datetime.now().strftime('%Y-%m-%d')
                        dateDir = path.join(namespaceDir, currentDate)
                        if not path.exists(dateDir):
                            makedirs(dateDir)
                        
                        for cronjob in cronjobList:
                            status = 200
                            error = None
                            
                            try:
                                metadata = cronjob['metadata']
                                name = metadata.get('name', None)
                                namespace = metadata.get('namespace', None)

                                cronjob['kind'] = "CronJob"
                                cronjob['apiVersion'] = "batch/v1"

                                for field in fieldsToRemove:
                                    if field in cronjob:
                                        del cronjob[field]

                                cronjobFileYAML = name + ".yaml"
                                backupPath = path.join(dateDir, cronjobFileYAML)
                                with open(backupPath, "w") as file:
                                    yamlDump(cronjob, file, default_flow_style=False)
                                
                                if path.isfile(backupPath) and path.getsize(backupPath) > 0:
                                    status = 200
                                    logger.info(f"Successfully downloaded backup file {cronjobFileYAML} from {cluster}/{region}/{namespace}")
                                
                            except PermissionError as e:
                                status = 403
                                error = f"Permission denied writing file: {e}"
                                logger.error(f"Permission error for {cronjobFileYAML} in {cluster}/{region}/{namespace}: {e}")
                            except OSError as e:
                                status = 500
                                error = f"OS error writing file: {e}"
                                logger.error(f"OS error for {cronjobFileYAML} in {cluster}/{region}/{namespace}: {e}")
                            except YAMLError as e:
                                status = 422
                                error = f"YAML serialization error: {e}"
                                logger.error(f"YAML error for {cronjobFileYAML} in {cluster}/{region}/{namespace}: {e}")
                            except Exception as e:
                                status = 500
                                error = f"Unexpected error: {e}"
                                logger.error(f"Unexpected error processing {cronjobFileYAML} in {cluster}/{region}/{namespace}: {e}")

                            resultBackupCronjob = {
                                'cluster': cluster,
                                'region': region,
                                'namespace': namespace,
                                'cronjob': cronjobFileYAML,
                                'status': status,
                                'reason': "OK" if error is None else str(error),
                                'repository': dateDir
                            }
                            resultBackupCronjobList.append(resultBackupCronjob)
    else:
        for region in regionList:
         
            namespaceDir = path.join(baseDir, region, namespace)
            makedirs(namespaceDir, exist_ok=True)
            
            currentDate = datetime.now().strftime('%Y-%m-%d')
            dateDir = path.join(namespaceDir, currentDate)
          
            if not path.exists(dateDir):
                makedirs(dateDir)
            
            try:
                cronjobList = await client.get_resource(resource = "cronjobs", functional_environment = functional_environment, cluster = cluster, region = region, namespace = namespace)
            except client_exceptions.ClientConnectorError:
                logger.error(f"Timeout detected....")
                continue
            except:
                logger.error(f"cronjobs could not be retrieved. Skipping...")
                continue

            try:
                items = cronjobList[region]['items']
            except:
                items = None
            if items and len(items) > 0:
                cronjobList = items
                for cronjob in cronjobList:
                    status = 200
                    error = None

                    try:
                        metadata = cronjob['metadata']
                        name = metadata.get('name', None)
                        namespace = metadata.get('namespace', None)

                        cronjob['kind'] = "CronJob"
                        cronjob['apiVersion'] = "batch/v1"

                        for field in fieldsToRemove:
                            if field in cronjob:
                                del cronjob[field]

                        for field in fieldsToRemoveMetadata:
                            if field in cronjob['metadata']:
                                del cronjob['metadata'][field]

                        cronjobFileYAML = name + ".yaml"
                        backupPath = path.join(dateDir, cronjobFileYAML)
                        backupPath = path.normpath(backupPath)

                        with open(backupPath, "w") as file:
                            yamlDump(cronjob, file, default_flow_style=False)

                        if path.isfile(backupPath) and path.getsize(backupPath) > 0:
                            status = 200
                            logger.info(f"Successfully downloaded backup file {cronjobFileYAML} from {cluster}/{region}/{namespace}")

                    except PermissionError as e:
                        status = 403
                        error = f"Permission denied writing file: {e}"
                        logger.error(f"Permission error for {cronjobFileYAML} in {cluster}/{region}/{namespace}: {e}")
                    except OSError as e:
                        status = 500
                        error = f"OS error writing file: {e}"
                        logger.error(f"OS error for {cronjobFileYAML} in {cluster}/{region}/{namespace}: {e}")
                    except YAMLError as e:
                        status = 422
                        error = f"YAML serialization error: {e}"
                        logger.error(f"YAML error for {cronjobFileYAML} in {cluster}/{region}/{namespace}: {e}")
                    except Exception as e:
                        status = 500
                        error = f"Unexpected error: {e}"
                        logger.error(f"Unexpected error processing {cronjobFileYAML} in {cluster}/{region}/{namespace}: {e}")
                    resultBackupCronjob = {
                        'cluster': cluster,
                        'region': region,
                        'namespace': namespace,
                        'cronjob': cronjobFileYAML,
                        'status': status,
                        'reason': "OK" if error is None else str(error),
                        'repository': dateDir
                    }
                    resultBackupCronjobList.append(resultBackupCronjob)

    return resultBackupCronjobList

async def getCronjobsBackupListPvc(functional_environment, cluster, region, namespace, cronjobs, date):
    filesListBackupbyDate = []
    id = 0
        
    if region is None:
        region = "both"
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]
    
    clusterDir = path.join(repositoryBackup, functional_environment, cluster)
    if not path.isdir(clusterDir):
        return []
    
    for region in regionList:
        regionDir = path.join(clusterDir, region)
        if not path.isdir(regionDir):
            continue

        if namespace:
            namespaceList = [namespace]
        else:
            namespaceList = [dir for dir in listdir(regionDir) if path.isdir(path.join(regionDir, dir))]

        for namespace in namespaceList:
            namespaceDir = path.join(regionDir, namespace)
            if not path.isdir(namespaceDir):
                continue

            if date:
                dateList = [date]
            else:
                dateList = [dir for dir in listdir(namespaceDir) if path.isdir(path.join(namespaceDir, dir))]
            for day in dateList:
                dateDir = path.join(namespaceDir, day)
                if not path.isdir(dateDir):
                    continue

                try:
                    filesInDir = [file for file in listdir(dateDir) if path.isfile(path.join(dateDir, file)) and file.endswith('.yaml')]
                    if filesInDir:
                        id += 1
                        filesBackupbyDate = {
                            'id': id,
                            'cluster': cluster,
                            'region': region,
                            'namespace': namespace,
                            'date': day,
                            'cronjobs': filesInDir
                        }
                        filesListBackupbyDate.append(filesBackupbyDate)
                        
                except OSError as e:
                    logger.error(f"Error accessing directory {dateDir}: {e}")
                    continue

    if cronjobs:
        for entry in filesListBackupbyDate:
            if "," not in cronjobs:
                if cronjobs.endswith('.yaml'):
                    entry['cronjobs'] = [cj for cj in entry['cronjobs'] if cj == cronjobs]
                else:
                    entry['cronjobs'] = [cj for cj in entry['cronjobs'] if cj.startswith(cronjobs)]
            else:
                cronjobsToFind = [cj.strip() for cj in cronjobs.split(",")]
                entry['cronjobs'] = [cj for cj in entry['cronjobs'] if any(
                    cj == target or cj.startswith(target.rstrip('.yaml')) 
                    for target in cronjobsToFind)]
    
    filesListBackupbyDate = [entry for entry in filesListBackupbyDate if entry['cronjobs']]

    return filesListBackupbyDate

async def getCronjobsBackupDownloadPvc(functional_environment, cluster, region, namespace, date, cronjobs):
    baseDir = path.join(repositoryBackup, functional_environment, cluster, region, namespace, date)
    
    if cronjobs is None:
        if not path.isdir(baseDir):
            return None
            
        try:
            zip_buffer = BytesIO()            
            with ZipFile(zip_buffer, 'w', ZIP_DEFLATED) as zip_file:
                yaml_files = [f for f in listdir(baseDir) if f.endswith('.yaml')]
                if not yaml_files:
                    logger.warning(f"No YAML files found in {baseDir}")
                    return None
                for yaml_file in yaml_files:
                    file_path = path.join(baseDir, yaml_file)
                    if path.isfile(file_path):
                        zip_file.write(file_path, yaml_file)
                        logger.info(f"Added {yaml_file} to ZIP")
            zip_buffer.seek(0)
            zip_content = zip_buffer.getvalue()
            zip_buffer.close()
            return zip_content
        except Exception as e:
            logger.error(f"Error creating ZIP file: {e}")
            return None
    else:
        if ".yaml" not in cronjobs:
            cronjobs = cronjobs + ".yaml"
        cronjobFileToDownload = path.join(baseDir, cronjobs)
        if path.isfile(cronjobFileToDownload):
            with open(cronjobFileToDownload, "r", encoding='utf-8') as file:
                try:
                    cronjobData = file.read()
                    return cronjobData
                except Exception as e:
                    logger.error(f"Error loading YAML file: {e}")
                    return None
        else:
            logger.warning(f"File not found: {cronjobFileToDownload}")
            return None

async def processBackupRetentionPvc():
    logger.info("=== STARTING MONTHLY RETENTION PROCESS ===")

    if not path.isdir(repositoryBackup):
        logger.warning(f"BCKs repositories does not exists or is inaccessible in path {repositoryBackup}")
        return

    try:
        environments = [env for env in listdir(repositoryBackup) if path.isdir(path.join(repositoryBackup, env))]
    except OSError as e:
        logger.error(f"Error accessing backup repository{repositoryBackup}: {e}")
        return
    for environment in environments:
        env_path = path.join(repositoryBackup, environment)
        logger.info(f"Processing environment: {environment}")
        
        try:
            clusters = [cluster for cluster in listdir(env_path) if path.isdir(path.join(env_path, cluster))]
        except OSError:
            continue
        for cluster in clusters:
            cluster_path = path.join(env_path, cluster)
            logger.info(f"Processing cluster: {cluster}")
            
            try:
                regions = [region for region in listdir(cluster_path) if path.isdir(path.join(cluster_path, region))]
            except OSError:
                continue                
            for region in regions:
                region_path = path.join(cluster_path, region)
                logger.info(f"Processing region: {region}")

                try:
                    namespaces = [ns for ns in listdir(region_path) if path.isdir(path.join(region_path, ns))]
                except OSError:
                    continue
                for namespace in namespaces:
                    namespace_path = path.join(region_path, namespace)
                    logger.info(f"Processing namespace: {namespace}")
                    
                    date_dirs = await getDateDirectories(namespace_path)
                    if not date_dirs:
                        logger.info(f"No date directories found in {namespace}")
                        continue

                    cutoff_date = datetime.now() - timedelta(days=retentionDays)
                    recent_dates, old_dates_by_month = await classifyBackupDates(date_dirs, cutoff_date)
                    logger.info(f"Found {len(recent_dates)} recent backups")

                    if not old_dates_by_month:
                        logger.info(f"No old backups to consolidate in {namespace}")
                        continue
                    total_old = sum(len(dates) for dates in old_dates_by_month.values())
                    logger.info(f"Found {total_old} old backups in {len(old_dates_by_month)} months")

                    for month_key, dates in old_dates_by_month.items():
                        logger.info(f"Consolidating month {month_key} ({len(dates)} days)")
                        await monthlyBackuptoZIP(namespace_path, month_key, dates)

    logger.info("=== RETENTION PROCESS COMPLETED ===")

async def getDateDirectories(namespace_path):
    date_dirs = []

    try:
        items = [item for item in listdir(namespace_path) if path.isdir(path.join(namespace_path, item))]
    except OSError:
        return date_dirs        
    for item in items:
        try:
            date_obj = datetime.strptime(item, "%Y-%m-%d")
            date_dirs.append(date_obj)
        except ValueError:
            continue

    return sorted(date_dirs)

async def classifyBackupDates(date_dirs, cutoff_date):
    recent_dates = []
    old_dates_by_month = {}
    
    for date_obj in date_dirs:
        if date_obj >= cutoff_date:
            recent_dates.append(date_obj)
        else:
            month_key = date_obj.strftime("%Y-%m")
            if month_key not in old_dates_by_month:
                old_dates_by_month[month_key] = []
            old_dates_by_month[month_key].append(date_obj)

    return recent_dates, old_dates_by_month

async def monthlyBackuptoZIP(namespace_path, month_key, dates):
    zip_filename = f"{month_key}_monthly_backup.zip"
    zip_path = path.join(namespace_path, zip_filename)
    
    if path.exists(zip_path):
        logger.info(f"Monthly ZIP already exists: {zip_filename}, cleaning daily backups")        
        existing_dates_in_zip = await getZipContentDates(zip_path)
        
        new_dates = []
        for date_obj in dates:
            date_str = date_obj.strftime("%Y-%m-%d")
            if date_str not in existing_dates_in_zip:
                date_dir = path.join(namespace_path, date_str)
                if path.exists(date_dir) and path.isdir(date_dir):
                    new_dates.append(date_obj)
                    logger.info(f"Found new date to add: {date_str}")

        if new_dates:
            await updateZipWithNewDates(zip_path, namespace_path, new_dates)
        else:
            logger.info(f"No new dates to add to {zip_filename}")
        await removeMonthlyBackup(namespace_path, dates)
        return
    
    logger.info(f"Creating monthly backup: {zip_filename}")
    
    try:
        with ZipFile(zip_path, 'w', ZIP_DEFLATED) as zipf:
            files_added = 0
            
            for date_obj in sorted(dates):
                date_str = date_obj.strftime("%Y-%m-%d")
                date_dir = path.join(namespace_path, date_str)
                
                if path.exists(date_dir) and path.isdir(date_dir):
                    logger.info(f"Adding date: {date_str}")
                    for root, dirs, files in walk(date_dir):
                        for file in files:
                            file_path = path.join(root, file)
                            relative_path = path.relpath(file_path, date_dir)
                            arcname = f"{date_str}/{relative_path}"
                            zipf.write(file_path, arcname)
                            files_added += 1
        logger.info(f"ZIP successfully created: {zip_filename} ({files_added} files)")
        await removeMonthlyBackup(namespace_path, dates)
        
    except Exception as e:
        logger.error(f"Error creating monthly backup {zip_filename}: {e}")
        if path.exists(zip_path):
            try:
                remove(zip_path)
            except OSError:
                pass

async def removeMonthlyBackup(namespace_path, dates):
    dates_by_month = {}
    for date_obj in dates:
        month_key = date_obj.strftime("%Y-%m")
        if month_key not in dates_by_month:
            dates_by_month[month_key] = []
        dates_by_month[month_key].append(date_obj)

    last_days_to_keep = set()
    for month_key, month_dates in dates_by_month.items():
        available_dates = []
        for date_obj in month_dates:
            date_str = date_obj.strftime("%Y-%m-%d")
            date_dir = path.join(namespace_path, date_str)
            if path.exists(date_dir) and path.isdir(date_dir):
                available_dates.append(date_obj)
        if available_dates:
            last_day_of_month = max(available_dates)
            last_days_to_keep.add(last_day_of_month)
            logger.info(f"Keeping last available day of {month_key}: {last_day_of_month.strftime('%Y-%m-%d')}")
        else:
            logger.warning(f"No available directories found for month {month_key}")

    for date_obj in dates:
        if date_obj not in last_days_to_keep:
            date_str = date_obj.strftime("%Y-%m-%d")
            date_dir = path.join(namespace_path, date_str)            
            if path.exists(date_dir) and path.isdir(date_dir):
                try:
                    rmtree(date_dir)
                    logger.info(f"Cleaned directory: {date_str}")
                except Exception as e:
                    logger.error(f"Error cleaning {date_str}: {e}")
        else:
            date_str = date_obj.strftime("%Y-%m-%d")
            logger.info(f"Preserved last day directory: {date_str}")

async def getZipContentDates(zip_path):
    existing_dates = set()
    
    try:
        with ZipFile(zip_path, 'r') as zipf:
            for name in zipf.namelist():
                if '/' in name:
                    date_part = name.split('/')[0]
                    try:
                        datetime.strptime(date_part, "%Y-%m-%d")
                        existing_dates.add(date_part)
                    except ValueError:
                        continue
    except Exception as e:
        logger.error(f"Error reading ZIP content {zip_path}: {e}")

    return existing_dates

async def updateZipWithNewDates(zip_path, namespace_path, new_dates):
    try:
        temp_zip_path = f"{zip_path}.tmp"
        
        with ZipFile(zip_path, 'r') as existing_zip:
            with ZipFile(temp_zip_path, 'w', ZIP_DEFLATED) as new_zip:
                for item in existing_zip.infolist():
                    data = existing_zip.read(item.filename)
                    new_zip.writestr(item, data)
                    
                files_added = 0
                for date_obj in sorted(new_dates):
                    date_str = date_obj.strftime("%Y-%m-%d")
                    date_dir = path.join(namespace_path, date_str)                    
                    if path.exists(date_dir) and path.isdir(date_dir):
                        logger.info(f"Adding new date to ZIP: {date_str}")
                        for root, dirs, files in walk(date_dir):
                            for file in files:
                                file_path = path.join(root, file)
                                relative_path = path.relpath(file_path, date_dir)
                                arcname = f"{date_str}/{relative_path}"
                                new_zip.write(file_path, arcname)
                                files_added += 1
        replace(temp_zip_path, zip_path)
        logger.info(f"ZIP updated incrementally with {files_added} new files")
    except Exception as e:
        logger.error(f"Error updating ZIP incrementally: {e}")
        try:
            if path.exists(temp_zip_path):
                remove(temp_zip_path)
        except OSError:
            pass
        raise

async def getCronjobsBackupMongo(functional_environment, cluster, region, namespace):    
    namespaceList = []
    resultBackupCronjobList = []

    if region is None:
        region = "both"
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]

    if namespace is None:
        # Procesar todos los namespaces
        for region in regionList:
            try:
                namespaceList = await client.get_resource(resource="namespaces", functional_environment=functional_environment, cluster=cluster, region=region)
            except client_exceptions.ClientConnectorError:
                logger.error(f"Timeout detected....")
                continue
            except:
                logger.error(f"namespaces could not be retrieved. Skipping...")
                continue
            
            try:
                items = namespaceList[region]['items']
            except:
                items = None
            if items and len(items) > 0:
                namespaceList = items
                for namespace in namespaceList:
                    namespaceName = namespace['metadata']['name']
                    cronjobs_results = await processCronjobsForMongo(functional_environment, cluster, region, namespaceName)
                    resultBackupCronjobList.extend(cronjobs_results)
    else:
        cronjobs_results = await processCronjobsForMongo(functional_environment, cluster, region, namespace)
        resultBackupCronjobList.extend(cronjobs_results)

    return resultBackupCronjobList

async def processCronjobsForMongo(functional_environment, cluster, region, namespace):
    resultBackupCronjobList = []
    fieldsToRemove = ['status']
    fieldsToRemoveMetadata = ['uid', 'generation', 'resourceVersion', 'creationTimestamp', 'managedFields']

    try:
        cronjobList = await client.get_resource(resource="cronjobs", functional_environment=functional_environment, cluster=cluster, region=region, namespace=namespace)
    except client_exceptions.ClientConnectorError:
        logger.error(f"Timeout detected for {namespace}....")
        return []
    except:
        logger.error(f"cronjobs could not be retrieved for {namespace}. Skipping...")
        return []

    try:
        items = cronjobList[region]['items']
    except:
        items = None
    if items and len(items) > 0:
        cronjobList = items
        cronjobs_for_mongo = {}
        for cronjob in cronjobList:
            status = 200
            error = None
            
            try:
                metadata = cronjob['metadata']
                name = metadata.get('name', None)
                cronjob_namespace = metadata.get('namespace', None)

                # Limpiar datos del cronjob
                cronjob['kind'] = "CronJob"
                cronjob['apiVersion'] = "batch/v1"

                for field in fieldsToRemove:
                    if field in cronjob:
                        del cronjob[field]
                for field in fieldsToRemoveMetadata:
                    if field in cronjob['metadata']:
                        del cronjob['metadata'][field]

                yaml_content = yamlDump(cronjob, default_flow_style=False)
                cronjobs_for_mongo[name] = yaml_content                
                logger.info(f"Successfully processed cronjob {name} from {cluster}/{region}/{namespace}")
                
            except Exception as e:
                status = 500
                error = f"Error processing cronjob: {e}"
                logger.error(f"Error processing cronjob in {cluster}/{region}/{namespace}: {e}")

            resultBackupCronjob = {
                'cluster': cluster,
                'region': region,
                'namespace': cronjob_namespace or namespace,
                'cronjob': f"{name}.yaml" if name else "unknown.yaml",
                'status': status,
                'reason': "OK" if error is None else str(error),
                'repository': "Mongo"
            }
            resultBackupCronjobList.append(resultBackupCronjob)
        
        if cronjobs_for_mongo:
            try:
                mongo_results = await saveCronjobsBackupMongo(
                    functional_environment=functional_environment,
                    cluster=cluster,
                    region=region,
                    namespace=namespace,
                    cronjobData=cronjobs_for_mongo,
                    triggered_by="shuttlecronjob"
                )

                failed_cronjobs = [name for name, success in mongo_results.items() if not success]
                if failed_cronjobs:
                    raise Exception(f"Failed to save {len(failed_cronjobs)} cronjobs to MongoDB: {failed_cronjobs}")
        
                for result_item in resultBackupCronjobList:
                    cronjob_name = result_item['cronjob'].replace('.yaml', '')
                    if cronjob_name in mongo_results:
                        if mongo_results[cronjob_name]:
                            result_item['status'] = 200
                            result_item['error'] = None
                        else:
                            result_item['status'] = 500
                            result_item['error'] = "Failed to save to MongoDB"

                successful_count = sum(1 for success in mongo_results.values() if success)
                logger.info(f"MongoDB backup for {namespace}: {successful_count}/{len(mongo_results)} successful")

            except Exception as e:
                logger.error(f"Error saving to MongoDB for namespace {namespace}: {e}")
                for result_item in resultBackupCronjobList:
                    if result_item['status'] == 200:
                        result_item['status'] = 500
                        result_item['error'] = f"MongoDB save failed: {e}"

                raise HTTPException(status_code=500, detail=f"MongoDB backup failed for namespace {namespace}: {str(e)}")

    return resultBackupCronjobList

async def saveCronjobsBackupMongo(functional_environment, cluster, region, namespace, cronjobData, triggered_by="shuttlecronjob"):
    try:
        if mg is not None:
            mg.change_collection(mongoCollectionBackups)
            logger.debug(f"Switched to MongoDB backups collection: {mongoCollectionBackups}")
        else:
            logger.error("MongoDB client not available")
            return []

        # ✅ OBTENER TIMESTAMP Y FECHA ACTUAL
        timestamp = datetime.now()
        current_date = timestamp.date().isoformat()
        
        # ✅ PREPARAR LISTA DE DOCUMENTOS
        backup_documents = []
        cronjobs_to_delete = []  # ✅ Lista de cronjobs que hay que limpiar
        
        for cronjob_name, yaml_content in cronjobData.items():
            if not yaml_content:
                logger.warning(f"Empty YAML content for cronjob {cronjob_name}, skipping")
                continue
            
            # ✅ AÑADIR A LISTA DE LIMPIEZA
            cronjobs_to_delete.append(cronjob_name)
            
            # ✅ CREAR DOCUMENTO DE BACKUP
            backup_document = {
                "_id": ObjectId(),
                "timestamp": timestamp,
                "date": current_date,
                "environment": functional_environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "cronjob_name": cronjob_name,
                "yaml_content": yaml_content,
                "triggered_by": triggered_by
            }
            backup_documents.append(backup_document)
        
        if not backup_documents:
            logger.warning("No valid backup documents to save")
            return {}
        
        # ✅ ELIMINAR BACKUPS ANTERIORES DEL MISMO DÍA
        if cronjobs_to_delete:
            delete_filter = {
                "environment": functional_environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "date": current_date,
                "cronjob_name": {"$in": cronjobs_to_delete}  # ✅ Solo los cronjobs que vamos a actualizar
            }
            
            try:
                delete_result = mg._collection.delete_many(delete_filter)
                deleted_count = delete_result.deleted_count if delete_result else 0
                
                if deleted_count > 0:
                    logger.info(f"Deleted {deleted_count} existing backups for date {current_date} in {namespace}/{region}")
                    logger.debug(f"Deleted cronjobs: {', '.join(cronjobs_to_delete)}")
                else:
                    logger.info(f"No existing backups found for date {current_date} in {namespace}/{region}")
                    
            except Exception as e:
                logger.warning(f"Error deleting existing backups (continuing anyway): {e}")
                # ✅ NO FALLAR si no puede eliminar - continuar con inserción
        
        # ✅ INSERTAR NUEVOS BACKUPS
        try:
            insert_result = mg._collection.insert_many(backup_documents)
            inserted_count = len(insert_result.inserted_ids) if insert_result else 0
            
            if inserted_count > 0:
                logger.info(f"Successfully saved {inserted_count} cronjob backups to MongoDB for {namespace}/{region}")
                
                # ✅ CREAR RESULTADO DE ÉXITO
                mongo_results = {}
                for doc in backup_documents:
                    cronjob_name = doc['cronjob_name']
                    mongo_results[cronjob_name] = True
                
                return mongo_results
            else:
                raise Exception("No documents were inserted")
                
        except Exception as e:
            logger.error(f"Error inserting backup documents: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to save backups to MongoDB: {str(e)}")
    
    except HTTPException:
        raise  # ✅ Re-lanzar HTTPExceptions
    except Exception as e:
        logger.error(f"Critical error in saveCronjobsBackupMongo: {e}")
        raise HTTPException(status_code=500, detail=f"Critical error: {str(e)}")

async def getCronjobsBackupListMongo(functional_environment, cluster, region, namespace, cronjobs, date):
    try:
        if mg is not None:
            mg.change_collection(mongoCollectionBackups)
            logger.debug(f"Switched to MongoDB backups collection: {mongoCollectionBackups}")
        else:
            logger.error("MongoDB client not available")
            return []

        filesListBackupbyDate = []
        id = 0
        
        if region is None:
            region = "both"
        if "both" in region:
            regionList = list(client.clusters[functional_environment][cluster])
        else:
            regionList = [region]
        
        # ✅ PROCESAR CADA REGIÓN
        for current_region in regionList:
            # ✅ FILTRO BASE DE BÚSQUEDA
            query_filter = {
                "environment": functional_environment,
                "cluster": cluster,
                "region": current_region
            }
            
            # ✅ FILTRAR POR NAMESPACE SI SE ESPECIFICA
            if namespace:
                query_filter["namespace"] = namespace
            
            # ✅ FILTRAR POR FECHA SI SE ESPECIFICA
            if date:
                query_filter["date"] = date
            
            # ✅ BUSCAR EN MONGODB
            backups = mg.find(query_filter)
            
            if not backups:
                continue
            
            # ✅ AGRUPAR POR NAMESPACE Y FECHA
            grouped_backups = {}
            
            for backup in backups:
                backup_namespace = backup.get('namespace', 'unknown')
                backup_date = backup.get('date', 'unknown')
                cronjob_name = backup.get('cronjob_name', 'unknown')
                
                # ✅ CREAR CLAVE ÚNICA POR NAMESPACE + FECHA
                key = f"{backup_namespace}_{backup_date}"
                
                if key not in grouped_backups:
                    grouped_backups[key] = {
                        'namespace': backup_namespace,
                        'date': backup_date,
                        'cronjobs': []
                    }
                
                # ✅ AÑADIR NOMBRE DEL CRONJOB CON EXTENSIÓN .yaml
                cronjob_filename = f"{cronjob_name}.yaml"
                if cronjob_filename not in grouped_backups[key]['cronjobs']:
                    grouped_backups[key]['cronjobs'].append(cronjob_filename)
            
            # ✅ CONVERTIR A FORMATO FINAL
            for group_key, group_data in grouped_backups.items():
                id += 1
                filesBackupbyDate = {
                    'id': id,
                    'cluster': cluster,
                    'region': current_region,
                    'namespace': group_data['namespace'],
                    'date': group_data['date'],
                    'cronjobs': sorted(group_data['cronjobs'])  # ✅ Ordenar alfabéticamente
                }
                filesListBackupbyDate.append(filesBackupbyDate)
        
        # ✅ FILTRAR POR CRONJOBS ESPECÍFICOS SI SE ESPECIFICA
        if cronjobs:
            for entry in filesListBackupbyDate:
                if "," not in cronjobs:
                    # ✅ FILTRO SIMPLE - UN SOLO CRONJOB
                    if cronjobs.endswith('.yaml'):
                        entry['cronjobs'] = [cj for cj in entry['cronjobs'] if cj == cronjobs]
                    else:
                        entry['cronjobs'] = [cj for cj in entry['cronjobs'] if cj.startswith(cronjobs)]
                else:
                    # ✅ FILTRO MÚLTIPLE - VARIOS CRONJOBS SEPARADOS POR COMA
                    cronjobsToFind = [cj.strip() for cj in cronjobs.split(",")]
                    entry['cronjobs'] = [cj for cj in entry['cronjobs'] if any(
                        cj == target or cj.startswith(target.rstrip('.yaml')) 
                        for target in cronjobsToFind)]
        
        # ✅ ELIMINAR ENTRADAS SIN CRONJOBS
        filesListBackupbyDate = [entry for entry in filesListBackupbyDate if entry['cronjobs']]
        
        logger.info(f"Found {len(filesListBackupbyDate)} MongoDB backup entries")
        return filesListBackupbyDate
        
    except Exception as e:
        logger.error(f"Error retrieving MongoDB backup list: {e}")
        return None

async def getCronjobsBackupDownloadMongo(functional_environment, cluster, region, namespace, date, cronjobs):
    try:
        if mg is not None:
            mg.change_collection(mongoCollectionBackups)
            logger.debug(f"Switched to MongoDB backups collection: {mongoCollectionBackups}")
        else:
            logger.error("MongoDB client not available")
            return []
        
        if cronjobs is None:
            # ✅ DESCARGA MÚLTIPLE - CREAR ZIP CON TODOS LOS CRONJOBS
            
            # ✅ FILTRO DE BÚSQUEDA
            query_filter = {
                "environment": functional_environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "date": date
            }
            
            # ✅ BUSCAR TODOS LOS BACKUPS DEL NAMESPACE/FECHA
            backups = mg.find(query_filter)
            
            if not backups:
                logger.warning(f"No MongoDB backups found for {functional_environment}/{cluster}/{region}/{namespace} on {date}")
                return None
            
            try:
                zip_buffer = BytesIO()
                
                with ZipFile(zip_buffer, 'w', ZIP_DEFLATED) as zip_file:
                    files_added = 0
                    
                    for backup in backups:
                        cronjob_name = backup.get('cronjob_name', 'unknown')
                        yaml_content = backup.get('yaml_content', '')
                        
                        if yaml_content:
                            yaml_filename = f"{cronjob_name}.yaml"
                            zip_file.writestr(yaml_filename, yaml_content)
                            logger.info(f"Added {yaml_filename} to ZIP from MongoDB")
                            files_added += 1
                    
                    if files_added == 0:
                        logger.warning(f"No valid YAML content found in MongoDB backups")
                        return None
                        
                zip_buffer.seek(0)
                zip_content = zip_buffer.getvalue()
                zip_buffer.close()
                
                logger.info(f"Created ZIP with {files_added} cronjobs from MongoDB")
                return zip_content
                
            except Exception as e:
                logger.error(f"Error creating ZIP file from MongoDB: {e}")
                return None
                
        else:
            # ✅ DESCARGA INDIVIDUAL - UN SOLO CRONJOB
            
            # ✅ LIMPIAR NOMBRE DEL CRONJOB
            if cronjobs.endswith('.yaml'):
                cronjob_name = cronjobs.replace('.yaml', '')
            else:
                cronjob_name = cronjobs
            
            # ✅ FILTRO ESPECÍFICO
            query_filter = {
                "environment": functional_environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "date": date,
                "cronjob_name": cronjob_name
            }
            
            # ✅ BUSCAR CRONJOB ESPECÍFICO
            backup = mg.find_one(query_filter)
            
            if not backup:
                logger.warning(f"MongoDB backup not found: {cronjob_name} on {date}")
                return None
            
            yaml_content = backup.get('yaml_content', '')
            
            if not yaml_content:
                logger.warning(f"Empty YAML content for cronjob {cronjob_name}")
                return None
            
            logger.info(f"Retrieved cronjob {cronjob_name} from MongoDB")
            return yaml_content
            
    except Exception as e:
        logger.error(f"Error retrieving MongoDB backup: {e}")
        return None

async def cronjobsBackupPvcTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"starting cronjobBackup PVC process")
                resultBackup = await getCronjobsBackupPvc(functional_environment, cluster, region, namespace)
                if resultBackup and len(resultBackup) > 0: 
                    await cronjobAuditRecordPvc(ldap, functional_environment, cluster, resultBackup, "backups", None, region)
                    #await cronjobAuditRecordMongo(ldap, functional_environment, cluster, resultBackup, "backups", None)
                logger.info(f"finished cronjobBackup PVC process")
                return resultBackup
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting cronjobBackup PVC process")
            resultBackup = await getCronjobsBackupPvc(functional_environment, cluster, region, namespace)
            if resultBackup and len(resultBackup) > 0: 
                await cronjobAuditRecordPvc(ldap, functional_environment, cluster, resultBackup, "backups", None, region)
                #await cronjobAuditRecordMongo(ldap, functional_environment, cluster, resultBackup, "backups", None)
            logger.info(f"finished cronjobBackup PVC process")
            return resultBackup

async def cronjobsBackupListPvcTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None, cronjobs = None, date = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"starting cronjobBackupList PVC process")
                cronjobBackupList = await getCronjobsBackupListPvc(functional_environment, cluster, region, namespace, cronjobs, date)
                logger.info(f"finished cronjobBackupList PVC process")
                return cronjobBackupList
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting cronjobBackupList PVC process")
            cronjobBackupList = await getCronjobsBackupListPvc(functional_environment, cluster, region, namespace, cronjobs, date)
            logger.info(f"finished cronjobBackupList PVC process")
            return cronjobBackupList

async def cronjobsBackupDownloadPvcTreatment(functional_environment, cluster, auth, ldap, region, namespace, date, cronjobs = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"starting cronjobBackupDownload PVC process")
                resultDownload = await getCronjobsBackupDownloadPvc(functional_environment, cluster, region, namespace, date, cronjobs)
                if resultDownload:
                    logger.info(f"finished cronjobBackupDownload PVC process")
                    if cronjobs is None:
                        return Response(content=resultDownload, media_type="application/zip")
                    else:
                        return Response(content=resultDownload, media_type="application/x-yaml")
                else:
                    logger.error(f"Cronjob backup file(s) not found")
                    raise HTTPException(status_code=404, detail="Cronjob backup file(s) not found")
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting cronjobBackupDownload PV process")
            resultDownload = await getCronjobsBackupDownloadPvc(functional_environment, cluster, region, namespace, date, cronjobs)
            if resultDownload:
                logger.info(f"finished cronjobBackupDownload PVC process")
                if cronjobs is None:
                    return Response(content=resultDownload, media_type="application/zip")
                else:
                    return Response(content=resultDownload, media_type="application/x-yaml")
            else:
                logger.error(f"Cronjob backup file(s) not found")
                raise HTTPException(status_code=404, detail="Cronjob backup file(s) not found")

async def cronjobsBackupRetentionPvcTreatment(auth, ldap):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                try:
                    await processBackupRetentionPvc()
                    result = {"status": "success", "message": "Backup retention process completed successfully", "user": ldap, "timestamp": datetime.now().isoformat(), "retention_days": retentionDays}
                    return result
                    
                except Exception as e:
                    logger.error(f"User {ldap} - Error in backup retention process: {e}")
                    raise HTTPException(status_code=500, detail=f"Backup retention process failed: {str(e)}")
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            try:
                await processBackupRetentionPvc()
                result = {"status": "success", "message": "Backup retention process completed successfully", "user": ldap, "timestamp": datetime.now().isoformat(), "retention_days": retentionDays}
                return result
                    
            except Exception as e:
                logger.error(f"User {ldap} - Error in backup retention process: {e}")
                raise HTTPException(status_code=500, detail=f"Backup retention process failed: {str(e)}")

async def cronjobsBackupsAuditPvcTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None, date= None, user= None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                return await searchAuditPvc(functional_environment, cluster, region, namespace, date, user, "backups")
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await searchAuditPvc(functional_environment, cluster, region, namespace, date, user, "backups")

async def cronjobsBackupMongoTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"starting cronjobBackup MONGO process")
                resultBackup = await getCronjobsBackupMongo(functional_environment, cluster, region, namespace)
                if resultBackup and len(resultBackup) > 0:
                    #await cronjobAuditRecordPvc(ldap, functional_environment, cluster, resultBackup, "backups", None, region)
                    await cronjobAuditRecordMongo(ldap, functional_environment, cluster, resultBackup, "backups", None)
                logger.info(f"finished cronjobBackup MONGO process")
                return resultBackup
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting cronjobBackup MONGO process")
            resultBackup = await getCronjobsBackupMongo(functional_environment, cluster, region, namespace)
            if resultBackup and len(resultBackup) > 0:
                #await cronjobAuditRecordPvc(ldap, functional_environment, cluster, resultBackup, "backups", None, region)
                await cronjobAuditRecordMongo(ldap, functional_environment, cluster, resultBackup, "backups", None)
            logger.info(f"finished cronjobBackup MONGO process")
            return resultBackup

async def cronjobsBackupListMongoTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None, cronjobs = None, date = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"starting cronjobBackupList MONGO process")
                cronjobBackupList = await getCronjobsBackupListMongo(functional_environment, cluster, region, namespace, cronjobs, date)
                logger.info(f"finished cronjobBackupList MONGO process")
                return cronjobBackupList
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting cronjobBackupList MONGO process")
            cronjobBackupList = await getCronjobsBackupListMongo(functional_environment, cluster, region, namespace, cronjobs, date)
            logger.info(f"finished cronjobBackupList MONGO process")
            return cronjobBackupList

async def cronjobsBackupDownloadMongoTreatment(functional_environment, cluster, auth, ldap, region, namespace, date, cronjobs = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"starting cronjobBackupDownload MONGO process")
                resultDownload = await getCronjobsBackupDownloadMongo(functional_environment, cluster, region, namespace, date, cronjobs)
                if resultDownload:
                    logger.info(f"finished cronjobBackupDownload MONGO process")
                    if cronjobs is None:
                        #filename = f"cronjobs-backup-{namespace}-{date}.zip"
                        return Response(content=resultDownload, media_type="application/zip")
                    else:
                        #filename = f"{cronjob}"
                        return Response(content=resultDownload, media_type="application/x-yaml")
                else:
                    logger.error(f"Cronjob backup file(s) not found")
                    raise HTTPException(status_code=404, detail="Cronjob backup file(s) not found")
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting cronjobBackupDownload process")
            resultDownload = await getCronjobsBackupDownloadMongo(functional_environment, cluster, region, namespace, date, cronjobs)
            if resultDownload:
                logger.info(f"finished cronjobBackupDownload Mongo process")
                if cronjobs is None:
                    #filename = f"cronjobs-backup-{namespace}-{date}.zip"
                    return Response(content=resultDownload, media_type="application/zip")
                else:
                    #filename = f"{cronjobs}"
                    return Response(content=resultDownload, media_type="application/x-yaml")
            else:
                logger.error(f"Cronjob backup file(s) not found")
                raise HTTPException(status_code=404, detail="Cronjob backup file(s) not found")

async def testBackupsCronTreatment(functional_environment, cluster, region, namespace, auth, ldap):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                return await getcronjobBackup(functional_environment, cluster, region, namespace)
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await getcronjobBackup(functional_environment, cluster, region, namespace)