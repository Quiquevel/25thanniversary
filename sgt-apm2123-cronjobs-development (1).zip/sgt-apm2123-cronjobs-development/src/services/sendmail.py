from shuttlelib.middleware.emailnotification import send_mail
from shuttlelib.utils.logger import logger

import os

async def sendeMailNotification(subject, htmlcontent):
    from_user = 'SRECoEDevSecOps@gruposantander.com'
    env_recipients = os.getenv("EMAIL_RECIPIENT_LIST")
    env_cc_recipients = os.getenv("EMAIL_CC_RECIPIENT_LIST")
    msg_to_user = env_recipients.split(",")
    msg_cc_user = env_cc_recipients.split(",")
    msg_subject = f'SHUTTLE-CRONJOBS: {subject}'

    content = f"""
        {htmlcontent}
    """
 
    try:
        answer = await send_mail(msg_from = from_user, msg_to_user = msg_to_user , msg_cc_user = msg_cc_user, msg_subject = msg_subject, msg_content=content)
    except:
        logger.error(f"send mail failed...") 
    
    return answer 
    