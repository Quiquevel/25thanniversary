from shuttlelib.utils.logger import logger
from time import time
from datetime import datetime
from os import getenv, path, chdir, mkdir
from json import dump as jsonDump, load
from sys import platform
from src.services.clientunique import entity_id, mg, ssl_verify
from src.models.cronjobs_models import AUDIT_TYPES
from shuttlelib.middleware.authorization import is_authorized_user
from fastapi import HTTPException
import re

import aiohttp

auditURL = (getenv("API_AUDIT","http://localhost:8080")).lower()
auditEndpoint = (getenv("ENDPOINT_AUDIT", "/api/v1/audit")).lower()
auditCollection = (getenv("COLLECTION_AUDIT","historical_trace")).lower()

AUDIT_CONFIG = {"mongoCollectionAudit": auditCollection}
for audit_type in AUDIT_TYPES:
    AUDIT_CONFIG[audit_type] = {
        "file": f"{audit_type}Audit.json",
        "directory": {
            "win32": fr"C:\Temp\{audit_type}Audit",
            "linux": fr"/tmp/{audit_type}Audit"
        }
    }

if mg is None:
    logger.warning("MongoDB client not available - MongoDB backup features will be disabled")
else:
    mongoCollectionAudit = AUDIT_CONFIG["mongoCollectionAudit"]
    logger.info(f"MongoDB audit collection will use: {mongoCollectionAudit}")
    
def getAuditConfig(auditType):
    if auditType not in AUDIT_CONFIG:
        raise ValueError(f"Audit type '{auditType}' not configured. Available: {list(AUDIT_CONFIG.keys())}")

    config = AUDIT_CONFIG[auditType].copy()

    if platform == "win32":
        config["directory"] = config["directory"]["win32"]
    else:
        config["directory"] = config["directory"]["linux"]

    config["path"] = path.join(config["directory"], config["file"])

    return config

def calculateHttpStatus(cronjobs_status):
    if not cronjobs_status:
        return 204
    
    status_codes = []
    for status in cronjobs_status:
        if isinstance(status, dict):
            status = status.get("status", 200)
            status_codes.append(status)

    if not status_codes:
        return 204

    unique_status_codes = set(status_codes)
    if unique_status_codes == {200}:
        return 200    
    if 200 in unique_status_codes:
        return 207

    return max(unique_status_codes)

def transform_mongodb_result_to_pvc_format(openshift_detail, record, typeAudit):
    transformed_result = []
    
    if not openshift_detail:
        return transformed_result
    
    environment = record.get("environment", "")
    cluster = record.get("cluster", "")
    namespace = record.get("namespace", "")
    record_date = None
    
    timestamp = record.get("timestamp")
    if timestamp:
        if hasattr(timestamp, 'date'):
            record_date = timestamp.date().isoformat()
        elif isinstance(timestamp, str):
            try:
                parsed_timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                record_date = parsed_timestamp.date().isoformat()
            except:
                record_date = str(timestamp)[:10]
    
    for detail in openshift_detail:
        if isinstance(detail, dict):
            region = detail.get("region", "")
            data_list = detail.get("data", [])
            
            for cronjob_data in data_list:
                if isinstance(cronjob_data, dict):
                    api_response = cronjob_data.get("api_response", 200)
                    status = api_response

                    if api_response == 200:
                        reason = "OK"
                    elif api_response == 201:
                        reason = "Created"
                    elif api_response >= 400:
                        reason = "Error"
                    else:
                        reason = f"HTTP {api_response}"

                    if typeAudit == "backups":
                        repository = f"MongoDB backup {record_date}"
                    elif typeAudit == "restores":
                        repository = f"MongoDB restore from {record_date}"
                    else:
                        repository = f"MongoDB {typeAudit}"

                    pvc_format_entry = {
                        "cluster": cluster,
                        "region": region,
                        "namespace": namespace,
                        "cronjob": cronjob_data.get("cronjob", "unknown.yaml"),
                        "status": status,
                        "reason": reason,
                        "repository": repository
                    }
                    
                    transformed_result.append(pvc_format_entry)
    
    return transformed_result

async def sendAuditMongo(body):
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(auditURL + auditEndpoint, json=body, ssl=ssl_verify) as answer:
                status_code = answer.status
                response_text = await answer.text()
                if answer.status == 200:
                    try:
                        logger.info(f'Audit API success: {status_code}')
                    except Exception as json_error:
                        logger.warning(f'Could not parse JSON response: {json_error}')
                        logger.info(f'Raw response: {response_text}')
                else:
                    logger.error(f'Audit API returned error {status_code}: {response_text}')
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {auditURL + auditEndpoint}. Skipping...")
        except:
            logger.error(f"{auditURL + auditEndpoint} could not be retrieved. Skipping...")

async def cronjobAuditRecordPvc(ldap, environment, cluster, resultAction, typeAudit, date = None, region = None):
    auditConfig = getAuditConfig(typeAudit)
    auditRepository = auditConfig["directory"]
    auditFile = auditConfig["file"]

    if region is None:
        region = "both"

    timeCronjobAction = time()
    dtTime = datetime.fromtimestamp(timeCronjobAction)

    dateAudit = dtTime.date().isoformat()
    timeAudit = dtTime.time().isoformat("seconds")
    idBase = dateAudit + timeAudit.replace(":", "-").replace(".", "-") 

    namespaces = list(set(result.get("namespace", "unknown") for result in resultAction))    

    newAuditRegisters = []

    for namespace in namespaces:
        namespaceResults = [result for result in resultAction if result.get("namespace", "unknown") == namespace]

        id = f"{namespace}-{idBase}"
        
        if typeAudit == "backups":
            newAuditRegister = {
                "id": id,
                "date": dateAudit,
                "time": timeAudit,
                "user": ldap.lower(),
                "environment": environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "result": namespaceResults
            }
        elif typeAudit == "restores":
            newAuditRegister = {
                "id": id,
                "date": dateAudit,
                "time": timeAudit,
                "user": ldap.lower(),
                "environment": environment,
                "cluster": cluster,
                "region": region,
                "dateBCKtoRestore": date,
                "namespace": namespace,
                "result": namespaceResults
            }

        newAuditRegisters.append(newAuditRegister)

    if path.isdir(auditRepository):
        chdir(auditRepository)
    else:
        mkdir(auditRepository)
        chdir(auditRepository)

    if path.isfile(auditFile):
        with open (auditFile, "r") as file:
            try:
                dataListAudit = load(file)
            except:
                dataListAudit = []
    else:
        dataListAudit = []

    for register in newAuditRegisters:
        dataListAudit.append(register)

    with open(auditFile, "w") as file:
        jsonDump(dataListAudit, file, indent=4)

#this only at the level of BACKUPS and RESTORES, pending unification of the rest and review of generic nomenclature
async def searchAuditPvc(environment, cluster, region, namespace, date, user, typeAudit):
    auditConfig = getAuditConfig(typeAudit)
    auditRepository = auditConfig["directory"]
    auditFile = auditConfig["file"]

    params = {
        "environment": environment,
        "cluster": cluster,
        "region": region,
        "namespace": namespace,
        "date": date,
        "user": user
    }

    filteredParams = {key: value for key, value in params.items() if value is not None}

    if path.isdir(auditRepository):
        chdir(auditRepository)
        if path.isfile(auditFile):
            try:
                file = open(auditFile, "r")
            except OSError: 
                logger.error(f"audit log does not exists or is inaccessible in path {auditRepository}")
            
            contentAuditFile = load(file)
            match = []
            for entry in contentAuditFile:
                if all((entry.get(param) == value) for param, value in filteredParams.items()):
                    match.append(entry)
        else:
            logger.error(f"audit log does not exists or is inaccessible in path {auditRepository}")
            return []
    else:
        logger.error(f"audit log does not exists or is inaccessible in path {auditRepository}")
        return []

    if match:
        return match
    else: 
        return []

async def cronjobAuditRecordMongo(ldap, environment, cluster, resultAction, auditType, date):
    auditConfig = getAuditConfig(auditType)
    
    namespace_groups = {}
    
    if resultAction and len(resultAction) > 0:
        for result in resultAction:
            item_namespace = result.get("namespace", "unknown")
            item_region = result.get("region", "unknown")
            item_cronjob = result.get("cronjob", "")
            item_repository = result.get("repository", "")
            item_status = result.get("status", 200)
            item_error = result.get("error_message", "")

            if item_namespace not in namespace_groups:
                namespace_groups[item_namespace] = {
                    "namespace": item_namespace,
                    "repository": item_repository,
                    "regions": {},
                    "status": []
                }

            if item_region not in namespace_groups[item_namespace]["regions"]:
                namespace_groups[item_namespace]["regions"][item_region] = []

            if item_cronjob:
                cronjob_data = {
                    "cronjob": item_cronjob,
                    "api_response": item_status
                }

            if item_error:
                cronjob_data["error_message"] = item_error

            namespace_groups[item_namespace]["regions"][item_region].append(cronjob_data)
            namespace_groups[item_namespace]["status"].append({"status": item_status})

        for namespace_name, namespace_data in namespace_groups.items():
            openshift_detail = []

            calculated_http_status = calculateHttpStatus(namespace_data["status"])

            for region_name, cronjobs_data in namespace_data["regions"].items():
                openshift_detail.append({
                    "region": region_name,
                    "data": cronjobs_data
                })

            if auditType == "restores":
                detailText = f"Restored from backup date: {date}"
            elif auditType == "backups":
                detailText = f"Backup repository: {namespace_data['repository']}"
            else:
                detailText = f"Operation: {auditType}"
    
            body = {
                "environment": environment,
                "ldap": ldap.lower(),
                "cluster": cluster,
                "namespace": namespace_name,
                "application": "cronjobs",
                "http_status": str(calculated_http_status),
                "operation": auditType,
                "dynatrace_url": "",
                "detail_text": detailText,
                "openshift_detail": openshift_detail
            }

            logger.info(f"Sending {auditType} audit for namespace {namespace_name} to {auditConfig['directory']}")
            await sendAuditMongo(body)

'''
async def searchAuditMongo(environment, cluster, region, namespace, date, user, typeAudit):
    try:
        if mg is not None:
            mg.change_collection(mongoCollectionAudit)
            logger.debug(f"Switched to MongoDB audit collection: {mongoCollectionAudit}")
        else:
            logger.error("MongoDB client not available")
            return []

        logger.info(f"Searching MongoDB collection: {mongoCollectionAudit} for audit type: {typeAudit}")

        params = {
            "environment": environment,
            "cluster": cluster,
            "region": region,
            "namespace": namespace,
            "date": date,
            "user": user
        }

        filteredParams = {key: value for key, value in params.items() if value is not None}
        
        logger.info(f"Filtered search parameters: {filteredParams}")
        
        query_filter = {}
        
        for param, value in filteredParams.items():
            if param == "user":
                query_filter["ldap"] = value.lower()
            elif param == "date":
                try:
                    date_obj = datetime.strptime(value, "%Y-%m-%d")
                    start_date = date_obj.replace(hour=0, minute=0, second=0, microsecond=0)
                    end_date = date_obj.replace(hour=23, minute=59, second=59, microsecond=999999)
                    query_filter["timestamp"] = {
                        "$gte": start_date,
                        "$lte": end_date
                    }
                    logger.info(f"Date range filter: {start_date} to {end_date}")
                except ValueError:
                    logger.warning(f"Invalid date format: {value}. Expected YYYY-MM-DD")
                    pass
            elif param == "region":
                if value != "both":
                    query_filter["openshift_detail.region"] = value
                    logger.info(f"Added region filter: {value}")
                else:
                    logger.info(f"Region filter 'both' - not filtering by specific region")
            else:
                query_filter[param] = value

        if typeAudit:
            query_filter["operation"] = typeAudit
        
        logger.info(f"MongoDB query filter: {query_filter}")
        
        try:
            audit_records = mg._collection.find(query_filter, sort=[("timestamp", -1)])
            audit_list = list(audit_records) if audit_records else []
            logger.info(f"Found {len(audit_list)} raw audit records in MongoDB collection {mongoCollectionAudit}")
        except Exception as e:
            logger.error(f"Error querying MongoDB audit collection {mongoCollectionAudit}: {e}")
            return []

        if not audit_list:
            logger.warning(f"No audit records found in MongoDB collection {mongoCollectionAudit} for filters: {filteredParams}")
            return []

        match = []
        for record in audit_list:
            logger.debug(f"Processing audit record: {record.get('_id')}")
            
            timestamp = record.get("timestamp")
            record_date = ""
            record_time = ""
            if timestamp:
                try:
                    if hasattr(timestamp, 'date') and hasattr(timestamp, 'time'):
                        record_date = timestamp.date().isoformat()
                        record_time = timestamp.time().isoformat("seconds")
                    elif isinstance(timestamp, str):
                        if timestamp.endswith('Z'):
                            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                        else:
                            dt = datetime.fromisoformat(timestamp)
                        record_date = dt.date().isoformat()
                        record_time = dt.time().isoformat("seconds")
                    else:
                        timestamp_str = str(timestamp)
                        if 'T' in timestamp_str:
                            record_date = timestamp_str.split('T')[0]
                            time_part = timestamp_str.split('T')[1].replace('Z', '')
                            record_time = time_part.split('.')[0] if '.' in time_part else time_part
                        else:
                            record_date = timestamp_str[:10] if len(timestamp_str) >= 10 else ""
                            record_time = "00:00:00"
                except Exception as e:
                    logger.warning(f"Error parsing timestamp {timestamp}: {e}")
                    record_date = ""
                    record_time = "00:00:00"
            
            openshift_detail = record.get("openshift_detail", [])
            record_region = "both"
            
            if openshift_detail and len(openshift_detail) > 0:
                first_detail = openshift_detail[0]
                if isinstance(first_detail, dict) and "region" in first_detail:
                    record_region = first_detail["region"]

            if region and region != "both":
                record_region = region

            formatted_record = {
                "id": str(record.get("_id", f"{record.get('namespace', 'unknown')}-{record_date}{record_time.replace(':', '-')}")),
                "date": record_date,
                "time": record_time,
                "user": record.get("ldap", "").lower(),
                "environment": record.get("environment", ""),
                "cluster": record.get("cluster", ""),
                "region": record_region,
                "namespace": record.get("namespace", ""),
                "result": record.get("openshift_detail", [])
            }
            
            if typeAudit == "restores":
                detail_text = record.get("detail_text", "")
                backup_date = None
                
                if "backup date:" in detail_text:
                    try:
                        backup_date = detail_text.split("backup date: ")[1].split()[0]
                    except:
                        pass
                
                if not backup_date and date:
                    backup_date = date
                if not backup_date:
                    backup_date = record_date
                formatted_record["dateBCKtoRestore"] = backup_date
            
            match.append(formatted_record)
        
        logger.info(f"Returning {len(match)} formatted audit records from MongoDB collection {mongoCollectionAudit}")

        return match if match else []

    except Exception as e:
        logger.error(f"Error searching audit records in MongoDB: {e}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return []
'''

async def searchAuditMongo(environment, cluster, region, namespace, date, user, typeAudit):
    try:
        if mg is not None:
            mg.change_collection(mongoCollectionAudit)
            logger.debug(f"Switched to MongoDB audit collection: {mongoCollectionAudit}")
        else:
            logger.error("MongoDB client not available")
            return []

        logger.info(f"Searching MongoDB collection: {mongoCollectionAudit} for audit type: {typeAudit}")

        params = {
            "environment": environment,
            "cluster": cluster,
            "region": region,
            "namespace": namespace,
            "date": date,
            "user": user
        }

        filteredParams = {key: value for key, value in params.items() if value is not None}
        
        logger.info(f"Filtered search parameters: {filteredParams}")
        
        query_filter = {}
        
        for param, value in filteredParams.items():
            if param == "user":
                query_filter["ldap"] = value.lower()
            elif param == "date":
                try:
                    date_obj = datetime.strptime(value, "%Y-%m-%d")
                    start_date = date_obj.replace(hour=0, minute=0, second=0, microsecond=0)
                    end_date = date_obj.replace(hour=23, minute=59, second=59, microsecond=999999)
                    query_filter["timestamp"] = {
                        "$gte": start_date,
                        "$lte": end_date
                    }
                    logger.info(f"Date range filter: {start_date} to {end_date}")
                except ValueError:
                    logger.warning(f"Invalid date format: {value}. Expected YYYY-MM-DD")
                    pass
            elif param == "region":
                if value != "both":
                    query_filter["openshift_detail.region"] = value
                    logger.info(f"Added region filter: {value}")
                else:
                    logger.info(f"Region filter 'both' - not filtering by specific region")
            else:
                query_filter[param] = value

        if typeAudit:
            query_filter["operation"] = typeAudit
        
        logger.info(f"MongoDB query filter: {query_filter}")
        
        try:
            audit_records = mg._collection.find(query_filter, sort=[("timestamp", -1)])
            audit_list = list(audit_records) if audit_records else []
            logger.info(f"Found {len(audit_list)} raw audit records in MongoDB collection {mongoCollectionAudit}")
        except Exception as e:
            logger.error(f"Error querying MongoDB audit collection {mongoCollectionAudit}: {e}")
            return []

        if not audit_list:
            logger.warning(f"No audit records found in MongoDB collection {mongoCollectionAudit} for filters: {filteredParams}")
            return []

        formatted_audit_records = []
        for record in audit_list:
            try:
                logger.debug(f"Processing audit record: {record.get('_id')}")
                # ✅ EXTRAER TIMESTAMP
                timestamp = record.get("timestamp")
                record_date = ""
                record_time = ""
                if timestamp:
                    if hasattr(timestamp, 'date') and hasattr(timestamp, 'time'):
                        record_date = timestamp.date().isoformat()
                        record_time = timestamp.time().isoformat("seconds")
                    elif isinstance(timestamp, str):
                        try:
                            parsed_timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                            record_date = parsed_timestamp.date().isoformat()
                            record_time = parsed_timestamp.time().isoformat("seconds")
                        except Exception as e:
                            logger.warning(f"Error parsing timestamp {timestamp}: {e}")
                            record_date = str(timestamp)[:10]
                            record_time = str(timestamp)[11:19] if len(str(timestamp)) > 19 else "00:00:00"
                # ✅ EXTRAER REGIÓN (MANTENER LÓGICA EXISTENTE)
                record_region = ""
                openshift_detail = record.get("openshift_detail", [])
                if openshift_detail and len(openshift_detail) > 0:
                    first_detail = openshift_detail[0]
                    if isinstance(first_detail, dict) and "region" in first_detail:
                        record_region = first_detail["region"]
                # ✅ GENERAR BACKUP DATE PARA RESTORES
                backup_date = ""
                if typeAudit == "restores":
                    detail_text = record.get("detail_text", "")
                    backup_date_match = re.search(r'backup date to restore: (\d{4}-\d{2}-\d{2})', detail_text)
                    if backup_date_match:
                        backup_date = backup_date_match.group(1)
                    else:
                        backup_date = record_date
                # ✅ TRANSFORMAR RESULT A FORMATO PVC
                transformed_result = transform_mongodb_result_to_pvc_format(
                    openshift_detail, record, typeAudit
                )
                # ✅ CREAR RECORD FORMATEADO
                formatted_record = {
                    "id": str(record.get("_id", f"{record.get('namespace', 'unknown')}-{record_date}{record_time.replace(':', '-')}")),
                    "date": record_date,
                    "time": record_time,
                    "user": record.get("ldap", "").lower(),
                    "environment": record.get("environment", ""),
                    "cluster": record.get("cluster", ""),
                    "region": record_region,
                    "namespace": record.get("namespace", ""),
                    "result": transformed_result  # ✅ FORMATO PVC
                }
                # ✅ AÑADIR FECHA DE BACKUP PARA RESTORES
                if typeAudit == "restores" and backup_date:
                    formatted_record["dateBCKtoRestore"] = backup_date
                formatted_audit_records.append(formatted_record)
            except Exception as e:
                logger.error(f"Error formatting audit record {record.get('_id', 'unknown')}: {e}")
                continue
            
        logger.info(f"Returning {len(formatted_audit_records)} formatted audit records from MongoDB collection {mongoCollectionAudit}")
        return formatted_audit_records


    except Exception as e:
        logger.error(f"Error searching audit records in MongoDB: {e}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return []

async def AuditAllPvcTreatment(functional_environment, cluster, auth, ldap, typeAudit, region = None, namespace = None, date= None, user= None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                return await searchAuditPvc(functional_environment, cluster, region, namespace, date, user, typeAudit)
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await searchAuditPvc(functional_environment, cluster, region, namespace, date, user, typeAudit)

async def AuditAllMongoTreatment(functional_environment, cluster, auth, ldap, typeAudit, region=None, namespace=None, date=None, user=None):
    """
    MongoDB audit treatment - analogous to AuditAllPvcTreatment
    """
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                return await searchAuditMongo(functional_environment, cluster, region, namespace, date, user, typeAudit)
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await searchAuditMongo(functional_environment, cluster, region, namespace, date, user, typeAudit)