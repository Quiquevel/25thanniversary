from shuttlelib.utils.logger import logger
from shuttlelib.middleware.authorization import is_authorized_user
from aiohttp import client_exceptions
from fastapi import HTTPException, Response
from src.services.clientunique import client, entity_id, ssl_verify
from sys import platform
from os import path, chdir, mkdir
from json import dump as jsonDump, load
from time import time
from datetime import datetime
from yaml import dump as yamlDump
from io import BytesIO
from zipfile import ZipFile, ZIP_DEFLATED

import urllib3
import json
import aiohttp

urllib3.disable_warnings()

auditCronjobsFile = "cronjobsAudit.json"

if platform == "win32":
    separator = "\\"
    repositoryAudit = r"C:\Temp\cronjobsAudit"    
else:
    separator = "/"
    repositoryAudit = r"/tmp/cronjobsAudit"

async def generateEnvSummary(environmentVars, current_env_vars):
    if isinstance(environmentVars, str) and "=" in environmentVars:
        env_changes = []        
        env_pairs = [pair.strip() for pair in environmentVars.split(',')]
        
        for env_pair in env_pairs:
            if "=" in env_pair:
                key, new_value = env_pair.split("=", 1)
                
                clean_key = key.strip().strip('"')
                clean_value = new_value.strip().strip('"')
                old_value = current_env_vars.get(clean_key)
                
                if old_value is None:
                    env_changes.append(f"{clean_key}={clean_value} (key not exist, insert)")
                elif str(old_value) != str(clean_value):
                    env_changes.append(f"{clean_key}={old_value}→{clean_value} (key exist, value different, update)")
                else:
                    env_changes.append(f"{clean_key}={clean_value} (key exist, value is the same, skipping)")
        
        return ", ".join(env_changes) if env_changes else str(environmentVars)
    else:
        return str(environmentVars)

async def generatePatchSummary(patch_data, path=""):
    processed_patch_data = patch_data
    
    if isinstance(patch_data, str):
        patch_data_stripped = patch_data.strip()
        if patch_data_stripped.startswith('{') and patch_data_stripped.endswith('}'):
            try:
                processed_patch_data = json.loads(patch_data)
            except json.JSONDecodeError:
                processed_patch_data = patch_data
    
    if isinstance(processed_patch_data, dict):
        summary_parts = []
        
        for key, value in processed_patch_data.items():
            current_path = f"{path}.{key}" if path else key
            
            if isinstance(value, dict):
                nested_summary = await generatePatchSummary(value, current_path)
                summary_parts.append(nested_summary)
            elif isinstance(value, list):
                summary_parts.append(f"{current_path}=[{len(value)} items]")
            else:
                value_str = str(value)[:50] + "..." if len(str(value)) > 50 else str(value)
                summary_parts.append(f"{current_path}={value_str}")

        return ", ".join(summary_parts)
    else:
        return str(processed_patch_data)

async def cronjobActionAuditRecord(ldap, environment, cluster, region, namespace, cronjobList, action, paramAction, resultAction):
    timeCronjobAction = time()
    dtTime = datetime.fromtimestamp(timeCronjobAction)

    dateAudit = dtTime.date().isoformat()
    timeAudit = dtTime.time().isoformat()  

    cronjobNameList = [cronjob['name'] for cronjob in cronjobList]
    cronjobClusterList = [cronjob['cluster'] for cronjob in cronjobList]
    cronjobRegionList = [cronjob['region'] for cronjob in cronjobList]

    match action:
        case "start" | "stop":
            cronjobCombinedList = []
            cronjobStateList = ["stop" if cronjob['suspend'] else "start" for cronjob in cronjobList]
            for cronjobName, cronjobCluster, cronjobRegion, cronjobState in zip(cronjobNameList, cronjobClusterList, cronjobRegionList, cronjobStateList): 
                cronjobCombinated = cronjobName + "(" + cronjobCluster + "/" + cronjobRegion + ")" + ": " + cronjobState
                cronjobCombinedList.append(cronjobCombinated)

            newAuditRegister = {
                "date": dateAudit,
                "time": timeAudit,
                "user": ldap.lower(),
                "environment": environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "cronjobs": cronjobCombinedList,
                "action": action,
                "result": resultAction
            }
        case "image":
            image = paramAction
            cronjobCombinedList = []
            cronjobImageList = [cronjob['image'] for cronjob in cronjobList]
            for cronjobName, cronjobCluster, cronjobRegion, imageName in zip(cronjobNameList, cronjobClusterList, cronjobRegionList, cronjobImageList): 
                cronjobCombinated = cronjobName + "(" + cronjobCluster + "/" + cronjobRegion + ")" + ">" + imageName
                cronjobCombinedList.append(cronjobCombinated)
            
            newAuditRegister = {
                "date": dateAudit,
                "time": timeAudit,
                "user": ldap.lower(),
                "environment": environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "cronjobs": cronjobCombinedList,
                "action": action,
                "image": image,
                "result": resultAction
            }
        case "schedule":
            schedule = paramAction
            cronjobCombinedList = []
            cronjobScheduleList = [cronjob['schedule'] for cronjob in cronjobList] 
            for cronjobName, cronjobCluster, cronjobRegion, cronjobSchedule in zip(cronjobNameList, cronjobClusterList, cronjobRegionList, cronjobScheduleList): 
                cronjobCombinated = cronjobName + "(" + cronjobCluster + "/" + cronjobRegion + ")" + ": " + cronjobSchedule
                cronjobCombinedList.append(cronjobCombinated)
            
            newAuditRegister = {
                "date": dateAudit,
                "time": timeAudit,
                "user": ldap.lower(),
                "environment": environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "cronjobs": cronjobCombinedList,
                "action": action,
                "schedule": schedule,
                "result": resultAction
            }
        case "history":
            countHistory = paramAction
            cronjobCombinedList = []
            cronjobHistoryLimitOKAList = [cronjob['historyLimitSuccessfulJob'] for cronjob in cronjobList]
            cronjobHistoryLimitKAOList = [cronjob['historyLimitfailedJob'] for cronjob in cronjobList]
            for cronjobName, cronjobCluster, cronjobRegion, cronjobHistoryLimitOK, cronjobHistoryLimitKAO in zip(cronjobNameList, cronjobClusterList, cronjobRegionList, cronjobHistoryLimitOKAList, cronjobHistoryLimitKAOList): 
                cronjobCombinated = cronjobName + "(" + cronjobCluster + "/" + cronjobRegion + ")" + "(History limit OKA:" + str(cronjobHistoryLimitOK) + "/ KAO:" + str(cronjobHistoryLimitKAO) + ")"
                cronjobCombinedList.append(cronjobCombinated)
            
            newAuditRegister = {
                "date": dateAudit,
                "time": timeAudit,
                "user": ldap.lower(),
                "environment": environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "cronjobs": cronjobCombinedList,
                "action": action,
                "countHistory": countHistory,
                "result": resultAction
            }
        case "environment":
            environmentVars = paramAction
            cronjobCombinedList = []

            for cronjob in cronjobList:
                cronjobName = cronjob['name']
                cronjobCluster = cronjob['cluster']
                cronjobRegion = cronjob['region']

                current_env_vars = cronjob.get('environmentVars', {})
                env_summary = await generateEnvSummary(environmentVars, current_env_vars)
                
                cronjobCombinated = f"{cronjobName}({cronjobCluster}/{cronjobRegion}): ENV[{env_summary}]"
                cronjobCombinedList.append(cronjobCombinated)
            
            newAuditRegister = {
                "date": dateAudit,
                "time": timeAudit,
                "user": ldap.lower(),
                "environment": environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "cronjobs": cronjobCombinedList,
                "action": action,
                "environmentVars": environmentVars,
                "result": resultAction
            }
        case "patch":
            patchData = paramAction
            cronjobCombinedList = []
            
            
            if isinstance(paramAction, str):
                # ✅ Detectar si es JSON string
                paramAction_stripped = paramAction.strip()
                if paramAction_stripped.startswith('{') and paramAction_stripped.endswith('}'):
                    try:
                        patchData = json.loads(paramAction)
                        logger.info(f'Audit: Successfully parsed JSON string paramAction for patch')
                    except json.JSONDecodeError as e:
                        logger.warning(f'Audit: Failed to parse JSON string for patch, using original format: {e}')
                        patchData = paramAction
            
            for cronjob in cronjobList:
                cronjobName = cronjob['name']
                cronjobCluster = cronjob['cluster']
                cronjobRegion = cronjob['region']

                patch_summary = await generatePatchSummary(patchData)
                
                cronjobCombinated = f"{cronjobName}({cronjobCluster}/{cronjobRegion}): PATCH[{patch_summary}]"
                cronjobCombinedList.append(cronjobCombinated)

            newAuditRegister = {
                "date": dateAudit,
                "time": timeAudit,
                "user": ldap.lower(),
                "environment": environment,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "cronjobs": cronjobCombinedList,
                "action": action,
                "patchData": patchData,
                "result": resultAction
            }
        case _:
            pass

    if path.isdir(repositoryAudit):
        chdir(repositoryAudit)
    else:
        mkdir(repositoryAudit)
        chdir(repositoryAudit)

    if path.isfile(auditCronjobsFile):
        with open (auditCronjobsFile, "r") as file:
            try:
                dataListAudit = load(file)
            except:
                dataListAudit = []
    else:
        dataListAudit = []

    dataListAudit.append(newAuditRegister)

    with open(auditCronjobsFile, "w") as file:
        jsonDump(dataListAudit, file, indent=4)

async def searchAuditLog(environment, cluster, region, namespace, date, user):
    params = {
        "environment": environment,
        "cluster": cluster,
        "region": region,
        "namespace": namespace,
        "date": date,
        "user": user
    }
    
    filteredParams = {key: value for key, value in params.items() if value is not None}

    if path.isdir(repositoryAudit):
        chdir(repositoryAudit)
        if path.isfile(auditCronjobsFile):
            try:
                file = open(auditCronjobsFile, "r")
            except OSError: 
                logger.error(f"audit log does not exists or is inaccessible in path {repositoryAudit}")
            
            contentAuditFile = load(file)
            match = []
            for entry in contentAuditFile:
                if all((entry.get(param) == value) for param, value in filteredParams.items()):
                    matchedJobs = [job for job in entry.get("result", [])]
                    if matchedJobs:
                        entryCopy = entry.copy()
                        entryCopy['result'] = matchedJobs
                        match.append(entryCopy)
        else:
            logger.error(f"audit log does not exists or is inaccessible in path {repositoryAudit}")
            return []
    else:
        logger.error(f"audit log does not exists or is inaccessible in path {repositoryAudit}")
        return []

    if match:
        return match
    else: 
        return []

async def getCronjobsList(functional_environment, cluster, region, namespace, cronjobs):
    cronjobList = []
    namespaceList = []
    cronjobDataList = []
        
    if region is None:
        region = "both"
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]

    if namespace is None:
        for region in regionList:
            try:
                namespaceList = await client.get_resource(resource = "namespaces", functional_environment = functional_environment, cluster = cluster, region = region)
            except client_exceptions.ClientConnectorError:
                logger.error(f"Timeout detected....")
                continue
            except:
                logger.error(f"namespaces could not be retrieved. Skipping...")
                continue

            try:
                items = namespaceList[region]['items']
            except:
                items = None
                
            if items and len(items) > 0:
                namespaceList = items
                for namespace in namespaceList:
                    namespaceName = namespace['metadata']['name']
                    try:
                        cronjobList = await client.get_resource(resource = "cronjobs", functional_environment = functional_environment, cluster = cluster, region = region, namespace = namespaceName)
                    except client_exceptions.ClientConnectorError:
                        logger.error(f"Timeout detected....")
                        continue
                    except:
                        logger.error(f"cronjobs could not be retrieved. Skipping...")
                        continue
                    
                    try:
                        items = cronjobList[region]['items']
                    except:
                        items = None
                
                    if items and len(items) > 0:
                        cronjobList = items
                        for cronjob in cronjobList:
                            metadata = cronjob['metadata']
                            name = metadata.get('name', None)
                            namespace = metadata.get('namespace', None)
                            creationTimestamp = metadata.get('creationTimestamp', None)

                            spec = cronjob['spec']
                            schedule = spec.get('schedule', None)
                            suspend = spec.get('suspend', None)
                            historyLimitSuccessJob = spec.get('successfulJobsHistoryLimit', None)
                            historyLimitfailedJob = spec.get('failedJobsHistoryLimit', None)
                            
                            image = spec.get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {}).get('containers', [{}])[0].get('image', None)
                            if "/" in image:
                                image = image.split("/")[-1]
                            
                            container = spec.get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {}).get('containers', [{}])[0].get('name', None)                            
                            environment = spec.get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {}).get('containers', [{}])[0].get('env', [])
                            environmentVars = {var.get('name'): var.get('value') for var in environment} if environment else {}
                            
                            status = cronjob['status']
                            lastScheduleTime = status.get('lastScheduleTime', None)
                            lastSuccessfulTime = status.get('lastSuccessfulTime', None)
                                
                            cronjobData = {
                                'environment': functional_environment,
                                'cluster': cluster,
                                'region': region,
                                'name': name,
                                'namespace': namespace,
                                'creationTimestamp': creationTimestamp, 
                                'schedule': schedule,
                                'suspend': suspend,
                                'container': container,
                                'image': image,
                                'lastScheduleTime': lastScheduleTime,
                                'lastSuccessfulTime': lastSuccessfulTime,
                                'historyLimitSuccessfulJob': historyLimitSuccessJob,
                                'historyLimitfailedJob': historyLimitfailedJob,
                                'environmentVars': environmentVars
                                }

                            if cronjobData:
                                cronjobDataList.append(cronjobData)
    else:
        for region in regionList:
            try:
                cronjobList = await client.get_resource(resource = "cronjobs", functional_environment = functional_environment, cluster = cluster, region = region, namespace = namespace)
            except client_exceptions.ClientConnectorError:
                logger.error(f"Timeout detected....")
                continue
            except:
                logger.error(f"cronjobs could not be retrieved. Skipping...")
                continue

            try:
                items = cronjobList[region]['items']
            except:
                items = None

            if items and len(items) > 0:
                cronjobList = items
                for cronjob in cronjobList:
                    metadata = cronjob['metadata']
                    name = metadata.get('name', None)
                    namespace = metadata.get('namespace', None)
                    creationTimestamp = metadata.get('creationTimestamp', None)

                    spec = cronjob['spec']
                    schedule = spec.get('schedule', None)
                    suspend = spec.get('suspend', None)
                    historyLimitSuccessJob = spec.get('successfulJobsHistoryLimit', None)
                    historyLimitfailedJob = spec.get('failedJobsHistoryLimit', None)
    
                    image = spec.get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {}).get('containers', [{}])[0].get('image', None)
                    if "/" in image:
                        image = image.split("/")[2]

                    container = spec.get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {}).get('containers', [{}])[0].get('name', None)
                    environment = spec.get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {}).get('containers', [{}])[0].get('env', [])
                    environmentVars = {var.get('name'): var.get('value') for var in environment} if environment else {}
                    
                    status = cronjob['status']
                    lastScheduleTime = status.get('lastScheduleTime', None)
                    lastSuccessfulTime = status.get('lastSuccessfulTime', None)

                    cronjobData = {
                        'environment': functional_environment,
                        'cluster': cluster,
                        'region': region,
                        'name': name, 
                        'namespace': namespace,
                        'creationTimestamp': creationTimestamp,
                        'schedule': schedule, 
                        'suspend': suspend, 
                        'container': container,
                        'image': image,
                        'lastScheduleTime': lastScheduleTime,
                        'lastSuccessfulTime': lastSuccessfulTime,
                        'historyLimitSuccessfulJob': historyLimitSuccessJob,
                        'historyLimitfailedJob': historyLimitfailedJob,
                        'environmentVars': environmentVars
                    }

                    if cronjobData:
                        cronjobDataList.append(cronjobData) 

    if cronjobs and "," not in cronjobs:
        cronjobDataList = [entry for entry in cronjobDataList if entry["name"].startswith(cronjobs)]
    if cronjobs and "," in cronjobs:
        cronjobDataList = [entry for entry in cronjobDataList if entry["name"] in [entry.strip() for entry in cronjobs.split(",")]]

    return cronjobDataList

async def getCronjobsAction(functional_environment, cluster, region, namespace, cronjobList, action, paramAction):
    resultPatchCronjobList = []
    
    if region is None:
        region = "both"
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]

    for region in regionList:
        clientData = client.clusters[functional_environment][cluster].get(region, None)
        
        if clientData is None:
            break

        urlApi = clientData.get("url", None)
        token = clientData.get("token", None)

        cronjobListbyRegion = [{k: cronjob[k] for k in cronjob if k in ['name', 'container']} for cronjob in cronjobList if cronjob['region'] == region]

        for cronjob in cronjobListbyRegion:
            cronjobName = cronjob['name']
            containerName = cronjob['container']
            requestUrl = urlApi + "/apis/batch/v1/namespaces/" + namespace + "/cronjobs/" + cronjobName
            headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close", "Content-Type": "application/strategic-merge-patch+json"}

            if action == "start":
                logger.info(f'starting cronjob {cronjobName}')
                body = {"spec": {"suspend": False}}
            elif action == "stop":
                logger.info(f'stopping cronjob {cronjobName}')
                body = {"spec": {"suspend": True}}
            elif action == "image":
                image = paramAction
                logger.info(f'changing cronjob image {cronjobName}')
                body = {"spec": {"jobTemplate": {"spec": {"template": {"spec": {"containers":[{"name": containerName, "image":image}]}}}}}}
            elif action == "schedule":
                schedule = paramAction
                logger.info(f'changing cronjob schedule {cronjobName}')
                body = {"spec": {"schedule": schedule}}
            elif action == "history": 
                countHistory = int(paramAction)
                logger.info(f'changing cronjob history {cronjobName}')
                body = {"spec": {"successfulJobsHistoryLimit": countHistory, 'failedJobsHistoryLimit': countHistory}}
            elif action == "environment":
                logger.info(f'configuring environment variables for cronjob {cronjobName}')
                environmentVars = []

                # ✅ NUEVA LÓGICA: Solo strings con clave=valor (simple o múltiple)
                if isinstance(paramAction, str) and "=" in paramAction:
                    # ✅ Dividir por comas para múltiples variables
                    env_pairs = [pair.strip() for pair in paramAction.split(',')]

                    for env_pair in env_pairs:
                        if "=" in env_pair:
                            key, value = env_pair.split("=", 1)

                            # ✅ Limpiar espacios y comillas dobles
                            clean_key = key.strip().strip('"')
                            clean_value = value.strip().strip('"')

                            environmentVars.append({"name": clean_key, "value": clean_value})
                            logger.info(f'  - Setting {clean_key}={clean_value}')
                        else:
                            logger.warning(f'Invalid environment pair (missing =): {env_pair}')

                    # ✅ Validar que se crearon variables
                    if not environmentVars:
                        logger.error(f'No valid environment variables found in: {paramAction}')
                        resultPatchCronjob = {
                            'cronjob': cronjobName,
                            'cluster': cluster,
                            'region': region,
                            'status': 400,
                            'reason': 'No valid environment variables found in paramAction'
                        }
                        resultPatchCronjobList.append(resultPatchCronjob)
                        continue
                else:
                    # ❌ Formato no soportado
                    logger.error(f'Invalid environment format for {cronjobName}: must be string with key=value format')
                    resultPatchCronjob = {
                        'cronjob': cronjobName,
                        'cluster': cluster,
                        'region': region,
                        'status': 400,
                        'reason': 'Invalid environment format: must be string with key=value format'
                    }
                    resultPatchCronjobList.append(resultPatchCronjob)
                    continue

                body = {"spec": {"jobTemplate": {"spec": {"template": {"spec": {"containers": [{"name": containerName,"env": environmentVars}]}}}}}}
            elif action == "patch":
                logger.info(f'applying generic patch to cronjob {cronjobName}')

                # ✅ NUEVA LÓGICA: Parsear JSON string automáticamente
                processed_paramAction = paramAction

                if isinstance(paramAction, str):
                    # ✅ Detectar si es JSON string
                    paramAction_stripped = paramAction.strip()
                    if paramAction_stripped.startswith('{') and paramAction_stripped.endswith('}'):
                        try:
                            processed_paramAction = json.loads(paramAction)
                            logger.info(f'Successfully parsed JSON string paramAction for patch on cronjob {cronjobName}')
                        except json.JSONDecodeError as e:
                            logger.error(f'Invalid JSON string format for {cronjobName}: {e}')
                            resultPatchCronjob = {
                                'cronjob': cronjobName,
                                'cluster': cluster,
                                'region': region,
                                'status': 400,
                                'reason': f'Invalid JSON format in paramAction: {str(e)}'
                            }
                            resultPatchCronjobList.append(resultPatchCronjob)
                            continue
                    else:
                        # ❌ String que no es JSON válido
                        logger.error(f'Invalid patch format for {cronjobName}: string must be valid JSON')
                        resultPatchCronjob = {
                            'cronjob': cronjobName,
                            'cluster': cluster,
                            'region': region,
                            'status': 400,
                            'reason': 'Invalid patch format: string must be valid JSON'
                        }
                        resultPatchCronjobList.append(resultPatchCronjob)
                        continue
                    
                # ✅ VALIDACIÓN: Debe ser dict después del parsing
                if not isinstance(processed_paramAction, dict):
                    logger.error(f'Invalid patch format for {cronjobName}: must be a dict')
                    resultPatchCronjob = {
                        'cronjob': cronjobName,
                        'cluster': cluster,
                        'region': region,
                        'status': 400,
                        'reason': f'Invalid patch format: must be a dict, got {type(processed_paramAction)}'
                    }
                    resultPatchCronjobList.append(resultPatchCronjob)
                    continue

                # ✅ NUEVA LÓGICA: Auto-completar container names
                body = processed_paramAction.copy() 
                
                # ✅ Verificar si hay containers sin name en el patch
                containers_patch = body.get('spec', {}).get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {}).get('containers', [])
                
                if containers_patch:
                    # ✅ Verificar si algún container no tiene name
                    containers_without_names = [i for i, container in enumerate(containers_patch) if isinstance(container, dict) and 'name' not in container]
                    
                    if containers_without_names:
                        logger.info(f'Auto-detecting container names for cronjob {cronjobName}')
                        
                        # ✅ Obtener cronjob actual para extraer container names
                        try:
                            getCurrentCronjobUrl = urlApi + "/apis/batch/v1/namespaces/" + namespace + "/cronjobs/" + cronjobName
                            getCurrentHeaders = {"Authorization": "Bearer " + token, "Accept": "application/json"}
                           
                            async with aiohttp.ClientSession() as session:
                                async with session.get(getCurrentCronjobUrl, headers=getCurrentHeaders, ssl=ssl_verify, timeout=aiohttp.ClientTimeout(total=10)) as answer:
                                    if answer.status == 200:
                                        currentCronjob = await answer.json()
                                        existing_containers = currentCronjob.get('spec', {}).get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {}).get('containers', [])

                                        # ✅ Asignar names automáticamente
                                        for i in containers_without_names:
                                            if i < len(existing_containers):
                                                container_name = existing_containers[i].get('name', f'container-{i}')
                                                containers_patch[i]['name'] = container_name
                                                logger.info(f'Auto-assigned container name: {container_name} at index {i}')
                                            else:
                                                # ✅ Si no hay suficientes containers, usar containerName del loop principal
                                                containers_patch[i]['name'] = containerName
                                                logger.info(f'Using default container name: {containerName} at index {i}')
                                    else:
                                        logger.warning(f'Could not fetch current cronjob {cronjobName} (status: {answer.status}), using default container name')
                                # ✅ Usar containerName como fallback
                                for i in containers_without_names:
                                    containers_patch[i]['name'] = containerName
                                    logger.info(f'Using fallback container name: {containerName} at index {i}')
                        except Exception as e:
                            logger.error(f'Error fetching current cronjob {cronjobName}: {e}')
                            # ✅ Usar containerName como fallback
                            for i in containers_without_names:
                                containers_patch[i]['name'] = containerName
                                logger.info(f'Using fallback container name: {containerName} at index {i}')
                
                logger.info(f'  - Applying patch: {body}')
            else:
                logger.error(f'Unknown action: {action}')
                resultPatchCronjob = {
                    'cronjob': cronjobName,
                    'cluster': cluster,
                    'region': region, 
                    'status': 400,
                    'reason': f'Unknown action: {action}'
                }
                resultPatchCronjobList.append(resultPatchCronjob)
                continue

            # ✅ REQUESTS PATCH (PARA TODAS LAS ACCIONES)
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.patch(requestUrl, headers=headers, json=body, ssl=ssl_verify, timeout=aiohttp.ClientTimeout(total=10)) as answer:
                        status_code = answer.status
                        reason = answer.reason
            except aiohttp.ClientConnectorError:
                logger.error(f'Connection error. Cannot connect to {urlApi}')
                status_code = 408
                reason = 'Connection error'
            except aiohttp.ServerTimeoutError:
                logger.error(f'Timeout for {cronjobName}')
                status_code = 408
                reason = 'Timeout'
            except Exception as e:
                logger.error(f'Error in the process for {cronjobName}: {e}')
                status_code = 500
                reason = f'Error: {str(e)}'

            resultPatchCronjob = {
                'cronjob': cronjobName,
                'cluster': cluster,
                'region': region,
                'status': status_code,
                'reason': reason
            }

            resultPatchCronjobList.append(resultPatchCronjob)

            logger.info(f"answer {status_code}({reason}) in {action} process ({namespace} > {cronjobName})")
        logger.info(f"finish in {region} > {action} process ({namespace} > {cronjobName})")

    return resultPatchCronjobList

async def getCronjobsDownload(functional_environment, cluster, region, namespace, cronjobs):
    cronjobDefinitions = []
    
    fieldsToRemove = ['status']
    fieldsToRemoveMetadata = ['uid', 'generation', 'resourceVersion', 'creationTimestamp', 'managedFields']

    if region is None:
        region = "both"
    if "both" in region:
        regionList = list(client.clusters[functional_environment][cluster])
    else:
        regionList = [region]

    for region in regionList:
        try:
            cronjobList = await client.get_resource(resource="cronjobs", functional_environment=functional_environment, cluster=cluster, region=region, namespace=namespace)
        except client_exceptions.ClientConnectorError:
            logger.error(f"Timeout detected....")
            continue
        except:
            logger.error(f"cronjobs could not be retrieved. Skipping...")
            continue

        try:
            items = cronjobList[region]['items']
        except:
            items = None

        if items and len(items) > 0:
            cronjobList = items
            for cronjob in cronjobList:
                metadata = cronjob['metadata']
                cronjobName = metadata.get('name', None)

                if cronjobs is not None:
                    if cronjobName != cronjobs:
                        continue
                    logger.info(f"Found specific cronjob: {cronjobName} in {region}")
                else:
                    logger.info(f"Including cronjob: {cronjobName} in {region}")

                namespace = metadata.get('namespace', None)
                cronjob['kind'] = "CronJob"
                cronjob['apiVersion'] = "batch/v1"
                for field in fieldsToRemove:
                    if field in cronjob:
                        del cronjob[field]
                for field in fieldsToRemoveMetadata:
                    if field in cronjob['metadata']:
                        del cronjob['metadata'][field]

                try:
                    yamlContent = yamlDump(cronjob, default_flow_style=False, sort_keys=False)
                    
                    cronjobDefinition = {"name": cronjobName, "filename": f"{cronjobName}.yaml", "content": yamlContent}
                    
                    cronjobDefinitions.append(cronjobDefinition)
                    logger.info(f"Retrieved definition for cronjob: {cronjobName} in {region}")
                    
                except Exception as e:
                    logger.error(f"Error converting cronjob {cronjobName} to YAML: {e}")
                    continue

    if not cronjobDefinitions:
        logger.warning(f"No cronjob definitions found for namespace {namespace}")
        return None

    if cronjobs is not None:
        if cronjobDefinitions and len(cronjobDefinitions) == 1:
            return cronjobDefinitions[0]["content"]
        else:
            logger.warning(f"Cronjob '{cronjobs}' not found in namespace {namespace}")
            return None
    else:
        try:
            zip_buffer = BytesIO()
            with ZipFile(zip_buffer, 'w', ZIP_DEFLATED) as zip_file:
                for definition in cronjobDefinitions:
                    zip_file.writestr(definition["filename"], definition["content"])
                    logger.info(f"Added {definition['filename']} to ZIP")

            zip_buffer.seek(0)
            zip_content = zip_buffer.getvalue()
            zip_buffer.close()

            return zip_content

        except Exception as e:
            logger.error(f"Error creating ZIP for all cronjob definitions: {e}")
            return None

async def cronjobsListTreatment(functional_environment, cluster, auth, ldap, region = None, namespace = None, cronjobs = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops") 
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
        
                logger.info(f"starting cronjobList process")
                cronjobList = await getCronjobsList(functional_environment, cluster, region, namespace, cronjobs)
                logger.info(f"finished cronjobList process")
                return cronjobList
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting cronjobList process")
            cronjobList = await getCronjobsList(functional_environment, cluster, region, namespace, cronjobs)
            logger.info(f"finished cronjobList process")
            return cronjobList

async def cronjobsActionTreatment(functional_environment, cluster, region, namespace, action, auth, ldap, cronjobs, paramAction = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"starting cronjobsAction ({action}) process")
                if cronjobs: 
                    if cronjobs.lower() == "all":
                        cronjobs = None
                    cronjobList = await getCronjobsList(functional_environment, cluster, region, namespace, cronjobs)
                    if cronjobList and len(cronjobList) > 0:
                        resultAction = await getCronjobsAction(functional_environment, cluster, region, namespace, cronjobList, action, paramAction)
                        if resultAction and len(resultAction) > 0:
                            await cronjobActionAuditRecord(ldap, functional_environment, cluster, region, namespace, cronjobList, action, paramAction, resultAction)
                    else:
                        logger.info(f"No cronjobs for {action} process in {cluster} > {namespace}")
                        resultAction = []
                    logger.info(f"finished cronjobsAction ({action}) process")
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting cronjobsAction ({action}) process")
            if cronjobs: 
                if cronjobs.lower() == "all":
                    cronjobs = None
                cronjobList = await getCronjobsList(functional_environment, cluster, region, namespace, cronjobs)
                if cronjobList and len(cronjobList) > 0:
                    resultAction = await getCronjobsAction(functional_environment, cluster, region, namespace, cronjobList, action, paramAction)
                    if resultAction and len(resultAction) > 0:
                        await cronjobActionAuditRecord(ldap, functional_environment, cluster, region, namespace, cronjobList, action, paramAction, resultAction)
                else:
                    logger.info(f"No cronjobs for {action} process in {cluster} > {namespace}")
                    resultAction = []
                logger.info(f"finished cronjobsAction ({action}) process")
    
    return resultAction

async def cronjobsAuditTreatment(functional_environment, cluster, auth, ldap,  region = None, namespace = None, date= None, user= None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")            
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                return await searchAuditLog(functional_environment, cluster, region, namespace, date, user)
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await searchAuditLog(functional_environment, cluster, region, namespace, date, user)

async def cronjobsDownloadTreatment(functional_environment, cluster, auth, ldap, region, namespace, cronjobs = None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                logger.info(f"starting cronjobDownload process")
                resultDownload = await getCronjobsDownload(functional_environment, cluster, region, namespace, cronjobs)
                if resultDownload:
                    logger.info(f"finished cronjobBackupDownload process")
                    
                    if cronjobs is None:
                        return Response(content=resultDownload, media_type="application/zip")
                    else:
                        return Response(content=resultDownload, media_type="application/x-yaml")
                else:
                    logger.error(f"Cronjob file(s) not found")
                    raise HTTPException(status_code=404, detail="Cronjob file(s) not found")
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            logger.info(f"starting cronjobBackupDownload process")
            resultDownload = await getCronjobsDownload(functional_environment, cluster, region, namespace, cronjobs)
            if resultDownload:
                logger.info(f"finished cronjobBackupDownload process")
                if cronjobs is None:
                    return Response(content=resultDownload, media_type="application/zip")
                else:
                    return Response(content=resultDownload, media_type="application/x-yaml")
            else:
                logger.error(f"Cronjob backup file(s) not found")
                raise HTTPException(status_code=404, detail="Cronjob backup file(s) not found")