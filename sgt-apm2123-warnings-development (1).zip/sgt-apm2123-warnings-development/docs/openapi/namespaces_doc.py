""" Get warnings of microservices. """

from pydantic import BaseModel, Field
from typing import Optional
from src.models.warnings_model import WarningModel

DEVOPS_OWNER = "Devops owner of the detected project"

class NamespacesRequest(WarningModel):
    
    pass
class NamespacesResponse(BaseModel):
    devops: str = Field(json_schema_extra={"description":DEVOPS_OWNER,'examples': ['Peter Parker']})  
    cluster: str = Field(json_schema_extra={"description":"cluster",'examples': ["ocp5azure"]})
    region: str = Field(json_schema_extra={"description":"region",'examples': ["weu1"]})
    configuration_object: str = Field(json_schema_extra={"description":"object where wrong routing is",'examples': ["configuration-service-g"]})
    file: str = Field(json_schema_extra={"description":"file where the wrong routing is",'examples': ["application.yaml"]})
    wrong_routing: str = Field(json_schema_extra={"description":"wrong routing",'examples': ["isban.dev.corp"]})
