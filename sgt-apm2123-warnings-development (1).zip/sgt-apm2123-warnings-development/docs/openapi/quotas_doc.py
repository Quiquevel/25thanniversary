""" Get warnings of microservices. """

from pydantic import BaseModel, Field
from typing import Optional
from src.models.warnings_model import WarningModel

class QuotasRequest(WarningModel):
    
    pass

class QuotasResponse(BaseModel):
    devops: str = Field(json_schema_extra={"description":"Devops owner of the detected project",'examples': ['Peter Parker']})  
    cluster: str = Field(json_schema_extra={"description":"cluster",'examples': ["ocp5azure"]})
    region: str = Field(json_schema_extra={"description":"region",'examples': ["weu1"]})
    namespace: str = Field(json_schema_extra={"description":"namespace",'examples': ["sanes-shuttle-pro"]})
    quotaswarning: str = Field(json_schema_extra={"description":"quotas warning",'examples': ["replicaSets"]})
    quotasexceeded: str = Field(json_schema_extra={"description":"quotas exceeded",'examples': ["replicaSets"]})
