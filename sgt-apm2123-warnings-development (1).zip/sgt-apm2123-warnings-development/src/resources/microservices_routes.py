"""
This module contains the implementation of the FastAPI resources for the xxxxx and xxxxxx endpoints.
"""
from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from src.services.microservices import get_mismatched_variables_warning, get_difference_between_regions,get_paused_rollouts,get_hc_failurethreshold
from docs.openapi.microservices_doc import MicroservicesRequest, MismatchedVariablesResponse, PausedRolloutsResponse, MicroservicesDiffResponse, MicroservicesDiffRequest

microswarnings = APIRouter(tags=["microservices"],prefix="/api/v1/warnings")

@microswarnings.post("/get_mismatched_variables",response_model=MismatchedVariablesResponse)
async def mismatched_variables(mismatchedvariables:MicroservicesRequest):
    """
    Endpoint for getting mismatched variables warning.
    
    This endpoint receives a request with the following parameters:

    - functional_environment: str
    - cluster: str
    - region: str
    - namespace: str
    
    It returns a JSON response with the result of the get_mismatched_variables_warning function.
    
    """
    result = await get_mismatched_variables_warning(cluster=mismatchedvariables.cluster, region=mismatchedvariables.region, namespaceslist=mismatchedvariables.namespaceslist)

    return JSONResponse(content={
                                    "result": result
                                }, status_code=200)

@microswarnings.post("/get_difference_btw_regions",response_model=MicroservicesDiffResponse)
async def micros_r1r2_diff(difference:MicroservicesDiffRequest):
    """
    Endpoint for getting regions differences warning.
    
    This endpoint receives a request with the following parameters:

    - functional_environment: str
    - cluster: str
    - region: str
    - namespace: str
    - option: str 
        - image
        - envVar
        - resources
    
    It returns a JSON response with the result of the get_difference_between_regions function.
    
    """
    
    result = await get_difference_between_regions(cluster=difference.cluster, namespaceslist=difference.namespaceslist,option=difference.option)

    return JSONResponse(content={
                                    "result": result
                                }, status_code=200)

@microswarnings.post("/get_paused_rollouts",response_model=PausedRolloutsResponse)
async def micros_paused(micro_paused:MicroservicesRequest):
    """
    Endpoint for getting paused rollouts warning.
    
    This endpoint receives a request with the following parameters:

    - functional_environment: str
    - cluster: str
    - region: str
    - namespace: str
    
    It returns a JSON response with the result of the get_paused_rollouts function.
    
    """
    
    result = await get_paused_rollouts(cluster=micro_paused.cluster,region=micro_paused.region, namespaceslist=micro_paused.namespaceslist)

    return JSONResponse(content={
                                    "result": result
                                }, status_code=200)


@microswarnings.post("/get_hc_failurethreshold",response_model=PausedRolloutsResponse)
async def hc_failurethreshold(failure_threshold:MicroservicesRequest):
    """
    Endpoint for getting failure threshold set to 1 warning.
    
    This endpoint receives a request with the following parameters:

    - functional_environment: str
    - cluster: str
    - region: str
    - namespace: str
    
    It returns a JSON response with the result of the get_hc_failurethreshold function.
    
    """
    
    result = await get_hc_failurethreshold(cluster=failure_threshold.cluster, region=failure_threshold.region,namespaceslist=failure_threshold.namespaceslist)

    return JSONResponse(content={
                                    "result": result
                                }, status_code=200)
