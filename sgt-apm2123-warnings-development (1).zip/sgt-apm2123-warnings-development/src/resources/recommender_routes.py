"""
This module handles external requests for the microservice.
"""
from shuttlelib.utils.logger import logger
from fastapi import APIRouter
import urllib3
from src.services.recommender import get_configuration, get_recommendation, get_diff, diff_final, get_configuration_memory_leak
from src.models.recomender_model import getDiffRequest, getConfigurationRequest, getRecomenderRequest, getFinalDiffRequest

urllib3.disable_warnings()

recommender_review = APIRouter(tags=["Recommender"], prefix="/api/v1/recommender_review")


@recommender_review.post("/get_configuration" )
async def get_configuration_api(target: getConfigurationRequest):
    """
    Asynchronously retrieves the current configuration for a specified cluster and namespace.
    Args:
        target (getRequest): An object containing the 'cluster' and 'namespace' attributes used to fetch the configuration.
    Returns:
        The result of the configuration retrieval, as returned by the get_configuration function.
    Logs:
        Logs an informational message indicating that the configuration is being retrieved.
    """

    logger.info("Retrieving actual configuration")
    result = get_configuration(
        cluster=target.cluster, 
        namespace=target.namespace,
        region=target.region,
        b_g_model=target.b_g_model
    )
    return result

@recommender_review.post("/get_recommendation" )
async def get_recommendation_api(target: getRecomenderRequest):
    """
    Asynchronously retrieves a recommended configuration for a given target.

    Args:
        target (getRequest): An object containing the cluster and namespace information for which the recommendation is requested.

    Returns:
        Any: The recommended configuration result as returned by the get_recomendation function.

    Logs:
        Logs an info message indicating the retrieval of the recommended configuration.
    """
    logger.info("Retrieving recommended configuration")
    result = get_recommendation(
        cluster=target.cluster, 
        namespace=target.namespace
    )
    return result

@recommender_review.post("/get_diff" )
async def get_diff_api(target: getDiffRequest):
    """
    Asynchronously retrieves the difference between the recommended and actual configuration for a given cluster and namespace.

    Args:
        target (getDiffRequest): An object containing the cluster, namespace, and a flag indicating whether to return only differing parameters.

    Returns:
        dict: The result of the diff operation, detailing the differences between the recommended and actual configuration.

    Logs:
        Logs an info message indicating the retrieval of the diff.
    """
    logger.info("Retrieving diff between recommended and actual configuration")
    result = get_diff(
        cluster=target.cluster, 
        namespace=target.namespace,
        only_diff_parameters=target.only_diff_parameters,
        b_g_model=target.b_g_model
    )
    return result

@recommender_review.post("/diff_final" )
async def get_diff_final_api(target: getFinalDiffRequest):
    """
    Asynchronously retrieves the final differences between the recommended and actual configuration for a given cluster and namespace.

    Args:
        target (getFinalDiffRequest): An object containing the cluster, namespace, and a flag indicating whether to return only differing parameters.

    Returns:
        dict: The result of the diff operation, detailing the differences between the recommended and actual configuration.

    Logs:
        Logs an info message indicating the retrieval of the diff.
    """
    logger.info("Retrieving diff between recommended and actual configuration")
    result = await diff_final(
        cluster=target.cluster, 
        namespace=target.namespace,
        only_diff_parameters=target.only_diff_parameters,
        b_g_model=target.b_g_model
    )
    return result

@recommender_review.post("/get_configuration_memory_leak" )
async def get_configuration_memory_leak_api(target: getConfigurationRequest):
    """
    Asynchronously retrieves the current configuration for a specified cluster and namespace.
    Args:
        target (getRequest): An object containing the 'cluster' and 'namespace' attributes used to fetch the configuration.
    Returns:
        The result of the configuration retrieval, as returned by the get_configuration function.
    Logs:
        Logs an informational message indicating that the configuration is being retrieved.
    """

    logger.info("Retrieving actual configuration")
    result = get_configuration_memory_leak(
        cluster=target.cluster, 
        namespace=target.namespace,
        region=target.region,
        b_g_model=target.b_g_model
    )
    return result
