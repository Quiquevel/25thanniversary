''' This file defines the routers for various services in the application. Each router is responsible 
for handling specific routes related to microservices, services, namespaces, HPAs, and quotas. The 
routers are instantiated as RouteClass objects with their respective warning routes. '''
from .microservices_routes import microswarnings
from .services_routes import serviceswarnings
from .namespaces_routes import namespaceswarnings
from .hpas_routes import hpaswarnings
from .quotas_routes import quotaswarnings
from .recommender_routes import recommender_review
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(microswarnings,["microservices"]),
    RouteClass(serviceswarnings,["services"]),
    RouteClass(namespaceswarnings,["namespaces"]),
    RouteClass(hpaswarnings,["hpas"]),
    RouteClass(quotaswarnings,["quotas"]),
    RouteClass(recommender_review,["Recommender"])
]
