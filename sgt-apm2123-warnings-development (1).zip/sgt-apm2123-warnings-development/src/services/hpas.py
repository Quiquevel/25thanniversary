'''This module defines the WarningModel class used for handling warning data in the application.'''
import shuttlelib.db.mongo as mongolib
import os
from shuttlelib.utils.logger import logger
from src.services.devops import get_data_from_knowledge
from src.services.outputdict import set_output_base_dict
from src.services.namespaces import get_production_block

mg = mongolib.MongoClient()
mongocollection = os.getenv("COLLECTION_HPAS")
mg.change_collection(collection=mongocollection)

async def check_min_man(cluster=None,region=None,namespaceslist=None):
    '''Check if the minReplicas and maxReplicas of the HPA are equal, which indicates that the HPA is not scaling.'''


    query = [{}]

    if cluster != None:
        query.append({"cluster": cluster})

    if region != None:
        query.append({"region": region})

    if namespaceslist != None:
        query.append({"namespace": {"$in": namespaceslist}})
    
    #Sometimes the HPA min replicas = max replicas = 1 when is the hidden block, depending on what leveling tool was used.
    query.append({"minReplicas": {"$gt": 1}})

    fullquery = {"$and": query}

    mongodata = mg.find(fullquery)
    logger.info(f"Querying MongoDB with: {fullquery}")
    
    outputlist = []

    for data in mongodata:
        logger.info(f"Checking HPA {data['name']} in namespace {data['namespace']} for minReplicas and maxReplicas.")
        hpa_name= data["name"]
        min_replicas = data["minReplicas"]
        max_replicas = data["maxReplicas"]

        outputdict = {}

        if min_replicas == max_replicas:
            block = await get_production_block(data["namespaceid"])
            logger.info(f"HPA {data['name']} in namespace {data['namespace']} has minReplicas = maxReplicas = {min_replicas}.")
            outputdict = await set_output_base_dict(data)
            outputdict.update({"block": block})
            outputdict.update({"hpaname": hpa_name})
            outputdict.update({"min_replicas": min_replicas})
            outputdict.update({"max_replicas": max_replicas})
            
            outputlist.append(outputdict)

    return outputlist

async def check_unable_condition(cluster=None,region=None,namespaceslist=None):
    '''Check if the HPA has the condition "AbleToScale" set to False, which indicates that the HPA is unable to scale.'''


    query = [{}]

    if cluster != None:
        query.append({"cluster": cluster})

    if region != None:
        query.append({"region": region})

    if namespaceslist != None:
        query.append({"namespace": {"$in": namespaceslist}})

    fullquery = {"$and": query}
    logger.info(f"Querying MongoDB with: {fullquery}")
    mongodata = mg.find(fullquery)
    
    outputlist = []

    for data in mongodata:
        logger.info(f"Checking HPA {data['name']} in namespace {data['namespace']} for unable to scale condition.")
        try:
            abletoscale = data["ableToScale"]
        except KeyError:
            abletoscale = None

        outputdict = {}

        if abletoscale == "False":
            block = await get_production_block(data["namespaceid"])
            logger.info(f"HPA {data['name']} in namespace {data['namespace']} is unable to scale.")
            outputdict = await set_output_base_dict(data)

            hpadata = {
                "hpaname": data["name"],
                "scaleTargetKind": data["scaleTargetKind"],
                "scaleTargetName": data["scaleTargetName"],
                "scaleTargetApiVersion": data["scaleTargetApiVersion"]
            }

            outputdict.update({"hpadata": hpadata})

            message = "unknown"
            for condition in data["hpaconditions"]:
                if condition["type"] == "AbleToScale":
                    message = condition["message"]

            abletoscale_msg = f'Unable to scale. Reason: {message}'
            outputdict.update({"block": block})
            outputdict.update({"abletoscale": abletoscale_msg})
            outputlist.append(outputdict)

    return outputlist

async def check_scalingactive_condition(cluster=None,region=None,namespaceslist=None):
    '''Check if the HPA has the condition "scalingActive" set to True, which indicates that the HPA is scaling without problems.'''


    query = [{}]

    if cluster != None:
        query.append({"cluster": cluster})

    if region != None:
        query.append({"region": region})

    if namespaceslist != None:
        query.append({"namespace": {"$in": namespaceslist}})

    #getting the scalingActive condition set to False but not the one that is False because the target replicas is 0
    query.append({
        "$and": [
            {"scalingActive": "False"},
            {"hpaconditions.message": {"$ne": "scaling is disabled since the replica count of the target is zero"}}
        ]
    })

    fullquery = {"$and": query}
    logger.info(f"Querying MongoDB with: {fullquery}")
    mongodata = mg.find(fullquery)
    
    outputlist = []

    for data in mongodata:
        logger.info(f"Checking HPA {data['name']} in namespace {data['namespace']} for scaling active condition.")

        outputdict = {}

    
        block = await get_production_block(data["namespaceid"])
        logger.info(f"HPA {data['name']} in namespace {data['namespace']} is not actively scaling.")
        outputdict = await set_output_base_dict(data)

        hpadata = {
            "hpaname": data["name"],
            "scaleTargetKind": data["scaleTargetKind"],
            "scaleTargetName": data["scaleTargetName"],
            "scaleTargetApiVersion": data["scaleTargetApiVersion"]
        }

        outputdict.update({"hpadata": hpadata})

        message = "unknown"
        for condition in data["hpaconditions"]:
            if condition["type"] == "ScalingActive":
                message = condition["reason"] + ": " + condition["message"]

        abletoscale_msg = f'Scaling is not active. Reason: {message}'
        outputdict.update({"block": block})
        outputdict.update({"abletoscale": abletoscale_msg})
        outputlist.append(outputdict)

    return outputlist
