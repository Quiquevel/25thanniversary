'''This module defines the WarningModel class used for handling warning data in the application.'''
from src.services.namespaces import get_wrong_routing_dnss_configurationservice
from src.services.configmaps import get_wrong_routing_dns_configmaps
from shuttlelib.utils.logger import logger
from src.services.clientunique import client

import os

async def get_wrong_routing_dns(cluster=None,region=None,namespaceslist=None):
    '''Get the wrong routing DNS for a given cluster, region, namespaceslist'''
    logger.info(
        f"Getting wrong routing DNS for"
        f"cluster: {cluster}, region: {region}"

    )
    configuration_service_list =  await get_wrong_routing_dnss_configurationservice(cluster,region,namespaceslist)
    configmaps_list = await get_wrong_routing_dns_configmaps(cluster,region,namespaceslist)
    outputlist = configuration_service_list + configmaps_list

    return outputlist

async def get_clusters():
    """
    Asynchronously retrieves a list of clusters along with their regions, and returns
    additional environment-related information.
    Returns:
        tuple: A tuple containing:
            - cluster_list (list): A list of dictionaries, where each dictionary represents
              a cluster with its name and associated regions. Example:
              [{"name": "cluster1", "region": ["region1", "region2"]}, ...]
            - entity_id (str or None): The entity ID retrieved from the "ENTITY_ID"
              environment variable.
            - functional_environment (str or None): The functional environment retrieved
              from the "ENVIRONMENT" environment variable.
    Raises:
        Any exceptions raised by the `client.get_resource` method.
    """
    functional_environment=os.getenv("ENVIRONMENT")
    entity_id=os.getenv("ENTITY_ID")
 
    clusters = await client.get_resource(resource="clusters", functional_environment=functional_environment,
                                         cluster=None)
    cluster_list = []
    for cluster in clusters.keys():
        regions = list(clusters[cluster].keys())
        cluster_list.append({"name": cluster, "region": regions})
 
    return cluster_list, entity_id, functional_environment

async def get_namespaces(cluster, functional_environment, region):
    """
    Asynchronously retrieves the list of namespaces for a given cluster, functional environment, and region.

    Args:
        cluster (str): The name of the cluster to query.
        functional_environment (str): The functional environment (e.g., dev, prod) to filter the namespaces.
        region (str): The region to query for namespaces.

    Returns:
        list: A list of namespace names if the region is found in the namespace list; otherwise, an empty list.

    Raises:
        None: This function does not explicitly raise exceptions but logs an error if the region is not found.

    Notes:
        - The function relies on a global `client` object to fetch resources.
        - Logs an error message if the specified region is not found in the namespace list.
    """
    global client
    namespace_list = await client.get_resource(functional_environment=functional_environment, resource="namespaces", region=region, cluster=cluster)
    if region in namespace_list:
        namespaces_names = [dic['metadata']['name'] for dic in namespace_list[region]['items']]
    else:
        logger.error(f"Region '{region}' not found in namespace list.")
        namespaces_names = []
    return namespaces_names

async def get_microservices(cluster, functional_environment, region, namespace):
    """
    Asynchronously retrieves the names of microservices (deployments and deploymentconfigs) 
    from a specified cluster, functional environment, region, and namespace.
    Args:
        cluster (str): The name of the cluster to query.
        functional_environment (str): The functional environment (e.g., dev, prod) to query.
        region (str): The region where the resources are located.
        namespace (str): The namespace within the cluster to query.
    Returns:
        list: A combined list of microservice names from deployments and deploymentconfigs.
    Raises:
        Exception: If there is an issue retrieving resources from the client.
    """
    global client
    
    # Get deployments.
    deployments_list = await client.get_resource(resource="deployments", functional_environment=functional_environment, region=region, cluster=cluster, namespace=namespace)
    deployments_names = [dic['metadata']['name'] for dic in deployments_list[region]['items']]
    
    # Get deploymentconfigs.
    deploymentconfigs_list = await client.get_resource(resource="deploymentconfigs", functional_environment=functional_environment, region=region, cluster=cluster, namespace=namespace)
    deploymentconfigs_names = [dic['metadata']['name'] for dic in deploymentconfigs_list[region]['items']]
    
    # Combine the results.
    microservices_names = deployments_names + deploymentconfigs_names
    
    return microservices_names