''' module: src/services/recommender.py
This module provides functions to retrieve and compare microservice configurations and recommendations from a MongoDB database.'''
import os
import re
from pymongo import MongoClient
from shuttlelib.utils.logger import logger
from bson import ObjectId
from src.services.outputdict import set_output_base_dict, set_all_output_base_dict


host = os.environ.get("MONGODB_HOST", "localhost:27017")
user = os.environ.get("USERMONGO", "mongo-shuttle")
password = os.environ.get("PASSMONGO")
database = os.environ.get("DATABASE", "mongo_shuttle")
CAPACITY = os.environ.get('COLLECTION_RECOMMENDER', 'capacity_sre_recomender')
MICROSERVICES = os.environ.get('COLLECTION_MICROSERVICES', 'sre_microservices')
HPA = os.environ.get('COLLECTION_HPAS', 'sre_hpas')
entity = os.environ.get('ENTITY_ID')
mongo_uri = f"mongodb://{user}:{password}@{host}/{database}"
connection  = MongoClient(mongo_uri)
db = connection [database]

async def diff_final(cluster=None, namespace=None, only_diff_parameters=False, b_g_model=False):
    """
    Asynchronously computes and enriches the differences between configurations for given cluster and namespace combinations.
    Args:
        cluster (str, optional): The cluster identifier to filter results. Defaults to None.
        namespace (str, optional): The namespace identifier to filter results. Defaults to None.
        only_diff_parameters (bool, optional): If True, only parameters with differences are considered. Defaults to False.
        b_g_model (bool, optional): If True, uses blue-green model for diff calculation. Defaults to False.
    Returns:
        list: A list of dictionaries, each representing a configuration difference entry, enriched with 'devops' and 'domain' information for each unique cluster/namespace combination.
    Raises:
        Any exceptions raised by `get_diff` or `set_output_base_dict` will propagate.
    """
    output_prov = get_diff(cluster=cluster, namespace=namespace, only_diff_parameters=only_diff_parameters, b_g_model=b_g_model)
    output_prov, removed_namespaces = await set_all_output_base_dict(data=output_prov, domain=True)

    return output_prov

def get_diff(cluster=None, namespace=None, only_diff_parameters=False, b_g_model=False):
    """
    Compares the current configuration with the recommended configuration for a given cluster and namespace.
    Args:
        cluster (str, optional): The name of the cluster to retrieve configuration and recommendation for. Defaults to None.
        namespace (str, optional): The namespace within the cluster. Defaults to None.
        only_diff_parameters (bool, optional): If True, only parameters that differ between the configuration and recommendation are returned. Defaults to False.
        b_g_model (bool, optional): If True, filters only active microservices based on their status and labels. Defaults to False.
    Returns:
        dict: A unified dictionary containing the comparison between the current configuration and the recommendation, optionally filtered to only show differing parameters.
    """

    data_configuration = get_configuration(cluster=cluster, namespace=namespace, b_g_model=b_g_model)
    data_recomendation = get_recommendation(cluster=cluster, namespace=namespace)
    unified = unify_configuration_and_recommendation(data_configuration=data_configuration,
                                                    data_recomendation=data_recomendation,
                                                    only_diff_parameters=only_diff_parameters)
    return unified

def get_configuration_memory_leak(cluster=None, namespace=None, region=None, b_g_model=False):  
    """
    Retrieves and filters configuration data for microservices that have been identified with memory leaks.
    This function fetches configuration data and memory leak recommendations for microservices within a specified cluster and namespace.
    It then filters the configuration data to include only those microservices that are present in the memory leak recommendations.
    Args:
        cluster (str, optional): The name of the cluster to filter by. Defaults to None.
        namespace (str, optional): The namespace to filter by. Defaults to None.
        b_g_model (bool, optional): Flag to indicate whether to use the blue/green model. Defaults to False.
    Returns:
        list: A list of filtered configuration dictionaries for microservices with memory leak recommendations.
    """


    data_configuration = get_configuration(cluster=cluster, namespace=namespace, region=region, b_g_model=b_g_model, hpa_name=True)
    data_recommendation = get_recommendation(cluster=cluster, namespace=namespace, only_memory_leak=True)

    recommendation_keys = set(
        (d.get("cluster"), d.get("namespace"), d.get("microservice"))
        for d in data_recommendation
    )

    unified = [
        d for d in data_configuration
        if (d.get("cluster"), d.get("namespace"), clean_microservice_name(d.get("microservice"))) in recommendation_keys
    ]

    return unified

def get_recommendation(cluster=None, namespace=None, only_memory_leak=False):
    """
    Fetches and processes microservice recommendation data from the MongoDB 'capacity' collection.
    This function builds a MongoDB aggregation pipeline to retrieve and transform recommendation data
    for microservices, optionally filtered by cluster and namespace. It processes the results to:
    - Replace "N/A" string values with None.
    - Extract numeric values from the 'HEAP_MaxRAM' field if present in the format "MaxRAM <number>".
    - Convert 'HPA_CPU_Target' percentage strings to integer values.
    - Optionally renames the 'cluster' field for specific conditions.
    - Removes the 'replicasBase' field from the output.
    Args:
        cluster (str, optional): The cluster name to filter recommendations. Defaults to None.
        namespace (str, optional): The namespace to filter recommendations. Defaults to None.
    Returns:
        list[dict]: A list of dictionaries containing processed recommendation data for each microservice.
    """
    try:
        capacity = db[CAPACITY]
    except Exception as ex:
        logger.error(f"{ex}")
    match_query = build_mongo_query(cluster=cluster, namespace=namespace)
    if only_memory_leak:
        match_query["microservices.commentMEM"] = "Possible Memory Leak"

    query = [
        {"$unwind": "$microservices"},
        {"$match": match_query},
        {"$project": {
            "_id": 0,
            "cluster": 1,
            "namespace": 1,
            "microservice": "$microservices.microservice",
            "CPU_Request": "$microservices.recomenderCPURequest",
            "CPU_Limit": "$microservices.recomenderCPULimit",
            "MEM_Request": "$microservices.recomenderMEMRequestInt",
            "MEM_Limit": "$microservices.recomenderMEMLimitInt",
            "HEAP_MaxRAM": "$microservices.commentMEM",
            "replicasBase": "$microservices.replicasBase",
            "HPA_MINReplicas": "$microservices.recomenderMINReplicas",
            "HPA_MAXReplicas": "$microservices.recomenderMAXReplicas",
            "HPA_CPU_Target": "$microservices.recomenderTarget"
        }}
    ]      

    data = []
    for d in capacity.aggregate(query):
        doc = serialize_mongo_doc(d)
        for k, v in doc.items():
            if isinstance(v, str) and v.strip() == "N/A":
                doc[k] = None
        heap = doc.get("HEAP_MaxRAM")
        if isinstance(heap, str):
            match = re.search(r"MaxRAM\s+([0-9]+(?:\.[0-9]+)?)", heap)
            if match:
                doc["HEAP_MaxRAM"] = float(match.group(1))
            elif heap.strip() == "N/A":
                doc["HEAP_MaxRAM"] = None
        
        hpa_cpu = doc.get("HPA_CPU_Target")
        if isinstance(hpa_cpu, str):
            match = re.match(r"^(\d+(?:\.\d+)?)\%$", hpa_cpu.strip())
            if match:
                doc["HPA_CPU_Target"] = int(float(match.group(1)))
            del doc["replicasBase"]  
        data.append(doc)
        if doc.get("cluster") == "azure" and entity == "spain":
            doc["cluster"] = "ocp05azure"

    return data

def get_configuration(cluster=None, namespace=None, region=None, b_g_model=False, hpa_name=False):
    """
    Retrieves and processes configuration information for microservices and their associated Horizontal Pod Autoscaler (HPA) settings from a MongoDB database.
    Args:
        cluster (str, optional): The name of the Kubernetes cluster to filter microservices. Defaults to None.
        namespace (str, optional): The namespace within the cluster to filter microservices. Defaults to None.
        region (str, optional): The region to filter microservices. Defaults to None.
        hpa_name (bool, optional): If True, includes the HPA name in the output. Defaults to False.
        b_g_model (bool, optional): If True, filters only active microservices based on their status and labels. Defaults to False.
    Returns:
        list[dict]: A list of dictionaries, each containing configuration details for a microservice, including resource requests/limits, environment variables, and HPA settings if applicable.
    Notes:
        - Converts memory values from Gi to Mi (multiplies by 1024).
        - Extracts the 'MaxRAMPercentage' value from the JAVA_OPTS_EXT environment variable if present.
        - Merges HPA configuration into the microservice configuration if HPA exists.
        - Removes intermediate keys such as 'hpaexists' and 'replicasBase' from the final output.
        - Logs errors encountered during database access.
    """

    match_query_microservice = build_mongo_query(cluster=cluster, namespace=namespace, region=region)
    if b_g_model:
        match_query_microservice["micro_status.block"] = {"$in":["Real","Unknown","On"]}

    try:
        microservice = db[MICROSERVICES]
    except Exception as ex:
        logger.error(f"{ex}")

    query_microservice = [
        {"$unwind": "$envVar"},
        {"$match": match_query_microservice},
        { "$project":
            {
            "_id": 0,
            "cluster": "$cluster",
            "namespace": "$namespace",
            "region": "$region",
            "microservice":"$name",
            "kind": "$kind",
            "hpaexists": "$hpaexists",
            "replicasBase": "$replicas.actualreplicas",
            "CPU_Request": "$resources.cpu.request_milicores",
            "CPU_Limit": "$resources.cpu.limit_milicores",
            "MEM_Request": "$resources.memory.request_Gi",
            "MEM_Limit": "$resources.memory.limit_Gi",
            "JAVA_OPTS_EXT":"$microservices.envVar.JAVA_OPTS_EXT",
            "MaxRAMPercentage":
                {
                "$regexFind" : 
                    {
                    "input": "$envVar.JAVA_OPTS_EXT",
                    "regex": "MaxRAMPercentage=([0-9]+\\.?[0-9]*)"
                    }
                }
            }
        },
        { "$project":
            {
            "_id": 0,
            "cluster": "$cluster",
            "namespace": "$namespace",
            "region": "$region",
            "microservice":"$microservice",
            "kind": "$kind",
            "hpaexists": "$hpaexists",
            "replicasBase": "$replicasBase",
            "CPU_Request": "$CPU_Request",
            "CPU_Limit": "$CPU_Limit",
            "MEM_Request": "$MEM_Request",
            "MEM_Limit": "$MEM_Limit",
            "HEAP_MaxRAM": { "$arrayElemAt": ["$MaxRAMPercentage.captures", 0] }
            }
        }
        ]

    data_configuration = [serialize_mongo_doc(d) for d in microservice.aggregate(query_microservice)]

    for d in data_configuration:
        heap = d.get("HEAP_MaxRAM")
        if isinstance(heap, str):
            try:
                d["HEAP_MaxRAM"] = float(heap)
            except ValueError:
                d["HEAP_MaxRAM"] = None
        mem_request = d.get("MEM_Request")
        mem_limit = d.get("MEM_Limit")
        d["MEM_Request"] = int(mem_request * 1024) if mem_request is not None else None
        d["MEM_Limit"] = int(mem_limit * 1024) if mem_limit is not None else None

    filtered_data = filter_data(data_configuration=data_configuration, b_g_model=b_g_model)

    try:
        hpa = db[HPA]
    except Exception as ex:
        logger.error(f"{ex}")

    match_query = build_mongo_query(cluster=cluster, namespace=namespace)
    query_hpa = [
    {"$match": match_query},
    {"$project": {
        "_id": 0,
        "cluster": 1,
        "region": 1,
        "namespace": 1,
        "scaleTargetKind" : 1,
        "microservice": "$scaleTargetName",
        "HPA_MINReplicas": "$minReplicas",
        "HPA_MAXReplicas": "$maxReplicas",
        "HPA_CPU_Target": "$targetCPUUsage"
    }}
    ]
    if hpa_name:
        query_hpa[1]["$project"]["name"] = 1  
        
    data_hpa = [serialize_mongo_doc(d) for d in hpa.aggregate(query_hpa)]

    for d in filtered_data:
        if d.get("hpaexists"):
            hpa_obj = next(
                (h for h in data_hpa
                 if h.get("cluster") == d.get("cluster")
                 and h.get("namespace") == d.get("namespace")
                 and h.get("microservice") == d.get("microservice")
                 and h.get("scaleTargetKind") == d.get("kind")),
                None
            )
            if hpa_obj:
                d["HPA_MINReplicas"] = hpa_obj.get("HPA_MINReplicas")
                d["HPA_MAXReplicas"] = hpa_obj.get("HPA_MAXReplicas")
                d["HPA_CPU_Target"] = hpa_obj.get("HPA_CPU_Target")
                if hpa_name:
                    d["HPA_Name"] = hpa_obj.get("name")
            del d["replicasBase"]        
        del d["hpaexists"]
        del d["kind"]

    return filtered_data

def unify_configuration_and_recommendation(data_configuration, data_recomendation, only_diff_parameters=False):
    """
    Compares and unifies configuration and recommendation data for microservices.
    Args:
        data_configuration (list of dict): List of configuration dictionaries, each representing a microservice's current settings.
        data_recomendation (list of dict): List of recommendation dictionaries, each representing suggested settings for a microservice.
        only_diff_parameters (bool, optional): If True, only include fields where configuration and recommendation differ significantly. Defaults to False.
    Returns:
        list of dict: A list of unified entries, each containing:
            - 'cluster': Cluster identifier.
            - 'namespace': Namespace identifier.
            - 'microservice': Cleaned microservice name.
            - 'Configuration': Dictionary of configuration values (all fields or only differing ones).
            - 'Recomendation': Dictionary of recommendation values (all fields or only differing ones).
    Notes:
        - The function uses a unique key (cluster, namespace, cleaned microservice name) to match configuration and recommendation entries.
        - The comparison of values is determined by the `is_significant_difference` function.
        - The `clean_microservice_name` function is used to normalize microservice names for matching.
    """

    def key(doc):
        return (
            doc.get("cluster"),
            doc.get("namespace"),
            clean_microservice_name(doc.get("microservice"))
        )

    config_dict = {key(d): d for d in data_configuration}
    rec_dict = {key(d): d for d in data_recomendation}

    unified = []
    all_keys = set(config_dict.keys()) | set(rec_dict.keys())

    fields = [
        "CPU_Request", "CPU_Limit", "MEM_Request", "MEM_Limit",
        "HEAP_MaxRAM", "replicasBase", "HPA_MINReplicas", "HPA_MAXReplicas", "HPA_CPU_Target"
    ]

    for k in all_keys:
        conf = config_dict.get(k, {})
        rec = rec_dict.get(k, {})
        microservice_clean = k[2]
        if only_diff_parameters:
            diff_conf = {}
            diff_rec = {}
            for f in fields:
                v_conf = conf.get(f, None)
                v_rec = rec.get(f, None)
                if is_significant_difference(f, v_conf, v_rec):
                    diff_conf[f] = v_conf
                    diff_rec[f] = v_rec
            if diff_conf or diff_rec:
                entry = {
                    "cluster": k[0],
                    "namespace": k[1],
                    "microservice": microservice_clean,
                    "Configuration": diff_conf,
                    "Recomendation": diff_rec
                }
                unified.append(entry)
        else:
            conf_values = {f: conf.get(f) for f in fields}
            rec_values = {f: rec.get(f) for f in fields}
            if any(is_significant_difference(f, conf_values[f], rec_values[f]) for f in fields):
                entry = {
                    "cluster": k[0],
                    "namespace": k[1],
                    "microservice": microservice_clean,
                    "Configuration": conf_values,
                    "Recomendation": rec_values
                }
                unified.append(entry)
    return unified

def is_significant_difference(f, v_conf, v_rec):
    """
    Devuelve True si los valores son significativamente diferentes.
    Para MEM_Request y MEM_Limit, solo si la diferencia es >= 10%.
    Para el resto, si son distintos.
    """
    if f in ["MEM_Request", "MEM_Limit"]:
        try:
            if v_conf is None or v_rec is None:
                return v_conf != v_rec
            v_conf_num = float(v_conf)
            v_rec_num = float(v_rec)
            if v_conf_num == 0 and v_rec_num == 0:
                return False
            if v_conf_num == 0 or v_rec_num == 0:
                return True
            percent_diff = abs(v_conf_num - v_rec_num) / max(abs(v_conf_num), abs(v_rec_num))
            return percent_diff >= 0.10
        except Exception:
            return v_conf != v_rec
    else:
        return v_conf != v_rec

def build_mongo_query(cluster=None, namespace=None, region=None):
    """
    Builds a MongoDB query dictionary based on the provided cluster, namespace, and region.
    Args:
        cluster (str, optional): The name of the cluster to filter by. Defaults to None.
        namespace (str, optional): The namespace to filter by. Defaults to None.
        region (str, optional): The region to filter by. Defaults to None.
    Returns:
        dict: A dictionary representing the MongoDB query with the specified filters.
    """
    query = {}

    if cluster is not None:
        query["cluster"] = cluster
    if namespace is not None:
        query["namespace"] = namespace
    if region is not None:
        query["region"] = region
    return query


def serialize_mongo_doc(doc):
    """
    Converts a MongoDB document to a serializable dictionary.

    If the document contains an '_id' field of type ObjectId, it converts it to a string.
    This is useful for preparing MongoDB documents for JSON serialization.

    Args:
        doc (dict): The MongoDB document to serialize.

    Returns:
        dict: The serialized document with '_id' as a string if applicable.
    """
    doc = dict(doc)
    if "_id" in doc and isinstance(doc["_id"], ObjectId):
        doc["_id"] = str(doc["_id"])
    return doc

def clean_microservice_name(name):
    """
    Removes the '-g' or '-b' suffix from the end of a microservice name string, if present.

    Args:
        name (str): The microservice name to clean.

    Returns:
        str: The cleaned microservice name with '-g' or '-b' suffix removed, if it was present.
             If the input is not a string, returns the input unchanged.
    """
    if isinstance(name, str):
        return re.sub(r'(-g|-b|-green|-blue)$', '', name)
    return name

def filter_data(data_configuration, b_g_model=False):
    """
    Filters a list of microservice configurations based on their suffixes and replica count,
    grouped by cluster and namespace.
    Args:
        data_configuration (list of dict): List of microservice configuration dictionaries. 
            Each dictionary should contain at least the keys "microservice" (str), "replicasBase" (int),
            "cluster" (str), and "namespace" (str).
        b_g_model (bool, optional): If True, separates microservices into 'b' (blue) and 'g' (green) 
            groups based on their name suffixes ("-b", "-blue", "-g", "-green") within each cluster/namespace. 
            If False, all qualifying microservices are grouped together. Defaults to False.
    Returns:
        list of dict: A filtered list of microservice configurations. If `b_g_model` is True, 
            for each cluster/namespace combination, returns the group ('b' or 'g') with more elements, 
            combined with any microservices that do not match the suffixes. If `b_g_model` is False, 
            returns all qualifying microservices (with replicasBase > 0).
    """
    
    b_suffixes = ("-b", "-blue")
    g_suffixes = ("-g", "-green")
    
    grouped_data = {}
    for d in data_configuration:
        cluster = d.get("cluster", "")
        namespace = d.get("namespace", "")
        key = (cluster, namespace)
        
        if key not in grouped_data:
            grouped_data[key] = []
        grouped_data[key].append(d)
    
    final_result = []
    
    for (cluster, namespace), group_data in grouped_data.items():
        b_list = []
        g_list = []
        b_cont = 0
        g_cont = 0
        other_list = []
        
        for d in group_data:
            name = d.get("microservice", "")
            replicas_base = d.get("replicasBase", 0)
            
            if replicas_base > 0:
                if b_g_model:    
                    if any(name.endswith(s) for s in b_suffixes):
                        b_list.append(d)
                        b_cont += replicas_base
                    elif any(name.endswith(s) for s in g_suffixes):
                        g_list.append(d)
                        g_cont += replicas_base
                    else:
                        other_list.append(d)
                else:
                    other_list.append(d)
        
        if b_g_model:
            if b_cont > g_cont:
                final_result.extend(b_list + other_list)
            else:
                final_result.extend(g_list + other_list)
        else:
            final_result.extend(other_list)
    
    return final_result