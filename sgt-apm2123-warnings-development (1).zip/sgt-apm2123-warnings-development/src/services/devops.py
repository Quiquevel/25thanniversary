'''This module defines the WarningModel class used for handling warning data in the application.'''
import os, requests, json, aiohttp, asyncio
from shuttlelib.utils.logger import logger

knowledge_URL = os.getenv("KNOWLEDGE_URL", "http://sgt-apm2123-knowledge:8080")
knowledge_API = os.getenv("KNOWLEDGE_API", "/api/v1/knowledge")

async def get_data_from_knowledge(namespace):
    '''Get data from the knowledge API for a given namespace.'''
    option = '/detailnamespace'

    body = {
        'namespace': namespace
    }

    # answer = requests.post(knowledge_URL+knowledge_API+option, json=body, verify=False)

    try:
        async with aiohttp.ClientSession() as session:
                async with session.post(knowledge_URL+knowledge_API+option, json=body ,ssl=True,timeout=aiohttp.ClientTimeout(total=15,connect=10)) as r:
                    if r.status == 200:
                        data = await r.json()
                        logger.info(f'Knowledge API response for namespace {namespace}: {r.status}')
                        return data
                    else: 
                        logger.error(f'Could not get data from knowledge: {r.status}')
                        return []
    except asyncio.TimeoutError:
        logger.error(f'Timeout getting data from {knowledge_URL+knowledge_API+option}')
        return 408  # Request Timeout
    except aiohttp.ClientError as e:
        logger.error(f'Client error : {e}')
        return 502  # Bad Gateway o lo que quieras mapear
    except Exception as e:
        logger.error(f'Unexpected error getting data from knowledge: {e}')
        return 500    
    # Check if the response is successful
    # If the response is successful, parse the JSON data
    
    # if answer.status_code == 200:
    #     data = json.loads(answer.text)
    # else:
    #     data = []

    # return data

async def get_all_data_from_knowledge():
    '''Get all data from the knowledge API.'''

    option = '/get_alldata_namespace_in_knowledge'

    body =  {}

    try:
        async with aiohttp.ClientSession() as session:
                async with session.post(knowledge_URL+knowledge_API+option, json=body ,ssl=True,timeout=aiohttp.ClientTimeout(total=15,connect=10)) as r:
                    if r.status == 200:
                        data = await r.json()
                        logger.info(f'Knowledge API response: {r.status}')
                    else: 
                        logger.error(f'Could not get data from knowledge: {r.status}')
                        data = []
    except asyncio.TimeoutError:
        logger.error(f'Timeout getting data from {knowledge_URL+knowledge_API+option}')
        data = []  # Request Timeout
    except aiohttp.ClientError as e:
        logger.error(f'Client error : {e}')
        data = []  # Bad Gateway o lo que quieras mapear
    except Exception as e:
        logger.error(f'Unexpected error getting data from knowledge: {e}')
        data = []    
    
    # Process data to leave only necessary fields
    processed_data = []
    deleted_data = []
    for d in data:
        # Extraer clusters válidos (ignorar "Deleted" y valores null)
        cluster_names = []
        for cluster in d.get("cluster", []):
            cluster_name = cluster.get("cluster")
            name = cluster.get("name")
            # Filtrar clusters válidos: no null, no "Deleted"
            if cluster_name and name != "Deleted":
                cluster_names.append(cluster_name)
            elif name == "Deleted":
                deleted_data.append(d.get("namespace"))
        
        unique_clusters = list(set(cluster_names))  # Elimina duplicados
        
        # Solo crear entrada si hay clusters válidos
        if unique_clusters:
            # Generar una entrada por cada cluster único
            for cluster_name in unique_clusters:
                processed_item = {
                    "namespace": d.get("namespace"),
                    "devops": d.get("devops", []),
                    "domain": d.get("domain"),
                    "cluster": cluster_name
                }
                processed_data.append(processed_item)

    return processed_data, deleted_data

async def get_devops_list(namespaceinfo, namespace):
    '''Get the list of DevOps for a given namespace from the knowledge API.'''
    logger.info(f'Getting DevOps list for namespace {namespace}')
    devopslist = []
    try:
        for devops in namespaceinfo[0].get("devops", []):
            devopslist.append(devops)

    except Exception as e:
        logger.info(f'No DevOps was gotten from knowledge for {namespace}: {e}')

    return devopslist

async def process_all_devops_list(data):
    '''Process the list of DevOps for all data from the knowledge API.'''
    logger.info(f'Process DevOps list for namespace')

    for item in data:
        devopslist = []
        try:
            for devops in item.get("devops", []):
                devopslist.append(devops)                
                # if destination == "itsm":
                #     uid = devops.get("uid")
                #     if uid:
                #         devopslist.append(uid)
                # else:
                #     name = devops.get("name")
                #     if name:
                #         devopslist.append(name)
                item["devops"] = [{"uid": d.get("uid"), "name": d.get("name")} for d in devopslist if d]
        except Exception as e:
            logger.info(f'No DevOps was gotten from knowledge for {item["namespace"]}: {e}')

    return data
