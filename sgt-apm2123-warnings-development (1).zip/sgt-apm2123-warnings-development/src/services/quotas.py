'''This module defines the WarningModel class used for handling warning data in the application.'''
import shuttlelib.db.mongo as mongolib
from shuttlelib.utils.logger import logger
import os
from src.services.outputdict import set_output_base_dict

mg = mongolib.MongoClient()
mongocollection = os.getenv("COLLECTION")
mg.change_collection(collection=mongocollection)

async def get_full_name(elem):
    '''Get the full name of the element based on its abbreviation.'''
    match elem:
        case "rc": 
            return "replicationControllers"
        case "dcs": 
            return "deploymentConfigs"
        case "cms": 
            return "configMaps"
        case "rs": 
            return "replicaSets"
        case "dss": 
            return "deployments"
        case _:
            return elem


async def get_quotas(cluster=None,region=None,namespaceslist=None):
    '''Get the quotas for a given functional_environment, cluster, region, namespace'''
    quota_warning_percentage = int(os.getenv("QUOTA_WARNING_PERCENTAGE"))
    quota_exceeded_percentage = int(os.getenv("QUOTA_EXCEEDED_PERCENTAGE"))



    query = [{}]

    if cluster != None:
        query.append({"cluster": cluster})

    if region != None:
        query.append({"region": region})

    if namespaceslist != None:
        query.append({"namespace": {"$in": namespaceslist}})

    fullquery = {"$and": query}

    mongodata = mg.find(fullquery)
    logger.info(f'Querying MongoDB with: {fullquery}')
    
    outputlist = []

    objects_to_warn_str = os.getenv("OBJECTS_TO_WARN","")
    objects_to_alert_str = os.getenv("OBJECTS_TO_ALERT","")

    objects_to_warn = [v for v in objects_to_warn_str.split(",") if v]
    objects_to_alert = [v for v in objects_to_alert_str.split(",") if v]

    for data in mongodata:
        logger.info(f'Processing data: {data}')
        quotaexceededlist = []
        quotawarninglist = []
        evaluation = data.get("evaluation",{})
        for element, value in evaluation.items():
            logger.info(f'Checking element {element} with value {value}')
            if "Quota" in element and value is not None:
                if value >= quota_warning_percentage and value < quota_exceeded_percentage:
                    elem = await get_full_name(element[:-5])
                    if elem in objects_to_warn:
                        quotawarninglist.append(elem)
                elif value >= quota_exceeded_percentage:
                    elem = await get_full_name(element[:-5])
                    if elem in objects_to_alert:
                        quotaexceededlist.append(elem)


        if quotaexceededlist != [] or quotawarninglist != []:
            
            outputdict = await set_output_base_dict(data)                 

            outputdict.update({
                "quotawarning": ','.join(quotawarninglist),
                "quotaexceeded": ','.join(quotaexceededlist)
            })

            outputlist.append(outputdict)
    logger.info(f'Output list for quotas: {outputlist}')
    return outputlist