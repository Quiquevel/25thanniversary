'''This module defines the WarningModel class used for handling warning data in the application.'''
import shuttlelib.db.mongo as mongolib
import os
from shuttlelib.utils.logger import logger
from datetime import datetime
from src.services.devops import get_data_from_knowledge, get_devops_list
from src.services.outputdict import set_output_base_dict
from src.services.namespaces import get_production_block

today = datetime.today()
today = datetime(year=today.year,month=today.month,day=today.day)

mg = mongolib.MongoClient()
mg_s = mongolib.MongoClient()
mg_ms = mongolib.MongoClient()

async def get_routing_services(cluster=None,region=None,namespaceslist=None):   
    '''Get the microservices that have routing status KO, meaning they are not routing traffic correctly.'''
    mongocollection = os.getenv("COLLECTION")
    mg.change_collection(collection=mongocollection)
    exceptednamespaces = os.getenv("EXCEPTED_NAMESPACES_FOR_ROUTING_SERVICES","")
    exceptednamespaces = [v for v in exceptednamespaces.split(",") if v]
    exceptedmicroservices = os.getenv("EXCEPTED_MICROS_FOR_ROUTING_SERVICES","")
    exceptedmicroservices= [v for v in exceptedmicroservices.split(",") if v]

    ## NO SERVICE ROUTING TO THIS MICROSERVICE
    query = [{}]

    if cluster != None:
        query.append({"cluster": cluster})

    if region != None:
        query.append({"region": region})

    if namespaceslist != None:
        query.append({"namespace": {"$in": namespaceslist}})

    fullquery = {"$and": query}

    mongodata = mg.find(fullquery)
    logger.info(f"Querying MongoDB with: {fullquery}")
    
    outputlist = []

    logger.info('Processing data from MongoDB')
    routing_ko_list = [data["namespaceid"] for data in mongodata if data.get("evaluation",{}).get("routing_status") == "KO"]
    
    noserviceslist = os.getenv("NO_SERVICES_MICROS","")
    noserviceslist = [v for v in noserviceslist.split(",") if v]
    if routing_ko_list != []:
        mongocollection = os.getenv("COLLECTION_MICROSERVICES")
        mg.change_collection(collection=mongocollection)

        for namespaceid in routing_ko_list:
            logger.info(f'Processing {namespaceid} for routing KO')
            if any(ns in namespaceid for ns in exceptednamespaces) or any(cluster in namespaceid for cluster in ["confluent","probks","dmzbbks"]):
                continue

            mongodata = mg.find({"namespaceid": namespaceid})
            microservicelist = []
            for micro in mongodata:
                logger.info(f'Processing microservice in namespace  {namespaceid}')
                if micro["name"] not in noserviceslist and micro["micro_status"]["reason"] == "No services routing to this microservice" and not any(microservice in micro["name"] for microservice in exceptedmicroservices):
                    #double check if micro's name contains noserviceslist name:
                    if not any(noserviceselem in micro["name"] for noserviceselem in noserviceslist):
                        microservicelist.append(micro["kind"]+"-"+micro["name"])
            
            if microservicelist != []:
                logger.info(f'Found microservices with routing KO in namespaceid {namespaceid}: {microservicelist}')
                cluster = namespaceid[:namespaceid.find("-")]
                nocluster = namespaceid[namespaceid.find("-")+1:]
                region = nocluster[:nocluster.find("-")]
                namespace = namespaceid[len(cluster)+1+len(region)+1:]

                microservicestr = ','.join(microservicelist)

                #Not setting outputdict like in other codes because of the way the data is looped here (not getting info directly from mongo)
                namespaceinfo = await get_data_from_knowledge(namespace[:-4])
                logger.info(f'Getting info of namespace {namespace}')
                devopslist = await get_devops_list(namespaceinfo,namespace)

                block = await get_production_block(namespaceid=namespaceid)
                outputdict = {
                    #"devops": ",".join(devopslist),
                    'devops': devopslist,
                    "cluster": cluster,
                    "region": region,
                    "namespace": namespace,
                    "block": block,
                    "microservices": microservicestr
                }

                outputlist.append(outputdict)
                    
    logger.info("Output list for routing services returned")
    return outputlist

async def get_services_routing_nowhere(cluster=None,region=None,namespaceslist=None):
    '''Get the services that are routing nowhere, meaning they have a selector status of KO and no microservice is associated with them.'''
    #exceptednamespaces = os.getenv("EXCEPTED_NAMESPACES_FOR_SERVICES_ROUTING_NOWHERE").split(",")
    exceptedclusters = os.getenv("EXCEPTED_CLUSTERS_FOR_SERVICES_ROUTING_NOWHERE","")
    exceptedclusters = [v for v in exceptedclusters.split(",") if v]

    mongocollection = os.getenv("COLLECTION_SERVICES")
    mg.change_collection(collection=mongocollection)

    b_g_services_flag = os.getenv("B_G_SERVICES_FLAG")

    ## SERVICES ROUTING TO NOWHERE. THERE IS NO MICRO DESTINATION WELL MATCHING THE SELECTOR LABEL

    
    query = [{}]

    if cluster != None:
        query.append({"cluster": cluster})

    if region != None:
        query.append({"region": region})

    if namespaceslist != None:
        query.append({"namespace": {"$in": namespaceslist}})        

    query.append({"selector_status.status": "KO"})
    
    if b_g_services_flag == "True":
        query.append({'name': {'$regex': 'b-g-'}})

    query.append({"cluster": {'$not': {'$in': exceptedclusters}}})

    fullquery = {"$and": query}

    mongodata = mg.find(fullquery)
    logger.info(f"Constructed query: {fullquery}")
    
    outputlist = []

    for data in mongodata:
        block = await get_production_block(namespaceid=data["namespaceid"])
        logger.info('Processing data from MongoDB')
        # cluster = data["cluster"]
        # region = data["region"]
        # namespace = data["namespace"]
        service = data["name"]
        creationdate = data["creationTimestamp"]
        selectors = data["selectors"]


        try:
            logger.info('Processing service in namespace')
            creationdate_datetime = datetime.strptime(creationdate,"%Y-%m-%dT%H:%M:%SZ")
            dates_difference = today - creationdate_datetime
            days = dates_difference.days
        except Exception as e:
            logger.error(f'There was an error with date operations: {e}')
            days = 365

        days_for_reporting = int(os.getenv("DAYS_FOR_REPORTING"))
        if days < days_for_reporting: #If service has no microservice for routing to but it was created less than {DAYS_FOR_START_REPORTING} days ago it will not be shown in the report
            continue        

        outputdict = await set_output_base_dict(data)

        outputdict.update({
            "block": block,
            "service": service,
            "selectors": selectors
        })

        outputlist.append(outputdict)
    logger.info("Output list for services routing nowhere returned")
    return outputlist

async def get_services_pointing_zero_pods_ms(cluster=None, region=None, namespace=None, microservice_name_filter=None, service_app_name_filter=None):
    collection_microservices = os.getenv("COLLECTION_MICROSERVICES")
    mg_ms.change_collection(collection=collection_microservices)

    query = [{}]

    if cluster != None:
        query.append({"cluster": cluster})

    if region != None:
        query.append({"region": region})

    if namespaceslist != None:
        query.append({"namespace": {"$in": namespaceslist}})

    fullquery = {"$and": query}

    mongodata = mg_ms.find(fullquery)
    
    outputlist = []

    for data in mongodata:
        logger.info(f'Checking microservice: {data["kind"]}-{data["name"]} for desired and actual replicas.')
        actualreplicas = data['replicas']["actualreplicas"]
        if actualreplicas == 0:
            logger.info(f'Microservice {data["kind"]}-{data["name"]} has different desired and actual replicas vs {actualreplicas}')
            outputdict = await set_output_base_dict(data)

            outputdict.update({"microservice": data["kind"] + "-" + data["name"]})
            replicas = f'Actual Replicas: {actualreplicas}'

            outputdict.update({"replicas": replicas})
                
            outputlist.append(outputdict)

    return outputlist
    
