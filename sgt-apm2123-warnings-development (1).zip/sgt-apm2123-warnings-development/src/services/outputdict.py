'''This module defines the WarningModel class used for handling warning data in the application.'''
from src.services.devops import get_data_from_knowledge,get_devops_list, get_all_data_from_knowledge, process_all_devops_list
from shuttlelib.utils.logger import logger

async def set_output_base_dict(data,domain=False):
    '''Set the base output dictionary for the given data'''
    namespace = data["namespace"]
    cluster = data["cluster"]
    try:
        region = data["region"]
    except KeyError:
        region = False
    namespaceinfo = await get_data_from_knowledge(namespace[:-4])
    devopslist = await get_devops_list(namespaceinfo,namespace)

    logger.debug(f"DevOps list for namespace {namespace}: {devopslist}")

    # if len(devopslist) == 0:
    #         devops_str = None
    # else:
    #     devops_str = ",".join([str(d) for d in devopslist if d])
            
    outputdict = {}
    if domain:
            try:
                outputdict = {"domain": namespaceinfo[0]["domain"]}
            except (IndexError, KeyError):
                outputdict = {"domain": None}
    if region:
        outputdict.update({
                "devops": devopslist,
                "cluster": cluster,
                "region": region,
                "namespace": namespace
            })
    else:    
        outputdict.update({
                "devops": devopslist,
                "cluster": cluster,
                "namespace": namespace
            })
    logger.debug(f"Output dict for namespace {namespace}: {outputdict}")
    return outputdict

async def set_all_output_base_dict(data,domain=False):
    '''Set the base output dictionary for all items in the given data'''

    knowledge_data, deleted_namespace = await get_all_data_from_knowledge()
    # Filtrar datos eliminando namespaces borrados
    knowledge_clean, removed_namespaces = filter_deleted_namespaces(knowledge_data, deleted_namespace)
    
    logger.info(f"Removed {len(removed_namespaces)} entries with deleted namespaces: {removed_namespaces}")
    print(f"Removed {len(removed_namespaces)} entries with deleted namespaces: {removed_namespaces}")
    

    knowledge_processed = await process_all_devops_list(knowledge_clean)

    # Crear un diccionario de búsqueda rápida por cluster y namespace
    knowledge_dict = {}
    for k in knowledge_processed:
        key = (k.get("cluster"), k.get("namespace"))
        knowledge_dict[key] = k
    
    # Recorrer data y añadir información correspondiente
    for d in data:
        cluster = d.get("cluster")
        namespace = d.get("namespace")[:-4]
        key = (cluster, namespace)
        
        # Buscar información correspondiente en knowledge_processed
        if key in knowledge_dict:
            knowledge_info = knowledge_dict[key]
            
            # Añadir devops
            d["devops"] = knowledge_info.get("devops")
            
            # Añadir domain solo si domain=True
            if domain:
                d["domain"] = knowledge_info.get("domain")
        else:
            # Si no se encuentra, añadir valores por defecto
            d["devops"] = None
            if domain:
                d["domain"] = None
    
    return data, removed_namespaces

def filter_deleted_namespaces(data, deleted_namespace):
    """
    Filters out data entries with namespaces that are in the deleted_namespace list.
    
    Args:
        data (list): List of dictionaries containing data entries with 'namespace' field.
        deleted_namespace (list): List of namespace strings to be filtered out.
    
    Returns:
        tuple: A tuple containing:
            - filtered_data (list): Data with deleted namespaces removed
            - removed_namespaces (list): List of namespaces that were removed from the data
    """
    removed_namespaces = []
    
    # Collect namespaces that will be removed
    for entry in data:
        namespace = entry.get("namespace")
        if namespace and namespace in deleted_namespace:
            if namespace not in removed_namespaces:
                removed_namespaces.append(namespace)
    
    # Filter using list comprehension
    filtered_data = [entry for entry in data 
                     if entry.get("namespace") not in deleted_namespace]
    
    return filtered_data, removed_namespaces

  

