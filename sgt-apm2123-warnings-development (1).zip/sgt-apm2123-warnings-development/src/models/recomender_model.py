"""
This module contains the data model for user accounts.
"""
from pydantic import BaseModel, Field
from typing import Optional, Any, List

CLUSTER = "Name of the OpenShift cluster."
NAMESPACE = "Namespace within the cluster."
APPLICATION = "Name of the application."

class getRecomenderRequest(BaseModel):
    """
    Model representing a request to retrieve information based on cluster and namespace.

    Attributes:
        cluster (Optional[str]): The name of the cluster. Example values include 'cluster1', 'cluster2'.
        namespace (Optional[str]): The name of the namespace. Example values include 'namespace1', 'namespace2'.
    """
    cluster: Optional[str] = Field(default=None, json_schema_extra={"description": CLUSTER, 'examples': ['cluster1', 'cluster2']})
    namespace: Optional[str] = Field(default=None, json_schema_extra={"description": NAMESPACE, 'examples': ['namespace1', 'namespace2']})    

class getConfigurationRequest(BaseModel):
    """
    Request model for retrieving configuration settings.
    Attributes:
        cluster (Optional[str]): Cluster name to filter microservices.
            Example: 'cluster1', 'cluster2'
        namespace (Optional[str]): Namespace to filter microservices.
            Example: 'namespace1', 'namespace2'
        region (Optional[str]): Region to filter microservices.
            Example: 'bo1', 'bo2'
        b_g_model (bool): Flag to filter between active or offline services in a blue-green (b-g) model.
            Example: False
    """

    cluster: Optional[str] = Field(default=None, json_schema_extra={"description": CLUSTER, 'examples': ['cluster1', 'cluster2']})
    namespace: Optional[str] = Field(default=None, json_schema_extra={"description": NAMESPACE, 'examples': ['namespace1', 'namespace2']})
    region: Optional[str] = Field(default=None, json_schema_extra={"description": "Region to filter microservices.", 'examples': ['bo1', 'bo2']})
    b_g_model: bool = Field(default=False, json_schema_extra={"description": "Flag to filter between active or offline services in a b-g model.", 'examples': [False]})    


class getDiffRequest(BaseModel):
    """
    Request model for retrieving differences in configuration parameters.

    Attributes:
        cluster (Optional[str]): The name of the cluster to filter the request. 
            Example values: 'cluster1', 'cluster2'.
        namespace (Optional[str]): The namespace within the cluster to filter the request.
            Example values: 'namespace1', 'namespace2'.
        only_diff_parameters (bool): Flag indicating whether to return only parameters that differ.
            Example value: True.
    """
    cluster: Optional[str] = Field(default=None, json_schema_extra={"description": CLUSTER, 'examples': ['cluster1', 'cluster2']})
    namespace: Optional[str] = Field(default=None, json_schema_extra={"description": NAMESPACE, 'examples': ['namespace1', 'namespace2']})    
    only_diff_parameters: bool = Field(default=True, json_schema_extra={"description":"Flag return only different items.",'examples': [True]})
    b_g_model: bool = Field(default=False, json_schema_extra={"description": "Flag to filter between active or offline services in a b-g model.", 'examples': [False]})

class getFinalDiffRequest(BaseModel):
    """
    Request model for retrieving differences in configuration parameters.

    Attributes:
        cluster (Optional[str]): The name of the cluster to filter the request. 
            Example values: 'cluster1', 'cluster2'.
        namespace (Optional[str]): The namespace within the cluster to filter the request.
            Example values: 'namespace1', 'namespace2'.
        only_diff_parameters (bool): Flag indicating whether to return only parameters that differ.
            Example value: True.
    """
    cluster: Optional[str] = Field(default=None, json_schema_extra={"description": CLUSTER, 'examples': ['cluster1', 'cluster2']})
    namespace: Optional[str] = Field(default=None, json_schema_extra={"description": NAMESPACE, 'examples': ['namespace1', 'namespace2']})    
    only_diff_parameters: bool = Field(default=True, json_schema_extra={"description":"Flag return only different items.",'examples': [True]})
    b_g_model: bool = Field(default=False, json_schema_extra={"description": "Flag to filter between active or offline services in a b-g model.", 'examples': [False]})
