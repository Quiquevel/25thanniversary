'''This module defines the WarningModel class used for handling warning data in the application.'''
from pydantic import BaseModel, Field
from typing import Optional

class WarningModel(BaseModel):
    '''Model representing a warning in the application.'''
    cluster: Optional[str] = None
    region: Optional[str] = None
    namespaceslist: Optional[list] = Field(default=None,json_schema_extra={"description":"Namespaces for getting the warning",'examples': [['sanes-shuttle-pro','san-home-banking-pro']]})

    class Config:
        extra = 'forbid'     