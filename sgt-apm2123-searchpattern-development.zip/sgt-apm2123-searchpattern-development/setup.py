import setuptools
from version import __version__

setuptools.setup(
    name = "searchpattern",
    version = __version__,
    author = "Juan Amores",
    author_email = "juan.amores@servexternos.gruposantander.com",
    description = "clone repositories and search patterns",
    long_description = "clone repositories and search patterns",
    long_description_content_type = "text/markdown",
    url = "http://mypythonpackage.com",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
    ],
    python_requires = '>=3.11',
)
