from shuttlelib.openshift.client import OpenshiftClient
from os import getenv

entity_id = (getenv("ENTITY_ID")).lower()
client = OpenshiftClient(entity_id=entity_id)

def getEnvironmentsClustersRegionsList():    
    environmentList = []
    clusterList = []
    regionList = []
    clusterListAux = []
    regionListAux = []     

    environmentList = list(client.clusters.keys())

    for environment in environmentList:        
        clusterListAux = list(client.clusters[environment].keys())
        for cluster in clusterListAux:
            regionListAux = list(client.clusters[environment][cluster].keys())
            regionList.extend(regionListAux)        
        clusterList.extend(clusterListAux)        
            
    environmentList.extend([x.upper() for x in environmentList])        
    environmentList.extend(["all", "ALL"])
    
    clusterList.extend([x.upper() for x in clusterList])
    clusterList.extend(["all", "ALL"])
    clusterList = list(set(clusterList))
    clusterList.sort()    
    
    regionList.extend([x.upper() for x in regionList])
    regionList.extend(["both", "BOTH"])
    regionList = list(set(regionList))
    regionList.sort()

    return environmentList, clusterList, regionList