from json import load, loads, dump, dumps, JSONDecodeError
from os import path, makedirs, chdir, listdir, getenv, mkdir, walk, remove, symlink
from re import match
from fnmatch import translate
from urllib3 import disable_warnings, exceptions
from shutil import rmtree, move, copy
from datetime import datetime
from time import ctime
from base64 import b64decode
from pandas import read_csv, json_normalize
from aiohttp import client_exceptions
from sys import platform
from subprocess import check_output, STDOUT, DEVNULL, CalledProcessError
from fastapi import HTTPException, responses, status
from fastapi.encoders import jsonable_encoder
from shuttlelib.utils.logger import logger
from shuttlelib.db.mongo import MongoClient
from shuttlelib.middleware.authorization import is_authorized_user
from src.services.anonymize import resultSearchAnonymize
from src.services.clientunique import client, entity_id
from time import time

from gc import get_objects, collect
from sys import getsizeof
import types, weakref

disable_warnings(exceptions.InsecureRequestWarning)

tokenGitHubConf = getenv("TOKEN_GITHUBCONF")
tokenGitHub = getenv("TOKEN_GITHUB")
infonamespaces = (getenv("COLLECTION")).lower()
anonymize = (getenv("ANONYMIZE")).lower()
environmentENV = (getenv("ENVIRONMENT")).lower()
namespaceStartWith = (getenv("NAMESPACES")).lower()
namespaceStartWith = [ns.strip() for ns in namespaceStartWith.split(",") if ns.strip()]

idnamespaces = None
contextLines = []

timestampFile = "timestamp.json"
timestampFileBCK = timestampFile + ".bck"
timestampFileSearching = timestampFile + ".searching"


auditSearchpatternFile = "searchpatternAudit.json"

if platform == "win32":
    gitExec = "git"
    separator = "\\"
    repositories = r"C:\Temp\repositories"
    repositoryAudit = r"C:\Temp\repositories\audit"
else:    
    separator = "/"
    repositories = r"/tmp/searchpattern/repositories"
    repositoryAudit = r"/tmp/searchpattern/repositories/audit"

    gitExecPath = getenv("GIT_EXEC_PATH")
    gitTemplatePath = getenv("GIT_TEMPLATE_DIR")
    gitLddPath = getenv("LD_LIBRARY_PATH")
    gitExec = getenv("GIT_EXEC")
    
    linkTargetGit = "git"
    linkTargetHttp = "git-remote-http"
    for fileName in listdir(gitExecPath):
        filePath = path.join(gitExecPath, fileName)
        
        if fileName.startswith(("git-remote-ftp", "git-remote-http")) and path.isfile(filePath) and not path.islink(filePath) and path.getsize(filePath) == 0:
            remove(filePath)
            symlink(linkTargetHttp, filePath)
        elif fileName.startswith("git-") and path.isfile(filePath) and not path.islink(filePath) and path.getsize(filePath) == 0:
            remove(filePath)
            symlink(linkTargetGit, filePath)

if not path.exists(repositories):
    try:
        makedirs(repositories, exist_ok=True)
        logger.info(f"Created repositories directory: {repositories}")
    except OSError as e:
        logger.error(f"Error creating repositories directory {repositories}: {e}")

if not path.exists(repositoryAudit):
    try:
        makedirs(repositoryAudit, exist_ok=True)
        logger.info(f"Created audit directory: {repositoryAudit}")
    except OSError as e:
        logger.error(f"Error creating audit directory {repositoryAudit}: {e}")
            
repositoriesSwap = repositories + ".swap"
 
try:
    mg = MongoClient()
except HTTPException as e:
    logger.error(f"Problems with mongo. ({e.status_code}-{e.detail}). Skipping...")
    mg = None
    pass

'''
#comentamos estas utilidades probadas que no se usan actualmente
async def dfH():
    output = check_output(["df", "-h"])
    for fich in output.decode().splitlines()[1:]:
        datos=fich.split(" ")
        while "" in datos:
            datos.remove('')
        logger.info(f"Filesystem: {datos[0]} - Size: {datos[1]} - Used: {datos[2]} - Available: {datos[3]} - Used%: {datos[4]} - Mounted on: {datos[5]}")

async def get_generation_objects_size(generation):
    objects = get_objects(generation=generation)
    total_size = 0
    object_sizes = []
    for obj in objects:
        obj_size = getsizeof(obj)
        total_size += obj_size
        object_sizes.append((type(obj), obj_size))
    # Ordenar los objetos por tamaño de mayor a menor
    object_sizes.sort(key=lambda x: x[1], reverse=True)
 
    return total_size, object_sizes

async def get_generation_objects_detail(generation):
    objects = get_objects(generation=generation)
    total_size = 0
    object_details = []
    for obj in objects:         
        try:
            obj_size = getsizeof(obj)    
            total_size += obj_size       
            object_details.append((type(obj), obj_size, repr(obj)))
        except:  
            pass # Ignorar objetos que no se pueden medir
            #object_details.append((type(obj), obj_size, obj))            
    # Ordenar los objetos por tamaño de mayor a menor
    object_details.sort(key=lambda x: x[1], reverse=True)
 
    return total_size, object_details

async def get_generation_objects_distribution(generation):
    objects = get_objects(generation=generation)
    size_distribution = defaultdict(int)
    total_size = 0
    for obj in objects:
        try:
            obj_size = getsizeof(obj)
            total_size += obj_size
            size_distribution[obj_size] += 1
        except:
            pass # Ignorar objetos que no se pueden medir
    return total_size, size_distribution

async def get_objects_by_type(generation):
    objects = get_objects(generation=generation)
    type_count = defaultdict(int)
    for obj in objects:
        obj_type = type(obj).__name__
        type_count[obj_type] += 1
    return type_count
'''
async def cleanAndCollectAllGenerationObjects():
    logger.info(f"Before cleaning:")
    logger.info(f"Generation 0: {len(get_objects(generation=0))}")
    logger.info(f"Generation 1: {len(get_objects(generation=1))}")
    logger.info(f"Generation 2: {len(get_objects(generation=2))}")
        
    objects = get_objects()    
    for obj in objects:
        if isinstance(obj, (list, dict, str, tuple, types.FunctionType, weakref.ref)):
            del obj
    collect()
    logger.info(f"Clean and collect garbage --> completed")
        
    logger.info(f"After cleaning:")
    logger.info(f"Generation 0: {len(get_objects(generation=0))}")
    logger.info(f"Generation 1: {len(get_objects(generation=1))}")
    logger.info(f"Generation 2: {len(get_objects(generation=2))}")

    objects = None

    '''
    # Obtener información SIZE de la generación 2
    total_size, object_sizes = get_generation_objects_size(2)
    # Mostrar el tamaño total y los 20 objetos más grandes
    logger.info(f"Total memory used by generation 2 objects: {total_size} bytes")
    logger.info("Top 20 largest objects:")
    for obj_type, obj_size in object_sizes[:20]:
        logger.info(f"{obj_type}: {obj_size} bytes")    

    # Obtener información DETAIL de la generación 2
    total_size, object_details = get_generation_objects_detail(2)
    # Mostrar el tamaño total y los 20 objetos más grandes con su contenido
    #print(f"Total memory used by generation 2 objects: {total_size} bytes")
    logger.info("Top 20 largest objects in generation 2:")
    for obj_type, obj_size, obj_repr in object_details[:20]:        
            logger.info(f"{obj_type}: {obj_size} bytes")
            logger.info(f"Content: {obj_repr[:100]}") # Limitamos la longitud del contenido para evitar demasiada salida
            logger.info('-' * 80)

    # Obtener información TYPE de la generación 2
    type_count = get_objects_by_type(2)
    # Mostrar los tipos de objetos más comunes
    logger.info("Top common object types in generation 2:")    
    sorted_type_items = sorted(type_count.items(), key=lambda x: x[1], reverse=True)    
    for obj_type, count in sorted_type_items[:20]:
        logger.info(f"{obj_type}: {count}")
    '''    
    return responses.JSONResponse(status_code=status.HTTP_200_OK,content=jsonable_encoder({"detail": "Del & Collection done"}))

async def searchPatternAuditRecord(ldap, environment, cluster, pattern, resultSearch):
    timeCronjobAction = time()
    dtTime = datetime.fromtimestamp(timeCronjobAction)

    dateAudit = dtTime.date().isoformat()
    timeAudit = dtTime.time().isoformat()  

    newAuditRegister = {"date": dateAudit, "time": timeAudit, "user": ldap.lower(), "environment": environment, "cluster": cluster, "pattern": pattern, "result": resultSearch}

    if path.isdir(repositoryAudit):
        chdir(repositoryAudit)
    else:
        mkdir(repositoryAudit)
        chdir(repositoryAudit)

    if path.isfile(auditSearchpatternFile):
        with open (auditSearchpatternFile, "r") as file:
            try:
                dataListAudit = load(file)
            except:
                dataListAudit = []
    else:
        dataListAudit = []

    dataListAudit.append(newAuditRegister)

    with open(auditSearchpatternFile, "w") as file:
        dump(dataListAudit, file, indent=4)
        
    file.close()
    file = None 

async def searchAuditLog(environment, cluster, date, user, pattern):
    params = {"environment": environment,
              "cluster": cluster,
              "date": date,
              "user": user,
              "pattern": pattern
    }
    
    filteredParams = {key: value for key, value in params.items() if value is not None}
         
    if path.isdir(repositoryAudit):
        chdir(repositoryAudit)
        if path.isfile(auditSearchpatternFile):
            try:
                file = open(auditSearchpatternFile, "r")
            except OSError:
                logger.error(f"audit log does not exists or is inaccessible in path {repositoryAudit}")
            
            contentAuditFile = load(file)
            
            match = []

            for entry in contentAuditFile:
                if all((entry.get(param) == value) for param, value in filteredParams.items()):
                    matchedJobs = [job for job in entry.get("result", [])]
                    if matchedJobs:
                        entryCopy = entry.copy()
                        entryCopy['result'] = matchedJobs
                        match.append(entryCopy)

            file.close()
            file = None
        else:
            logger.error(f"audit log does not exists or is inaccessible in path {repositoryAudit}")
            return []
    else:
        logger.error(f"audit log does not exists or is inaccessible in path {repositoryAudit}")
        return []

    if match:
        return match
    else: 
        return []

async def getcronJobcloneAll():
    logger.info(f"Cronjob cloneALL -> started")
    logger.info(f"Working to clone all repositories")

    await cloneAll("all", "all")
    logger.info(f"Cronjob cloneALL -> completed")

async def getProjectGIT(url):
    if url:
        logger.info(url)
        if "githubconf" in url:
            token = tokenGitHubConf
            if "ssh://git@githubconf" in url:
                if "gs.corp:2220" in url:
                    projectGIT = url.replace("ssh://git@githubconf.santander.gs.corp:2220/ImpEs/", "").replace(".git", "")
                    urlwithtoken = url.replace("ssh://git", "https://{}".format(token)).replace(":2220", "")
                elif "gs.corp:22" in url:
                    if "cloudops" in url:
                        projectGIT = url.replace("ssh://git@githubconf.santander.gs.corp:22/cloudops/", "")
                        urlwithtoken = url.replace("ssh://git", "https://{}".format(token)).replace(":22", "")
                    else:
                        projectGIT = url.replace("ssh://git@githubconf.santander.gs.corp:22/ImpEs/", "").replace(".git", "")
                        urlwithtoken = url.replace("ssh://git", "https://{}".format(token)).replace(":22", "")
                elif "corp:2220" in url:
                    projectGIT = url.replace("ssh://git@githubconf.santander.corp:2220/santec/", "").replace(".git", "")
                    urlwithtoken = url.replace("ssh://git", "https://{}".format(token)).replace(":2220", "")
                elif "corp:22" in url:
                    projectGIT = url.replace("ssh://git@githubconf.santander.corp:22/santec/", "").replace(".git", "")
                    urlwithtoken = url.replace("ssh://git", "https://{}".format(token)).replace(":22", "")
                elif "corp:santec" in url:
                    projectGIT = url.replace("ssh://git@githubconf.santander.corp:santec/", "").replace(".git", "")
                    urlwithtoken = url.replace("ssh://git", "https://{}".format(token)).replace("p:", "p/")
                elif "corp/santec" in url:
                    projectGIT = url.replace("ssh://git@githubconf.santander.corp/santec/", "").replace(".git", "")
                    urlwithtoken = url.replace("ssh://git", "https://{}".format(token))
                else:
                    projectGIT = None
                    urlwithtoken = None
            elif "git@" in url:
                if "corp:22" in url:
                    projectGIT = url.replace("git@githubconf.santander.corp:22/santec/", "").replace(".git", "")
                    urlwithtoken = url.replace("git@", "https://{}@".format(token)).replace(":22", "")
                elif "corp:santec" in url:
                    projectGIT = url.replace("git@githubconf.santander.corp:santec/", "").replace(".git", "")
                    urlwithtoken = url.replace("git@", "https://{}@".format(token)).replace("p:", "p/")
                elif "corp/santec" in url:
                    projectGIT = url.replace("git@githubconf.santander.corp/santec/", "").replace(".git", "")
                    urlwithtoken = url.replace("git@", "https://{}@".format(token))
                else:
                    projectGIT = None
                    urlwithtoken = None
            elif "https" in url:
                projectGIT = url.replace("https://githubconf.santander.corp/santec/", "").replace(".git", "")
                urlwithtoken = url.replace("https://", "https://{}@".format(token))
            else:
                projectGIT = None
                urlwithtoken = None
        elif "gitconfhq" in url: #obsolete repository
            projectGIT = None
            urlwithtoken = None
        elif "git@github.com" in url:
            token = "pendiente"
            projectGIT = url.replace("git@github.com:", "").split("/")[0]
            urlwithtoken = url.replace("git@", "https://{}@".format(token)).replace("p:", "p/")  
            #projectGIT = urlwithtoken = None 
        elif "github" in url and "produban" not in url:
            token = tokenGitHub
            if "git@" in url:
                if "corp:22" in url:
                    projectGIT = url.replace("ssh://git@github.alm.europe.cloudcenter.corp:22/", "").replace(".git", "")
                    urlwithtoken = url.replace("ssh://git", "https://{}".format(token)).replace(":22", "")
                elif "ssh://" in url:
                    projectGIT = url.replace("ssh://git@github.alm.europe.cloudcenter.corp/", "").replace(".git", "")
                    urlwithtoken = url.replace("ssh://git", "https://{}".format(token))
                else:
                    projectGIT = url.replace("git@github.alm.europe.cloudcenter.corp:", "").replace(".git", "")
                    urlwithtoken = url.replace("git@", "https://{}@".format(token)).replace("p:", "p/")  
            elif "https" in url:
                projectGIT = url.replace("https://github.alm.europe.cloudcenter.corp/", "").replace(".git", "")
                urlwithtoken = url.replace("https://", "https://{}@".format(token))
            elif "@github" in url:
                index = url.find("@")
                url = url[index + 1:]
                projectGIT = url.replace("github.alm.europe.cloudcenter.corp:", "").replace(".git", "")
                url = url.replace("corp:", "corp/")
                urlwithtoken = "https://{}@".format(token)
                urlwithtoken = urlwithtoken + url
            else:    
                projectGIT = url.replace("github.alm.europe.cloudcenter.corp:", "").replace(".git", "")
                urlwithtoken = "https://{}@".format(token)
                urlwithtoken = urlwithtoken + url
                urlwithtoken = urlwithtoken.replace("corp:", "corp/")
            index = projectGIT.find("/")
            if index != -1:
                projectGIT = projectGIT[0:index]
        else:
            projectGIT = urlwithtoken = None
    else:
        projectGIT = urlwithtoken = None

    return projectGIT, urlwithtoken

async def fileLoop(i, lines, regex):
#this function is use to fileLoop in Env y Secrets
    result = ""

    for pattern in regex:
        if pattern.upper() in lines.upper():
            if lines.strip().startswith("#"):
                pass
            elif "allowedorigins" in lines.lower():
                pass
            else:
                result += "- " + str(i + 1) + " " + lines                

    if  len(result) > 0 and result[-1] == "\n":
        return result[:-1]
    else:
        return result
    
async def fileLoopGW(i, line, regex):
#this function is use to fileLoop in Git and Cmaps    
    global contextLines
    matchtUmbrellaList = []
    patternGW = ["- id:", "uri:", "predicates", "Path="]
    result = ""
    
    if "Path=" in regex[0]:
        result = "#" + str(i + 1) + " " + line[:-1]
        for pattern in patternGW:
            if pattern in result:
                contextLines.append(result)
                if len(contextLines) >= 5: 
                    contextLines.pop(0)                       
                    
    for pattern in regex:
        if pattern.upper() in line.upper():
            if line.strip().startswith("#"):
                pass
            elif "allowedorigins" in line.lower():
                pass
            else:                
                result += "- " + str(i + 1) + " " + line[:-1]
                if "Path=" in regex[0]:
                    matchtUmbrellaList.extend(contextLines)
    
    if "Path=" not in regex[0] and result:                        
        matchtUmbrellaList.append(result)
        
    result = None

    return matchtUmbrellaList

async def getConfigServiceInfo(configMicro):    
    configservice = configMicro.get('APP_NAME', None)

    if "SPRING_CLOUD_CONFIG_SERVER_GIT_URI" in configMicro:
        gitProject = configMicro["SPRING_CLOUD_CONFIG_SERVER_GIT_URI"]
    else:
        gitProject = None
    if "SPRING_APPLICATION_JSON" in configMicro and configMicro["SPRING_APPLICATION_JSON"] != None:
        try:
            release = loads(configMicro["SPRING_APPLICATION_JSON"])["spring.cloud.config.server.git.default-label"]
        except (KeyError, JSONDecodeError):
            try:
                release = configMicro["SPRING_CLOUD_CONFIG_SERVER_GIT_DEFAULT_LABEL"]
            except:
                #logger.error("Config-service tag not found or JSON formatting problems")
                pass        
        try:
            searchpath = loads(configMicro["SPRING_APPLICATION_JSON"])["spring.cloud.config.server.git.search-paths"]
        except (KeyError, JSONDecodeError):
            #logger.error("Config-service tag not found or JSON formatting problems")
            pass
    else:
        try:
            release = configMicro["SPRING_CLOUD_CONFIG_SERVER_GIT_DEFAULT_LABEL"]
        except:
            #logger.error("Config-service tag not found or JSON formatting problems")
            pass        
    
    if "release" not in locals():
        release = "master"
    if "searchpath" not in locals():
        searchpath = None
    
    return (gitProject, release, searchpath, configservice)

async def getEnvironmentVars(deployment):
    container = deployment["spec"]["template"]["spec"]["containers"][0]
    res = {}
    
    for i, cont in enumerate(container["env"]):
        res[cont["name"]] = cont.get("value")
    
    container = None

    return (res)

async def cloneGitProject(url, workdir):
    project, urlwithtoken = await getProjectGIT(url)
    
    chdir(workdir)
    if project and urlwithtoken != None:
        if not path.isdir(workdir + separator + project):            
            mkdir(project)
            chdir(project)
        else:
            #logger.info("Repository already downloaded")
            pass
              
        try:
            if project in str(listdir()):
                pass            
            else:
                #logger.info(f"Downloading repository of {project}")
                #if it is necesary change the stderr=DEVNULL by stderr=STDOUT to debug                
                check_output([gitExec, "clone", urlwithtoken, "."], stderr=DEVNULL)
        except CalledProcessError as e:
            logger.error(f"An error has occurred while downloading the repository. Code -> {e.output.decode()}")            
    else:
        pass

async def cloneGIT(microservices, region, workdir):
    microservices = microservices[region]["items"]

    if len(microservices) > 0:                
        for microservice in microservices:
            microserviceName = microservice["metadata"]["name"]
            if "config" in microserviceName and "serv" in microserviceName:
                #logger.info(f"Checking microservice: {microserviceName}")
                varsEnvironment = await getEnvironmentVars(microservice)
            else:
                varsEnvironment = None
                continue
            configServiceInfo = await getConfigServiceInfo(varsEnvironment)
            if type(configServiceInfo) == None:
                continue
            else:
                url = configServiceInfo[0]            
            
            await cloneGitProject(url, workdir)

    microservice = varsEnvironment = configServiceInfo = None    

async def cloneCMAP(configMap, workdir, region):
    excludeFilesConfigMaps = ('.crt', '.pem')

    itemsConfigMap = configMap[region]['items']                                                 

    for itemConfigMap in itemsConfigMap:
        nameConfigMap = itemConfigMap['metadata']['name']
        #logger.info(f"Checking CMAPs: {nameConfigMap}")
        nameConfigMap = nameConfigMap + ".cmap"
        
        if "data" in itemConfigMap:
            datasConfigMap = itemConfigMap['data']
            for itemConfigMap, dataConfigMap in datasConfigMap.items():
                if not (nameConfigMap.endswith(excludeFilesConfigMaps) or itemConfigMap.endswith(excludeFilesConfigMaps)):
                    if not path.isdir(workdir):
                        makedirs(workdir)
                    chdir(workdir)
                    if not path.isdir(workdir + separator + nameConfigMap):
                        mkdir(nameConfigMap)
                    chdir(nameConfigMap)                                                
                    file = open(itemConfigMap, 'w', encoding="utf-8")
                    try:
                        file.write(dataConfigMap)
                    finally:
                        file.close()
                        file = None
    
    itemsConfigMap = None

async def cloneSECRET(secret, workdir, region):
    excludeFiles = ('.crt', '.pem', '.jks', '.pkcs12', '.jceks', '.keytab', 'key', 'keystore', 'secret', 'truststore', 'password', 'pass', 'token', 'credential')
    exclude = []
    
    items = secret[region]['items']
        
    exclude.extend([x.upper() for x in excludeFiles])
    exclude.extend([x.capitalize() for x in excludeFiles])
    exclude = tuple(exclude)
    
    for item in items:
        name = item['metadata']['name']
        name = name + ".secret"
        #logger.info(f"Checking SECRETs: {nameSecret}")
        type = item['type']

        if "data" in item:
            datas = item['data']
        else:
            continue

        if type == "Opaque":
            for item, data in datas.items():
                if not (item.startswith(exclude) or item.endswith(exclude) or [i for i in exclude if i in item]):
                    if data:
                        data = b64decode(data).decode('utf-8', 'ignore')
                    if not path.isdir(workdir):
                        makedirs(workdir)
                    chdir(workdir)
                    if not path.isdir(workdir + separator + name):
                        mkdir(name)
                    chdir(name)                                                
                    file = open(item, 'w', encoding="utf-8")
                    try:
                        file.write(data)
                    finally:
                        file.close()
                        file = None

    item = datas = None    

async def cloneENV(objectsMongoList, workdir):
    if not path.isdir(workdir):
        makedirs(workdir)
        chdir(workdir)
        makedirs("DeploymentConfigs")
        makedirs("Deployments")
        makedirs("StatefulSet")
    
    for microservice in objectsMongoList:
        microserviceName = microservice.get('name', None)
        if microserviceName != None:
            envVars = microservice.get('envVar', None)
            microType = microservice.get('kind', None)
            if envVars != None:
                if microType != None:
                    match microType:
                        case "DeploymentConfig":                    
                            chdir(workdir + separator + "DeploymentConfigs")
                        case "Deployment":
                            chdir(workdir + separator + "Deployments")
                        case "StatefulSet":
                            chdir(workdir + separator + "StatefulSet")
                        case _:
                            continue

                    try:
                        file = open(microserviceName, 'w', encoding="utf-8")
                    except Exception as e:
                        logger.error(type(e).__name__, "–", e)
                    try:
                        file.write(dumps(envVars, indent=2))
                    except Exception as e:
                        logger.error(type(e).__name__, "–", e)
                    finally:
                        file.close()
                        file = None
                        chdir(workdir)

async def cloneAll(environment, clusterin):
    regions = []
    environmentList = []
    clusterList = []
       
    environmentList = list(client.clusters.keys())
         
    if environment.lower() == "all":
        environments = environmentList

        if path.isdir(repositoriesSwap):
            try:
                rmtree(repositoriesSwap)  
            except OSError:
                logger.error(f"error remove repositories SWAP")
                raise HTTPException(status_code=500, detail=f"error remove repositories SWAP")   
        if not path.isdir(repositories): 
            makedirs(repositories)
            activeRepositories = repositories             
        elif not path.isdir(repositoriesSwap): 
            makedirs(repositoriesSwap)
            activeRepositories = repositoriesSwap             
        
        for environment in environments:
            chdir(activeRepositories)
            mkdir(environment) 
        
        logger.info(f"STARTING downloading ALL repositories")
    else:        
        environments = [environment]
        activeRepositories = repositories    
       
    for environment in environments:
        logger.info(f"STARTING downloading repository in {environment}")
        if clusterin:
            if clusterin.lower() == "all":
                clusterList = client.clusters[environment]   
                if path.isdir(activeRepositories + separator + environment): 
                    try:
                        rmtree(activeRepositories + separator + environment)  
                    except OSError:
                        logger.error(f"error remove repositories")
                        raise HTTPException(status_code=500, detail=f"error remove repositories")                        
            else:
                clusterList = [clusterin.lower()]
                if path.isdir(activeRepositories + separator + environment + separator + clusterin.lower()): 
                    try:
                        rmtree(activeRepositories + separator + environment + separator + clusterin.lower())  
                    except OSError:
                        logger.error(f"error remove repositories")
                        raise HTTPException(status_code=500, detail=f"error remove repositories")                
        else:
            clusterList = client.clusters[environment]
            if path.isdir(activeRepositories + separator + environment): 
                try:
                    rmtree(activeRepositories + separator + environment)  
                except OSError:
                    logger.error(f"error remove repositories")
                    raise HTTPException(status_code=500, detail=f"error remove repositories")                    

        if mg:
            if  mg.server_info():
                match environmentENV.lower():
                    case "dev":
                        if environment.lower() == "dev":
                            mg.change_collection(infonamespaces)
                        elif environment.lower() == "pre":
                            mg.change_collection(infonamespaces + "_" + environment)
                        elif environment.lower() == "pro":
                            mg.change_collection(infonamespaces + "_" + environment)
                    case "pre":
                        if environment.lower() == "dev":
                            mg.change_collection(infonamespaces + "_" + environment)
                        elif environment.lower() == "pre":
                            mg.change_collection(infonamespaces)
                        elif environment.lower() == "pro":
                            mg.change_collection(infonamespaces + "_" + environment)
                    case "pro":
                        if environment.lower() == "dev":
                            mg.change_collection(infonamespaces + "_" + environment)
                        elif environment.lower() == "pre":
                            mg.change_collection(infonamespaces + "_" + environment)
                        elif environment.lower() == "pro":
                            mg.change_collection(infonamespaces)
                    case _:
                        raise HTTPException(status_code = 400, detail=f"Entry data for the collection is not correct, please check")
        else:
            logger.error('Could not connect to MongoDB')            

        for cluster in clusterList: 
            logger.info(f"STARTING cluster repositories {cluster.upper()} in {environment.upper()}")
           
            if path.isdir(activeRepositories + separator + environment):
                chdir(activeRepositories + separator + environment)
                mkdir(cluster)  
            else:
                chdir(activeRepositories + separator)
                mkdir(environment)
                chdir(activeRepositories + separator + environment)
                mkdir(cluster)  

            workdir = activeRepositories + separator + environment + separator + cluster

            chdir(workdir)
            try:
                file = open(timestampFile, "w")
            except OSError: 
                 logger.error(f"timestamp does not exists or is inaccessible in path {workdir}") 
           
            timestampDic = {"environment": environment, "cluster": cluster, "cTime": "refreshing", "mTime": "refreshing"}

            dump(timestampDic, file) 
            file.close()
            file = None
            timestampDic = None

            regions = []
            regions.append(list(client.clusters[environment][cluster].keys())[0])            
            if cluster == 'bks' and environment == 'pre':
                regions.append(list(client.clusters[environment][cluster].keys())[1])
        
            chdir(workdir)            
            
            for region in regions:
                try:
                    namespaceList = await client.get_resource(resource = "namespaces", functional_environment = environment, cluster = cluster, region = region)
                except client_exceptions.ServerTimeoutError:
                    logger.error(f"Timeout detected against {cluster.upper()}({region})")
                    continue         
                except:
                    logger.error(f"Namespaces of {cluster.upper()}-{region.upper()} could not be retrieved. Skipping...")
                    continue                   
                
                try:
                    items = namespaceList[region]['items']
                except:
                    items = None
                
                if items != None and len(items) > 0:
                    namespaceList = items
                    for namespace in namespaceList:
                        namespaceName = namespace['metadata']['name']
                        
                        #if namespaceName.startswith("sanes-") or namespaceName.startswith("san-") or namespaceName.startswith("sgt-"):
                        if namespaceName.startswith(tuple(namespaceStartWith)):
                            logger.info(f"Downloading namespace: {namespaceName}")

                            try:
                                secret = await client.get_resource(resource = "secrets", functional_environment = environment, cluster = cluster, region = region, namespace = namespaceName)
                            except client_exceptions.ClientConnectorError:
                                logger.error(f"Timeout detected against {cluster.upper()}({region}) > {namespaceName}")
                                secret = None
                            except:
                                logger.error(f"secrets of {cluster.upper()}-{region.upper()}-{namespaceName} could not be retrieved. Skipping...")
                                secret = None

                            if secret and len(secret) > 0:
                                workdir = activeRepositories + separator + environment + separator + cluster + separator + namespaceName + "-secret"
                                await cloneSECRET(secret, workdir, region)
                                secret = None
                            else:
                                logger.error(f"secrets of {cluster.upper()}-{region.upper()}-{namespaceName} could not be retrieved. Skipping...")
                                secret = None

                            if mg != None:
                                try:
                                    objectsMongoList = list(mg.find({'cluster': cluster, 'region': region, 'namespace': namespaceName}))
                                except Exception as e:
                                    logger.error(f'caught {type(e)}: e')
                                    logger.error(f"Code -> {e.output}")
                                    objectsMongoList = []

                                if len(objectsMongoList) > 0:
                                    workdir = activeRepositories + separator + environment + separator + cluster + separator + namespaceName + "-env"
                                    await cloneENV(objectsMongoList, workdir)
                                    objectsMongoList = []

                            try:
                                configMap = await client.get_resource(resource = "configmaps", functional_environment = environment, cluster = cluster, region = region, namespace = namespaceName)
                            except client_exceptions.ClientConnectorError:
                                logger.error(f"Timeout detected against {cluster.upper()}({region}) > {namespaceName}")
                                configMap = None
                            except:
                                logger.error(f"configmaps of {cluster.upper()}-{region.upper()}-{namespaceName} could not be retrieved. Skipping...")                
                                configMap = None

                            if configMap and len(configMap) > 0:
                                workdir = activeRepositories + separator + environment + separator + cluster + separator + namespaceName + "-cmap"
                                await cloneCMAP(configMap, workdir, region)
                                configMap = None

                            try:
                                microservicesD = await client.get_resource(resource = "deployments", functional_environment = environment, cluster = cluster, region = region, namespace = namespaceName)
                            except client_exceptions.ClientConnectorError:
                                logger.error(f"Timeout detected against {cluster.upper()}({region}) > {namespaceName}")
                                microservicesD = None
                            except:
                                logger.error(f"deployments of {cluster.upper()}-{region.upper()}-{namespaceName} could not be retrieved. Skipping...")                
                                microservicesD = None

                            if microservicesD and len(microservicesD) > 0:
                                workdir = activeRepositories + separator + environment + separator + cluster
                                await cloneGIT(microservicesD, region, workdir)
                                microservicesD = None

                            try:
                                microservicesDC = await client.get_resource(resource = "deploymentconfigs", functional_environment = environment, cluster = cluster, region = region, namespace = namespaceName)
                            except client_exceptions.ClientConnectorError:
                                logger.error(f"Timeout detected against {cluster.upper()}({region}) > {namespaceName}")
                                microservicesDC = None
                            except:
                                logger.error(f"deploymentconfigs of {cluster.upper()}-{region.upper()}-{namespaceName} could not be retrieved. Skipping...")                
                                microservicesDC = None

                            if microservicesDC and len(microservicesDC) > 0:
                                workdir = activeRepositories + separator + environment + separator + cluster
                                await cloneGIT(microservicesDC, region, workdir)                        
                                microservicesDC = None

            workdir = activeRepositories + separator + environment + separator + cluster
            chdir(workdir)
            try:
                file = open(timestampFile, "w")
            except OSError: 
                 logger.error(f"timestamp does not exists or is inaccessible in path {workdir}") 
            
            cTime = path.getctime(workdir) 
            mTime = path.getmtime(workdir) 
            localcTime = ctime(cTime) 
            localmTime = ctime(mTime) 
            
            timestampDic = {"environment": environment, "cluster": cluster, "cTime": str(localcTime), "mTime": str(localmTime)}

            dump(timestampDic, file)             
            file.close()
            file = None
            timestampDic = None
            
            logger.info(f"FINISHED downloading repositories {cluster.upper()} in {environment.upper()}")        
    
    if path.isdir(repositories) and path.isdir(repositoriesSwap) and activeRepositories == repositoriesSwap:
        try:
            rmtree(repositories)
            move(repositoriesSwap, repositories)
        except:
            logger.error(f"error swapping repositories")
            raise HTTPException(status_code=500, detail=f"error swapping repositories")
        
    logger.info(f"FINISHED downloading ALL repositories")

async def searchTimestamp(environment):
    listTimestamp = []
    environmentList = []
    timestampDic = {}
               
    if environment.lower() == "all":        
        environmentList = list(client.clusters.keys())
    else:
        environmentList = [environment]

    for environment in environmentList:
        for cluster in client.clusters[environment]:
            workdir = repositories + separator + environment + separator + cluster
            
            if path.isdir(workdir):
                chdir(workdir)

                if path.isfile(timestampFile):
                    try:
                        file = open(timestampFile, "r")
                    except OSError: 
                        logger.error(f"timestamp does not exists or is inaccessible in path {workdir}")                         
                        break

                    contentTimestamp = load(file)
                    if contentTimestamp:
                        listTimestamp.append(contentTimestamp)
                    file.close()
                    file = None    
                else:                    
                    timestampDic = {"environment": environment, "cluster": cluster, "cTime": "refreshing", "mTime": "refreshing"}
                    listTimestamp.append(timestampDic)
                    timestampDic = None
            else:                    
                timestampDic = {"environment": environment, "cluster": cluster, "cTime": "refreshing", "mTime": "refreshing"}
                listTimestamp.append(timestampDic)
                timestampDic = None          

    contentTimestamp = timestampDic = None
                     
    return listTimestamp

async def searchDeployment(namespaceName, microservices, environment, cluster, patternsplit):
    listResult = []
    resultSearchList = []
    appendResult = {}
        
    global idnamespaces

    workdir = repositories + separator + environment + separator + cluster    

    for microservice in microservices:
        microserviceName = microservice["metadata"]["name"]
        if "config" in microserviceName and "serv" in microserviceName:
            #logger.info(f"Checking microservice: {microserviceName}")
            varsEnvironment = await getEnvironmentVars(microservice)
        else:
            varsEnvironment = None
            continue
        configServiceInfo = await getConfigServiceInfo(varsEnvironment)
        if type(configServiceInfo) == None:
            continue
        
        projectGIT, url = await getProjectGIT(configServiceInfo[0])        

        try:
            chdir(workdir)
        except FileNotFoundError:
            logger.debug(f"Cluster directory {workdir} does not exist for searchDeployment, skipping")
            continue
        except Exception as e:
            logger.error(f"Error accessing cluster directory in searchDeployment: {e}")
            continue

        if projectGIT:
            if projectGIT in str(listdir()):
                resultSearchList = await searchGIT(environment, cluster, projectGIT, configservice = configServiceInfo[3], branch = configServiceInfo[1], block = configServiceInfo[2], patternsplit = patternsplit)
                if len(resultSearchList) > 0:                                                        
                    for result in resultSearchList:
                        idnamespaces += 1
                        appendResult = {"Id": idnamespaces, "cluster": cluster, "namespace": namespaceName}
                        appendResult.update(result)
                        listResult.append(appendResult)
                        appendResult = {}
                    else:
                        appendResult = {}
                        resultSearchList = []
                else:
                    listResult = [] 
    
    microservices = resultSearchList = appendResult = None    

    return listResult

async def searchGIT(environment, cluster, project, configservice, branch, block, patternsplit):
    statusUmbrellaList = []
    matchtUmbrellaList = []
    locationList = []
    statusUmbrella = {}
    location = {}
        
    global contextLines

    workdir = repositories + separator + environment + separator + cluster + separator + project

    if len(patternsplit) > 1:
        if patternsplit[0] == "paths" and patternsplit[1]:            
            patternsplit = [f"Path={patternsplit[1].strip()}"]
            includesfiles = ['*gateway*.yml', '*gateway*.yaml']
        else:
            includesfiles = ['*.project', '*.properties','application*', 'pro-*','*.yml', '*.yaml','*.json']
    elif patternsplit[0] == "paths":
        patternsplit = ["- id:", "uri:", "predicates", "Path="]
        includesfiles = ['*gateway*.yml', '*gateway*.yaml']
    else:
        includesfiles = ['*.project', '*.properties','application*', 'pro-*','*.yml', '*.yaml','*.json']
            
    if path.isdir(workdir):
        try:
            chdir(workdir)
        except FileNotFoundError:
            logger.debug(f"Project directory {workdir} does not exist in searchGIT, skipping")
            return statusUmbrellaList
        except Exception as e:
            logger.error(f"Error accessing project directory in searchGIT: {e}")
            return statusUmbrellaList
    else:
        logger.debug(f"Project directory {workdir} does not exist, skipping")
        return statusUmbrellaList
    
    try:
        #if it is necesary change the stderr=DEVNULL by stderr=STDOUT to debug        
        check_output([gitExec, "checkout", branch], stderr=DEVNULL)        
    except CalledProcessError as e:
        logger.error(f"An error has occurred while searching in the repository.Code(checkout) -> {e.output.decode()}")   
        '''
        try:            
            check_output(["git", "fetch", "origin"], stderr=DEVNULL)
        except CalledProcessError as e:
            logger.error(f"An error occurred searching the repository {project}.Code(fetch) -> {e.output}")          
        try:    
            check_output(["git", "checkout", "--force", branch], stderr=DEVNULL)        
        except CalledProcessError as e:
            logger.error(f"An error occurred searching the repository {project}.Code(checkout force) -> {e.output}")          
        '''

    if block:
        includesfolder = [w.replace('/', '') for w in block]
        if any(x in includesfolder for x in ["BLUE", "blue","Blue"]):
            includesfiles.extend(['*blue*', '*-b-*'])
        elif any(x in includesfolder for x in ["GREEN", "green","Green"]):
            includesfiles.extend(['*green*', '*-g-*'])
        elif any(x in includesfolder for x in ["DEV", "dev","Dev"]):
            includesfiles.extend(['*-dev*'])
        elif any(x in includesfolder for x in ["PRE", "pre","Pre"]):
            includesfiles.extend(['*-pre*'])
        includesfolder = r'|'.join([translate(x) for x in includesfolder]) or r'$.'
    
    includesfiles = r'|'.join([translate(x) for x in includesfiles])
        
    for root, dirs, dirfiles in walk(workdir):
        if block:
            dirs[:] = [d for d in dirs if match(includesfolder, d)]
        
        filesGIT = [f for f in dirfiles if match(includesfiles, f)]
        
        for fileGIT in filesGIT:
            workingfile = path.join(root, fileGIT)
            if platform == "win32":
                directory = (workingfile.split("\\")[-2])
            else:
                directory = (workingfile.split("/")[-2])

            contextLines = []
            with open(workingfile, "r", encoding="utf-8", errors='replace') as workfile:
                targetline = workfile.readlines()
                for i, line in enumerate(targetline):                    
                    matchtUmbrella = await fileLoopGW(i, line, patternsplit)
                    if matchtUmbrella:
                        matchtUmbrellaList.extend(matchtUmbrella)

            if len(matchtUmbrellaList) > 0:
                if block and len(block) > 0 and directory != project:
                    location = {'file': directory + ">" + fileGIT, 'match': matchtUmbrellaList}
                else:
                    location = {'file': fileGIT, 'match': matchtUmbrellaList}
                locationList.append(location)
                matchtUmbrellaList = []                 
                location = {} 
            
            workfile.close()
            workfile = None

    if len(locationList) > 0:
        if block:
            if len(block) > 1:
                blocklist = [w.replace('/', '') for w in block]
                block = '/'.join(blocklist)               
            else:
                block = block[0]
                block = block[1:]                
            statusUmbrella = {'microservice': configservice, 'branch': branch, 'block': block, 'files': locationList}
        else:
            statusUmbrella = {'microservice': configservice, 'branch': branch, 'block': None, 'files': locationList}
        statusUmbrellaList.append(statusUmbrella)        
        statusUmbrella = {}
    else:
        statusUmbrellaList = []

    statusUmbrella = location = None    
    matchtUmbrellaList = []    
    locationList = []

    return statusUmbrellaList

async def searchConfigMap(environment, cluster, namespaceName, patternsplit):
    listResult = []
    statusUmbrellaList = []
    matchtUmbrellaList = []
    locationList = []
    appendResult = {}        
    statusUmbrella = {}
    location = {}

    global contextLines
    global idnamespaces
    
    workdir = repositories + separator + environment + separator + cluster + separator + namespaceName + "-cmap" + separator

    if len(patternsplit) > 1:
        if patternsplit[0] == "paths" and patternsplit[1]:            
            patternsplit = [f"Path={patternsplit[1].strip()}"]
            includesfiles = ['*gateway*.yml', '*gateway*.yaml']
        else:
            includesfiles = ['*.project', '*.properties','application*', 'pro-*','*.yml', '*.yaml','*.json']
    elif patternsplit[0] == "paths":
        patternsplit = ["- id:", "uri:", "predicates", "Path="]
        includesfiles = ['*gateway*.yml', '*gateway*.yaml']
    else:        
        includesfiles = ['*','*.*']

    includesfiles = r'|'.join([translate(x) for x in includesfiles])

    # Check if workdir exists before trying to walk
    if not path.exists(workdir):
        logger.debug(f"ConfigMap directory {workdir} does not exist, skipping")
        return listResult

    try:
        for root, dirs, dirfiles in walk(workdir):        
            dirs[:] = [d for d in dirs]                
            files = [f for f in dirfiles if match(includesfiles, f)]

            for file in files:
                workingfile = path.join(root, file)
                if platform == "win32":
                    directory = (workingfile.split("\\")[-2])
                else:
                    directory = (workingfile.split("/")[-2])
                
                contextLines = []
                with open(workingfile, "r", encoding="utf-8", errors='replace') as workfile:
                    targetline = workfile.readlines()
                    for i, line in enumerate(targetline):                    
                        matchtUmbrella = await fileLoopGW(i, line, patternsplit)
                        if matchtUmbrella:
                            matchtUmbrellaList.extend(matchtUmbrella)
                            
                if len(matchtUmbrellaList) > 0:
                    location = {'file': directory + ">" + file, 'match': matchtUmbrellaList}              
                    locationList.append(location)                
                    matchtUmbrellaList = []                  
                    location = {}

                workfile.close()
                workfile = None
    except Exception as e:
        logger.error(f"Error accessing ConfigMap directory {workdir}: {e}")
        return listResult

    if len(locationList) > 0:
        statusUmbrella = {'microservice': "configMap", 'branch': None, 'block': None, 'files': locationList}
        statusUmbrellaList.append(statusUmbrella)        
        statusUmbrella = {}
    else:
        statusUmbrellaList = []

    if len(statusUmbrellaList) > 0:                                                        
        for result in statusUmbrellaList:
            idnamespaces += 1            
            appendResult = {"Id": idnamespaces, "cluster": cluster, "namespace": namespaceName}
            appendResult.update(result)
            listResult.append(appendResult)
            appendResult = {}
        else:
            appendResult = {}
    else:
        listResult = [] 
    
    appendResult = statusUmbrella = location = None     
    matchtUmbrellaList = []
    statusUmbrellaList = []     
    locationList = []

    return listResult

async def searchConfigEnv(environment, cluster, namespaceName, patternsplit):
    listResult = []
    statusUmbrellaList = []
    matchtUmbrellaList = []
    locationList = []
    appendResult = {}        
    statusUmbrella = {}
    location = {}
    
    global idnamespaces

    workdir = repositories + separator + environment + separator + cluster + separator + namespaceName + "-env" + separator   

    if patternsplit[0] == "paths":        
        return listResult
    else:
        includesfiles = ['*','*.*']
    
    includesfiles = r'|'.join([translate(x) for x in includesfiles])

    # Check if workdir exists before trying to walk
    if not path.exists(workdir):
        logger.debug(f"ConfigEnv directory {workdir} does not exist, skipping")
        return listResult

    try:
        for root, dirs, dirfiles in walk(workdir):        
            dirs[:] = [d for d in dirs]        
            files = [f for f in dirfiles if match(includesfiles, f)]
            
            for file in files:
                workingfile = path.join(root, file)
                if platform == "win32":
                    directory = (workingfile.split("\\")[-2])
                else:
                    directory = (workingfile.split("/")[-2])
                
                with open(workingfile, "r", encoding="utf-8", errors='replace') as workfile:
                    targetline = workfile.readlines()
                    for i, lines in enumerate(targetline):
                        matchtUmbrella = await fileLoop(i, lines, patternsplit)
                        if matchtUmbrella:
                            if matchtUmbrella[-1] == ",":
                                matchtUmbrella = matchtUmbrella[:-1]                        
                            matchtUmbrellaList.append(matchtUmbrella)
                            
                if len(matchtUmbrellaList) > 0:
                    location = {'file': directory + ">" + file, 'match': matchtUmbrellaList}              
                    locationList.append(location)                
                    matchtUmbrellaList = []    
                    location = {}              
                
                workfile.close()
                workfile = None
    except Exception as e:
        logger.error(f"Error accessing ConfigEnv directory {workdir}: {e}")
        return listResult

    if len(locationList) > 0:
        statusUmbrella = {'microservice': "configEnv", 'branch': None, 'block': None, 'files': locationList}
        statusUmbrellaList.append(statusUmbrella)        
    else:
        statusUmbrellaList = []

    if len(statusUmbrellaList) > 0:                                                        
        for result in statusUmbrellaList:
            idnamespaces += 1
            appendResult = {"Id": idnamespaces, "cluster": cluster, "namespace": namespaceName}
            appendResult.update(result)
            listResult.append(appendResult)
            appendResult = {}
        else:
            appendResult = {}
    else:
        listResult = [] 
    
    appendResult = statusUmbrella = location = None     
    matchtUmbrellaList = []
    statusUmbrellaList = []    
    locationList = []

    return listResult

async def searchConfigSecret(environment, cluster, namespaceName, patternsplit):
    listResult = []    
    statusUmbrellaList = []
    matchtUmbrellaList = []
    locationList = []
    appendResult = {}        
    statusUmbrella = {}
    location = {}
    
    global idnamespaces

    workdir = repositories + separator + environment + separator + cluster + separator + namespaceName + "-secret" + separator   

    if patternsplit[0] == "paths":        
        return listResult
    else:
        includesfiles = ['*','*.*']
    
    includesfiles = r'|'.join([translate(x) for x in includesfiles])

    # Check if workdir exists before trying to walk
    if not path.exists(workdir):
        logger.debug(f"ConfigSecret directory {workdir} does not exist, skipping")
        return listResult

    try:
        for root, dirs, dirfiles in walk(workdir):        
            dirs[:] = [d for d in dirs]        
            files = [f for f in dirfiles if match(includesfiles, f)]
            
            for file in files:
                workingfile = path.join(root, file)
                if platform == "win32":
                    directory = (workingfile.split("\\")[-2])
                else:
                    directory = (workingfile.split("/")[-2])
                
                with open(workingfile, "r", encoding="utf-8", errors='replace') as workfile:
                    targetline = workfile.readlines()
                    for i, lines in enumerate(targetline):
                        matchtUmbrella = await fileLoop(i, lines, patternsplit)
                        if matchtUmbrella:                        
                            matchtUmbrellaList.append(matchtUmbrella)
                            
                if len(matchtUmbrellaList) > 0:
                    location = {'file': directory + ">" + file, 'match': matchtUmbrellaList}              
                    locationList.append(location)                
                    matchtUmbrellaList = []                  
                
                workfile.close()
                workfile = None
    except Exception as e:
        logger.error(f"Error accessing ConfigSecret directory {workdir}: {e}")
        return listResult

    if len(locationList) > 0:
        statusUmbrella = {'microservice': "secret", 'branch': None, 'block': None, 'files': locationList}
        statusUmbrellaList.append(statusUmbrella)        
    else:
        statusUmbrellaList = []
    
    if len(statusUmbrellaList) > 0:                                                        
        for result in statusUmbrellaList:
            idnamespaces += 1
            appendResult = {"Id": idnamespaces, "cluster": cluster, "namespace": namespaceName}
            appendResult.update(result)
            listResult.append(appendResult)
            appendResult = {}
        else:
            appendResult = {}            
    else:
        listResult = []  
    
    appendResult = statusUmbrella = location = None     
    matchtUmbrellaList = []
    statusUmbrellaList = []     
    locationList = []

    return listResult

async def searchPattern(environment, cluster, pattern):
    listResult = []    
    clusters = []
    regions = []
    dictResult = {}
    
    global idnamespaces
    
    idnamespaces = 0
        
    workdir = repositories + separator + environment + separator + cluster
        
    patternsplit = list(pattern.split(","))
    
    startTime = time()
    
    if cluster.lower() == "all":
        clusters = list(client.clusters[environment].keys())
        workdir = repositories + separator + environment
    else: 
        workdir = repositories + separator + environment + separator + cluster
        clusters = [cluster.lower()]

    try:
        chdir(workdir)
    except FileNotFoundError:    
        logger.warning(f"Repository directory {workdir} does not exist, creating it...")
        try:
            makedirs(workdir, exist_ok=True)
            chdir(workdir)
            logger.info(f"Created and accessed directory: {workdir}")
        except OSError as e:
            logger.error(f"Failed to create repository directory {workdir}: {e}")
            raise HTTPException(status_code=500, detail=f"Cannot create or access repository {cluster.upper()} in {environment.upper()}")
    except Exception as e:
        logger.error(f"Error accessing repository {cluster.upper()}: {e}")
        raise HTTPException(status_code=500, detail=f"repository {cluster.upper()} does not exist in {environment.upper()}")
    
    logger.info(f'STARTING search in {environment.upper()}')

    if listdir(workdir):
        for cluster in clusters: 
            logger.info(f'STARTING search for cluster repositories {cluster.upper()} in {environment.upper()}')            
            
            workdir = repositories + separator + environment + separator + cluster
            try:
                chdir(workdir)
            except FileNotFoundError:
                logger.warning(f"Cluster directory {workdir} does not exist in searchPattern, creating it...")
                try:
                    makedirs(workdir, exist_ok=True)
                    chdir(workdir)
                    logger.info(f"Created and accessed cluster directory: {workdir}")
                except OSError as e:
                    logger.error(f"Failed to create cluster directory {workdir}: {e}")
                    logger.info(f"Skipping cluster {cluster.upper()}")
                    continue
            except Exception as e:
                logger.error(f"Error accessing cluster directory {cluster.upper()}: {e}")
                logger.info(f"Skipping cluster {cluster.upper()}")
                continue
            if path.isfile(timestampFile):
                if not path.isfile(timestampFileBCK):
                    copy(timestampFile,timestampFileBCK)                  
                    
                    file = open(timestampFile, "r")                  
                    timestampDic = load(file)     
                    file.close()
                    file = None

                    timestampDic["cTime"] = "searching"
                    
                    file = open(timestampFile, "w")
                    dump(timestampDic, file) 
                    file.close()
                    file = None
                else:
                    if not path.isfile(timestampFileSearching):
                        file = open(timestampFileSearching, "w")
                        file.write(str(2))
                        file.close()
                        file = None
                    else:
                        file = open(timestampFileSearching, "r")
                        line = file.read()
                        searchCounter = int(line)
                        file = open(timestampFileSearching, "w")
                        file.write(str(searchCounter + 1))
                        file.close()
                        file = None
                        line = None
                    logger.error(f"There is already an active search at this moment") 
            else:
                logger.error(f"timestamp does not exists or is inaccessible in path {workdir}")

            regions = []           
            regions.append(list(client.clusters[environment][cluster].keys())[0])
            if cluster == 'bks' and environment == 'pre':    
                regions.append(list(client.clusters[environment][cluster].keys())[1])
            for region in regions:
                try:
                    namespaceList = await client.get_resource(resource="namespaces",functional_environment=environment,cluster=cluster,region=region)
                except client_exceptions.ServerTimeoutError:
                    logger.error(f"Timeout detected against {cluster.upper()}({region})")            
                    continue         
                except:
                    logger.error(f"Namespaces of {cluster.upper()}-{region.upper()} could not be retrieved. Skipping...")            
                    continue                                           
                
                try:
                    items = namespaceList[region]['items']
                except:
                    items = None
                
                if items != None and len(items) > 0:
                    namespaceList = items
                    for namespace in namespaceList:
                        namespaceName = namespace['metadata']['name']
                        #if namespaceName.startswith("sanes-") or namespaceName.startswith("san-") or namespaceName.startswith("sgt-"):
                        if namespaceName.startswith(tuple(namespaceStartWith)):
                            logger.info(f"Checking namespace: {namespaceName}")                            
                            
                            listResultENV = await searchConfigEnv(environment, cluster, namespaceName, patternsplit)
                            if len(listResultENV) > 0:                                                                            
                                listResult.extend(listResultENV) 
                                listResultENV = None                                     
                            else:
                                pass

                            listResultSEC = await searchConfigSecret(environment, cluster, namespaceName, patternsplit)
                            if len(listResultSEC) > 0:                                                                            
                                listResult.extend(listResultSEC)                                           
                                listResultSEC = None
                            else:
                                pass
                            
                            listResultCP = await searchConfigMap(environment, cluster, namespaceName, patternsplit)
                            if len(listResultCP) > 0:                                                                            
                                listResult.extend(listResultCP)                                           
                                listResultCP = None
                            else:
                                pass                            
                            
                            try:
                                microservicesD = await client.get_resource(resource="deployments",functional_environment=environment,cluster=cluster,region=region,namespace=namespaceName)                    
                            except client_exceptions.ServerTimeoutError:
                                logger.error(f"Timeout detected against {cluster.upper()}({region}) > {namespaceName}")            
                                microservicesD = None
                            except:
                                logger.error(f"Microservices of {cluster.upper()}-{region.upper()}-{namespaceName} -  could not be retrieved. Skipping...")   
                                microservicesD = None
                            
                            if microservicesD and len(microservicesD) > 0:
                                microservicesD = microservicesD[region]["items"]
                                if len(microservicesD) > 0:
                                    listResultD = await searchDeployment(namespaceName, microservicesD, environment, cluster, patternsplit)
                                    if len(listResultD) > 0:                                                                            
                                        listResult.extend(listResultD)
                                        listResultD = None
                                    else:
                                        pass
                            
                            try:
                                microservicesDC = await client.get_resource(resource="deploymentconfigs",functional_environment=environment,cluster=cluster,region=region,namespace=namespaceName)
                            except client_exceptions.ServerTimeoutError:
                                logger.error(f"Timeout detected against {cluster.upper()}({region}) > {namespaceName}")            
                                microservicesDC = None
                            except:
                                logger.error(f"Microservices of {cluster.upper()}-{region.upper()}-{namespaceName} -  could not be retrieved. Skipping...")   
                                microservicesDC = None
                            
                            if microservicesDC and len(microservicesDC) > 0:                            
                                microservicesDC = microservicesDC[region]["items"]
                                if len(microservicesDC) > 0:
                                    listResultDC = await searchDeployment(namespaceName, microservicesDC, environment, cluster, patternsplit)
                                    if len(listResultDC) > 0:                                                                            
                                        listResult.extend(listResultDC)
                                        listResultDC = None
                                    else:
                                        pass                     
                            
            chdir(workdir)
            if path.isfile(timestampFile):
                if path.isfile(timestampFileSearching):
                    file = open(timestampFileSearching, "r")
                    line = file.read()
                    searchCounter = int(line)
                    file.close()
                    file = line = None                    
                    if searchCounter > 1:
                        file = open(timestampFileSearching, "w")
                        file.write(str(searchCounter - 1))
                        file.close()
                        file = None
                    else:                        
                        remove(timestampFileSearching)
                        move(timestampFileBCK, timestampFile)                        
                elif path.isfile(timestampFileBCK):                    
                    move(timestampFileBCK, timestampFile)
            else:
                logger.error(f"timestamp does not exists or is inaccessible in path {workdir}") 
  
            logger.info(f'FINISHED search for cluster repositories {cluster.upper()} in {environment.upper()}')

        if len(listResult) == 0:            
            dictResult["result"] = []
        else:
            if anonymize == "true":
                listResult = await resultSearchAnonymize(listResult)
            dictResult["result"] = listResult

            now = datetime.now()
            now = now.strftime('%Y%m%d-%H%M')
            outputfile = repositories + separator + environment + separator + "resultSearch." + now + ".json"
            try:
                remove(outputfile)
            except OSError:
                pass

            with open(outputfile, "a") as fileresult:
                dump(dictResult, fileresult) 
            fileresult.close()
            fileresult = None

            df = json_normalize(listResult)
            outputfile = repositories + separator + environment + separator + "resultSearch." + now + ".csv"
            df = df.fillna(value="Not informed")
            df.to_csv(outputfile, index = False, encoding = "utf-8")

            df = fileresult = None            
    else:
        logger.error(f"repository {cluster.upper()} is empty")        
        raise HTTPException(status_code=500, detail=f"repository {cluster.upper()} is empty in {environment.upper()}")        

    logger.info(f'FINISHED search in {environment.upper()}')

    endTime = time() 
    executionTime = endTime - startTime
    m, s = divmod(executionTime, 60)
    h, m = divmod(m, 60)
    executionTimeFormat = "{:02.0f}:{:02.0f}:{:02.0f}".format(h, m, s)
    logger.info(f'Time execution: {executionTimeFormat}')

    return dictResult["result"]

async def searchPatternWS(websocket, environment, cluster, pattern, ldap):
    listResult = []
    regions = []
    dictResult = {}
    dict_counter = {}
    currentnamespaces = 0
    totalnamespaces = 0
    
    global idnamespaces

    empty = False
    idnamespaces = 0
    workdir = repositories + separator + environment + separator + cluster        

    patternsplit = list(pattern.split(","))
        
    startTime = time()

    if cluster.lower() == "all":
        clusters = list(client.clusters[environment].keys())
        workdir = repositories + separator + environment
    else: 
        workdir = repositories + separator + environment + separator + cluster
        clusters = [cluster.lower()]

    await websocket.accept()
    while True:
        try:            
            chdir(workdir)
        except FileNotFoundError:    
            logger.warning(f"Repository directory {workdir} does not exist, creating it...")
            await websocket.send_text(f"Repository directory does not exist, creating: {workdir}")
            try:
                makedirs(workdir, exist_ok=True)
                chdir(workdir)
                logger.info(f"Created and accessed directory: {workdir}")
                await websocket.send_text(f"Successfully created directory: {workdir}")
            except OSError as e:
                logger.error(f"Failed to create repository directory {workdir}: {e}")
                await websocket.send_text(f"Error creating repository directory: {e}")
                raise HTTPException(status_code=500, detail=f"Cannot create or access repository {cluster.upper()} in {environment.upper()}")
        except Exception as e:
            logger.error(f"Error accessing repository {cluster.upper()}: {e}")
            await websocket.send_text(f"repository {cluster.upper()} does not exist in {environment.upper()}")
            raise HTTPException(status_code=500, detail=f"repository {cluster.upper()} does not exist in {environment.upper()}")                    
        
        logger.info(f'STARTING search in {environment.upper()}')        
        await websocket.send_text(f'STARTING search in {environment.upper()}')
        if listdir(workdir):
            for cluster in clusters: 
                logger.info(f"STARTING search: {cluster.upper()}")
                
                workdir = repositories + separator + environment + separator + cluster
                try:
                    chdir(workdir)
                except FileNotFoundError:
                    logger.warning(f"Cluster directory {workdir} does not exist, creating it...")
                    await websocket.send_text(f"Cluster directory does not exist, creating: {cluster.upper()}")
                    try:
                        makedirs(workdir, exist_ok=True)
                        chdir(workdir)
                        logger.info(f"Created and accessed cluster directory: {workdir}")
                        await websocket.send_text(f"Successfully created cluster directory: {cluster.upper()}")
                    except OSError as e:
                        logger.error(f"Failed to create cluster directory {workdir}: {e}")
                        await websocket.send_text(f"Error creating cluster directory {cluster.upper()}: {e}")
                        await websocket.send_text(f"Skipping cluster {cluster.upper()}")
                        continue
                except Exception as e:
                    logger.error(f"Error accessing cluster directory {cluster.upper()}: {e}")
                    await websocket.send_text(f"Error accessing cluster {cluster.upper()}: {e}")
                    await websocket.send_text(f"Skipping cluster {cluster.upper()}")
                    continue
                if path.isfile(timestampFile):
                    if not path.isfile(timestampFileBCK):
                        copy(timestampFile,timestampFileBCK)                  

                        file = open(timestampFile, "r")                  
                        timestampDic = load(file)     
                        file.close()
                        file = None

                        timestampDic["cTime"] = "searching"

                        file = open(timestampFile, "w")
                        dump(timestampDic, file) 
                        file.close()
                        file = None
                    else:
                        if not path.isfile(timestampFileSearching):
                            file = open(timestampFileSearching, "w")
                            file.write(str(2))
                            file.close()
                            file = None
                        else:
                            file = open(timestampFileSearching, "r")
                            line = file.read()
                            searchCounter = int(line)                            
                            file = open(timestampFileSearching, "w")
                            file.write(str(searchCounter + 1))
                            file.close()
                            file = None
                        logger.error(f"There is already an active search at this moment") 
                else:
                    logger.error(f"timestamp does not exists or is inaccessible in path {workdir}")

                regions = []
                currentnamespaces = 0
                totalnamespaces = 0
                regions.append(list(client.clusters[environment][cluster].keys())[0])
                if cluster == 'bks' and environment == 'pre':    
                    regions.append(list(client.clusters[environment][cluster].keys())[1])

                await websocket.send_text(f"STARTING search: {cluster.upper()}")
                for region in regions:
                    try:
                        namespaceList = await client.get_resource(resource="namespaces",functional_environment=environment,cluster=cluster,region=region)
                    except client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {cluster.upper()}({region})")                
                        continue
                    except:
                        logger.error(f"Namespaces of {cluster.upper()}-{region.upper()} could not be retrieved. Skipping...")                
                        continue
                
                    try:
                        items = namespaceList[region]['items']
                    except:
                        items = None
                
                    if items != None and len(items) > 0:
                        namespaceList = items
                        for namespace in namespaceList:                
                            namespaceName = namespace['metadata']['name']                
                            #if namespaceName.startswith("sanes-") or namespaceName.startswith("san-") or namespaceName.startswith("sgt-"):
                            if namespaceName.startswith(tuple(namespaceStartWith)):
                                totalnamespaces += 1                        

                        for namespace in namespaceList:
                            namespaceName = namespace['metadata']['name']
                            #if namespaceName.startswith("sanes-") or namespaceName.startswith("san-") or namespaceName.startswith("sgt-"):
                            if namespaceName.startswith(tuple(namespaceStartWith)):
                                currentnamespaces += 1
                                dict_counter = {"total": totalnamespaces, "current": currentnamespaces}                    
                                logger.info(f"checking namespace: {namespaceName}")

                                #await websocket.send_text(f"Comprobando namespace: {namespace}")
                                await websocket.send_json(dict_counter)
                                
                                listResultENV = await searchConfigEnv(environment, cluster, namespaceName, patternsplit)
                                if len(listResultENV) > 0:                                                                            
                                    listResult.extend(listResultENV)                                           
                                    listResultENV = None
                                else:
                                    pass

                                listResultSEC = await searchConfigSecret(environment, cluster, namespaceName, patternsplit)
                                if len(listResultSEC) > 0:                                                                            
                                    listResult.extend(listResultSEC)
                                    listResultSEC = None
                                else:
                                    pass

                                listResultCP = await searchConfigMap(environment, cluster, namespaceName, patternsplit)
                                if len(listResultCP) > 0:                                                                            
                                    listResult.extend(listResultCP)
                                    listResultCP = None
                                else:
                                    pass

                                try:
                                    microservicesD = await client.get_resource(resource="deployments",functional_environment=environment,cluster=cluster,region=region,namespace=namespaceName)                    
                                except client_exceptions.ServerTimeoutError:
                                    logger.error(f"Timeout detected against {cluster.upper()}({region}) > {namespaceName}")            
                                    microservicesD = None
                                except:
                                    logger.error(f"Microservices of {cluster.upper()}-{region.upper()}-{namespaceName} -  could not be retrieved. Skipping...")   
                                    microservicesD = None

                                if microservicesD and len(microservicesD) > 0:
                                    microservicesD = microservicesD[region]["items"]
                                    if len(microservicesD) > 0:
                                        listResultD = await searchDeployment(namespaceName, microservicesD, environment, cluster, patternsplit)
                                        if len(listResultD) > 0:                                                                                                            
                                            listResult.extend(listResultD)
                                            listResultD = None
                                        else:
                                            pass

                                try:
                                    microservicesDC = await client.get_resource(resource="deploymentconfigs",functional_environment=environment,cluster=cluster,region=region,namespace=namespaceName)
                                except client_exceptions.ServerTimeoutError:
                                    logger.error(f"Timeout detected against {cluster.upper()}({region}) > {namespaceName}")            
                                    microservicesDC = None
                                except:
                                    logger.error(f"Microservices of {cluster.upper()}-{region.upper()}-{namespaceName} -  could not be retrieved. Skipping...")   
                                    microservicesDC = None
    
                                if microservicesDC and len(microservicesDC) > 0:
                                    microservicesDC = microservicesDC[region]["items"]
                                    if len(microservicesDC) > 0:
                                        listResultDC = await searchDeployment(namespaceName, microservicesDC, environment, cluster, patternsplit)
                                        if len(listResultDC) > 0:                                                                                                            
                                            listResult.extend(listResultDC)
                                            listResultDC = None
                                        else:
                                            pass
                                
                chdir(workdir)
                if path.isfile(timestampFile):
                    if path.isfile(timestampFileSearching):
                        file = open(timestampFileSearching, "r")
                        line = file.read()
                        searchCounter = int(line)
                        file.close()
                        file = line = None                         
                        if searchCounter > 1:
                            file = open(timestampFileSearching, "w")
                            file.write(str(searchCounter - 1))
                            file.close()
                            file = None
                        else:                        
                            remove(timestampFileSearching)
                            move(timestampFileBCK,timestampFile)                            
                    elif path.isfile(timestampFileBCK):                    
                        move(timestampFileBCK,timestampFile)
                else:
                    logger.error(f"timestamp does not exists or is inaccessible in path {workdir}") 
                
                logger.info(f"FINISHED search: {cluster.upper()}")
                await websocket.send_text(f"FINISHED search: {cluster.upper()}")
            
            if len(listResult) == 0:            
                dictResult["result"] = []
                await searchPatternAuditRecord(ldap, environment, cluster, pattern, listResult)
                data = str.encode(dumps(dictResult))
                await websocket.send_text(data)
                data = dictResult = None                    

                if not empty:
                    logger.info(f"No search results in {environment.upper()} {cluster.upper()}")
                    await websocket.send_text(f"No search results in {environment.upper()} {cluster.upper()}")
            else:
                if anonymize == "true":
                    await websocket.send_text(f"STARTING anonymize....")
                    listResult = await resultSearchAnonymize(listResult)
                    await websocket.send_text(f"FINISHED anonymize....")
                dictResult["result"] = listResult                
                            
                now = datetime.now()
                now = now.strftime('%Y%m%d-%H%M')
                outputfile = repositories + separator + environment + separator + "resultSearch." + now + ".json"

                try:
                    remove(outputfile)
                except OSError:
                    pass

                with open(outputfile, "a") as fileresult:
                    dump(dictResult, fileresult) 
                fileresult.close()                
                fileresult = None

                data = str.encode(dumps(dictResult))
                await websocket.send_text(data)

                df = json_normalize(listResult)
                outputfile = repositories + separator + environment + separator + "resultSearch." + now + ".csv"
                df = df.fillna(value="Not informed")
                df.to_csv(outputfile, index = False, encoding = "utf-8") 
                df = read_csv(outputfile)
                csv2string = df.to_csv(index = False)
                
                await websocket.send_text(csv2string)
                
                # Guardar audit ANTES de vaciar listResult
                await searchPatternAuditRecord(ldap, environment, cluster, pattern, listResult)
                
                data = dictResult = df = csv2string = None
                listResult = []
        else:
            logger.error(f"repository {cluster.upper()} is empty in {environment.upper()}")
            await websocket.send_text(f"repository {cluster.upper()} is empty in {environment.upper()}")
            await searchPatternAuditRecord(ldap, environment, cluster, pattern, listResult)
            listResult = []
            empty = True
        
        logger.info(f'FINISHED search in {environment.upper()}')                
        await websocket.send_text(f'FINISHED search in {environment.upper()}')

        endTime = time() 
        executionTime = endTime - startTime 
        m, s = divmod(executionTime, 60)
        h, m = divmod(m, 60)
        executionTimeFormat = "{:02.0f}:{:02.0f}:{:02.0f}".format(h, m, s)
        logger.info(f'Time execution: {executionTimeFormat}')
        await websocket.send_text(f'Time execution: {executionTimeFormat}')
        
        await websocket.close(code = 1000, reason = None)        

        return

async def searchPatternBatchTreatment(functional_environment, auth, ldap, cluster=None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                
                await cloneAll(functional_environment.lower(), cluster)
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            await cloneAll(functional_environment.lower(), cluster)

async def searchPatternOfflineTreatment(functional_environment, cluster, pattern, auth, ldap):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                resultSearch = await searchPattern(functional_environment.lower(), cluster.lower(), pattern)                
                await searchPatternAuditRecord(ldap, functional_environment, cluster, pattern, resultSearch)
                return resultSearch
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            resultSearch = await searchPattern(functional_environment.lower(), cluster.lower(), pattern)
            await searchPatternAuditRecord(ldap, functional_environment, cluster, pattern, resultSearch)
            return resultSearch

async def searchPatternAuditTreatment(functional_environment, cluster, auth, ldap, date = None, user = None, pattern=None):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                return await searchAuditLog(functional_environment.lower(), cluster.lower(), date, user, pattern)
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await searchAuditLog(functional_environment.lower(), cluster, date, user, pattern)

async def searchPatternTimestampTreatment(functional_environment, auth, ldap):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
                resultSearchTimestamp = await searchTimestamp(functional_environment.lower())
                return resultSearchTimestamp
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            resultSearchTimestamp = await searchTimestamp(functional_environment.lower())
            return resultSearchTimestamp

async def searchPatternCollectionGC(auth, ldap):
    match entity_id:
        case "spain":
            if auth:
                isDevops = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_devops")
                if isDevops == False:
                    isEstruct = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_cambios_estructurales")
                    if isEstruct == False:
                        raise HTTPException(status_code=403, detail="User not authorized")
        
                return await cleanAndCollectAllGenerationObjects()
            else:
                raise HTTPException(status_code=400, detail="Token not exist")
        case _:
            return await cleanAndCollectAllGenerationObjects()
    

