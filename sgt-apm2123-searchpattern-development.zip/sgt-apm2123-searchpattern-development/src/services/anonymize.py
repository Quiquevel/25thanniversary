from subprocess import check_output, STDOUT, DEVNULL, CalledProcessError
from shuttlelib.utils.logger import logger

includeAnonymizeSed1 = {'password', 'pass', 'secret','key', 'token', 'pwd', 'psw', 'pswd', 'credential'}
includeAnonymizeSed2 = {'cipher'}
excludeAnonymizeSed1 = {'\'\'','\' \'','\"\"','\" \"', '=\n', ':\n', '= \n', ': \n', \
                        'portfor', '.port.', '-port-', 'httpporttoken', \
                        'address', 'host', 'generate', \
                        '${', '={', '=%', \
                        'false\'', 'true\'', \
                        'false"', 'true"', \
                        'corporate', 'binary', \
                        '/sas', '/uds', '/password', '/oauth', '/scc', \
                        'dataKey', 'appkey', 'app-key', '\"datakey\"', \
                        'srvnuarintra' \
                        }
excludeAnonymizeSed2 = {'${', ':<', 'thin', ':1433', 'port'}

patternAnonymizeSed = "(password:|password: |password :|password : " \
                        "|Password:|Password: |Password :|Password : " \
                        "|password=|password= |password =|password = " \
                        "|Password=|Password= |Password =|Password = " \
                        "|PASSWORD:|PASSWORD: |PASSWORD :|PASSWORD : " \
                        "|PASSWORD=|PASSWORD= |PASSWORD =|PASSWORD = " \
                        "|pass:|pass: |pass :|pass : " \
                        "|Pass:|Pass: |Pass :|Pass : " \
                        "|pass=|pass= |pass =|pass = " \
                        "|Pass=|Pass= |Pass =|Pass = " \
                        "|PASS:|PASS: |PASS :|PASS : " \
                        "|PASS=|PASS= |PASS =|PASS = " \
                        "|pwd:|pwd: |pwd :|pwd : " \
                        "|Pwd:|Pwd: |Pwd :|Pwd : " \
                        "|pwd=|pwd= |pwd =|pwd = " \
                        "|Pwd=|Pwd= |Pwd =|Pwd = " \
                        "|PWD:|PWD: |PWD :|PWD : " \
                        "|PWD=|PWD= |PWD =|PWD = " \
                        "|psw:|psw: |psw :|psw : " \
                        "|Psw:|Psw: |Psw :|Psw : " \
                        "|psw=|psw= |psw =|psw = " \
                        "|Psw=|Psw= |Psw =|Psw = " \
                        "|PSW:|PSW: |PSW :|PSW : " \
                        "|PSW=|PSW= |PSW =|PSW = " \
                        "|pswd:|pswd: |pswd :|pswd : " \
                        "|Pswd:|Pswd: |Pswd :|Pswd : " \
                        "|pswd=|pswd= |pswd =|pswd = " \
                        "|Pswd=|Pswd= |Pswd =|Pswd = " \
                        "|PSWD:|PSWD: |PSWD :|PSWD : " \
                        "|PSWD=|PSWD= |PSWD =|PSWD = " \
                        "|secret:|secret: |secret :|secret : " \
                        "|Secret:|Secret: |Secret :|Secret : " \
                        "|secret=|secret= |secret =|secret = " \
                        "|Secret=|Secret= |Secret =|Secret = " \
                        "|SECRET:|SECRET: |SECRET :|SECRET : " \
                        "|SECRET=|SECRET= |SECRET =|SECRET = " \
                        "|key:|key: |key :|key : " \
                        "|Key:|Key: |Key :|Key : " \
                        "|key=|key= |key =|key = " \
                        "|Key=|Key= |Key =|Key = " \
                        "|KEY:|KEY: |KEY: |KEY : " \
                        "|KEY=|KEY= |KEY= |KEY = " \
                        "|token:|token: |token :|token : " \
                        "|Token:|Token: |Token :|Token : " \
                        "|token=|token= |token =|token = " \
                        "|Token=|Token= |Token =|Token = " \
                        "|TOKEN:|TOKEN: |TOKEN :|TOKEN : " \
                        "|TOKEN=|TOKEN= |TOKEN =|TOKEN = " \
                        "|keystore_password" \
                        "|credentials:|credentials: |credentials :|credentials : " \
                        "|Credentials:|Credentials: |Credentials :|Credentials : " \
                        "|credentials=|credentials= |credentials =|credentials = " \
                        "|Credentials=|Credentials= |Credentials =|Credentials = " \
                        "|CREDENTIALS:|CREDENTIALS: |CREDENTIALS :|CREDENTIALS : " \
                        "|CREDENTIALS=|CREDENTIALS= |CREDENTIALS =|CREDENTIALS = " \
                        "|credential:|credential: |credential :|credential : " \
                        "|Credential:|Credential: |Credential :|Credential : " \
                        "|credential=|credential= |credential =|credential = " \
                        "|Credential=|Credential= |Credential =|Credential = " \
                        "|CREDENTIAL:|CREDENTIAL: |CREDENTIAL :|CREDENTIAL : " \
                        "|CREDENTIAL=|CREDENTIAL= |CREDENTIAL =|CREDENTIAL = " \
                        "|password\":\"|password\": \"|password \":\"|password \": \"" \
                        "|Password\":\"|Password\": \"|Password \":\"|Password \": \"" \
                        "|PASSWORD\":\"|PASSWORD\": \"|PASSWORD \":\"|PASSWORD \": \"" \
                        "|pass\":\"|pass\": \"|pass \":\"|pass \": \"" \
                        "|Pass\":\"|Pass\": \"|Pass \":\"|Pass \": \"" \
                        "|PASS\":\"|PASS\": \"|PASS \":\"|PASS \": \"" \
                        "|pwd\":\"|pwd\": \"|pwd \":\"|pwd \": \"" \
                        "|Pwd\":\"|Pwd\": \"|Pwd \":\"|Pwd \": \"" \
                        "|PWD\":\"|PWD\": \"|PWD \":\"|PWD \": \"" \
                        "|secret\":\"|secret\": \"|secret \":\"|secret \": \"" \
                        "|Secret\":\"|Secret\": \"|Secret \":\"|Secret \": \"" \
                        "|SECRET\":\"|SECRET\": \"|SECRET \":\"|SECRET \": \"" \
                        "|key\":\"|key\": \"|key \":\"|key \": \"" \
                        "|Key\":\"|Key\": \"|Key \":\"|Key \": \"" \
                        "|KEY\":\"|KEY\": \"|KEY \":\"|KEY \": \"" \
                        "|token\":\"|token\": \"|token \":\"|token \": \"" \
                        "|Token\":\"|Token\": \"|Token \":\"|Token \": \"" \
                        "|TOKEN\":\"|TOKEN\": \"|TOKEN \":\"|TOKEN \": \"" \
                        "|passphase\":\"|passphase\": \"|passphase \":\"|passphase \": \"" \
                        "|Passphase\":\"|Passphase\": \"|Passphase \":\"|Passphase \": \"" \
                        "|PASSPHRASE\":\"|PASSPHRASE\": \"|PASSPHRASE\": \"|PASSPHRASE \": \"" \
                        ")"

async def resultSearchAnonymize(listResult):
    command1=rf"""s/{patternAnonymizeSed}[^;]*/\1********/g"""
    
    #local version 
    command2=r"'s/\(.*:\)[^@]*\(@\)/\1********\2/'"
    #microservice version
    command2=r's/\(.*:\)[^@]*\(@\)/\1********\2/'

    #current version --> microservice
    command2=r's/\(.*:\)[^@]*\(@\)/\1********\2/'

    #print("comando1: ", command1)
    #print("comando2: ", command2)
        
    logger.info(f'starting anonymize results.....')
    
    for item in listResult: 
        #print(item['namespace'])
        #if item['namespace'] == "sanes-gabriel-test-dev":
        #    pass

        for file in item['files']:            
            for i in range(len(file["match"])):
                match=file["match"][i]
                #print("without anonymizing ", match)
                #logger.info(f'without anonymizing --> {match}')
                isAnonymize = False
                
                for itemAnonymize in includeAnonymizeSed1:
                    if itemAnonymize in match.lower():
                        if isAnonymize == False and not ([excludeWord for excludeWord in excludeAnonymizeSed1 if excludeWord in match.lower()]) and not match.lower().endswith(('=', ':')):
                            try:                                
                                matchAnonymize=check_output(["sed", "-E", command1], universal_newlines=True, input=match, stderr=STDOUT)
                            except CalledProcessError as e:
                                #print("Error in anonymize1")
                                #print("Error: ", e)
                                logger.error("Error in anonymize ", e)
                                raise RuntimeError("command '{}' return with error (code {}): {}".format(e.cmd, e.returncode, e.output))    
                            if matchAnonymize and "********" in matchAnonymize:
                                isAnonymize = True
                                #print("Anonimizado1 ", matchAnonymize)
                                file["match"][i]=matchAnonymize
                            else:
                                isAnonymize = False
                else:
                    if isAnonymize == True and not ([excludeWord for excludeWord in excludeAnonymizeSed2 if excludeWord in match.lower()]):
                        try:
                            matchAnonymize=check_output(["sed", command2], universal_newlines=True, input=matchAnonymize, stderr=STDOUT)
                        except CalledProcessError as e:
                            #print("Error in anonymize2")
                            #print("Error: ", e)
                            logger.error("Error in anonymize ", e)
                            raise RuntimeError("command '{}' return with error (code {}): {}".format(e.cmd, e.returncode, e.output))    
                            
                        if matchAnonymize and "********" in matchAnonymize:
                            isAnonymize = True
                            #print("Anonimizado2 ", matchAnonymize)
                            file["match"][i]=matchAnonymize
                        else:
                            isAnonymize = False
                    elif isAnonymize == False and not ([excludeWord for excludeWord in excludeAnonymizeSed2 if excludeWord in match.lower()]):
                        try:
                            matchAnonymize=check_output(["sed", command2], universal_newlines=True, input=match, stderr=STDOUT)
                        except CalledProcessError as e:
                            #print("Error en anonymize3")
                            #print("Error: ", e)
                            logger.error("Error in anonymize ", e)
                            raise RuntimeError("command '{}' return with error (code {}): {}".format(e.cmd, e.returncode, e.output))                                
                        if matchAnonymize and "********" in matchAnonymize:
                            isAnonymize = True
                            #print("Anonimizado3 ", matchAnonymize)
                            file["match"][i]=matchAnonymize
                        
                        elif isAnonymize == False and ([includeWord for includeWord in includeAnonymizeSed2 if includeWord in match.lower()]):
                            #print("Entramo en 1º else")
                            try:
                                matchAnonymize=check_output(["sed", "-E", command1], universal_newlines=True, input=match, stderr=STDOUT)
                            except CalledProcessError as e:
                                #print("Error en anonymize4")
                                #print("Error: ", e)
                                logger.error("Error in anonymize ", e)
                                raise RuntimeError("command '{}' return with error (code {}): {}".format(e.cmd, e.returncode, e.output))                                
                            if matchAnonymize and "********" in matchAnonymize:
                                isAnonymize = True
                                #print("Anonimizado4 ", matchAnonymize)
                                file["match"][i]=matchAnonymize

                    #logger.info(f'Anonimizado --> {matchAnonymize}')
                    '''
                    else:
                        print("Entramo en 2º else")
                        try:
                            matchAnonymize=check_output(["sed", "-E", command1], universal_newlines=True, input=match, stderr=STDOUT)
                        except CalledProcessError as e:
                            print("Error en anonymize4")
                            print("Error: ", e)
                            raise RuntimeError("command '{}' return with error (code {}): {}".format(e.cmd, e.returncode, e.output))                                
                        if matchAnonymize and "********" in matchAnonymize:
                            isAnonymize = True
                            print("Anonimizado4 ", matchAnonymize)
                            file["match"][i]=matchAnonymize
                    '''
    logger.info(f'finished anonymize results.....')
    return(listResult)