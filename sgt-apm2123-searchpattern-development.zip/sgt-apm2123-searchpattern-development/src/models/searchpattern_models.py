
from fastapi import HTTPException
from pydantic import BaseModel, validator
from src.services.clientunique import getEnvironmentsClustersRegionsList

environmentList, clusterList, regionList = getEnvironmentsClustersRegionsList()

class searchpatternBatch(BaseModel):
    functionalEnvironment: str
    cluster: str = None
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code=400, detail=f"{v} value is not valid for functionalEnvironment")
        return v

    @validator("cluster")
    def validate_cluster(cls, v):        
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code=400, detail=f"{v} value is not valid for cluster")
        return v

class searchpatternTimestamp(BaseModel):
    functionalEnvironment: str 
    ldap: str

    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code=400, detail=f"{v} value is not valid for functionalEnvironment")
        return v
class searchpatternOffline(BaseModel):
    functionalEnvironment: str
    cluster: str
    pattern: str
    ldap: str
    
    @validator("functionalEnvironment")
    def validate_environment(cls, v):        
        if not any(x == v for x in environmentList):
            raise HTTPException(status_code=400, detail=f"{v} value is not valid for functionalEnvironment")
        return v
    
    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in clusterList):
            raise HTTPException(status_code=400, detail=f"{v} value is not valid for cluster")
        return v

class searchpatternAuditModel(BaseModel):
    functionalEnvironment: str
    cluster: str
    date: str = None
    user: str = None
    pattern: str = None
    ldap: str

class searchpatternAuthorization(BaseModel):
    ldap: str
