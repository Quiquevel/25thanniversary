"""
This module handles external requests for the microservice.
"""
from fastapi import APIRouter, Depends
from fastapi.security import HTTPBearer
from src.services.searchpatterns import searchPatternBatchTreatment, searchPatternOfflineTreatment, searchPatternAuditTreatment, searchPatternTimestampTreatment, searchPatternCollectionGC
from src.services.authorization import authorizationTreatment
from src.models.searchpattern_models import searchpatternBatch, searchpatternOffline, searchpatternTimestamp, searchpatternAuditModel, searchpatternAuthorization 
from urllib3 import disable_warnings

disable_warnings()
bearer = HTTPBearer()

#constant
API_SEARCHPATTERN = "/api/v1/searchpattern"

searchpattern_core = APIRouter(tags=["Searchpattern CORE(Clone repositories, searchs patterns and audits)"], prefix=API_SEARCHPATTERN)
searchpattern_authorization = APIRouter(tags=["Searchpattern AUTHORIZATION"], prefix=API_SEARCHPATTERN)
searchpattern_others = APIRouter(tags=["Searchpattern OTHERs"], prefix=API_SEARCHPATTERN)

#Searchpattern CORE(CloneALL and Searchs)
@searchpattern_core.post("/searchPatternBatch", tags=["Searchpattern CORE(Clone repositories, searchs patterns and audits)"], description="SEARCH PATTERNS BATCH(CLONE)", response_description="JSON", status_code=200)
async def search_pattern_batch(target: searchpatternBatch, Authorization: str = Depends(bearer)):
    """
    Asynchronously clone repositories.

    Parameters:
    - target: The target searchpatternBatch object containing the functionalEnvironment, cluster and user to retrieve data for.

    Returns:
    - http status code of the operation.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    await searchPatternBatchTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap)

@searchpattern_core.post("/searchPatternOffline", tags=["Searchpattern CORE(Clone repositories, searchs patterns and audits)"], description="SEARCH PATTERNS OFFLINE(SEARCH)", response_description="JSON", status_code=200)
async def search_pattern_offline(target: searchpatternOffline, Authorization: str = Depends(bearer)):
    """
    Asynchronously search patterns in repositories.

    Parameters:
    - target: The target searchpatternOffline object containing the functionalEnvironment, cluster, pattern and user to retrieve data for.

    Returns:
    - The retrieved matchs of the pattern data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await searchPatternOfflineTreatment(functional_environment=target.functionalEnvironment,cluster=target.cluster, pattern=target.pattern, auth=Authorization, ldap=target.ldap)

@searchpattern_core.post("/searchPatternsAudit", tags=["Searchpattern CORE(Clone repositories, searchs patterns and audits)"], description="SEARCH AUDIT SEARCHs", response_description="JSON", status_code=200)
async def search_pattern_audit(target: searchpatternAuditModel, Authorization: str=Depends(bearer)):
    """
    Asynchronously search patterns audit.

    Parameters:
    - target: The target searchpatternAuditModel object containing the functionalEnvironment, cluster and pattern to retrive audit for.

    Returns:
    - The retrieved searchpattern audit data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await searchPatternAuditTreatment(functional_environment=target.functionalEnvironment, cluster=target.cluster, auth=Authorization, ldap=target.ldap, date=target.date, user=target.user, pattern=target.pattern)

@searchpattern_core.post("/searchPatternTimestamp", tags=["Searchpattern CORE(CloneALL and Searchs)"], description="SEARCH PATTERNS TIMESTAMP", response_description="JSON", status_code=200)
async def search_pattern_timestamp(target: searchpatternTimestamp, Authorization: str = Depends(bearer)):
    """
    Asynchronously search timestamps of the repositories.

    Parameters:
    - target: The target searchpatternTimestamp object containing the functionalEnvironment and user to retrieve data for.

    Returns:
    - The retrieved timestamp data.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """
    return await searchPatternTimestampTreatment(functional_environment=target.functionalEnvironment, auth=Authorization, ldap=target.ldap)


@searchpattern_authorization.post("/authorizationuser", tags=["Searchpattern AUTHORIZATION"], description="VALIDATE USER UID - AUTHORIZATION", response_description="JSON", status_code=200)
async def search_pattern_authorization(target: searchpatternAuthorization, Authorization: str = Depends(bearer)):
    """
    Asynchronously retrieves authorization for user.     

    Parameters:
    - target: The target alertingAuthorization object containing the ldap user to retrieve data for.

    Returns:
    - The retrieved authorization token.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """  
    return await authorizationTreatment(auth=Authorization, ldap=target.ldap)


@searchpattern_others.post("/searchPatternCollectionGC", tags=["Searchpattern OTHERs"], description="LAUNCH GARBAGE COLLECTION", response_description="JSON", status_code=200)
async def search_pattern_collection_GC(target: searchpatternAuthorization, Authorization: str = Depends(bearer)):
    """
    Asynchronously launch GCs.     

    Parameters:
    - target: The target alertingAuthorization object containing the ldap user.

    Returns:
    - http status code of the operation.

    Raises:
    - Any exceptions that occur during the retrieval process.
    """  
    return await searchPatternCollectionGC(auth=Authorization, ldap=target.ldap)



