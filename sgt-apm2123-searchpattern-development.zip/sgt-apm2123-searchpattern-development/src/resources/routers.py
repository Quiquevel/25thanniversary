from src.handler.external_requests import searchpattern_core, searchpattern_authorization, searchpattern_others
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(searchpattern_core),
    RouteClass(searchpattern_authorization),
    RouteClass(searchpattern_others)
]
