"""
This module contains a Fastapi resource for creating a new user.
"""
