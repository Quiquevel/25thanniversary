from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "sgt-apm2123-searchpattern",
          "description": "clone repositories and search patterns",
          "contact": {
               "name": "SRECoEDevSecOps",
               "url": "SRECoEDevSecOps@gruposantander.com"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
