"""
This module contains the main FastAPI application for the microservice.
"""
from fastapi import FastAPI, WebSocket
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers
from src.app.config.composer_config import config as composer_config
from src.services.searchpatterns import searchPatternWS

app = FastAPI()

description = """
sgt-apm2123-searchpattern

### SUMMARY
Microservice to search patterns in githubconf, github, cmaps and environment\n
Every day, first thing in the morning, automatically download the data to be able to search later

### ENDPOINTS
* **/searchPatternBatch:** Downloads repositories (githubconf and github), cmaps and vars in environment (openshift) to local file system in microservice
* **/searchPatternOffline:** Searchs patterns in the repository downloaded
* **/searchPatternTimestamp:** Shows creation and modification timestamp of the repositories > clusters
* **/searchPatternEnvironmentsClusters:** Shows clusters avalaibles in the entity
* **/searchPatternAuthorization:** Validate user UID - Authorization
* **/searchPatternCollectionGC:** Lauchs GC on demand

### PARAMETERS
* **Environment:** dev, pre, pro or all 
* **cluster:** \n
    This parameter is optional and it can be:\n
    * For environment dev / pre --> azure, bks and ocp05azure \n
    * For environment pro --> azure, confluent, dmz2bmov, dmzbbks, dmzbdarwin, probks, prodarwin, dmzbazure and ocp05azure \n
    Note: we can use "all" to execute all cluster in one environment
* **pattern:** terms to search (can be more of one, separete by comma or in the case of gateways can be "paths" --> all paths of GWs or "paths, request to search" --> particular path of GWs)
* **ldap:** uid devops team to lauch enpoints
* **entity:** entity like "spain"

### REPO
* [searchpattern](https://github.com/santander-group-sds-gln/sgt-apm2123-searchpattern)
"""

app = FastAPI(
                docs_url="/docs",
                title="searchpattern",
                description=description,version="1.0",
                openapi_url="/api/v1/openapi.json",
                contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"}
              )

DarwinComposer(app, config=composer_config, routers=routers)

@app.websocket("/searchRepositoriesWS")
async def searchRepositoriesWS(websocket: WebSocket, environment, cluster, pattern, ldap):
    await searchPatternWS(websocket, environment.lower(), cluster.lower(), pattern, ldap)

