import setuptools
from version import __version__

setuptools.setup(
    name = "sgt-apm2123-azcomparison",
    version = __version__,
    author = "Pedro Alamilla",
    author_email = "pedro.alamilla@gruposantander.com",
    description = "AZ comparison - warnings",
    long_description = "AZ comparison - warnings",
    long_description_content_type = "text/markdown",
    url = "sgt-apm2123-azcomparison",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
    ],
    python_requires = '>=3.13.0',
)
