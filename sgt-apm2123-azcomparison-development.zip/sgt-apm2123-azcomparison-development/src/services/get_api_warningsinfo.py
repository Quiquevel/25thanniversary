import json
import requests

def api_endpoint(do_api=None,namespace=None,cluster=None,region=None,option=None,entity_sanes=None):

    #pro - urlapi backend
    urlapi = "http://sgt-apm2123-warnings:8080"
    #urlapi = "https://sgt-apm2123-warnings-sanes-shuttle-pro.apps.san01darwin.san.pro.bo1.paas.cloudcenter.corp"
    #urlapi  = "https://shuttle-warnings-sanes-shuttle-dev.apps.san01bks.san.dev.bo1.paas.cloudcenter.corp"
    endpoint = f"/api/v1/warnings/{do_api}"
    match do_api:
        case "get_mismatched_variables":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "destination": "swagger"
                 }
            if namespace:
                body["namespace"] = namespace
        case "get_difference_btw_regions":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "option": option,
                    "destination": "swagger"
                  }
            if namespace:
                body["namespace"] = namespace
        case "get_paused_rollouts":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "destination": "swagger"
                    }
            if namespace:
                body["namespace"] = namespace
        case "get_hc_failurethreshold":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "destination": "swagger"
                    }
            if namespace:
                body["namespace"] = namespace
        case "get_services":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "destination": "swagger"
                    }
            if namespace:
                body["namespace"] = namespace
        case "get_services_routing_nowhere":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "destination": "swagger"
                 }
            if namespace:
                body["namespace"] = namespace
        case "get_wrong_routing_dns":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "destination": "swagger"
                }
            if namespace:
                body["namespace"] = namespace
        case "hpa_minmax_equal":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "destination": "swagger"
                    }
            if namespace:
                body["namespace"] = namespace
        case "get_hpa_unabletoscale":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "destination": "swagger"
                    }
            if namespace:
                body["namespace"] = namespace
        case "get_quotas":
            body = {
                    "entity_id": "spain",
                    "functional_environment": "pro",
                    "cluster": cluster,
                    "destination": "swagger"
                    }
            if namespace:
                body["namespace"] = namespace
        case "diff_final": #recommender_review
            endpoint = f"/api/v1/recommender_review/{do_api}"
            if entity_sanes:
                b_g_model = True
            else:
                b_g_model = False
            if cluster == "all":
                body = {
                        #"cluster": cluster,
                        #"namespace": namespace,
                        "only_diff_parameters": True,
                        "b_g_model": b_g_model,
                        "destination": "swagger"
                        }
            else:
                if namespace == None:
                    body = {
                            "cluster": cluster,
                            #"namespace": namespace,
                            "only_diff_parameters": True,
                            "b_g_model": b_g_model,
                            "destination": "swagger"
                            }
                else:
                    body = {
                            "cluster": cluster,
                            "namespace": namespace,
                            "only_diff_parameters": True,
                            "b_g_model": b_g_model,
                            "destination": "swagger"
                            }
    try:
        answer = requests.post(url=urlapi+endpoint, data=json.dumps(body), verify=False)
        if answer.status_code != 200:
            data = None
        else:
            data = json.loads(answer.text)
        return data
    except requests.exceptions.RequestException as e:
        return None