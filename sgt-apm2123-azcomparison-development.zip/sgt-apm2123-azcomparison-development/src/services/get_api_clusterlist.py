import json
import requests

def tokenparameter(token=None,do_api=None):
    token = ''
    #urlapi  = "https://shuttle-openshift-alerting-bbdd-read-sanes-shuttle-pro.apps.san01darwin.san.pro.bo1.paas.cloudcenter.corp"
    #urlapi  = "https://shuttle-openshift-alerting-bbdd-read-gsc-shuttletool-pro.apps.gsc04.gsc.pro.cn1.paas.cloudcenter.corp"
    #urlapi  = "https://shuttle-openshift-alerting-bbdd-read-sanes-shuttle-dev.apps.san01bks.san.dev.bo1.paas.cloudcenter.corp"
    #urlapi  = "https://shuttle-openshift-alerting-bbdd-read-sgt-shuttlepython-pro.apps.sgt01.sgt.pro.cn1.paas.cloudcenter.corp"
    urlapi  = "http://sgt-apm2123-alertsread:8080"

    match do_api:
        case "cluster_list":
            request_url = f"{urlapi}/api/v1/alerting/clusters"
            headers = {"Accept": "application/json","Authorization":'Bearer '+str(token),"x-clientid":"darwin"}
            try:
                response = requests.post(url=request_url,headers=headers, verify=False,timeout=100)
                if response.status_code == 200:
                    #datos = response.json()
                    datos = response.text
                    json_object = json.loads(datos)
                    return json_object
                else:
                    json_object = None
                    return json_object
            except requests.exceptions.RequestException as e:
                json_object = None
                return json_object

def get_namespaces(cluster,token=None):
    token = ''
    urlapi  = "http://sgt-apm2123-k8objects:8080"
    #urlapi  = "https://sgt-apm2123-k8objects-sanes-shuttle-pro.apps.san01darwin.san.pro.bo1.paas.cloudcenter.corp"
    request_url = f"{urlapi}/api/v1/objects/get-namespaces"
    headers = {"Accept": "application/json","Authorization":'Bearer '+str(token),"x-clientid":"darwin"}
    body = {
            "functionalEnvironment": "pro",
            "cluster": cluster
            }
    try:
        response = requests.post(url=request_url, data=json.dumps(body), verify=False,timeout=100)
        if response.status_code != 200:
            data = None
        else:
            data = json.loads(response.text)
        return data
    except requests.exceptions.RequestException as e:
        return None
