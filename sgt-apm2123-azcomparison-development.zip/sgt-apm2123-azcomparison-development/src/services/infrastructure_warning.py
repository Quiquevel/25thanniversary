import streamlit as st
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder
from src.services.get_api_warningsinfo import api_endpoint
from src.services.get_api_clusterlist import tokenparameter,get_namespaces

# Function to create download buttons
#@st.cache_data
def convert_df_to_csv(df):
    return df.to_csv().encode('utf-8')

# Main function
def do_infrastructure_warning():
    # Create separate placeholders for each option
    infra_placeholder = st.empty()
    global_placeholder = st.empty()
    
    global_placeholder.empty()  # Clear content for Global Warnings
    with infra_placeholder.container():
        st.markdown('### 🛡️Infrastructure Warnings')
        st.markdown("""
            <style>
            .stApp a:first-child { display: none; }
            .css-15zrgzn, .css-eczf16, .css-jn99sy { display: none; }
            </style>
            """, unsafe_allow_html=True)

        col1, col2 = st.columns([1, 2])
        with col1:
            json_object_cluster_region_list = tokenparameter(do_api='cluster_list')
        if json_object_cluster_region_list is None:
            st.info("No data available.")
            return

        with col1:
            # Show selectbox for clusters with a default option "Enter Cluster"
            optioncluster = st.selectbox(
                'Select Cluster',
                ["Enter Cluster", "all"] + [item['name'] for item in json_object_cluster_region_list],
                key="t_restart_c21_warning"
            )

            # Ensure the user selects an option other than the default before proceeding
            if optioncluster == "Enter Cluster":
                st.warning("Please select a valid cluster to proceed.")
                st.stop()

            # Add a selectbox for namespace search
            namespace_search = st.selectbox(
                'Search by namespace',
                ["no", "yes"],
                index=0,  # Default to "no"
                key="namespace_search_option_infra"
            )

            # Handle namespace selection if "yes" is chosen
            optionnamespace = None  # Initialize optionnamespace
            if namespace_search == "yes":
                find_namespaces = get_namespaces(cluster=optioncluster)

                # Validate if find_namespaces = None
                if not find_namespaces:
                    st.warning("Failed to fetch namespaces for the selected cluster.")
                    st.stop()

                projects = find_namespaces.get("projects", {})
                namespaces = projects.get("common", []) + projects.get("uncommon", [])

                # Validate if namespaces is empty
                if not namespaces:
                    st.warning("No namespaces available for the selected cluster.")
                    st.stop()

                optionnamespace = st.selectbox(
                    'Select Namespace',
                    namespaces,
                    key="namespace_selection"
                )
            
        # Display the content directly without tabs
        st.markdown("### Configured vs Recommended (resources)")

        # Ensure api_endpoints is defined globally or at the top of the function
        api_endpoints = {
            "Configured vs Recommended (resources)": "diff_final",
        }

        # Fetch data directly without tabs
        with st.spinner("Fetching data for Configured vs Recommended (resources), please wait..."):
            cluster_names = ["dmzbdarwin", "dmzbazure", "confluent", "ocp05azure", "probks", "prodarwin", "dmz2bmov", "dmzbbks"]
            exists = any(cluster['name'] in cluster_names for cluster in json_object_cluster_region_list)
            if exists:
                entity_sanes = True
                if namespace_search == "yes" and optionnamespace:
                    json_object = api_endpoint(cluster=optioncluster, do_api=api_endpoints["Configured vs Recommended (resources)"], namespace=optionnamespace, entity_sanes=entity_sanes)
                else:
                    json_object = api_endpoint(cluster=optioncluster, do_api=api_endpoints["Configured vs Recommended (resources)"], entity_sanes=entity_sanes)
            else:
                entity_sanes = False
                if namespace_search == "yes" and optionnamespace:
                    json_object = api_endpoint(cluster=optioncluster, do_api=api_endpoints["Configured vs Recommended (resources)"], namespace=optionnamespace)
                else:
                    json_object = api_endpoint(cluster=optioncluster, do_api=api_endpoints["Configured vs Recommended (resources)"])

            if json_object:
                data = json_object  # Extract the result list from the JSON object
                df = pd.DataFrame(data)  # Convert the JSON data to a pandas DataFrame

                # Flatten the nested columns for Configuration and Recomendation
                if "Configuration" in df.columns:
                    config_df = pd.json_normalize(df["Configuration"]).add_prefix("Configuration-")
                    df = pd.concat([df.drop(columns=["Configuration"]), config_df], axis=1)

                if "Recomendation" in df.columns:
                    rec_df = pd.json_normalize(df["Recomendation"]).add_prefix("Recomendation-")
                    df = pd.concat([df.drop(columns=["Recomendation"]), rec_df], axis=1)

                # Replace NaN with empty strings only in columns of type object
                for col in df.columns:
                    if df[col].dtype == "object":  # If the column is of object type
                        df[col] = df[col].fillna("")  # Replace NaN with empty strings

                # Ensure all columns have consistent types
                for col in df.columns:
                    if df[col].dtype == "object":  # Check for object type columns
                        df[col] = df[col].astype(str)  # Convert to string to avoid conversion errors

                # Replace empty values ​​in the 'domain' column with 'None'
                if 'domain' in df.columns:
                    df['domain'] = df['domain'].replace('', 'None')

                # Replace empty values in the 'devops' column with 'None'
                if 'devops' in df.columns:
                    df['devops'] = df['devops'].replace('', 'None')

                # Add filters for devops and domain
                st.markdown("#### Filters")
                # Display filters for devops and domain in the same row
                col1, col2 = st.columns(2)
                with col1:
                    devops_filter = st.multiselect(
                        "Filter by DevOps",
                        options=df["devops"].unique(),
                        key="devops_filter_key"
                    )
                with col2:
                    domain_filter = st.multiselect(
                        "Filter by Domain",
                        options=df["domain"].unique(),
                        key="domain_filter_keys"
                    )

                # Apply filters to the DataFrame
                filtered_df = df.copy()  # Create a copy of the DataFrame to apply filters
                if devops_filter:  # Apply devops filter only if it has values
                    filtered_df = filtered_df[filtered_df["devops"].isin(devops_filter)]
                if domain_filter:  # Apply domain filter only if it has values
                    filtered_df = filtered_df[filtered_df["domain"].isin(domain_filter)]

                # Show filtered data with AgGrid
                gb = GridOptionsBuilder.from_dataframe(filtered_df)
                gb.configure_default_column(
                    filterable=True,
                    sortable=True,
                    editable=False,
                    wrapHeaderText=True,  # Wrap text in the header to make it readable
                    autoHeaderHeight=True  # Adjust header height automatically
                )
                gb.configure_pagination(paginationAutoPageSize=False, paginationPageSize=10)

                # Set auto-sizing for columns
                gridOptions = gb.build()
                gridOptions["defaultColDef"] = {
                    "resizable": True,  # Allow resizing of columns
                }
                gridOptions["suppressHorizontalScroll"] = False  # Enable horizontal scrolling
                gridOptions["domLayout"] = "normal"  # Ensure the table layout allows scrolling
                gridOptions["columnDefs"] = [
                    {"field": col, "autoWidth": True} for col in filtered_df.columns
                ]  # Ensure each column auto-sizes

                # Render the table with a fixed width and enable horizontal scrolling
                AgGrid(
                    filtered_df,
                    gridOptions=gridOptions,
                    height=400,
                    width="100%",  # Set the table width to 100% of the container
                    fit_columns_on_grid_load=False,  # Disable auto-fit to allow scrolling
                    enable_enterprise_modules=True,
                )

                # Add a download button for the filtered data
                csv_data = convert_df_to_csv(filtered_df)
                st.download_button(
                    label="Download as CSV",
                    data=csv_data,
                    file_name="filtered_infrastructure_warnings.csv",
                    mime="text/csv",
                    key=f"download_button_infra_{optioncluster}_{namespace_search}"
                )
            else:
                st.info("No data available to display.")