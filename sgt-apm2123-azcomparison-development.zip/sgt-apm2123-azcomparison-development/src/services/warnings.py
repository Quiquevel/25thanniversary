import streamlit as st
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder
from src.services.get_api_warningsinfo import api_endpoint
from src.services.get_api_clusterlist import tokenparameter,get_namespaces

# Function to create download buttons
#@st.cache_data
def convert_df_to_csv(df):
    return df.to_csv().encode('utf-8')

# Main function
def do_warning_details():
    # Create separate placeholders for each option
    infra_placeholder = st.empty()
    global_placeholder = st.empty()

    infra_placeholder.empty()  # Clear content for Infrastructure Warnings
    with global_placeholder.container():
        st.markdown('### 🛡️Global Warnings')
        st.markdown("""
            <style>
            .stApp a:first-child { display: none; }
            .css-15zrgzn, .css-eczf16, .css-jn99sy { display: none; }
            </style>
            """, unsafe_allow_html=True)

        col1, col2 = st.columns([1, 2])
        with col1:
            json_object_cluster_region_list = tokenparameter(do_api='cluster_list')
        if json_object_cluster_region_list is None:
            st.info("No data available.")
            return

        with col1:
            # Show selectbox for clusters with a default option "Enter Cluster"
            optioncluster = st.selectbox(
                'Select Cluster',
                ["Enter Cluster"] + [item['name'] for item in json_object_cluster_region_list],
                key="t_restart_c21_global"
            )

            # Ensure the user selects an option other than the default before proceeding
            if optioncluster == "Enter Cluster":
                st.warning("Please select a valid cluster to proceed.")
                st.stop()

            # Add a selectbox for namespace search
            namespace_search = st.selectbox(
                'Search by namespace',
                ["yes", "no"],
                index=0,  # Default to "yes"
                key="namespace_search_option_global"
            )

            # Handle namespace selection if "yes" is chosen
            optionnamespace = None
            if namespace_search == "yes":
                find_namespaces = get_namespaces(cluster=optioncluster)

                # Validate if find_namespaces = None
                if not find_namespaces:
                    st.warning("Failed to fetch namespaces for the selected cluster.")
                    st.stop()

                projects = find_namespaces.get("projects", {})
                namespaces = projects.get("common", []) + projects.get("uncommon", [])

                # Validate if namespaces is empty
                if not namespaces:
                    st.warning("No namespaces available for the selected cluster.")
                    st.stop()

                optionnamespace = st.selectbox(
                    'Select Namespace',
                    namespaces,
                    key="namespace_selection"
                )

        # Add tabs for displaying different results
        tabs = [
            "Mismatched Variables", "Difference Between Regions", "Paused Rollouts", "HC Failure Threshold",
            "Services", "Services Routing Nowhere", "Wrong Routing DNS", "HPA MinMax Equal",
            "HPA Unable to Scale", "Quotas"
        ]
        tab_objects = st.tabs(tabs)

        # Ensure api_endpoints is defined globally or at the top of the function
        api_endpoints = {
            "Mismatched Variables": "get_mismatched_variables",
            "Difference Between Regions": "get_difference_btw_regions",
            "Paused Rollouts": "get_paused_rollouts",
            "HC Failure Threshold": "get_hc_failurethreshold",
            "Services": "get_services",
            "Services Routing Nowhere": "get_services_routing_nowhere",
            "Wrong Routing DNS": "get_wrong_routing_dns",
            "HPA MinMax Equal": "hpa_minmax_equal",
            "HPA Unable to Scale": "get_hpa_unabletoscale",
            "Quotas": "get_quotas"
        }

        # Iterate over each tab and fetch data only when the user enters the tab
        for tab_name, tab in zip(tabs, tab_objects):
            with tab:
                st.markdown(f"### {tab_name}")

                # Handle additional parameter for "Difference Between Regions"
                if tab_name == "Difference Between Regions":
                    option = st.selectbox(
                        "Select Option",
                        ["image", "envVar", "resources"],
                        key="difference_between_regions_option"
                    )

                    with st.spinner(f"Fetching data for {tab_name} with option {option}, please wait..."):
                        # Call the API endpoint with the selected option
                        if namespace_search == "yes" and optionnamespace:
                            json_object = api_endpoint(cluster=optioncluster, do_api=api_endpoints[tab_name], option=option, namespace=optionnamespace)
                        else:
                            json_object = api_endpoint(cluster=optioncluster, do_api=api_endpoints[tab_name], option=option)

                        if not json_object or "result" not in json_object or not json_object["result"]:
                            st.info(f"No data available for {tab_name}.")
                            continue

                        # Process data
                        data = json_object["result"]
                        df = pd.DataFrame(data)

                        # Show data with AgGrid
                        gb = GridOptionsBuilder.from_dataframe(df)
                        gb.configure_default_column(filterable=True, sortable=True, editable=False)
                        gb.configure_pagination(paginationAutoPageSize=False, paginationPageSize=10)
                        gridOptions = gb.build()

                        AgGrid(
                            df,
                            gridOptions=gridOptions,
                            height=400,
                            fit_columns_on_grid_load=True,
                            enable_enterprise_modules=True,
                        )

                        # Download as CSV
                        csv_data = convert_df_to_csv(df)
                        st.download_button(
                            label="Download as CSV",
                            data=csv_data,
                            file_name=f"{tab_name.lower().replace(' ', '_')}_option_{option}.csv",
                            mime="text/csv",
                            key=f"download_button_global_{tab_name}_{option}"
                        )
                else:
                    with st.spinner(f"Fetching data for {tab_name}, please wait..."):
                        if namespace_search == "yes" and optionnamespace:
                            json_object = api_endpoint(cluster=optioncluster, do_api=api_endpoints[tab_name], namespace=optionnamespace)
                        else:
                            json_object = api_endpoint(cluster=optioncluster, do_api=api_endpoints[tab_name])

                        if not json_object or "result" not in json_object or not json_object["result"]:
                            st.info(f"No data available for {tab_name}.")
                            continue

                        # Process data based on the tab name
                        if tab_name == "Services Routing Nowhere":
                            flattened_data = []
                            for item in json_object["result"]:
                                base_info = {
                                    "devops": item["devops"],
                                    "cluster": item["cluster"],
                                    "region": item["region"],
                                    "namespace": item["namespace"],
                                    "service": item["service"]
                                }
                                for key, value in item["selectors"].items():
                                    flattened_data.append({**base_info, "selector_key": key, "selector_value": value})

                            df = pd.DataFrame(flattened_data)
                        elif tab_name == "Wrong Routing DNS":
                            flattened_data = []
                            for item in json_object["result"]:
                                base_info = {
                                    "devops": item["devops"],
                                    "cluster": item["cluster"],
                                    "region": item["region"],
                                    "namespace": item["namespace"],
                                    "configuration object": item["configuration object"],
                                    "file": item["file"]
                                }
                                for routing in item["wrongRouting"]:
                                    flattened_data.append({**base_info, **routing})

                            df = pd.DataFrame(flattened_data)
                        else:
                            data = json_object["result"]
                            df = pd.DataFrame(data)

                        # Show data with AgGrid
                        gb = GridOptionsBuilder.from_dataframe(df)
                        gb.configure_default_column(filterable=True, sortable=True, editable=False)
                        gb.configure_pagination(paginationAutoPageSize=False, paginationPageSize=10)
                        gridOptions = gb.build()

                        AgGrid(
                            df,
                            gridOptions=gridOptions,
                            height=400,
                            fit_columns_on_grid_load=True,
                            enable_enterprise_modules=True,
                        )

                        # Download as CSV
                        csv_data = convert_df_to_csv(df)
                        st.download_button(
                            label="Download as CSV",
                            data=csv_data,
                            file_name=f"{tab_name.lower().replace(' ', '_')}.csv",
                            mime="text/csv",
                        )