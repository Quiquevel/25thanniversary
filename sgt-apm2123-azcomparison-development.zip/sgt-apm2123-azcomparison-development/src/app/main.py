import streamlit as st
import urllib3
import sys
from streamlit_option_menu import option_menu
from src.services.infrastructure_warning import do_infrastructure_warning
from src.services.warnings import do_warning_details

sys.path.insert(0, './src.services')

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Add custom CSS to remove the white box in the option menu
hide_white_box_style = """
    <style>
        .css-1n543e5 {  /* Adjust this class based on the Streamlit-generated class for the white box */
            background-color: transparent !important;
            box-shadow: none !important;
        }
    </style>
"""
st.markdown(hide_white_box_style, unsafe_allow_html=True)

async def get_data_api():
    """
    Main function to display the menu and handle user interactions.
    """
    # Define the menu and handle user selection
    selected = option_menu(
        menu_title=None,
        options=["Infrastructure Warning", "Global Warning" ],
        icons=["None", "None"],
        menu_icon="cast",
        default_index=0,
        orientation="horizontal"
    )

    # Call the appropriate function based on the selection
    if selected == "Infrastructure Warning":
        do_infrastructure_warning()
    elif selected == "Global Warning":
        do_warning_details()