from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "sgt-apm2123-azcomparison",
          "description": "AZ comparison - warnings",
          "contact": {
               "name": "Pedro Alamilla",
               "url": "https://github.com/santander-group-sds-gln/sgt-apm2123-azcomparison"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
