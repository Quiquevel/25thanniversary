from fastapi import APIRouter
from src.services.extractinfo import get_info_config_maps
import urllib3
from pydantic import BaseModel

urllib3.disable_warnings()

extracting = APIRouter(tags=["v1"])

class ObjectsModel(BaseModel):
    entity_id: str
    functional_environment: str
    cluster: str = None #Optional
    region: str = None #Opcional
    namespaceslist: list = None #Opcional


@extracting.post("/configmaps", tags=["v1"], description="GET CONFIG MAPS DATA AND SAVE IT IN SRE_CONFIGMAPS MONGO COLLECTION", response_description="JSON", status_code=200)
async def extractinfo(target: ObjectsModel):
    return await get_info_config_maps(entity_id=target.entity_id,functional_environment=target.functional_environment,clusterparam=target.cluster,regionparam=target.region,namespaceslist=target.namespaceslist)


