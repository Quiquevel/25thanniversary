from src.handler.external_requests import extracting
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(extracting, ["v1"]),

]
