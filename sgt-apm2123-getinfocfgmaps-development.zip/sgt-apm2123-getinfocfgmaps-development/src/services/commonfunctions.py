from shuttlelib.utils.logger import logger
import yaml
import xml.etree.ElementTree as ET
import json
import re
import os
import shuttlelib.db.mongo as mongolib
from datetime import datetime
from src.services.client import client

mg = mongolib.MongoClient()

async def deleteMongoObject(cluster, region, namespace,mongoobjects,openshiftobjects):

    openshiftelemid = [f'{cluster}-{region}-{namespace}-{elem["metadata"]["name"]}' for elem in openshiftobjects]

    for id in mongoobjects:
        if id not in openshiftelemid:
            logger.debug(f'Mongo elem {id} is not on Openshift anymore. Deleting...')
            mg.delete_one({"id": id})

async def getNamespaceObjects(functional_environment,cluster,region,namespace,resource):

    #TODO
    # AÑADIR CAMBIO DE ENTIDAD, RECIBIÉNDOLA POR PARÁMETRO...

    try:
        object = await client.get_resource(resource=resource,functional_environment=functional_environment,cluster=cluster,region=region,namespace=namespace)
        objectitems = object[region]["items"]
    except:
        logger.error(f'{resource} couldn\'t be obtained')
        objectitems = []

    return objectitems

async def LoopJsonFile(jsonfile, actualkey=None, path=None, pathslist=None):
    URL_PATTERNS = os.getenv("URL_PATTERNS").split(",")
    
    if pathslist is None:
        pathslist = []

    if path is None:
        path = ''

    if actualkey is not None:
        path = path + "." + actualkey

    if isinstance(jsonfile, dict):
        for key,value in jsonfile.items():
            if any(pattern in str(value) for pattern in URL_PATTERNS):
                if isinstance(value, (dict, list)):
                    await LoopJsonFile(value, key, path, pathslist)
                elif isinstance(value, str) and any(pattern in str(value) for pattern in URL_PATTERNS):
                    pathslist.append({"variable": path[1:]+"."+key,
                                      "value": value})
            else:
                continue

    elif isinstance(jsonfile, list):
        for i, item in enumerate(jsonfile):
            if any(pattern in str(item) for pattern in URL_PATTERNS):
                if isinstance(item, (dict, list)):
                    await LoopJsonFile(item, f'[{i}]', path, pathslist)
                elif isinstance(item, str):
                    if any(pattern in str(item) for pattern in URL_PATTERNS):
                        pathslist.append({"variable": path[1:],
                                          "value": item})
            else:
                continue

    return pathslist

async def LoopXmlFile(xmlfile, pathslist=None,path=None):
    URL_PATTERNS = os.getenv("URL_PATTERNS").split(",")
    if pathslist is None:
        pathslist = []

    if path is None:
        path = ''

    for attr_name, attr_value in xmlfile.attrib.items():
        if any(pattern in str(attr_value).lower() for pattern in URL_PATTERNS):
            attr_path = f'{path}/@{attr_name}' if path else f'@{attr_name}'
            pathslist.append({"variable": attr_path,
                              "value": str(attr_value)})

    if xmlfile.text and any(pattern in str(xmlfile.text).lower() for pattern in URL_PATTERNS):
        regex_pattern = '|'.join(re.escape(p) for p in URL_PATTERNS)
        regex = re.compile(regex_pattern)

        if xmlfile.text and regex.search(xmlfile.text):
            #matches = regex.findall(xmlfile.text)
            pathslist.append({"variable": path,
                              "value": str(xmlfile.text)})

    for child in xmlfile:
        child_path = f'{path}/{child.tag}' if path else child.tag
        await LoopXmlFile(child, pathslist, child_path)

    return pathslist

async def LoopYamlFile(yamlfile, actualkey=None, path=None, pathslist=None, looptimes=None):
    URL_PATTERNS = os.getenv("URL_PATTERNS").split(",")
    if pathslist is None:
        pathslist = []

    if path is None:
        path = ''

    if actualkey is not None:
        path = path + "." + actualkey
    
    looptimes += 1
    if isinstance(yamlfile, dict):
        for key,value in yamlfile.items():
            if isinstance(value, (dict,list)):
                await LoopYamlFile(value, key, path, pathslist,looptimes)
            elif isinstance(value, str):
                if any(pattern in str(value) for pattern in URL_PATTERNS):
                    if looptimes == 1:
                        pathslist.append({"variable": key,
                                          "value": value})
                    else:
                        pathslist.append({"variable": path[1:]+'.'+key,
                                          "value": value})

    elif isinstance(yamlfile, list):
        for i,item in enumerate(yamlfile):
            if isinstance(item, (dict,list)):
                await LoopYamlFile(item, f'{[i]}', path, pathslist,looptimes)
            elif isinstance(item, str):
                if any(pattern in str(item) for pattern in URL_PATTERNS):
                    if looptimes == 1:
                        pathslist.append({"variable": "no-variable",
                                          "value": item})
                    else:
                        pathslist.append({"variable": path[1:],
                                          "value": item})

    return pathslist

async def LoopStrings(k,v):
    URL_PATTERNS = os.getenv("URL_PATTERNS").split(",")
    pathslist = []
    splitstring = v.split('\r\n')
    if splitstring[0] == v:
        splitstring = v.split('\n')
        if splitstring[0] == v:
            splitstring = v.split('\r')
    for string in splitstring:
        # if len(splitstring) == 1:
        #     pathslist.append({k: string})
        # else:
            string = string.lstrip("\t")
            if any(pattern in str(string) for pattern in URL_PATTERNS) and (not string.startswith('#') and not string.startswith('/')):
                line = string.strip()
                separator_colon_equal = re.search(":|=",line.strip())
                separator_whitespace = re.search(r"\s",line.strip())
                if separator_whitespace != None:
                    if separator_whitespace.regs[0][0]+1 < separator_colon_equal.regs[0][0]:
                        separator = separator_whitespace
                    else:
                        separator = separator_colon_equal
                else:
                    separator = separator_colon_equal              
                variable_name = line[:separator.regs[0][0]].strip()
                variable_value = line[separator.regs[0][1]:].strip()
                
                # variable_name = ""
                # variable_value = ""
                # match = re.search(r'\s*(?P<separator>[=:])\s*',line)
                # if match:
                #     separator = match.group('separator')
                #     parts = re.split(r'\s*' + re.escape(separator) + r'\s*', line, maxsplit=1)
                #     if len(parts) == 2:
                #         variable_name, variable_value = parts
                #     else:
                #         variable_name = parts
                #         variable_value = ""
                if any(pattern in str(variable_name.strip()) for pattern in URL_PATTERNS):
                    continue
                pathslist.append({"variable": variable_name.strip(), "value": variable_value.strip()})
    
    return pathslist

async def LoopPropertiesFile(k,v):
    pathslist = await LoopStrings(k,v)
    
    return pathslist

async def LoopConfFile(k,v):
    pathslist = await LoopStrings(k,v)

    return pathslist

async def LoopText(k,v):
    URL_PATTERNS = os.getenv("URL_PATTERNS").split(",")
    if "\n" in v:
        lines = v.split("\n")
        if len(lines) == 2 and lines[1] == "":
            if any(pattern in str(lines[0]) for pattern in URL_PATTERNS) and (not lines[0].startswith('#') and not lines[0].startswith('/')):
                pathslist = [{"variable": k, "value": lines[0]}]
        else:
            pathslist = await LoopStrings(k,v)
    else:
        if any(pattern in str(v) for pattern in URL_PATTERNS) and (not v.startswith('#') and not v.startswith('/')):
            pathslist = [{"variable": k, "value": v}]
        else:
            pathslist = []

    return pathslist

async def Loopfile(k,v,configmapname,namespaceid):
    
    if k.endswith("xml"):
        logger.debug(f'Checking xml file of configmap {configmapname} of {namespaceid}')
        try:
            xmlfile = ET.fromstring(v)
            pathslist = await LoopXmlFile(xmlfile)
        except ET.ParseError as e:
            logger.warning(f'XML parse error for {configmapname} in {namespaceid}: {e}')
            try:
                wrapped_xml = f"<root>{v}</root>"
                xmlfile = ET.fromstring(wrapped_xml)
                pathslist = await LoopXmlFile(xmlfile)
                logger.debug(f'Successfully parsed XML after wrapping in root element')
            except ET.ParseError as e2:
                logger.error(f'Failed to parse XML even after secure wrapping for {configmapname} in {namespaceid}: {e2}')
                pathslist = []
        except Exception as e:
            logger.error(f'Unexpected error parsing XML for {configmapname} in {namespaceid}: {e}')
            pathslist = []
    elif k.endswith("yaml") or k.endswith("yml"):
        logger.debug(f'Checking yaml file on configmap {configmapname} of {namespaceid}')
        try:
            yamlfile = yaml.safe_load(v)
            pathslist = await LoopYamlFile(yamlfile, looptimes=0)
        except (yaml.composer.ComposerError, yaml.parser.ParserError):
            try:
                logger.debug(f'Multi-document YAML detected in {configmapname}, processing all documents')
                pathslist = []
                documents = yaml.safe_load_all(v)
                for doc_index, yamlfile in enumerate(documents):
                    if yamlfile is not None:  # Skip empty documents
                        doc_pathslist = await LoopYamlFile(yamlfile, looptimes=0)
                        pathslist.extend(doc_pathslist)
            except (yaml.composer.ComposerError, yaml.scanner.ScannerError, yaml.parser.ParserError):
                try:
                    v_clean = v.replace('\t', '    ') 
                    yamlfile = yaml.safe_load(v_clean)
                    pathslist = await LoopYamlFile(yamlfile, looptimes=0)
                except (yaml.composer.ComposerError, yaml.scanner.ScannerError):
                    logger.error(f'[ERROR] - Failed to parse YAML in configmap {configmapname} of {namespaceid}')
                    pathslist = []
        except (yaml.scanner.ScannerError, yaml.parser.ParserError):
            try:
                # Try to fix formatting issues
                v_clean = v.replace('\t', '    ')
                yamlfile = yaml.safe_load(v_clean)
                pathslist = await LoopYamlFile(yamlfile, looptimes=0)
            except (yaml.scanner.ScannerError, yaml.parser.ParserError):
                logger.error(f'[ERROR] - YAML scanner error in configmap {configmapname} of {namespaceid}')
                pathslist = []
    elif k.endswith("json"):
        logger.debug(f'Checking json file of configmap {configmapname} of {namespaceid}')
        try:
            jsonfile = json.loads(v)
            pathslist = await LoopJsonFile(jsonfile)
        except json.decoder.JSONDecodeError:
            try:
                logger.error('There was an error loading the json file. Fixed')
                v = v.replace('\ufeff','')
                jsonfile = json.loads(v)
                pathslist = await LoopJsonFile(jsonfile)
            except json.decoder.JSONDecodeError:
                logger.error(f'Another json.decoder.JSONDecodeError exception with file {k}')
                pathslist = []
            except Exception as e:
                logger.error(f'Exception {e} loading de json file {k}')
                pathslist = []            
    elif k.endswith("properties"):
        logger.debug(f'Checking properties file of configmap {configmapname} of {namespaceid}')
        pathslist = await LoopPropertiesFile(k,v)
    elif k.endswith("conf"):
        logger.debug(f'Checking conf file of configmap {configmapname} of {namespaceid}')
        pathslist = await LoopConfFile(k,v)
    else:
        logger.debug(f'Checking text string of configmap {configmapname} of {namespaceid}')
        pathslist = await LoopText(k,v)

    logger.debug(f'Pathslist of {configmapname} of {namespaceid}: {pathslist}')

    return {"file": k, "pathslist": pathslist}

async def createConfigMapsDict(configmap, namespaceinfo):

    URL_PATTERNS = os.getenv("URL_PATTERNS").split(",")
    datalist = []
    
    try:
        labels = configmap["metadata"]["labels"]
    except KeyError:
        labels = None

    configmapname = configmap["metadata"]["name"]

    configmapsdict = {
        "name": configmapname,
        "labels": labels,
        "creationTimestamp": configmap["metadata"]["creationTimestamp"]
    }

    try:
        configmapdata = configmap['data']
    except KeyError:
        try:
            configmapdata = configmap['binaryData']
        except KeyError:
            configmapdata = None
    except:
        configmapdata = None

    pathslist = []
    if configmapdata != None:
        for k,v in configmapdata.items():
            logger.debug(f'Checking {k} data on configmap {configmapname} of {namespaceinfo["namespaceid"]}')
            datalist.append({k: v})
            if any(pattern in str(v) for pattern in URL_PATTERNS):
            #if "http" in str(v) or "https" in str(v):
                logger.debug(f'Configmap{configmapname} of {namespaceinfo["namespaceid"]} has url in it')
                pathslist.append(await Loopfile(k,v,configmapname,namespaceinfo["namespaceid"]))
                
    else:
        datalist = None

    configmapsdict.update({"data": datalist})
    configmapsdict.update({"pathslist": pathslist})
    configmapsdict.update(namespaceinfo)

    return configmapsdict


async def checkDeleteKeys(micro_dict,mongomicroforcomparison):
    deletedkeys = []
    for key in micro_dict.keys():
        if key not in str(mongomicroforcomparison.keys()):
            deletedkeys.append(key)
    
    deletedkeys2 = [key for key in micro_dict.keys() if key not in str(mongomicroforcomparison.keys())]

    return deletedkeys, deletedkeys2

async def updateMongoData(id,collection,datakey,datavalue,action=None):

    logger.info(f'Changing to mongo collection  {collection} to update info')
    mg.change_collection(collection=collection)

    if action == "unset":
        updatedData = mg.update_one({'id': id},
                                        {"$unset": {datakey: ""}})
    else:
        if datakey==None:
            updatedData = mg.update_one({'id': id},
                                        {"$set": datavalue})
        else:
            updatedData = mg.update_one({'id': id},
                                        {"$set": {datakey: datavalue}})
        
    if updatedData.modified_count == 1:
        logger.info(f'{id} updated')
        mg.update_one({'id': id}, {"$set": {"timestamp": datetime.utcnow()}})
        return True
    else:
        logger.info(f'{id} was not updated')
        return False
    
async def compareLists(openshiftinfo,mongoinfo):
    differencesFlag = False
    
    for index,openshiftelem in enumerate(openshiftinfo):
        if openshiftelem != mongoinfo[index]:
            differencesFlag = True
    
    return differencesFlag

async def compareInfo(openshiftvalues,mongovalues):
    
    differencesFlag = False

    if type(openshiftvalues) == list and type(mongovalues) == list:
        if len(openshiftvalues) != len(mongovalues):
            differencesFlag = True
        else:
            differencesFlag = await compareLists(openshiftvalues,mongovalues)
    
    else:
        #await compareDicts(openshiftvalues,mongovalues)

        if openshiftvalues != None and mongovalues != None:
            #ordeno las claves primero.
            openshiftvalueskeyssorted = sorted(openshiftvalues)
            mongovalueskeyssorted = sorted(mongovalues)

            openshiftvaluessorted = {key: openshiftvalues[key] for key in openshiftvalueskeyssorted}
            mongovaluessorted = {key: mongovalues[key] for key in mongovalueskeyssorted}

            for item1,item2 in zip(openshiftvaluessorted,mongovaluessorted):
                if openshiftvaluessorted[item1] != mongovaluessorted[item2]:
                    differencesFlag = True
                    break
        elif openshiftvalues == None and mongovalues == None:
        # mongovalues != None:
            differencesFlag = False
        else:
            differencesFlag = True
    
    return differencesFlag 

async def createDictOrchestrator(ksobject, ksobjectelem, namespaceinfo):
    match ksobject:
        case "services":
            dictionary = await createServicesDict(ksobjectelem, namespaceinfo)
        case "replicationcontrollers":
            dictionary = await createRepliContrDict(ksobjectelem, namespaceinfo)
        case "replicasets":
            dictionary = await createReplicaSetsDict(ksobjectelem, namespaceinfo)
        case "configmaps":
            dictionary = await createConfigMapsDict(ksobjectelem, namespaceinfo)
        case "hpas":
            dictionary = await createHPAsDict(ksobjectelem, namespaceinfo)
    
    return dictionary

async def updateMongoInfo(cluster,region,namespace,namespaceinfo,commonobjectid,collection,ksobject,ksobject_list):

    mg.change_collection(collection=collection)
    mongosdocs = mg.find({"namespaceid": commonobjectid})
    mongoidslist = [object["id"] for object in mongosdocs]

    for ksobjectelem in ksobject_list:
        info = await createDictOrchestrator(ksobject, ksobjectelem, namespaceinfo)
        id = cluster+"-"+region+"-"+namespace+"-"+ksobjectelem["metadata"]["name"]
        info.update({"id": id})

        mg.change_collection(collection=collection)
        if id not in mongoidslist:
            mg.add_data(info)
        else:
            logger.info(f'Checking changes in kubernetes object {ksobjectelem["metadata"]["name"]} ({ksobject})')
            valueschangedflag = False
            mongoupdated = False
            mongoobject = mg.find_one({"id": id})
            mongoinfoforcomparison = mongoobject.copy()
            del mongoinfoforcomparison["_id"]
            del mongoinfoforcomparison["timestamp"]
            valueschangedflag = await compareInfo(info,mongoinfoforcomparison)
            if valueschangedflag:
                mongoupdated = await updateMongoData(id=mongoobject["id"],collection=collection,datakey=None,datavalue=info)
            
            if mongoupdated == True:
                logger.info(f'Mongo updated')

    return ksobject_list