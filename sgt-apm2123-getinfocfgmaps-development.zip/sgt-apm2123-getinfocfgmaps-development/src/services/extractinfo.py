from shuttlelib.utils.logger import logger
import time
import aiohttp
import shuttlelib.db.mongo as mongolib
import aiohttp
import os
from src.services.commonfunctions import getNamespaceObjects, updateMongoInfo, deleteMongoObject
from src.services.client import client

mg = mongolib.MongoClient()

async def get_info_config_maps(entity_id="spain",functional_environment="pro",clusterparam=None,regionparam=None,namespaceslist=None):

    t1 = time.time()
    namespaceListExcepted = os.getenv("NAMESPACES_EXCEPTED_LIST").split(",")
    mongocollection = os.getenv("COLLECTION")

    mongodata = mg.find({})

    mongo_namespacesids = [element["namespaceid"] for element in mongodata]
    openshift_namespacesid = []

    #if entity_id != "spain":
        #client.change_entity(entity_id=entity_id)

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)
    
    if clusterparam != None:
        clusterslist = [clusterparam]
    else:
        clusterslist = list(clusters.keys())

    for cluster in clusterslist:
        
        if regionparam != None:
            regionlist = [regionparam]
        else:
            regionlist = list(clusters[cluster].keys())

        for region in regionlist:

            try:
                namespaces = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
                if namespaces[region] == 401:
                    continue
            except aiohttp.client_exceptions.ServerTimeoutError:
                logger.error(f"Timeout detected against {functional_environment+cluster+region} ")
                continue
            except Exception as e:
                logger.error(f"An error ocurred getting namespaces: {e}")
                continue

            if namespaces != []:
                namespacesdictlist = namespaces[region]["items"]
            else:
                namespacesdictlist = []

            for namespacedict in namespacesdictlist:

                namespace = namespacedict["metadata"]["name"]

                if namespaceslist != None:
                    if namespace not in namespaceslist:
                        continue
                            
                if any(ns in namespace for ns in namespaceListExcepted):
                    #namespace.startswith("sanes-zzz") or namespace.startswith("sanes-autoz"):
                    continue

                namespaceid = cluster+"-"+region+"-"+namespace
                openshift_namespacesid.append(namespaceid) #For comparing to mongo info and drop mongo object if project doesn't exist anymore
                logger.info(f'[INFO] - Getting info of {namespaceid}')

                namespaceinfo = {
                    "cluster": cluster,
                    "region": region,
                    "namespace": namespace,
                    "namespaceid": namespaceid,
                }
                
                configmaps = await getNamespaceObjects(functional_environment,cluster,region,namespace,resource='configmaps')

                mongo_configmaps = mg.find({"namespaceid": namespaceid})
                mmongo_configmaps_list = [f'{mongo_configmap["id"]}' for mongo_configmap in mongo_configmaps]
                
                await deleteMongoObject(cluster,region,namespace,mmongo_configmaps_list,configmaps)

                if configmaps != []:
                    await updateMongoInfo(cluster=cluster,region=region,namespace=namespace,namespaceinfo=namespaceinfo,commonobjectid=namespaceid,collection=mongocollection,ksobject='configmaps',ksobject_list=configmaps)

    if clusterparam == None and regionparam == None and namespaceslist == None:
        for id in mongo_namespacesids:
            if id not in openshift_namespacesid:
                mg.delete_one({"namespaceid": id})

    t2 = time.time()
    totalTime = t2-t1

    logger.info(f'Total time: {totalTime}')
