from src.app.config.composer_config import config
from fastapi import FastAPI
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers

description = """
##GET CONFIG MAPS INFO

### SUMMARY
Microservice for getting configmaps info and save it in mongoDB:

### ENDPOINTS
* **/extractinfo/configmaps:** get all the configmaps info from every cluster and namespace

### PARAMETERS
For getting or updating the info:
* **entity_id**: spain, xxxxxx
* **functional_environment**: dev, pre, pro
* **cluster (optional)**: ohe (only for dev & pre), bks (only for dev & pre), probks, dmzbbks, dmzbazure, azure, prodarwin, dmzbdarwin, confluent
* **region (optional)**: bo1, bo2, weu1, weu2
* **namespaceslist (optional)**: list of namespaces to get and update (it should be on the selected cluster)


### REPO 
* [sgt-apm2123-getinfocfgmaps](https://github.com/santander-group-sds-gln/sgt-apm2123-getinfocfgmaps)
"""

app = FastAPI(
                docs_url="/api/v1/docs",
                title="sgt-apm2123-getinfocfgmaps",
                description = description,
                version="1.0",
                openapi_url="/api/v1/openapi.json",
                contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"},
              )

DarwinComposer(app, config=config, routers=routers)