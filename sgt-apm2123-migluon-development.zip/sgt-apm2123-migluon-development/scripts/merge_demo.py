#!/usr/bin/env python3
"""
Demo y guía de uso de los resolvers de merge automático.
Muestra cómo usar las herramientas creadas basadas en la investigación profunda.
"""

import sys
from pathlib import Path

# Añadir el directorio scripts al path para importar
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

try:
    from auto_merge_resolver import AutoMergeResolver
    from gluon_merge_resolver import GluonMergeResolver
except ImportError as e:
    print(f"❌ Error importando resolvers: {e}")
    sys.exit(1)


def demo_usage():
    """Muestra ejemplos de uso de los resolvers."""
    print("🚀 DEMO: Resolvers de Merge Automático")
    print("=" * 50)
    print()
    
    print("📋 HERRAMIENTAS DISPONIBLES:")
    print("1. AutoMergeResolver - Resolver general para cualquier repositorio")
    print("2. GluonMergeResolver - Especializado para archivos .gluon/cd/*.yml")
    print()
    
    print("💡 CASOS DE USO TÍPICOS:")
    print()
    
    print("🔧 Caso 1: Merge con conflictos en archivos Gluon")
    print("   python scripts/gluon_merge_resolver.py main")
    print("   python scripts/gluon_merge_resolver.py origin/develop --summary")
    print()
    
    print("🔧 Caso 2: Merge general con estrategias avanzadas")
    print("   python scripts/auto_merge_resolver.py main --strategy auto")
    print("   python scripts/auto_merge_resolver.py feature/branch --strategy x-theirs")
    print("   python scripts/auto_merge_resolver.py main --strategy pladijs --verify")
    print()
    
    print("📊 ESTRATEGIAS IMPLEMENTADAS:")
    print("- 🎯 x-theirs: Resuelve conflictos favoreciendo rama origen (MÁS USADA)")
    print("- 🔄 checkout: Merge + checkout --theirs archivo por archivo")
    print("- ⚡ pladijs: Método avanzado equivalente a 'git merge -s theirs'")
    print("- 🤖 auto: Prueba estrategias automáticamente hasta encontrar una que funcione")
    print()
    
    print("⚠️ ARCHIVOS MONITOREADOS (Gluon):")
    for file in GluonMergeResolver.GLUON_CONFIG_FILES:
        print(f"   - {file}")
    print()


def interactive_demo():
    """Demo interactivo para probar los resolvers."""
    print("🎮 MODO INTERACTIVO")
    print("=" * 30)
    
    # Detectar si estamos en un repo git
    resolver = AutoMergeResolver()
    result = resolver.run_git_command(['status', '--porcelain'])
    
    if not result[0] == 0:
        print("❌ No estás en un repositorio Git válido")
        print("💡 Navega a tu repositorio y ejecuta de nuevo")
        return
    
    # Obtener rama actual
    current_result = resolver.run_git_command(['branch', '--show-current'])
    current_branch = current_result[1] if current_result[0] == 0 else "unknown"
    
    print(f"📍 Repositorio: {Path.cwd().name}")
    print(f"🌿 Rama actual: {current_branch}")
    print()
    
    # Mostrar ramas disponibles
    branches_result = resolver.run_git_command(['branch', '-a'])
    if branches_result[0] == 0:
        print("🌳 Ramas disponibles:")
        for line in branches_result[1].split('\n'):
            if line.strip() and not line.strip().startswith('*'):
                branch = line.strip().replace('remotes/', '')
                print(f"   - {branch}")
        print()
    
    # Solicitar rama a mergear
    try:
        source_branch = input("🔀 ¿Qué rama quieres mergear? (ej: main, origin/develop): ").strip()
        
        if not source_branch:
            print("❌ No se proporcionó rama")
            return
        
        print(f"\n🎯 Seleccionaste: {source_branch}")
        
        # Preguntar si usar resolver específico para Gluon
        use_gluon = input("🔧 ¿Usar resolver específico para archivos Gluon? (Y/n): ").strip().lower()
        
        if use_gluon in ['', 'y', 'yes', 'sí', 'si']:
            print("\n🚀 Usando GluonMergeResolver...")
            gluon_resolver = GluonMergeResolver()
            success = gluon_resolver.resolve_gluon_merge(source_branch, "theirs")
            
            if success:
                gluon_resolver.show_merge_summary(source_branch)
            
        else:
            print("\n🚀 Usando AutoMergeResolver...")
            strategy = input("📋 ¿Estrategia? (auto/x-theirs/checkout/pladijs) [auto]: ").strip() or "auto"
            
            success = resolver.auto_resolve_merge(source_branch, strategy)
            
            if success:
                verify = input("\n🔍 ¿Verificar merge? (Y/n): ").strip().lower()
                if verify in ['', 'y', 'yes', 'sí', 'si']:
                    resolver.verify_merge(source_branch)
        
        print("\n🎉 Demo completado!")
        
    except KeyboardInterrupt:
        print("\n\n⏹️ Demo cancelado por el usuario")
    except Exception as e:
        print(f"\n💥 Error en demo: {e}")


def main():
    """Función principal del demo."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Demo de resolvers de merge automático",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '--interactive',
        action='store_true',
        help='Ejecutar demo interactivo'
    )
    
    args = parser.parse_args()
    
    if args.interactive:
        interactive_demo()
    else:
        demo_usage()


if __name__ == "__main__":
    main()