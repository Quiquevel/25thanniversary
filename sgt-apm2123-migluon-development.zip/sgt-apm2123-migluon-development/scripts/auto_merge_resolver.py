#!/usr/bin/env python3
"""
Automatizador de resolución de conflictos de merge
Implementa las estrategias encontradas en la investigación profunda para resolver
automáticamente conflictos al mergear ramas.

Autor: Migluon System
Fecha: 25 de septiembre de 2025
"""

import subprocess
import sys
import os
from pathlib import Path
from typing import List, Tuple, Optional


class AutoMergeResolver:
    """Resuelve automáticamente conflictos de merge usando estrategias probadas."""
    
    def __init__(self, repo_path: Optional[str] = None):
        """
        Inicializa el resolver de conflictos.
        
        Args:
            repo_path: Ruta al repositorio. Si es None, usa el directorio actual.
        """
        self.repo_path = Path(repo_path) if repo_path else Path.cwd()
        self.conflicted_files = []
        
    def run_git_command(self, command: List[str]) -> Tuple[int, str, str]:
        """
        Ejecuta un comando git y retorna el resultado.
        
        Args:
            command: Lista con el comando git a ejecutar
            
        Returns:
            Tupla con (código_retorno, stdout, stderr)
        """
        try:
            result = subprocess.run(
                ['git'] + command,
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            return result.returncode, result.stdout.strip(), result.stderr.strip()
        except subprocess.TimeoutExpired:
            return 1, "", "Timeout executing git command"
        except Exception as e:
            return 1, "", str(e)
    
    def get_conflicted_files(self) -> List[str]:
        """
        Obtiene la lista de archivos en conflicto.
        
        Returns:
            Lista de rutas de archivos con conflictos
        """
        code, stdout, _ = self.run_git_command(['diff', '--name-only', '--diff-filter=U'])
        if code == 0 and stdout:
            self.conflicted_files = stdout.split('\n')
            return self.conflicted_files
        return []
    
    def strategy_x_theirs(self, source_branch: str) -> bool:
        """
        Estrategia 1: Usa -X theirs para resolver conflictos.
        Más común y recomendada por la comunidad.
        
        Args:
            source_branch: Rama de origen a mergear
            
        Returns:
            True si el merge fue exitoso, False si hubo conflictos
        """
        print(f"🔄 Intentando merge con estrategia -X theirs desde {source_branch}")
        
        code, stdout, stderr = self.run_git_command(['merge', '-X', 'theirs', source_branch])
        
        if code == 0:
            print("✅ Merge exitoso con estrategia -X theirs")
            return True
        else:
            print(f"❌ Merge falló: {stderr}")
            # Abortar el merge fallido para intentar otra estrategia
            self.run_git_command(['merge', '--abort'])
            return False
    
    def strategy_checkout_theirs(self, source_branch: str) -> bool:
        """
        Estrategia 2: Merge normal + checkout --theirs para cada archivo conflictivo.
        
        Args:
            source_branch: Rama de origen a mergear
            
        Returns:
            True si la resolución fue exitosa
        """
        print(f"🔄 Intentando merge normal desde {source_branch}")
        
        # Intentar merge normal
        code, stdout, stderr = self.run_git_command(['merge', source_branch])
        
        if code == 0:
            print("✅ Merge exitoso sin conflictos")
            return True
        
        # Si hay conflictos, resolverlos individualmente
        print("⚠️ Detectados conflictos, resolviendo con --theirs")
        conflicted = self.get_conflicted_files()
        
        if not conflicted:
            print("❌ No se pudieron detectar archivos en conflicto")
            return False
        
        print(f"📁 Archivos en conflicto encontrados: {len(conflicted)}")
        for file in conflicted:
            print(f"  - {file}")
        
        # Resolver cada archivo usando 'theirs'
        success_count = 0
        for file in conflicted:
            code, _, stderr = self.run_git_command(['checkout', '--theirs', file])
            if code == 0:
                success_count += 1
                print(f"✅ Resuelto: {file}")
            else:
                print(f"❌ Error resolviendo {file}: {stderr}")
        
        if success_count == len(conflicted):
            # Agregar archivos resueltos y hacer commit
            self.run_git_command(['add', '.'])
            code, _, stderr = self.run_git_command([
                'commit', 
                '-m', 
                f'Merge resolved favoring {source_branch} (auto-resolved {success_count} conflicts)'
            ])
            
            if code == 0:
                print(f"✅ Merge completado exitosamente con {success_count} conflictos resueltos")
                return True
            else:
                print(f"❌ Error haciendo commit: {stderr}")
                return False
        else:
            print(f"❌ Solo se resolvieron {success_count} de {len(conflicted)} conflictos")
            return False
    
    def strategy_paul_pladijs(self, source_branch: str) -> bool:
        """
        Estrategia 3: Método de Paul Pladijs - equivalente a "git merge -s theirs"
        Para casos donde necesitas contenido exacto de la rama origen.
        
        Args:
            source_branch: Rama de origen a mergear
            
        Returns:
            True si la operación fue exitosa
        """
        print(f"🔄 Aplicando estrategia Paul Pladijs desde {source_branch}")
        
        try:
            # Paso 1: Merge con estrategia 'ours' (sin conflictos)
            code, _, stderr = self.run_git_command(['merge', '-s', 'ours', source_branch])
            if code != 0:
                print(f"❌ Error en merge -s ours: {stderr}")
                return False
            
            # Paso 2: Crear branch temporal
            temp_branch = f"temp_theirs_{source_branch.replace('/', '_')}"
            code, _, stderr = self.run_git_command(['branch', temp_branch])
            if code != 0:
                print(f"❌ Error creando branch temporal: {stderr}")
                return False
            
            # Paso 3: Reset hard a source_branch (obtener contenido)
            code, _, stderr = self.run_git_command(['reset', '--hard', source_branch])
            if code != 0:
                print(f"❌ Error en reset --hard: {stderr}")
                return False
            
            # Paso 4: Reset soft a temp branch (mantener merge commit)
            code, _, stderr = self.run_git_command(['reset', '--soft', temp_branch])
            if code != 0:
                print(f"❌ Error en reset --soft: {stderr}")
                return False
            
            # Paso 5: Amend commit para actualizar contenido
            code, _, stderr = self.run_git_command(['commit', '--amend', '--no-edit'])
            if code != 0:
                print(f"❌ Error en commit --amend: {stderr}")
                return False
            
            # Paso 6: Limpiar branch temporal
            code, _, stderr = self.run_git_command(['branch', '-D', temp_branch])
            if code != 0:
                print(f"⚠️ Warning: No se pudo eliminar branch temporal: {stderr}")
            
            print("✅ Merge Paul Pladijs completado exitosamente")
            return True
            
        except Exception as e:
            print(f"❌ Error en estrategia Paul Pladijs: {e}")
            return False
    
    def auto_resolve_merge(self, source_branch: str, strategy: str = "auto") -> bool:
        """
        Resuelve automáticamente conflictos de merge usando la mejor estrategia.
        
        Args:
            source_branch: Rama de origen a mergear
            strategy: Estrategia a usar ("auto", "x-theirs", "checkout", "pladijs")
            
        Returns:
            True si el merge fue exitoso
        """
        print(f"🚀 Iniciando resolución automática de merge")
        print(f"   Rama origen: {source_branch}")
        print(f"   Estrategia: {strategy}")
        print()
        
        # Verificar estado del repositorio
        code, stdout, stderr = self.run_git_command(['status', '--porcelain'])
        if code == 0 and stdout:
            print("⚠️ Hay cambios sin commitear. Recomendable hacer stash primero.")
            response = input("¿Continuar anyway? (y/N): ").strip().lower()
            if response != 'y':
                print("❌ Operación cancelada por el usuario")
                return False
        
        if strategy == "auto":
            # Probar estrategias en orden de preferencia
            strategies = [
                ("x-theirs", self.strategy_x_theirs),
                ("checkout", self.strategy_checkout_theirs),
                ("pladijs", self.strategy_paul_pladijs)
            ]
            
            for name, func in strategies:
                print(f"\n🔍 Probando estrategia: {name}")
                if func(source_branch):
                    return True
                print(f"   Estrategia {name} no fue exitosa, probando siguiente...")
            
            print("❌ Todas las estrategias fallaron")
            return False
        
        elif strategy == "x-theirs":
            return self.strategy_x_theirs(source_branch)
        elif strategy == "checkout":
            return self.strategy_checkout_theirs(source_branch)
        elif strategy == "pladijs":
            return self.strategy_paul_pladijs(source_branch)
        else:
            print(f"❌ Estrategia desconocida: {strategy}")
            return False
    
    def verify_merge(self, source_branch: str) -> bool:
        """
        Verifica que el merge se hizo correctamente.
        
        Args:
            source_branch: Rama origen que se mergeó
            
        Returns:
            True si la verificación es exitosa
        """
        print(f"\n🔍 Verificando merge con {source_branch}")
        
        # Verificar que no hay diferencias con la rama origen
        code, stdout, stderr = self.run_git_command(['diff', 'HEAD', source_branch])
        
        if code == 0 and not stdout:
            print("✅ Verificación exitosa: contenido idéntico a rama origen")
            return True
        elif code == 0:
            print(f"⚠️ Hay {len(stdout.split('\\n'))} líneas de diferencia")
            print("   Esto puede ser normal dependiendo de la estrategia usada")
            return True
        else:
            print(f"❌ Error en verificación: {stderr}")
            return False


def main():
    """Función principal del script."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Automatizador de resolución de conflictos de merge",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:
  python auto_merge_resolver.py main
  python auto_merge_resolver.py origin/develop --strategy x-theirs
  python auto_merge_resolver.py feature/new-feature --strategy auto
        """
    )
    
    parser.add_argument(
        'source_branch',
        help='Rama de origen a mergear (ej: main, origin/develop, feature/xyz)'
    )
    
    parser.add_argument(
        '--strategy',
        choices=['auto', 'x-theirs', 'checkout', 'pladijs'],
        default='auto',
        help='Estrategia de resolución a usar (default: auto)'
    )
    
    parser.add_argument(
        '--repo-path',
        help='Ruta al repositorio (default: directorio actual)'
    )
    
    parser.add_argument(
        '--verify',
        action='store_true',
        help='Verificar merge después de completarlo'
    )
    
    args = parser.parse_args()
    
    # Crear resolver
    resolver = AutoMergeResolver(args.repo_path)
    
    # Ejecutar merge
    success = resolver.auto_resolve_merge(args.source_branch, args.strategy)
    
    if success and args.verify:
        resolver.verify_merge(args.source_branch)
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()