#!/usr/bin/env python3
"""
Resolver específico para conflictos en archivos de configuración Gluon.
Automatiza la resolución de conflictos para:
- .gluon/cd/cert/cd.yml
- .gluon/cd/pre/cd.yml  
- .gluon/cd/pro/cd.yml
- .gluon/cd/values.yaml
- Dockerfile
- deployment-backup.yaml

Basado en la investigación profunda de estrategias de merge automático.
"""

import subprocess
import sys
from pathlib import Path
from typing import List, Dict, Optional


class GluonMergeResolver:
    """Resolver específico para archivos de configuración Gluon CD."""
    
    # Archivos típicamente en conflicto en proyectos Gluon
    GLUON_CONFIG_FILES = [
        '.gluon/cd/cert/cd.yml',
        '.gluon/cd/pre/cd.yml',
        '.gluon/cd/pro/cd.yml',
        '.gluon/cd/values.yaml',
        'Dockerfile',
        'deployment-backup.yaml'
    ]
    
    def __init__(self):
        self.repo_path = Path.cwd()
        
    def run_git_command(self, command: List[str], capture_output: bool = True) -> Dict:
        """Ejecuta comando git y retorna resultado estructurado."""
        try:
            result = subprocess.run(
                ['git'] + command,
                cwd=self.repo_path,
                capture_output=capture_output,
                text=True,
                timeout=30
            )
            return {
                'success': result.returncode == 0,
                'code': result.returncode,
                'stdout': result.stdout.strip() if capture_output else '',
                'stderr': result.stderr.strip() if capture_output else '',
                'command': ' '.join(['git'] + command)
            }
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'code': 1,
                'stdout': '',
                'stderr': 'Command timeout',
                'command': ' '.join(['git'] + command)
            }
        except Exception as e:
            return {
                'success': False,
                'code': 1,
                'stdout': '',
                'stderr': str(e),
                'command': ' '.join(['git'] + command)
            }
    
    def get_current_branch(self) -> Optional[str]:
        """Obtiene la rama actual."""
        result = self.run_git_command(['branch', '--show-current'])
        return result['stdout'] if result['success'] else None
    
    def check_conflicted_files(self) -> List[str]:
        """Identifica archivos en conflicto, priorizando archivos Gluon."""
        result = self.run_git_command(['diff', '--name-only', '--diff-filter=U'])
        if not result['success']:
            return []
        
        all_conflicts = result['stdout'].split('\n') if result['stdout'] else []
        
        # Separar conflictos en Gluon vs otros
        gluon_conflicts = []
        other_conflicts = []
        
        for file in all_conflicts:
            if any(gluon_file in file for gluon_file in self.GLUON_CONFIG_FILES):
                gluon_conflicts.append(file)
            else:
                other_conflicts.append(file)
        
        return gluon_conflicts + other_conflicts
    
    def resolve_gluon_merge(self, source_branch: str, force_strategy: str = "theirs") -> bool:
        """
        Resuelve merge de rama con conflictos en archivos Gluon.
        
        Args:
            source_branch: Rama a mergear
            force_strategy: "theirs" (usar archivos de la rama origen) o "ours"
            
        Returns:
            True si el merge fue exitoso
        """
        current_branch = self.get_current_branch()
        print(f"🚀 Resolviendo merge: {current_branch} ← {source_branch}")
        print(f"📋 Estrategia: Usar versión '{force_strategy}' para conflictos")
        print()
        
        # Paso 1: Intentar merge con estrategia -X
        print("🔄 Paso 1: Intentando merge automático con -X theirs")
        merge_result = self.run_git_command(['merge', '-X', force_strategy, source_branch])
        
        if merge_result['success']:
            print("✅ Merge exitoso sin conflictos manuales!")
            return True
        
        print("⚠️ Merge con conflictos detectados")
        print(f"   Error: {merge_result['stderr']}")
        
        # Paso 2: Abortar merge fallido y intentar resolución manual
        print("\n🔄 Paso 2: Abortando merge y resolviendo manualmente")
        abort_result = self.run_git_command(['merge', '--abort'])
        if not abort_result['success']:
            print(f"❌ No se pudo abortar el merge: {abort_result['stderr']}")
            return False
        
        # Paso 3: Merge normal para identificar conflictos
        print("🔄 Paso 3: Iniciando merge para identificar conflictos")
        merge_result = self.run_git_command(['merge', '--no-commit', source_branch])
        
        # Paso 4: Identificar archivos en conflicto
        conflicted_files = self.check_conflicted_files()
        
        if not conflicted_files:
            print("✅ No se encontraron conflictos, completando merge")
            commit_result = self.run_git_command(['commit', '--no-edit'])
            return commit_result['success']
        
        print(f"📁 Archivos en conflicto encontrados ({len(conflicted_files)}):")
        for file in conflicted_files:
            marker = "🔧" if any(gf in file for gf in self.GLUON_CONFIG_FILES) else "📄"
            print(f"   {marker} {file}")
        
        # Paso 5: Resolver cada archivo usando la estrategia especificada
        print(f"\n🔄 Paso 5: Resolviendo conflictos con --{force_strategy}")
        
        resolved_count = 0
        failed_files = []
        
        for file in conflicted_files:
            checkout_result = self.run_git_command(['checkout', f'--{force_strategy}', file])
            
            if checkout_result['success']:
                resolved_count += 1
                print(f"   ✅ {file}")
            else:
                failed_files.append(file)
                print(f"   ❌ {file} - Error: {checkout_result['stderr']}")
        
        if failed_files:
            print(f"\n❌ {len(failed_files)} archivos no pudieron resolverse:")
            for file in failed_files:
                print(f"   - {file}")
            return False
        
        # Paso 6: Agregar archivos resueltos y hacer commit
        print(f"\n🔄 Paso 6: Agregando {resolved_count} archivos resueltos")
        add_result = self.run_git_command(['add', '.'])
        
        if not add_result['success']:
            print(f"❌ Error agregando archivos: {add_result['stderr']}")
            return False
        
        # Commit final
        commit_msg = f"Merge {source_branch} into {current_branch}\n\n" \
                    f"Auto-resolved {resolved_count} conflicts using '{force_strategy}' strategy:\n"
        
        for file in conflicted_files:
            commit_msg += f"- {file}\n"
        
        commit_result = self.run_git_command(['commit', '-m', commit_msg])
        
        if commit_result['success']:
            print(f"✅ Merge completado exitosamente!")
            print(f"   Archivos resueltos: {resolved_count}")
            print(f"   Estrategia aplicada: {force_strategy}")
            return True
        else:
            print(f"❌ Error en commit final: {commit_result['stderr']}")
            return False
    
    def show_merge_summary(self, source_branch: str) -> None:
        """Muestra resumen del merge realizado."""
        print("\n" + "="*50)
        print("📊 RESUMEN DEL MERGE")
        print("="*50)
        
        # Mostrar último commit (el merge)
        log_result = self.run_git_command(['log', '-1', '--oneline'])
        if log_result['success']:
            print(f"Último commit: {log_result['stdout']}")
        
        # Mostrar archivos modificados
        diff_result = self.run_git_command(['diff', '--name-only', 'HEAD~1', 'HEAD'])
        if diff_result['success'] and diff_result['stdout']:
            files = diff_result['stdout'].split('\n')
            print(f"\nArchivos modificados ({len(files)}):")
            for file in files:
                marker = "🔧" if any(gf in file for gf in self.GLUON_CONFIG_FILES) else "📄"
                print(f"  {marker} {file}")
        
        # Verificación de integridad
        print(f"\n🔍 Verificando integridad del merge...")
        status_result = self.run_git_command(['status', '--porcelain'])
        
        if status_result['success'] and not status_result['stdout']:
            print("✅ Repositorio en estado limpio")
        else:
            print("⚠️ Hay cambios pendientes")
            
        print("\n🎉 Merge completado correctamente!")


def main():
    """Función principal."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Resolver automático para conflictos en archivos Gluon CD",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos de uso:
  python gluon_merge_resolver.py main
  python gluon_merge_resolver.py origin/develop
  python gluon_merge_resolver.py feature/config-updates --strategy ours
        """
    )
    
    parser.add_argument(
        'source_branch',
        help='Rama a mergear (ej: main, origin/develop)'
    )
    
    parser.add_argument(
        '--strategy',
        choices=['theirs', 'ours'],
        default='theirs',
        help='Estrategia para resolver conflictos (default: theirs)'
    )
    
    parser.add_argument(
        '--summary',
        action='store_true',
        help='Mostrar resumen detallado al finalizar'
    )
    
    args = parser.parse_args()
    
    # Crear resolver y ejecutar
    resolver = GluonMergeResolver()
    
    try:
        success = resolver.resolve_gluon_merge(args.source_branch, args.strategy)
        
        if success:
            if args.summary:
                resolver.show_merge_summary(args.source_branch)
            sys.exit(0)
        else:
            print("\n❌ El merge no pudo completarse automáticamente")
            print("💡 Posibles soluciones:")
            print("   1. Revisar conflictos manualmente con: git status")
            print("   2. Probar estrategia 'ours': --strategy ours")
            print("   3. Contactar al equipo para resolución manual")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\n\n⏹️ Operación cancelada por el usuario")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Error inesperado: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()