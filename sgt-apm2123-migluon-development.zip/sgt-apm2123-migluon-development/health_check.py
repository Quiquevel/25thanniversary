#!/usr/bin/env python3
"""
Basic health check script for MigLuon service startup.
This script can be optionally used for debugging container startup issues.
"""

import os
import sys
import importlib.util
from pathlib import Path

def check_environment():
    """Check basic environment setup."""
    print("=== ENVIRONMENT CHECK ===")
    print(f"Python version: {sys.version}")
    print(f"Current directory: {os.getcwd()}")
    print(f"PYTHONPATH: {os.environ.get('PYTHONPATH', 'Not set')}")
    print(f"Environment: {os.environ.get('ENVIRONMENT', 'Not set')}")
    print(f"Darwin AppKey: {os.environ.get('DARWIN_APPKEY', 'Not set')}")

def check_files():
    """Check required files exist."""
    print("\n=== FILE CHECK ===")
    required_files = [
        'asgi.py',
        'gunicorn_config.py',
        'src/app/main.py',
        'src/__init__.py'
    ]
    
    all_exist = True
    for file_path in required_files:
        if os.path.exists(file_path):
            print(f"✅ {file_path} - Found")
        else:
            print(f"❌ {file_path} - Missing")
            all_exist = False
    
    return all_exist

def check_imports():
    """Check critical imports."""
    print("\n=== IMPORT CHECK ===")
    try:
        from src.app.main import app
        print("✅ src.app.main.app - Import successful")
        return True
    except ImportError as e:
        print(f"❌ src.app.main.app - Import failed: {e}")
        return False

def main():
    """Run all health checks."""
    print("🏥 MigLuon Service Health Check")
    print("=" * 40)
    
    check_environment()
    files_ok = check_files()
    imports_ok = check_imports()
    
    print(f"\n=== SUMMARY ===")
    if files_ok and imports_ok:
        print("✅ All checks passed - Service should start normally")
        return 0
    else:
        print("❌ Some checks failed - Service may have startup issues")
        return 1

if __name__ == "__main__":
    sys.exit(main())