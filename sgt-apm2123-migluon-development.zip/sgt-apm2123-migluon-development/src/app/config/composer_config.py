from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "MiGluon",
          "description": """
# MICROSERVICIO PARA MIGRACION DE GLUON
- URL DOCUMENTACION: [BROWNFIELD DOC](https://sanes.atlassian.net/wiki/spaces/AIOPS/pages/26481165032/BROWNFIELD)
- URL PARA GENERAR TOKEN DE GITHUB.COM: [Crear token en GitHub](https://github.com/settings/tokens)

## PARAMETERS
- **appkey:** Nombre de aplicacion en GLUON
- **old_name:** Nombre del microservicio antiguo, para respetar el nombre al despelgar
- **registry_project:** Nombre de aplicacion en Harbor  
- **namespace:** Namespace de openshiftsin el subfijo -dev,-pre, -pro 
- **clusters:** Puede ser intranet, dmz, azure, movilidad, dependiendo de en qué clusters esté en openshift  
- **vault_token:** Token de Vault smanager.gluon.gs.corp  
- **entidad:** Por defecto es san, pero puede ser sfc, ssg,  ..., esto hace referencia a la entidad de GLUON, y en que ruta se va a guardar en VAULT.

## REPO
- [MiGluon](https://github.com/santander-group-sds-gln/sgt-apm2123-migluon)
          """,
          "contact": {
               "name": "DevSecOps Engineering",
               "url": "mailto:cristian.valinani@gruposantander.com"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
