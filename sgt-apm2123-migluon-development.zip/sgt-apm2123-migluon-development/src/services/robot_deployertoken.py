from src.services.robot import *
from src.services.despliegue_token import *
from src.services.vault import save_tokens_dict_in_vault, validate_vault_token
from src.models.gitmodel import *
from shuttlelib.utils.logger import logger

async def robot_deployertoken_service(
    entidad: str,
    registry_project: str,
    appkey: str,
    namespace: str,
    clusters: str,
    vault_token: str
):
    """
    Orquestador principal para el proceso de despliegue de tokens.
    """

    print("Ejecutando robot_deployertoken...")
    
    # 🔍 VALIDACIÓN CRÍTICA: Verificar token de Vault ANTES de crear nada
    print("🔐 Validando token de Vault...")
    vault_validation = validate_vault_token(vault_token)
    
    if not vault_validation.get("valid", False):
        error_msg = vault_validation.get("error", "Token de Vault inválido")
        print(f"❌ ERROR: {error_msg}")
        logger.error(f"❌ VALIDACIÓN VAULT FALLIDA: {error_msg}")
        
        # Retornar error inmediatamente sin crear nada
        return f"""❌ ERROR CRÍTICO: Token de Vault inválido

Detalle del error: {error_msg}

⚠️ No se ejecutaron operaciones para evitar crear recursos huérfanos.
⚠️ Verifique el token de Vault y vuelva a intentar.

Parámetros de la solicitud:
- Registry Project: {registry_project}
- AppKey: {appkey}
- Namespace: {namespace}
- Clusters: {clusters}"""

    print("✅ Token de Vault validado correctamente")
    logger.info("✅ Token de Vault validado - procediendo con la ejecución")
    result = await create_robot_accounts_by_env_type(
        registry_project=registry_project,
        appkey=appkey,
        clusters=clusters,
        vault_token=vault_token
    )

    service = DespliegueTokenService()
    tokens = await service.get_tokens_from_clusters({
        "cluster": clusters,
        "data": {
            env: {
                "cluster_ids": cluster_types.get(clusters, {}),
                "namespace": f"{namespace}-{env}"
            }
            for env, cluster_types in SHUTTLE_CLUSTERS.items()
        }
    })
    # Guardar los tokens en Vault y obtener los resultados (pasamos entidad)
    resultados_vault = await save_tokens_dict_in_vault(dict=tokens, vault_token=vault_token, appkey=appkey, entidad=entidad)

    # 🔍 VERIFICAR ERRORES EN VAULT - Tokens
    vault_errors = []
    vault_successes = []
    for ruta, estado in resultados_vault.items():
        if estado != "OK":
            vault_errors.append(f"Token error: {ruta} -> {estado}")
            logger.error(f"❌ VAULT TOKEN ERROR: {ruta} -> {estado}")
        else:
            vault_successes.append(ruta)
            logger.info(f"✅ VAULT TOKEN OK: {ruta}")

    # Formatear la respuesta estructurada
    env_map = {
        "dev": "certification",
        "pre": "preproduction",
        "pro": "production"
    }

    despliegue_status = []
    for env, value_path in env_map.items():
        regiones = SHUTTLE_CLUSTERS.get(env, {}).get(clusters, {}).keys()
        for region in regiones:
            # Lógica para cluster_value según entorno y cluster
            if clusters == "azure":
                cluster_value = "ocp05"
            elif value_path in ["certification", "preproduction"]:
                cluster_value = "san01bks"
            elif value_path == "production":
                if clusters in ["dmz", "movilidad"]:
                    cluster_value = "dmzb01darwin"
                elif clusters == "intranet":
                    cluster_value = "san01darwin"
                else:
                    cluster_value = "san01bks"
            else:
                cluster_value = "san01bks"

            secret_name = f"ohe_{region}_{cluster_value}_{namespace}-{env}_token"
            ruta_region = f"{entidad}/{appkey}/{value_path}/deployment/{secret_name}"
            estado_region = resultados_vault.get(ruta_region, "KO")
            despliegue_status.append({"environment": value_path, "region": region, "status": estado_region})

    # Construir dict de respuesta con detalles
    response = {
        "status": "success" if not vault_errors else "partial_failure",
        "deploy_status": despliegue_status,
        "robot_accounts_raw": result,
        "vault_results": resultados_vault,
        "vault_errors": vault_errors,
    }

    # Registrar si hay errores
    if vault_errors:
        logger.error(f"❌ PROCESO COMPLETADO CON ERRORES: {len(vault_errors)} errores en Vault")

    if isinstance(result, str) and ("error" in result.lower() or "ko" in result.lower()):
        logger.error(f"❌ ERRORES EN ROBOT ACCOUNTS: {result}")

    return response
