"""
Módulo de utilidades compartidas para los servicios.
Funciones comunes que se usan en múltiples módulos para evitar imports circulares.
"""
from shuttlelib.utils.logger import logger


def get_environment_suffix(env_name: str) -> str:
    """
    Extrae el sufijo específico del nombre del entorno para usar en component_name y applicationName.
    
    Args:
        env_name: Nombre del entorno (ej: 'pro-b-test', 'pro-g-test', 'pro-b', 'pro-g')
        
    Returns:
        str: Sufijo del entorno (ej: '-b-test', '-g-test', '-b', '-g')
    """
    if env_name in ['pro-b-test', 'pro-g-test', 'pro-b', 'pro-g']:
        # Extraer el sufijo después de 'pro'
        suffix = env_name[3:]  # Quita 'pro' del inicio
        return suffix
    else:
        # Para otros entornos, no añadir sufijo
        return ""