"""
Módulo para el procesamiento y manipulación de archivos YAML.
"""
import logging
from typing import Dict, Any, Optional, Union
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap

logger = logging.getLogger(__name__)

class YAMLProcessor:
    def __init__(self):
        self.yaml = YAML()
        self.yaml.preserve_quotes = True
        self.yaml.indent(mapping=2, sequence=4, offset=2)
        
    def load_yaml(self, content: str) -> Optional[CommentedMap]:
        """
        Carga un string YAML manteniendo comentarios y formato.
        
        Args:
            content: Contenido YAML en string
            
        Returns:
            Optional[CommentedMap]: Datos YAML o None si hay error
        """
        try:
            return self.yaml.load(content)
        except Exception as e:
            logger.error(f"Error al cargar YAML: {str(e)}")
            return None
            
    def dump_yaml(self, data: Union[Dict, CommentedMap]) -> Optional[str]:
        """
        Convierte datos a string YAML manteniendo formato.
        
        Args:
            data: Datos a convertir
            
        Returns:
            Optional[str]: String YAML o None si hay error
        """
        try:
            from io import StringIO
            stream = StringIO()
            self.yaml.dump(data, stream)
            return stream.getvalue()
        except Exception as e:
            logger.error(f"Error al convertir a YAML: {str(e)}")
            return None
            
    def update_yaml_value(self, data: CommentedMap, path: str, value: Any) -> bool:
        """
        Actualiza un valor en el YAML usando una ruta de puntos.
        
        Args:
            data: Datos YAML
            path: Ruta de claves separadas por puntos (ej: "spec.template.metadata.name")
            value: Nuevo valor
            
        Returns:
            bool: True si se actualizó correctamente
        """
        try:
            current = data
            parts = path.split(".")
            
            # Navegar hasta el penúltimo elemento
            for part in parts[:-1]:
                if isinstance(current, dict):
                    if part not in current:
                        current[part] = CommentedMap()
                    current = current[part]
                else:
                    return False
                    
            # Actualizar el valor final
            if isinstance(current, dict):
                current[parts[-1]] = value
                return True
            return False
            
        except Exception as e:
            logger.error(f"Error al actualizar valor en YAML: {str(e)}")
            return False
            
    def merge_yaml(self, base: CommentedMap, overlay: Dict) -> Optional[CommentedMap]:
        """
        Combina dos estructuras YAML manteniendo comentarios del base.
        
        Args:
            base: YAML base con comentarios
            overlay: Datos a sobrescribir
            
        Returns:
            Optional[CommentedMap]: YAML combinado o None si hay error
        """
        try:
            def merge_dict(base_dict: Union[Dict, CommentedMap], overlay_dict: Dict) -> None:
                for key, value in overlay_dict.items():
                    if (
                        key in base_dict 
                        and isinstance(base_dict[key], (dict, CommentedMap))
                        and isinstance(value, dict)
                    ):
                        merge_dict(base_dict[key], value)
                    else:
                        base_dict[key] = value
                        
            result = CommentedMap(base)
            merge_dict(result, overlay)
            return result
            
        except Exception as e:
            logger.error(f"Error al combinar YAMLs: {str(e)}")
            return None