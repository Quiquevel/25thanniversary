import aiohttp
import asyncio
import tempfile
import os
import shutil
import yaml
import base64
from datetime import datetime
from typing import Dict, Any, Tuple, Optional
from pathlib import Path
from shuttlelib.utils.logger import logger
from .common_utils import normalize_oam_url, normalize_git_url, get_ci_id_from_oam, get_ci_id_for_environment, get_all_ci_ids_for_environment, convert_github_url_to_api
from .openshift.processor import get_oam_from_git, get_deployment_from_openshift, determine_cluster_config_from_oam, extract_namespace_from_oam, get_secret_from_openshift
from .github.operations import modify_values_file_optimized
from .github_client import GitHubClient
from .frontend_detection import detect_frontend_config_files, create_frontend_config_json_files
from .respuestas import (
    format_header_main_process, format_step_result, format_microservice_detection,
    format_process_completion, format_success, format_error, format_warning, fix_encoding,
    ResponseFormatter
)


def _convert_yaml_to_properties(yaml_data: dict, prefix: str = "") -> str:
    """
    Convierte un diccionario YAML a formato properties.
    
    Args:
        yaml_data: Diccionario con datos YAML
        prefix: Prefijo para las claves (usado en recursión)
        
    Returns:
        str: Contenido en formato properties
    """
    properties_lines = []
    
    for key, value in yaml_data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        
        if isinstance(value, dict):
            # Recursión para objetos anidados
            properties_lines.append(_convert_yaml_to_properties(value, full_key))
        elif isinstance(value, list):
            # Para listas, crear múltiples entradas indexadas
            for i, item in enumerate(value):
                if isinstance(item, dict):
                    properties_lines.append(_convert_yaml_to_properties(item, f"{full_key}[{i}]"))
                else:
                    properties_lines.append(f"{full_key}[{i}]={item}")
        else:
            # Valor simple
            properties_lines.append(f"{full_key}={value}")
    
    return "\n".join(properties_lines)


def detect_microservice_type(old_name: str, deployment_data: Optional[Dict], config_files_in_memory: Optional[Dict[str, str]] = None) -> Tuple[str, str, Optional[str]]:
    """
    Detecta si el microservicio es Backend o Frontend basándose en criterios específicos.
    
    ORDEN DE DETECCIÓN (parar en el primer match):
    1. old_name contiene 'f-ng' → Frontend
    2. deployment.yaml tiene template: nginx → Frontend  
    3. deployment.yaml tiene CONFIG_END_POINT → Frontend + extraer nombre archivo
    4. old_name contiene 's-java' → Backend
    5. Otros criterios de backend
    
    Args:
        old_name: Nombre del microservicio
        deployment_data: Datos del deployment.yaml de OpenShift
        config_files_in_memory: Archivos de configuración descargados del config server (opcional)
        
    Returns:
        Tuple[str, str, Optional[str]]: (tipo, razon, config_endpoint_filename) 
        donde tipo es 'backend', 'frontend' o 'unknown'
        config_endpoint_filename es el nombre exacto del archivo extraído de CONFIG_END_POINT (solo para frontend)
    """
    try:
        logger.info(f"🔍 Detectando tipo de microservicio para: {old_name}")
        
        # Variables para almacenar el resultado de la detección
        detected_type = None
        detected_reason = None
        config_endpoint_filename = None
        
        # CRITERIO 1: Verificar nombre del microservicio (f-ng = frontend)
        if 'f-ng' in old_name.lower():
            logger.info(f"✅ Microservicio FRONTEND detectado por nombre: contiene 'f-ng'")
            detected_type = 'frontend'
            detected_reason = f"Nombre contiene 'f-ng': {old_name}"
            # NO RETORNAR AQUÍ - continuar para buscar CONFIG_END_POINT
            
        # CRITERIO 2 y 3: Verificar deployment.yaml si está disponible
        if deployment_data and isinstance(deployment_data, dict):
            # Buscar en labels del deployment
            labels = deployment_data.get('metadata', {}).get('labels', {})
            if isinstance(labels, dict):
                # Verificar template nginx para frontend
                template = labels.get('template', '') or labels.get('vostok/template', '')
                if 'nginx' in template.lower():
                    logger.info(f"✅ Microservicio FRONTEND detectado por template: {template}")
                    if not detected_type:  # Solo asignar si no se detectó antes
                        detected_type = 'frontend'
                        detected_reason = f"Label 'template' contiene 'nginx': {template}"
            
            # CRITERIO 3: SIEMPRE verificar CONFIG_END_POINT (especialmente importante para frontends)
            try:
                spec = deployment_data.get('spec', {})
                template_spec = spec.get('template', {}).get('spec', {})
                containers = template_spec.get('containers', [])
                
                for container in containers:
                    env_vars = container.get('env', [])
                    for env_var in env_vars:
                        if env_var.get('name') == 'CONFIG_END_POINT':
                            config_endpoint = env_var.get('value', '')
                            logger.info(f"✅ CONFIG_END_POINT encontrado: {config_endpoint}")
                            
                            # Extraer nombre del archivo del CONFIG_END_POINT
                            if config_endpoint and '/' in config_endpoint:
                                extracted_filename = config_endpoint.split('/')[-1]
                                logger.info(f"📝 Archivo extraído del path: '{extracted_filename}'")
                                if extracted_filename.endswith('.json'):
                                    config_endpoint_filename = extracted_filename
                                    logger.info(f"🎯 Nombre específico extraído de CONFIG_END_POINT: {config_endpoint_filename}")
                                    # Si encontramos CONFIG_END_POINT con .json, confirmar como frontend
                                    if not detected_type:
                                        detected_type = 'frontend'
                                        detected_reason = f"Encontrado CONFIG_END_POINT: {config_endpoint}"
                                else:
                                    logger.warning(f"⚠️ Archivo extraído no termina en .json: {extracted_filename}")
                            else:
                                logger.warning(f"⚠️ CONFIG_END_POINT no contiene '/' o está vacío: {config_endpoint}")
                            
                            break  # Solo tomar el primer CONFIG_END_POINT encontrado
                            
            except Exception as env_error:
                logger.warning(f"Error analizando variables de entorno: {str(env_error)}")
        
        # Si ya se detectó como frontend por cualquier criterio anterior, retornar con config_endpoint_filename
        if detected_type == 'frontend':
            final_reason = detected_reason
            if config_endpoint_filename:
                final_reason += f" + CONFIG_END_POINT detectado: {config_endpoint_filename}"
            logger.info(f"🎯 Retornando FRONTEND con config_endpoint_filename: {config_endpoint_filename}")
            return detected_type, final_reason, config_endpoint_filename
        
        # CRITERIO 4: Verificar nombre del microservicio (s-java = backend) 
        if 's-java' in old_name.lower():
            logger.info(f"✅ Microservicio BACKEND detectado por nombre: contiene 's-java'")
            return 'backend', f"Nombre contiene 's-java': {old_name}", None
            
        # CRITERIO 5: Verificar base_image para backend (javase)
        if deployment_data and isinstance(deployment_data, dict):
            labels = deployment_data.get('metadata', {}).get('labels', {})
            if isinstance(labels, dict):
                base_image = labels.get('base_image', '')
                if 'javase' in base_image.lower():
                    logger.info(f"✅ Microservicio BACKEND detectado por base_image: {base_image}")
                    return 'backend', f"Label 'base_image' contiene 'javase': {base_image}", None
                
                # Verificar nombre del app en labels para backend (s-java)
                app_name = labels.get('app', '') or labels.get('app_name', '')
                if 's-java' in app_name.lower():
                    logger.info(f"✅ Microservicio BACKEND detectado por app name en labels: {app_name}")
                    return 'backend', f"Label 'app' contiene 's-java': {app_name}", None
        
        # CRITERIO 6: Verificar archivos JSON con old_name (es un frontend si existe)
        if config_files_in_memory:
            is_frontend_by_json, compatible_json_files = detect_frontend_config_files(config_files_in_memory, old_name, deployment_data)
            if is_frontend_by_json:
                json_files_names = [f['file_name'] for f in compatible_json_files]
                logger.info(f"✅ Microservicio FRONTEND detectado por archivos JSON: {json_files_names}")
                return 'frontend', f"Encontrados archivos JSON compatibles: {', '.join(json_files_names)}", None
        
        # No se pudo determinar el tipo
        logger.warning(f"⚠️ No se pudo determinar el tipo de microservicio para: {old_name}")
        return 'unknown', "No se encontraron criterios válidos para backend o frontend", None
        
    except Exception as e:
        logger.error(f"❌ Error detectando tipo de microservicio: {str(e)}")
        return 'unknown', f"Error en detección: {str(e)}", None


# Importar la función desde el módulo utils para evitar imports circulares
from .utils import get_environment_suffix


async def configmap_service(
    old_name: str,
    git_token: str,
    url_git_cm: str,
    url_oam: str
) -> str:
    """
    Orquestador principal para el proceso de edición de ConfigMaps.
    1. Obtiene archivo OAM y extrae ci_id
    2. Descarga deployment del configuration-server
    3. Extrae CI_ID del OAM
    4. Detecta tipo de microservicio (Backend/Frontend)
    5. Procesa según el tipo detectado
    
    Args:
        old_name: Nombre del microservicio
        git_token: Token de GitHub
        url_git_cm: URL del repositorio de ConfigMaps
        url_oam: URL del archivo OAM
        
    Returns:
        str: Resumen del procesamiento como string
    """
    
    # Usar sistema centralizado de respuestas
    resumen_completo = format_header_main_process("MICROSERVICIO CONFIG MAP", old_name)
    
    try:
        # Paso 1: Obtener archivo OAM
        try:
            oam_data = await get_oam_from_git(url_oam, git_token)
            if oam_data:
                resumen_completo.extend(format_step_result(1, "Descarga archivo OAM", True))
                logger.debug("Archivo OAM descargado exitosamente")
            else:
                resumen_completo.extend(format_step_result(1, "Descarga archivo OAM", False, "No se pudo descargar archivo OAM"))
                return fix_encoding("\n".join(resumen_completo))
        except Exception as e:
            resumen_completo.extend(format_step_result(1, "Descarga archivo OAM", False, f"Error: {str(e)}"))
            return fix_encoding("\n".join(resumen_completo))
        
        # Paso 2: Descargar deployment del configuration-server
        try:
            deployment_data, deployment_resumen, config_files_in_memory = await download_config_server_deployment(oam_data, old_name, git_token, url_git_cm)
            resumen_completo.extend(deployment_resumen)
            
            # LOG CRÍTICO: Confirmar que los archivos están aquí
            logger.info(f"🔍 POST-PASO2: config_files_in_memory length: {len(config_files_in_memory)}")
            logger.info(f"🔍 POST-PASO2: config_files_in_memory keys: {list(config_files_in_memory.keys())}")
            
        except Exception as e:
            logger.error(f"❌ EXCEPCIÓN EN PASO 2: {str(e)}")
            logger.error("❌ ESTO CAUSARÁ QUE config_files_in_memory SEA VACÍO")
            resumen_completo.extend(format_step_result(2, "Descarga deployment config-server", False, f"Error: {str(e)}"))
            deployment_data = None
            config_files_in_memory = {}
            
            # LOG CRÍTICO: Confirmar que se vació
            logger.error(f"🔍 POST-EXCEPCIÓN: config_files_in_memory length: {len(config_files_in_memory)}")
        
        logger.info(f"🔍 ANTES-PASO3: config_files_in_memory length: {len(config_files_in_memory)}")
        
        # Paso 3: Extraer CI_ID del OAM
        try:
            ci_id = get_ci_id_from_oam(oam_data)
            ci_id_failed = not ci_id
            
            if ci_id:
                resumen_completo.extend(format_step_result(3, "Extracción CI_ID", True))
                logger.debug(f"CI_ID extraído: {ci_id}")
            else:
                resumen_completo.extend(format_step_result(3, "Extracción CI_ID", False, "No se pudo extraer CI_ID del OAM"))
                logger.warning("No se pudo extraer CI_ID del OAM")
        except Exception as e:
            logger.error(f"❌ EXCEPCIÓN EN PASO 3: {str(e)}")
            resumen_completo.extend(format_step_result(3, "Extracción CI_ID", False, f"Error: {str(e)}"))
            ci_id = None
            ci_id_failed = True

        logger.info(f"🔍 ANTES-DETECCIÓN: config_files_in_memory length: {len(config_files_in_memory)}")
        
        # Paso 3.5: Obtener deployment del microservicio (para CONFIG_END_POINT)
        microservice_deployment_data = None
        try:
            # Extraer namespace desde el OAM (usando certificación como referencia)
            target_namespace = extract_namespace_from_oam(oam_data)
            
            # Determinar configuración del cluster desde OAM
            cluster_config = oam_data
            logger.info(f"🔍 PASO 3.5: Obteniendo deployment del microservicio '{old_name}' en namespace '{target_namespace}'")
            logger.info(f"🔍 PASO 3.5: DEBUG - old_name completo: '{old_name}'")
            logger.info(f"🔍 PASO 3.5: DEBUG - target_namespace: '{target_namespace}'")
            
            # Intentar obtener deployment con nombre exacto
            microservice_deployment_data, microservice_namespace, _ = await get_deployment_from_openshift(
                old_name, 
                target_namespace, 
                cluster_config
            )
            
            # Si no se encuentra con nombre exacto, intentar buscar por patrón (para casos como f-ng-50076021-front vs f-ng-50076021-gascor-front)
            if not microservice_deployment_data and old_name.count('-') >= 3:
                logger.info(f"🔄 PASO 3.5: No encontrado con nombre exacto, intentando patrón extendido...")
                # Extraer el patrón base (ej: f-ng-50076021-front -> f-ng-50076021-*-front)
                parts = old_name.split('-')
                if len(parts) >= 4:
                    # Intentar patrones comunes
                    extended_patterns = [
                        f"{'-'.join(parts[:3])}-gascor-{parts[-1]}",  # f-ng-50076021-gascor-front
                        f"{'-'.join(parts[:3])}-{parts[-1]}",         # f-ng-50076021-front (original)
                    ]
                    
                    for pattern in extended_patterns:
                        logger.info(f"🔄 PASO 3.5: Probando patrón: '{pattern}'")
                        try:
                            test_deployment, test_namespace, _ = await get_deployment_from_openshift(
                                pattern,
                                target_namespace, 
                                cluster_config
                            )
                            if test_deployment:
                                logger.info(f"✅ PASO 3.5: Encontrado con patrón '{pattern}'")
                                microservice_deployment_data = test_deployment
                                microservice_namespace = test_namespace
                                break
                        except Exception as pattern_error:
                            logger.debug(f"Patrón '{pattern}' falló: {str(pattern_error)}")
                            continue
            
            if microservice_deployment_data:
                logger.info(f"✅ PASO 3.5: Deployment del microservicio '{old_name}' encontrado en namespace '{microservice_namespace}'")
                # DEBUG: Verificar si contiene CONFIG_END_POINT
                has_config_endpoint = False
                try:
                    spec = microservice_deployment_data.get('spec', {})
                    template_spec = spec.get('template', {}).get('spec', {})
                    containers = template_spec.get('containers', [])
                    for container in containers:
                        env_vars = container.get('env', [])
                        for env_var in env_vars:
                            if env_var.get('name') == 'CONFIG_END_POINT':
                                has_config_endpoint = True
                                config_endpoint_value = env_var.get('value', '')
                                logger.info(f"✅ PASO 3.5: CONFIG_END_POINT encontrado: {config_endpoint_value}")
                                break
                        if has_config_endpoint:
                            break
                    if not has_config_endpoint:
                        logger.warning(f"⚠️ PASO 3.5: Deployment encontrado pero NO contiene CONFIG_END_POINT")
                except Exception as parse_error:
                    logger.warning(f"⚠️ PASO 3.5: Error verificando CONFIG_END_POINT: {str(parse_error)}")
            else:
                logger.warning(f"⚠️ PASO 3.5: No se encontró deployment del microservicio '{old_name}' en namespace '{target_namespace}'")
                
        except Exception as e:
            logger.warning(f"⚠️ PASO 3.5: Error obteniendo deployment del microservicio: {str(e)}")
            microservice_deployment_data = None
        
        # Detectar tipo de microservicio
        try:
            # Usar el deployment del microservicio (no del config-server) para detección
            deployment_for_detection = microservice_deployment_data if microservice_deployment_data else deployment_data
            
            # DEBUG: Mostrar qué deployment se está usando para detección
            if microservice_deployment_data:
                deployment_source = "MICROSERVICIO"
                deployment_name = microservice_deployment_data.get('metadata', {}).get('name', 'unknown')
            else:
                deployment_source = "CONFIG-SERVER (FALLBACK)"
                deployment_name = deployment_data.get('metadata', {}).get('name', 'unknown') if deployment_data else 'None'
            
            logger.info(f"🔍 DETECCIÓN: Usando deployment de {deployment_source}: '{deployment_name}'")
            
            config_type, detection_reason, config_endpoint_filename = detect_microservice_type(old_name, deployment_for_detection, config_files_in_memory)
            resumen_completo.extend(format_microservice_detection(config_type.upper(), old_name, detection_reason))
            
            # Log del archivo específico si se detectó por CONFIG_END_POINT
            if config_endpoint_filename:
                logger.info(f"📝 Archivo específico detectado para frontend: {config_endpoint_filename}")
            
            logger.info(f"🔍 ANTES-PROCESADO-{config_type.upper()}: config_files_in_memory length: {len(config_files_in_memory)}")
            
            # Procesar según el tipo detectado
            if config_type == 'backend':
                backend_resumen = await process_backend_configmap(
                    old_name, git_token, url_git_cm, oam_data, 
                    microservice_deployment_data, ci_id, ci_id_failed, config_files_in_memory
                )
                resumen_completo.extend(backend_resumen)
                
            elif config_type == 'frontend':
                frontend_resumen = await process_frontend_configmap(
                    old_name, git_token, url_git_cm, oam_data, 
                    microservice_deployment_data, ci_id, ci_id_failed, config_files_in_memory, config_endpoint_filename
                )
                resumen_completo.extend(frontend_resumen)
                
            else:
                resumen_completo.append(f"⚠️ Tipo '{config_type}' no soportado - usando flujo Backend por defecto")
                backend_resumen = await process_backend_configmap(
                    old_name, git_token, url_git_cm, oam_data, 
                    microservice_deployment_data, ci_id, ci_id_failed, config_files_in_memory
                )
                resumen_completo.extend(backend_resumen)
        
        except Exception as e:
            resumen_completo.append(f"❌ Error en detección de tipo: {str(e)}")
            # En caso de error, usar backend por defecto
            logger.warning("Error en detección, usando backend por defecto")
            try:
                backend_resumen = await process_backend_configmap(
                    old_name, git_token, url_git_cm, oam_data, 
                    microservice_deployment_data, ci_id, ci_id_failed, config_files_in_memory
                )
                resumen_completo.extend(backend_resumen)
            except Exception as fallback_error:
                resumen_completo.append(f"❌ Error en procesamiento fallback: {str(fallback_error)}")
        
        # Resumen final
        resumen_completo.extend(format_process_completion("CONFIGMAP", old_name))
        
    except Exception as e:
        resumen_completo.append(format_error("CONFIGMAP SERVICE", str(e)))
        logger.error(f"Error general en configmap_service: {str(e)}")
    
    return fix_encoding("\n".join(resumen_completo))


async def process_backend_configmap(
    old_name: str,
    git_token: str, 
    url_git_cm: str,
    oam_data: Dict[str, Any],
    deployment_data: Optional[Dict],
    ci_id: Optional[str],
    ci_id_failed: bool,
    config_files_in_memory: Dict[str, str]
) -> list:
    """
    Procesa ConfigMap específico para microservicios Backend.
    
    Returns:
        list: Lista de strings con el resumen del procesamiento
    """
    resumen = ResponseFormatter.backend_flow_header()
    
    # PASO 2.4: Crear archivos de configuración específicos para backend
    resumen.append("\n--- PASO 2.4: Creación archivos configuración desde config server ---")
    logger.info("🔄 INICIANDO CREACIÓN DE ARCHIVOS DE CONFIGURACIÓN BACKEND...")
    
    try:
        config_creation_result = await create_config_files_from_downloaded_files(
            config_files_in_memory, old_name, git_token, url_git_cm, "backend", None
        )
        
        logger.info(f"🔄 RESULTADO CREACIÓN ARCHIVOS BACKEND: {config_creation_result}")
        
        if config_creation_result:
            # Dividir el resultado y añadir cada archivo por separado para mejor visibilidad
            if " | " in config_creation_result:
                file_results = config_creation_result.split(" | ")
                for file_result in file_results:
                    resumen.append(f"   {file_result.strip()}")
            else:
                resumen.append(f"   {config_creation_result}")
        else:
            resumen.append("❌ Error: No se obtuvo resultado de creación de archivos")
            
    except Exception as e:
        logger.error(f"❌ Error creando archivos de configuración backend: {str(e)}")
        resumen.append(f"❌ Error creando archivos backend: {str(e)}")
    
    # Inicializar variables necesarias
    config_repo_failed = False
    temp_base_dir = None
    
    # Paso 4: Modificar archivos cd.yml inmediatamente después de extraer CI_ID
    resumen.append("\n--- PASO 4: Modificación de archivos cd.yml ---")
    modified_files = []
    
    if ci_id_failed:
        resumen.append("❌ Saltando modificación de cd.yml - CI_ID requerido no disponible")
    else:
        environments = ['cert', 'pre', 'pro']
        new_component_name = f"cm-{old_name}"
        namespace_for_cd = extract_namespace_from_oam(oam_data) if oam_data else 'default'
        
        # Usar modify_values_file_optimized para cada archivo cd.yml
        session = aiohttp.ClientSession()
        try:
            normalized_git_url = normalize_git_url(url_git_cm)
            repo_api_url = convert_github_url_to_api(normalized_git_url)
            logger.info(f"ConfigMap: repo_api_url convertida: {repo_api_url}")
            logger.info(f"ConfigMap: namespace_for_cd: {namespace_for_cd}")
            logger.info(f"ConfigMap: old_name: {old_name}")
            logger.info(f"ConfigMap: oam_data disponible: {oam_data is not None}")
            
            for env in environments:
                cd_file_path = f".gluon/cd/{env}/cd.yml"
                
                # Extraer CI_ID específico para este entorno
                if env == 'pro':
                    # Para PRO, extraer TODOS los CI_IDs (dual cluster)
                    all_env_ci_ids = get_all_ci_ids_for_environment(oam_data, env)
                    if not all_env_ci_ids:
                        logger.warning(f"No se pudieron extraer CI_IDs específicos para {env}, usando CI_ID general: {ci_id}")
                        env_ci_id = ci_id
                    else:
                        # Para PRO dual cluster, usar TODOS los CI_IDs separados por coma
                        env_ci_id = ",".join(all_env_ci_ids)
                        logger.info(f"CI_IDs específicos para {env} (dual cluster): {env_ci_id}")
                else:
                    # Para cert y pre, usar solo un CI_ID
                    env_ci_id = get_ci_id_for_environment(oam_data, env)
                    if not env_ci_id:
                        logger.warning(f"No se pudo extraer CI_ID específico para {env}, usando CI_ID general: {ci_id}")
                        env_ci_id = ci_id
                    else:
                        logger.info(f"CI_ID específico para {env}: {env_ci_id}")
                
                try:
                    logger.info(f"ConfigMap: Procesando {cd_file_path} en repositorio {repo_api_url}")
                    
                    # Preparar datos OAM igual que en backends 
                    oam_data_for_cd = None
                    if oam_data:
                        # Para ConfigMaps, preservar application_name del nivel superior junto con raw_data
                        if 'raw_data' in oam_data:
                            oam_data_for_cd = oam_data['raw_data'].copy()
                            # ✅ PRESERVAR application_name para ConfigMaps (no se pierde)
                            if 'application_name' in oam_data:
                                oam_data_for_cd['application_name'] = oam_data['application_name']
                                logger.info(f"✅ ConfigMap: Preservado application_name: {oam_data['application_name']}")
                        else:
                            oam_data_for_cd = oam_data
                    
                    cd_result = await modify_values_file_optimized(
                        session, 
                        repo_api_url, 
                        git_token, 
                        old_name,
                        namespace_for_cd,  # namespace
                        "",  # java_opts_ext (vacío para ConfigMaps)
                        "online",  # region por defecto
                        cd_file_path,  # archivo cd.yml específico
                        oam_data_for_cd,  # datos OAM preparados igual que backends
                        deployment_data,  # datos del deployment
                        "main",  # branch (se ignora cuando is_configmap=True)
                        True,  # is_configmap=True - fuerza uso de rama "main"
                        "backend",  # service_type (ConfigMaps no diferencian frontend/backend, usamos backend por defecto)
                        env,  # env_override para buscar CI_ID específico del entorno
                        env_ci_id  # required_ci_id específico del entorno
                    )
                    
                    if cd_result:
                        if env == 'pro':
                            resumen.append(f"✅ CD.YML {env.upper()}: OK - Verificado/Modificado (con dual cluster para PRO)")
                        else:
                            resumen.append(f"✅ CD.YML {env.upper()}: OK - Verificado/Modificado")
                        modified_files.append(cd_file_path)
                    else:
                        resumen.append(f"❌ CD.YML {env.upper()}: KO - La función modify_values_file_optimized devolvió False")
                        
                except Exception as e:
                    logger.error(f"Error procesando {cd_file_path}: {str(e)}")
                    resumen.append(f"❌ CD.YML {env.upper()}: KO - Error: {str(e)}")
                    
        except Exception as e:
            logger.error(f"Error general en modify_values_file_optimized: {str(e)}")
            resumen.append(f"❌ Error general modificando archivos cd.yml: {str(e)}")
        finally:
            await session.close()

    # Paso 4.5: Crear values-xxx.yaml para entornos básicos 
    resumen.append("\n--- PASO 4.5: Creación values-xxx.yaml para entornos básicos ---")
    
    if ci_id_failed:
        resumen.append("❌ Saltando values-xxx.yaml básicos - CI_ID requerido no disponible")
    else:
        basic_values_files = {
            'cert': '.gluon/cd/cert/values-cert.yaml',
            'pre': '.gluon/cd/pre/values-pre.yaml',
            'pro': '.gluon/cd/pro/values-pro.yaml'
        }
        
        basic_values_created = 0
        # Crear nueva sesión para archivos values básicos
        session = aiohttp.ClientSession()
        try:
            for env_name, values_file_path in basic_values_files.items():
                try:
                    logger.info(f"ConfigMap: Creando archivo values básico {values_file_path} (env: {env_name})")

                    # Extraer CI_ID específico para cada entorno básico
                    if env_name == 'pro':
                        # Para PRO, extraer TODOS los CI_IDs (dual cluster)
                        all_env_ci_ids = get_all_ci_ids_for_environment(oam_data, env_name)
                        if not all_env_ci_ids:
                            logger.warning(f"No se pudieron extraer CI_IDs específicos para {env_name}, usando CI_ID general: {ci_id}")
                            env_ci_id = ci_id
                        else:
                            # Para PRO dual cluster, usar TODOS los CI_IDs separados por coma
                            env_ci_id = ",".join(all_env_ci_ids)
                            logger.info(f"CI_IDs específicos para {env_name} (dual cluster): {env_ci_id}")
                    else:
                        # Para cert y pre, usar solo un CI_ID
                        env_ci_id = get_ci_id_for_environment(oam_data, env_name)
                        if not env_ci_id:
                            logger.warning(f"No se pudo extraer CI_ID específico para {env_name}, usando CI_ID general: {ci_id}")
                            env_ci_id = ci_id
                        else:
                            logger.info(f"CI_ID específico para {env_name}: {env_ci_id}")

                    # Preparar datos OAM igual que en backends
                    oam_data_for_values = None
                    if oam_data:
                        if 'raw_data' in oam_data:
                            oam_data_for_values = oam_data['raw_data']
                        else:
                            oam_data_for_values = oam_data
                    
                    values_result = await modify_values_file_optimized(
                        session, 
                        repo_api_url, 
                        git_token, 
                        old_name,  # Sin sufijo para entornos básicos
                        namespace_for_cd,  # namespace
                        "",  # java_opts_ext (vacío para ConfigMaps)
                        "online",  # region por defecto
                        values_file_path,  # archivo .gluon/cd/xxx/values-xxx.yaml
                        oam_data_for_values,  # datos OAM preparados
                        deployment_data,  # datos del deployment
                        "main",  # branch (se ignora cuando is_configmap=True)
                        True,  # is_configmap=True - fuerza uso de rama "main"
                        "backend",  # service_type
                        env_name,  # env_override
                        env_ci_id  # required_ci_id específico del entorno
                    )
                    
                    if values_result:
                        resumen.append(f"✅ VALUES-{env_name.upper()}: OK - {values_file_path} creado")
                        basic_values_created += 1
                    else:
                        resumen.append(f"❌ VALUES-{env_name.upper()}: KO - Error en procesamiento")
                        
                except Exception as e:
                    logger.error(f"Error procesando {values_file_path}: {str(e)}")
                    resumen.append(f"❌ VALUES-{env_name.upper()}: KO - Error: {str(e)}")
        finally:
            await session.close()
        
        resumen.append(f"✅ Archivos values-xxx.yaml básicos creados: {basic_values_created}/{len(basic_values_files)} procesados")

    # Paso 5: Procesar ConfigMaps - Entornos adicionales de producción inmediatamente después
    resumen.append("\n--- PASO 5: ConfigMaps - Entornos adicionales de producción ---")
    
    if ci_id_failed:
        resumen.append("❌ Saltando entornos adicionales - CI_ID requerido no disponible")
    else:
        configmap_cd_files = {
            'pro-b-test': '.gluon/cd/pro-b-test/cd.yml',
            'pro-g-test': '.gluon/cd/pro-g-test/cd.yml', 
            'pro-b': '.gluon/cd/pro-b/cd.yml',
            'pro-g': '.gluon/cd/pro-g/cd.yml'
        }
        
        configmap_cd_created = 0
        # Para entornos adicionales de PRO, usar TODOS los CI_IDs (dual cluster)
        all_pro_ci_ids = get_all_ci_ids_for_environment(oam_data, 'pro')
        if not all_pro_ci_ids:
            logger.warning(f"No se pudieron extraer CI_IDs específicos para PRO, usando CI_ID general: {ci_id}")
            pro_ci_id = ci_id
        else:
            # Para entornos PRO adicionales, usar TODOS los CI_IDs separados por coma (dual cluster)
            pro_ci_id = ",".join(all_pro_ci_ids)
            logger.info(f"CI_IDs específicos para entornos PRO adicionales (dual cluster): {pro_ci_id}")
        
        # Crear nueva sesión para entornos adicionales
        session = aiohttp.ClientSession()
        try:
            for env_name, cd_file_path in configmap_cd_files.items():
                try:
                    logger.info(f"ConfigMap: Procesando archivo cd adicional {cd_file_path} (env: {env_name})")

                    # TODOS los entornos pro-b*, pro-g* son variantes de PRO
                    # Usar el CI_ID de PRO con dual cluster ya calculado
                    env_specific_ci_id = pro_ci_id  # Ya contiene todos los CI_IDs separados por coma
                    logger.info(f"CI_ID de PRO (dual cluster) para {env_name}: {env_specific_ci_id}")

                    # Preparar datos OAM igual que en backends
                    oam_data_for_cd = None
                    if oam_data:
                        if 'raw_data' in oam_data:
                            oam_data_for_cd = oam_data['raw_data']
                        else:
                            oam_data_for_cd = oam_data
                    
                    # Agregar sufijo al nombre para entornos específicos
                    env_suffix = get_environment_suffix(env_name)
                    old_name_with_suffix = f"{old_name}{env_suffix}"
                    logger.info(f"ConfigMap: Usando nombre con sufijo para {env_name}: {old_name_with_suffix}")
                    
                    cd_result = await modify_values_file_optimized(
                        session, 
                        repo_api_url, 
                        git_token, 
                        old_name_with_suffix,
                        namespace_for_cd,  # namespace
                        "",  # java_opts_ext (vacío para ConfigMaps)
                        "online",  # region por defecto
                        cd_file_path,  # archivo cd.yml específico
                        oam_data_for_cd,  # datos OAM preparados igual que backends
                        deployment_data,  # datos del deployment
                        "main",  # branch (se ignora cuando is_configmap=True)
                        True,  # is_configmap=True - fuerza uso de rama "main"
                        "backend",  # service_type
                        env_name,  # env_override - usar el nombre específico del entorno
                        env_specific_ci_id  # required_ci_id específico de PRO
                    )
                    
                    if cd_result:
                        resumen.append(f"✅ CD.YML {env_name.upper()}: OK - {cd_file_path.split('/')[-1]} creado")
                        configmap_cd_created += 1
                    else:
                        resumen.append(f"❌ CD.YML {env_name.upper()}: KO - Error en procesamiento")
                        
                except Exception as e:
                    logger.error(f"Error procesando {cd_file_path}: {str(e)}")
                    resumen.append(f"❌ CD.YML {env_name.upper()}: KO - Error en procesamiento")
        finally:
            await session.close()
        
        resumen.append(f"✅ Entornos adicionales ConfigMap: {configmap_cd_created}/{len(configmap_cd_files)} procesados")

    # Paso 5: Crear .gluon/cd/values.yaml principal
    resumen.append("\n--- PASO 5: Creación .gluon/cd/values.yaml principal ---")
    
    if ci_id_failed:
        resumen.append("❌ Saltando values.yaml principal - CI_ID requerido no disponible")
    else:
        # Crear nueva sesión para el archivo values.yaml principal
        session = aiohttp.ClientSession()
        try:
            normalized_git_url = normalize_git_url(url_git_cm)
            repo_api_url = convert_github_url_to_api(normalized_git_url)
            
            # Preparar datos OAM igual que para cd.yml
            oam_data_for_values = None
            if oam_data:
                if 'raw_data' in oam_data:
                    oam_data_for_values = oam_data['raw_data'].copy()
                    # ✅ PRESERVAR application_name para ConfigMaps
                    if 'application_name' in oam_data:
                        oam_data_for_values['application_name'] = oam_data['application_name']
                        logger.info(f"✅ ConfigMap values.yaml: Preservado application_name: {oam_data['application_name']}")
                else:
                    oam_data_for_values = oam_data
            
            logger.info(f"ConfigMap: Procesando .gluon/cd/values.yaml principal")
            
            values_result = await modify_values_file_optimized(
                session, 
                repo_api_url, 
                git_token, 
                old_name,
                namespace_for_cd,
                "",  # java_opts_ext (vacío para ConfigMaps)
                "online",  # region por defecto
                ".gluon/cd/values.yaml",  # archivo values.yaml principal
                oam_data_for_values,  # datos OAM con application_name preservado
                deployment_data,  # datos del deployment
                "main",  # branch (se ignora cuando is_configmap=True)
                True,  # is_configmap=True
                "backend",  # service_type
                None,  # env_override (no aplica para values.yaml principal)
                ci_id  # required_ci_id 
            )
            
            if values_result:
                resumen.append("✅ Archivo .gluon/cd/values.yaml principal creado correctamente")
                logger.info("✅ ConfigMap: values.yaml principal procesado exitosamente")
            else:
                resumen.append("❌ Error al crear .gluon/cd/values.yaml principal")
                logger.error("❌ ConfigMap: Error al procesar values.yaml principal")
                
        except Exception as e:
            logger.error(f"Error al procesar values.yaml principal: {e}")
            resumen.append(f"❌ Error en values.yaml principal: {str(e)}")
            
        finally:
            await session.close()

    # Paso 6: Crear values.yaml en .gluon/cd/ para entornos adicionales
    resumen.append("\n--- PASO 6: Creación values.yaml en .gluon/cd/ para entornos adicionales ---")
    
    if ci_id_failed:
        resumen.append("❌ Saltando values.yaml adicionales - CI_ID requerido no disponible")
    else:
        gluon_values_files = {
            'pro-b-test': '.gluon/cd/pro-b-test/values.yaml',
            'pro-g-test': '.gluon/cd/pro-g-test/values.yaml', 
            'pro-b': '.gluon/cd/pro-b/values.yaml',
            'pro-g': '.gluon/cd/pro-g/values.yaml'
        }
        
        gluon_values_created = 0
        # Crear nueva sesión para archivos values.yaml en .gluon
        session = aiohttp.ClientSession()
        try:
            for env_name, values_file_path in gluon_values_files.items():
                try:
                    logger.info(f"ConfigMap: Creando archivo values {values_file_path} (env: {env_name})")

                    # TODOS los entornos pro-b*, pro-g* usan datos de PRO del OAM con dual cluster
                    all_pro_ci_ids = get_all_ci_ids_for_environment(oam_data, 'pro')
                    if not all_pro_ci_ids:
                        logger.warning(f"No se pudieron extraer CI_IDs específicos de PRO para {env_name}, usando CI_ID general: {ci_id}")
                        env_specific_ci_id = ci_id
                    else:
                        # Para entornos PRO adicionales, usar TODOS los CI_IDs separados por coma (dual cluster)
                        env_specific_ci_id = ",".join(all_pro_ci_ids)
                        logger.info(f"CI_IDs de PRO (dual cluster) para {env_name}: {env_specific_ci_id}")

                    # Preparar datos OAM igual que en backends
                    oam_data_for_values = None
                    if oam_data:
                        if 'raw_data' in oam_data:
                            oam_data_for_values = oam_data['raw_data']
                        else:
                            oam_data_for_values = oam_data
                    
                    # Agregar sufijo al nombre para entornos específicos
                    env_suffix = get_environment_suffix(env_name)
                    old_name_with_suffix = f"{old_name}{env_suffix}"
                    logger.info(f"ConfigMap: Usando nombre con sufijo para values {env_name}: {old_name_with_suffix}")
                    
                    values_result = await modify_values_file_optimized(
                        session, 
                        repo_api_url, 
                        git_token, 
                        old_name_with_suffix,
                        namespace_for_cd,  # namespace
                        "",  # java_opts_ext (vacío para ConfigMaps)
                        "online",  # region por defecto
                        values_file_path,  # archivo .gluon/cd/xxx/values.yaml
                        oam_data_for_values,  # datos OAM preparados
                        deployment_data,  # datos del deployment
                        "main",  # branch (se ignora cuando is_configmap=True)
                        True,  # is_configmap=True - fuerza uso de rama "main"
                        "backend",  # service_type
                        env_name,  # env_override - usar el nombre específico del entorno
                        env_specific_ci_id  # required_ci_id específico de PRO
                    )
                    
                    if values_result:
                        resumen.append(f"✅ VALUES {env_name.upper()}: OK - {values_file_path} creado")
                        gluon_values_created += 1
                    else:
                        resumen.append(f"❌ VALUES {env_name.upper()}: KO - Error en procesamiento")
                        
                except Exception as e:
                    logger.error(f"Error procesando {values_file_path}: {str(e)}")
                    resumen.append(f"❌ VALUES {env_name.upper()}: KO - Error: {str(e)}")
        finally:
            await session.close()
        
        resumen.append(f"✅ Archivos values.yaml en .gluon/cd/ creados: {gluon_values_created}/{len(gluon_values_files)} procesados")

    # PASO 7: Resumen de archivos de configuración creados
    config_files_created = any("✅" in result for result in resumen if "application.yaml" in result or "application.properties" in result)
    step_7_results = ResponseFormatter.step_result(7, "Resumen creación archivos configuración", config_files_created, 
                                                   "Archivos de configuración del config server procesados" if config_files_created else "No se pudieron crear todos los archivos de configuración")
    resumen.extend(step_7_results)
    
    # Detalles específicos de los archivos
    yaml_created = any("application.yaml" in result and "✅" in result for result in resumen)
    properties_created = any("application.properties" in result and "✅" in result for result in resumen)
    
    yaml_status = "✅" if yaml_created else "❌"
    properties_status = "✅" if properties_created else "❌"
    
    resumen.append(f"{yaml_status} Creación de config/cert/application.yaml: {'OK' if yaml_created else 'KO'}")
    resumen.append(f"{properties_status} Creación de config/cert/application.properties: {'OK' if properties_created else 'KO'}")

    # Resto de pasos...
    resumen.append(f"\n✅ Archivos cd.yml procesados: {len(modified_files)} archivos usando función corregida")
    
    logger.info("Proceso de edición de ConfigMap Backend completado")
    return resumen


async def process_frontend_configmap(
    old_name: str,
    git_token: str, 
    url_git_cm: str,
    oam_data: Dict[str, Any],
    deployment_data: Optional[Dict],
    ci_id: Optional[str],
    ci_id_failed: bool,
    config_files_in_memory: Dict[str, str],
    config_endpoint_filename: Optional[str] = None
) -> list:
    """
    Procesa ConfigMap específico para microservicios Frontend.
    
    Returns:
        list: Lista de strings con el resumen del procesamiento
    """
    resumen = ResponseFormatter.frontend_flow_header()
    
    # PASO 2.4: Crear archivos de configuración específicos para frontend
    resumen.append("\n--- PASO 2.4: Creación archivos configuración desde config server ---")
    logger.info("🔄 INICIANDO CREACIÓN DE ARCHIVOS DE CONFIGURACIÓN FRONTEND...")
    
    try:
        config_creation_result = await create_config_files_from_downloaded_files(
            config_files_in_memory, old_name, git_token, url_git_cm, "frontend", config_endpoint_filename
        )
        
        logger.info(f"🔄 RESULTADO CREACIÓN ARCHIVOS FRONTEND: {config_creation_result}")
        
        if config_creation_result:
            # Dividir el resultado y añadir cada archivo por separado para mejor visibilidad
            if " | " in config_creation_result:
                for file_result in config_creation_result.split(" | "):
                    resumen.append(file_result.strip())
            else:
                resumen.append(config_creation_result)
        else:
            resumen.append("❌ Error: No se obtuvo resultado de creación de archivos")
            
    except Exception as e:
        logger.error(f"❌ Error creando archivos de configuración frontend: {str(e)}")
        resumen.append(f"❌ Error creando archivos frontend: {str(e)}")
    
    # PASOS 4-6: Modificar archivos .gluon (misma lógica que backend)
    logger.info("🔧 FRONTEND_CONFIGMAP: Iniciando modificación archivos .gluon")
    
    # Paso 4: Modificar archivos cd.yml
    resumen.append("\n--- PASO 4: Modificación de archivos cd.yml ---")
    modified_files = []
    
    if ci_id_failed:
        resumen.append("❌ Saltando modificación de cd.yml - CI_ID requerido no disponible")
    else:
        environments = ['cert', 'pre', 'pro']
        namespace_for_cd = extract_namespace_from_oam(oam_data) if oam_data else 'default'
        
        # Usar modify_values_file_optimized para cada archivo cd.yml
        session = aiohttp.ClientSession()
        try:
            normalized_git_url = normalize_git_url(url_git_cm)
            repo_api_url = convert_github_url_to_api(normalized_git_url)
            logger.info(f"ConfigMap Frontend: repo_api_url convertida: {repo_api_url}")
            logger.info(f"ConfigMap Frontend: namespace_for_cd: {namespace_for_cd}")
            
            for env in environments:
                cd_file_path = f".gluon/cd/{env}/cd.yml"
                
                # Extraer CI_ID específico para este entorno
                if env == 'pro':
                    all_env_ci_ids = get_all_ci_ids_for_environment(oam_data, env)
                    if not all_env_ci_ids:
                        logger.warning(f"No se pudieron extraer CI_IDs específicos para {env}, usando CI_ID general: {ci_id}")
                        env_ci_id = ci_id
                    else:
                        env_ci_id = ",".join(all_env_ci_ids)
                        logger.info(f"CI_IDs específicos para {env} (dual cluster): {env_ci_id}")
                else:
                    env_ci_id = get_ci_id_for_environment(oam_data, env)
                    if not env_ci_id:
                        logger.warning(f"No se pudo extraer CI_ID específico para {env}, usando CI_ID general: {ci_id}")
                        env_ci_id = ci_id
                    else:
                        logger.info(f"CI_ID específico para {env}: {env_ci_id}")
                
                try:
                    logger.info(f"ConfigMap Frontend: Procesando {cd_file_path}")
                    
                    # Preparar datos OAM igual que en backends
                    oam_data_for_cd = None
                    if oam_data:
                        if 'raw_data' in oam_data:
                            oam_data_for_cd = oam_data['raw_data'].copy()
                            if 'application_name' in oam_data:
                                oam_data_for_cd['application_name'] = oam_data['application_name']
                                logger.info(f"✅ ConfigMap Frontend: Preservado application_name: {oam_data['application_name']}")
                        else:
                            oam_data_for_cd = oam_data
                    
                    cd_result = await modify_values_file_optimized(
                        session, 
                        repo_api_url, 
                        git_token, 
                        old_name,
                        namespace_for_cd,
                        "",  # java_opts_ext (vacío para ConfigMaps)
                        "online",
                        cd_file_path,
                        oam_data_for_cd,
                        deployment_data,
                        "main",
                        True,  # is_configmap=True - fuerza uso de rama "main"
                        "frontend",  # service_type (frontend para este flujo)
                        env,
                        env_ci_id
                    )
                    
                    if cd_result:
                        if env == 'pro':
                            resumen.append(f"✅ CD.YML {env.upper()}: OK - Verificado/Modificado (con dual cluster para PRO)")
                        else:
                            resumen.append(f"✅ CD.YML {env.upper()}: OK - Verificado/Modificado")
                        modified_files.append(cd_file_path)
                    else:
                        resumen.append(f"❌ CD.YML {env.upper()}: KO - Error en procesamiento")
                        
                except Exception as e:
                    logger.error(f"Error procesando {cd_file_path}: {str(e)}")
                    resumen.append(f"❌ CD.YML {env.upper()}: KO - Error: {str(e)}")
                    
        except Exception as e:
            logger.error(f"Error general en modify_values_file_optimized frontend: {str(e)}")
            resumen.append(f"❌ Error general modificando archivos cd.yml: {str(e)}")
        finally:
            await session.close()

    # Paso 4.5: Crear values-xxx.yaml para entornos básicos 
    resumen.append("\n--- PASO 4.5: Creación values-xxx.yaml para entornos básicos ---")
    
    if ci_id_failed:
        resumen.append("❌ Saltando values-xxx.yaml básicos - CI_ID requerido no disponible")
    else:
        basic_values_files = {
            'cert': '.gluon/cd/cert/values-cert.yaml',
            'pre': '.gluon/cd/pre/values-pre.yaml',
            'pro': '.gluon/cd/pro/values-pro.yaml'
        }
        
        basic_values_created = 0
        session = aiohttp.ClientSession()
        try:
            for env_name, values_file_path in basic_values_files.items():
                try:
                    logger.info(f"ConfigMap Frontend: Creando archivo values básico {values_file_path} (env: {env_name})")

                    if env_name == 'pro':
                        all_env_ci_ids = get_all_ci_ids_for_environment(oam_data, env_name)
                        if not all_env_ci_ids:
                            env_ci_id = ci_id
                        else:
                            env_ci_id = ",".join(all_env_ci_ids)
                    else:
                        env_ci_id = get_ci_id_for_environment(oam_data, env_name)
                        if not env_ci_id:
                            env_ci_id = ci_id

                    # Preparar datos OAM
                    oam_data_for_values = None
                    if oam_data:
                        if 'raw_data' in oam_data:
                            oam_data_for_values = oam_data['raw_data']
                        else:
                            oam_data_for_values = oam_data
                    
                    values_result = await modify_values_file_optimized(
                        session, 
                        repo_api_url, 
                        git_token, 
                        old_name,
                        namespace_for_cd,
                        "",
                        "online",
                        values_file_path,
                        oam_data_for_values,
                        deployment_data,
                        "main",
                        True,  # is_configmap=True
                        "frontend",  # service_type
                        env_name,
                        env_ci_id
                    )
                    
                    if values_result:
                        resumen.append(f"✅ VALUES-{env_name.upper()}: OK - {values_file_path} creado")
                        basic_values_created += 1
                    else:
                        resumen.append(f"❌ VALUES-{env_name.upper()}: KO - Error en procesamiento")
                        
                except Exception as e:
                    logger.error(f"Error procesando {values_file_path}: {str(e)}")
                    resumen.append(f"❌ VALUES-{env_name.upper()}: KO - Error: {str(e)}")
        finally:
            await session.close()
        
        resumen.append(f"✅ Archivos values-xxx.yaml básicos creados: {basic_values_created}/{len(basic_values_files)} procesados")

    # Paso 5: Entornos adicionales de producción
    resumen.append("\n--- PASO 5: ConfigMaps - Entornos adicionales de producción ---")
    
    if ci_id_failed:
        resumen.append("❌ Saltando entornos adicionales - CI_ID requerido no disponible")
    else:
        configmap_cd_files = {
            'pro-b-test': '.gluon/cd/pro-b-test/cd.yml',
            'pro-g-test': '.gluon/cd/pro-g-test/cd.yml', 
            'pro-b': '.gluon/cd/pro-b/cd.yml',
            'pro-g': '.gluon/cd/pro-g/cd.yml'
        }
        
        configmap_cd_created = 0
        all_pro_ci_ids = get_all_ci_ids_for_environment(oam_data, 'pro')
        if not all_pro_ci_ids:
            pro_ci_id = ci_id
        else:
            pro_ci_id = ",".join(all_pro_ci_ids)
        
        session = aiohttp.ClientSession()
        try:
            for env_name, cd_file_path in configmap_cd_files.items():
                try:
                    logger.info(f"ConfigMap Frontend: Procesando archivo cd adicional {cd_file_path} (env: {env_name})")

                    # Preparar datos OAM
                    oam_data_for_cd = None
                    if oam_data:
                        if 'raw_data' in oam_data:
                            oam_data_for_cd = oam_data['raw_data']
                        else:
                            oam_data_for_cd = oam_data
                    
                    # Agregar sufijo al nombre para entornos específicos
                    env_suffix = get_environment_suffix(env_name)
                    old_name_with_suffix = f"{old_name}{env_suffix}"
                    
                    cd_result = await modify_values_file_optimized(
                        session, 
                        repo_api_url, 
                        git_token, 
                        old_name_with_suffix,
                        namespace_for_cd,
                        "",
                        "online",
                        cd_file_path,
                        oam_data_for_cd,
                        deployment_data,
                        "main",
                        True,  # is_configmap=True
                        "frontend",  # service_type
                        env_name,
                        pro_ci_id
                    )
                    
                    if cd_result:
                        resumen.append(f"✅ CD.YML {env_name.upper()}: OK - {cd_file_path.split('/')[-1]} creado")
                        configmap_cd_created += 1
                    else:
                        resumen.append(f"❌ CD.YML {env_name.upper()}: KO - Error en procesamiento")
                        
                except Exception as e:
                    logger.error(f"Error procesando {cd_file_path}: {str(e)}")
                    resumen.append(f"❌ CD.YML {env_name.upper()}: KO - Error en procesamiento")
        finally:
            await session.close()
        
        resumen.append(f"✅ Entornos adicionales ConfigMap: {configmap_cd_created}/{len(configmap_cd_files)} procesados")

    # Paso 5: Crear .gluon/cd/values.yaml principal
    resumen.append("\n--- PASO 5: Creación .gluon/cd/values.yaml principal ---")
    
    if ci_id_failed:
        resumen.append("❌ Saltando values.yaml principal - CI_ID requerido no disponible")
    else:
        session = aiohttp.ClientSession()
        try:
            # Preparar datos OAM
            oam_data_for_values = None
            if oam_data:
                if 'raw_data' in oam_data:
                    oam_data_for_values = oam_data['raw_data'].copy()
                    if 'application_name' in oam_data:
                        oam_data_for_values['application_name'] = oam_data['application_name']
                else:
                    oam_data_for_values = oam_data
            
            values_result = await modify_values_file_optimized(
                session, 
                repo_api_url, 
                git_token, 
                old_name,
                namespace_for_cd,
                "",
                "online",
                ".gluon/cd/values.yaml",
                oam_data_for_values,
                deployment_data,
                "main",
                True,  # is_configmap=True
                "frontend",  # service_type
                None,
                ci_id
            )
            
            if values_result:
                resumen.append("✅ Archivo .gluon/cd/values.yaml principal creado correctamente")
            else:
                resumen.append("❌ Error al crear .gluon/cd/values.yaml principal")
                
        except Exception as e:
            logger.error(f"Error al procesar values.yaml principal: {e}")
            resumen.append(f"❌ Error en values.yaml principal: {str(e)}")
            
        finally:
            await session.close()

    # Paso 6: Crear values.yaml en .gluon/cd/ para entornos adicionales
    resumen.append("\n--- PASO 6: Creación values.yaml en .gluon/cd/ para entornos adicionales ---")
    
    if ci_id_failed:
        resumen.append("❌ Saltando values.yaml adicionales - CI_ID requerido no disponible")
    else:
        gluon_values_files = {
            'pro-b-test': '.gluon/cd/pro-b-test/values.yaml',
            'pro-g-test': '.gluon/cd/pro-g-test/values.yaml', 
            'pro-b': '.gluon/cd/pro-b/values.yaml',
            'pro-g': '.gluon/cd/pro-g/values.yaml'
        }
        
        gluon_values_created = 0
        session = aiohttp.ClientSession()
        try:
            for env_name, values_file_path in gluon_values_files.items():
                try:
                    all_pro_ci_ids = get_all_ci_ids_for_environment(oam_data, 'pro')
                    if not all_pro_ci_ids:
                        env_specific_ci_id = ci_id
                    else:
                        env_specific_ci_id = ",".join(all_pro_ci_ids)

                    # Preparar datos OAM
                    oam_data_for_values = None
                    if oam_data:
                        if 'raw_data' in oam_data:
                            oam_data_for_values = oam_data['raw_data']
                        else:
                            oam_data_for_values = oam_data
                    
                    # Agregar sufijo al nombre para entornos específicos
                    env_suffix = get_environment_suffix(env_name)
                    old_name_with_suffix = f"{old_name}{env_suffix}"
                    
                    values_result = await modify_values_file_optimized(
                        session, 
                        repo_api_url, 
                        git_token, 
                        old_name_with_suffix,
                        namespace_for_cd,
                        "",
                        "online",
                        values_file_path,
                        oam_data_for_values,
                        deployment_data,
                        "main",
                        True,  # is_configmap=True
                        "frontend",  # service_type
                        env_name,
                        env_specific_ci_id
                    )
                    
                    if values_result:
                        resumen.append(f"✅ VALUES {env_name.upper()}: OK - {values_file_path} creado")
                        gluon_values_created += 1
                    else:
                        resumen.append(f"❌ VALUES {env_name.upper()}: KO - Error en procesamiento")
                        
                except Exception as e:
                    logger.error(f"Error procesando {values_file_path}: {str(e)}")
                    resumen.append(f"❌ VALUES {env_name.upper()}: KO - Error: {str(e)}")
        finally:
            await session.close()
        
        resumen.append(f"✅ Archivos values.yaml en .gluon/cd/ creados: {gluon_values_created}/{len(gluon_values_files)} procesados")
    
    # PASO 7: Resumen de archivos de configuración creados (específico para frontend)
    config_json_created = any("✅" in result and "config.json" in result for result in resumen)
    step_7_results = ResponseFormatter.step_result(7, "Resumen creación archivos configuración", config_json_created, 
                                                   "Archivos de configuración frontend procesados" if config_json_created else "No se pudieron crear archivos de configuración frontend")
    resumen.extend(step_7_results)
    
    # Detalles específicos para frontend
    config_json_status = "✅" if config_json_created else "❌"
    cleanup_done = any("CLEANUP" in result and "✅" in result for result in resumen)
    cleanup_status = "✅" if cleanup_done else "⚠️"
    
    resumen.append(f"{config_json_status} Creación de config/cert/config.json: {'OK' if config_json_created else 'KO'}")
    if config_json_created:
        resumen.append(f"{cleanup_status} Eliminación de application-cert.properties: {'OK' if cleanup_done else 'Pendiente'}")
    
    logger.info("Proceso de edición de ConfigMap Frontend completado")
    return resumen
    
    return resumen


async def download_config_server_deployment(oam_data: Dict[str, Any], old_name: str, git_token: str, url_git_cm: str) -> Tuple[Optional[Dict], list, Dict[str, str]]:
    """
    Descarga el deployment del configuration-server desde OpenShift.
    
    Args:
        oam_data: Datos del archivo OAM
        old_name: Nombre del microservicio
        git_token: Token de GitHub
        url_git_cm: URL del repositorio de ConfigMaps
        
    Returns:
        Tuple[Optional[Dict], list, Dict[str, str]]: (deployment_data, resumen_info, config_files_in_memory)
    """
    resumen = []
    
    try:
        # Extraer namespace desde el OAM (usando certificación como referencia)
        target_namespace = extract_namespace_from_oam(oam_data)
        logger.debug(f"Namespace extraído del OAM: {target_namespace}")
        
        # Determinar configuración del cluster desde OAM
        cluster, region, cluster_type, api_server = determine_cluster_config_from_oam(oam_data)
        cluster_config = oam_data  # Pasamos el OAM completo para otras funciones que lo necesiten
        logger.debug(f"Configuración de cluster determinada: {cluster}/{region} ({cluster_type})")
        
        # Lista de nombres posibles para el deployment del config-server
        deployment_names = [
            f"configuration-service",
            f"config-service",
            f"config-server"
            f"configuration-server"
        ]
        
        found_deployment_name = None
        deployment_data = None
        
        # Intentar obtener deployment con cada nombre posible
        for deployment_name in deployment_names:
            logger.debug(f"Intentando obtener deployment: {deployment_name} en namespace: {target_namespace}")
            
            try:
                result_deployment, result_namespace, _ = await get_deployment_from_openshift(
                    deployment_name, 
                    target_namespace, 
                    cluster_config
                )
                
                if result_deployment:
                    found_deployment_name = deployment_name
                    deployment_data = result_deployment
                    logger.debug(f"Deployment encontrado: {deployment_name}")
                    break
                    
            except Exception as e:
                logger.debug(f"Deployment {deployment_name} no encontrado: {str(e)}")
                continue
        
        if not deployment_data:
            resumen.extend(format_step_result(2, "Descarga deployment config-server", False, f"No se encontró deployment en namespace {target_namespace}"))
            deployment_data = None
        else:
            resumen.extend(format_step_result(2, "Descarga deployment config-server", True, f"Deployment {found_deployment_name} encontrado"))
        
        # Paso 2.1: Extraer configuración Git del deployment
        config_files_in_memory = {}
        if deployment_data:
            try:
                git_uri, secret_name = extract_git_config_from_deployment(deployment_data)
                
                if git_uri and secret_name:
                    logger.info(f"Configuración Git extraída - URI: {git_uri}, Secret: {secret_name}")
                    
                    # Paso 2.2: Obtener SSH key del secret
                    ssh_key_base64 = await get_ssh_key_from_secret(secret_name, target_namespace, cluster_config)
                    
                    if ssh_key_base64:
                        logger.info("SSH key obtenida del secret")
                        
                        # Paso 2.3: Descargar repositorio de configuración
                        config_result = await download_config_repository(git_uri, ssh_key_base64, target_namespace)
                        
                        if config_result.get("success", False):
                            config_files_in_memory = config_result.get("config_files_in_memory", {})
                            resumen.append(f"✅ Archivos de configuración descargados: {len(config_files_in_memory)} archivos")
                            logger.info(f"Configuración descargada exitosamente: {list(config_files_in_memory.keys())}")
                            
                            # NO crear archivos aquí - se hará en el proceso específico (backend/frontend)
                            logger.info("� CREACIÓN DE ARCHIVOS se realizará en el proceso específico según el tipo detectado")
                            
                        else:
                            error_msg = config_result.get("error", "Error desconocido")
                            resumen.append(f"❌ Error descargando configuración: {error_msg}")
                            logger.error(f"Error descargando repositorio de configuración: {error_msg}")
                    else:
                        resumen.append(f"❌ No se pudo obtener SSH key del secret {secret_name}")
                        logger.warning(f"SSH key no disponible en secret {secret_name}")
                else:
                    resumen.append("⚠️ No se encontró configuración Git en el deployment")
                    logger.warning("URL Git o secret SSH no encontrados en deployment")
                    
            except Exception as e:
                error_msg = f"Error procesando configuración Git: {str(e)}"
                resumen.append(f"❌ {error_msg}")
                logger.error(error_msg)
        
        # Si todo fue bien y no hay mensajes de error, mostrar solo OK
        if deployment_data and not any('❌' in msg or '⚠️' in msg for msg in resumen):
            resumen = ["✅ PASO 2: OK"]
        
        # LOG CRÍTICO: Confirmar lo que se retorna
        logger.info(f"🔍 RETORNANDO: config_files_in_memory length: {len(config_files_in_memory)}")
        logger.info(f"🔍 RETORNANDO: config_files_in_memory keys: {list(config_files_in_memory.keys())}")
        
        return deployment_data, resumen, config_files_in_memory
        
    except Exception as e:
        error_msg = f"❌ Error descargando deployment config-server: {str(e)}"
        resumen.append(error_msg)
        logger.error(error_msg)
        return None, resumen, {}


async def create_config_files_from_downloaded_files(config_files_in_memory: Dict[str, str], old_name: str, git_token: str, url_git_cm: str, service_type: str = "backend", config_endpoint_filename: Optional[str] = None) -> str:
    """
    Orquestador principal para crear archivos de configuración en GitHub.
    Delega el trabajo a módulos especializados según el tipo de servicio.
    
    Args:
        config_files_in_memory: Archivos de configuración descargados
        old_name: Nombre del microservicio
        git_token: Token de GitHub
        url_git_cm: URL del repositorio de ConfigMaps
        service_type: Tipo de servicio ('backend' o 'frontend')
        config_endpoint_filename: Nombre específico del archivo CONFIG_END_POINT
        
    Returns:
        str: Mensaje de resultado de la creación de archivos
    """
    try:
        if not config_files_in_memory:
            logger.warning("⚠️ CREAR_ARCHIVOS_CONFIG: No hay archivos de configuración en memoria")
            return "⚠️ No hay archivos de configuración en memoria para procesar"
            
        logger.info(f"🔄 CREAR_ARCHIVOS_CONFIG: Iniciando orquestador con {len(config_files_in_memory)} archivos")
        logger.info(f"🔄 CREAR_ARCHIVOS_CONFIG: old_name='{old_name}', service_type='{service_type}'")
        
        # Importar módulos especializados
        from .CM_front_config import create_frontend_config_files
        from .CM_back_config import create_backend_config_files
        
        # Delegar según el tipo de servicio
        if service_type.lower() == "frontend":
            logger.info(f"🖥️ CREAR_ARCHIVOS_CONFIG: Delegando a módulo frontend")
            return await create_frontend_config_files(
                config_files_in_memory, old_name, git_token, url_git_cm, config_endpoint_filename
            )
        else:
            logger.info(f"⚙️ CREAR_ARCHIVOS_CONFIG: Delegando a módulo backend")
            return await create_backend_config_files(
                config_files_in_memory, old_name, git_token, url_git_cm
            )
        
    except ImportError as e:
        logger.error(f"❌ CREAR_ARCHIVOS_CONFIG: Error importando módulos especializados: {str(e)}")
        return f"❌ Error importando módulos de configuración: {str(e)}"
    except Exception as e:
        logger.error(f"❌ CREAR_ARCHIVOS_CONFIG: Error general en orquestador: {str(e)}")
        return f"❌ Error en orquestador de configuración: {str(e)}"


async def download_config_repository(git_uri: str, ssh_key_base64: str, namespace: str) -> Dict[str, Any]:
    """
    Descarga el repositorio de configuración usando SSH key del secret de OpenShift.
    
    Args:
        git_uri: URI del repositorio Git
        ssh_key_base64: SSH private key en formato base64
        namespace: Namespace donde se ejecuta
        
    Returns:
        Dict[str, Any]: Resultado con archivos de configuración en memoria y resumen
    """
    import base64
    from pathlib import Path
    
    resumen = []
    temp_dir = None
    ssh_key_file = None
    config_repo_dir = None
    
    try:
        resumen.append(f"\n--- DESCARGA REPOSITORIO CONFIGURACIÓN ---")
        
        # Crear directorio temporal para el proceso
        temp_dir = tempfile.mkdtemp(prefix=f"config_repo_{namespace}_")
        logger.debug(f"Directorio temporal creado: {temp_dir}")
        
        # Decodificar SSH private key
        try:
            ssh_private_key = base64.b64decode(ssh_key_base64).decode('utf-8')
        except Exception as e:
            resumen.append(f"❌ Error decodificando SSH key: {str(e)}")
            return {"success": False, "resumen": resumen}
        
        # Validar formato SSH key
        if not (ssh_private_key.startswith('-----BEGIN') and 'PRIVATE KEY' in ssh_private_key):
            resumen.append("❌ Formato SSH key inválido")
            return {"success": False, "resumen": resumen}
        
        # Crear archivo temporal para SSH key
        ssh_key_file = os.path.join(temp_dir, 'ssh_key')
        with open(ssh_key_file, 'w', encoding='utf-8') as f:
            f.write(ssh_private_key)
        os.chmod(ssh_key_file, 0o600)  # Permisos seguros
        
        # Crear directorio para el repositorio de configuración
        config_repo_dir = os.path.join(temp_dir, 'config_repo')
        os.makedirs(config_repo_dir, exist_ok=True)
        
        # Configurar comando Git con SSH key
        ssh_command = f'ssh -i "{ssh_key_file}" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null'
        clone_cmd = f'git clone "{git_uri}" "{config_repo_dir}"'
        
        # Ejecutar clonado con SSH key
        result = await run_git_command(
            clone_cmd, 
            temp_dir, 
            env={'GIT_SSH_COMMAND': ssh_command}
        )
        
        if result["success"]:
            resumen.append("✅ Repositorio clonado exitosamente")
            
            # Analizar contenido del repositorio
            try:
                files = list(Path(config_repo_dir).rglob("*"))
                file_count = len([f for f in files if f.is_file() and not f.parts[-2:-1] == ('.git',)])
                
                # Buscar archivos de configuración específicos
                config_files = [f for f in files if f.is_file() and 
                              any(ext in f.suffix.lower() for ext in ['.yml', '.yaml', '.properties', '.json']) and
                              not f.parts[-2:-1] == ('.git',)]
                
                # Leer archivos de configuración en memoria
                config_files_in_memory = {}
                
                for config_file in config_files:
                    try:
                        rel_path = config_file.relative_to(config_repo_dir)
                        file_key = rel_path.name  # Usar solo el nombre del archivo como clave
                        
                        # Leer contenido del archivo en memoria
                        with open(config_file, 'r', encoding='utf-8') as f:
                            file_content = f.read()
                        
                        config_files_in_memory[file_key] = file_content
                        logger.debug(f"Archivo leído en memoria: {file_key} ({len(file_content)} chars)")
                        
                    except Exception as read_error:
                        resumen.append(f"⚠️ Error leyendo {rel_path}: {str(read_error)}")
                
                resumen.append(f"✅ Archivos del config server descargados: {len(config_files_in_memory)} archivos")
                
                return {
                    "success": True,
                    "resumen": resumen,
                    "file_count": file_count,
                    "config_files_count": len(config_files),
                    "config_files_in_memory": config_files_in_memory
                }
                
            except Exception as analysis_error:
                resumen.append(f"❌ Error analizando repositorio: {str(analysis_error)}")
                return {"success": False, "resumen": resumen}
        
        else:
            resumen.append("❌ Error clonando repositorio de configuración:")
            resumen.append(f"   📤 stdout: {result.get('stdout', 'N/A')}")
            resumen.append(f"   📥 stderr: {result.get('stderr', 'N/A')}")
            return {"success": False, "resumen": resumen}
            
    except Exception as e:
        resumen.append(f"❌ Error general descargando repositorio config: {str(e)}")
        logger.error(f"Error en download_config_repository: {str(e)}")
        return {"success": False, "resumen": resumen}
        
    finally:
        # Limpiar SSH key de forma segura
        if ssh_key_file and os.path.exists(ssh_key_file):
            try:
                os.chmod(ssh_key_file, 0o600)
                os.remove(ssh_key_file)
                logger.debug("SSH key temporal eliminada de forma segura")
            except Exception as cleanup_error:
                logger.warning(f"No se pudo eliminar SSH key temporal: {cleanup_error}")
        
        # Limpiar directorio temporal
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
                logger.debug(f"Directorio temporal limpiado: {temp_dir}")
            except Exception as cleanup_error:
                logger.debug(f"No se pudo limpiar directorio temporal: {cleanup_error}")


async def run_git_command(command: str, working_dir: str, env: Dict[str, str] = None) -> Dict[str, Any]:
    """
    Ejecuta un comando git de forma asíncrona con soporte para variables de entorno.
    
    Args:
        command: Comando git a ejecutar
        working_dir: Directorio de trabajo
        env: Variables de entorno adicionales (opcional)
        
    Returns:
        Dict con el resultado de la ejecución
    """
    try:
        import subprocess
        
        # Combinar variables de entorno del sistema con las personalizadas
        full_env = os.environ.copy()
        if env:
            full_env.update(env)
        
        # Ejecutar comando
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            cwd=working_dir,
            env=full_env,
            timeout=60  # Aumentado a 60 segundos para clonado
        )
        
        if result.returncode == 0:
            return {
                "success": True,
                "output": result.stdout.strip(),
                "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip(),
                "error": None
            }
        else:
            return {
                "success": False,
                "output": result.stdout.strip(),
                "stdout": result.stdout.strip(),
                "stderr": result.stderr.strip(),
                "error": result.stderr.strip()
            }
            
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "output": "",
            "error": "Comando git timeout (>30s)"
        }
    except Exception as e:
        return {
            "success": False,
            "output": "",
            "error": f"Error ejecutando comando: {str(e)}"
        }


def extract_git_config_from_deployment(deployment_data: Dict[str, Any]) -> tuple[str, str]:
    """
    Extrae la URL de Git y el nombre del secret con SSH key del deployment del config-server.
    
    Args:
        deployment_data: Datos del deployment del config-server
        
    Returns:
        tuple[str, str]: (git_uri, secret_name) o (None, None) si no se encuentra
    """
    try:
        git_uri = None
        secret_name = None
        
        # Buscar en las variables de entorno del deployment
        containers = deployment_data.get('spec', {}).get('template', {}).get('spec', {}).get('containers', [])
        
        for container in containers:
            env_vars = container.get('env', [])
            
            for env_var in env_vars:
                env_name = env_var.get('name', '')
                env_value = env_var.get('value', '')
                value_from = env_var.get('valueFrom', {})
                
                # Buscar la URL de Git del config server
                if env_name in ['SPRING_CLOUD_CONFIG_SERVER_GIT_URI', 'spring.cloud.config.server.git.uri']:
                    git_uri = env_value
                    logger.info(f"URL Git encontrada en {env_name}: {git_uri}")
                
                # Buscar el nombre del secret con SSH key
                if env_name in ['SPRING_CLOUD_CONFIG_SERVER_GIT_PRIVATE_KEY', 'spring.cloud.config.server.git.private.key', 'SPRING_CLOUD_CONFIG_SERVER_GIT_PRIVATEKEY']:
                    if env_value:
                        # Valor directo
                        secret_name = env_value
                        logger.info(f"Secret SSH encontrado en {env_name}: {secret_name}")
                    elif value_from and 'secretKeyRef' in value_from:
                        # Valor desde secretKeyRef
                        secret_name = value_from['secretKeyRef'].get('name', '')
                        logger.info(f"Secret SSH encontrado en {env_name} (secretKeyRef): {secret_name}")
                    else:
                        logger.debug(f"Variable {env_name} no tiene valor ni secretKeyRef")
        
        # También buscar en volumeMounts y volumes por si la key viene de un secret montado
        if not secret_name:
            volumes = deployment_data.get('spec', {}).get('template', {}).get('spec', {}).get('volumes', [])
            for volume in volumes:
                if volume.get('secret') and 'git' in volume.get('name', '').lower():
                    secret_name = volume.get('secret', {}).get('secretName', '')
                    logger.info(f"Secret SSH encontrado en volume: {secret_name}")
                    break
        
        return git_uri, secret_name
        
    except Exception as e:
        logger.error(f"Error extrayendo configuración Git del deployment: {str(e)}")
        return None, None


async def get_ssh_key_from_secret(secret_name: str, namespace: str, cluster_config: Dict[str, Any]) -> str:
    """
    Obtiene la SSH private key desde un secret de OpenShift.
    
    Args:
        secret_name: Nombre del secret
        namespace: Namespace donde está el secret
        cluster_config: Configuración del cluster
        
    Returns:
        str: SSH private key en base64 o None si no se encuentra
    """
    try:
        logger.info(f"Obteniendo secret {secret_name} del namespace {namespace}")
        
        secret_data = await get_secret_from_openshift(secret_name, namespace, cluster_config)
        
        if not secret_data:
            logger.warning(f"Secret {secret_name} no encontrado")
            return None
        
        # Buscar la SSH key en el secret (posibles nombres de campos)
        data = secret_data.get('data', {})
        
        for key_name in ['ssh-privatekey', 'id_rsa', 'private-key', 'key']:
            if key_name in data:
                ssh_key_base64 = data[key_name]
                logger.info(f"SSH key encontrada en campo '{key_name}'")
                return ssh_key_base64
        
        logger.warning(f"No se encontró SSH key en el secret {secret_name}")
        return None
        
    except Exception as e:
        logger.error(f"Error obteniendo SSH key del secret {secret_name}: {str(e)}")
        return None