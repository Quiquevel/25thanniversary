"""
Orquestador del sistema de migración de microservicios FRONTEND.
Este archivo actúa como coordinador para microservicios frontend (con nginx/package.json).

ARQUITECTURA MODULAR FRONTEND:
- github/: Operaciones GitHub especializadas (reutilizadas de back_values)
- openshift/: Procesamiento de deployments y OAM de OpenShift (reutilizado)
- file_processors/: Modificación de archivos específicos (Dockerfile con nginx)  
- front_values.py: Orquestador principal para FRONTEND
- common_utils.py: Funciones compartidas incluyendo detect_microservice_type()

DETECCIÓN DE TIPO DE MICROSERVICIO:
La función detect_microservice_type() se encuentra ahora en common_utils.py para evitar confusión
y permitir su uso desde cualquier módulo.

DIFERENCIAS CON BACKEND:
- Dockerfile usa imagen nginx del launch.json en lugar de Java
- Mismos archivos: values.{env}.yaml, values.yaml, cd.yaml
- Misma lógica pero adaptada para frontend
"""
import os
from datetime import datetime
from typing import Dict, Any
from shuttlelib.utils.logger import logger
from src.utils.proxy_config import get_proxy_config
import aiohttp
from .respuestas import ResponseFormatter

# Importar módulos especializados (reutilizados)
from .github.operations import (
    backup_development_branch,
    backup_pulse_import_branch,
    modify_values_file_optimized,
    modify_cd_yml_comprehensive
)

from .github_client import GitHubClient

from .openshift import (
    get_deployment_from_openshift,
    get_oam_from_git,
    DeploymentData
)

from .file_processors import (
    modify_dockerfile,
    modify_pom_file  # No se usará en front, pero se importa por compatibilidad
)

from .common_utils import validate_and_update_dockerfile_with_api_versions, detect_microservice_type

# Instancia global para compatibilidad con el código existente
front_deployment_data = DeploymentData()


async def update_front_microservice_values(
    old_name: str,
    git_token: str,
    url_git: str,
    url_oam: str
) -> str:
    """Orquestador principal FRONTEND (nginx + package.json).

    OBJETIVO:
    - Respaldar ramas base (development, pulse-import)
    - Obtener OAM y namespace
    - (Opcional) Obtener deployment para extra env vars (frontend suele necesitar menos)
    - Modificar y generar archivos de values / cd / nginx / Dockerfile / package.json / package-lock.json
    - Limpiar valores originales redundantes

    OPTIMIZACIÓN APLICADA (alineada con backend):
    - Reutilización de UNA sola sesión para ambos backups (reduce overhead TLS)
    - Reutilización de UNA sola sesión para todas las modificaciones y validaciones
    - Métricas de tiempo (backups, modificaciones, limpieza, total) para futura observabilidad
    - No se altera firma pública ni formato de salida ya consumido externamente

    PENDIENTE (no incluido para mantener riesgo bajo): paralelización `asyncio.gather` y semaphore.

    Args:
        old_name: Nombre actual del deployment
        git_token: Token de autenticación de GitHub
        url_git: URL del repositorio Git
        url_oam: URL del archivo OAM

    Returns:
        str: Texto plano con el progreso paso a paso de la operación
    """
    response_text = []
    response_text.append(f"🎯 MIGRACIÓN FRONT: {old_name}")
    response_text.append("")
    
    try:
        logger.info(f"=== INICIANDO MIGRACIÓN MODULAR DE MICROSERVICIO FRONT ===")
        logger.info(f"Deployment: {old_name}")
        
        # Validar y convertir URL del repositorio
        from .common_utils import extract_repo_info
        
        try:
            owner, repo = extract_repo_info(url_git)
        except ValueError as e:
            response_text.append(f"❌ VALIDACIÓN URL GIT: KO - {str(e)}")
            return "\n".join(response_text)
        repo_api_url = f"https://api.github.com/repos/{owner}/{repo}"
        response_text.append(f"✅ VALIDACIÓN URL GIT: OK - {owner}/{repo}")
        
        # La imagen nginx ahora se valida automáticamente con la API de versiones
        response_text.append(f"📦 IMAGEN NGINX: Se validará automáticamente con API de versiones")
        logger.info("Imagen nginx se determinará del Dockerfile actual y se validará con API")
        
        proxy_config = get_proxy_config()
        
        # PASO 0: Verificar que es realmente un microservicio FRONT
        response_text.append("")
        response_text.append("--- PASO 0: VERIFICACIÓN TIPO MICROSERVICIO ---")
        
        async with aiohttp.ClientSession(**proxy_config) as session:
            microservice_type = await detect_microservice_type(session, owner, repo, git_token)
            
            if microservice_type not in ["FRONT", "FRONTEND"]:
                response_text.append(f"❌ VERIFICACIÓN TIPO: KO - Detectado como {microservice_type}, no es FRONT/FRONTEND")
                response_text.append("Este orquestador solo procesa microservicios FRONT/FRONTEND (con nginx/package.json)")
                return "\n".join(response_text)
            
            response_text.append(f"✅ VERIFICACIÓN TIPO: OK - Confirmado como microservicio {microservice_type}")
        
        # PASOS 1/2 combinados: Backups con una sola sesión
        import time
        t_total_start = time.perf_counter()
        response_text.append("")
        response_text.append("--- PASO 1 / 2: BACKUPS development y pulse-import (sesión reutilizada) ---")
        t_backups_start = time.perf_counter()
        async with aiohttp.ClientSession(**proxy_config) as session:
            # Development
            success_dev = await backup_development_branch(session, owner, repo, git_token, old_name)
            if not success_dev:
                response_text.append("❌ BACKUP DEVELOPMENT: KO - Error en el respaldo")
                response_text.append("💥 EJECUCIÓN ABORTADA: El backup de development es obligatorio para microservicios Front")
                return "\n".join(response_text)
            response_text.append("✅ BACKUP DEVELOPMENT: OK - Rama respaldada correctamente")
            # Pulse-import
            success_pi, branch_status = await backup_pulse_import_branch(session, owner, repo, git_token, old_name, is_configmap=False)
            if not success_pi:
                response_text.append(f"❌ BACKUP PULSE-IMPORT: KO - {branch_status}")
                response_text.append("💥 EJECUCIÓN ABORTADA: El backup de pulse-import es obligatorio para microservicios Front")
                return "\n".join(response_text)
            response_text.append(f"✅ BACKUP PULSE-IMPORT: OK - {branch_status}")
        t_backups_end = time.perf_counter()
        response_text.append(f"⏱️ DURACIÓN BACKUPS: {t_backups_end - t_backups_start:.2f}s")
        
        # PASO 3: Obtener OAM usando módulo OpenShift especializado
        response_text.append("")
        response_text.append("--- PASO 3: OBTENER ARCHIVO OAM [módulo: openshift/processor] ---")
        
        try:
            # Normalizar URL OAM antes de procesarla
            from .common_utils import normalize_oam_url
            normalized_url_oam = normalize_oam_url(url_oam)
            response_text.append(f"URL OAM normalizada: {normalized_url_oam}")
            
            oam_yaml = await get_oam_from_git(normalized_url_oam, git_token)
            response_text.append("✅ OBTENER OAM: OK - Archivo procesado")
        except Exception as e:
            response_text.append(f"❌ OBTENER OAM: KO - {str(e)}")
            return "\n".join(response_text)
        
        # PASO 3.1: Extraer namespace del OAM (igual que en back)
        response_text.append("")
        response_text.append("--- PASO 3.1: EXTRAER NAMESPACE DEL OAM ---")
        
        namespace = None
        
        # Intentar extraer del formato con raw_data (formato principal)
        if oam_yaml and 'raw_data' in oam_yaml and 'environments' in oam_yaml['raw_data']:
            for env in oam_yaml['raw_data']['environments']:
                if 'infrastructures' in env:
                    for infra in env['infrastructures']:
                        if 'properties' in infra and 'namespace' in infra['properties']:
                            namespace = infra['properties']['namespace']
                            break
                    if namespace:
                        break
        
        # Si no se encuentra en raw_data, intentar en el formato directo (fallback)
        if not namespace and oam_yaml and 'environments' in oam_yaml:
            for env in oam_yaml['environments']:
                if 'infrastructures' in env:
                    for infra in env['infrastructures']:
                        if 'properties' in infra and 'namespace' in infra['properties']:
                            namespace = infra['properties']['namespace']
                            break
                    if namespace:
                        break
        
        if not namespace:
            response_text.append("❌ EXTRAER NAMESPACE: KO - No se encontró namespace en el OAM")
            return "\n".join(response_text)
        
        # Importar función para limpiar namespace
        from .openshift.processor import _clean_namespace
        clean_namespace_extracted = _clean_namespace(namespace)
        
        response_text.append(f"✅ EXTRAER NAMESPACE: OK - {namespace} → {clean_namespace_extracted}")
        response_text.append(f"📍 NAMESPACE DETECTADO: {clean_namespace_extracted}")
        
        # Actualizar el log con el namespace detectado
        logger.info(f"Namespace extraído del OAM para FRONT: {namespace} → {clean_namespace_extracted}")
        
        # PASO 4: Obtener deployment usando módulo OpenShift especializado
        response_text.append("")
        response_text.append("--- PASO 4: OBTENER DEPLOYMENT [módulo: openshift/processor] ---")
        
        try:
            deployment_yaml, clean_namespace, _ = await get_deployment_from_openshift(
                old_name, clean_namespace_extracted, oam_yaml
            )
            
            # Asegurar que clean_namespace tenga un valor válido incluso si deployment es None
            if not clean_namespace:
                clean_namespace = clean_namespace_extracted
            
            # Verificar si se obtuvo el deployment o ya fue eliminado
            if deployment_yaml:
                response_text.append("✅ OBTENER DEPLOYMENT: OK - Deployment procesado")
            else:
                response_text.append(f"⚠️ OBTENER DEPLOYMENT: Ya eliminado - {old_name} no existe en OpenShift (posiblemente migrado previamente)")
                logger.warning(f"Deployment {old_name} ya fue eliminado, continuando sin obtener configuración de deployment")
                
        except Exception as e:
            response_text.append(f"❌ OBTENER DEPLOYMENT: KO - {str(e)}")
            # Asegurar que clean_namespace y deployment_yaml tengan valores para continuar
            clean_namespace = clean_namespace_extracted
            deployment_yaml = None  # Inicializar como None para evitar errores
            # NO retornar aquí - continuar con el flujo para modificar archivos .gluon
            logger.warning(f"Error obteniendo deployment, pero continuando con modificaciones de archivos: {str(e)}")
        
        # PASO 4.1: Determinar configuración del cluster desde el OAM (igual que back)
        response_text.append("")
        response_text.append("--- PASO 4.1: DETERMINAR CONFIGURACIÓN DEL CLUSTER ---")
        
        from .openshift.processor import determine_cluster_config_from_oam
        from .common_utils import get_environment_mapping
        
        # Obtener mapeo automático de entornos desde el OAM
        env_mapping = get_environment_mapping({'raw_data': oam_yaml} if oam_yaml else None)
        dev_env_name = env_mapping.get('dev', 'cert')  # Por defecto 'cert' si no se detecta
        
        cluster, region, cluster_type, api_server = determine_cluster_config_from_oam(
            oam_yaml, dev_env_name, clean_namespace_extracted
        )
        
        response_text.append(f"✅ CONFIGURACIÓN CLUSTER: OK")
        response_text.append(f"   └─ Entorno OAM: {dev_env_name} (mapeado desde 'dev')")
        response_text.append(f"   └─ Cluster: {cluster}")
        response_text.append(f"   └─ Región: {region}")
        response_text.append(f"   └─ Tipo: {cluster_type}")
        response_text.append(f"   └─ API Server: {api_server[:50]}..." if len(api_server) > 50 else f"   └─ API Server: {api_server}")
        
        logger.info(f"Configuración cluster detectada para FRONT: cluster={cluster}, region={region}, type={cluster_type}")

        # PASO 5: Almacenar datos en el objeto global para compatibilidad
        front_deployment_data.set_deployment(deployment_yaml)
        front_deployment_data.set_oam(oam_yaml)
        front_deployment_data.namespace = clean_namespace_extracted
        front_deployment_data.old_name = old_name
        
        # Para FRONT no hay java_opts_ext, usamos configuración de nginx
        java_opts_ext = ""  # Vacío para front
        
        # PASO 6: Modificar archivos usando módulos especializados
        response_text.append("")
        response_text.append("--- PASO 5: MODIFICAR ARCHIVOS FRONT [módulo: file_processors/handlers] ---")
        modification_results = []
        t_mods_start = time.perf_counter()
        async with aiohttp.ClientSession(**proxy_config) as session:
            # Modificar nginx/default.conf
            result_nginx_config = await modify_nginx_default_conf(
                session, owner, repo, git_token, old_name, clean_namespace_extracted
            )
            modification_results.append(result_nginx_config)
            response_text.append(f"   {'✅' if result_nginx_config else '❌'} nginx/default.conf: {'OK' if result_nginx_config else 'KO'}")
            
            # Resto de modificaciones...
            # Modificar values.yaml principal (FRONTEND: plantilla específica)
            logger.info("Modificando .gluon/cd/values.yaml para FRONT (plantilla específica)")
            result_values = await modify_frontend_main_values_file(
                session, url_git, git_token, old_name, clean_namespace, java_opts_ext,
                region, ".gluon/cd/values.yaml", oam_yaml, deployment_yaml
            )
            modification_results.append(result_values)
            response_text.append(f"   {'✅' if result_values else '❌'} values.yaml: {'OK' if result_values else 'KO'}")
            
            # Modificar archivos values específicos de entorno (FRONTEND: renombrados con sufijo)
            for env_suffix in ['cert', 'pre', 'pro']:
                logger.info(f"Modificando values-{env_suffix}.yaml para FRONT (renombrado)")
                result_env = await modify_frontend_values_file(
                    session, url_git, git_token, old_name, clean_namespace, java_opts_ext,
                    region, f".gluon/cd/{env_suffix}/values-{env_suffix}.yaml", oam_yaml, deployment_yaml, env_suffix
                )
                modification_results.append(result_env)
                response_text.append(f"   {'✅' if result_env else '❌'} values-{env_suffix}.yaml: {'OK' if result_env else 'KO'}")
            
            # Modificar archivos cd.yml específicos de entorno (FRONTEND: referencias actualizadas)
            for env_suffix in ['cert', 'pre', 'pro']:
                logger.info(f"🔄 Iniciando modificación cd.yml para {env_suffix} (FRONT)")
                logger.info(f"   - Archivo: .gluon/cd/{env_suffix}/cd.yml")
                logger.info(f"   - OAM disponible: {'Sí' if oam_yaml else 'No'}")
                logger.info(f"   - Deployment disponible: {'Sí' if deployment_yaml else 'No'}")
                
                result_cd = await modify_frontend_cd_file(
                    session, url_git, git_token, old_name, clean_namespace, java_opts_ext,
                    region, f".gluon/cd/{env_suffix}/cd.yml", oam_yaml, deployment_yaml, env_suffix
                )
                
                modification_results.append(result_cd)
                logger.info(f"✅ Resultado cd.yml {env_suffix}: {'ÉXITO' if result_cd else 'FALLO'}")
                response_text.append(f"   {'✅' if result_cd else '❌'} cd-{env_suffix}.yml: {'OK' if result_cd else 'KO'}")
            
            # Validar y actualizar Dockerfile con versiones más recientes de la API (FRONT - nginx)
            logger.info("Validando y actualizando Dockerfile para FRONT (nginx) con API")
            try:
                from .github_client import GitHubClient
                github_client = GitHubClient(git_token, session)
                
                # Usar función especializada para frontend nginx
                logger.info(f"🔄 Iniciando validación especializada nginx FRONT para {owner}/{repo}")
                api_validation_result = await validate_and_update_dockerfile_frontend_nginx(
                    github_client, owner, repo
                )
                
                logger.info(f"🔍 Resultado API FRONT: success={api_validation_result['success']}, error={api_validation_result.get('error')}")
                
                if api_validation_result['success']:
                    if api_validation_result['updated']:
                        response_text.append(f"   ✅ Dockerfile (nginx API): Actualizado {api_validation_result['image_name']} de {api_validation_result['current_version']} a {api_validation_result['latest_version']}")
                    else:
                        response_text.append(f"   ✅ Dockerfile (nginx API): {api_validation_result['image_name']}:{api_validation_result['current_version']} ya está actualizado")
                    modification_results.append(True)
                else:
                    logger.error(f"❌ Validación API FRONT falló: {api_validation_result.get('error', 'Error desconocido')}")
                    # NO usar fallback - fallar limpiamente
                    response_text.append(f"   ❌ Dockerfile (nginx API): Error - {api_validation_result.get('error', 'Error desconocido')}")
                    modification_results.append(False)
                    
            except Exception as e:
                logger.error(f"❌ Error crítico en validación de Dockerfile FRONT con API: {str(e)}")
                response_text.append(f"   ❌ Dockerfile (nginx API): Error crítico - {str(e)}")
                modification_results.append(False)
            
            # Validar y corregir versión en package.json
            logger.info("Validando versión en package.json")
            result_package = await validate_and_fix_package_version(
                session, owner, repo, git_token
            )
            modification_results.append(result_package)
            response_text.append(f"   {'✅' if result_package else '❌'} package.json (versión): {'OK' if result_package else 'KO'}")
            
            # Validar y corregir versión en package-lock.json
            logger.info("Validando versión en package-lock.json")
            result_package_lock = await validate_and_fix_packagelock_version(
                session, owner, repo, git_token
            )
            modification_results.append(result_package_lock)
            response_text.append(f"   {'✅' if result_package_lock else '❌'} package-lock.json (versión): {'OK' if result_package_lock else 'KO'}")
        
        # PASO 6: Eliminar archivos values.yaml originales (mantenemos nueva sesión separada para aislamiento)
        response_text.append("")
        response_text.append("--- PASO 6: LIMPIAR ARCHIVOS ORIGINALES [FRONTEND] ---")
        t_clean_start = time.perf_counter()
        async with aiohttp.ClientSession(**proxy_config) as session:
            delete_result = await delete_original_frontend_values_files(session, url_git, git_token)
        t_clean_end = time.perf_counter()
        if delete_result.get("status") == "completed":
            summary = delete_result.get("summary", {})
            deleted = summary.get("deleted", 0)
            not_found = summary.get("not_found", 0)
            errors = summary.get("errors", 0)
            if errors == 0:
                response_text.append(f"✅ LIMPIEZA ARCHIVOS: OK - {deleted} eliminados, {not_found} no encontrados")
                modification_results.append(True)
            else:
                response_text.append(f"⚠️ LIMPIEZA ARCHIVOS: PARCIAL - {deleted} eliminados, {errors} errores")
                modification_results.append(False)
        else:
            response_text.append(f"❌ LIMPIEZA ARCHIVOS: KO - {delete_result.get('message', 'Error desconocido')}")
            modification_results.append(False)

        t_mods_end = time.perf_counter()
        t_total_end = time.perf_counter()

        # PASO 7: Generar resumen final con métricas
        response_text.append("")
        response_text.append("=== RESUMEN FINAL DE MIGRACIÓN FRONT ===")
        response_text.append(f"⏱️ TIEMPOS: backups={t_backups_end - t_backups_start:.2f}s | modificaciones={t_mods_end - t_mods_start:.2f}s | limpieza={t_clean_end - t_clean_start:.2f}s | total={t_total_end - t_total_start:.2f}s")

        success_count = sum(modification_results)
        total_count = len(modification_results)

        if success_count == total_count:
            response_text.append(f"🎉 MIGRACIÓN FRONT COMPLETADA: {success_count}/{total_count} archivos procesados exitosamente")
        else:
            response_text.append(f"⚠️  MIGRACIÓN FRONT PARCIAL: {success_count}/{total_count} archivos procesados")

        response_text.append("")
        response_text.append("🎯 DATOS DE LA MIGRACIÓN FRONT PROCESADA:")
        response_text.append(f"   ├─ Deployment: {old_name}")
        response_text.append(f"   ├─ Namespace: {clean_namespace_extracted} → {clean_namespace}")
        response_text.append(f"   ├─ Cluster: {cluster} ({cluster_type})")
        response_text.append(f"   ├─ Región: {region}")
        response_text.append(f"   ├─ Imagen nginx: API/Default")
        response_text.append(f"   ├─ Repositorio: {owner}/{repo}")
        response_text.append(f"   └─ Tipo: MICROSERVICIO FRONTEND")

        return "\n".join(response_text)
        
    except Exception as e:
        response_text.append("")
        response_text.append(f"❌ ERROR CRÍTICO EN ORQUESTADOR FRONT: {str(e)}")
        logger.error(f"Error crítico en orquestador FRONT: {str(e)}")
        return "\n".join(response_text)






async def validate_and_fix_package_version(
    session: aiohttp.ClientSession,
    owner: str,
    repo: str,
    git_token: str
) -> bool:
    """
    Valida y corrige la versión en package.json para que esté en formato X.X.X.
    Si no está en formato correcto, la cambia a 1.0.0.
    
    Args:
        session: Sesión HTTP aiohttp
        owner: Propietario del repositorio
        repo: Nombre del repositorio
        git_token: Token de GitHub
        
    Returns:
        bool: True si la validación/corrección fue exitosa, False en caso contrario
    """
    try:
        import json
        import re
        
        github_client = GitHubClient(git_token, session)
        
        # Obtener contenido actual del package.json
        result = await github_client.get_file_content(
            owner, repo, 'package.json', "feature/gluon-migration-config-from-pulse-import"
        )
        
        if not result:
            logger.info(f"package.json no encontrado en {owner}/{repo}, omitiendo validación de versión")
            return True  # No es un error si no existe
        
        content, file_sha = result
        logger.info(f"package.json encontrado en {owner}/{repo}")
        
        # Parsear el JSON
        try:
            package_data = json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(f"Error parseando package.json en {owner}/{repo}: {e}")
            return False
        
        # Obtener versión actual
        current_version = package_data.get('version', '')
        if not current_version:
            logger.warning(f"No se encontró campo 'version' en package.json de {owner}/{repo}")
            return False
        
        # Validar formato X.X.X (donde X son números)
        version_pattern = r'^\d+\.\d+\.\d+$'
        is_valid_format = re.match(version_pattern, current_version)
        
        if is_valid_format:
            logger.info(f"Versión {current_version} ya está en formato correcto X.X.X, no se requieren cambios")
            return True
        
        # La versión no está en formato correcto, cambiarla a 1.0.0
        logger.info(f"Versión actual '{current_version}' no está en formato X.X.X, cambiando a '1.0.0'")
        
        package_data['version'] = '1.0.0'
        
        # Convertir de vuelta a JSON con formato bonito
        updated_content = json.dumps(package_data, indent=2, ensure_ascii=False)
        
        # Actualizar el archivo en GitHub
        update_result = await github_client.update_file(
            owner, repo, 'package.json', updated_content, file_sha,
            f"Fix package.json version format: {current_version} → 1.0.0"
        )
        
        if update_result.get("status") == "success":
            logger.info(f"package.json actualizado correctamente: versión {current_version} → 1.0.0")
            return True
        else:
            logger.error(f"Error al actualizar package.json en {owner}/{repo}: {update_result.get('error')}")
            return False
            
    except Exception as e:
        logger.error(f"Error en validate_and_fix_package_version: {str(e)}")
        return False


async def validate_and_fix_packagelock_version(
    session: aiohttp.ClientSession,
    owner: str,
    repo: str,
    git_token: str
) -> bool:
    """
    Valida y corrige la versión en package-lock.json para que esté en formato X.X.X.
    Si no está en formato correcto, la cambia a 1.0.0.
    
    Args:
        session: Sesión HTTP aiohttp
        owner: Propietario del repositorio
        repo: Nombre del repositorio
        git_token: Token de GitHub
        
    Returns:
        bool: True si la validación/corrección fue exitosa, False en caso contrario
    """
    try:
        import json
        import re
        
        github_client = GitHubClient(git_token, session)
        
        # Obtener contenido actual del package-lock.json
        result = await github_client.get_file_content(
            owner, repo, 'package-lock.json', "feature/gluon-migration-config-from-pulse-import"
        )
        
        if not result:
            logger.info(f"package-lock.json no encontrado en {owner}/{repo}, omitiendo validación de versión")
            return True  # No es un error si no existe
        
        content, file_sha = result
        logger.info(f"package-lock.json encontrado en {owner}/{repo}")
        
        # Parsear el JSON
        try:
            package_lock_data = json.loads(content)
        except json.JSONDecodeError as e:
            logger.error(f"Error parseando package-lock.json en {owner}/{repo}: {e}")
            return False
        
        # Obtener versión actual del nivel raíz
        current_version = package_lock_data.get('version', '')
        if not current_version:
            logger.warning(f"No se encontró campo 'version' en package-lock.json de {owner}/{repo}")
            return False
        
        # Validar formato X.X.X (donde X son números)
        version_pattern = r'^\d+\.\d+\.\d+$'
        is_valid_format = re.match(version_pattern, current_version)
        
        # Verificar si necesita actualización
        needs_update = False
        
        if not is_valid_format:
            logger.info(f"Versión raíz '{current_version}' no está en formato X.X.X, cambiando a '1.0.0'")
            package_lock_data['version'] = '1.0.0'
            needs_update = True
        
        # También actualizar la versión en packages[""]
        if 'packages' in package_lock_data and '' in package_lock_data['packages']:
            packages_version = package_lock_data['packages'][''].get('version', '')
            if packages_version and not re.match(version_pattern, packages_version):
                logger.info(f"Versión en packages[\"\"] '{packages_version}' no está en formato X.X.X, cambiando a '1.0.0'")
                package_lock_data['packages']['']['version'] = '1.0.0'
                needs_update = True
        
        if not needs_update:
            logger.info(f"Versión {current_version} ya está en formato correcto X.X.X, no se requieren cambios")
            return True
        
        # Convertir de vuelta a JSON con formato bonito
        updated_content = json.dumps(package_lock_data, indent=2, ensure_ascii=False)
        
        # Actualizar el archivo en GitHub
        update_result = await github_client.update_file(
            owner, repo, 'package-lock.json', updated_content, file_sha,
            f"Fix package-lock.json version format: {current_version} → 1.0.0"
        )
        
        if update_result.get("status") == "success":
            logger.info(f"package-lock.json actualizado correctamente: versión {current_version} → 1.0.0")
            return True
        else:
            logger.error(f"Error al actualizar package-lock.json en {owner}/{repo}: {update_result.get('error')}")
            return False
            
    except Exception as e:
        logger.error(f"Error en validate_and_fix_packagelock_version: {str(e)}")
        return False


async def modify_frontend_main_values_file(
    session: aiohttp.ClientSession,
    repo_url: str,
    git_token: str,
    old_name: str,
    namespace: str,
    java_opts_ext: str,
    region: str,
    file_path: str,
    oam_data: dict,
    deployment_yaml: dict
) -> bool:
    """
    Modifica el archivo values.yaml principal específico para frontend con plantilla Angular.
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre del servicio
        namespace: Namespace limpio
        java_opts_ext: Opciones Java (no usado en frontend)
        region: Región
        file_path: Ruta del archivo values principal
        oam_data: Datos del OAM
        deployment_yaml: Deployment de OpenShift
        
    Returns:
        bool: True si fue exitoso
    """
    try:
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner/repo de la URL usando la función unificada
        from src.services.common_utils import extract_repo_info
        try:
            owner, repo = extract_repo_info(repo_url)
            logger.info(f"Procesando {file_path} en {owner}/{repo} (FRONTEND MAIN)")
        except ValueError as e:
            logger.error(f"No se pudo extraer owner/repo de la URL: {repo_url}. Error: {e}")
            return False
        
        # Construir URL del repositorio para gitRepo
        git_repo_url = f"https://github.com/{owner}/{repo}.git"
        
        # Extraer path del repositorio para image.repository
        git_repo_path = f"{owner}/{repo}"
        
        # Extraer variables de entorno del deployment de OpenShift
        extra_env_vars = []
        if deployment_yaml:
            extra_env_vars = _extract_env_vars_from_deployment_frontend(deployment_yaml)
            logger.info(f"Extraídas {len(extra_env_vars)} variables de entorno del deployment para frontend main")
        
        # Obtener contenido actual
        result = await github_client.get_file_content(owner, repo, file_path, "feature/gluon-migration-config-from-pulse-import")
        
        if not result:
            # Crear archivo inicial usando plantilla específica de frontend
            content = _create_frontend_main_values_content(
                old_name, namespace, region, git_repo_url, git_repo_path, extra_env_vars
            )
            
            create_result = await github_client.update_file(
                owner, repo, file_path, content, None,
                f"Create frontend main {file_path} for {namespace} migration [ci skip]"
            )
            
            if create_result.get("status") == "success":
                logger.info(f"Archivo frontend main {file_path} creado exitosamente")
                return True
            else:
                logger.error(f"Error al crear archivo frontend main {file_path}: {create_result.get('error')}")
                return False
        else:
            # Actualizar archivo existente
            content, file_sha = result
            updated_content = _update_frontend_main_values_content(
                content, git_repo_url, git_repo_path, region, extra_env_vars
            )
            
            update_result = await github_client.update_file(
                owner, repo, file_path, updated_content, file_sha,
                f"Update frontend main {file_path} with Angular template [ci skip]"
            )
            
            if update_result.get("status") == "success":
                logger.info(f"Archivo frontend main {file_path} actualizado exitosamente")
                return True
            else:
                logger.error(f"Error al actualizar archivo frontend main {file_path}: {update_result.get('error')}")
                return False
                
    except Exception as e:
        logger.error(f"Error en modify_frontend_main_values_file: {str(e)}")
        return False


async def modify_frontend_values_file(
    session: aiohttp.ClientSession,
    repo_url: str,
    git_token: str,
    old_name: str,
    namespace: str,
    java_opts_ext: str,
    region: str,
    file_path: str,
    oam_data: dict,
    deployment_yaml: dict,
    env_suffix: str
) -> bool:
    """
    Modifica archivos values-{env}.yaml específicos para frontend con variables de OpenShift.
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre del servicio
        namespace: Namespace limpio
        java_opts_ext: Opciones Java (no usado en frontend)
        region: Región
        file_path: Ruta del archivo values
        oam_data: Datos del OAM
        deployment_yaml: Deployment de OpenShift
        env_suffix: Sufijo del entorno (cert, pre, pro)
        
    Returns:
        bool: True si fue exitoso
    """
    try:
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner/repo de la URL usando la función unificada
        from src.services.common_utils import extract_repo_info
        try:
            owner, repo = extract_repo_info(repo_url)
            logger.info(f"Procesando {file_path} en {owner}/{repo} (FRONTEND)")
        except ValueError as e:
            logger.error(f"No se pudo extraer owner/repo de la URL: {repo_url}. Error: {e}")
            return False
        
        # Extraer variables de entorno del deployment de OpenShift
        extra_env_vars = []
        if deployment_yaml:
            extra_env_vars = _extract_env_vars_from_deployment_frontend(deployment_yaml)
            logger.info(f"Extraídas {len(extra_env_vars)} variables de entorno del deployment para frontend")
        
        # Obtener contenido actual
        result = await github_client.get_file_content(owner, repo, file_path, "feature/gluon-migration-config-from-pulse-import")
        
        if not result:
            # Crear archivo inicial usando plantilla específica de frontend
            content = _create_frontend_values_content(env_suffix, extra_env_vars)
            
            create_result = await github_client.update_file(
                owner, repo, file_path, content, None,
                f"Create frontend {file_path} for {namespace} migration [ci skip]"
            )
            
            if create_result.get("status") == "success":
                logger.info(f"Archivo frontend {file_path} creado exitosamente")
                return True
            else:
                logger.error(f"Error al crear archivo frontend {file_path}: {create_result.get('error')}")
                return False
        else:
            # Actualizar archivo existente
            content, file_sha = result
            updated_content = _update_frontend_values_content(content, extra_env_vars, env_suffix)
            
            update_result = await github_client.update_file(
                owner, repo, file_path, updated_content, file_sha,
                f"Update frontend {file_path} with OpenShift variables and replicaCount [ci skip]"
            )
            
            if update_result.get("status") == "success":
                logger.info(f"Archivo frontend {file_path} actualizado exitosamente")
                return True
            else:
                logger.error(f"Error al actualizar archivo frontend {file_path}: {update_result.get('error')}")
                return False
                
    except Exception as e:
        logger.error(f"Error en modify_frontend_values_file: {str(e)}")
        return False


async def modify_frontend_cd_file(
    session: aiohttp.ClientSession,
    repo_url: str,
    git_token: str,
    old_name: str,
    namespace: str,
    java_opts_ext: str,
    region: str,
    file_path: str,
    oam_data: dict,
    deployment_yaml: dict,
    env_suffix: str
) -> bool:
    """
    Modifica archivos cd.yml para frontend actualizando referencias a values-{env}.yaml.
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre del servicio
        namespace: Namespace limpio
        java_opts_ext: Opciones Java (no usado)
        region: Región
        file_path: Ruta del archivo cd.yml
        oam_data: Datos del OAM
        deployment_yaml: Deployment de OpenShift
        env_suffix: Sufijo del entorno (cert, pre, pro)
        
    Returns:
        bool: True si fue exitoso
    """
    try:
        logger.info(f"🔧 INICIO modify_frontend_cd_file para {env_suffix}")
        logger.info(f"   - Archivo: {file_path}")
        logger.info(f"   - Repositorio: {repo_url}")
        
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner/repo de la URL usando la función unificada
        from src.services.common_utils import extract_repo_info
        try:
            owner, repo = extract_repo_info(repo_url)
            logger.info(f"✅ Procesando {file_path} en {owner}/{repo} (FRONTEND CD)")
            logger.info(f"   - Token disponible: {'Sí' if git_token else 'No'}")
        except ValueError as e:
            logger.error(f"❌ No se pudo extraer owner/repo de la URL: {repo_url}. Error: {e}")
            return False
        logger.info(f"   - Sesión válida: {'Sí' if session else 'No'}")
        
        # Obtener contenido actual
        result = await github_client.get_file_content(owner, repo, file_path, "feature/gluon-migration-config-from-pulse-import")
        
        # Usar la función completa de backend pero adaptada para frontend
        
        if not result:
            # Crear archivo cd.yml inicial usando plantilla completa
            base_content = modify_cd_yml_comprehensive(
                "", oam_data, namespace, region, env_suffix, old_name
            )
            # Adaptar las referencias para frontend
            content = _adapt_cd_content_for_frontend(base_content, env_suffix)
            
            create_result = await github_client.update_file(
                owner, repo, file_path, content, None,
                f"Create frontend {file_path} with complete structure for {env_suffix} [ci skip]"
            )
            
            if create_result.get("status") == "success":
                logger.info(f"Archivo frontend CD {file_path} creado exitosamente")
                return True
            else:
                logger.error(f"Error al crear archivo frontend CD {file_path}: {create_result.get('error')}")
                return False
        else:
            # Actualizar archivo existente usando plantilla completa
            content, file_sha = result
            base_updated_content = modify_cd_yml_comprehensive(
                content, oam_data, namespace, region, env_suffix, old_name
            )
            # Adaptar las referencias para frontend
            updated_content = _adapt_cd_content_for_frontend(base_updated_content, env_suffix)
            
            update_result = await github_client.update_file(
                owner, repo, file_path, updated_content, file_sha,
                f"Update frontend {file_path} with complete structure for {env_suffix} [ci skip]"
            )
            
            if update_result.get("status") == "success":
                logger.info(f"Archivo frontend CD {file_path} actualizado exitosamente")
                return True
            else:
                logger.error(f"Error al actualizar archivo frontend CD {file_path}: {update_result.get('error')}")
                return False
                
    except Exception as e:
        logger.error(f"Error en modify_frontend_cd_file: {str(e)}")
        return False


def _extract_env_vars_from_deployment_frontend(deployment_yaml: dict) -> list:
    """
    Extrae variables de entorno del deployment de OpenShift específicas para frontend.
    Frontend típicamente no tiene secrets ni logging variables.
    
    Args:
        deployment_yaml: YAML del deployment de OpenShift
        
    Returns:
        list: Lista de variables de entorno para frontend
    """
    try:
        env_vars = []
        
        # Navegar por la estructura del deployment
        if isinstance(deployment_yaml, dict):
            spec = deployment_yaml.get('spec', {})
            template = spec.get('template', {})
            pod_spec = template.get('spec', {})
            containers = pod_spec.get('containers', [])
            
            for container in containers:
                container_env = container.get('env', [])
                
                for env_var in container_env:
                    var_name = env_var.get('name', '')
                    
                    # Filtrar variables específicas de frontend (excluir logging y secrets de Java)
                    if _is_frontend_relevant_env_var(var_name, env_var):
                        processed_var = {
                            'name': var_name
                        }
                        
                        # Procesar valor directo
                        if 'value' in env_var:
                            processed_var['value'] = env_var['value']
                        
                        # Procesar valueFrom (ConfigMap/Secret)
                        elif 'valueFrom' in env_var:
                            processed_var['valueFrom'] = env_var['valueFrom']
                        
                        env_vars.append(processed_var)
                        logger.debug(f"Variable frontend agregada: {var_name}")
        
        logger.info(f"Variables de entorno frontend extraídas: {len(env_vars)}")
        return env_vars
        
    except Exception as e:
        logger.error(f"Error extrayendo variables de entorno frontend: {e}")
        return []


def _is_frontend_relevant_env_var(var_name: str, env_var: dict) -> bool:
    """
    Determina si una variable de entorno es relevante para frontend.
    
    Args:
        var_name: Nombre de la variable
        env_var: Datos completos de la variable
        
    Returns:
        bool: True si es relevante para frontend
    """
    # Variables a excluir (específicas de Java/Spring y OpenShift)
    java_specific_vars = {
        'JAVA_OPTS', 'JAVA_OPTIONS', 'JVM_OPTS',
        'SPRING_PROFILES_ACTIVE', 'SPRING_CONFIG_LOCATION',
        'TECH_LOG', 'ROOT_LOG', 'LOG_LEVEL',
        'MANAGEMENT_ENDPOINTS', 'ACTUATOR_'
    }
    
    # Variables específicas de OpenShift que no deben migrarse a Gluon
    openshift_specific_vars = {
        'CONFIG_END_POINT',  # URL del configuration-service específico de OpenShift
        'BUILD_URL'          # URL de Jenkins/CloudBees específico del build
    }
    
    var_upper = var_name.upper()
    
    # Excluir SOLO las variables específicas de OpenShift que no deben migrarse
    if var_name in openshift_specific_vars:
        logger.debug(f"Excluyendo variable OpenShift: {var_name}")
        return False
    
    # Excluir SOLO variables específicas de Java/Spring (muy específicas)
    for java_var in java_specific_vars:
        if java_var in var_upper:
            logger.debug(f"Excluyendo variable Java: {var_name}")
            return False
    
    # Para ConfigMaps y Secrets, excluir solo si son claramente de Java
    if 'valueFrom' in env_var:
        value_from = env_var['valueFrom']
        if 'configMapKeyRef' in value_from or 'secretKeyRef' in value_from:
            # Revisar el nombre del ConfigMap/Secret
            ref_name = ''
            if 'configMapKeyRef' in value_from:
                ref_name = value_from['configMapKeyRef'].get('name', '').upper()
            elif 'secretKeyRef' in value_from:
                ref_name = value_from['secretKeyRef'].get('name', '').upper()
            
            # Excluir solo si es claramente específico de Java
            if any(java_term in ref_name for java_term in ['JAVA', 'SPRING', 'JVM', 'ACTUATOR']):
                logger.debug(f"Excluyendo ConfigMap/Secret Java: {var_name} ({ref_name})")
                return False
    
    # INCLUIR TODAS LAS DEMÁS VARIABLES (comportamiento por defecto)
    logger.debug(f"Incluyendo variable: {var_name}")
    return True


def _create_frontend_values_content(env_suffix: str, extra_env_vars: list) -> str:
    """
    Crea contenido inicial para archivos values-{env}.yaml de frontend.
    
    Args:
        env_suffix: Sufijo del entorno (cert, pre, pro)
        extra_env_vars: Variables extraídas del deployment
        
    Returns:
        str: Contenido del archivo values
    """
    try:
        from jinja2 import Environment, DictLoader
        
        # Usar la plantilla específica de frontend
        template_content = open(
            os.path.join(os.path.dirname(__file__), 'templates', 'values-frontend-env.yaml.j2'),
            'r', encoding='utf-8'
        ).read()
        
        jinja_env = Environment(loader=DictLoader({'template': template_content}))
        template = jinja_env.get_template('template')
        
        # Preparar variables para la plantilla
        template_vars = {
            'spring_profile': env_suffix,  # Para compatibilidad con recursos
            'extra_env_vars': extra_env_vars,
            'service_type': 'frontend'  # Especificar que es un servicio frontend
        }
        
        content = template.render(**template_vars)
        logger.info(f"Contenido frontend creado para {env_suffix} con {len(extra_env_vars)} variables")
        
        return content
        
    except Exception as e:
        logger.error(f"Error creando contenido frontend para {env_suffix}: {e}")
        # Contenido de fallback
        return f"""# Frontend environment-specific values for {env_suffix}

image:
  pullPolicy: Always
  tag: development

extraEnvVars: []

resources:
  limits:
    memory: 512Mi
    cpu: {'500m' if env_suffix == 'pro' else '300m'}
  requests:
    memory: 256Mi
    cpu: 25m
"""


def _update_frontend_values_content(content: str, extra_env_vars: list, env_suffix: str = None) -> str:
    """
    Actualiza contenido existente de values frontend con nuevas variables y replicaCount.
    
    Args:
        content: Contenido actual del archivo
        extra_env_vars: Variables a añadir/actualizar
        env_suffix: Sufijo del entorno para determinar replicaCount
        
    Returns:
        str: Contenido actualizado
    """
    try:
        from ruamel.yaml import YAML
        import io
        
        yaml = YAML()
        yaml.preserve_quotes = True
        yaml.width = 4096
        
        # Parsear YAML existente
        data = yaml.load(content)
        if data is None:
            data = {}
        
        # Añadir/actualizar replicaCount según el entorno
        if env_suffix:
            # cert y pre = 1, pro = 0
            if env_suffix == 'pro':
                data['replicaCount'] = 0
            else:
                data['replicaCount'] = 1
            logger.info(f"Añadido replicaCount para entorno {env_suffix}: {data['replicaCount']}")
        
        # Actualizar extraEnvVars
        if extra_env_vars:
            data['extraEnvVars'] = []
            for env_var in extra_env_vars:
                data['extraEnvVars'].append(env_var)
        
        # Convertir de vuelta a YAML
        output = io.StringIO()
        yaml.dump(data, output)
        
        updated_content = output.getvalue()
        logger.info(f"Contenido frontend actualizado con {len(extra_env_vars)} variables y replicaCount")
        
        return updated_content
        
    except Exception as e:
        logger.error(f"Error actualizando contenido frontend: {e}")
        return content  # Devolver contenido original si hay error


def _create_frontend_main_values_content(
    application_name: str,
    namespace: str,
    region: str,
    git_repo_url: str,
    git_repo_path: str,
    extra_env_vars: list
) -> str:
    """
    Crea contenido inicial para el archivo values.yaml principal de frontend usando plantilla Angular.
    
    Args:
        application_name: Nombre de la aplicación
        namespace: Namespace
        region: Región
        git_repo_url: URL del repositorio git
        git_repo_path: Path del repositorio para image.repository
        extra_env_vars: Variables extraídas del deployment
        
    Returns:
        str: Contenido del archivo values principal
    """
    try:
        from jinja2 import Environment, DictLoader
        
        # Usar la plantilla específica de frontend
        template_content = open(
            os.path.join(os.path.dirname(__file__), 'templates', 'values-frontend.yaml.j2'),
            'r', encoding='utf-8'
        ).read()
        
        jinja_env = Environment(loader=DictLoader({'template': template_content}))
        template = jinja_env.get_template('template')
        
        # Preparar variables para la plantilla
        template_vars = {
            'application_name': application_name,
            'git_repo_url': git_repo_url,
            'git_repo_path': git_repo_path,
            'region': region,
            'extra_env_vars': extra_env_vars,
            'extra_env_vars_cm': '',
            'extra_env_vars_secret': '',
            'extra_volumes': [],
            'extra_volume_mounts': []
        }
        
        content = template.render(**template_vars)
        logger.info(f"✅ PLANTILLA FRONTEND PROCESADA CORRECTAMENTE con gitRepo: {git_repo_url}")
        
        return content
        
    except Exception as e:
        logger.error(f"❌ ERROR CRÍTICO procesando plantilla frontend: {e}")
        logger.error(f"❌ Variables usadas: application_name={application_name}, git_repo_url={git_repo_url}, git_repo_path={git_repo_path}, region={region}")
        # NO USAR FALLBACK - Relanzar la excepción para que falle visiblemente
        raise RuntimeError(f"Error crítico procesando plantilla values-frontend.yaml.j2: {e}. NO se usará fallback.")


def _update_frontend_main_values_content(
    content: str,
    git_repo_url: str,
    git_repo_path: str,
    region: str,
    extra_env_vars: list
) -> str:
    """
    Actualiza contenido existente del values.yaml principal para frontend.
    ⚠️ IMPORTANTE: Ahora usa la plantilla completa en lugar de parsear YAML existente
    para preservar TODAS las configuraciones incluyendo health checks.
    
    Args:
        content: Contenido actual del archivo (se ignora)
        git_repo_url: URL del repositorio git
        git_repo_path: Path del repositorio para image.repository
        region: Región
        extra_env_vars: Variables a añadir/actualizar
        
    Returns:
        str: Contenido actualizado usando plantilla completa
    """
    try:
        from jinja2 import Environment, DictLoader
        
        # ⚠️ CAMBIO CRÍTICO: Usar plantilla completa en lugar de parsear YAML existente
        # Esto preserva TODAS las configuraciones incluyendo health checks
        logger.info("🔄 Actualizando values.yaml principal con plantilla COMPLETA (preserva health checks)")
        
        # Usar la misma plantilla que _create_frontend_main_values_content
        template_content = open(
            os.path.join(os.path.dirname(__file__), 'templates', 'values-frontend.yaml.j2'),
            'r', encoding='utf-8'
        ).read()
        
        jinja_env = Environment(loader=DictLoader({'template': template_content}))
        template = jinja_env.get_template('template')
        
        # Preparar variables para la plantilla
        template_vars = {
            'application_name': '${APPLICATION_NAME}',  # Se mantiene como variable para CI/CD
            'git_repo_url': git_repo_url,
            'git_repo_path': git_repo_path,
            'region': region,
            'extra_env_vars': extra_env_vars,
            'extra_env_vars_cm': '',
            'extra_env_vars_secret': '',
            'extra_volumes': [],
            'extra_volume_mounts': []
        }
        
        updated_content = template.render(**template_vars)
        logger.info(f"✅ PLANTILLA FRONTEND ACTUALIZADA correctamente con gitRepo: {git_repo_url}")
        logger.info("✅ Health checks /nginx_status preservados en actualización")
        
        return updated_content
        
    except Exception as e:
        logger.error(f"❌ ERROR CRÍTICO actualizando plantilla frontend: {e}")
        logger.error(f"❌ Variables: git_repo_url={git_repo_url}, git_repo_path={git_repo_path}, region={region}")
        # NO USAR FALLBACK - Relanzar la excepción
        raise RuntimeError(f"Error crítico actualizando plantilla values-frontend.yaml.j2: {e}. NO se usará fallback.")


def _adapt_cd_content_for_frontend(content: str, env_suffix: str) -> str:
    """
    Adapta el contenido de cd.yml generado por la función backend para usar
    las referencias correctas de frontend (values-{env}.yaml).
    
    Args:
        content: Contenido generado por modify_cd_yml_comprehensive
        env_suffix: Sufijo del entorno (cert, pre, pro)
        
    Returns:
        str: Contenido adaptado para frontend
    """
    try:
        # Patrón que debemos cambiar para frontend
        old_pattern = f".gluon/cd/{env_suffix}/values.yaml"
        new_pattern = f".gluon/cd/{env_suffix}/values-{env_suffix}.yaml"
        
        # Reemplazar las referencias en el contenido
        updated_content = content.replace(old_pattern, new_pattern)
        
        if old_pattern in content:
            logger.info(f"✅ Adaptado CD para frontend: {old_pattern} → {new_pattern}")
        else:
            logger.info(f"ℹ️ No se encontraron referencias a adaptar en CD para {env_suffix}")
        
        return updated_content
        
    except Exception as e:
        logger.error(f"Error adaptando contenido CD para frontend: {e}")
        return content


async def delete_original_frontend_values_files(
    session: aiohttp.ClientSession,
    repo_url: str,
    git_token: str
) -> dict:
    """
    Elimina los archivos originales values.yaml de cada entorno después de crear los archivos values-{env}.yaml.
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        
    Returns:
        dict: Resultados de las eliminaciones por entorno
    """
    try:
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner/repo de la URL usando la función unificada
        from src.services.common_utils import extract_repo_info
        try:
            owner, repo = extract_repo_info(repo_url)
            logger.info(f"Eliminando archivos values.yaml originales en {owner}/{repo}")
        except ValueError as e:
            logger.error(f"No se pudo extraer owner/repo de la URL: {repo_url}. Error: {e}")
            return {"status": "error", "message": "URL inválida"}
        
        results = {}
        environments = ['cert', 'pre', 'pro']
        
        for env_suffix in environments:
            file_path = f".gluon/cd/{env_suffix}/values.yaml"
            
            try:
                # Verificar si el archivo existe antes de intentar eliminarlo
                result = await github_client.get_file_content(
                    owner, repo, file_path, "feature/gluon-migration-config-from-pulse-import"
                )
                
                if result:
                    # El archivo existe, proceder a eliminarlo
                    content, file_sha = result
                    
                    delete_result = await github_client.delete_file(
                        owner, repo, file_path, file_sha,
                        f"🗑️ Remove original {file_path} (replaced by values-{env_suffix}.yaml)"
                    )
                    
                    if delete_result:
                        logger.info(f"✅ Archivo {file_path} eliminado exitosamente")
                        results[env_suffix] = {"status": "deleted", "path": file_path}
                    else:
                        logger.error(f"❌ Error eliminando {file_path}")
                        results[env_suffix] = {"status": "error", "path": file_path, "message": "Error en eliminación"}
                else:
                    # El archivo no existe
                    logger.info(f"ℹ️ Archivo {file_path} no existe, omitiendo eliminación")
                    results[env_suffix] = {"status": "not_found", "path": file_path}
                    
            except Exception as e:
                logger.error(f"❌ Error procesando eliminación de {file_path}: {str(e)}")
                results[env_suffix] = {"status": "error", "path": file_path, "message": str(e)}
        
        # Resumen de resultados
        deleted_count = sum(1 for r in results.values() if r["status"] == "deleted")
        not_found_count = sum(1 for r in results.values() if r["status"] == "not_found")
        error_count = sum(1 for r in results.values() if r["status"] == "error")
        
        logger.info(f"📊 Resumen eliminación: {deleted_count} eliminados, {not_found_count} no encontrados, {error_count} errores")
        
        return {
            "status": "completed",
            "summary": {
                "deleted": deleted_count,
                "not_found": not_found_count,
                "errors": error_count
            },
            "details": results
        }
        
    except Exception as e:
        logger.error(f"Error en delete_original_frontend_values_files: {str(e)}")
        return {"status": "error", "message": str(e)}


async def modify_nginx_default_conf(
    session: aiohttp.ClientSession,
    owner: str,
    repo: str,
    git_token: str,
    old_name: str,
    namespace: str
) -> bool:
    """
    Modifica el archivo nginx/default.conf para añadir/actualizar la configuración
    de ConfigMaps en la sección CONFIG_END_POINT.
    
    Args:
        session: Sesión HTTP aiohttp
        owner: Propietario del repositorio
        repo: Nombre del repositorio
        git_token: Token de GitHub
        old_name: Nombre del servicio (para {old_name} en la configuración)
        namespace: Namespace del servicio
        
    Returns:
        bool: True si la modificación fue exitosa, False en caso contrario
    """
    try:
        from .github_client import GitHubClient
        
        github_client = GitHubClient(git_token, session)
        
        file_path = "nginx/default.conf"
        
        # Obtener contenido actual del archivo
        result = await github_client.get_file_content(
            owner, repo, file_path, "feature/gluon-migration-config-from-pulse-import"
        )
        
        if not result:
            logger.warning(f"Archivo {file_path} no encontrado en {owner}/{repo}")
            return False
        
        content, file_sha = result
        logger.info(f"Archivo {file_path} encontrado en {owner}/{repo}")
        
        # Modificar el contenido
        modified_content = _update_nginx_config_section(content, old_name)
        
        # Actualizar el archivo si hay cambios
        if content != modified_content:
            logger.info(f"Detectados cambios en {file_path}, procediendo con actualización...")
            
            update_result = await github_client.update_file(
                owner, repo, file_path, modified_content, file_sha,
                f"Update nginx/default.conf CONFIG_END_POINT section for {namespace} migration",
                "feature/gluon-migration-config-from-pulse-import"  # Especificar rama explícitamente
            )
            
            if update_result.get("status") == "success":
                logger.info(f"✅ Archivo {file_path} actualizado correctamente")
                return True
            else:
                logger.error(f"❌ Error al actualizar {file_path}: {update_result.get('error')}")
                return False
        else:
            logger.info(f"ℹ️ No hay cambios en {file_path}, archivo ya actualizado")
            return True
            
    except Exception as e:
        logger.error(f"Error en modify_nginx_default_conf: {str(e)}")
        return False


def _update_nginx_config_section(content: str, old_name: str) -> str:
    """
    Actualiza la sección CONFIG_END_POINT en el archivo nginx/default.conf.
    
    Inserta la nueva sección justo DESPUÉS de la sección existente CONFIG_END_POINT.
    
    Args:
        content: Contenido actual del archivo nginx/default.conf
        old_name: Nombre del servicio para usar en la configuración
        
    Returns:
        str: Contenido modificado del archivo
    """
    try:
        import re
        
        # Configuración nueva que queremos añadir DESPUÉS de la sección CONFIG_END_POINT existente
        new_config_section = f'''
  <% if !ENV["CONFIG_END_POINT"] %>
  # to get config properties from ConfigMaps
  location <%= ENV["relativePath"] %>/config/config.json {{
    alias /etc/san-configmap-darwin/config.json;
    include conf.d/proxy-cache.conf;
    include conf.d/common-headers.conf;
  }}
  <% end %>'''
        
        # Patrón para encontrar la sección existente CONFIG_END_POINT
        # Busca desde <% if ENV["CONFIG_END_POINT"] %> hasta el <% end %> correspondiente
        existing_config_pattern = r'(<% if ENV\["CONFIG_END_POINT"\] %>.*?<% end %>)'
        
        # Buscar si ya existe la sección CONFIG_END_POINT (la original)
        existing_match = re.search(existing_config_pattern, content, re.DOTALL)
        
        if existing_match:
            logger.info("Sección CONFIG_END_POINT existente encontrada, insertando nueva sección después...")
            
            # Verificar si ya existe nuestra sección (!ENV["CONFIG_END_POINT"])
            our_section_pattern = r'<% if !ENV\["CONFIG_END_POINT"\] %>.*?<% end %>'
            our_section_exists = re.search(our_section_pattern, content, re.DOTALL)
            
            if our_section_exists:
                logger.info("ℹ️ Sección !ENV[\"CONFIG_END_POINT\"] ya existe; se forzará su reemplazo con la nueva sección")

                # Eliminar todas las ocurrencias previas de nuestra sección para evitar duplicados
                temp_content = re.sub(our_section_pattern, '', content, flags=re.DOTALL)

                # Insertar la nueva sección justo después de la sección CONFIG_END_POINT existente
                modified_content = re.sub(
                    existing_config_pattern,
                    r'\1' + new_config_section,
                    temp_content,
                    flags=re.DOTALL
                )

                logger.info(f"✅ Sección !ENV[\"CONFIG_END_POINT\"] reemplazada después de la sección CONFIG_END_POINT para servicio: {old_name}")
                return modified_content
            
            # Insertar nuestra nueva sección justo después de la sección existente
            modified_content = re.sub(
                existing_config_pattern, 
                r'\1' + new_config_section,  # \1 es la sección existente + nuestra nueva sección
                content, 
                flags=re.DOTALL
            )
            
            logger.info(f"✅ Sección !ENV[\"CONFIG_END_POINT\"] añadida después de la sección CONFIG_END_POINT para servicio: {old_name}")
            return modified_content
        else:
            # No existe la sección CONFIG_END_POINT original, insertar al final del bloque server
            logger.info("No se encontró sección CONFIG_END_POINT existente, insertando al final del bloque server")
            
            # Buscar el último cierre de bloque server } antes del final del archivo
            # Patrón más específico para encontrar el cierre del bloque server principal
            server_close_pattern = r'(\n\s*# to serve the app.*?})\s*(\n\s*})\s*$'
            server_close_match = re.search(server_close_pattern, content, re.DOTALL)
            
            if server_close_match:
                # Insertar antes del cierre del server (después de la última location)
                modified_content = re.sub(
                    server_close_pattern,
                    r'\1' + new_config_section + r'\2',
                    content,
                    flags=re.DOTALL
                )
                logger.info(f"✅ Sección !ENV[\"CONFIG_END_POINT\"] añadida al final del bloque server para servicio: {old_name}")
                return modified_content
            else:
                # Fallback más simple: buscar cualquier cierre de bloque al final
                simple_close_pattern = r'(\n)(\s*}\s*)$'
                simple_close_match = re.search(simple_close_pattern, content, re.MULTILINE)
                
                if simple_close_match:
                    # Insertar antes del último cierre de bloque
                    modified_content = re.sub(
                        simple_close_pattern,
                        new_config_section + r'\1\2',
                        content,
                        flags=re.MULTILINE
                    )
                    logger.info(f"✅ Sección !ENV[\"CONFIG_END_POINT\"] añadida antes del cierre final para servicio: {old_name}")
                    return modified_content
                else:
                    # Último fallback: añadir al final del archivo (sin estructura server reconocible)
                    logger.warning("No se encontró estructura server reconocible, añadiendo al final del archivo...")
                    if not content.endswith('\n'):
                        modified_content = content + '\n' + new_config_section + '\n'
                    else:
                        modified_content = content + new_config_section + '\n'
                    
                    logger.info(f"✅ Sección !ENV[\"CONFIG_END_POINT\"] añadida al final del archivo para servicio: {old_name}")
                    return modified_content
        
    except Exception as e:
        logger.error(f"Error actualizando sección nginx CONFIG_END_POINT: {e}")
        return content  # Devolver contenido original si hay error


async def validate_and_update_dockerfile_frontend_nginx(
    github_client: GitHubClient,
    owner: str,
    repo: str
) -> dict:
    """
    Validación especializada para microfront con nginx.
    
    REGLA ESPECIAL PARA FRONTEND:
    - Si la imagen actual empieza por 'nginx-1', se actualiza a la última nginx-1-28-ubi8
    - Si empieza por otra cosa, no se modifica nada
    
    Args:
        github_client: Cliente GitHub inicializado
        owner: Propietario del repositorio
        repo: Nombre del repositorio
        
    Returns:
        dict: Resultado con información de la validación y actualización
    """
    import aiohttp
    import json
    
    result = {
        'success': False,
        'updated': False,
        'current_version': None,
        'latest_version': None,
        'image_name': None,
        'error': None,
        'details': []
    }
    
    try:

        # Obtener contenido del Dockerfile
        dockerfile_result = await github_client.get_file_content(owner, repo, "Dockerfile", "feature/gluon-migration-config-from-pulse-import")
        if not dockerfile_result:
            result['error'] = "No se encontró Dockerfile en rama feature/gluon-migration-config-from-pulse-import"
            return result
        
        dockerfile_content, dockerfile_sha = dockerfile_result
        
        # Extraer línea FROM
        from_line = None
        for line in dockerfile_content.split('\n'):
            if line.strip().startswith('FROM'):
                from_line = line.strip()
                break
        
        if not from_line:
            result['error'] = "No se encontró línea FROM en Dockerfile"
            return result
        
        logger.info(f"🔍 FROM encontrado: {from_line}")
        
        # Extraer componentes de la imagen
        from .common_utils import extract_docker_image_components
        registry, image_name, current_version, suffixes = extract_docker_image_components(from_line)
        
        if not image_name:
            result['error'] = f"No se pudo extraer nombre de imagen de: {from_line}"
            return result
        
        result['current_version'] = current_version
        result['image_name'] = image_name
        
        # LÓGICA ESPECIAL FRONTEND: Solo procesar si la imagen empieza por 'nginx-1'
        if not image_name.startswith('nginx-1'):
            logger.info(f"✅ Imagen '{image_name}' no empieza por 'nginx-1', no se modifica")
            result['success'] = True
            result['details'].append(f"Imagen {image_name} no requiere actualización (no es nginx-1.x)")
            return result
        
        logger.info(f"📦 Procesando imagen nginx-1.x: {image_name}:{current_version}")
        
        # Para frontend, siempre usar nginx-1-28-ubi8 como imagen objetivo
        target_image_name = "nginx-1-28-ubi8"
        
        # Consultar API de versiones
        api_url = "https://image-version.sgtech.gs.corp/api/images"
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(api_url) as response:
                    if response.status != 200:
                        result['error'] = f"Error consultando API: HTTP {response.status}"
                        return result
                    
                    api_data = await response.json()
                    
                    # Extraer lista de imágenes
                    if isinstance(api_data, dict) and 'value' in api_data:
                        images_list = api_data['value']
                    elif isinstance(api_data, list):
                        images_list = api_data
                    else:
                        result['error'] = f"Formato inesperado de API: {type(api_data)}"
                        return result
                    
                    # Buscar nginx-1-28-ubi8 específicamente
                    target_image = None
                    for img in images_list:
                        if img.get('productName') == target_image_name:
                            target_image = img
                            break
                    
                    if not target_image:
                        result['error'] = f"Imagen {target_image_name} no encontrada en API"
                        logger.error(f"⚠️ {target_image_name} no encontrada en API")
                        return result
                    
                    # Extraer versión más reciente
                    latest_release = target_image.get('lastRelease', '')
                    if ':' in latest_release:
                        latest_version = latest_release.split(':')[-1]
                    else:
                        result['error'] = f"Formato inválido en lastRelease: {latest_release}"
                        return result
                    
                    result['latest_version'] = latest_version
                    logger.info(f"🔄 Última versión {target_image_name}: {latest_version}")
                    
                    # Construir nueva línea FROM con nginx-1-28-ubi8
                    from .common_utils import build_docker_from_line
                    new_from_line = build_docker_from_line(registry, target_image_name, latest_version, suffixes)
                    
                    # Si la imagen actual ya es nginx-1-28-ubi8 con la versión correcta, no actualizar
                    if image_name == target_image_name and current_version == latest_version:
                        logger.info(f"✅ Ya tiene la versión correcta: {target_image_name}:{latest_version}")
                        result['success'] = True
                        return result
                    
                    # Actualizar Dockerfile
                    lines = dockerfile_content.split('\n')
                    for i, line in enumerate(lines):
                        if line.strip().startswith('FROM'):
                            lines[i] = new_from_line
                            break
                    
                    updated_content = '\n'.join(lines)
                    
                    # Guardar en GitHub
                    update_result = await github_client.update_file(
                        owner, repo, "Dockerfile", updated_content, dockerfile_sha,
                        f"Update nginx image: {image_name}:{current_version} → {target_image_name}:{latest_version}"
                    )
                    
                    if update_result.get("status") == "success":
                        logger.info(f"✅ Dockerfile actualizado: {image_name}:{current_version} → {target_image_name}:{latest_version}")
                        result['success'] = True
                        result['updated'] = True
                        result['image_name'] = target_image_name
                        result['details'].append(f"Actualizado de {image_name}:{current_version} a {target_image_name}:{latest_version}")
                    else:
                        result['error'] = f"Error actualizando Dockerfile: {update_result.get('error')}"
                    
            except aiohttp.ClientError as e:
                result['error'] = f"Error de conexión con API: {str(e)}"
                
    except Exception as e:
        logger.error(f"Error en validación nginx frontend: {str(e)}")
        result['error'] = f"Error interno: {str(e)}"
    
    return result