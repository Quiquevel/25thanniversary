"""
Módulo de operaciones GitHub especializadas.
Contiene todas las funciones relacionadas con la modificación de archivos en repositorios GitHub.
"""
import aiohttp
from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap
import yaml
import io
from typing import Dict, Any, Optional, Tuple
from datetime import datetime
from shuttlelib.utils.logger import logger
from ..github_client import GitHubClient
from ..utils import get_environment_suffix


async def modify_values_file_optimized(
    session: aiohttp.ClientSession, 
    repo_url: str, 
    git_token: str,
    old_name: str, 
    namespace: str,
    java_opts_ext: str,
    region: str = "bo1",
    file_path: str = ".gluon/cd/values.yaml",
    oam_data: Optional[Dict] = None,
    deployment_yaml: Optional[Dict] = None,
    branch: str = "feature/gluon-migration-config-from-pulse-import",
    is_configmap: bool = False,
    service_type: str = "backend",
    env_override: Optional[str] = None,
    required_ci_id: Optional[str] = None,
    pom_content: Optional[str] = None
) -> bool:
    """
    Modifica el archivo values.yaml usando el cliente GitHub optimizado.
    RUTA CORREGIDA: .gluon/cd/values.yaml
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre antiguo del servicio
        namespace: Namespace limpio
        java_opts_ext: Opciones Java extendidas
        region: Región (default: bo1)
        file_path: Ruta del archivo a modificar (default: .gluon/cd/values.yaml)
        oam_data: Datos del OAM para extraer ci_id (opcional)
        deployment_yaml: Datos del deployment de OpenShift (opcional)
        branch: Rama de GitHub a usar (default: feature/gluon-migration-config-from-pulse-import)
        is_configmap: True si es ConfigMap (usa rama "main"), False para Backend/Frontend (ignora branch param)
        service_type: Tipo de servicio (backend, frontend)
        env_override: Entorno específico para archivos de entorno
        required_ci_id: CI ID requerido para validación 
        pom_content: Contenido del pom.xml para extraer Darwin version (opcional)
        
    Returns:
        bool: True si la modificación fue exitosa, False en caso contrario
    """
    try:
        # Determinar la rama correcta según el tipo de servicio
        if is_configmap:
            actual_branch = "main"
            logger.info(f"🔧 ConfigMap detectado - usando rama: main")
        else:
            actual_branch = branch  # Usar el parámetro branch para Backend/Frontend
            logger.info(f"🔧 Backend/Frontend detectado - usando rama: {actual_branch}")
        
        logger.info(f"🔧 modify_values_file_optimized iniciado para: {file_path}")
        logger.info(f"📋 Parámetros recibidos:")
        logger.info(f"    - repo_url: {repo_url}")
        logger.info(f"    - rama_final: {actual_branch}")
        logger.info(f"    - is_configmap: {is_configmap}")
        logger.info(f"    - old_name: {old_name}")
        logger.info(f"    - namespace: {namespace}")
        logger.info(f"    - service_type: {service_type}")
        logger.info(f"    - file_path: {file_path}")
        
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner y repo de la URL (soporte para URLs normales de GitHub y API)
        import re
        
        # Primero intentar URL normal de GitHub: https://github.com/owner/repo (con o sin .git)
        match = re.search(r'https://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$', repo_url)
        if not match:
            # Si no, intentar formato API: https://api.github.com/repos/owner/repo
            match = re.search(r'github\.com/repos/([^/]+)/([^/]+?)(?:\.git)?/?$', repo_url)
        
        if not match:
            logger.error(f"❌ No se pudo extraer owner/repo de la URL: {repo_url}")
            return False
        
        owner, repo = match.groups()
        # Remover .git si quedó en el nombre del repo (seguridad adicional)
        if repo.endswith('.git'):
            repo = repo[:-4]
        
        logger.info(f"✅ URL procesada: {repo_url} -> owner={owner}, repo={repo}")
        logger.info(f"✅ Procesando {file_path} en {owner}/{repo} (rama: {actual_branch})")
        
        # Obtener contenido actual usando la rama especificada
        logger.info(f"🔍 Obteniendo contenido del archivo {file_path} en rama {actual_branch}...")
        logger.info(f"📋 Llamando get_file_content con: owner={owner}, repo={repo}, file_path={file_path}, branch={actual_branch}")
        result = await github_client.get_file_content(owner, repo, file_path, actual_branch)
        
        if not result:
            logger.info(f"📝 Archivo {file_path} no existe en rama {actual_branch}, creando contenido inicial...")
            logger.info(f"🔧 get_file_content devolvió None/False para {file_path} en rama {actual_branch}")
            # Crear contenido inicial según el tipo de archivo
            logger.info(f"🔧 Llamando a _create_initial_file_content...")
            content, file_sha = await _create_initial_file_content(file_path, old_name, namespace, java_opts_ext, region, oam_data, is_configmap, env_override)
            if content is None:
                logger.error(f"❌ No se pudo crear contenido inicial para {file_path}")
                logger.error(f"📋 _create_initial_file_content devolvió None")
                logger.error(f"📋 DEVOLVIENDO FALSE POR ERROR EN CREACIÓN DE CONTENIDO INICIAL")
                return False
            
            logger.info(f"✅ Contenido inicial creado para {file_path}")
            
            # PASO 1: Crear el archivo inicial
            logger.info(f"📤 Creando archivo inicial {file_path}...")
            create_result = await github_client.update_file(
                owner, repo, file_path, content, None,  # sha=None para crear
                f"Create initial {file_path} for {namespace} migration [ci skip]",
                actual_branch  # Pasar la rama correcta
            )
            
            logger.info(f"📋 Resultado de creación: {create_result}")
            if create_result.get("status") != "success":
                logger.error(f"❌ Error al crear archivo inicial {file_path}: {create_result.get('error')}")
                logger.error(f"📋 DEVOLVIENDO FALSE POR ERROR EN CREACIÓN DE ARCHIVO INICIAL")
                return False
            
            logger.info(f"✅ Archivo inicial {file_path} creado exitosamente")
            
            # PASO 2: Obtener el SHA del archivo recién creado
            result_after_create = await github_client.get_file_content(owner, repo, file_path, actual_branch)
            if not result_after_create:
                logger.error(f"No se pudo obtener el SHA del archivo recién creado {file_path}")
                logger.error(f"📋 DEVOLVIENDO FALSE POR ERROR AL OBTENER SHA DESPUÉS DE CREACIÓN")
                return False
            
            # Verificar que result_after_create tiene exactamente 2 elementos
            if len(result_after_create) != 2:
                logger.error(f"❌ ERROR: get_file_content devolvió {len(result_after_create)} valores para {file_path} después de creación, se esperaban 2")
                logger.error(f"   Valores recibidos: {result_after_create}")
                return False
            
            content, file_sha = result_after_create
            
            # Verificar que no es un directorio
            if content == "directory" and file_sha == "directory":
                logger.error(f"⚠️ '{file_path}' devuelto como directorio después de creación")
                return False
            
            logger.info(f"Archivo {file_path} creado y SHA obtenido: {file_sha[:8]}...")
        else:
            # Verificar que result tiene exactamente 2 elementos
            if len(result) != 2:
                logger.error(f"❌ ERROR: get_file_content devolvió {len(result)} valores para {file_path}, se esperaban 2")
                logger.error(f"   Valores recibidos: {result}")
                return False
            
            content, file_sha = result
            
            # Verificar que no es un directorio
            if content == "directory" and file_sha == "directory":
                logger.warning(f"⚠️ '{file_path}' es un directorio, no un archivo")
                return False
            
            logger.info(f"✅ Contenido de {file_path} obtenido exitosamente (SHA: {file_sha[:8]}...)")
        
        # Aplicar transformaciones según el tipo de archivo
        logger.info(f"🔧 Determinando tipo de archivo para aplicar transformaciones...")
        if file_path.endswith('cd.yml') or file_path.endswith('cd.yaml'):
            logger.info(f"📋 Archivo detectado como cd.yml - aplicando transformaciones específicas")
            # Para archivos cd.yml - detectar entorno desde la ruta o usar env_override
            if env_override:
                # ConfigMaps: usar entorno específico del OAM
                env_type = env_override
                env_search = [env_override]
                logger.info(f"🔧 ConfigMap: Usando entorno específico del OAM: {env_override}")
            else:
                # Detección estándar desde la ruta del archivo
                env_type = "cert"  # Por defecto
                
                if '/cert/' in file_path:
                    env_type = "cert"
                    env_search = ["cert", "certification", "dev"]
                elif '/pre/' in file_path:
                    env_type = "pre"
                    env_search = ["pre", "preproduction"]
                elif '/pro/' in file_path:
                    env_type = "pro"
                    env_search = ["pro", "production"]
                else:
                    env_type = "cert"  # default
                    env_search = ["cert", "certification", "dev"]
            
            logger.info(f"🔍 Buscando configuración para entorno: {env_type}")
            logger.info(f"📁 Archivo: {file_path}")
            
            # Usar el API Server del deployment si está disponible
            target_api_server = None
            if deployment_yaml:
                target_api_server = deployment_yaml.get('spec', {}).get('template', {}).get('spec', {}).get('apiServer')
            if target_api_server:
                logger.info(f"✅ Usando apiServer del deployment: {target_api_server}")
                target_ci_id = deployment_yaml.get('spec', {}).get('template', {}).get('metadata', {}).get('labels', {}).get('ci_id')
                found_env_type = env_type
            else:
                # Si no está en el deployment, buscar en el OAM
                target_api_server = None
                target_ci_id = None
                found_env_type = None
                
                logger.info(f"🔄 Buscando apiServer en OAM para entorno {env_type}...")
                
                if oam_data and 'environments' in oam_data:
                    # Primera pasada: buscar coincidencia exacta del entorno
                    for env in oam_data['environments']:
                        env_name = env.get('name', '').lower()
                        env_type_name = env.get('type', '').lower()
                        
                        logger.debug(f"🔍 Evaluando entorno del OAM - name: {env_name}, type: {env_type_name}")
                        
                        # Buscar coincidencia exacta primero
                    if env_name == env_type or env_type_name == env_type:
                        for infra in env.get('infrastructures', []):
                            if (infra.get('type', '').upper() == 'KUBERNETES' or 
                                infra.get('properties', {}).get('type', '').upper() == 'KUBERNETES'):
                                properties = infra.get('properties', {})
                                logger.debug(f"🔧 Propiedades de infraestructura: {properties}")
                                if properties.get('apiServer'):
                                    target_api_server = properties['apiServer'].rstrip('/')
                                    target_ci_id = infra.get('id')
                                    found_env_type = env_name
                                    logger.info(f"✅ Encontrado apiServer para coincidencia exacta de {env_type}: {target_api_server}")
                                    break
                            if target_api_server:
                                break
                
                    # Segunda pasada: solo si no se encontró coincidencia exacta
                if not target_api_server and oam_data and 'environments' in oam_data:
                    for env in oam_data['environments']:
                        env_name = env.get('name', '').lower()
                        env_type_name = env.get('type', '').lower()
                        
                        logger.debug(f"🔍 Segunda pasada - Evaluando entorno: {env_name} ({env_type_name})")
                        logger.debug(f"🎯 Buscando coincidencia en: {env_search}")
                        
                        # Para certificación, ser más estrictos con las coincidencias
                        if env_type == 'cert':
                            if not (env_name == 'cert' or env_name == 'certification' or env_type_name == 'certification'):
                                logger.debug(f"⚠️ Ignorando {env_name} para certificación por no ser coincidencia exacta")
                                continue
                        
                        if env_name in env_search or env_type_name in env_search:
                            logger.info(f"🎯 Encontrada coincidencia parcial con {env_name} ({env_type_name})")
                            for infra in env.get('infrastructures', []):
                                if (infra.get('type', '').upper() == 'KUBERNETES' or 
                                    infra.get('properties', {}).get('type', '').upper() == 'KUBERNETES'):
                                    properties = infra.get('properties', {})
                                    logger.debug(f"🔧 Propiedades de infraestructura: {properties}")
                                    if properties.get('apiServer'):
                                        # Evitar usar pro-shadow para entornos no-pro
                                        if env_type != 'pro' and 'shadow' in env_name.lower():
                                            logger.warning(f"⚠️ Ignorando apiServer de {env_name} para entorno {env_type}")
                                            continue
                                        
                                        target_api_server = properties['apiServer'].rstrip('/')
                                        target_ci_id = infra.get('id')
                                        found_env_type = env_name
                                        logger.info(f"✅ Encontrado apiServer para {env_type} (alternativa {env_name}): {target_api_server}")
                                        break
                            if target_api_server:
                                break
            
            if not target_api_server:
                logger.warning(f"⚠️ No se encontró apiServer en OAM para el entorno {env_type}")
                
                # Valores por defecto solo si no encontramos en el OAM
                env_prefix_mapping = {
                    'cert': 'dev',
                    'pre': 'pre', 
                    'pro': 'pro'
                }
                env_type_mapping = {
                    'cert': 'certification',
                    'pre': 'preproduction',
                    'pro': 'production'
                }
                prefix = env_prefix_mapping.get(env_type, 'dev')
                type_name = env_type_mapping.get(env_type, 'certification')
                
                # Usar plantilla de configuración por defecto
                from jinja2 import Environment, DictLoader
                
                # Template para URLs de API server usando Jinja2
                api_server_template = Environment(loader=DictLoader({
                    'cert': 'https://api.san01bks.san.{{env_suffix}}.bo1.paas.cloudcenter.corp:6443',
                    'pre': 'https://api.san01bks.san.{{env_suffix}}.bo1.paas.cloudcenter.corp:6443'
                }))
                
                env_suffix_map = {'cert': 'dev', 'pre': 'pre'}
                
                if env_type == 'cert':
                    template = api_server_template.get_template('cert')
                    target_api_server = template.render(env_suffix=env_suffix_map['cert'])
                    logger.info(f"✅ Usando apiServer por defecto para certificación: {target_api_server}")
                elif env_type == 'pre':
                    template = api_server_template.get_template('pre')
                    target_api_server = template.render(env_suffix=env_suffix_map['pre'])
                    logger.info(f"✅ Usando apiServer por defecto para preproducción: {target_api_server}")
                elif env_type == 'pro':
                    logger.error(f"❌ No se puede usar valores por defecto para entorno {env_type}. Se requiere configuración del OAM.")
                    return False
                
                if not target_api_server:
                    logger.error(f"❌ No se encontró apiServer para el entorno {env_type} y no hay valor por defecto disponible")
                    return False
                
                oam_data = {
                    'environments': [
                        {
                            'name': env_type,
                            'type': type_name,
                            'infrastructures': [
                                {
                                    'id': f'{prefix}_ohe_{region}',
                                    'properties': {'type': 'KUBERNETES'}
                                }
                            ]
                        }
                    ]
                }
            
            logger.info(f"🔧 Llamando a modify_cd_yml_comprehensive para {env_type}...")
            
            # VALIDAR CI_ID SOLO PARA CONFIGMAPS (backends usan extracción interna)
            if is_configmap and not required_ci_id:
                error_msg = f"❌ ERROR CRÍTICO operations.py: ConfigMaps requieren required_ci_id para cd.yml en entorno '{env_type}'"
                error_msg += f"\n❌ required_ci_id debe extraerse en el Paso 3 del ConfigMap"
                error_msg += f"\n❌ cd.yml ConfigMap NO SE PUEDE PROCESAR SIN CI_ID VÁLIDO"
                logger.error(error_msg)
                raise ValueError(error_msg)
            
            if is_configmap:
                logger.info(f"✅ ConfigMap: CI_ID recibido desde Paso 3: {required_ci_id}")
            else:
                logger.info(f"✅ Backend: CI_ID se extraerá internamente del OAM (como antes)")
            
            modified_content = modify_cd_yml_comprehensive(
                content, oam_data, namespace, region, env_type, old_name, is_configmap, required_ci_id
            )
            logger.info(f"✅ modify_cd_yml_comprehensive completado para {env_type}")
        else:
            # Para archivos values.yaml - detectar tipo específico
            if file_path.endswith('/values.yaml'):
                # Archivo values.yaml principal con configuración completa
                # Usar el pom_content pasado como parámetro
                logger.info("✅ Usando pom_content pasado como parámetro para extraer Darwin version")
                
                modified_content = modify_gluon_values_yaml_comprehensive(
                    content, old_name, namespace, java_opts_ext, deployment_yaml, region, is_configmap,
                    pom_content, env_override, oam_data
                )
            elif any(x in file_path for x in ['/values-cert.yaml', '/values-pre.yaml', '/values-pro.yaml', '/values-dev.yaml', '/values-b-test.yaml', '/values-g-test.yaml', '/values-b.yaml', '/values-g.yaml']):
                # Archivos values específicos de entorno - usar plantilla Jinja2
                if env_override:
                    # ConfigMaps: usar entorno específico del OAM
                    env_type = env_override
                    logger.info(f"🔧 ConfigMap values: Usando entorno específico del OAM: {env_override}")
                else:
                    # Detección estándar
                    env_type = "cert"  # default
                    if '/values-pre.yaml' in file_path:
                        env_type = "pre"
                    elif '/values-pro.yaml' in file_path:
                        env_type = "pro"
                    elif '/values-dev.yaml' in file_path:
                        env_type = "dev"
                    elif '/values-cert.yaml' in file_path:
                        env_type = "cert"
                    # ConfigMap values adicionales
                    elif '/values-b-test.yaml' in file_path:
                        env_type = "pro-b-test"
                    elif '/values-g-test.yaml' in file_path:
                        env_type = "pro-g-test"
                    elif '/values-b.yaml' in file_path:
                        env_type = "pro-b"
                    elif '/values-g.yaml' in file_path:
                        env_type = "pro-g"
                
                logger.info(f"🔧 Detectado entorno {env_type} para archivo values: {file_path}")
                logger.info(f"🔒 Los contextos de seguridad NO se añadirán a values-{env_type}.yaml")
                
                # Usar el pom_content pasado como parámetro para extraer Darwin version también en archivos de entorno
                logger.info(f"✅ Usando pom_content pasado como parámetro para values-{env_type}.yaml")
                
                # DEBUG: Verificar contenido del pom antes de pasarlo
                if pom_content:
                    logger.info(f"🎯 DEBUG: pom_content se pasará a modify_values_environment_yaml (no es None)")
                else:
                    logger.warning(f"⚠️ DEBUG: pom_content es None - se usará versión por defecto de Darwin")
                
                # Extraer variables de entorno del deployment.yaml si está disponible
                extra_env_vars = []
                if deployment_yaml:
                    logger.info(f"🔍 deployment_yaml recibido para {env_type}: OK")
                    extra_env_vars = _extract_env_vars_from_deployment(deployment_yaml)
                    logger.info(f"✅ Extraídas {len(extra_env_vars)} variables de entorno del deployment para {env_type}")
                    if extra_env_vars:
                        for var in extra_env_vars:
                            logger.info(f"   - {var.get('name')}: {var}")
                    else:
                        logger.warning(f"⚠️  No se encontraron variables de entorno en el deployment para {env_type}")
                else:
                    logger.warning(f"⚠️  deployment_yaml es None/vacío para {env_type} - no se extraerán variables de entorno")
                
                # Usar función específica para archivos values que usa plantillas Jinja2
                modified_content = modify_values_environment_yaml(
                    content=content,
                    oam_data=oam_data,
                    clean_namespace=namespace,
                    region=region,
                    env_type=env_type,
                    old_name=old_name,
                    extra_env_vars=extra_env_vars,
                    service_type=service_type,
                    java_opts_ext=java_opts_ext,
                    pom_content=pom_content, 
                    is_configmap=is_configmap
                )
            else:
                # Para otros archivos values que no son de entorno específico
                logger.warning(f"⚠️  Archivo values no reconocido: {file_path}")
                logger.info("📝 Usando modificación básica sin contextos de seguridad")
                modified_content = content  # No modificar archivos no reconocidos
        
        # Actualizar el archivo si hay cambios
        logger.info(f"🔍 Comparando contenido original vs modificado...")
        if content != modified_content:
            logger.info(f"📝 Detectados cambios en {file_path}, procediendo con actualización...")
            result = await github_client.update_file(
                owner, repo, file_path, modified_content, file_sha,
                f"Update {file_path} for {namespace} migration [ci skip]",
                actual_branch  # Pasar la rama correcta
            )
            
            logger.info(f"📋 Resultado de actualización: {result}")
            if result.get("status") == "success":
                logger.info(f"✅ Archivo {file_path} actualizado correctamente")
                return True
            else:
                logger.error(f"❌ Error al actualizar {file_path}: {result.get('error', 'Unknown error')}")
                logger.error(f"📋 DEVOLVIENDO FALSE POR ERROR EN ACTUALIZACIÓN")
                return False
        else:
            logger.info(f"ℹ️ No hay cambios en {file_path}, archivo ya actualizado")
            logger.info(f"✅ DEVOLVIENDO TRUE - SIN CAMBIOS NECESARIOS")
            return True
            
    except Exception as e:
        logger.error(f"❌ Error en modify_values_file_optimized: {str(e)}")
        logger.error(f"📋 Parámetros del error: file_path={file_path}, branch_original={branch}, is_configmap={is_configmap}, repo_url={repo_url}")
        logger.error(f"📋 actual_branch calculado: {actual_branch if 'actual_branch' in locals() else 'NO_CALCULADO'}")
        logger.error(f"📋 owner={owner if 'owner' in locals() else 'NO_EXTRAIDO'}, repo={repo if 'repo' in locals() else 'NO_EXTRAIDO'}")
        import traceback
        logger.error(f"🔍 Traceback completo: {traceback.format_exc()}")
        return False

async def backup_development_branch(session: aiohttp.ClientSession, owner: str, repo: str, 
                                   git_token: str, old_name: str) -> bool:
    """
    Crea un backup de la rama development con timestamp.
    
    Args:
        session: Sesión HTTP aiohttp
        owner: Propietario del repositorio
        repo: Nombre del repositorio
        git_token: Token de GitHub
        old_name: Nombre del servicio para incluir en el nombre del backup
        
    Returns:
        bool: True si el backup fue exitoso o ya existe, False en caso contrario
    """
    try:
        logger.info(f"🔄 Iniciando backup de rama development para {owner}/{repo}")
        headers = {
            "Authorization": f"token {git_token}",
            "Accept": "application/vnd.github.v3+json"
        }
        
        # Validar permisos del repositorio primero
        repo_url = f"https://api.github.com/repos/{owner}/{repo}"
        async with session.get(repo_url, headers=headers) as response:
            if response.status == 404:
                logger.error(f"❌ Repositorio {owner}/{repo} no encontrado o sin permisos de acceso")
                return False
            elif response.status != 200:
                error_text = await response.text()
                logger.error(f"❌ Error al acceder al repositorio {owner}/{repo}: {error_text}")
                return False
        
        logger.debug(f"✅ Permisos de repositorio validados para {owner}/{repo}")
        
        # Crear nombre de rama de backup con fecha actual
        fecha = datetime.now().strftime("%d-%m-%Y")
        backup_branch_name = f"development_backup_{fecha}"
        logger.debug(f"📝 Nombre de rama de backup: {backup_branch_name}")
        
        # Verificar primero si la rama ya existe
        check_branch_url = f"https://api.github.com/repos/{owner}/{repo}/git/refs/heads/{backup_branch_name}"
        async with session.get(check_branch_url, headers=headers) as response:
            if response.status == 200:
                # La rama ya existe - esto es OK, no es un error
                logger.info(f"La rama de backup {backup_branch_name} ya existe, backup completo")
                return True
        
        # Obtener el SHA de la rama development (OBLIGATORIA - NO FALLBACK)
        dev_branch_url = f"https://api.github.com/repos/{owner}/{repo}/git/refs/heads/development"
        async with session.get(dev_branch_url, headers=headers) as response:
            if response.status != 200:
                error_text = await response.text()
                logger.error(f"❌ RAMA DEVELOPMENT NO ENCONTRADA en {owner}/{repo}: Status {response.status}")
                logger.error(f"Error detallado: {error_text}")
                logger.error("💥 ABORTANDO EJECUCIÓN: La rama development es obligatoria para microservicios Back/Front")
                return False
            
            dev_branch_data = await response.json()
            dev_sha = dev_branch_data['object']['sha']
            logger.debug(f"✅ Rama development encontrada, SHA: {dev_sha[:8]}...")
            
            dev_branch_data = await response.json()
            dev_sha = dev_branch_data['object']['sha']
        
        # Crear la nueva rama
        create_branch_url = f"https://api.github.com/repos/{owner}/{repo}/git/refs"
        branch_data = {
            "ref": f"refs/heads/{backup_branch_name}",
            "sha": dev_sha
        }
        
        async with session.post(create_branch_url, headers=headers, json=branch_data) as response:
            if response.status == 201:
                logger.info(f"Backup de development creado exitosamente: {backup_branch_name}")
                return True
            elif response.status == 422:
                # Si falla porque la referencia ya existe - esto también es OK
                error_text = await response.text()
                if "Reference already exists" in error_text:
                    logger.info(f"La rama de backup {backup_branch_name} ya existe, backup completo")
                    return True
                else:
                    logger.error(f"Error al crear backup de development: {error_text}")
                    return False
            else:
                error_text = await response.text()
                logger.error(f"Error al crear backup de development: {error_text}")
                return False
                
    except Exception as e:
        logger.error(f"Error en backup_development_branch: {str(e)}")
        return False


async def backup_pulse_import_branch(session: aiohttp.ClientSession, owner: str, 
                                   repo: str, git_token: str, old_name: str, is_configmap: bool = False) -> tuple[bool, str]:
    """
    Crea un backup de la rama pulse-import con nombre específico según el tipo de servicio.
    
    Args:
        session: Sesión HTTP aiohttp
        owner: Propietario del repositorio
        repo: Nombre del repositorio
        git_token: Token de GitHub
        old_name: Nombre del servicio para incluir en el nombre del backup
        is_configmap: True si es ConfigMap (usa rama "main"), False para Backend/Frontend (usa "feature/gluon-migration-config-from-pulse-import")
        
    Returns:
        tuple[bool, str]: (True si el backup fue exitoso o ya existe, Estado de la rama ("exists"/"created"/"error"))
    """
    try:
        logger.info(f"🔄 Iniciando backup de rama pulse-import para {owner}/{repo} (configmap: {is_configmap})")
        headers = {
            "Authorization": f"token {git_token}",
            "Accept": "application/vnd.github.v3+json"
        }
        
        # Validar permisos del repositorio primero
        repo_url = f"https://api.github.com/repos/{owner}/{repo}"
        async with session.get(repo_url, headers=headers) as response:
            if response.status == 404:
                logger.error(f"❌ Repositorio {owner}/{repo} no encontrado o sin permisos de acceso")
                return False, "error"
            elif response.status != 200:
                error_text = await response.text()
                logger.error(f"❌ Error al acceder al repositorio {owner}/{repo}: {error_text}")
                return False, "error"
        
        logger.debug(f"✅ Permisos de repositorio validados para {owner}/{repo}")
        
        source_branch = "pulse-import"
        # ConfigMaps usan rama "main", Backend/Frontend usan "feature/gluon-migration-config-from-pulse-import"
        target_branch = "main" if is_configmap else "feature/gluon-migration-config-from-pulse-import"
        logger.debug(f"📝 Rama origen: {source_branch}, rama destino: {target_branch}")
        
        # Verificar si la rama target ya existe
        target_url = f"https://api.github.com/repos/{owner}/{repo}/git/refs/heads/{target_branch}"
        async with session.get(target_url, headers=headers) as response:
            if response.status == 200:
                # La rama ya existe - esto es OK, no es un error
                logger.info(f"La rama {target_branch} ya existe")
                return True, "exists"
        
        # La rama no existe, proceder con el backup
        # Obtener el SHA de la rama pulse-import (OBLIGATORIA - NO FALLBACK)
        source_url = f"https://api.github.com/repos/{owner}/{repo}/git/refs/heads/{source_branch}"
        async with session.get(source_url, headers=headers) as response:
            if response.status != 200:
                error_text = await response.text()
                logger.error(f"❌ RAMA PULSE-IMPORT NO ENCONTRADA en {owner}/{repo}: Status {response.status}")
                logger.error(f"Error detallado: {error_text}")
                logger.error("💥 ABORTANDO EJECUCIÓN: La rama pulse-import es obligatoria para microservicios Back/Front")
                return False, "error"
            
            source_data = await response.json()
            source_sha = source_data['object']['sha']
            logger.debug(f"✅ Rama pulse-import encontrada, SHA: {source_sha[:8]}...")
        
        # Crear la nueva rama
        create_branch_url = f"https://api.github.com/repos/{owner}/{repo}/git/refs"
        branch_data = {
            "ref": f"refs/heads/{target_branch}",
            "sha": source_sha
        }
        async with session.post(create_branch_url, headers=headers, json=branch_data) as response:
            if response.status == 201:
                logger.info(f"Nueva rama {target_branch} creada exitosamente desde {source_branch}")
                return True, "created"
            elif response.status == 422:
                # Si falla porque la referencia ya existe - esto también es OK
                error_text = await response.text()
                if "Reference already exists" in error_text:
                    logger.info(f"La rama {target_branch} ya existe (detectado durante creación)")
                    return True, "exists"
                else:
                    logger.error(f"Error al crear rama: {error_text}")
                    return False, "error"
            else:
                error_text = await response.text()
                logger.error(f"Error al crear rama: {error_text}")
                return False, "error"
                
    except Exception as e:
        logger.error(f"Error en backup_pulse_import_branch: {str(e)}")
        return False, "error"


# Funciones wrapper eliminadas - usar directamente modify_values_file_optimized con el file_path específico


def _extract_env_vars_from_deployment(deployment_yaml: dict) -> list:
    """
    Extrae variables de entorno del deployment.yaml de OpenShift que tienen valueFrom.
    
    Args:
        deployment_yaml: Deployment YAML de OpenShift
        
    Returns:
        list: Lista de variables de entorno para extraEnvVars
    """
    try:
        containers = deployment_yaml.get('spec', {}).get('template', {}).get('spec', {}).get('containers', [])
        if not containers:
            return []
        
        # Tomar el primer contenedor (contenedor principal)
        main_container = containers[0]
        env_vars = main_container.get('env', [])
        
        # Variables que NO deben incluirse en la migración a Gluon
        excluded_env_vars = [
            'CONFIG_END_POINT',  # URL de configuration-service específico de OpenShift
            'BUILD_URL'          # URL de Jenkins/CloudBees específico del build
        ]
        
        extracted_env_vars = []
        for env_var in env_vars:
            env_name = env_var.get('name', '')
            
            # Excluir variables específicas que no deben migrarse
            if env_name in excluded_env_vars:
                logger.debug(f"Excluyendo variable de entorno: {env_name} (no debe migrarse a Gluon)")
                continue
            
            # Solo incluir variables que tengan valueFrom (secretKeyRef, configMapKeyRef, etc.)
            if 'valueFrom' in env_var and env_name:
                env_config = {
                    'name': env_var['name'],
                    'valueFrom': env_var['valueFrom']
                }
                
                # Asegurar que optional esté definido para secretKeyRef
                if 'secretKeyRef' in env_var['valueFrom']:
                    if 'optional' not in env_config['valueFrom']['secretKeyRef']:
                        env_config['valueFrom']['secretKeyRef']['optional'] = False
                
                extracted_env_vars.append(env_config)
        
        # Contar variables excluidas para el log
        excluded_count = sum(1 for env_var in env_vars if env_var.get('name') in excluded_env_vars)
        
        logger.info(f"Extraídas {len(extracted_env_vars)} variables de entorno del deployment")
        if excluded_count > 0:
            logger.info(f"Excluidas {excluded_count} variables específicas de OpenShift (CONFIG_END_POINT, BUILD_URL)")
        
        return extracted_env_vars
        
    except Exception as e:
        logger.warning(f"Error al extraer env vars del deployment: {e}")
        return []


def _extract_env_from_from_deployment(deployment_yaml: dict) -> tuple:
    """
    Extrae envFrom (configMapRef y secretRef) del deployment.yaml de OpenShift.
    
    Args:
        deployment_yaml: Deployment YAML de OpenShift
        
    Returns:
        tuple: (config_map_name, secret_name) o ("", "") si no se encuentran
    """
    try:
        containers = deployment_yaml.get('spec', {}).get('template', {}).get('spec', {}).get('containers', [])
        if not containers:
            return "", ""
        
        # Tomar el primer contenedor (contenedor principal)
        main_container = containers[0]
        env_from = main_container.get('envFrom', [])
        
        config_map_name = ""
        secret_name = ""
        
        for env_from_item in env_from:
            # Buscar configMapRef
            if 'configMapRef' in env_from_item:
                config_map_name = env_from_item['configMapRef'].get('name', '')
                logger.info(f"ConfigMap encontrado en envFrom: {config_map_name}")
            
            # Buscar secretRef
            if 'secretRef' in env_from_item:
                secret_name = env_from_item['secretRef'].get('name', '')
                logger.info(f"Secret encontrado en envFrom: {secret_name}")
        
        if config_map_name or secret_name:
            logger.info(f"Extraído del deployment - ConfigMap: '{config_map_name}', Secret: '{secret_name}'")
        else:
            logger.info("No se encontraron envFrom (configMapRef/secretRef) en el deployment")
        
        return config_map_name, secret_name
        
    except Exception as e:
        logger.warning(f"Error al extraer envFrom del deployment: {e}")
        return "", ""


def _extract_volumes_from_deployment(deployment_yaml: dict) -> list:
    """
    Extrae volúmenes del deployment.yaml de OpenShift.
    Filtra solo los volúmenes relevantes (secrets y configMaps específicos).
    
    Args:
        deployment_yaml: Deployment YAML de OpenShift
        
    Returns:
        list: Lista de volúmenes para extraVolumes
    """
    try:
        volumes = deployment_yaml.get('spec', {}).get('template', {}).get('spec', {}).get('volumes', [])
        
        extracted_volumes = []
        
        # Lista de volúmenes a excluir (automáticos o no relevantes)
        excluded_volume_types = ['downwardAPI', 'projected']
        excluded_volume_names = ['podinfo', 'default-token', 'san-configmap-darwin']
        
        for volume in volumes:
            volume_name = volume.get('name', '')
            
            # Excluir volúmenes por tipo
            if any(excluded_type in volume for excluded_type in excluded_volume_types):
                logger.debug(f"Excluyendo volumen {volume_name} por tipo automático")
                continue
                
            # Excluir volúmenes por nombre
            if any(excluded_name in volume_name for excluded_name in excluded_volume_names):
                logger.debug(f"Excluyendo volumen {volume_name} por nombre automático")
                continue
            
            # Excluir configMaps automáticos que contienen el nombre de la aplicación
            if 'configMap' in volume and 'cm-s-java-' in volume_name:
                logger.debug(f"Excluyendo configMap automático {volume_name}")
                continue
            
            if volume_name:
                # Para mantener el orden correcto, crear volume_config de forma ordenada
                if 'secret' in volume:
                    # Para secrets: name primero, luego secret
                    volume_config = {
                        'name': volume_name,
                        'secret': {'secretName': volume['secret'].get('secretName', volume['secret'].get('name'))}
                    }
                elif 'configMap' in volume:
                    # Para configMaps: name primero, luego configMap
                    config_value = volume['configMap']
                    simplified_config = {'name': config_value.get('name')}
                    if 'defaultMode' in config_value:
                        simplified_config['defaultMode'] = config_value['defaultMode']
                    volume_config = {
                        'name': volume_name,
                        'configMap': simplified_config
                    }
                else:
                    # Para otros tipos
                    volume_config = {'name': volume_name}
                    for key, value in volume.items():
                        if key != 'name':
                            volume_config[key] = value
                
                extracted_volumes.append(volume_config)
                logger.debug(f"Incluido volumen: {volume_name}")
        
        logger.info(f"Extraídos {len(extracted_volumes)} volúmenes relevantes del deployment")
        return extracted_volumes
        
    except Exception as e:
        logger.warning(f"Error al extraer volumes del deployment: {e}")
        return []


def _extract_volume_mounts_from_deployment(deployment_yaml: dict) -> list:
    """
    Extrae montajes de volúmenes del deployment.yaml de OpenShift.
    Filtra solo los montajes de volúmenes relevantes.
    
    Args:
        deployment_yaml: Deployment YAML de OpenShift
        
    Returns:
        list: Lista de montajes de volúmenes para extraVolumeMounts
    """
    try:
        containers = deployment_yaml.get('spec', {}).get('template', {}).get('spec', {}).get('containers', [])
        if not containers:
            return []
        
        # Tomar el primer contenedor (contenedor principal)
        main_container = containers[0]
        volume_mounts = main_container.get('volumeMounts', [])
        
        # Lista de montajes a excluir
        excluded_mount_names = ['podinfo', 'default-token']
        excluded_paths = ['/opt/metadata', '/var/run/secrets']
        
        extracted_mounts = []
        for mount in volume_mounts:
            mount_name = mount.get('name', '')
            mount_path = mount.get('mountPath', '')
            
            # Excluir montajes por nombre
            if any(excluded_name in mount_name for excluded_name in excluded_mount_names):
                logger.debug(f"Excluyendo montaje {mount_name} por nombre automático")
                continue
                
            # Excluir montajes por path
            if any(excluded_path in mount_path for excluded_path in excluded_paths):
                logger.debug(f"Excluyendo montaje {mount_name} por path automático")
                continue
            
            # Excluir montajes de configMaps automáticos
            if 'cm-s-java-' in mount_name or 'san-configmap-darwin' in mount_name:
                logger.debug(f"Excluyendo montaje de configMap automático {mount_name}")
                continue
            
            if mount_name and mount_path:
                mount_config = {
                    'name': mount_name,
                    'mountPath': mount_path
                }
                
                # No incluir readOnly para simplificar
                # if 'readOnly' in mount:
                #     mount_config['readOnly'] = mount['readOnly']
                
                # Añadir subPath si está definido
                if 'subPath' in mount:
                    mount_config['subPath'] = mount['subPath']
                
                extracted_mounts.append(mount_config)
                logger.debug(f"Incluido montaje: {mount_name} -> {mount_path}")
        
        logger.info(f"Extraídos {len(extracted_mounts)} montajes relevantes del deployment")
        return extracted_mounts
        
    except Exception as e:
        logger.warning(f"Error al extraer volume mounts del deployment: {e}")
        return []







def modify_gluon_values_yaml_comprehensive(content: str, old_name: str, clean_namespace: str, 
                                          java_opts_ext: str, deployment_yaml: dict = None, region: str = "bo1", is_configmap: bool = False, 
                                          pom_content: str = None, env_override: str = None, oam_data: dict = None) -> str:
    """
    Genera .gluon/cd/values.yaml usando la plantilla Jinja2.
    Esta función ahora usa exclusivamente la plantilla values.yaml.j2 para generar 
    el contenido completo del archivo, asegurando consistencia y estructura correcta.
    """
    try:
        logger.info("🎯 Generando .gluon/cd/values.yaml usando plantilla Jinja2...")
        
        # Importar Jinja2 para renderizar plantillas y YAML para formatear
        from jinja2 import Environment, FileSystemLoader, select_autoescape
        import yaml
        
        # Función personalizada para convertir a YAML con orden específico
        def to_yaml(value, indent=2):
            if not value:
                return "[]"
            
            # Función auxiliar para convertir diccionarios anidados a YAML
            def dict_to_yaml(d, current_indent=4):
                lines = []
                for k, v in d.items():
                    if isinstance(v, dict):
                        lines.append(f"{' ' * current_indent}{k}:")
                        lines.extend(dict_to_yaml(v, current_indent + 2))
                    elif isinstance(v, bool):
                        lines.append(f"{' ' * current_indent}{k}: {str(v).lower()}")
                    elif isinstance(v, str):
                        lines.append(f"{' ' * current_indent}{k}: {v}")
                    else:
                        lines.append(f"{' ' * current_indent}{k}: {v}")
                return lines
            
            # Construir YAML manualmente para controlar el orden
            result_lines = []
            for item in value:
                if isinstance(item, dict):
                    # Detectar el tipo de elemento para aplicar orden específico
                    if 'mountPath' in item and 'name' in item:
                        # Para volume mounts: mountPath primero, luego name
                        result_lines.append(f"  - mountPath: {item['mountPath']}")
                        result_lines.append(f"    name: {item['name']}")
                        
                        # Añadir otros campos si existen
                        for key, val in item.items():
                            if key not in ['mountPath', 'name']:
                                if isinstance(val, dict):
                                    result_lines.append(f"    {key}:")
                                    result_lines.extend(dict_to_yaml(val, 6))
                                else:
                                    result_lines.append(f"    {key}: {val}")
                    
                    elif 'name' in item and ('secret' in item or 'configMap' in item):
                        # Para volúmenes: name primero, luego otros campos
                        result_lines.append(f"  - name: {item['name']}")
                        
                        # Añadir otros campos en orden específico
                        for key, val in item.items():
                            if key != 'name':
                                if isinstance(val, dict):
                                    result_lines.append(f"    {key}:")
                                    result_lines.extend(dict_to_yaml(val, 6))
                                else:
                                    result_lines.append(f"    {key}: {val}")
                    
                    elif 'name' in item and 'valueFrom' in item:
                        # Para variables de entorno: name primero, luego valueFrom expandido
                        result_lines.append(f"  - name: {item['name']}")
                        
                        # Manejar valueFrom de forma expandida
                        for key, val in item.items():
                            if key != 'name':
                                if isinstance(val, dict):
                                    result_lines.append(f"    {key}:")
                                    result_lines.extend(dict_to_yaml(val, 6))
                                else:
                                    result_lines.append(f"    {key}: {val}")
                    
                    else:
                        # Para cualquier otro elemento, usar name primero si existe
                        if 'name' in item:
                            result_lines.append(f"  - name: {item['name']}")
                            for key, val in item.items():
                                if key != 'name':
                                    if isinstance(val, dict):
                                        result_lines.append(f"    {key}:")
                                        result_lines.extend(dict_to_yaml(val, 6))
                                    else:
                                        result_lines.append(f"    {key}: {val}")
                        else:
                            # Fallback al método YAML normal
                            yaml_str = yaml.dump([item], default_flow_style=False, indent=indent)
                            if yaml_str.startswith('---\n'):
                                yaml_str = yaml_str[4:]
                            lines = yaml_str.strip().split('\n')
                            if lines and lines[0].startswith('- '):
                                lines[0] = '  ' + lines[0]
                                for line in lines[1:]:
                                    result_lines.append('  ' + line)
                            else:
                                for line in lines:
                                    result_lines.append('  ' + line)
            
            return '\n'.join(result_lines)
        
        # Configurar el entorno Jinja2 con la función personalizada
        jinja_env = Environment(
            loader=FileSystemLoader('src/services/templates/'),
            autoescape=select_autoescape(['html', 'xml']),
            trim_blocks=True,
            lstrip_blocks=True
        )
        jinja_env.filters['to_yaml'] = to_yaml
        
        # Preparar variables extraídas del deployment.yaml si está disponible
        extra_env_vars = []
        extra_volumes = []
        extra_volume_mounts = []
        config_map_name = ""
        secret_name = ""
        
        if deployment_yaml:
            extra_env_vars = _extract_env_vars_from_deployment(deployment_yaml)
            extra_volumes = _extract_volumes_from_deployment(deployment_yaml)
            extra_volume_mounts = _extract_volume_mounts_from_deployment(deployment_yaml)
            config_map_name, secret_name = _extract_env_from_from_deployment(deployment_yaml)
            logger.info(f"✅ Extraído del deployment: {len(extra_env_vars)} env vars, {len(extra_volumes)} volumes, {len(extra_volume_mounts)} volume mounts")
            logger.info(f"✅ EnvFrom extraído: ConfigMap='{config_map_name}', Secret='{secret_name}'")
        
        # Usar plantilla Jinja2 según el tipo de servicio
        if is_configmap:
            # Para ConfigMaps usar plantilla específica valuesCM.yaml.j2
            template = jinja_env.get_template('valuesCM.yaml.j2')
            logger.info("✅ Usando plantilla valuesCM.yaml.j2 para ConfigMap")
            
            # Preparar application_name - para ConfigMaps usar oam_data si está disponible, sino old_name
            if oam_data and 'application_name' in oam_data:
                app_name = oam_data['application_name']
                logger.info(f"🔧 ConfigMap: Usando application_name de oam_data: {app_name}")
            else:
                app_name = old_name
                logger.info(f"🔧 ConfigMap: Usando old_name como fallback: {app_name}")
            
            # Remover prefijo cm- si existe (el template lo añadirá automáticamente)
            if app_name.startswith('cm-'):
                original_app_name = app_name
                app_name = app_name[3:]  # Remover prefijo cm- si existe
                logger.info(f"🔧 Removido prefijo cm- de {original_app_name} -> {app_name}")
            
            # Obtener el sufijo del entorno para ConfigMaps (pro-b -> -b, pro-g-test -> -g-test, etc.)
            environment_suffix = ""
            if env_override:
                environment_suffix = get_environment_suffix(env_override)
                logger.info(f"🏷️ Sufijo de entorno para {env_override}: '{environment_suffix}'")
            
            rendered_content = template.render(
                application_name=app_name,
                environment_suffix=environment_suffix
            )
        else:
            # Para Backend/Frontend usar plantilla tradicional values.yaml.j2
            template = jinja_env.get_template('values.yaml.j2')
            logger.info("✅ Usando plantilla values.yaml.j2 para Backend/Frontend")
            
            # Extraer Darwin version del pom.xml si está disponible
            darwin_version = None  # Inicializar como None para usar default del template
            if pom_content:
                try:
                    logger.info("🔄 Extrayendo Darwin version del pom.xml para values.yaml principal...")
                    logger.info(f"🔍 DEBUG: pom_content recibido (primeros 200 chars): {pom_content[:200]}...")
                    extracted_version = extract_darwin_version_from_pom(pom_content)
                    if extracted_version:
                        darwin_version = extracted_version
                        logger.info(f"✅ Darwin version extraído para values.yaml: {darwin_version}")
                    else:
                        logger.warning(f"⚠️ No se pudo extraer Darwin version del pom.xml para values.yaml, usando default del template")
                except Exception as e:
                    logger.error(f"❌ Error al extraer Darwin version del pom.xml para values.yaml: {e}, usando default del template")
            else:
                logger.warning(f"⚠️ No se proporcionó contenido del pom.xml para values.yaml, usando Darwin version default del template")
            
            # Preparar variables para la plantilla
            template_vars = {
                'application_name': old_name,
                'clean_namespace': clean_namespace,
                'java_opts_ext': java_opts_ext,
                'region': region,
                'extra_env_vars': [],  # Siempre vacío en values.yaml principal - las env vars van en values-env.yaml
                'extra_volumes': extra_volumes,
                'extra_volume_mounts': extra_volume_mounts,
                'extra_env_vars_cm': config_map_name,  # Extraído del deployment.yaml
                'extra_env_vars_secret': secret_name   # Extraído del deployment.yaml
            }
            
            # Solo pasar darwin_version si se extrajo correctamente del pom.xml
            if darwin_version:
                template_vars['darwin_version'] = darwin_version
                logger.info(f"🎯 Darwin version {darwin_version} será usado en template values.yaml")
            else:
                logger.info(f"🎯 No se extrajo Darwin version, template values.yaml usará valor por defecto")
            
            rendered_content = template.render(**template_vars)
        
        logger.info("✅ Archivo .gluon/cd/values.yaml generado exitosamente usando plantilla")
        return rendered_content
        
    except Exception as e:
        logger.error(f"Error al generar .gluon/cd/values.yaml con plantilla Jinja2: {e}")
        logger.error("❌ No se puede generar el archivo sin la plantilla")
        # En caso de error, devolver el contenido original
        return content


def modify_cd_yml_comprehensive(content: str, oam_data: dict, clean_namespace: str, 
                               region: str = "bo1", env_type: str = "cert", old_name: str = "", is_configmap: bool = False, 
                               required_ci_id: str = None) -> str:
    """
    Modifica específicamente archivos cd.yml dentro de .gluon/cd/{env}/
    Regenera completamente el archivo usando la plantilla cd.yml.j2 para asegurar
    que tenga la estructura completa con todos los campos necesarios.
    
    Args:
        content: Contenido original del archivo cd.yml (para logging de cambios)
        oam_data: Datos del OAM parseados (con environments)
        clean_namespace: Namespace limpio
        region: Región (default: bo1)
        env_type: Tipo de entorno (cert, pre, pro)
        old_name: Nombre del componente/servicio
        is_configmap: Si es ConfigMap (afecta el component_name)
        required_ci_id: CI_ID específico (OBLIGATORIO para ConfigMaps, opcional para backends)
        
    Returns:
        str: Contenido regenerado del archivo cd.yml usando plantilla completa
    """
    try:
        logger.info(f"Regenerando cd.yml para entorno {env_type} usando plantilla completa")
        logger.info(f"🔍 DEBUG - Parámetros recibidos:")
        logger.info(f"   - old_name: {old_name}")
        logger.info(f"   - env_type: {env_type}")
        logger.info(f"   - clean_namespace: {clean_namespace}")
        logger.info(f"   - region: {region}")
        logger.info(f"   - is_configmap: {is_configmap}")
        logger.info(f"   - required_ci_id: {required_ci_id}")
        logger.info(f"   - oam_data disponible: {'Sí' if oam_data else 'No'}")
        if oam_data and 'environments' in oam_data:
            env_names = [env.get('name') for env in oam_data.get('environments', [])]
            logger.info(f"   - Entornos disponibles en OAM: {env_names}")
        
        # DETERMINAR CI_IDs SEGÚN TIPO DE FLUJO
        target_ci_ids = []
        
        if is_configmap:
            # CONFIGMAPS: CI_ID debe venir del Paso 3 (validación obligatoria)
            if not required_ci_id:
                error_msg = f"❌ ERROR CRÍTICO cd.yml: ConfigMaps requieren required_ci_id para el entorno '{env_type}'"
                error_msg += f"\n❌ CI_ID debe extraerse en el Paso 3 del ConfigMap usando get_ci_id_from_oam()"
                error_msg += f"\n❌ NO SE PUEDE PROCESAR cd.yml ConfigMap SIN CI_ID VÁLIDO"
                logger.error(error_msg)
                raise ValueError(error_msg)
            
            # Para ConfigMaps, usar CI_IDs del Paso 3 (puede ser múltiple para PRO)
            if "," in required_ci_id:
                target_ci_ids = [ci_id.strip() for ci_id in required_ci_id.split(",")]
                logger.info(f"✅ ConfigMap: Usando múltiples CI_IDs del Paso 3 (dual cluster): {target_ci_ids}")
            else:
                target_ci_ids = [required_ci_id]
                logger.info(f"✅ ConfigMap: Usando CI_ID único del Paso 3: {required_ci_id}")
        else:
            # BACKENDS: Extraer CI_IDs del OAM (lógica original)
            logger.info(f"✅ Backend: Extrayendo CI_IDs del OAM para entorno {env_type}")
            
            # Buscar ci_ids en el OAM para el entorno específico
            environments = None
            if oam_data:
                # Buscar environments en la estructura correcta
                if 'raw_data' in oam_data and 'environments' in oam_data['raw_data']:
                    environments = oam_data['raw_data']['environments']
                    logger.info(f"🔍 Environments encontrados en raw_data.environments")
                elif 'environments' in oam_data:
                    environments = oam_data['environments']
                    logger.info(f"🔍 Environments encontrados en root.environments")
                else:
                    logger.warning(f"⚠️ No se encontró sección 'environments' en OAM")
                    
            if environments:
                logger.info(f"🔍 Buscando CI_IDs en OAM para entorno '{env_type}'...")
                for env in environments:
                    env_name = env.get('name')
                    logger.info(f"   - Evaluando entorno: '{env_name}' (¿coincide con '{env_type}'? {env_name == env_type})")
                    if env.get('name') == env_type:
                        infrastructures = env.get('infrastructures', [])
                        logger.info(f"   - Entorno coincidente encontrado, revisando {len(infrastructures)} infraestructuras...")
                        for i, infra in enumerate(infrastructures):
                            ci_id = infra.get('id')
                            infra_type = infra.get('properties', {}).get('type')
                            logger.info(f"     * Infraestructura {i+1}: id='{ci_id}', type='{infra_type}'")
                            if ci_id and infra_type == 'KUBERNETES':
                                target_ci_ids.append(ci_id)
                                logger.info(f"✅ CI_ID encontrado en OAM para {env_type}: {ci_id}")
                            elif not ci_id:
                                logger.warning(f"⚠️ Infraestructura sin ID encontrada")
                            elif infra_type != 'KUBERNETES':
                                logger.info(f"ℹ️ Infraestructura ignorada (tipo: {infra_type})")
            else:
                logger.warning("⚠️ No hay datos de OAM válidos o no contiene sección 'environments'")
            
            if not target_ci_ids:
                logger.error(f"❌ CRÍTICO: No se encontraron CI_IDs en OAM para entorno '{env_type}'")
                logger.error(f"❌ ESTO NO DEBERÍA PASAR - EL OAM DEBE CONTENER LOS CI_IDs")
                logger.error(f"❌ RECHAZANDO USO DE FALLBACK - DEBE CORREGIRSE LA EXTRACCIÓN DEL OAM")
                # NO usar fallback - lanzar error para forzar corrección
                raise ValueError(f"No se encontraron CI_IDs válidos en OAM para entorno '{env_type}'. Revisar datos del OAM.")
        

        
        # Usar plantilla Jinja2 para regenerar completamente el contenido
        from jinja2 import Environment, FileSystemLoader, select_autoescape
        import os
        
        # Configurar el entorno Jinja2
        template_dir = os.path.join(os.path.dirname(__file__), '..', 'templates')
        jinja_env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(['html', 'xml'])
        )
        
        # Cargar la plantilla cd.yml.j2
        template = jinja_env.get_template('cd.yml.j2')
        
        # Preparar variables para la plantilla
        # Para ConfigMaps, conservar el nombre original y usar la variable is_configmap en el template
        component_name = old_name
        if is_configmap:
            # Si viene con prefijo cm-, quitarlo porque el template lo añadirá automáticamente
            if old_name.startswith('cm-'):
                component_name = old_name[3:]  # Remover "cm-" para que el template pueda añadirlo condicionalmente
                logger.info(f"🔧 ConfigMap detectado - preparando nombre base: {old_name} -> {component_name} (template añadirá cm-)")
            else:
                logger.info(f"🔧 ConfigMap detectado - usando nombre base: {component_name} (template añadirá cm-)")
        
        template_vars = {
            'ci_ids': target_ci_ids,  # Lista de ci_ids (puede tener múltiples para PRO)
            'component_name': component_name,
            'env_type': env_type,
            'is_configmap': is_configmap
        }
        
        # Renderizar la plantilla
        regenerated_content = template.render(**template_vars)
        
        # Log de cambios si el contenido es diferente
        if content.strip() != regenerated_content.strip():
            logger.info(f"✅ cd.yml regenerado completamente usando plantilla")
            for ci_id in target_ci_ids:
                logger.info(f"  - ci_id: {ci_id}")
            logger.info(f"  - component_name: {old_name}")
            logger.info(f"  - env_type: {env_type}")
            logger.info(f"  - Estructura completa con configuration_files añadida")
        else:
            logger.info("cd.yml ya tenía la estructura correcta")
        
        # DEBUG: Para PRO, mostrar contenido comparativo
        if env_type == 'pro':
            logger.info(f"🔍 DEBUG PRO - Contenido original:")
            logger.info(f"--- ORIGINAL ---")
            for i, line in enumerate(content.strip().split('\n')[:10], 1):
                logger.info(f"{i:2}: {line}")
            logger.info(f"--- REGENERADO ---")
            for i, line in enumerate(regenerated_content.strip().split('\n')[:10], 1):
                logger.info(f"{i:2}: {line}")
            logger.info(f"--- FIN DEBUG ---")
        
        return regenerated_content
        
    except ValueError as e:
        # ValueError son errores críticos de validación del OAM - NO CAPTURAR, PROPAGAR
        logger.error(f"Error crítico en modify_cd_yml_comprehensive: {str(e)}")
        raise e
    except Exception as e:
        logger.error(f"Error técnico en modify_cd_yml_comprehensive: {str(e)}")
        logger.warning("Devolviendo contenido original debido al error técnico")
        return content




def _process_java_opts_ext_for_environment(java_opts_ext: str, env_type: str) -> str:
    """
    Procesa java_opts_ext para asegurar que tenga las opciones requeridas según el entorno.
    SIEMPRE incluye -Djava.security.krb5.conf=/etc/krb/krb5.conf como primera opción.
    
    Args:
        java_opts_ext: Opciones JVM originales del microservicio
        env_type: Tipo de entorno (cert, pre, pro)
        
    Returns:
        str: Opciones JVM procesadas con opciones requeridas
    """
    import re
    
    # OBLIGATORIO: Opción Kerberos que siempre debe estar presente como primera
    required_krb_option = "-Djava.security.krb5.conf=/etc/krb/krb5.conf"
    
    # Determinar el valor correcto de MaxRAMPercentage según el entorno
    target_percentage = "70.0" if env_type == "pro" else "50.0"
    
    # Limpiar java_opts_ext de entrada
    java_opts_ext = java_opts_ext.strip() if java_opts_ext else ""
    
    # Remover la opción Kerberos si ya existe (para evitar duplicados)
    krb_pattern = r'-Djava\.security\.krb5\.conf=[^\s]+'
    java_opts_ext = re.sub(krb_pattern, '', java_opts_ext).strip()
    
    # Procesar MaxRAMPercentage
    ram_percentage_pattern = r'-XX:MaxRAMPercentage=\d+\.?\d*'
    if re.search(ram_percentage_pattern, java_opts_ext):
        # Reemplazar el valor existente con el correcto
        java_opts_ext = re.sub(ram_percentage_pattern, f'-XX:MaxRAMPercentage={target_percentage}', java_opts_ext)
        logger.info(f"✅ MaxRAMPercentage actualizado a {target_percentage} para entorno {env_type}")
    else:
        # Añadir MaxRAMPercentage si no existe
        java_opts_ext = f"{java_opts_ext} -XX:MaxRAMPercentage={target_percentage}".strip()
        logger.info(f"✅ MaxRAMPercentage añadido ({target_percentage}) para entorno {env_type}")
    
    # CONSTRUIR RESULTADO FINAL: Kerberos SIEMPRE primero, luego el resto
    if java_opts_ext:
        processed_opts = f"{required_krb_option} {java_opts_ext}".strip()
    else:
        processed_opts = required_krb_option
    
    logger.info(f"✅ java_opts_ext procesado para {env_type} con Kerberos obligatorio como primera opción")
    logger.info(f"   Resultado: {processed_opts}")
    
    return processed_opts


def modify_values_environment_yaml(content: str, oam_data: dict, clean_namespace: str,
                                  region: str = "bo1", env_type: str = "cert", old_name: str = "", 
                                  extra_env_vars: list = None, service_type: str = "backend", 
                                  java_opts_ext: str = "", pom_content: str = None, is_configmap: bool = False) -> str:
    """
    Genera un nuevo archivo values-{env_type}.yaml usando la plantilla Jinja2.
    IMPORTANTE: Para ConfigMaps usa valuesCM.yaml.j2, para Backend/Frontend usa values-env.yaml.j2
    
    Args:
        content: Contenido original (ignorado, se genera nuevo)
        oam_data: Datos del OAM parseados (con environments)
        clean_namespace: Namespace limpio
        region: Región (default: bo1)
        env_type: Tipo de entorno (cert, pre, pro)
        old_name: Nombre del servicio
        extra_env_vars: Lista de variables de entorno extraídas del deployment
        service_type: Tipo de servicio (backend, frontend, etc.)
        java_opts_ext: Opciones JVM extendidas del microservicio
        pom_content: Contenido del pom.xml para extraer Darwin version (opcional)
        is_configmap: True si es ConfigMap (usa valuesCM.yaml.j2), False para Backend/Frontend (usa values-env.yaml.j2)
        
    Returns:
        str: Contenido YAML generado con la plantilla correcta
    """
    try:
        # Importar Jinja2 para renderizar plantillas
        from jinja2 import Environment, FileSystemLoader, select_autoescape
        import os
        
        logger.info(f"Generando values-{env_type}.yaml usando plantilla Jinja2...")
        
        # Configurar el entorno Jinja2
        template_dir = os.path.join(os.path.dirname(__file__), '..', 'templates')
        jinja_env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(['html', 'xml'])
        )
        
        # SELECCIÓN DE PLANTILLA SEGÚN EL TIPO DE SERVICIO
        if is_configmap:
            # Para ConfigMaps usar plantilla específica valuesCM.yaml.j2
            template = jinja_env.get_template('valuesCM.yaml.j2')
            logger.info(f"✅ ConfigMap: Usando plantilla valuesCM.yaml.j2 para values-{env_type}.yaml")
            
            # Preparar application_name sin prefijo cm- (el template lo añadirá automáticamente)
            # Para ConfigMaps usar el application_name del oam_data, no el old_name
            app_name = oam_data.get('application_name', old_name)
            if app_name.startswith('cm-'):
                app_name = app_name[3:]  # Remover prefijo cm- si existe
                logger.info(f"🔧 Removido prefijo cm- de {oam_data.get('application_name', old_name)} -> {app_name}")
            else:
                logger.info(f"🔧 Usando application_name: {app_name}")
            
            # Obtener el sufijo del entorno para ConfigMaps (pro-b -> -b, pro-g-test -> -g-test, etc.)
            environment_suffix = get_environment_suffix(env_type)
            logger.info(f"🏷️ Sufijo de entorno para {env_type}: '{environment_suffix}'")
            
            # Renderizar template ConfigMap
            rendered_content = template.render(
                environment=env_type,  # ✅ AÑADIDA LA VARIABLE FALTANTE
                application_name=app_name,
                environment_suffix=environment_suffix
            )
            
            logger.info(f"✅ ConfigMap values-{env_type}.yaml generado con valuesCM.yaml.j2")
            return rendered_content
        else:
            # Para Backend/Frontend usar plantilla tradicional values-env.yaml.j2
            template = jinja_env.get_template('values-env.yaml.j2')
            logger.info(f"✅ Backend/Frontend: Usando plantilla values-env.yaml.j2 para values-{env_type}.yaml")
        
        # Preparar variables específicas del entorno
        spring_profile = env_type if env_type != 'cert' else 'cert'
        
        # Determinar el porcentaje de RAM por defecto según el entorno
        default_ram_percentage = "70.0" if env_type == "pro" else "50.0"
        
        # Procesar java_opts_ext SIEMPRE para microservicios backend (incluso si viene vacío)
        java_opts_ext_processed = ""
        if service_type == "backend":
            # PROCESAR SIEMPRE: Incluso si java_opts_ext está vacío, debe incluir opciones obligatorias
            java_opts_ext_processed = _process_java_opts_ext_for_environment(java_opts_ext or "", env_type)
            logger.info(f"🔧 JAVA_OPTS_EXT procesado para {service_type} en {env_type}: {java_opts_ext_processed}")
        
        # Extraer Darwin version del pom.xml si está disponible
        darwin_version = None  # Inicializar como None para usar default del template
        if pom_content:
            try:
                logger.info(f"🔄 Extrayendo Darwin version del pom.xml para values-{env_type}.yaml...")
                logger.info(f"🔍 DEBUG: pom_content recibido (primeros 200 chars): {pom_content[:200]}...")
                extracted_version = extract_darwin_version_from_pom(pom_content)
                if extracted_version:
                    darwin_version = extracted_version
                    logger.info(f"✅ Darwin version extraído para {env_type}: {darwin_version}")
                else:
                    logger.warning(f"⚠️ No se pudo extraer Darwin version del pom.xml para {env_type}, usando default del template")
            except Exception as e:
                logger.error(f"❌ Error al extraer Darwin version del pom.xml para {env_type}: {e}, usando default del template")
        else:
            logger.warning(f"⚠️ No se proporcionó contenido del pom.xml para {env_type}, usando Darwin version default del template")
        
        template_vars = {
            'spring_profile': spring_profile,
            'extra_env_vars': extra_env_vars if extra_env_vars is not None else [],
            'service_type': service_type,
            'java_opts_ext_processed': java_opts_ext_processed,
            'default_ram_percentage': default_ram_percentage
        }
        
        # Solo pasar darwin_version si se extrajo correctamente del pom.xml
        if darwin_version:
            template_vars['darwin_version'] = darwin_version
            logger.info(f"🎯 Darwin version {darwin_version} será usado en template para {env_type}")
        else:
            logger.info(f"🎯 No se extrajo Darwin version, template usará valor por defecto para {env_type}")
        
        # Renderizar la plantilla
        rendered_content = template.render(**template_vars)
        
        logger.info(f"✅ Plantilla values-{env_type}.yaml generada correctamente ({len(rendered_content)} caracteres)")
        logger.info(f"🔒 IMPORTANTE: Los contextos de seguridad solo están en values.yaml principal, NO en values-{env_type}.yaml")
        
        return rendered_content
        
    except Exception as e:
        logger.error(f"Error generando values-{env_type}.yaml con plantilla Jinja2: {str(e)}")
        logger.error("❌ No se puede generar el archivo sin la plantilla Jinja2")
        raise Exception(f"Error al renderizar plantilla values-env.yaml.j2 para {env_type}: {str(e)}")




def modify_bootstrap_yml(content: str, app_name: str) -> Tuple[str, Dict[str, Any]]:
    """
    Modifica el archivo bootstrap.yml eliminando la configuración spring.cloud.config
    y manteniendo el resto de la configuración.
    
    Args:
        content: Contenido original del bootstrap.yml
        app_name: Nombre de la aplicación
    
    Returns:
        Tuple[str, Dict[str, Any]]: (Contenido modificado del bootstrap.yml, resumen de cambios)
    """
    try:
        changes = {
            'removed_config': [],
            'modified_config': [],
            'preserved_config': []
        }
        
        yaml = YAML()
        yaml.preserve_quotes = True
        yaml.indent(mapping=2, sequence=4, offset=2)
        
        # Cargar contenido existente
        if not content or not content.strip():
            logger.info("Bootstrap.yml está vacío, no hay cambios que hacer")
            return content, changes
            
        data = yaml.load(content)
        if not data:
            logger.info("Bootstrap.yml no contiene datos válidos")
            return content, changes
        
        # Verificar y procesar configuración de spring
        if 'spring' in data:
            spring_config = data['spring']
            
            # Verificar si existe cloud.config y eliminarlo
            if 'cloud' in spring_config:
                cloud_config = spring_config['cloud']
                
                if 'config' in cloud_config:
                    # Eliminar configuración del config server
                    del cloud_config['config']
                    changes['removed_config'].append('Eliminada configuración spring.cloud.config')
                    logger.info("✅ Eliminada configuración spring.cloud.config de bootstrap.yml")
                
                # Si cloud queda vacío, eliminarlo también
                if not cloud_config or len(cloud_config) == 0:
                    del spring_config['cloud']
                    changes['removed_config'].append('Eliminada sección spring.cloud (quedó vacía)')
                    logger.info("✅ Eliminada sección spring.cloud vacía")
                else:
                    # Preservar otras configuraciones de cloud
                    for key in cloud_config.keys():
                        changes['preserved_config'].append(f'Preservada configuración spring.cloud.{key}')
            
            # Preservar otras configuraciones de spring
            for key in spring_config.keys():
                if key != 'cloud':
                    changes['preserved_config'].append(f'Preservada configuración spring.{key}')
        
        # Preservar configuraciones fuera de spring
        for key in data.keys():
            if key != 'spring':
                changes['preserved_config'].append(f'Preservada configuración {key}')
        
        # Generar contenido modificado
        yaml = YAML()
        yaml.indent(mapping=2, sequence=4, offset=2)
        yaml.width = 1000
        yaml.preserve_quotes = True
        
        string_stream = io.StringIO()
        yaml.dump(data, string_stream)
        result = string_stream.getvalue()
        
        logger.info("Bootstrap.yml procesado correctamente")
        return result, changes
        
    except Exception as e:
        logger.error(f"Error al procesar bootstrap.yml: {str(e)}")
        return content, {'error': [str(e)]}





async def _create_initial_file_content(file_path: str, old_name: str, namespace: str, 
                                     java_opts_ext: str, region: str = "bo1", 
                                     oam_data: Optional[Dict] = None, is_configmap: bool = False,
                                     env_override: Optional[str] = None) -> Tuple[Optional[str], Optional[str]]:
    """
    Crea contenido inicial para archivos que no existen en la rama feature usando plantillas Jinja2.
    
    Returns:
        Tuple[content: str, sha: str] con contenido inicial y sha None para creación
    """
    try:
        logger.info(f"🔧 Creando contenido inicial para {file_path}")
        
        # Importar Jinja2 para renderizar plantillas
        from jinja2 import Environment, FileSystemLoader, select_autoescape
        import os
        
        # Configurar el entorno Jinja2
        template_dir = os.path.join(os.path.dirname(__file__), '..', 'templates')
        logger.info(f"📁 Directorio de plantillas: {template_dir}")
        logger.info(f"📋 Directorio existe: {os.path.exists(template_dir)}")
        
        if os.path.exists(template_dir):
            logger.info(f"📋 Archivos en directorio templates: {os.listdir(template_dir)}")
        
        jinja_env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(['html', 'xml'])
        )
        
        if file_path.endswith('values.yaml'):
            logger.info(f"📝 Procesando archivo values.yaml (is_configmap={is_configmap})")
            
            if is_configmap:
                # Para ConfigMaps usar plantilla específica valuesCM.yaml.j2
                template = jinja_env.get_template('valuesCM.yaml.j2')
                logger.info(f"✅ Plantilla valuesCM.yaml.j2 cargada exitosamente para ConfigMap")
                
                # Preparar application_name sin prefijo cm- (el template lo añadirá automáticamente)
                app_name = old_name
                if app_name.startswith('cm-'):
                    app_name = app_name[3:]  # Remover prefijo cm- si existe
                    logger.info(f"🔧 Removido prefijo cm- de {old_name} -> {app_name}")
                
                # Obtener el sufijo del entorno para ConfigMaps (pro-b -> -b, pro-g-test -> -g-test, etc.)
                environment_suffix = ""
                if env_override:
                    environment_suffix = get_environment_suffix(env_override)
                    logger.info(f"🏷️ Sufijo de entorno para {env_override}: '{environment_suffix}'")
                
                # Preparar variables para la plantilla de ConfigMap
                template_vars = {
                    'environment': env_override or 'cert',  # ✅ AÑADIDA LA VARIABLE FALTANTE
                    'application_name': app_name,
                    'environment_suffix': environment_suffix
                }
            else:
                # Para Backend/Frontend usar plantilla tradicional values.yaml.j2
                template = jinja_env.get_template('values.yaml.j2')
                logger.info(f"✅ Plantilla values.yaml.j2 cargada exitosamente para Backend/Frontend")
                
                # Preparar variables para la plantilla tradicional
                template_vars = {
                    'old_name': old_name,
                    'namespace': namespace,
                    'region': region,
                    'java_opts_ext': java_opts_ext,
                    'spring_profile': 'dev',
                    'replica_count': 1,
                    'extra_env_vars_cm': '',
                    'extra_env_vars_secret': '',
                    'extra_volumes': [],
                    'extra_volume_mounts': []
                }
            
            # Renderizar la plantilla
            logger.info(f"🎯 RENDERIZANDO TEMPLATE: {'valuesCM.yaml.j2' if is_configmap else 'values.yaml.j2'}")
            logger.info(f"📋 Variables del template: {list(template_vars.keys())}")
            content = template.render(**template_vars)
        
        elif file_path.endswith('cd.yml') or file_path.endswith('cd.yaml'):
            logger.info(f"📝 Procesando archivo cd.yml")
            # Detectar entorno desde la ruta
            env_type = "cert"
            if '/pre/' in file_path:
                env_type = "pre"
            elif '/pro/' in file_path:
                env_type = "pro"
            
            # Obtener ci_id del OAM usando la función correcta
            ci_id_value = "OAM-CI-ID"  # Valor por defecto
            if oam_data:
                try:
                    # Importar la función correcta para extraer ci_id
                    from ..common_utils import get_ci_id_from_oam
                    
                    # Usar la función especializada que maneja la extracción correctamente
                    ci_id, success, message = get_ci_id_from_oam(oam_data)
                    if success and ci_id:
                        ci_id_value = ci_id
                        logger.info(f"✅ ci_id extraído del OAM usando get_ci_id_from_oam: {ci_id_value}")
                    else:
                        logger.warning(f"⚠️ No se pudo extraer ci_id del OAM: {message}")
                        logger.warning(f"⚠️ Usando valor por defecto: {ci_id_value}")
                except Exception as e:
                    logger.warning(f"❌ Error extrayendo ci_id del OAM: {e}")
                    logger.warning(f"⚠️ Usando valor por defecto: {ci_id_value}")
            
            # Usar plantilla Jinja2 para cd.yaml
            logger.info(f"🔧 Cargando plantilla cd.yml.j2 para entorno {env_type}")
            template = jinja_env.get_template('cd.yml.j2')
            logger.info(f"✅ Plantilla cd.yml.j2 cargada exitosamente")
            
            # Preparar variables para la plantilla
            component_name = old_name
            if is_configmap and old_name.startswith('cm-'):
                component_name = old_name[3:]  # Remover prefijo cm- para que el template lo añada condicionalmente
            
            template_vars = {
                'ci_ids': [ci_id_value],  # La plantilla espera una lista ci_ids
                'component_name': component_name,
                'env_type': env_type,
                'is_configmap': is_configmap
            }
            
            # Renderizar la plantilla
            content = template.render(**template_vars)
        
        elif 'values-cert.yaml' in file_path or 'values-pre.yaml' in file_path or 'values-pro.yaml' in file_path:
            # Detectar entorno específico
            if 'cert' in file_path:
                env_suffix = "cert"
                env_name = "certification"
            elif 'pre' in file_path:
                env_suffix = "pre" 
                env_name = "preproduction"
            elif 'pro' in file_path:
                env_suffix = "pro"
                env_name = "production"
            else:
                env_suffix = "cert"
                env_name = "certification"
            
            # Usar plantilla Jinja2 para values específicos de entorno
            template = jinja_env.get_template('values-env.yaml.j2')
            
            # Solo usar el parámetro necesario para la plantilla
            template_vars = {
                'spring_profile': env_suffix if env_suffix != 'cert' else 'cert'
            }
            
            # Renderizar la plantilla
            content = template.render(**template_vars)
        
        else:
            logger.warning(f"Tipo de archivo no reconocido: {file_path}")
            return None, None
        
        logger.info(f"Contenido inicial creado para {file_path} ({len(content)} caracteres)")
        return content, None  # SHA None indica que es un archivo nuevo
        
    except Exception as e:
        logger.error(f"Error al crear contenido inicial para {file_path}: {str(e)}")
        logger.error("❌ No se puede generar el archivo sin las plantillas Jinja2")
        return None, None


def extract_darwin_major_version(version_string: str) -> Optional[str]:
    """
    Extrae el número de versión mayor de una cadena de versión.
    
    Args:
        version_string: Cadena de versión (ej: "3.1.0-RELEASE", "6.3.2", "4")
        
    Returns:
        str: Número de versión mayor (ej: "3", "6", "4") o None si no se puede extraer
    """
    try:
        import re
        
        # Buscar el primer número en la cadena
        match = re.search(r'^(\d+)', version_string.strip())
        if match:
            return match.group(1)
        return None
    except Exception:
        return None

def extract_darwin_version_from_pom(pom_content: str) -> Optional[str]:
    """
    Extrae la versión del Darwin Framework del pom.xml desde el elemento parent.
    Soporta múltiples formatos: 3.1.0-RELEASE, 6.3.2, etc.
    
    Args:
        pom_content: Contenido del pom.xml
        
    Returns:
        str: Versión del Darwin Framework (ej: "6.3.2", "3.1.0-RELEASE") o None si no se encuentra
    """
    try:
        import re
        
        logger.info("🔍 Iniciando extracción de Darwin version del pom.xml")
        
        # Verificar si contiene la palabra "darwin"
        if "darwin" not in pom_content.lower():
            logger.warning("⚠️ El pom.xml no contiene referencias a 'darwin'")
            return None
        
        logger.info("✅ El pom.xml contiene referencias a 'darwin'")
        
        # Patrones múltiples para diferentes formatos de groupId
        patterns = [
            # Patrón original: es.santander.darwin
            r'<parent>\s*.*?<groupId>es\.santander\.darwin</groupId>\s*<artifactId>darwin-spring-boot-starter-parent</artifactId>\s*<version>([^<]+)</version>.*?</parent>',
            # Patrón nuevo: com.santander.darwin  
            r'<parent>\s*.*?<groupId>com\.santander\.darwin</groupId>\s*<artifactId>darwin-spring-boot-starter-parent</artifactId>\s*<version>([^<]+)</version>.*?</parent>',
            # Patrón genérico: cualquier groupId que contenga darwin
            r'<parent>\s*.*?<groupId>[^<]*darwin[^<]*</groupId>\s*<artifactId>darwin-spring-boot-starter-parent</artifactId>\s*<version>([^<]+)</version>.*?</parent>'
        ]
        
        for i, pattern in enumerate(patterns, 1):
            logger.info(f"🔍 Aplicando patrón {i}/3...")
            match = re.search(pattern, pom_content, re.DOTALL | re.IGNORECASE)
            
            if match:
                darwin_version = match.group(1).strip()
                logger.info(f"✅ Versión Darwin extraída del pom.xml (patrón {i}): {darwin_version}")
                return darwin_version
        
        # Si no funciona con parent, buscar en dependencias normales
        logger.info("🔍 Buscando Darwin en dependencias normales...")
        dependency_patterns = [
            r'<dependency>\s*<groupId>[^<]*darwin[^<]*</groupId>\s*<artifactId>darwin-spring-boot-starter-parent</artifactId>\s*<version>([^<]+)</version>.*?</dependency>',
            r'<dependency>\s*<groupId>[^<]*darwin[^<]*</groupId>\s*<artifactId>[^<]*darwin[^<]*</artifactId>\s*<version>([^<]+)</version>.*?</dependency>'
        ]
        
        for i, pattern in enumerate(dependency_patterns, 1):
            logger.info(f"🔍 Aplicando patrón dependencia {i}/2...")
            match = re.search(pattern, pom_content, re.DOTALL | re.IGNORECASE)
            
            if match:
                darwin_version = match.group(1).strip()
                logger.info(f"✅ Versión Darwin extraída de dependencias (patrón {i}): {darwin_version}")
                return darwin_version
        
        # Debug: mostrar estructura del POM para diagnóstico
        logger.warning("⚠️ No se encontró versión de Darwin con ningún patrón")
        if "<parent>" in pom_content:
            parent_match = re.search(r'<parent>.*?</parent>', pom_content, re.DOTALL)
            if parent_match:
                logger.info(f"🔍 Bloque parent encontrado:\n{parent_match.group(0)[:500]}...")
        
        return None
            
    except Exception as e:
        logger.error(f"❌ Error al extraer versión Darwin del pom.xml: {str(e)}")
        return None
