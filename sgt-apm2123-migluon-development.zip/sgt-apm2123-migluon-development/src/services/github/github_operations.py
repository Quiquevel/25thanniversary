"""
Módulo para manejar todas las operaciones relacionadas con GitHub.
"""
import logging
from typing import Dict, Any, Optional
import aiohttp
from dataclasses import dataclass
from ..common_utils import get_proxy_config

logger = logging.getLogger(__name__)

@dataclass
class GitHubOperations:
    """Clase para manejar operaciones con GitHub."""
    def __init__(self, client):
        self.client = client
        if isinstance(client, aiohttp.ClientSession):
            self.session = client
            self.headers = {
                "Accept": "application/vnd.github.v3+json",
                "Authorization": f"token {client.token if hasattr(client, 'token') else ''}"
            }
            self.proxy_config = get_proxy_config()

    async def create_fork(self, repo: str) -> Dict[str, Any]:
        """Crear un fork del repositorio."""
        return await self.client.create_fork(repo)

    async def create_branch(self, repo: str, branch: str, source_branch: str = "main") -> Dict[str, Any]:
        """Crear una nueva rama en el repositorio."""
        repo_obj = await self.client.get_repo(repo)
        return await repo_obj.create_branch(branch, source_branch)

    async def get_file_content(self, repo: str, path: str, ref: Optional[str] = None) -> Dict[str, Any]:
        """Obtener el contenido de un archivo."""
        return await self.client.get_file_content(repo, path, ref)

    async def update_file(self, repo: str, path: str, content: str, message: str, sha: str, branch: str) -> Dict[str, Any]:
        """Actualizar un archivo en el repositorio."""
        return await self.client.update_file(repo, path, content, message, sha, branch)

    async def create_pull_request(self, repo: str, head: str, base: str, title: str, body: str) -> Dict[str, Any]:
        """Crear un pull request."""
        return await self.client.create_pull_request(repo, head, base, title, body)
        """
        Crea un backup de una rama específica.
        
        Args:
            owner: Propietario del repositorio
            repo: Nombre del repositorio
            branch: Nombre de la rama a respaldar
            backup_suffix: Sufijo para el nombre de la rama de backup
        
        Returns:
            Tuple[bool, str]: (éxito, estado de la rama)
        """
        try:
            # Verificar si la rama de backup ya existe
            backup_branch = f"backup/{branch}-{backup_suffix}"
            check_url = f"https://api.github.com/repos/{owner}/{repo}/branches/{backup_branch}"
            
            async with self.session.get(check_url, headers=self.headers, **self.proxy_config) as response:
                if response.status == 200:
                    return True, "exists"
            
            # Si no existe, crear el backup
            create_url = f"https://api.github.com/repos/{owner}/{repo}/git/refs"
            
            # Obtener el SHA del último commit de la rama original
            ref_url = f"https://api.github.com/repos/{owner}/{repo}/git/refs/heads/{branch}"
            async with self.session.get(ref_url, headers=self.headers, **self.proxy_config) as response:
                if response.status != 200:
                    return False, "error"
                data = await response.json()
                sha = data["object"]["sha"]
            
            # Crear la nueva rama
            payload = {
                "ref": f"refs/heads/{backup_branch}",
                "sha": sha
            }
            
            async with self.session.post(create_url, headers=self.headers, json=payload, **self.proxy_config) as response:
                return response.status == 201, "created"
                
        except Exception as e:
            logger.error(f"Error al crear backup de rama {branch}: {str(e)}")
            return False, "error"

    async def get_file_content(self, owner: str, repo: str, path: str, ref: str = "development") -> Optional[Dict]:
        """
        Obtiene el contenido de un archivo del repositorio.
        
        Args:
            owner: Propietario del repositorio
            repo: Nombre del repositorio
            path: Ruta al archivo
            ref: Referencia (rama, tag o commit)
            
        Returns:
            Optional[Dict]: Contenido del archivo y metadata o None si hay error
        """
        try:
            url = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={ref}"
            async with self.session.get(url, headers=self.headers, **self.proxy_config) as response:
                if response.status == 200:
                    return await response.json()
                return None
        except Exception as e:
            logger.error(f"Error al obtener archivo {path}: {str(e)}")
            return None

    async def update_file(self, owner: str, repo: str, path: str, content: str, message: str, sha: str) -> bool:
        """
        Actualiza un archivo en el repositorio.
        
        Args:
            owner: Propietario del repositorio
            repo: Nombre del repositorio
            path: Ruta al archivo
            content: Nuevo contenido del archivo
            message: Mensaje del commit
            sha: SHA del archivo actual
            
        Returns:
            bool: True si la actualización fue exitosa
        """
        try:
            url = f"https://api.github.com/repos/{owner}/{repo}/contents/{path}"
            payload = {
                "message": message,
                "content": content,
                "sha": sha
            }
            
            async with self.session.put(url, headers=self.headers, json=payload, **self.proxy_config) as response:
                return response.status == 200
                
        except Exception as e:
            logger.error(f"Error al actualizar archivo {path}: {str(e)}")
            return False