"""
Módulo de procesadores de archivos.
Contiene todas las funciones relacionadas con la modificación de archivos específicos como Dockerfile y pom.xml.
"""
import aiohttp
import re
from typing import Dict, Any, Optional, Tuple
from shuttlelib.utils.logger import logger
from ..github_client import GitHubClient


async def prepare_dockerfile_changes(session: aiohttp.ClientSession, repo_url: str, 
                                    git_token: str, old_name: str, clean_namespace: str) -> Tuple[str, Optional[str]]:
    """
    Prepara cambios para Dockerfile sin hacer commit (dry-run).
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre antiguo del servicio
        clean_namespace: Nuevo namespace/nombre limpio
        
    Returns:
        tuple: ("Dockerfile", nuevo_contenido) o ("", None) si no hay cambios o error
    """
    try:
        logger.info(f"Preparando cambios Dockerfile: {old_name} -> {clean_namespace}")
        
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner y repo de la URL
        match = re.search(r'/repos/([^/]+)/([^/]+)', repo_url)
        if not match:
            logger.error(f"No se pudo extraer owner/repo de la URL: {repo_url}")
            return "", None
        
        owner, repo = match.groups()
        logger.info(f"Extraído owner: {owner}, repo: {repo}")
        
        # Obtener contenido actual del Dockerfile
        result = await github_client.get_file_content(owner, repo, "Dockerfile")
        if not result:
            logger.warning("No se pudo obtener el contenido del Dockerfile")
            return "", None
        
        if len(result) != 2:
            logger.error(f"❌ ERROR: get_file_content devolvió {len(result)} valores para Dockerfile, se esperaban 2")
            return "", None
        
        content, file_sha = result
        
        # Realizar las modificaciones de reemplazo de texto
        modified_content = content.replace(old_name, clean_namespace)
        
        # Verificar si hubo cambios
        if modified_content != content:
            logger.info("✅ Cambios detectados en Dockerfile - preparado para commit")
            return "Dockerfile", modified_content
        else:
            logger.info("No hay cambios necesarios en Dockerfile")
            return "", None
            
    except Exception as e:
        logger.error(f"Error en prepare_dockerfile_changes: {str(e)}")
        return "", None


async def modify_dockerfile(session: aiohttp.ClientSession, repo_url: str, 
                           git_token: str, old_name: str, clean_namespace: str) -> bool:
    """
    Modifica el Dockerfile para actualizar referencias al nombre del servicio.
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre antiguo del servicio
        clean_namespace: Nuevo namespace/nombre limpio
        
    Returns:
        bool: True si la modificación fue exitosa, False en caso contrario
    """
    try:
        logger.info(f"Modificando Dockerfile: {old_name} -> {clean_namespace}")
        
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner y repo de la URL
        # repo_url formato: "https://api.github.com/repos/owner/repo"
        match = re.search(r'/repos/([^/]+)/([^/]+)', repo_url)
        if not match:
            logger.error(f"No se pudo extraer owner/repo de la URL: {repo_url}")
            return "ERROR"
        
        owner, repo = match.groups()
        logger.info(f"Extraído owner: {owner}, repo: {repo}")
        
        # Obtener contenido actual del Dockerfile
        result = await github_client.get_file_content(owner, repo, "Dockerfile")
        if not result:
            logger.warning("No se pudo obtener el contenido del Dockerfile")
            return "ERROR"
        
        # Verificar que result tiene exactamente 2 elementos y no es un directorio
        if len(result) != 2:
            logger.error(f"❌ ERROR: get_file_content devolvió {len(result)} valores para Dockerfile, se esperaban 2")
            logger.error(f"   Valores recibidos: {result}")
            return "ERROR"
            
        dockerfile_content, file_sha = result
        
        # Verificar que no es un directorio
        if dockerfile_content == "directory" and file_sha == "directory":
            logger.warning("⚠️ 'Dockerfile' es un directorio, no un archivo")
            return "NO_CHANGES"
        
        logger.info("✅ Contenido del Dockerfile obtenido exitosamente")
        
        # Aplicar transformaciones al Dockerfile
        modified_content = _transform_dockerfile_content(
            dockerfile_content, old_name, clean_namespace
        )
        
        # Actualizar el archivo si hay cambios
        if dockerfile_content != modified_content:
            result = await github_client.update_file(
                owner, repo, "Dockerfile", modified_content, file_sha,
                f"Update Dockerfile for {clean_namespace} migration"
            )
            
            if result.get("status") == "success":
                logger.info("Dockerfile actualizado correctamente")
                return "MODIFIED"  # Indica que se hicieron cambios
            else:
                logger.error(f"Error al actualizar Dockerfile: {result.get('error', 'Unknown error')}")
                return "ERROR"
        else:
            logger.info("No hay cambios en Dockerfile, archivo ya actualizado")
            return "NO_CHANGES"  # Indica que no hay cambios necesarios
            
    except Exception as e:
        logger.error(f"Error en modify_dockerfile: {str(e)}")
        return "ERROR"


async def prepare_pom_changes(session: aiohttp.ClientSession, repo_url: str, 
                             git_token: str, old_name: str, clean_namespace: str) -> Tuple[str, Optional[str]]:
    """
    Prepara cambios para pom.xml sin hacer commit (dry-run).
    
    Returns:
        tuple: ("pom.xml", nuevo_contenido) o ("", None) si no hay cambios o error
    """
    try:
        logger.info(f"🔧 PREPARANDO cambios pom.xml: {old_name} -> {clean_namespace}")
        
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner y repo de la URL
        match = re.search(r'/repos/([^/]+)/([^/]+)', repo_url)
        if not match:
            logger.error(f"❌ No se pudo extraer owner/repo de la URL: {repo_url}")
            return "", None
        
        owner, repo = match.groups()
        logger.info(f"✅ Extraído owner: '{owner}', repo: '{repo}'")
        
        # Obtener contenido actual del pom.xml
        result = await github_client.get_file_content(owner, repo, "pom.xml")
        if not result:
            logger.warning("⚠️ No se encontró pom.xml - omitiendo modificación")
            return "", None
        
        if len(result) != 2:
            logger.error(f"❌ ERROR: get_file_content devolvió {len(result)} valores para pom.xml")
            return "", None
        
        pom_content, file_sha = result
        
        # Verificar que no es un directorio
        if pom_content == "directory" and file_sha == "directory":
            logger.warning("⚠️ 'pom.xml' es un directorio, no un archivo")
            return "", None
        
        logger.info("✅ Contenido del pom.xml obtenido exitosamente")
        
        # Aplicar transformaciones al pom.xml
        modified_content = _transform_pom_content(pom_content, old_name, clean_namespace)

        # Verificar si hubo cambios
        if pom_content != modified_content:
            logger.info("✅ Cambios detectados en pom.xml - preparado para commit")
            # Dump diff para trazabilidad (como en el script manual)
            try:
                import difflib
                diff = difflib.unified_diff(
                    pom_content.splitlines(),
                    modified_content.splitlines(),
                    fromfile='original/pom.xml',
                    tofile='modified/pom.xml',
                    lineterm=''
                )
                logger.info("=== DIFF (primeras 20 líneas) ===\n" + '\n'.join(list(diff)[:20]))
            except Exception as e:
                logger.warning(f"No se pudo generar diff: {e}")
            return "pom.xml", modified_content
        else:
            logger.info("ℹ️ No hay cambios necesarios en pom.xml")
            return "", None
            
    except Exception as e:
        logger.error(f"❌ Error en prepare_pom_changes: {str(e)}")
        return "", None


async def modify_pom_file(session: aiohttp.ClientSession, repo_url: str, 
                         git_token: str, old_name: str, clean_namespace: str) -> bool:
    """
    Modifica el archivo pom.xml para actualizar configuraciones Maven.
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre antiguo del servicio
        clean_namespace: Nuevo namespace/nombre limpio
        
    Returns:
        bool: True si la modificación fue exitosa, False en caso contrario
    """
    try:
        logger.info(f"🔧 INICIO modify_pom_file: {old_name} -> {clean_namespace}")
        logger.info(f"📋 Parámetros: repo_url='{repo_url}', git_token={'[PRESENTE]' if git_token else '[AUSENTE]'}")
        
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner y repo de la URL
        match = re.search(r'/repos/([^/]+)/([^/]+)', repo_url)
        if not match:
            logger.error(f"❌ No se pudo extraer owner/repo de la URL: {repo_url}")
            return "ERROR"
        
        owner, repo = match.groups()
        logger.info(f"✅ Extraído owner: '{owner}', repo: '{repo}'")
        
        # Obtener contenido actual del pom.xml
        logger.info(f"🔍 Intentando obtener pom.xml desde {owner}/{repo}")
        result = await github_client.get_file_content(owner, repo, "pom.xml")
        
        # Log del resultado de manera más segura
        if result is None:
            logger.info("📊 Resultado de get_file_content: None")
        else:
            result_len = len(result) if hasattr(result, "__len__") else "N/A"
            logger.info(f"📊 Resultado de get_file_content: {type(result)} - longitud={result_len}")
            if hasattr(result, "__len__") and len(result) <= 3:
                logger.info(f"📊 Contenido del resultado: ")
        
        if not result:
            logger.warning("❌ No se pudo obtener el contenido del pom.xml - result es None/False")
            return "ERROR"
        
        # Verificar que result tiene exactamente 2 elementos y no es un directorio
        if len(result) != 2:
            logger.error(f"❌ ERROR: get_file_content devolvió {len(result)} valores, se esperaban 2")
            logger.error(f"   Valores recibidos: {result}")
            return "ERROR"
            
        pom_content, file_sha = result
        
        # Verificar que no es un directorio
        if pom_content == "directory" and file_sha == "directory":
            logger.warning("⚠️ 'pom.xml' es un directorio, no un archivo")
            return "NO_CHANGES"
        
        logger.info("✅ Contenido del pom.xml obtenido exitosamente")
        
        # Aplicar transformaciones al pom.xml
        modified_content = _transform_pom_content(
            pom_content, old_name, clean_namespace
        )
        
        # Debug: Comparar contenidos
        logger.info(f"🔍 COMPARANDO CONTENIDOS:")
        logger.info(f"   Original hash: {hash(pom_content)}")
        logger.info(f"   Modificado hash: {hash(modified_content)}")
        logger.info(f"   ¿Son diferentes?: {pom_content != modified_content}")
        
        if pom_content != modified_content:
            logger.info("🔄 CONTENIDO MODIFICADO - Actualizando archivo en GitHub")
            result = await github_client.update_file(
                owner, repo, "pom.xml", modified_content, file_sha,
                f"Update pom.xml for {clean_namespace} migration"
            )
            
            if result.get("status") == "success":
                logger.info("✅ pom.xml actualizado correctamente")
                return "MODIFIED"
            else:
                logger.error(f"❌ Error al actualizar pom.xml: {result.get('error', 'Unknown error')}")
                # Dump completo para diagnostico
                try:
                    logger.debug(f"modify_pom_file: resultado update_file completo: {result}")
                except Exception:
                    logger.debug("modify_pom_file: no se pudo serializar resultado completo")
                return "ERROR"
        else:
            logger.info("ℹ️ NO HAY CAMBIOS en pom.xml - contenido original = contenido modificado")
            logger.info("🎯 DEVOLVIENDO 'NO_CHANGES'")
            return "NO_CHANGES"
            
    except Exception as e:
        logger.error(f"Error en modify_pom_file: {str(e)}")
        return "ERROR"


def _transform_dockerfile_content(content: str, old_name: str, clean_namespace: str) -> str:
    """
    Aplica transformaciones específicas al contenido del Dockerfile.
    Actualiza versiones Java a las configuradas en launch.json
    
    Args:
        content: Contenido original del Dockerfile
        old_name: Nombre antiguo del servicio
        clean_namespace: Nuevo namespace/nombre limpio
        
    Returns:
        str: Contenido modificado del Dockerfile
    """
    try:
        modified_content = content
        
        # Versiones Java actualizadas (desde launch.json)
        java_versions = {
            "javase-8-ubi8": "1.7.8.RELEASE",
            "javase-11-ubi8": "1.10.7.RELEASE", 
            "javase-17-ubi8": "1.7.9.RELEASE",
            "javase-21-ubi8": "1.4.8.RELEASE"
        }
        
        # Actualizar versiones Java en FROM statements
        for java_image, new_version in java_versions.items():
            # Patrón: FROM registry.../produban/javase-XX-ubi8:VERSION as builder
            pattern = rf'(FROM\s+[^\s]+/produban/{re.escape(java_image)}):([^:\s]+)(\s+as\s+\w+)?'
            
            def replace_version(match):
                base_image = match.group(1)
                old_version = match.group(2)
                as_clause = match.group(3) or ""
                
                if old_version != new_version:
                    logger.info(f"Actualizando {java_image}: {old_version} -> {new_version}")
                    return f"{base_image}:{new_version}{as_clause}"
                else:
                    logger.info(f"{java_image} ya tiene la versión correcta: {new_version}")
                    return match.group(0)
            
            modified_content = re.sub(pattern, replace_version, modified_content, flags=re.IGNORECASE)
        
        # Validar que el Dockerfile modificado es sintácticamente correcto
        if _validate_dockerfile_syntax(modified_content):
            logger.info("Dockerfile transformado y validado correctamente")
            return modified_content
        else:
            logger.warning("Dockerfile modificado podría tener errores de sintaxis")
            return modified_content
            
    except Exception as e:
        logger.error(f"Error transformando Dockerfile: {str(e)}")
        return content


def _transform_pom_content(content: str, old_name: str, clean_namespace: str) -> str:
    """
    Aplica transformaciones específicas al contenido del pom.xml.
    SOLO modifica la versión si no cumple el formato X.X.X
    
    Args:
        content: Contenido original del pom.xml
        old_name: Nombre antiguo del servicio
        clean_namespace: Nuevo namespace/nombre limpio
        
    Returns:
        str: Contenido modificado del pom.xml
    """
    try:
        logger.info("🔍 INICIANDO _transform_pom_content")
        logger.info(f"📋 Parámetros: old_name='{old_name}', clean_namespace='{clean_namespace}'")
        logger.info(f"📄 Contenido pom.xml (primeras 200 chars): {content[:200]}...")
        
        modified_content = content
        
        # SOLO modificar la primera versión (del proyecto principal) que aparece después de <artifactId>
        # Buscar la primera versión que aparece en el proyecto principal (antes de <parent>)
        
        # Patrón más flexible: encontrar versión del proyecto principal
        # Busca: <artifactId>...</artifactId> (opcionalmente <packaging>...</packaging>) <version>CUALQUIER_VERSION</version>
        # Mejorado para capturar versiones con guiones como 2025-04-07-10-10
        project_version_pattern = r'(<artifactId>[^<]+</artifactId>\s*(?:<packaging>[^<]+</packaging>\s*)?<version>)([^<]+)(</version>)'
        
        # Intentar buscar de forma robusta usando un parser XML para localizar
        # la versión del proyecto (elemento <version> que no esté dentro de <parent>).
        version = None
        prefix = None
        suffix = None
        try:
            import xml.etree.ElementTree as ET

            root = ET.fromstring(content)

            # Detectar namespace si existe
            ns_map = {}
            if root.tag.startswith('{'):
                uri = root.tag.split('}')[0].strip('{')
                ns_map = {'m': uri}

            # Buscar la versión del proyecto como child directo de <project>
            if ns_map:
                proj_version_elem = root.find('m:version', ns_map)
            else:
                proj_version_elem = root.find('version')

            project_version = None
            project_artifact = None
            if proj_version_elem is not None and proj_version_elem.text:
                project_version = proj_version_elem.text.strip()

            # Buscar artifactId directo en proyecto para localizar contexto
            if ns_map:
                art_elem = root.find('m:artifactId', ns_map)
            else:
                art_elem = root.find('artifactId')

            if art_elem is not None and art_elem.text:
                project_artifact = art_elem.text.strip()

            xml_found = False
            if project_version:
                # Versión detectada por XML en el proyecto
                version = project_version
                xml_found = True
                # Simplificar: si la versión no cumple semver X.Y.Z, forzamos 1.0.0
                ver_pattern_simple = r'^\d+\.\d+\.\d+$'
                prefix = None
                suffix = None
                if re.match(ver_pattern_simple, version):
                    # Es válida, nothing to do
                    pass
                else:
                    # Buscamos la primera etiqueta <version> cuyo inner sea exactamente la version
                    replaced = False
                    for m in re.finditer(r'<version\b[^>]*>([\s\S]*?)</version>', content, flags=re.IGNORECASE):
                        inner = m.group(1).strip()
                        if inner != version:
                            continue
                        # verificar que no está dentro de un <parent> (texto antes/after)
                        start_idx = m.start()
                        before = content[:start_idx]
                        last_parent_open = before.rfind('<parent')
                        last_parent_close = before.rfind('</parent>')
                        if last_parent_open != -1 and last_parent_open > last_parent_close:
                            # está dentro de un parent -> ignorar
                            continue
                        # Reemplazamos sólo el contenido interno del tag <version>
                        abs_inner_start = m.start(1)
                        abs_inner_end = m.end(1)
                        new_inner = "1.0.0"
                        logger.info(f"🔄 REEMPLAZANDO contenido interno de <version> en offsets {abs_inner_start}:{abs_inner_end} por '1.0.0'")
                        modified_content = content[:abs_inner_start] + new_inner + content[abs_inner_end:]
                        replaced = True
                        # para información de contexto: usar offsets del tag completo
                        tag_start = m.start(0)
                        tag_end = m.end(0)
                        prefix = content[max(0, tag_start-200):tag_start]
                        suffix = content[tag_start: min(len(content), tag_start + (tag_end-tag_start) + 200)]
                        break
                    if not replaced:
                        # intento conservador: reemplazo textual del primer bloque que contenga la version
                        ver_marker = f"<version>{version}</version>"
                        if ver_marker in content:
                            logger.info("🔄 REEMPLAZO textual por bloque (fallback simple)")
                            modified_content = content.replace(ver_marker, '<version>1.0.0</version>', 1)
                        else:
                            logger.warning("⚠️ No se encontró el tag <version> exacto para reemplazar; se omite el cambio")

        except Exception:
            # Si el parseo falla, fallback al método por regex
            version = None

        # Si no pudimos localizar con XML, usar el método basado en regex que ya existía
        if version is None:
            selected_match = None
            for m in re.finditer(project_version_pattern, content, re.DOTALL):
                start = m.start()
                end = m.end()
                # Obtener un snippet contextual alrededor del match para diagnostico
                snippet = content[max(0, start-120):min(len(content), end+120)]
                # INFO para asegurar visibilidad en logging de consola
                logger.info(f"_transform_pom_content: regex candidate offsets {start}:{end} -> snippet (trunc): {snippet[:300]!r}")
                before = content[:start]
                last_parent_open = before.rfind('<parent')
                last_parent_close = before.rfind('</parent>')
                if last_parent_open != -1 and last_parent_open > last_parent_close:
                    logger.info("_transform_pom_content: candidate dentro de <parent> - ignorando")
                    continue
                selected_match = m
                logger.info(f"_transform_pom_content: candidate seleccionado en offsets {start}:{end}")
                break

            match = selected_match

            if match:
                prefix = match.group(1)
                version = match.group(2).strip()
                suffix = match.group(3)

        # ahora, si tenemos una versión, proceder a validación y posible reemplazo
        if version is not None:
            logger.info(f"✅ MATCH ENCONTRADO - Versión del proyecto: '{version}'")
            logger.info(f"📦 Bloque completo: '{prefix}{version}{suffix}'")

            # VALIDAR: Solo modificar si la versión NO cumple con naming convention X.X.X
            valid_version_pattern = r'^\d+\.\d+\.\d+$'

            if re.match(valid_version_pattern, version):
                logger.info(f"✅ Versión '{version}' ya cumple naming convention X.X.X - NO se modifica")
            else:
                logger.info(f"⚠️ DETECTADO: Versión '{version}' NO cumple naming convention X.X.X")
                logger.info(f"🔧 ACCIÓN: Cambiando versión inválida '{version}' a '1.0.0'")
                logger.info(f"📝 MOTIVO: Versiones con guiones como '2025-04-07-10-10' no son válidas")

                # Si detectamos la versión vía XML, reemplazamos cuidadosamente el tag <version>
                # teniendo en cuenta posibles saltos de línea/indentación entre tags y el valor.
                if 'xml_found' in locals() and xml_found:
                    logger.info("🔄 REEMPLAZO vía XML: intentado localizar tag <version> correspondiente al artifact")

                    replaced = False
                    # Si conocemos el artifactId, buscar la primera ocurrencia de <version> después del artifact
                    if project_artifact:
                        artifact_marker = f"<artifactId>{project_artifact}</artifactId>"
                        art_idx = content.find(artifact_marker)
                    else:
                        art_idx = -1

                    search_start = art_idx if art_idx != -1 else 0

                    # Buscar el primer tag <version> tras el artifact (o desde el inicio) y comparar su contenido
                    ver_match = re.search(r'<version\b[^>]*>([\s\S]*?)</version>', content[search_start:], flags=re.IGNORECASE)
                    if ver_match:
                        inner = ver_match.group(1).strip()
                        # Verificar que el inner coincide con la versión encontrada por XML
                        if inner == version:
                            abs_start = search_start + ver_match.start(0)
                            abs_end = search_start + ver_match.end(0)
                            new_tag = f"<version>1.0.0</version>"
                            logger.info(f"🔄 REEMPLAZANDO tag <version> encontrado en offsets {abs_start}:{abs_end}")
                            modified_content = content[:abs_start] + new_tag + content[abs_end:]
                            replaced = True
                        else:
                            logger.info(f"ℹ️ Tag <version> encontrado pero su contenido '{inner}' no coincide con version '{version}'")

                    # Si no reemplazamos todavía, intentar búsqueda global segura (evitando <parent>)
                    if not replaced:
                        logger.info("🔎 Intentando reemplazo global evitando <parent>...")
                        for m in re.finditer(r'<version\b[^>]*>([\s\S]*?)</version>', content, flags=re.IGNORECASE):
                            start_idx = m.start()
                            before = content[:start_idx]
                            last_parent_open = before.rfind('<parent')
                            last_parent_close = before.rfind('</parent>')
                            if last_parent_open != -1 and last_parent_open > last_parent_close:
                                # Esta ocurrencia está dentro de un <parent> -> saltar
                                continue

                            inner = m.group(1).strip()
                            if inner == version:
                                abs_start = m.start()
                                abs_end = m.end()
                                new_tag = f"<version>1.0.0</version>"
                                logger.info(f"🔄 REEMPLAZANDO tag <version> global en offsets {abs_start}:{abs_end}")
                                modified_content = content[:abs_start] + new_tag + content[abs_end:]
                                replaced = True
                                break

                    if not replaced:
                        # Fallback conservador: intentar reemplazo textual del bloque localizado previamente
                        logger.warning("⚠️ No se pudo reemplazar vía XML/reglas anteriores; usando reemplazo conservador por bloque")
                        old_version_block = f"{prefix}{version}{suffix}"
                        new_version_block = f"{prefix}1.0.0{suffix}"
                        logger.info(f"🔄 REEMPLAZANDO por bloque: '{old_version_block[:80]}...' -> '{new_version_block[:80]}...'")
                        modified_content = modified_content.replace(old_version_block, new_version_block, 1)
                else:
                    old_version_block = f"{prefix}{version}{suffix}"
                    new_version_block = f"{prefix}1.0.0{suffix}"
                    logger.info(f"🔄 REEMPLAZANDO: '{old_version_block}' -> '{new_version_block}'")
                    modified_content = modified_content.replace(old_version_block, new_version_block)

                # Verificar que el reemplazo funcionó
                if "1.0.0" in modified_content and version not in modified_content:
                    logger.info(f"✅ ÉXITO: Versión actualizada correctamente {version} -> 1.0.0")
                else:
                    logger.error(f"❌ ERROR: El reemplazo no funcionó correctamente")
                    logger.error(f"   Contenido sigue teniendo '{version}': {version in modified_content}")
                    logger.error(f"   Contenido tiene '1.0.0': {'1.0.0' in modified_content}")
        else:
            logger.warning("❌ NO MATCH: No se encontró la versión del proyecto en pom.xml")
            logger.warning(f"📄 Contenido analizado: {content[:500]}...")
        
        logger.info("🏁 FINALIZANDO _transform_pom_content")
        return modified_content
        
    except Exception as e:
        logger.error(f"Error transformando pom.xml: {str(e)}")
        return content


def _validate_dockerfile_syntax(content: str) -> bool:
    """
    Valida la sintaxis básica del Dockerfile.
    
    Args:
        content: Contenido del Dockerfile
        
    Returns:
        bool: True si la sintaxis es válida, False en caso contrario
    """
    try:
        lines = content.strip().split('\n')
        
        # Validaciones básicas
        valid_instructions = {
            'FROM', 'RUN', 'CMD', 'LABEL', 'EXPOSE', 'ENV', 'ADD', 'COPY',
            'ENTRYPOINT', 'VOLUME', 'USER', 'WORKDIR', 'ARG', 'ONBUILD',
            'STOPSIGNAL', 'HEALTHCHECK', 'SHELL'
        }
        
        has_from = False
        
        for line in lines:
            line = line.strip()
            
            # Ignorar líneas vacías y comentarios
            if not line or line.startswith('#'):
                continue
            
            # Obtener la primera palabra (instrucción)
            first_word = line.split()[0].upper()
            
            # Validar que la instrucción es válida
            if first_word not in valid_instructions:
                logger.warning(f"Instrucción desconocida en Dockerfile: {first_word}")
                return False
            
            # Verificar que existe al menos una instrucción FROM
            if first_word == 'FROM':
                has_from = True
        
        if not has_from:
            logger.warning("Dockerfile no contiene instrucción FROM")
            return False
        
        return True
        
    except Exception as e:
        logger.error(f"Error validando sintaxis de Dockerfile: {str(e)}")
        return False


def _validate_pom_syntax(content: str) -> bool:
    """
    Valida la sintaxis básica del pom.xml.
    
    Args:
        content: Contenido del pom.xml
        
    Returns:
        bool: True si la sintaxis es válida, False en caso contrario
    """
    try:
        import xml.etree.ElementTree as ET
        
        # Intentar parsear el XML
        ET.fromstring(content)
        
        # Validar elementos esenciales de Maven
        required_elements = ['<project', '<groupId', '<artifactId', '<version']
        
        for element in required_elements:
            if element not in content:
                logger.warning(f"Elemento requerido no encontrado en pom.xml: {element}")
                return False
        
        return True
        
    except ET.ParseError as e:
        logger.error(f"Error de sintaxis XML en pom.xml: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Error validando pom.xml: {str(e)}")
        return False


async def modify_properties_file(session: aiohttp.ClientSession, repo_url: str, 
                                git_token: str, old_name: str, clean_namespace: str,
                                file_path: str = "src/main/resources/application.properties") -> bool:
    """
    Modifica archivos de propiedades (application.properties, etc.).
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre antiguo del servicio
        clean_namespace: Nuevo namespace/nombre limpio
        file_path: Ruta del archivo de propiedades
        
    Returns:
        bool: True si la modificación fue exitosa, False en caso contrario
    """
    try:
        logger.info(f"Modificando archivo de propiedades: {file_path}")
        
        github_client = GitHubClient(session, git_token)
        
        # Obtener contenido actual
        result = await github_client.get_file_content(repo_url, file_path)
        if not result:
            logger.warning(f"No se pudo obtener el contenido de {file_path}")
            return False
        
        # Verificar que result tiene exactamente 2 elementos y no es un directorio
        if len(result) != 2:
            logger.error(f"❌ ERROR: get_file_content devolvió {len(result)} valores para {file_path}, se esperaban 2")
            logger.error(f"   Valores recibidos: {result}")
            return False
            
        properties_content, file_sha = result
        
        # Verificar que no es un directorio
        if properties_content == "directory" and file_sha == "directory":
            logger.warning(f"⚠️ '{file_path}' es un directorio, no un archivo")
            return False
        
        # Aplicar transformaciones a las propiedades
        modified_content = _transform_properties_content(
            properties_content, old_name, clean_namespace
        )
        
        # Actualizar el archivo si hay cambios
        if properties_content != modified_content:
            success = await github_client.update_file(
                repo_url, 
                file_path, 
                modified_content,
                f"Update {file_path} for {clean_namespace} migration"
            )
            
            if success:
                logger.info(f"Archivo {file_path} actualizado correctamente")
                return True
            else:
                logger.error(f"Error al actualizar {file_path}")
                return False
        else:
            logger.info(f"No hay cambios en {file_path}, archivo ya actualizado")
            return True
            
    except Exception as e:
        logger.error(f"Error en modify_properties_file: {str(e)}")
        return False


def _transform_properties_content(content: str, old_name: str, clean_namespace: str) -> str:
    """
    Aplica transformaciones específicas al contenido de archivos de propiedades.
    
    Args:
        content: Contenido original del archivo
        old_name: Nombre antiguo del servicio
        clean_namespace: Nuevo namespace/nombre limpio
        
    Returns:
        str: Contenido modificado del archivo
    """
    try:
        modified_content = content
        
        # Transformaciones específicas para archivos de propiedades
        transformations = [
            # Actualizar spring.application.name
            (rf'spring\.application\.name\s*=\s*{re.escape(old_name)}', 
             f'spring.application.name={clean_namespace}'),
            
            # Actualizar server.servlet.context-path
            (rf'server\.servlet\.context-path\s*=\s*/.*{re.escape(old_name)}.*', 
             f'server.servlet.context-path=/{clean_namespace}'),
            
            # Actualizar logging.file.name
            (rf'logging\.file\.name\s*=\s*.*{re.escape(old_name)}.*', 
             f'logging.file.name=/var/log/{clean_namespace}.log'),
            
            # Actualizar management.endpoints.web.base-path
            (rf'management\.endpoints\.web\.base-path\s*=\s*/.*{re.escape(old_name)}.*', 
             f'management.endpoints.web.base-path=/{clean_namespace}/actuator'),
        ]
        
        # Aplicar transformaciones
        for pattern, replacement in transformations:
            modified_content = re.sub(pattern, replacement, modified_content, flags=re.MULTILINE)
        
        logger.info("Archivo de propiedades transformado correctamente")
        return modified_content
        
    except Exception as e:
        logger.error(f"Error transformando archivo de propiedades: {str(e)}")
        return content


async def modify_bootstrap_yml(session: aiohttp.ClientSession, repo_url: str, 
                              git_token: str, old_name: str, clean_namespace: str) -> str:
    """
    Modifica el archivo bootstrap.yml eliminando la configuración spring.cloud.config.
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre antiguo del servicio
        clean_namespace: Nuevo namespace/nombre limpio
        
    Returns:
        str: "MODIFIED", "NO_CHANGES", "NOT_FOUND", o "ERROR"
    """
    try:
        logger.info(f"Procesando bootstrap.yml: {old_name} -> {clean_namespace}")
        
        github_client = GitHubClient(git_token, session)
        
        # Extraer owner y repo de la URL
        match = re.search(r'/repos/([^/]+)/([^/]+)', repo_url)
        if not match:
            logger.error(f"No se pudo extraer owner/repo de la URL: {repo_url}")
            return "ERROR"
        
        owner, repo = match.groups()
        logger.info(f"Extraído owner: {owner}, repo: {repo}")
        
        # Obtener contenido actual del bootstrap.yml desde la rama específica
        file_path = "src/main/resources/config/bootstrap.yml"
        branch = "feature/gluon-migration-config-from-pulse-import"
        logger.info(f"Buscando {file_path} en rama {branch}")
        result = await github_client.get_file_content(owner, repo, file_path, branch)
        if not result:
            logger.info("Archivo bootstrap.yml no encontrado en la rama de migración")
            return "NOT_FOUND"
        
        # Verificar que result tiene exactamente 2 elementos y no es un directorio
        if len(result) != 2:
            logger.error(f"❌ ERROR: get_file_content devolvió {len(result)} valores para {file_path}, se esperaban 2")
            logger.error(f"   Valores recibidos: {result}")
            return "ERROR"
            
        bootstrap_content, file_sha = result
        
        # Verificar que no es un directorio
        if bootstrap_content == "directory" and file_sha == "directory":
            logger.warning(f"⚠️ '{file_path}' es un directorio, no un archivo")
            return "NOT_FOUND"
        
        logger.info("✅ Contenido del bootstrap.yml obtenido exitosamente")
        
        # Importar la función de modificación desde operations
        from ..github.operations import modify_bootstrap_yml
        
        # Procesar el contenido
        modified_content, changes = modify_bootstrap_yml(bootstrap_content, clean_namespace)
        
        # Verificar si hubo cambios
        if modified_content != bootstrap_content:
            # Actualizar el archivo en GitHub
            commit_message = f"feat: limpiar configuración config server en bootstrap.yml para {clean_namespace} [ci skip]"
            
            update_result = await github_client.update_file(
                owner, repo, file_path, modified_content, file_sha, commit_message, branch
            )
            
            if update_result.get("status") == "success":
                logger.info("✅ Bootstrap.yml actualizado exitosamente")
                
                # Log de cambios realizados
                if changes.get('removed_config'):
                    for change in changes['removed_config']:
                        logger.info(f"   - {change}")
                
                return "MODIFIED"
            else:
                logger.error(f"Error al actualizar bootstrap.yml en GitHub: {update_result.get('error', 'Error desconocido')}")
                return "ERROR"
        else:
            logger.info("No hay cambios en bootstrap.yml, archivo ya limpio")
            return "NO_CHANGES"
            
    except Exception as e:
        logger.error(f"Error en modify_bootstrap_yml: {str(e)}")
        return "ERROR"


async def prepare_all_file_changes(session: aiohttp.ClientSession, repo_url: str, 
                                  git_token: str, old_name: str, clean_namespace: str,
                                  file_list: list = None) -> Dict[str, str]:
    """
    Prepara todos los cambios de archivos sin hacer commits (batch mode).
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio GitHub
        git_token: Token de GitHub
        old_name: Nombre antiguo del servicio
        clean_namespace: Nuevo namespace/nombre limpio
        file_list: Lista de archivos específicos a procesar (opcional)
    
    Returns:
        Dict con {file_path: new_content} para archivos que necesitan cambios
    """
    changes = {}
    
    # Lista por defecto de archivos a procesar
    if file_list is None:
        file_list = ["Dockerfile", "pom.xml"]
    
    try:
        logger.info(f"🔄 Preparando cambios batch para {len(file_list)} archivos")
        
        # Dockerfile
        if "Dockerfile" in file_list:
            file_path, content = await prepare_dockerfile_changes(session, repo_url, git_token, old_name, clean_namespace)
            if content is not None:
                changes[file_path] = content
        
        # pom.xml  
        if "pom.xml" in file_list:
            file_path, content = await prepare_pom_changes(session, repo_url, git_token, old_name, clean_namespace)
            if content is not None:
                changes[file_path] = content
        
        logger.info(f"✅ Batch preparación completada: {len(changes)} archivos con cambios")
        return changes
        
    except Exception as e:
        logger.error(f"❌ Error en prepare_all_file_changes: {str(e)}")
        return {}
