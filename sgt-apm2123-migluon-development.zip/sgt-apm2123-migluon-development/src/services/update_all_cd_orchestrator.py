"""Orquestador mínimo para update_all_cd_proyect.

Contiene la función `update_all_cd_project` que implementará el flujo completo.
Actualmente solo imprime "ok" para validar el endpoint.
"""
from typing import Dict, Any
import asyncio
from shuttlelib.utils.logger import logger
from .common_utils import normalize_oam_url, extract_repo_info, get_ci_id_from_oam, get_all_ci_ids_for_environment
from .openshift.processor import get_oam_from_git
from .respuestas import format_success, format_error, format_warning
from src.services.github.operations import modify_cd_yml_comprehensive
import re
from .github_client import GitHubClient
import aiohttp


async def update_all_cd_project(git_token: str, url_oam: str) -> Dict[str, Any]:
    """Orquestador inicial mínimo.

    Args:
        git_token: Token para acceder a GitHub
        url_oam: URL del OAM en el repositorio

    Returns:
        Dict[str, Any]: Resultado mínimo para validar el endpoint
    """
    # Aquí irá la lógica completa en siguientes pasos
    # Por ahora solo validamos que el orquestador se invoque correctamente
    logger.info("Iniciando orquestador update_all_cd_project")
    # Normalizar y procesar la URL del OAM tal y como hacen otros endpoints
    oam_complete_url = normalize_oam_url(url_oam) if url_oam else url_oam
    logger.info(f"URL OAM original: '{url_oam}'")
    logger.info(f"OAM URL normalizada: '{oam_complete_url}'")

    # Extraer el nombre del repositorio y derivar el nombre del proyecto (sin sufijos)
    proyecto = None
    try:
        owner, repo = extract_repo_info(oam_complete_url)
        # repo puede ser 'san-gascor-oam' o similar. Queremos 'san-gascor'.
        parts = repo.split('-')
        if len(parts) > 1:
            proyecto = '-'.join(parts[:-1])
        else:
            proyecto = repo
        logger.info(f"Repositorio extraído: '{repo}', proyecto derivado: '{proyecto}'")
    except Exception as e:
        logger.warning(f"No se pudo extraer el nombre del proyecto desde OAM URL: {str(e)}")
        proyecto = None

    # Si hemos obtenido un proyecto, listar repos en la organización que empiecen por ese proyecto
    project_repos = []
    if proyecto:
        org_name = "santander-group-spain-gln"
        try:
            # Usar Search API para reducir el número de repos devueltos por GitHub
            timeout = aiohttp.ClientTimeout(total=30)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                gh = GitHubClient(git_token, session)
                page = 1
                per_page = 100
                max_pages = 10  # suficiente para la mayoría de búsquedas

                # Query: buscar en la org y en el nombre; filtraremos por prefijo localmente
                base_q = f"org:{org_name} {proyecto} in:name"
                while True:
                    if page > max_pages:
                        logger.warning(f"Alcanzado max_pages={max_pages} en Search API, deteniendo")
                        break

                    url = f"https://api.github.com/search/repositories?q={aiohttp.helpers.quote(base_q)}&per_page={per_page}&page={page}"
                    try:
                        async with session.get(url, headers=gh.headers) as resp:
                            status = resp.status
                            body_text = await resp.text()
                            if status != 200:
                                logger.warning(f"Error Search API repos de {org_name}: HTTP {status} - {body_text[:500]}")
                                break
                            data = await resp.json()
                    except asyncio.TimeoutError:
                        logger.error(f"Timeout en Search API para {org_name} page={page}")
                        break
                    except Exception as e:
                        logger.error(f"Excepción Search API listando repos: {str(e)}")
                        break

                    items = data.get('items', []) if isinstance(data, dict) else []
                    if not items:
                        break

                    for r in items:
                        name = r.get('name', '')
                        # Filtrar por prefijo estricto en el cliente para evitar falsos positivos
                        if name.startswith(proyecto):
                            project_repos.append(f"https://github.com/{org_name}/{name}")

                    # Paginación: si hay menos items que per_page, hemos terminado
                    if len(items) < per_page:
                        break
                    page += 1
                    await asyncio.sleep(0.2)
        except Exception as e:
            logger.error(f"Excepción listando repos para proyecto {proyecto}: {str(e)}")

    # Ahora, si tenemos repos y una URL OAM válida, extraer el ci_id del OAM
    update_results = []
    modified_repos = []
    if project_repos and oam_complete_url:
        try:
            oam_data = await get_oam_from_git(oam_complete_url, git_token)
            ci_id, found_ci, ci_err = get_ci_id_from_oam(oam_data)
            if not found_ci or not ci_id:
                logger.warning(f"No se ha podido extraer ci_id del OAM: {ci_err}")
                # No podemos actualizar sin ci_id
                update_results.append(format_error("OAM", f"No se extrajo ci_id: {ci_err}"))
            else:
                # Abrir sesión para modificar repos en branch 'development'
                timeout = aiohttp.ClientTimeout(total=60)
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    gh = GitHubClient(git_token, session)
                    for repo_url in project_repos:
                        try:
                            owner, repo = extract_repo_info(repo_url)
                            # Determinar rama a usar: por defecto 'development'
                            branch_for_cd = 'development'
                            # Si no tiene Dockerfile en main, es un ConfigMap → usar branch 'main'
                            try:
                                docker_check = await gh.get_file_content(owner, repo, 'Dockerfile', branch='main')
                                if not docker_check:
                                    logger.info(f"Repo {owner}/{repo} no tiene Dockerfile en main → tratado como CONFIG_MAP")
                                    branch_for_cd = 'main'
                                else:
                                    # Si existe docker_check y es 'directory', no es un Dockerfile.
                                    if docker_check == ('directory', 'directory'):
                                        logger.info(f"Repo {owner}/{repo} tiene un directorio Dockerfile? ignorando y marcando como CONFIG_MAP")
                                        branch_for_cd = 'main'
                                    else:
                                        logger.info(f"Repo {owner}/{repo} tiene Dockerfile en main → tratado como microservicio (usar development)")
                            except Exception:
                                # Si la comprobación falla, asumimos que no hay Dockerfile
                                logger.info(f"No se pudo comprobar Dockerfile en {owner}/{repo}, asumiendo CONFIG_MAP (branch main)")
                                branch_for_cd = 'main'

                            # Listar archivos en .gluon/cd en la rama determinada
                            files = await gh.list_repository_files(owner, repo, branch=branch_for_cd, path='.gluon/cd')
                            if not files:
                                update_results.append(format_warning(repo, "No .gluon/cd en branch - saltado"))
                                continue

                            # Buscar cd.yml dentro de los paths listados y deducir el entorno por la ruta
                            cd_files = [f['path'] for f in files if f.get('path', '').endswith('/cd.yml')]
                            if not cd_files:
                                update_results.append(format_warning(repo, "No se encontraron cd.yml en .gluon/cd - saltado"))
                                continue

                            repo_success_files = []
                            repo_failures = []
                            for file_path in cd_files:
                                try:
                                    fc = await gh.get_file_content(owner, repo, file_path, branch=branch_for_cd)
                                    if not fc or fc == ('directory', 'directory'):
                                        repo_failures.append((file_path, 'No se pudo leer el archivo'))
                                        continue
                                    content, sha = fc

                                    # Determinar entorno a partir de la ruta: .gluon/cd/{env}/cd.yml
                                    env_type = 'cert'
                                    parts = file_path.split('/')
                                    # Expect .gluon, cd, <env>, cd.yml
                                    if len(parts) >= 4:
                                        env_type = parts[2]

                                    # Si es ConfigMap (branch main), necesitamos pasar required_ci_id
                                    is_configmap = (branch_for_cd == 'main')

                                    required_ci_id = None
                                    if is_configmap:
                                        # Obtener todos los ci_ids para ese entorno (PRO puede devolver varios)
                                        ci_list = get_all_ci_ids_for_environment(oam_data, env_type)
                                        if not ci_list:
                                            repo_failures.append((file_path, f'No CI_IDs encontrados en OAM para entorno {env_type} (ConfigMap)'))
                                            continue
                                        required_ci_id = ','.join(ci_list)

                                    # Extraer component_name existente para preservarlo (NO modificarlo)
                                    existing_component_name = repo
                                    existing_component_line = None
                                    try:
                                        m = re.search(r'^(\s*component_name:\s*.*)$', content, flags=re.M)
                                        if m:
                                            # conservar la linea completa tal como está (espacios/quotes)
                                            existing_component_line = m.group(1)
                                            # y también el valor sin comillas para pasarlo a la función como fallback
                                            val_m = re.search(r'^\s*component_name:\s*"?\'?(.+?)"?\'?\s*$', m.group(1))
                                            if val_m:
                                                existing_component_name = val_m.group(1).strip()
                                            else:
                                                # si no coincide, usar repo como fallback
                                                existing_component_name = repo
                                    except Exception:
                                        # Si cualquier cosa falla, usamos el repo como fallback
                                        existing_component_name = repo

                                    # Llamar a la función reutilizable que regenera cd.yml correctamente
                                    try:
                                        new_content = modify_cd_yml_comprehensive(content, oam_data, proyecto or repo, region='bo1', env_type=env_type, old_name=existing_component_name, is_configmap=is_configmap, required_ci_id=required_ci_id)
                                    except Exception as e:
                                        repo_failures.append((file_path, f'Error regenerando cd.yml: {str(e)}'))
                                        continue

                                    # Antes de comparar, asegurarnos de preservar la linea exacta component_name
                                    try:
                                        if existing_component_line:
                                            m_new = re.search(r'^(\s*component_name:\s*.*)$', new_content, flags=re.M)
                                            if m_new:
                                                # reemplazar la línea generada por la original exacta
                                                new_content = new_content[:m_new.start(1)] + existing_component_line + "\n" + new_content[m_new.end(1):]
                                            else:
                                                # si no existe en el regenerado, añadirla al principio
                                                new_content = existing_component_line + "\n" + new_content
                                    except Exception:
                                        # en caso de fallo en preservación, seguimos con el new_content regenerado
                                        pass

                                    if new_content == content:
                                        # No hubo cambio útil
                                        repo_failures.append((file_path, 'Contenido ya actualizado o sin cambios'))
                                        continue

                                    commit_message = f"Actualiza cd.yml desde OAM: {env_type} (branch {branch_for_cd})"
                                    ok = await gh.create_or_update_file(owner, repo, file_path, new_content, commit_message, branch=branch_for_cd)
                                    if ok:
                                        repo_success_files.append(file_path)
                                    else:
                                        repo_failures.append((file_path, 'Error al commitear cambios'))
                                except Exception as e:
                                    repo_failures.append((file_path, str(e)))

                            if repo_success_files and not repo_failures:
                                update_results.append(format_success(repo, f"Actualizados: {', '.join(repo_success_files)}"))
                                modified_repos.append(repo)
                            elif repo_success_files and repo_failures:
                                details = f"Actualizados: {', '.join(repo_success_files)}; Fallos: {repo_failures}"
                                update_results.append(format_warning(repo, details))
                                # incluir también como repo modificado (parcial)
                                modified_repos.append(repo)
                            else:
                                update_results.append(format_error(repo, f"No se actualizaron cd.yml: {repo_failures}"))

                        except Exception as e:
                            update_results.append(format_error(repo_url.split('/')[-1] if '/' in repo_url else repo_url, str(e)))
        except Exception as e:
            logger.error(f"Error procesando OAM para updates: {str(e)}")
            update_results.append(format_error('OAM', str(e)))

    # Construir resumen legible usando el formateador centralizado
    from .respuestas import format_cd_edit_summary
    summary = format_cd_edit_summary(modified_repos, update_results)

    return summary