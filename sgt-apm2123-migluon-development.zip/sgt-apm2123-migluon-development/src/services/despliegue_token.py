import base64
from typing import Optional, TYPE_CHECKING
from shuttlelib.utils.logger import logger
import aiohttp
import asyncio
import time
from src.utils.proxy_config import get_proxy_config

# Importación solo para type hints, evita dependencias circulares
if TYPE_CHECKING:
    from shuttlelib.openshift.client import OpenshiftClient

def get_ocp_client():
    """
    Obtiene la instancia del cliente OCP usando el singleton centralizado.
    Ya no crea nuevas instancias, reutiliza la única instancia del sistema.
    """
    try:
        from src.services.openshift.processor import get_openshift_client
        return get_openshift_client()
    except Exception as e:
        logger.warning(f"⚠️ No se pudo obtener cliente OpenShift singleton: {e}")
        return None

def get_openshift_client():
    """Alias para compatibilidad con código existente."""
    return get_ocp_client()

# Diccionario para mapear entorno, tipo y región a identificador shuttlelib
SHUTTLE_CLUSTERS = {
    "dev": {
        "intranet": {"bo1": {"cluster": "bks", "region": "bo1"}},
        "azure": {"weu1": {"cluster": "ocp05azure", "region": "weu1", "az": True}},
        "dmz": {"bo1": {"cluster": "bks", "region": "bo1"}},
        "mov": {"bo1": {"cluster": "bks", "region": "bo1"}}
    },
    "pre": {
        "intranet": {
            "bo1": {"cluster": "bks", "region": "bo1"},
            "bo2": {"cluster": "bks", "region": "bo2"}
        },
        "azure": {
            "weu1": {"cluster": "ocp05azure", "region": "weu1", "az": True},
            "weu2": {"cluster": "ocp05azure", "region": "weu2", "az": True}
        },
        "dmz": {
            "bo1": {"cluster": "bks", "region": "bo1"},
            "bo2": {"cluster": "bks", "region": "bo2"}
        },
        "mov": {
            "bo1": {"cluster": "bks", "region": "bo1"},
            "bo2": {"cluster": "bks", "region": "bo2"}
        }
    },
    "pro": {
        "intranet": {
            "bo1": {"cluster": "prodarwin", "region": "bo1"},
            "bo2": {"cluster": "prodarwin", "region": "bo2"}
        },
        "azure": {
            "weu1": {"cluster": "ocp05azure", "region": "weu1","az": True},
            "weu2": {"cluster": "ocp05azure", "region": "weu2", "az": True}
        },
        "dmz": {
            "bo1": {"cluster": "dmzbdarwin", "region": "bo1"},
            "bo2": {"cluster": "dmzbdarwin", "region": "bo2"}
        },
        "mov": {
            "bo1": {"cluster": "dmz2bmov", "region": "bo1"},
            "bo2": {"cluster": "dmz2bmov", "region": "bo2"}
        }
    }
}

class DespliegueTokenService:
    """Servicio para obtener el token de despliegue desde OpenShift usando shuttlelib."""

    def __init__(self):
        pass  # Se eliminó `self.env_mapping` porque no se utiliza.

    async def get_validated_clusters(self, namespace: str, clusters: str) -> dict:
        """
        Valida los parámetros y guarda los tokens en Vault usando save_tokens_dict_in_vault.
        """
        valid_clusters = ["intranet", "dmz", "azure", "mov", "movilidad"]

        clusters_key = clusters.lower()
        if clusters_key == "movilidad":
            clusters_key = "mov"

        if clusters_key not in valid_clusters:
            return {"error": f"Cluster inválido: {clusters}. Debe ser uno de {valid_clusters}"}

        regiones = set()
        for env, cluster_types in SHUTTLE_CLUSTERS.items():
            regiones.update(cluster_types.get(clusters, {}).keys())

        # Usar SHUTTLE_CLUSTERS para obtener los identificadores
        result = {}
        for env, cluster_types in SHUTTLE_CLUSTERS.items():
            ns_full = f"{namespace}-{env}"
            cluster_ids = cluster_types.get(clusters_key, {})
            result[env] = {
                "cluster_ids": cluster_ids,
                "namespace": ns_full
            }

        clusters_dict = {
            "cluster": clusters_key,
            "data": result
        }

        # Llamada a la función que obtiene los tokens
        tokens = await self.get_tokens_from_clusters(clusters_dict)

        # Generar respuesta para Swagger
        response = []
        for key, value in tokens.items():
            env, region = key.split("-")
            status = value.get("status", "KO")
            if status == "KO" and "error" in value:
                response.append(f"{env.capitalize()} {region.upper()} = KO ({value['error']})")
            else:
                response.append(f"{env.capitalize()} {region.upper()} = {status}")

        logger.info(f"===============Tokens obtenidos===============")
        return {"detail": "\n".join(response)}

    async def get_token_from_shuttle(self, params: dict, oc_client: "OpenshiftClient") -> Optional[str]:
        try:
            secrets_dict = await oc_client.get_resource(
                functional_environment=params["functional_environment"],
                cluster=params["cluster"],
                resource=params["resource"],
                namespace=params["namespace"],
                region=params["region"]
            )
        except Exception as e:
            logger.error(f"Error al obtener el secret: {e}")
            return f"Error: {str(e)}"

        for secret in secrets_dict.get(params["region"], {}).get("items", []):
            name = secret.get('metadata', {}).get('name', '')
            if name.startswith("despliegue-token"):
                token_b64 = secret.get('data', {}).get('token')
                if token_b64:
                    token = base64.b64decode(token_b64).decode('utf-8')
                    logger.info(f"Token obtenido en {params['namespace']} ({params['cluster']})")
                    return token

        # Si no existe el secret, crearlo y obtener el token
        logger.info(f"No existe el secret despliegue-token en {params['namespace']}, se va a crear")
        
        # Obtener la URL de la API del cluster desde el cliente de OpenShift
        api_url = oc_client.clusters.get(params["functional_environment"], {}).get(
            params["cluster"], {}).get(params["region"], {}).get("url")
        
        if not api_url:
            logger.error(f"No se pudo obtener la URL de la API para {params['functional_environment']}, {params['cluster']}, {params['region']}")
            return None
        
        # Crear el secret usando la función auxiliar
        new_token = await create_secret(
            api=api_url, 
            env=params["functional_environment"], 
            namespace=params["namespace"], 
            region=params["region"]
        )
        
        # Volver a consultar los secrets para obtener el token recién creado
        try:
            # Esperamos un momento para que el secret se cree completamente
            await asyncio.sleep(2)
            
            # Obtenemos de nuevo los secrets
            updated_secrets = await oc_client.get_resource(
                functional_environment=params["functional_environment"],
                cluster=params["cluster"],
                resource=params["resource"],
                namespace=params["namespace"],
                region=params["region"]
            )
            
            # Buscamos el secret recién creado
            for item in updated_secrets.get(params["region"], {}).get("items", []):
                if item['metadata']['name'].startswith("despliegue-token"):
                    token_b64 = item['data'].get('token')
                    if token_b64:
                        token = base64.b64decode(token_b64).decode('utf-8')
                        logger.info(f"Token obtenido del secret recién creado en {params['namespace']}")
                        return token
            
            logger.error(f"No se pudo obtener el token después de crear el secret en {params['namespace']}")
            return None
            
        except Exception as e:
            logger.error(f"Error al obtener el token después de crear el secret: {e}")
            return None

    async def get_tokens_from_clusters(self, clusters_dict: dict) -> dict:
        """
        Recorre el diccionario de clusters y obtiene el token de cada uno usando shuttlelib.
        """
        tokens = {}
        for env, info in clusters_dict['data'].items():
            namespace = info['namespace']
            logger.info(f"Procesando entorno: {env}, Namespace: {namespace}")
            logger.info(f"Clusters encontrados: {info['cluster_ids']}")

            for region, cluster_info in info['cluster_ids'].items():
                try:
                    logger.info(f"Procesando región: {region}, Cluster Info: {cluster_info}")
                    params = get_shuttle_params(env, clusters_dict['cluster'], region, namespace)
                    token = await self.get_token_from_shuttle(params, get_ocp_client())

                    # Si el entorno es pre y el token es error 403 o None, no insertes nada
                    if env == "pre" and (
                        token is None or
                        (isinstance(token, str) and "403" in token)
                    ):
                        logger.warning(f"Permiso denegado en pre para región {region}. No se insertará token.")
                        tokens[f"{env}-{region}"] = {
                            "namespace": namespace,
                            "cluster": params["cluster"],
                            "region": params["region"],
                            "status": "KO",
                            "error": "Permiso denegado (403)"
                        }
                        continue

                    # Guardar el token en el diccionario
                    tokens[f"{env}-{region}"] = {
                        "namespace": namespace,
                        "cluster": params["cluster"],
                        "region": params["region"],
                        "token": token,
                        "status": "OK" if token else "KO"
                    }
                    logger.info(f"Token obtenido para {env}-{region}: {'***' if token else 'No token'}")

                except Exception as e:
                    logger.warning(f"Error en entorno {env}, región {region}: {e}")
                    tokens[f"{env}-{region}"] = {
                        "namespace": namespace,
                        "cluster": cluster_info["cluster"],
                        "region": region,
                        "status": "KO",
                        "error": str(e)
                    }
                    continue
        return tokens

def get_shuttle_params(env: str, cluster_type: str, region: str, namespace: str) -> dict:
    cluster_info = SHUTTLE_CLUSTERS.get(env, {}).get(cluster_type, {}).get(region)
    if not cluster_info:
        raise ValueError(f"No se encuentra configuración para {env}, {cluster_type}, {region}")
    return {
        "functional_environment": env,
        "cluster": cluster_info["cluster"],
        "resource": "secrets",
        "namespace": namespace,
        "region": cluster_info["region"],
        "az": cluster_info.get("az", False)
    }

async def create_secret(api, env, namespace, region):
    """
    Crear un Secret deployer-token en el namespace para obtener el token.
    """
    # Asegurarnos de que tenemos el módulo aiohttp
    
    
    # Crear el cliente OpenShift para obtener tokens
    #ocpClient = OpenshiftClient("spain")
    
    secret_template = {
        "apiVersion": "v1",  # Añadido apiVersion
        "kind": "Secret",    # Añadido kind
        "metadata": {
            "name": f"despliegue-token-{int(time.time())}",  # Nombre único basado en timestamp
            "annotations": {
                "kubernetes.io/service-account.name": "despliegue"
            }
        },
        "type": "kubernetes.io/service-account-token"
    }
    
    # Obtener el token para la autenticación
    clusters = get_ocp_client().clusters[env]
    cluster_token = None
    
    # Buscar el cluster correcto
    for cluster_name, cluster_regions in clusters.items():
        for reg_name, reg_info in cluster_regions.items():
            # Comprobar si la URL coincide con la variable api
            if reg_info.get("url") == api:
                cluster_token = reg_info.get("token")
                break
        if cluster_token:
            break
    
    if not cluster_token:
        logger.error(f"No se pudo encontrar el token para {env}, {region}")
        return None
    
    # Crear el header para la petición
    header = {
        "Authorization": f"Bearer {str(cluster_token)}", 
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    
    # URL para crear el secret
    req_url = f"{api}/api/v1/namespaces/{namespace}/secrets"
    
    # Realizar la petición
    try:
        # Only GitHub API needs proxy - all internal corporate domains go direct
        if 'api.github.com' in req_url:
            proxy_config = get_proxy_config()
        else:
            proxy_config = {}  # No proxy for all other URLs (OpenShift APIs, etc.)
            
        async with aiohttp.ClientSession(**proxy_config) as session:
            # Usar SSL contextual para manejar certificados
            import ssl
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            async with session.post(
                url=req_url, 
                headers=header, 
                json=secret_template,
                ssl=ssl_context
            ) as response:
                status = response.status
                
                if status == 201:
                    logger.info(f"Secret creado correctamente en {namespace}")
                    return status
                elif status == 401:
                    logger.error(f"Token no autorizado para {namespace}")
                elif status == 403:
                    logger.error(f"Acceso denegado para {namespace}")
                else:
                    response_text = await response.text()
                    logger.error(f"Error al crear el secret: {status}, {response_text}")
                
                return status
    except Exception as e:
        logger.error(f"Excepción al crear el secret: {str(e)}")
        return None