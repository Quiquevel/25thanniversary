import os
import hvac
from typing import Dict, Optional, Any
from shuttlelib.utils.logger import logger

# Configuración global del cliente de Vault
_vault_client: Optional[hvac.Client] = None

def get_vault_client(token: str) -> hvac.Client:
    """
    Obtiene o crea una instancia del cliente de Vault.
    Utiliza el patrón Singleton para evitar múltiples conexiones.
    """
    global _vault_client

    if not token:
        raise ValueError("El token de autenticación no fue proporcionado.")

    if _vault_client is not None and _vault_client.is_authenticated():
        return _vault_client

    vault_url = os.getenv("VAULT_GLUON")
    if not vault_url:
        raise ValueError("Falta la variable de entorno VAULT_GLUON.")

    _vault_client = hvac.Client(url=vault_url, token=token, verify=False)

    if not _vault_client.is_authenticated():
        raise Exception("No se pudo autenticar con Vault usando el token proporcionado.")

    logger.info(f"Cliente de Vault autenticado correctamente en {vault_url}")
    return _vault_client


def validate_vault_token(token: str) -> Dict[str, Any]:
    """
    Valida si el token de Vault es válido y puede acceder a Vault.
    
    Args:
        token (str): Token de autenticación para Vault
        
    Returns:
        Dict con 'valid' (bool) y 'error' (str) si aplica
    """
    try:
        if not token or not token.strip():
            return {
                "valid": False,
                "error": "Token de Vault vacío o None"
            }
        
        vault_url = os.getenv("VAULT_GLUON")
        if not vault_url:
            return {
                "valid": False,
                "error": "Variable de entorno VAULT_GLUON no configurada"
            }

        # Crear cliente temporal para validación
        temp_client = hvac.Client(url=vault_url, token=token.strip(), verify=False)
        
        # Verificar autenticación
        if not temp_client.is_authenticated():
            return {
                "valid": False,
                "error": "Token de Vault inválido o expirado"
            }
        
        # Intentar hacer una operación básica para confirmar que el token funciona
        try:
            # Intentar leer metadatos del token (sin revelar información sensible)
            token_info = temp_client.auth.token.lookup_self()
            
            if not token_info or 'data' not in token_info:
                return {
                    "valid": False,
                    "error": "No se pudieron obtener metadatos del token"
                }
            
            logger.info("✅ Token de Vault validado correctamente")
            return {
                "valid": True,
                "token_data": {
                    "policies": token_info['data'].get('policies', []),
                    "ttl": token_info['data'].get('ttl', 0),
                    "renewable": token_info['data'].get('renewable', False)
                }
            }
            
        except Exception as lookup_error:
            logger.warning(f"No se pudo obtener información del token, pero está autenticado: {lookup_error}")
            # Si falla el lookup pero está autenticado, consideramos válido
            return {"valid": True}
            
    except Exception as e:
        logger.error(f"❌ Error al validar token de Vault: {str(e)}")
        return {
            "valid": False,
            "error": f"Error de conexión con Vault: {str(e)}"
        }


def vault_create_secret(path: str, secret: Dict[str, Any], token: str) -> str:
    """
    Crea o actualiza un secreto en Vault en la ruta especificada.
    
    Args:
        path (str): Ruta donde se guardará el secreto
        secret (Dict[str, Any]): Diccionario con el secreto a guardar
        token (str): Token de autenticación para Vault
        
    Returns:
        str: "OK" si el secreto se guardó correctamente, "KO" con detalles del error en caso contrario
    """
    client = get_vault_client(token)
    try:
        logger.info(f"=== INICIANDO VAULT CREATE SECRET ===")
        logger.info(f"Ruta completa: {path}")
        logger.info(f"Mount point: kv-v2")
        
        # Verificar si es entorno certification/dev para logging específico
        if "certification" in path or "/dev/" in path:
            logger.info(f"🔍 DEBUGGING CERTIFICATION/DEV: Ruta detectada como entorno de desarrollo")

        # Verificar si el cliente está autenticado
        if not client.is_authenticated():
            logger.error("Cliente de Vault no está autenticado")
            return "KO (Cliente no autenticado)"

        response = client.secrets.kv.v2.create_or_update_secret(
            path=path,
            secret=secret,
            mount_point="kv-v2"
        )

        # 🔍 VALIDACIÓN ESTRICTA DE LA RESPUESTA
        if not response:
            logger.error(f"❌ Respuesta de Vault vacía o None")
            return "KO (Respuesta vacía)"
            
        if not isinstance(response, dict):
            logger.error(f"❌ Respuesta de Vault no es un diccionario: {type(response)}")
            return f"KO (Tipo de respuesta inválido: {type(response)})"

        # Verificar que tiene request_id (indica que fue procesada)
        if 'request_id' not in response:
            logger.error(f"❌ Respuesta de Vault sin request_id: {response}")
            return f"KO (Sin request_id: {str(response)})"

        # Verificar que tiene datos
        if 'data' not in response or not response['data']:
            logger.error(f"❌ Respuesta de Vault sin datos: {response}")
            return f"KO (Sin datos: {str(response)})"

        # Verificar que los datos contienen version (prueba de éxito)
        data = response['data']
        if 'version' not in data:
            logger.error(f"❌ Respuesta de Vault sin versión en datos: {data}")
            return f"KO (Sin versión en datos: {str(data)})"

        # ✅ TODAS LAS VALIDACIONES PASARON
        version = data.get('version', 'N/A')
        created_time = data.get('created_time', 'N/A')
        
        logger.info(f"✅ Secreto creado/actualizado correctamente en: {path}")
        logger.info(f"   Versión: {version}")
        logger.info(f"   Creado: {created_time}")
        
        if "certification" in path or "/dev/" in path:
            logger.info(f"🔍 CERTIFICATION/DEV: Éxito confirmado - Version: {version}, Created: {created_time}")
        
        return "OK"

    except Exception as e:
        logger.error(f"✗ Error al crear/actualizar el secreto en Vault")
        logger.error(f"Ruta: {path}")
        logger.error(f"Tipo de error: {type(e).__name__}")
        logger.error(f"Mensaje de error: {str(e)}")
        if "certification" in path or "/dev/" in path:
            logger.error(f"🔍 CERTIFICATION/DEV: Exception details - {repr(e)}")
        return f"KO ({str(e)})"


async def insert_robot(harbor: str, env: str, clusters: str, datos: Dict[str, str], token: str, entidad: str = "san") -> Dict[str, Any]:
    """
    Inserta credenciales de RobotAccount en Vault.
    """
    if not datos:
        logger.error("No se proporcionaron datos para insertar en Vault.")
        return {"detail": "ko, no hay datos para insertar"}

    # Convertir harbor a minúsculas
    harbor = harbor.lower()

    logger.info(f"=== INSERT ROBOT ===")
    logger.info(f"Harbor: {harbor}")
    logger.info(f"Environment: {env}")
    logger.info(f"Cluster: {clusters}")
    
    # base_path usa 'san' por defecto; si en el futuro queremos parametrizarlo, podemos pasar 'entidad'
    base_path = f"{entidad}/{harbor}/ci-tools/{env}/artifact-management"
    
    # Mapeo de entornos a subdominios para el nombre del secreto
    env_subdomain_map = {
        "certification": "dev",
        "preproduction": "pre",
        "production": "pro"  # Valor por defecto, se ajustará según el cluster
    }
    
    # Determinar el subdominio para production basado en el cluster
    if env == "production":
        if clusters == "dmz":
            env_subdomain = "dmzb"
        else:
            env_subdomain = "pro"  # Para intranet u otros casos
    else:
        # Para certification y preproduction usamos el mapeo normal
        if clusters == "azure" and env == "certification":
            env_subdomain = "pre"  # Caso especial: azure + certification => pre
        else:
            env_subdomain = env_subdomain_map.get(env, env)

    # Mapeo de regiones dinámicas
    region_map = {
        "azure": "weu",
        "intranet": "bo1",
        "movilidad": "bo1",
        "dmz": "bo1",
        "default": "bo1"
    }
    
    try:
        # Determinar la región según el cluster
        region = region_map.get(clusters, "bo1")  # Valor predeterminado es bo1
        
        # Lista para rastrear los resultados de cada operación
        resultados = []
        
        for key, value in datos.items():
            # Construir el nombre del secreto con la región correcta
            if key == "user":
                secret_name = f"ohe_harbor_harbor_registry.harbor.san.{env_subdomain}.{region}.paas.cloudcenter.corp_basic_user"
            elif key == "pass":
                secret_name = f"ohe_harbor_harbor_registry.harbor.san.{env_subdomain}.{region}.paas.cloudcenter.corp_basic_pass"
            else:
                # Si la clave no es 'user' o 'pass', usar el nombre tal cual
                secret_name = key
            
            # LA RUTA COMPLETA DEBE INCLUIR EL SECRET_NAME AL FINAL
            secret_path = f"{base_path}/{secret_name}"
            logger.info(f"Procesando: {key}")
            logger.info(f"Ruta completa del secreto: {secret_path}")
            logger.info(f"Valor a guardar: ***[CENSURADO]***")
            
            # Pasar el token a vault_create_secret y capturar el resultado
            resultado = vault_create_secret(secret_path, {secret_name: value}, token)
            resultados.append(resultado)
            
            # Log del resultado específico
            if resultado == "OK":
                logger.info(f"✓ Secreto guardado exitosamente: {secret_name}")
            else:
                logger.error(f"✗ Error al guardar secreto {secret_name}: {resultado}")
        
        # 🔍 VERIFICAR SI TODOS LOS RESULTADOS FUERON EXITOSOS
        errores = []
        exitos = []
        
        for i, resultado in enumerate(resultados):
            if resultado != "OK":
                errores.append(f"Secret {i+1}: {resultado}")
            else:
                exitos.append(f"Secret {i+1}: OK")
        
        # Log detallado de resultados
        logger.info(f"📊 RESUMEN INSERT_ROBOT - Éxitos: {len(exitos)}, Errores: {len(errores)}")
        
        if errores:
            logger.error(f"❌ ALGUNOS SECRETOS FALLARON:")
            for error in errores:
                logger.error(f"   - {error}")
            return {"detail": f"ko, errores en vault: {'; '.join(errores)}"}
        
        logger.info("✅ TODOS LOS SECRETOS PROCESADOS CORRECTAMENTE")
        for exito in exitos:
            logger.info(f"   ✓ {exito}")
        
        return {"detail": "ok"}
    except Exception as e:
        logger.error(f"✗ Error al insertar secretos en Vault")
        logger.error(f"Base path: {base_path}")
        logger.error(f"Error: {str(e)}")
        return {"detail": f"ko, error al insertar en {base_path}: {str(e)}"}


async def process_insert(
    harbor: str,
    registry_username_certification: str, registry_pass_certification: str,
    registry_username_preproduction: str, registry_pass_preproduction: str,
    registry_username_production: str, registry_pass_production: str,
    clusters: str,
    token: str
) -> Dict[str, Any]:
    """
    Inserta credenciales de RobotAccount en Vault para los entornos especificados.
    """
    # Convertir harbor a minúsculas
    harbor = harbor.lower()

    # Validar que el token esté presente
    if not token:
        logger.error("El token de autenticación no fue proporcionado.")
        return {"success": False, "error": "Token de autenticación no proporcionado"}

    datos_certification = {
        "user": registry_username_certification,
        "pass": registry_pass_certification
    } if registry_username_certification and registry_pass_certification else None

    datos_preproduction = {
        "user": registry_username_preproduction,
        "pass": registry_pass_preproduction
    } if registry_username_preproduction and registry_pass_preproduction else None

    datos_production = {
        "user": registry_username_production,
        "pass": registry_pass_production
    } if registry_username_production and registry_pass_production else None

    result = {"successful": [], "failed": []}

    if datos_certification:
        result_certification = await insert_robot(harbor, "certification", clusters, datos_certification, token, entidad="san")
        if result_certification.get("detail") == "ok":
            result["successful"].append("certification")
        else:
            result["failed"].append("certification")

    if datos_preproduction:
        result_preproduction = await insert_robot(harbor, "preproduction", clusters, datos_preproduction, token, entidad="san")
        if result_preproduction.get("detail") == "ok":
            result["successful"].append("preproduction")
        else:
            result["failed"].append("preproduction")

    if datos_production:
        result_production = await insert_robot(harbor, "production", clusters, datos_production, token, entidad="san")
        if result_production.get("detail") == "ok":
            result["successful"].append("production")
        else:
            result["failed"].append("production")

    return result

async def save_tokens_dict_in_vault(dict: dict, vault_token: str, appkey: str, entidad: str = "san") -> dict:
    """
    Guarda los tokens de despliegue en Vault en la ruta específica para cada entorno y namespace.
    Retorna un diccionario con el estado de cada operación (OK o KO).
    """
    resultados = {}
    # Usar la entidad proporcionada
    entidad_default = entidad or "san"
    env_map = {
        "dev": "certification",
        "pre": "preproduction",
        "pro": "production"
    }

    for key, info in dict.items():
        try:
            # Extraer entorno y región
            entorno = key.split('-')[0]
            region = info.get("region", "bo1")
            value_path = env_map[entorno]

            # Determinar el valor dinámico según el entorno y cluster
            cluster = info.get("cluster", "default")
            if cluster == "ocp05azure":
                entorno_value = "ocp05"  # Siempre ocp05 para azure
            elif entorno == "pro" and cluster == "prodarwin":
                entorno_value = "san01darwin"  # Intranet en production
            elif entorno == "pro" and cluster in ["dmzbdarwin"]:
                entorno_value = "dmzb01darwin" 
            elif entorno == "pro" and cluster in ["dmz2mov"]:
                entorno_value = "movilidad"
            else:
                entorno_value = "san01bks"  # Valor predeterminado

            # Construir la ruta del secreto
            token = info.get("token", "XXXXXXXXXXX")
            
            # CASO ESPECIAL DMZ Y MOVILIDAD: Guardar token 2 veces con nombres diferentes
            if entorno == "pro" and cluster in ["dmzbdarwin", "dmz2bmov"]:
                if cluster == "dmzbdarwin":
                    # DMZ Darwin: Primera entrada dmzb01darwin + segunda san01darwin
                    secret_name_original = f"ohe_{region}_dmzb01darwin_{info['namespace']}_token"
                    vault_path_original = f"{entidad_default}/{appkey}/{value_path}/deployment/{secret_name_original}"
                    cluster_type_log = "DMZ Darwin"
                    
                elif cluster == "dmz2bmov":
                    # Movilidad: Primera entrada movilidad + segunda san01darwin
                    secret_name_original = f"ohe_{region}_movilidad_{info['namespace']}_token"
                    vault_path_original = f"{entidad_default}/{appkey}/{value_path}/deployment/{secret_name_original}"
                    cluster_type_log = "Movilidad"
                
                # Primera entrada: nombre específico del cluster
                logger.info(f"Guardando token {cluster_type_log} (original) en Vault: {vault_path_original}")
                response_original = vault_create_secret(vault_path_original, {secret_name_original: token}, vault_token)
                
                if response_original == "OK":
                    resultados[vault_path_original] = "OK"
                else:
                    resultados[vault_path_original] = response_original
                
                # Segunda entrada: san01darwin (común para ambos clusters DMZ)
                secret_name_darwin = f"ohe_{region}_san01darwin_{info['namespace']}_token"
                vault_path_darwin = f"{entidad_default}/{appkey}/{value_path}/deployment/{secret_name_darwin}"
                
                logger.info(f"Guardando token {cluster_type_log} (san01darwin) en Vault: {vault_path_darwin}")
                response_darwin = vault_create_secret(vault_path_darwin, {secret_name_darwin: token}, vault_token)
                
                if response_darwin == "OK":
                    resultados[vault_path_darwin] = "OK"
                else:
                    resultados[vault_path_darwin] = response_darwin
                    
                logger.info(f"✅ Token {cluster_type_log} guardado en 2 ubicaciones: {cluster} y san01darwin")
                
            else:
                # Comportamiento normal para otros clusters
                secret_name = f"ohe_{region}_{entorno_value}_{info['namespace']}_token"
                vault_path = f"{entidad_default}/{appkey}/{value_path}/deployment/{secret_name}"
                
                logger.info(f"Guardando token en Vault: {vault_path}")
                response = vault_create_secret(vault_path, {secret_name: token}, vault_token)
                
                if response == "OK":
                    resultados[vault_path] = "OK"
                else:
                    resultados[vault_path] = response
        except Exception as e:
            logger.error(f"Error al guardar el token en Vault para {key}: {e}")
            resultados[vault_path] = f"KO ({str(e)})"  # Si ocurre un error

    return resultados