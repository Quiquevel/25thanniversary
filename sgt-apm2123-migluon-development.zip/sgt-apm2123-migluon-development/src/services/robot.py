from typing import Dict, Any
from shuttlelib.utils.logger import logger
from src.services.vault import *
from src.services.harb import *

# ===================================
# CONFIGURACIÓN Y CONSTANTES
# ===================================

# Definir los registries por tipo de entorno
REGISTRY_GROUPS = {
    "intranet": {
        "certification": "registry.harbor.san.dev.bo1.paas.cloudcenter.corp",
        "preproduction": "registry.harbor.san.pre.bo1.paas.cloudcenter.corp",
        "production": "registry.harbor.san.pro.bo1.paas.cloudcenter.corp"
    },
    "dmz": {
        "certification": "registry.harbor.san.dev.bo1.paas.cloudcenter.corp",
        "preproduction": "registry.harbor.san.pre.bo1.paas.cloudcenter.corp",
        "production": "registry.harbor.san.dmzb.bo1.paas.cloudcenter.corp"
    },
    "azure": {
        "certification": "registry.harbor.san.pre.weu.paas.cloudcenter.corp",
        "preproduction": "registry.harbor.san.pre.weu.paas.cloudcenter.corp",
        "production": "registry.harbor.san.pro.weu.paas.cloudcenter.corp"
    }
}

# Mapeo de registries a entornos (para compatibilidad)
REGISTRY_ENV_MAP = {
    "registry.harbor.san.dev.bo1.paas.cloudcenter.corp": "certification",
    "registry.harbor.san.pre.bo1.paas.cloudcenter.corp": "preproduction",
    "registry.harbor.san.pro.bo1.paas.cloudcenter.corp": "production",
    "registry.harbor.san.dmzb.bo1.paas.cloudcenter.corp": "production",
    "registry.san.dev.weu.azure.paas.cloudcenter.corp": "certification",
    "registry.san.pre.weu.azure.paas.cloudcenter.corp": "preproduction",
    "registry.san.pro.weu.azure.paas.cloudcenter.corp": "production"
}

# ===================================
# FUNCIONES PRINCIPALES - CREAR E INSERTAR
# ===================================

async def create_robot_accounts_by_env_type(registry_project: str,clusters: str, appkey: str, vault_token: str) -> str:
    """
    Crear robot accounts para un proyecto en todos los registries del tipo de entorno especificado
    y guardar las credenciales en Vault automáticamente.
    """
    # 🔍 VALIDACIÓN CRÍTICA: Verificar token de Vault antes de crear robot accounts
    from src.services.vault import validate_vault_token
    
    logger.info("🔐 Validando token de Vault antes de crear robot accounts...")
    vault_validation = validate_vault_token(vault_token)
    
    if not vault_validation.get("valid", False):
        error_msg = vault_validation.get("error", "Token de Vault inválido")
        logger.error(f"❌ VALIDACIÓN VAULT FALLIDA: {error_msg}")
        return f"ERROR: Token de Vault inválido - {error_msg}"
    
    logger.info("✅ Token de Vault validado - procediendo con creación de robot accounts")
    
    try:
        # Obtener los registries correspondientes al tipo de entorno
        registries = get_registries_by_env_type(clusters)
    except ValueError as e:
        logger.error(f"Error al obtener registries para el entorno '{clusters}': {str(e)}")
        return f"Error: {str(e)}"

    # Variables para almacenar credenciales
    registry_credentials = {
        "certification": {"user": None, "pass": None},
        "preproduction": {"user": None, "pass": None},
        "production": {"user": None, "pass": None}
    }

    # Resultados
    harbor_results = []
    vault_results = []
    errors = []

    # Iterar sobre los registries del entorno
    for env_name, registry_url in registries.items():
        logger.info(f"Procesando proyecto '{registry_project}' en {env_name} ({registry_url})")

        # PASO 1: Verificar y añadir usuario shuttle si es necesario
        logger.info(f"Verificando usuario shuttle para proyecto '{registry_project}' en {env_name}")
        shuttle_ok = await ensure_shuttle_user(registry_url, registry_project)
        
        if not shuttle_ok:
            error_msg = f"No se pudo verificar/añadir el usuario shuttle en {env_name}"
            logger.error(error_msg)
            harbor_results.append(f"HARBOR {env_name.upper()}: Error - {error_msg}")
            errors.append(f"HARBOR {env_name.upper()}: {error_msg}")
            continue

        logger.info(f"✓ Usuario shuttle verificado/añadido correctamente en {env_name}")

        # PASO 2: Crear la robot account
        robot_name = f"vault-{env_name}"
        logger.info(f"Creando robot account: {robot_name}")

        result = await create_robot_account_direct(
            registry_url=registry_url,
            project=registry_project,
            robot_name=robot_name,
            permissions=DEFAULT_ROBOT_PERMISSIONS
        )

        if result.get("success"):
            logger.info(f"✓ Robot account '{robot_name}' creada exitosamente en {env_name}")
            harbor_results.append(f"HARBOR {env_name.upper()}: Creada robot account")

            # Guardar credenciales para este entorno
            registry_credentials[env_name] = {
                "user": result.get("name"),
                "pass": result.get("secret")
            }
        elif result.get("error") and "already exists" in result.get("error"):
            logger.warning(f"✗ Robot account '{robot_name}' ya existe en {env_name}. No se generaron nuevas credenciales.")
            harbor_results.append(f"HARBOR {env_name.upper()}: Ya existía la robot account")
        else:
            logger.error(f"✗ Error al crear la robot account: {result.get('error')}")
            harbor_results.append(f"HARBOR {env_name.upper()}: Error al crear la robot account")
            errors.append(f"HARBOR {env_name.upper()}: {result.get('error')}")

    # PASO 3: Enviar credenciales a Vault para cada entorno que tenga credenciales válidas
    # Importar función de eliminación
    from src.services.harb import delete_robot_account_direct
    
    created_robots = {}  # Para rastrear qué robots se crearon exitosamente
    
    for env_name, creds in registry_credentials.items():
        if creds["user"] and creds["pass"]:
            vault_result = await insert_robot(
                harbor=appkey.lower(),
                env=env_name,
                datos=creds,
                token=vault_token,
                clusters=clusters
            )
            
            if "detail" in vault_result and vault_result["detail"] == "ok":
                vault_results.append(f"VAULT {env_name.upper()}: Guardadas credenciales")
                # Marcar como exitoso
                created_robots[env_name] = {"success": True}
            else:
                vault_results.append(f"VAULT {env_name.upper()}: Error al guardar credenciales")
                errors.append(f"VAULT {env_name.upper()}: {vault_result.get('detail', 'Error desconocido')}")
                
                # ⚠️ ROLLBACK: Eliminar la robot account creada porque Vault falló
                logger.warning(f"🔄 ROLLBACK: Eliminando robot account de {env_name} porque falló Vault")
                registry_url = registries.get(env_name)
                robot_name = f"vault-{env_name}"
                
                if registry_url:
                    delete_result = await delete_robot_account_direct(
                        registry_url=registry_url,
                        project=registry_project,
                        robot_name=robot_name
                    )
                    
                    if delete_result.get("success"):
                        logger.info(f"✓ Robot account '{robot_name}' eliminada exitosamente (rollback)")
                        vault_results.append(f"ROLLBACK {env_name.upper()}: Robot account eliminada por fallo en Vault")
                    else:
                        logger.error(f"✗ Error al eliminar robot account '{robot_name}' (rollback): {delete_result.get('error')}")
                        errors.append(f"ROLLBACK {env_name.upper()}: Error al eliminar robot account: {delete_result.get('error')}")
                
                # Marcar como fallido
                created_robots[env_name] = {"success": False, "vault_error": vault_result.get('detail', 'Error desconocido')}
        else:
            vault_results.append(f"VAULT {env_name.upper()}: No se guardaron credenciales, al no crear nueva cuenta")
            created_robots[env_name] = {"success": False, "reason": "no_new_credentials"}

    # Construir el resumen
    summary = [
        f"Harbor: {registry_project.lower()}",
        f"Appkey: {appkey.lower()}",
        "",
        *harbor_results,
        "",
        *vault_results,
    ]

    if errors:
        summary.append("")
        summary.append("ERRORES:")
        summary.extend(errors)

    return "\n".join(summary)


async def create_robot_account_with_vault(
    registry_url: str, 
    project: str, 
    robot_name: str = None,
    save_to_vault: bool = True,
    vault_token: str = None
) -> Dict[str, Any]:
    """
    Crear una RobotAccount en Harbor y guardar las credenciales en Vault
    
    Args:
        registry_url: URL del registry
        project: Nombre del proyecto en Harbor
        robot_name: Nombre para la robot account (opcional, se genera automáticamente)
        save_to_vault: Si True, guarda las credenciales en Vault
        vault_token: Token de autenticación para Vault
        
    Returns:
        Dict con el resultado de la operación
    """
    # Verificar y añadir usuario shuttle si es necesario
    if not await ensure_shuttle_user(registry_url, project):
        return {
            "success": False,
            "error": "No se pudo verificar/añadir el usuario shuttle"
        }
    
    # Obtener el entorno basado en el registry
    env = REGISTRY_ENV_MAP.get(registry_url)
    if not env:
        logger.error(f"No se pudo determinar el entorno para {registry_url}")
        return {
            "success": False,
            "error": f"Registry {registry_url} no mapeado a ningún entorno"
        }
    
    # Generar nombre de robot si no se proporciona
    if not robot_name:
        robot_name = f"vault-{env}-{project}"

    # Crear la robot account usando la función de harb.py
    create_result = await create_harbor_robot_account(
        registry_url=registry_url,
        project=project,
        robot_name=robot_name,
        permissions=DEFAULT_ROBOT_PERMISSIONS
    )
    
    if not create_result.get("success"):
        return create_result
    
    # Construir el resultado
    result = {
        "success": True,
        "name": create_result.get("name"),
        "secret": create_result.get("secret"),
        "id": create_result.get("id"),
        "full_name": create_result.get("full_name"),
        "environment": env,
        "registry": registry_url
    }
    
    # Guardar credenciales en Vault si está habilitado
    if save_to_vault and create_result.get("secret") and vault_token:
        # Mapear el entorno al sufijo corto para las claves
        env_suffix_map = {
            "certification": "dev",
            "preproduction": "pre",
            "production": "pro"
        }
        
        env_suffix = env_suffix_map.get(env, env)
        
        # Construir las credenciales con el formato correcto
        user_key = f"ohe_harbor_harbor_registry.harbor.san.{env_suffix}.bo1.paas.cloudcenter.corp_basic_user"
        pass_key = f"ohe_harbor_harbor_registry.harbor.san.{env_suffix}.bo1.paas.cloudcenter.corp_basic_pass"
        
        credenciales = {
            user_key: create_result.get("full_name"),
            pass_key: create_result.get("secret")
        }
        
        # Guardar en Vault usando insert_robot de vault.py
        vault_result = await insert_robot(harbor=project, env=env, datos=credenciales, token=vault_token)
        
        if "detail" in vault_result and "ko" in vault_result["detail"]:
            logger.error(f"Error al guardar credenciales en Vault: {vault_result['detail']}")
            result["vault_saved"] = False
            result["vault_error"] = vault_result["detail"]
        else:
            logger.info(f"Credenciales guardadas exitosamente en Vault para {project}/{env}")
            result["vault_saved"] = True
    
    return result

def get_registries_by_env_type(registry_env: str) -> Dict[str, str]:
    """
    Obtiene los registries correspondientes al tipo de entorno especificado.

    Args:
        registry_env: Tipo de entorno (intranet, dmz, azure).

    Returns:
        Dict con los registries para certification, preproduction y production.

    Raises:
        ValueError: Si el tipo de entorno no es válido.
    """
    registries = REGISTRY_GROUPS.get(registry_env)
    if not registries:
        raise ValueError(f"El tipo de entorno '{registry_env}' no es válido. Opciones válidas: {', '.join(REGISTRY_GROUPS.keys())}")
    return registries