"""
Módulo para detectar servicios frontend basándose en archivos de configuración .json
"""
import aiohttp
import re
from typing import Dict, Any, Tuple, Optional, List
from shuttlelib.utils.logger import logger


def extract_config_filename_from_deployment(deployment_data: Optional[Dict], old_name: str) -> Optional[str]:
    """
    Extrae el nombre del archivo de configuración desde CONFIG_END_POINT en el deployment.yaml
    
    Ejemplo: CONFIG_END_POINT: http://configuration-service:8080/front/dev/master/front.json
    Devuelve: "front.json"
    
    Args:
        deployment_data: Datos del deployment.yaml de OpenShift
        old_name: Nombre del servicio para fallback
        
    Returns:
        str: Nombre del archivo de configuración o None si no se encuentra
    """
    try:
        if not deployment_data or not isinstance(deployment_data, dict):
            logger.warning(f"⚠️ No hay datos de deployment disponibles para {old_name}")
            return None
            
        # Buscar CONFIG_END_POINT en variables de entorno
        spec = deployment_data.get('spec', {})
        template = spec.get('template', {})
        pod_spec = template.get('spec', {})
        containers = pod_spec.get('containers', [])
        
        for container in containers:
            env_vars = container.get('env', [])
            for env_var in env_vars:
                if env_var.get('name') == 'CONFIG_END_POINT':
                    config_endpoint = env_var.get('value', '')
                    logger.info(f"🔍 CONFIG_END_POINT encontrado: {config_endpoint}")
                    
                    # Extraer el nombre del archivo desde la URL
                    # Ejemplo: http://configuration-service:8080/front/dev/master/front.json -> front.json
                    match = re.search(r'/([^/]+\.json)$', config_endpoint)
                    if match:
                        filename = match.group(1)
                        logger.info(f"✅ Archivo de configuración extraído: {filename}")
                        return filename
                    else:
                        logger.warning(f"⚠️ No se pudo extraer nombre de archivo de: {config_endpoint}")
                        
        logger.warning(f"⚠️ CONFIG_END_POINT no encontrado en deployment de {old_name}")
        return None
        
    except Exception as e:
        logger.error(f"❌ Error extrayendo CONFIG_END_POINT del deployment: {str(e)}")
        return None


def detect_frontend_config_files(config_files_in_memory: Dict[str, str], old_name: str, deployment_data: Optional[Dict] = None) -> Tuple[bool, List[Dict]]:
    """
    Detecta si el servicio es un frontend basándose en archivos .json compatibles con old_name
    en los archivos de configuración del config server.
    
    Args:
        config_files_in_memory: Archivos de configuración descargados del config server
        old_name: Nombre del servicio a buscar
        deployment_data: Datos del deployment.yaml para extraer CONFIG_END_POINT
        
    Returns:
        Tuple[is_frontend: bool, compatible_json_files: List[Dict]]
    """
    try:
        logger.info(f"🔍 Detectando si {old_name} es frontend basándose en archivos de configuración...")
        
        compatible_json_files = []
        
        # Debug: Mostrar todos los archivos .json disponibles
        json_files_available = [f for f in config_files_in_memory.keys() if f.endswith('.json')]
        logger.info(f"🔍 Archivos .json disponibles en config server ({len(json_files_available)}):")
        for json_file in json_files_available:
            logger.info(f"   - {json_file}")
        
        # PRIORIDAD 1: Extraer nombre correcto desde CONFIG_END_POINT del deployment
        target_filename = extract_config_filename_from_deployment(deployment_data, old_name)
        
        if target_filename:
            logger.info(f"🎯 Buscando archivo específico desde deployment: {target_filename}")
            
            # Buscar el archivo exacto extraído del deployment
            for file_path, file_content in config_files_in_memory.items():
                if not file_path.endswith('.json'):
                    continue
                    
                file_name = file_path.split('/')[-1]
                
                # Buscar coincidencia exacta con el archivo del deployment
                if file_name == target_filename:
                    compatible_json_files.append({
                        'file_path': file_path,
                        'file_name': file_name,
                        'content': file_content
                    })
                    logger.info(f"✅ Archivo de deployment encontrado: {file_path}")
                    break
                    
                # También buscar con variantes de entorno (-dev, -cert, etc.)
                base_name = target_filename.replace('.json', '')
                env_variants = [f"{base_name}-dev.json", f"{base_name}-cert.json", f"{base_name}-pre.json", f"{base_name}-pro.json"]
                
                if file_name in env_variants:
                    compatible_json_files.append({
                        'file_path': file_path,
                        'file_name': file_name,
                        'content': file_content
                    })
                    logger.info(f"✅ Variante de archivo de deployment encontrada: {file_path}")
        
        # FALLBACK: Si no se encontró desde deployment, usar patrones tradicionales
        if not compatible_json_files:
            logger.warning(f"⚠️ No se encontró archivo desde deployment, usando patrones fallback...")
            
            for file_path, file_content in config_files_in_memory.items():
                if not file_path.endswith('.json'):
                    continue
                
                file_name = file_path.split('/')[-1]
                
                # PRIORIDAD 2: Buscar patrones específicos con old_name
                specific_patterns = [
                    f"{old_name}-dev.json",
                    f"{old_name}-cert.json", 
                    f"{old_name}-pre.json",
                    f"{old_name}-pro.json",
                    f"{old_name}.json"
                ]
                
                # PRIORIDAD 3: Buscar patrones genéricos de frontend
                generic_patterns = [
                    "front-dev.json",
                    "front-cert.json", 
                    "front-pre.json",
                    "front-pro.json",
                    "front.json"
                ]
                
                # Verificar patrones específicos primero
                match_found = False
                for pattern in specific_patterns:
                    if file_name == pattern or file_path.endswith(pattern):
                        match_found = True
                        logger.info(f"✅ Archivo .json específico encontrado (fallback): {file_path}")
                        break
                
                # Si no se encuentra específico, buscar genéricos
                if not match_found:
                    for pattern in generic_patterns:
                        if file_name == pattern or file_path.endswith(pattern):
                            match_found = True
                            logger.info(f"✅ Archivo .json genérico de frontend encontrado (fallback): {file_path}")
                            break
                
                if match_found:
                    compatible_json_files.append({
                        'file_path': file_path,
                        'file_name': file_name,
                        'content': file_content
                    })
        
        is_frontend = len(compatible_json_files) > 0
        
        if is_frontend:
            logger.info(f"🎯 DETECTADO COMO FRONTEND: Encontrados {len(compatible_json_files)} archivos .json compatibles")
            for file_info in compatible_json_files:
                logger.info(f"   - {file_info['file_path']}")
        else:
            # Mensaje de error claro con información de debugging
            config_server_url = "https://github.alm.europe.cloudcenter.corp/sanes-gascor/config"
            logger.error(f"❌ ERROR: No se encontró config.json del microservicio '{old_name}'")
            logger.error(f"❌ Config Server URL: {config_server_url}")
            logger.error(f"❌ Archivos .json disponibles en config server: {len(json_files_available)}")
            
            if target_filename:
                logger.error(f"❌ Archivo esperado desde deployment: {target_filename}")
            else:
                logger.error(f"❌ No se pudo extraer CONFIG_END_POINT del deployment")
                
            if json_files_available:
                logger.error(f"❌ Archivos .json encontrados que NO coinciden:")
                for json_file in json_files_available[:10]:  # Mostrar máximo 10 para evitar spam
                    logger.error(f"   - {json_file}")
                if len(json_files_available) > 10:
                    logger.error(f"   ... y {len(json_files_available) - 10} archivos más")
            else:
                logger.error(f"❌ No hay archivos .json en el config server")
            
            logger.info(f"📋 DETECTADO COMO BACKEND: Procesando con archivos .yaml")
        
        return is_frontend, compatible_json_files
        
    except Exception as e:
        logger.error(f"❌ Error detectando tipo de servicio: {str(e)}")
        return False, []


async def create_frontend_config_json_files(
    session: aiohttp.ClientSession,
    owner: str,
    repo: str,
    git_token: str,
    compatible_json_files: List[Dict],
    environments: List[str],
    old_name: str
) -> bool:
    """
    Crea archivos config.json para frontend en lugar de values-{env}.yaml.
    Mapea archivos específicos por entorno: dev->cert, pre->pre, pro->pro.
    Crea los archivos en config/{env}/config.json y elimina archivos antiguos.
    
    Args:
        session: Sesión HTTP aiohttp
        owner: Propietario del repositorio
        repo: Nombre del repositorio
        git_token: Token de GitHub
        compatible_json_files: Lista de archivos .json compatibles encontrados
        environments: Lista de entornos (cert, pre, pro)
        old_name: Nombre del servicio
        
    Returns:
        bool: True si todos los archivos se crearon correctamente
    """
    try:
        from .github_client import GitHubClient
        
        github_client = GitHubClient(git_token, session)
        
        logger.info(f"🔧 Creando archivos config.json para frontend {old_name}...")
        
        if not compatible_json_files:
            logger.error("❌ No hay archivos .json compatibles para crear config.json")
            return False
        
        # Crear mapeo de archivos por entorno
        # dev -> cert, pre -> pre, pro -> pro
        env_file_mapping = {}
        dev_fallback_file = None
        
        for file_info in compatible_json_files:
            file_path = file_info['file_path']
            file_name = file_info['file_name']
            
            logger.info(f"📄 Procesando archivo: {file_path}")
            
            # Mapear archivos basándose en el nombre específico
            if file_name.endswith('-cert.json') or file_name.endswith('-dev.json'):
                env_file_mapping['cert'] = file_info
                # Guardar archivo dev como fallback para pre y pro
                if file_name.endswith('-dev.json'):
                    dev_fallback_file = file_info
                logger.info(f"   🔄 Mapeado para CERT: {file_name}")
            elif file_name.endswith('-pre.json'):
                env_file_mapping['pre'] = file_info  
                logger.info(f"   🔄 Mapeado para PRE: {file_name}")
            elif file_name.endswith('-pro.json'):
                env_file_mapping['pro'] = file_info
                logger.info(f"   🔄 Mapeado para PRO: {file_name}")
            else:
                # NO hacer fallback - solo procesar archivos con sufijos específicos
                logger.info(f"   ⚠️ Archivo ignorado (no tiene sufijo específico): {file_name}")
        
        # Implementar fallback: usar dev.json para pre y pro si no tienen archivos específicos
        if dev_fallback_file:
            if 'pre' not in env_file_mapping:
                env_file_mapping['pre'] = dev_fallback_file
                logger.info(f"   � FALLBACK para PRE: usando {dev_fallback_file['file_name']}")
            if 'pro' not in env_file_mapping:
                env_file_mapping['pro'] = dev_fallback_file
                logger.info(f"   🔄 FALLBACK para PRO: usando {dev_fallback_file['file_name']}")
        
        logger.info(f"�📋 Mapeo final de archivos por entorno:")
        for env, file_info in env_file_mapping.items():
            logger.info(f"   - {env.upper()}: {file_info['file_name']}")
        
        # Procesar todos los entornos requeridos (cert, pre, pro)
        required_envs = environments  # Usar la lista completa de entornos pasada como parámetro
        logger.info(f"🎯 Procesando entornos requeridos: {required_envs}")
        
        success_count = 0
        total_envs = len(required_envs)
        
        # Crear config.json para cada entorno usando el archivo correspondiente
        for env in required_envs:
            if env not in env_file_mapping:
                logger.warning(f"⚠️ No hay archivo mapeado para {env}, saltando...")
                continue
                
            config_json_path = f"config/{env}/config.json"
            file_info = env_file_mapping[env]
            config_content = file_info['content']
            
            try:
                # Paso 1: Crear archivo config.json con el contenido del .json del config server
                logger.info(f"📤 Paso 1: Creando {config_json_path} usando {file_info['file_name']}...")
                
                result = await github_client.update_file(
                    owner, repo, config_json_path, config_content, None,  # sha=None para crear
                    f"Create config/{env}/config.json for frontend {old_name} from {file_info['file_name']}",
                    "main"  # ConfigMaps usan rama main
                )
                
                if result.get("status") == "success":
                    logger.info(f"✅ Paso 1 completado: config.json creado correctamente para {env}")
                    
                    # Paso 2: Eliminar archivos de configuración existentes (application-{env}.properties)
                    old_config_files = [
                        f"config/{env}/application-{env}.properties",
                        f"config/{env}/application.properties"
                    ]
                    
                    for old_file_path in old_config_files:
                        try:
                            logger.info(f"🗑️ Paso 2: Intentando eliminar archivo existente {old_file_path}...")
                            
                            # Verificar si el archivo existe antes de eliminarlo
                            file_content_result = await github_client.get_file_content(owner, repo, old_file_path, "main")
                            
                            if file_content_result is not None:
                                # El archivo existe, eliminarlo
                                content, sha = file_content_result
                                delete_result = await github_client.delete_file(
                                    owner, repo, old_file_path, sha,
                                    f"Remove old config file {old_file_path} (replaced by config/{env}/config.json)",
                                    "main"
                                )
                                
                                if delete_result.get("status") == "success":
                                    logger.info(f"✅ Paso 2 completado: {old_file_path} eliminado correctamente")
                                else:
                                    logger.warning(f"⚠️ No se pudo eliminar {old_file_path}: {delete_result.get('error')}")
                            else:
                                logger.info(f"ℹ️ Archivo {old_file_path} no existe, no necesita eliminación")
                                
                        except Exception as delete_error:
                            logger.warning(f"⚠️ Error eliminando {old_file_path}: {str(delete_error)}")
                    
                    success_count += 1
                else:
                    logger.error(f"❌ Error creando config.json para {env}: {result.get('error')}")
                    
            except Exception as e:
                logger.error(f"❌ Excepción procesando {env}: {str(e)}")
        
        success = success_count == total_envs
        
        if success:
            logger.info(f"✅ Todos los archivos config.json creados correctamente ({success_count}/{total_envs})")
        else:
            logger.warning(f"⚠️ Solo {success_count}/{total_envs} archivos config.json se crearon correctamente")
        
        return success
        
    except Exception as e:
        logger.error(f"❌ Error creando archivos config.json para frontend: {str(e)}")
        return False