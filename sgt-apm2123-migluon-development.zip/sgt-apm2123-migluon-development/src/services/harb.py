import requests
import os
import base64
from typing import Dict, Any, List
from shuttlelib.utils.logger import logger
import aiohttp
from src.utils.proxy_config import get_proxy_config

API_URL = "https://gateway.apiohe.pro.cloudcenter.corp"
API_AUTH = os.getenv('HARBOR_TOKEN')

# Credenciales directas para Harbor (aplappshuttle)
HARBOR_USER = os.getenv('HARBOR_USER', 'aplappshuttle')
HARBOR_PWD = os.getenv('HARBOR_PWD')

requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)

class ApioheClient:
    def __init__(self) -> None:
        self.API_URL = API_URL
        self.CAAS_URL = API_URL + "/caas/api"
        self.API_AUTH = API_AUTH
        self._token = self._get_access_token()

    def _get_access_token(self):
        """ Get API token from Marketplace """
        headers = {'Authorization': f'Basic {self.API_AUTH}'}
        answer = requests.post(f"{self.API_URL}/token?grant_type=client_credentials", headers=headers, verify=False)
        return answer.json().get("access_token")

registry_data = [
    {"id": 86, "registryUrl": "https://registry.harbor.san.dmzb.bo1.paas.cloudcenter.corp"},
    {"id": 80, "registryUrl": "https://registry.harbor.san.pre.bo1.paas.cloudcenter.corp"},
    {"id": 49, "registryUrl": "https://registry.san.dev.weu.azure.paas.cloudcenter.corp"},
    {"id": 50, "registryUrl": "https://registry.san.pre.weu.azure.paas.cloudcenter.corp"},
    {"id": 88, "registryUrl": "https://registry.harbor.san.pro.bo1.paas.cloudcenter.corp"},
    {"id": 84, "registryUrl": "https://registry.harbor.san.dev.bo1.paas.cloudcenter.corp"},
    {"id": 29, "registryUrl": "https://registry.global.ccc.srvb.bo.paas.cloudcenter.corp"},
    {"id": 1, "registryUrl": "https://registry.san.pro.weu.azure.paas.cloudcenter.corp"},
    {"id": 148, "registryUrl": "https://registry.harbor.san.pre.weu.paas.cloudcenter.corp"},
    {"id": 150, "registryUrl": "https://registry.harbor.san.pro.weu.paas.cloudcenter.corp"}
]

# Crear el diccionario con y sin https para compatibilidad
registry_dict = {}
for entry in registry_data:
    url = entry["registryUrl"]
    id = entry["id"]
    registry_dict[url] = id
    if url.startswith("https://"):
        registry_dict[url[8:]] = id

# Permisos por defecto para robot accounts
DEFAULT_ROBOT_PERMISSIONS = [
    {"action": "list", "resource": "repository"},
    {"action": "pull", "resource": "repository"},
    {"action": "push", "resource": "repository"},
    {"action": "list", "resource": "artifact"},
    {"action": "read", "resource": "artifact"},
    {"action": "delete", "resource": "artifact"},
    {"action": "create", "resource": "artifact"},
    {"action": "list", "resource": "tag"},
    {"action": "create", "resource": "tag"},
    {"action": "create", "resource": "scan"},
    {"action": "stop", "resource": "scan"},
    {'action': 'create', 'resource': 'artifact-label'}
]

async def comprobar_shuttle_user(api: str, project: str):
    """ Comprobar si existe el usuario APLAPPSHUTTLE en el registry"""
    
    client = ApioheClient()
    headers = {
        'Authorization': f'Bearer {client._token}',
        'Tenant': 'san',
        'Accept': 'application/json'
    }

    registry_id = registry_dict.get(api)
    
    if not registry_id:
        logger.error(f"Registry URL {api} no encontrado en registry_data")
        return False

    url = f"{client.CAAS_URL}/v1/harbors/{registry_id}/projects/{project}"
    
    try:
        response = requests.get(url, headers=headers, verify=False)
        
        if response.status_code == 200:
            data = response.json().get("data", {})
            users = data.get("users", {}).get("admin", [])
            if "aplappshuttle" in users:
                return True
        elif response.status_code == 404:
            return "no existe el registry, crealo desde OHE PORTAL"
            
    except Exception as e:
        logger.error(f"Exception en comprobar_shuttle_user: {str(e)}")
        
    return False


async def add_shuttle_user(api: str, project: str):
    """ Añadir el usuario APLAPPSHUTTLE al registry"""
    
    client = ApioheClient()
    headers = {
        'Authorization': f'Bearer {client._token}',
        'Tenant': 'san',
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }

    registry_id = registry_dict.get(api)

    if not registry_id:
        logger.error(f"Registry URL {api} no encontrado en registry_data")
        return False

    url = f"{client.CAAS_URL}/v1/harbors/{registry_id}/projects/{project}/users-add"
    body = {"admin": ["aplappshuttle", "n574433", "n951135"]}

    response = requests.post(url, headers=headers, json=body, verify=False)

    if response.status_code == 201:
        logger.info(f"Usuario aplappshuttle añadido correctamente al proyecto {project}")
        return True
    else:
        logger.error(f"Error al añadir usuario aplappshuttle al proyecto {project}: {response.text}")
        return False


async def create_harbor_robot_account(
    registry_url: str,
    project: str,
    robot_name: str,
    permissions: List[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Crear una RobotAccount en Harbor.
    
    Args:
        registry_url: URL del registry
        project: Nombre del proyecto en Harbor
        robot_name: Nombre para la robot account (sin timestamp)
        permissions: Lista de permisos (opcional, usa permisos por defecto si no se especifica)
        
    Returns:
        Dict con el resultado de la operación incluyendo las credenciales
    """
    # Llamar directamente a create_robot_account_direct
    return await create_robot_account_direct(registry_url, project, robot_name, permissions)


async def create_robot_account_direct(
    registry_url: str,
    project: str,
    robot_name: str,
    permissions: List[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Crear una RobotAccount directamente en Harbor usando autenticación básica.
    """
    # Obtener credenciales de Harbor
    harbor_user = os.getenv('HARBOR_USER', 'aplappshuttle')
    harbor_pwd = os.getenv('HARBOR_PWD')
    
    if not harbor_user or not harbor_pwd:
        logger.error("Credenciales de Harbor no configuradas (HARBOR_USER/HARBOR_PWD)")
        return {"success": False, "error": "Credenciales de Harbor no configuradas"}

    # Generar token de autenticación básica
    auth_token = base64.b64encode(f"{harbor_user}:{harbor_pwd}".encode('utf-8')).decode("ascii")

    # Limpiar la URL del registry
    if registry_url.startswith("https://"):
        harbor_host = registry_url[8:]
    else:
        harbor_host = registry_url

    # Construir la URL del endpoint
    url = f"https://{harbor_host}/api/v2.0/robots"

    # Headers
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Basic {auth_token}"
    }

    # Usar DEFAULT_ROBOT_PERMISSIONS si no se especifican permisos
    if not permissions:
        permissions = DEFAULT_ROBOT_PERMISSIONS

    # Cuerpo de la solicitud
    data = {
        "name": robot_name,
        "level": "project",
        "duration": -1,
        "description": f"Robot account para {project}",
        "disable": False,
        "permissions": [
            {
                "kind": "project",
                "namespace": project,
                "access": permissions
            }
        ]
    }

    import ssl
    # Configurar SSL para ignorar verificación
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE

    try:
        # Only GitHub API needs proxy - all internal corporate domains go direct
        if 'api.github.com' in url:
            proxy_config = get_proxy_config()
        else:
            proxy_config = {}  # No proxy for all other URLs (Harbor, OpenShift, etc.)
        
        timeout = aiohttp.ClientTimeout(total=30)
        session_config = {**proxy_config, "timeout": timeout}
        async with aiohttp.ClientSession(**session_config) as session:
            async with session.post(
                url, 
                headers=headers, 
                json=data,
                ssl=ssl_context
            ) as response:
                response_text = await response.text()

                if response.status == 201:
                    response_data = await response.json()
                    logger.info(f"✓ RobotAccount '{robot_name}' creada exitosamente")
                    
                    return {
                        "success": True,
                        "name": response_data.get("name"),
                        "secret": response_data.get("secret"),
                        "id": response_data.get("id"),
                        "full_name": response_data.get("name"),
                        "method": "direct_harbor"
                    }
                elif response.status == 409:
                    logger.warning(f"Robot account '{robot_name}' ya existe")
                    return {
                        "success": False,
                        "error": f"Robot account '{robot_name}' ya existe en el proyecto",
                        "method": "direct_harbor"
                    }
                elif response.status == 400:
                    # Intentar parsear el error
                    try:
                        error_data = await response.json()
                        error_message = error_data.get('errors', [{}])[0].get('message', response_text)
                    except:
                        error_message = response_text
                    return {
                        "success": False,
                        "error": f"Error 400: {error_message}",
                        "method": "direct_harbor"
                    }
                else:
                    logger.error(f"Error al crear RobotAccount: {response.status}")
                    return {
                        "success": False,
                        "error": f"Error {response.status}: {response_text}",
                        "method": "direct_harbor"
                    }
                    
    except aiohttp.ClientError as e:
        logger.error(f"Error de conexión: {str(e)}")
        return {
            "success": False,
            "error": f"Error de conexión: {str(e)}",
            "method": "direct_harbor"
        }
    except Exception as e:
        logger.error(f"Excepción al crear RobotAccount: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "method": "direct_harbor"
        }

async def ensure_shuttle_user(registry_url: str, project: str) -> bool:
    """
    Verificar y añadir el usuario shuttle si es necesario
    
    Args:
        registry_url: URL del registry
        project: Nombre del proyecto
        
    Returns:
        bool: True si el usuario existe o se añadió correctamente
    """
    logger.info(f"Verificando usuario shuttle en proyecto {project}")
    
    # Comprobar si existe el usuario shuttle
    shuttle_exists = await comprobar_shuttle_user(registry_url, project)
    
    if shuttle_exists == True:
        logger.info(f"Usuario shuttle ya existe en proyecto {project}")
        return True
    elif shuttle_exists == "no existe el registry, crealo desde OHE PORTAL":
        logger.error(f"El proyecto {project} no existe en {registry_url}. Debe crearse desde OHE Portal")
        return False
    else:
        # Intentar añadir el usuario shuttle
        logger.info(f"Añadiendo usuario shuttle al proyecto {project}")
        added = await add_shuttle_user(registry_url, project)
        if added:
            logger.info(f"Usuario shuttle añadido correctamente al proyecto {project}")
            return True
        else:
            logger.error(f"No se pudo añadir el usuario shuttle al proyecto {project}")
            return False


async def delete_robot_account_direct(
    registry_url: str,
    project: str,
    robot_name: str,
    robot_id: int = None
) -> Dict[str, Any]:
    """
    Eliminar una RobotAccount directamente en Harbor usando autenticación básica.
    
    Args:
        registry_url: URL del registry Harbor
        project: Nombre del proyecto
        robot_name: Nombre de la robot account
        robot_id: ID de la robot account (opcional, se buscará si no se proporciona)
        
    Returns:
        Dict con resultado de la operación
    """
    # Obtener credenciales de Harbor
    harbor_user = os.getenv('HARBOR_USER', 'aplappshuttle')
    harbor_pwd = os.getenv('HARBOR_PWD')
    
    if not harbor_user or not harbor_pwd:
        logger.error("Credenciales de Harbor no configuradas (HARBOR_USER/HARBOR_PWD)")
        return {"success": False, "error": "Credenciales de Harbor no configuradas"}

    # Generar token de autenticación básica
    auth_token = base64.b64encode(f"{harbor_user}:{harbor_pwd}".encode('utf-8')).decode("ascii")

    # Limpiar la URL del registry
    if registry_url.startswith("https://"):
        harbor_host = registry_url[8:]
    else:
        harbor_host = registry_url

    # Headers
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Basic {auth_token}"
    }

    import ssl
    # Configurar SSL para ignorar verificación
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE

    try:
        # Si no tenemos el ID, necesitamos buscarlo primero
        if not robot_id:
            logger.info(f"Buscando ID de robot account '{robot_name}' en proyecto '{project}'")
            robot_id = await get_robot_account_id(registry_url, project, robot_name)
            if not robot_id:
                logger.warning(f"No se encontró robot account '{robot_name}' en proyecto '{project}'")
                return {"success": False, "error": f"Robot account '{robot_name}' no encontrada"}

        # Construir la URL del endpoint para eliminar
        url = f"https://{harbor_host}/api/v2.0/robots/{robot_id}"
        
        # Only GitHub API needs proxy - all internal corporate domains go direct
        if 'api.github.com' in url:
            proxy_config = get_proxy_config()
        else:
            proxy_config = {}  # No proxy for all other URLs (Harbor, OpenShift, etc.)
        
        timeout = aiohttp.ClientTimeout(total=30)
        session_config = {**proxy_config, "timeout": timeout}
        async with aiohttp.ClientSession(**session_config) as session:
            async with session.delete(
                url, 
                headers=headers,
                ssl=ssl_context
            ) as response:
                response_text = await response.text()

                if response.status == 200:
                    logger.info(f"✓ Robot account '{robot_name}' (ID: {robot_id}) eliminada exitosamente")
                    return {
                        "success": True,
                        "robot_name": robot_name,
                        "robot_id": robot_id,
                        "method": "direct_harbor"
                    }
                elif response.status == 404:
                    logger.warning(f"Robot account '{robot_name}' no existe (404)")
                    return {
                        "success": False,
                        "error": "Robot account no existe",
                        "robot_name": robot_name
                    }
                else:
                    logger.error(f"✗ Error al eliminar robot account: HTTP {response.status}")
                    logger.error(f"Respuesta: {response_text}")
                    return {
                        "success": False,
                        "error": f"HTTP {response.status}: {response_text}",
                        "robot_name": robot_name
                    }

    except Exception as e:
        logger.error(f"Excepción al eliminar robot account: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "robot_name": robot_name,
            "method": "direct_harbor"
        }


async def get_robot_account_id(
    registry_url: str,
    project: str,
    robot_name: str
) -> int:
    """
    Obtener el ID de una robot account por su nombre en un proyecto específico.
    
    Args:
        registry_url: URL del registry Harbor
        project: Nombre del proyecto
        robot_name: Nombre de la robot account a buscar
        
    Returns:
        int: ID de la robot account o None si no se encuentra
    """
    # Obtener credenciales de Harbor
    harbor_user = os.getenv('HARBOR_USER', 'aplappshuttle')
    harbor_pwd = os.getenv('HARBOR_PWD')
    
    if not harbor_user or not harbor_pwd:
        logger.error("Credenciales de Harbor no configuradas")
        return None

    # Generar token de autenticación básica
    auth_token = base64.b64encode(f"{harbor_user}:{harbor_pwd}".encode('utf-8')).decode("ascii")

    # Limpiar la URL del registry
    if registry_url.startswith("https://"):
        harbor_host = registry_url[8:]
    else:
        harbor_host = registry_url

    # Construir la URL para listar robots del proyecto
    url = f"https://{harbor_host}/api/v2.0/robots?q=level=project,project_id={project}"

    # Headers
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Basic {auth_token}"
    }

    import ssl
    # Configurar SSL para ignorar verificación
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE

    try:
        # Only GitHub API needs proxy - all internal corporate domains go direct
        if 'api.github.com' in url:
            proxy_config = get_proxy_config()
        else:
            proxy_config = {}
        
        timeout = aiohttp.ClientTimeout(total=30)
        session_config = {**proxy_config, "timeout": timeout}
        async with aiohttp.ClientSession(**session_config) as session:
            async with session.get(
                url, 
                headers=headers,
                ssl=ssl_context
            ) as response:
                if response.status == 200:
                    robots = await response.json()
                    
                    # Buscar la robot account por nombre
                    for robot in robots:
                        # El nombre completo incluye el proyecto, ej: "project+robot_name"
                        full_name = robot.get("name", "")
                        if full_name.endswith(f"+{robot_name}"):
                            logger.info(f"Encontrada robot account '{robot_name}' con ID: {robot.get('id')}")
                            return robot.get("id")
                    
                    logger.warning(f"Robot account '{robot_name}' no encontrada en proyecto '{project}'")
                    return None
                else:
                    logger.error(f"Error al listar robot accounts: HTTP {response.status}")
                    return None

    except Exception as e:
        logger.error(f"Excepción al buscar robot account: {str(e)}")
        return None