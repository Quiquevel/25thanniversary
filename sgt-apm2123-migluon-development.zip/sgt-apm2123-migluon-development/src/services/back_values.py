"""
Orquestador del sistema de migración de microservicios.
Este archivo actúa como coordinador de todos los módulos especializados.

ARQUITECTURA MODULAR:
├─ github/: Operaciones GitHub especializadas (backups, modificaciones YAML)
├─ openshift/: Procesamiento de deployments y OAM de OpenShift  
├─ file_processors/: Modificación de archivos específicos (Dockerfile, pom.xml)
└─ back_values.py: Orquestador principal y coordinador
"""
import base64
import json
import aiohttp
from datetime import datetime
from typing import Dict, Any
import time
from shuttlelib.utils.logger import logger
from src.utils.proxy_config import get_proxy_config

# Importar módulos especializados
from .github.operations import (
    backup_development_branch,
    backup_pulse_import_branch,
    modify_values_file_optimized
)

from .openshift import (
    get_deployment_from_openshift,
    get_oam_from_git,
    DeploymentData
)

from .file_processors import (
    modify_pom_file,
    modify_bootstrap_yml
)

from .common_utils import validate_and_update_dockerfile_with_api_versions, format_general_result
from .github.operations import extract_darwin_version_from_pom
from .respuestas import entrypoint_messages


async def update_dockerfile_entrypoint_for_darwin_version(github_client, owner: str, repo: str, darwin_version: str) -> dict:
    """
    Actualiza el ENTRYPOINT del Dockerfile basado en la versión de Darwin.
    Para versiones Darwin < 4.0, usa el ENTRYPOINT específico para JarLauncher.
    
    Args:
        github_client: Cliente GitHub
        owner: Propietario del repositorio
        repo: Nombre del repositorio  
        darwin_version: Versión de Darwin (ej: "3.0.1-RELEASE", "6.3.2")
        
    Returns:
        dict: Resultado de la operación con success, updated, version_info
    """
    result = {
        'success': False,
        'updated': False,
        'darwin_version': darwin_version,
        'major_version': None,
        'entrypoint_needed': False,
        'error': None
    }
    
    try:
        # Extraer versión mayor de Darwin usando función auxiliar
        from .github.operations import extract_darwin_major_version
        
        logger.info(f"🔍 DEBUG ENTRYPOINT: darwin_version recibido = '{darwin_version}'")
        
        major_version_str = extract_darwin_major_version(darwin_version)
        logger.info(f"🔍 DEBUG ENTRYPOINT: major_version_str extraído = '{major_version_str}'")
        
        if not major_version_str:
            result['error'] = f"No se pudo extraer versión mayor de: {darwin_version}"
            logger.error(f"❌ DEBUG ENTRYPOINT: {result['error']}")
            return result
            
        major_version = int(major_version_str)
        result['major_version'] = major_version
        logger.info(f"🔍 DEBUG ENTRYPOINT: major_version como int = {major_version}")
        
        # Solo procesar si es versión < 4
        if major_version >= 4:
            logger.info(f"🔍 Darwin v{major_version} >= 4, no necesita modificación ENTRYPOINT")
            result['success'] = True
            result['entrypoint_needed'] = False
            return result
            
        logger.info(f"🔄 Darwin v{major_version} < 4, necesita ENTRYPOINT específico para JarLauncher")
        result['entrypoint_needed'] = True
        
        # Obtener contenido del Dockerfile
        logger.info("🔍 DEBUG ENTRYPOINT: Obteniendo contenido del Dockerfile...")
        dockerfile_result = await github_client.get_file_content(owner, repo, "Dockerfile", "feature/gluon-migration-config-from-pulse-import")
        if not dockerfile_result:
            result['error'] = "No se encontró Dockerfile"
            logger.error(f"❌ DEBUG ENTRYPOINT: {result['error']}")
            return result
            
        dockerfile_content, dockerfile_sha = dockerfile_result
        logger.info(f"✅ DEBUG ENTRYPOINT: Dockerfile obtenido, SHA: {dockerfile_sha[:10]}...")
        
        lines = dockerfile_content.split('\n')
        logger.info(f"🔍 DEBUG ENTRYPOINT: Dockerfile tiene {len(lines)} líneas")
        
        # ENTRYPOINT específico para Darwin < 4 - DEBE usar la versión SIN "launch"
        target_entrypoint = 'ENTRYPOINT ["sh", "-c", "java ${JAVA_OPTS_EXT} org.springframework.boot.loader.JarLauncher $JAVA_PARAMETERS ${@}"]'
        
        logger.info(f"🔍 DEBUG ENTRYPOINT: ENTRYPOINT objetivo (SIN launch) = {target_entrypoint}")
        
        # Buscar línea ENTRYPOINT existente
        entrypoint_found = False
        entrypoint_updated = False
        
        for i, line in enumerate(lines):
            if line.strip().startswith('ENTRYPOINT'):
                entrypoint_found = True
                current_entrypoint = line.strip()
                logger.info(f"🔍 DEBUG ENTRYPOINT: Encontrado en línea {i+1}: {current_entrypoint}")
                
                # Verificar si ya tiene exactamente el ENTRYPOINT objetivo (sin launch)
                if current_entrypoint == target_entrypoint:
                    logger.info(f"✅ ENTRYPOINT ya configurado correctamente para Darwin < 4 (sin launch)")
                    result['success'] = True
                    result['updated'] = False
                    return result
                
                # Si tiene JarLauncher pero con "launch", o cualquier otro ENTRYPOINT, actualizarlo
                if ('JarLauncher' in current_entrypoint or 
                    'ApplicationRunner' in current_entrypoint or 
                    'MainMethodRunner' in current_entrypoint):
                    logger.info(f"🔄 Actualizando ENTRYPOINT para usar versión sin 'launch': {current_entrypoint} -> {target_entrypoint}")
                else:
                    logger.info(f"🔄 Actualizando ENTRYPOINT desconocido: {current_entrypoint} -> {target_entrypoint}")
                
                lines[i] = target_entrypoint
                entrypoint_updated = True
                break
        
        if not entrypoint_found:
            result['error'] = "No se encontró línea ENTRYPOINT en Dockerfile"
            logger.error(f"❌ DEBUG ENTRYPOINT: {result['error']}")
            
            # DEBUG: Mostrar las primeras 10 líneas del Dockerfile para análisis
            logger.info("🔍 DEBUG ENTRYPOINT: Primeras 10 líneas del Dockerfile:")
            for i, line in enumerate(lines[:10]):
                logger.info(f"   {i+1}: {line}")
            
            return result
            
        if entrypoint_updated:
            # Actualizar archivo en GitHub
            updated_content = '\n'.join(lines)
            logger.info("🔄 DEBUG ENTRYPOINT: Actualizando archivo en GitHub...")
            
            update_result = await github_client.update_file(
                owner=owner,
                repo=repo,
                file_path="Dockerfile",
                content=updated_content,
                sha=dockerfile_sha,
                commit_message=f"feat: actualizar ENTRYPOINT para Darwin v{major_version} (JarLauncher) [ci skip]",
                branch="feature/gluon-migration-config-from-pulse-import"
            )
            
            logger.info(f"🔍 DEBUG ENTRYPOINT: update_result = {update_result}")
            
            if update_result.get('status') == 'success':
                logger.info(f"✅ Dockerfile actualizado con ENTRYPOINT para Darwin v{major_version}")
                result['success'] = True
                result['updated'] = True
            else:
                result['error'] = f"Error actualizando Dockerfile: {update_result.get('error', 'Unknown error')}"
                logger.error(f"❌ DEBUG ENTRYPOINT: {result['error']}")
        else:
            logger.warning("⚠️ DEBUG ENTRYPOINT: entrypoint_updated es False - no se realizará actualización")
        
        return result
        
    except Exception as e:
        logger.error(f"❌ Error actualizando ENTRYPOINT para Darwin: {str(e)}")
        result['error'] = str(e)
        return result


def extract_owner_repo_from_url(repo_url: str) -> tuple:
    """
    Extrae owner y repo de una URL de GitHub API.
    
    Args:
        repo_url: URL de la API de GitHub
        
    Returns:
        tuple: (owner, repo) o (None, None) si no se puede extraer
    """
    try:
        repo_parts = repo_url.replace('https://api.github.com/repos/', '').split('/')
        if len(repo_parts) >= 2:
            return repo_parts[0], repo_parts[1]
    except Exception:
        pass
    return None, None

# Instancia global para compatibilidad con el código existente
deployment_data = DeploymentData()


async def update_microservice_values(
    old_name: str,
    git_token: str,
    url_git: str,
    url_oam: str,
    skip_deployment: bool = False  # CAMBIADO: False para obtener extraEnvVars del deployment.yaml
) -> str:
    """Orquestador principal de migración BACKEND.

    RESUMEN DE RESPONSABILIDADES:
    - Backups de ramas críticas (development, pulse-import)
    - Obtención y parseo del OAM, extracción de namespace y cluster config
    - (Opcional) Descarga del deployment para extraer variables de entorno
    - Actualización de Dockerfile (versión base y ENTRYPOINT Darwin<4)
    - Modificaciones centralizadas de múltiples archivos (values, cd.yml, pom.xml, application.yml, bootstrap.yml)

    OPTIMIZACIONES INTRODUCIDAS EN ESTA VERSIÓN:
    - Reutilización de UNA sola sesión `aiohttp.ClientSession` para los dos backups (reduce latencia TLS + creación de conexiones)
    - Reutilización de UNA sola sesión para todas las operaciones de modificación (antes se abrían varias)
    - Métricas de tiempo añadidas (backups, modificaciones y total) para futuras observaciones de rendimiento
    - Sin cambios en la firma pública ni en el orden funcional de pasos (compatibilidad mantenida)

    PENDIENTE (no implementado todavía – se dejó fuera para minimizar riesgo):
    - Paralelización con `asyncio.gather` de modificaciones independientes
    - Semaphore de control de concurrencia y pequeño caché in-memory para lecturas repetidas

    Args:
        old_name: Nombre actual del deployment
        git_token: Token de autenticación de GitHub
        url_git: URL del repositorio Git
        url_oam: URL del archivo OAM
        skip_deployment: Si True, omite la descarga del deployment (por defecto False para extraEnvVars)

    Returns:
        str: Texto plano con el progreso paso a paso de la operación
    """
    response_text = []
    response_text.append(f"🎯 MIGRACIÓN: {old_name}")
    response_text.append("")
    try:
        logger.info("=== INICIANDO MIGRACIÓN MODULAR DE MICROSERVICIO ===")
        logger.info(f"Deployment: {old_name}")
        t_start_total = time.perf_counter()

        # 1. Validar URL repositorio
        from .common_utils import extract_repo_info
        try:
            owner, repo = extract_repo_info(url_git)
        except ValueError as e:
            response_text.append(f"❌ VALIDACIÓN URL GIT: KO - {e}")
            return "\n".join(response_text)
        repo_api_url = f"https://api.github.com/repos/{owner}/{repo}"
        response_text.append(f"✅ VALIDACIÓN URL GIT: OK - {owner}/{repo}")

        # 2. Backups (development y pulse-import) con una sola sesión
        response_text.append("")
        response_text.append("--- PASO 1 / 2: BACKUPS development y pulse-import (sesión reutilizada) ---")
        proxy_config = get_proxy_config()
        t_backups_start = time.perf_counter()
        async with aiohttp.ClientSession(**proxy_config) as session:
            success_dev = await backup_development_branch(session, owner, repo, git_token, old_name)
            if not success_dev:
                response_text.append("❌ BACKUP DEVELOPMENT: KO - Error al procesar backup")
                response_text.append("💥 EJECUCIÓN ABORTADA: El backup de development es obligatorio")
                return "\n".join(response_text)
            response_text.append("✅ BACKUP DEVELOPMENT: OK - Backup completado (creado o ya existe)")

            success_pi, branch_status = await backup_pulse_import_branch(session, owner, repo, git_token, old_name, is_configmap=False)
            if not success_pi:
                response_text.append("❌ BACKUP PULSE-IMPORT: KO - Error al procesar backup")
                response_text.append("💥 EJECUCIÓN ABORTADA: El backup de pulse-import es obligatorio")
                return "\n".join(response_text)
            if branch_status == "exists":
                response_text.append("✅ BACKUP PULSE-IMPORT: OK - Feature branch ya existe")
            else:
                response_text.append("✅ BACKUP PULSE-IMPORT: OK - Feature branch creada correctamente")
        t_backups_end = time.perf_counter()
        response_text.append(f"⏱️ DURACIÓN BACKUPS: {t_backups_end - t_backups_start:.2f}s")

        # 3. Obtener OAM
        response_text.append("")
        response_text.append("--- PASO 3: OBTENER ARCHIVO OAM [módulo: openshift/processor] ---")
        from .common_utils import normalize_oam_url
        try:
            normalized_url_oam = normalize_oam_url(url_oam)
            response_text.append(f"URL OAM normalizada: {normalized_url_oam}")
            oam_yaml = await get_oam_from_git(normalized_url_oam, git_token)
            response_text.append("✅ OBTENER OAM: OK - Archivo procesado")
        except Exception as e:
            response_text.append(f"❌ OBTENER OAM: KO - {e}")
            return "\n".join(response_text)

        # 3.1 Namespace desde OAM
        response_text.append("")
        response_text.append("--- PASO 3.1: EXTRAER NAMESPACE DEL OAM ---")
        namespace = None
        if oam_yaml and 'raw_data' in oam_yaml and 'environments' in oam_yaml['raw_data']:
            for env in oam_yaml['raw_data']['environments']:
                if 'infrastructures' in env:
                    for infra in env['infrastructures']:
                        if 'properties' in infra and 'namespace' in infra['properties']:
                            namespace = infra['properties']['namespace']
                            break
                if namespace:
                    break
        if not namespace and oam_yaml and 'environments' in oam_yaml:
            for env in oam_yaml['environments']:
                if 'infrastructures' in env:
                    for infra in env['infrastructures']:
                        if 'properties' in infra and 'namespace' in infra['properties']:
                            namespace = infra['properties']['namespace']
                            break
                if namespace:
                    break
        if not namespace:
            response_text.append("❌ EXTRAER NAMESPACE: KO - No se encontró namespace en el OAM")
            return "\n".join(response_text)
        from .openshift.processor import _clean_namespace
        clean_namespace_extracted = _clean_namespace(namespace)
        response_text.append(f"✅ EXTRAER NAMESPACE: OK - {namespace} → {clean_namespace_extracted}")
        response_text.append(f"📍 NAMESPACE DETECTADO: {clean_namespace_extracted}")
        logger.info(f"Namespace extraído del OAM: {namespace} → {clean_namespace_extracted}")

        # 4. Deployment de OpenShift (para extraEnvVars)
        deployment_yaml = None
        clean_namespace = clean_namespace_extracted
        if skip_deployment:
            response_text.append("")
            response_text.append("--- PASO 4: OBTENER DEPLOYMENT [OMITIDO] ---")
            response_text.append("ℹ️  DEPLOYMENT OMITIDO: Saltando obtención del deployment de OpenShift")
        else:
            response_text.append("")
            response_text.append("--- PASO 4: OBTENER DEPLOYMENT [módulo: openshift/processor] ---")
            response_text.append("🔍 EXTRAYENDO EXTRAENVVARS: Obteniendo deployment de OpenShift para extraer variables de entorno")
            try:
                deployment_yaml, clean_namespace, _ = await get_deployment_from_openshift(old_name, clean_namespace_extracted, oam_yaml)
                if deployment_yaml:
                    response_text.append("✅ OBTENER DEPLOYMENT: OK - Procesado para extracción de extraEnvVars")
                else:
                    response_text.append(f"⚠️ OBTENER DEPLOYMENT: Ya eliminado - {old_name} no existe (posible migración previa)")
            except Exception as e:
                error_msg = str(e)
                response_text.append(f"❌ OBTENER DEPLOYMENT: KO - {error_msg}")
                if "Acceso denegado" in error_msg:
                    response_text.append("📋 CAUSA: Token sin permisos en namespace")
                elif "no encontrado" in error_msg:
                    response_text.append("📋 CAUSA: Deployment o namespace inexistente")
                response_text.append("⚠️  CONTINUAR SIN DEPLOYMENT: Usando configuración por defecto")
                deployment_yaml = None
                clean_namespace = clean_namespace_extracted

        # 4.1 Cluster config
        response_text.append("")
        response_text.append("--- PASO 4.1: DETERMINAR CONFIGURACIÓN DEL CLUSTER ---")
        from .openshift.processor import determine_cluster_config_from_oam
        from .common_utils import get_environment_mapping
        env_mapping = get_environment_mapping({'raw_data': oam_yaml} if oam_yaml else None)
        dev_env_name = env_mapping.get('dev', 'cert')
        cluster, region, cluster_type, api_server = determine_cluster_config_from_oam(oam_yaml, dev_env_name, clean_namespace_extracted)
        response_text.append("✅ CONFIGURACIÓN CLUSTER: OK")
        response_text.append(f"   └─ Entorno OAM: {dev_env_name} (mapeado desde 'dev')")
        response_text.append(f"   └─ Cluster: {cluster}")
        response_text.append(f"   └─ Región: {region}")
        response_text.append(f"   └─ Tipo: {cluster_type}")
        response_text.append(f"   └─ API Server: {api_server[:50]}..." if len(api_server) > 50 else f"   └─ API Server: {api_server}")

        # 5. Almacenar datos globales
        deployment_data.set_deployment(deployment_yaml)
        deployment_data.set_oam(oam_yaml)
        deployment_data.namespace = clean_namespace_extracted
        deployment_data.old_name = old_name

        # 5.1 JAVA_OPTS_EXT
        java_opts_ext = ""
        if deployment_yaml:
            try:
                containers = deployment_yaml.get('spec', {}).get('template', {}).get('spec', {}).get('containers', [])
                if containers:
                    env_vars = containers[0].get('env', [])
                    for env_var in env_vars:
                        if env_var.get("name") == "JAVA_OPTS_EXT":
                            java_opts_ext = env_var.get("value", "")
                            break
                response_text.append(f"✅ EXTRACCIÓN JAVA_OPTS_EXT: OK - {java_opts_ext or 'valor por defecto'}")
            except Exception as e:  # noqa: F841
                response_text.append("⚠️  EXTRACCIÓN JAVA_OPTS_EXT: KO - usando valor por defecto")
        else:
            response_text.append("⚠️  EXTRACCIÓN JAVA_OPTS_EXT: Sin deployment disponible - usando valor por defecto")
        if not java_opts_ext:
            java_opts_ext = "-XX:MaxRAMPercentage=50.0 -Dfile.encoding=UTF-8"

        # 6. Modificaciones de archivos
        response_text.append("")
        response_text.append("--- PASO 5: MODIFICAR ARCHIVOS [módulo: file_processors/handlers] ---")
        modification_results = []
        t_mods_start = time.perf_counter()
        async with aiohttp.ClientSession(**proxy_config) as session:
            # 6.1 Validar y actualizar Dockerfile con versiones más recientes de la API
            try:
                from .github_client import GitHubClient
                github_client = GitHubClient(git_token, session)
                
                # Extraer owner y repo de la URL
                owner, repo = extract_owner_repo_from_url(repo_api_url)
                if owner and repo:
                    
                    # Validar versiones con API de Santander
                    logger.info(f"🔄 Iniciando validación API para {owner}/{repo}")
                    api_validation_result = await validate_and_update_dockerfile_with_api_versions(
                        github_client, owner, repo, "backend"
                    )
                    
                    logger.info(f"🔍 Resultado API: success={api_validation_result['success']}, error={api_validation_result.get('error')}")
                    
                    if api_validation_result['success']:
                        if api_validation_result['updated']:
                            response_text.append(f"✅ DOCKERFILE (API): Actualizado {api_validation_result['image_name']} de {api_validation_result['current_version']} a {api_validation_result['latest_version']}")
                        else:
                            response_text.append(f"✅ DOCKERFILE (API): {api_validation_result['image_name']}:{api_validation_result['current_version']} ya está actualizado")
                        modification_results.append(True)
                    else:
                        logger.error(f"❌ Validación API falló: {api_validation_result.get('error', 'Error desconocido')}")
                        # NO usar fallback - fallar limpiamente
                        response_text.append(f"❌ DOCKERFILE (API): Error - {api_validation_result.get('error', 'Error desconocido')}")
                        modification_results.append(False)
                else:
                    # Si no se puede extraer owner/repo, fallar
                    logger.error(f"❌ No se pudo extraer owner/repo de la URL: {repo_api_url}")
                    response_text.append(f"❌ DOCKERFILE (API): Error - No se pudo extraer owner/repo de la URL")
                    modification_results.append(False)
                    
            except Exception as e:
                logger.error(f"❌ Error crítico en validación de Dockerfile con API: {str(e)}")
                response_text.append(f"❌ DOCKERFILE (API): Error crítico - {str(e)}")
                modification_results.append(False)
            
            # 6.1.5 Modificar ENTRYPOINT del Dockerfile para versiones Darwin < 4 (solo backend)  
            try:
                from .github_client import GitHubClient
                github_client = GitHubClient(git_token, session)
                
                # Inicializar pom_content al principio para que esté disponible en toda la función
                pom_content = None
                
                # Extraer owner y repo de la URL
                owner, repo = extract_owner_repo_from_url(repo_api_url)
                if owner and repo:
                    # Obtener pom.xml para extraer versión Darwin
                    pom_result = await github_client.get_file_content(owner, repo, "pom.xml", "feature/gluon-migration-config-from-pulse-import")
                    if pom_result:
                        pom_content, _ = pom_result
                        logger.info("✅ pom_content obtenido y disponible para todas las funciones")
                        darwin_version = extract_darwin_version_from_pom(pom_content)
                        
                        if darwin_version:
                            logger.info(f"🔍 Procesando ENTRYPOINT para Darwin versión: {darwin_version}")
                            entrypoint_result = await update_dockerfile_entrypoint_for_darwin_version(
                                github_client, owner, repo, darwin_version
                            )
                            
                            if entrypoint_result['success']:
                                if entrypoint_result['entrypoint_needed']:
                                    if entrypoint_result['updated']:
                                        response_text.append(entrypoint_messages.success_updated(str(entrypoint_result['major_version'])))
                                    else:
                                        response_text.append(entrypoint_messages.success_already_configured(str(entrypoint_result['major_version'])))
                                else:
                                    response_text.append(entrypoint_messages.success_not_needed(str(entrypoint_result['major_version'])))
                                modification_results.append(True)
                            else:
                                logger.error(f"❌ Error actualizando ENTRYPOINT: {entrypoint_result.get('error')}")
                                response_text.append(entrypoint_messages.error_processing(entrypoint_result.get('error', 'Error desconocido')))
                                modification_results.append(False)
                        else:
                            logger.warning("⚠️ No se pudo extraer versión Darwin del pom.xml")
                            response_text.append(entrypoint_messages.warning_no_darwin_version())
                            modification_results.append(True)  # No es crítico
                    else:
                        logger.warning("⚠️ No se encontró pom.xml")
                        response_text.append(entrypoint_messages.warning_no_pom())
                        modification_results.append(True)  # No es crítico
                else:
                    logger.warning("⚠️ No se pudo extraer owner/repo para ENTRYPOINT")
                    response_text.append(entrypoint_messages.warning_no_owner_repo())
                    modification_results.append(True)  # No es crítico
                    
            except Exception as e:
                logger.error(f"❌ Error crítico actualizando ENTRYPOINT: {str(e)}")
                response_text.append(entrypoint_messages.error_critical(str(e)))
                modification_results.append(False)
            
            # 6.2 MODO BATCH: Preparar cambios de Dockerfile y pom.xml sin commits individuales
            batch_changes = {}
            batch_results = []
            
            try:
                from .file_processors.handlers import prepare_all_file_changes
                logger.info("🔄 Iniciando preparación batch de archivos...")
                
                # Preparar todos los cambios en memoria (sin commits)
                batch_changes = await prepare_all_file_changes(
                    session, repo_api_url, git_token, old_name, clean_namespace,
                    file_list=["Dockerfile", "pom.xml"]
                )
                

                if batch_changes:
                    from .github_client import GitHubClient
                    github_client = GitHubClient(git_token, session)
                    owner, repo = extract_owner_repo_from_url(repo_api_url)

                    if owner and repo:
                        batch_result = await github_client.batch_update_files(
                            owner, repo, batch_changes,
                            f"feat: migración batch {clean_namespace} - actualizar Dockerfile y pom.xml [ci skip]",
                            "feature/gluon-migration-config-from-pulse-import"
                        )

                        if batch_result.get("status") == "success":
                            response_text.append(f"✅ BATCH COMMIT: OK - {batch_result['files_updated']} archivos actualizados en commit {batch_result['commit_sha'][:7]}")
                            for file_path in batch_changes.keys():
                                batch_results.append(True)
                                response_text.append(f"   ├─ {file_path}: ACTUALIZADO")
                        else:
                            # Fallback: si solo hay un archivo, intentar commit individual
                            if len(batch_changes) == 1:
                                file_path, content = next(iter(batch_changes.items()))
                                logger.warning(f"Intentando commit individual para {file_path} tras fallo en batch...")
                                single_result = await github_client.batch_update_files(
                                    owner, repo, {file_path: content},
                                    f"feat: commit individual {clean_namespace} - {file_path} [ci skip]",
                                    "feature/gluon-migration-config-from-pulse-import"
                                )
                                if single_result.get("status") == "success":
                                    response_text.append(f"✅ COMMIT INDIVIDUAL: OK - {file_path} actualizado en commit {single_result['commit_sha'][:7]}")
                                    batch_results.append(True)
                                else:
                                    err_msg = single_result.get('error', 'Error desconocido')
                                    logger.error(f"Commit individual error details: {err_msg}")
                                    # Fallback final: si es pom.xml, intenta PUT vía API Contents
                                    if file_path == 'pom.xml':
                                        logger.warning("Intentando fallback PUT API Contents para pom.xml tras fallo en batch y commit individual...")
                                        # Obtener SHA actual de pom.xml
                                        contents_url = f"https://api.github.com/repos/{owner}/{repo}/contents/pom.xml?ref=feature/gluon-migration-config-from-pulse-import"
                                        async with session.get(contents_url, headers=github_client.headers) as resp:
                                            if resp.status != 200:
                                                logger.error(f"No se pudo obtener SHA de pom.xml para fallback PUT: HTTP {resp.status}")
                                                response_text.append(f"❌ MODIFICAR POM.XML: KO fallo al obtener SHA para fallback PUT")
                                                batch_results.append(False)
                                                return
                                            data = await resp.json()
                                            sha = data.get('sha')
                                            if not sha:
                                                logger.error("No se encontró SHA en la respuesta de contents para fallback PUT")
                                                response_text.append(f"❌ MODIFICAR POM.XML: KO sin SHA para fallback PUT")
                                                batch_results.append(False)
                                                return
                                        # Preparar payload
                                        new_content_b64 = base64.b64encode(content.encode('utf-8')).decode('utf-8')
                                        payload = json.dumps({
                                            'message': f'Update pom.xml for migration [{clean_namespace}]',
                                            'content': new_content_b64,
                                            'sha': sha,
                                            'branch': 'feature/gluon-migration-config-from-pulse-import'
                                        }).encode('utf-8')
                                        put_url = f"https://api.github.com/repos/{owner}/{repo}/contents/pom.xml"
                                        async with session.put(put_url, headers={**github_client.headers, 'Content-Type': 'application/json'}, data=payload) as put_resp:
                                            put_body = await put_resp.text()
                                            if put_resp.status in (200,201):
                                                logger.info("✅ Fallback PUT API Contents para pom.xml exitoso")
                                                response_text.append(f"✅ Fallback PUT API Contents: pom.xml actualizado correctamente")
                                                batch_results.append(True)
                                            else:
                                                logger.error(f"❌ Fallback PUT API Contents fallido: HTTP {put_resp.status} - {put_body[:500]}")
                                                response_text.append(f"❌ MODIFICAR POM.XML: KO también en fallback PUT API Contents")
                                                response_text.append(f"   └─ Detalle técnico: HTTP {put_resp.status} - {put_body[:300]}")
                                                batch_results.append(False)
                                    else:
                                        response_text.append(f"❌ COMMIT INDIVIDUAL: KO - {err_msg}")
                                        batch_results.append(False)
                            else:
                                err_msg = batch_result.get('error', 'Error desconocido')
                                try:
                                    logger.error(f"Batch update error details (full): {str(batch_result)[:2000]}")
                                except Exception:
                                    logger.error(f"Batch update error details: {err_msg}")
                                if 'pom.xml' in batch_changes:
                                    response_text.append(f"❌ MODIFICAR POM.XML: KO fallo al cambiar la version")
                                    response_text.append(f"   └─ Detalle técnico: {err_msg}")
                                else:
                                    response_text.append(f"❌ BATCH COMMIT: KO - {err_msg}")
                                batch_results.append(False)
                    else:
                        response_text.append("❌ BATCH COMMIT: KO - No se pudo extraer owner/repo")
                        batch_results.append(False)
                else:
                    response_text.append("ℹ️ BATCH COMMIT: No hay archivos para actualizar")
                    
            except Exception as e:
                logger.error(f"❌ Error crítico en batch commit: {str(e)}")
                response_text.append(f"❌ BATCH COMMIT: KO - Error crítico: {str(e)}")
                batch_results.append(False)
            
            # Añadir resultados batch a modification_results
            modification_results.extend(batch_results)
            
            # 6.2 FALLBACK: Si el batch falló, usar método individual (comentado para este demo)
            # try:
            #     pom_result = await modify_pom_file(
            #         session, repo_api_url, git_token, old_name, clean_namespace
            #     )
            #     
            #     response_text.append(format_general_result("MODIFICAR POM.XML", pom_result))
            #     modification_results.append(pom_result != "ERROR")
            # except Exception as e:
            #     response_text.append(f"❌ MODIFICAR POM.XML: KO - {str(e)}")
            #     modification_results.append(False)
            
            # 6.3 Modificar values.yaml principal (.gluon/cd/values.yaml)
            try:
                # Debug: Confirmar que pom_content está disponible
                if pom_content:
                    logger.info("✅ pom_content disponible - se pasará a modify_values_file_optimized")
                else:
                    logger.warning("⚠️ pom_content es None - templates usarán Darwin version por defecto")
                
                values_result = await modify_values_file_optimized(
                    session, repo_api_url, git_token, old_name, clean_namespace, java_opts_ext, region, ".gluon/cd/values.yaml", 
                    None, deployment_yaml, "feature/gluon-migration-config-from-pulse-import", False, "backend", None, None, pom_content  # oam_data=None, deployment_yaml=deployment_yaml, service_type=backend, pom_content=pom_content
                )
                
                if values_result:
                    response_text.append("✅ MODIFICAR VALUES.YAML: OK - Verificado/Modificado")
                    modification_results.append(True)
                else:
                    response_text.append("❌ MODIFICAR VALUES.YAML: KO - Error en procesamiento")
                    modification_results.append(False)
            except Exception as e:
                response_text.append(f"❌ MODIFICAR VALUES.YAML: KO - {str(e)}")
                modification_results.append(False)
            
            # 6.4 Modificar cd.yml para certificación (.gluon/cd/cert/cd.yml)
            try:
                # Para cd.yml, pasar los datos del OAM para extraer ci_id correcto
                oam_data_for_cd = None
                if oam_yaml:
                    # Usar raw_data si está disponible, sino usar datos directos
                    if 'raw_data' in oam_yaml:
                        oam_data_for_cd = oam_yaml['raw_data']
                    else:
                        oam_data_for_cd = oam_yaml
                
                values_dev_result = await modify_values_file_optimized(
                    session, repo_api_url, git_token, old_name, clean_namespace, java_opts_ext, region, ".gluon/cd/cert/cd.yml", oam_data_for_cd, None, "feature/gluon-migration-config-from-pulse-import", False, "backend", None, None, pom_content
                )
                
                if values_dev_result:
                    response_text.append("✅ MODIFICAR CD-CERT.YML: OK - Verificado/Modificado")
                    modification_results.append(True)
                else:
                    response_text.append("❌ MODIFICAR CD-CERT.YML: KO - Error en procesamiento")
                    modification_results.append(False)
            except ValueError as ve:
                # Error específico de OAM (entorno no encontrado)
                response_text.append(f"❌ MODIFICAR CD-CERT.YML: KO - OAM no contiene entorno 'cert': {str(ve)}")
                modification_results.append(False)
            except Exception as e:
                response_text.append(f"❌ MODIFICAR CD-CERT.YML: KO - {str(e)}")
                modification_results.append(False)
            
            # 6.5 Modificar values-cert.yaml (.gluon/cd/cert/values-cert.yaml) - CON CI_ID del OAM
            try:
                # Usar la misma lógica que para cd.yml pero para values-cert.yaml
                if 'raw_data' in oam_yaml:
                    oam_data_for_values_cert = oam_yaml['raw_data']
                else:
                    oam_data_for_values_cert = oam_yaml
                
                values_cert_result = await modify_values_file_optimized(
                    session, repo_api_url, git_token, old_name, clean_namespace, java_opts_ext, region, ".gluon/cd/cert/values-cert.yaml", oam_data_for_values_cert, deployment_yaml, "feature/gluon-migration-config-from-pulse-import", False, "backend", None, None, pom_content
                )
                
                if values_cert_result:
                    response_text.append("✅ MODIFICAR VALUES-CERT.YAML: OK - Verificado/Modificado con ci_id del OAM")
                    modification_results.append(True)
                else:
                    response_text.append("❌ MODIFICAR VALUES-CERT.YAML: KO - Error en procesamiento")
                    modification_results.append(False)
            except Exception as e:
                response_text.append(f"❌ MODIFICAR VALUES-CERT.YAML: KO - {str(e)}")
                modification_results.append(False)
            
            # 6.6 ELIMINADO: Modificación duplicada de cd.yml cert - ya se hace en 6.4
            
            # 6.7 Modificar cd.yml PRE (.gluon/cd/pre/cd.yml)
            try:
                # Para cd.yml PRE, pasar los datos del OAM para extraer ci_id correcto
                oam_data_for_cd_pre = None
                if oam_yaml:
                    # Usar raw_data si está disponible, sino usar datos directos
                    if 'raw_data' in oam_yaml:
                        oam_data_for_cd_pre = oam_yaml['raw_data']
                    else:
                        oam_data_for_cd_pre = oam_yaml
                
                cd_yml_pre_result = await modify_values_file_optimized(
                    session, repo_api_url, git_token, old_name, clean_namespace, java_opts_ext, region, ".gluon/cd/pre/cd.yml", oam_data_for_cd_pre, None, "feature/gluon-migration-config-from-pulse-import", False, "backend", None, None, pom_content
                )
                
                if cd_yml_pre_result:
                    response_text.append("✅ MODIFICAR CD.YML PRE: OK - Verificado/Modificado")
                    modification_results.append(True)
                else:
                    response_text.append("❌ MODIFICAR CD.YML PRE: KO - Error en procesamiento")
                    modification_results.append(False)
            except ValueError as ve:
                # Error específico de OAM (entorno no encontrado)
                response_text.append(f"❌ MODIFICAR CD.YML PRE: KO - OAM no contiene entorno 'pre': {str(ve)}")
                modification_results.append(False)
            except Exception as e:
                response_text.append(f"❌ MODIFICAR CD.YML PRE: KO - {str(e)}")
                modification_results.append(False)
            
            # 6.8 Modificar cd.yml PRO (.gluon/cd/pro/cd.yml)
            try:
                # Para cd.yml PRO, pasar los datos del OAM para extraer ci_id correcto
                oam_data_for_cd_pro = None
                if oam_yaml:
                    # Usar raw_data si está disponible, sino usar datos directos
                    if 'raw_data' in oam_yaml:
                        oam_data_for_cd_pro = oam_yaml['raw_data']
                    else:
                        oam_data_for_cd_pro = oam_yaml
                
                cd_yml_pro_result = await modify_values_file_optimized(
                    session, repo_api_url, git_token, old_name, clean_namespace, java_opts_ext, region, ".gluon/cd/pro/cd.yml", oam_data_for_cd_pro, None, "feature/gluon-migration-config-from-pulse-import", False, "backend", None, None, pom_content
                )
                
                if cd_yml_pro_result:
                    response_text.append("✅ MODIFICAR CD.YML PRO: OK - Verificado/Modificado")
                    modification_results.append(True)
                else:
                    response_text.append("❌ MODIFICAR CD.YML PRO: KO - Error en procesamiento")
                    modification_results.append(False)
            except Exception as e:
                response_text.append(f"❌ MODIFICAR CD.YML PRO: KO - {str(e)}")
                modification_results.append(False)
            
            # 6.9 Modificar values-pre.yaml (.gluon/cd/pre/values-pre.yaml) - CON CI_ID del OAM
            try:
                # Usar la misma lógica que para cd.yml pero para values-pre.yaml
                if 'raw_data' in oam_yaml:
                    oam_data_for_values_pre = oam_yaml['raw_data']
                else:
                    oam_data_for_values_pre = oam_yaml
                
                values_pre_result = await modify_values_file_optimized(
                    session, repo_api_url, git_token, old_name, clean_namespace, java_opts_ext, region, ".gluon/cd/pre/values-pre.yaml", oam_data_for_values_pre, deployment_yaml, "feature/gluon-migration-config-from-pulse-import", False, "backend", None, None, pom_content
                )
                
                if values_pre_result:
                    response_text.append("✅ MODIFICAR VALUES-PRE.YAML: OK - Verificado/Modificado con ci_id del OAM")
                    modification_results.append(True)
                else:
                    response_text.append("❌ MODIFICAR VALUES-PRE.YAML: KO - Error en procesamiento")
                    modification_results.append(False)
            except Exception as e:
                response_text.append(f"❌ MODIFICAR VALUES-PRE.YAML: KO - {str(e)}")
                modification_results.append(False)
            
            # 6.10 Modificar values-pro.yaml (.gluon/cd/pro/values-pro.yaml) - CON CI_ID del OAM
            try:
                # Usar la misma lógica que para cd.yml pero para values-pro.yaml
                if 'raw_data' in oam_yaml:
                    oam_data_for_values_pro = oam_yaml['raw_data']
                else:
                    oam_data_for_values_pro = oam_yaml
                
                values_pro_result = await modify_values_file_optimized(
                    session, repo_api_url, git_token, old_name, clean_namespace, java_opts_ext, region, ".gluon/cd/pro/values-pro.yaml", oam_data_for_values_pro, deployment_yaml, "feature/gluon-migration-config-from-pulse-import", False, "backend", None, None, pom_content
                )
                
                if values_pro_result:
                    response_text.append("✅ MODIFICAR VALUES-PRO.YAML: OK - Verificado/Modificado con ci_id del OAM")
                    modification_results.append(True)
                else:
                    response_text.append("❌ MODIFICAR VALUES-PRO.YAML: KO - Error en procesamiento")
                    modification_results.append(False)
            except Exception as e:
                response_text.append(f"❌ MODIFICAR VALUES-PRO.YAML: KO - {str(e)}")
                modification_results.append(False)
            
            # 6.11 Limpiar application.yml eliminando configuración del config server
            try:
                app_yml_result = await clean_application_yml_config_server(
                    session, repo_api_url, git_token, clean_namespace
                )
                
                if app_yml_result == "CLEANED":
                    response_text.append("✅ LIMPIAR APPLICATION.YML: OK - Eliminada configuración del config server")
                    modification_results.append(True)
                elif app_yml_result == "NOT_FOUND":
                    response_text.append("ℹ️ LIMPIAR APPLICATION.YML: OK - Archivo no encontrado (no es necesario)")
                    modification_results.append(True)
                elif app_yml_result == "NO_CHANGES":
                    response_text.append("ℹ️ LIMPIAR APPLICATION.YML: OK - Sin configuración de config server")
                    modification_results.append(True)
                else:  # ERROR
                    response_text.append("❌ LIMPIAR APPLICATION.YML: KO - Error en procesamiento")
                    modification_results.append(False)
            except Exception as e:
                response_text.append(f"❌ LIMPIAR APPLICATION.YML: KO - {str(e)}")
                modification_results.append(False)
            
            # 6.12 Limpiar bootstrap.yml eliminando configuración spring.cloud.config
            try:
                bootstrap_yml_result = await modify_bootstrap_yml(
                    session, repo_api_url, git_token, old_name, clean_namespace
                )
                
                if bootstrap_yml_result == "MODIFIED":
                    response_text.append("✅ LIMPIAR BOOTSTRAP.YML: OK - Eliminada configuración spring.cloud.config")
                    modification_results.append(True)
                else:
                    response_text.append(format_general_result("LIMPIAR BOOTSTRAP.YML", bootstrap_yml_result))
                    modification_results.append(bootstrap_yml_result != "ERROR")
            except Exception as e:
                response_text.append(f"❌ LIMPIAR BOOTSTRAP.YML: KO - {e}")
                modification_results.append(False)

        t_mods_end = time.perf_counter()
        # 7. Resumen final
        response_text.append("")
        response_text.append("=== RESUMEN FINAL DE MIGRACIÓN MODULAR ===")
        response_text.append(f"⏱️ TIEMPOS: backups={t_backups_end - t_backups_start:.2f}s | modificaciones={t_mods_end - t_mods_start:.2f}s | total={time.perf_counter() - t_start_total:.2f}s")
        success_count = sum(modification_results)
        total_count = len(modification_results)
        if success_count == total_count:
            response_text.append("✅ MIGRACIÓN COMPLETADA: OK - Todos los módulos ejecutados correctamente")
        else:
            response_text.append(f"⚠️ MIGRACIÓN PARCIAL: {success_count}/{total_count} módulos completados")
        response_text.append("")
        response_text.append("🎯 DATOS DE LA MIGRACIÓN PROCESADA:")
        response_text.append(f"   ├─ Deployment: {old_name}")
        response_text.append(f"   ├─ Namespace: {clean_namespace_extracted} → {clean_namespace}")
        response_text.append(f"   ├─ Cluster: {cluster} ({cluster_type})")
        response_text.append(f"   ├─ Región: {region}")
        response_text.append(f"   ├─ Java Options: {java_opts_ext}")
        response_text.append(f"   ├─ Repositorio: {owner}/{repo}")
        image = deployment_data.get_deployment_value("spec.template.spec.containers.0.image")
        if image:
            response_text.append(f"   └─ Imagen deployment: {image}")
        return "\n".join(response_text)
    except Exception as e:
        response_text.append("")
        response_text.append(f"❌ ERROR CRÍTICO EN ORQUESTADOR: {e}")
        logger.error(f"Error crítico en orquestador principal: {e}")
        return "\n".join(response_text)


async def clean_application_yml_config_server(session: aiohttp.ClientSession, repo_api_url: str, 
                                            git_token: str, app_name: str) -> str:
    """
    Elimina la configuración del config server del archivo application.yml.
    
    Específicamente elimina estas líneas:
    config:
      import: "optional:configserver:"
    cloud:
      config:
        uri: http://configuration-service:8080
    
    Args:
        session: Sesión HTTP activa
        repo_api_url: URL base de la API del repositorio
        git_token: Token de autenticación
        app_name: Nombre de la aplicación
    
    Returns:
        str: "CLEANED", "NOT_FOUND", "NO_CHANGES", o "ERROR"
    """
    try:
        file_path = "src/main/resources/config/application.yml"
        # Agregar referencia a la rama específica
        file_url = f"{repo_api_url}/contents/{file_path}?ref=feature/gluon-migration-config-from-pulse-import"
        
        headers = {
            'Authorization': f'token {git_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # Obtener el archivo desde la rama específica
        async with session.get(file_url, headers=headers) as response:
            if response.status == 404:
                return "NOT_FOUND"
            elif response.status != 200:
                logger.error(f"Error al obtener application.yml: HTTP {response.status}")
                return "ERROR"
            
            # Procesar la respuesta DENTRO del context manager
            file_data = await response.json()
            import base64
            content = base64.b64decode(file_data['content']).decode('utf-8')
            
            # Eliminar configuración específica del config server
            original_content = content
            changes_made = False
            
            # Buscar y eliminar secciones específicas del config server
            import re
            
            # Patrón para eliminar toda la sección spring.config.import con configserver
            config_import_pattern = r'^(\s*)config:\s*\n(\s*)import:\s*["\']?optional:configserver:["\']?\s*$'
            if re.search(config_import_pattern, content, re.MULTILINE):
                content = re.sub(config_import_pattern, '', content, flags=re.MULTILINE)
                changes_made = True
                logger.debug("Eliminada sección spring.config.import con configserver")
            
            # Patrón para eliminar toda la sección spring.cloud.config
            cloud_config_pattern = r'^(\s*)cloud:\s*\n(\s*)config:\s*\n(\s*)uri:\s*http://configuration-service[^:\n]*:8080/?.*$'
            if re.search(cloud_config_pattern, content, re.MULTILINE):
                content = re.sub(cloud_config_pattern, '', content, flags=re.MULTILINE)
                changes_made = True
                logger.debug("Eliminada sección spring.cloud.config")
            
            # Si los patrones regex no funcionaron, usar método línea por línea más específico
            if not changes_made:
                lines = content.split('\n')
                filtered_lines = []
                i = 0
                
                while i < len(lines):
                    line = lines[i]
                    line_stripped = line.strip()
                    
                    # Detectar inicio de sección config: con import:
                    if line_stripped == 'config:' and i + 1 < len(lines):
                        next_line = lines[i + 1].strip()
                        if next_line.startswith('import:') and 'configserver' in next_line:
                            logger.debug(f"Eliminando sección config/import: líneas {i}-{i+1}")
                            changes_made = True
                            i += 2  # Saltar ambas líneas
                            continue
                    
                    # Detectar inicio de sección cloud: con config: y uri:
                    elif line_stripped == 'cloud:' and i + 2 < len(lines):
                        config_line = lines[i + 1].strip()
                        uri_line = lines[i + 2].strip()
                        if (config_line == 'config:' and 
                            uri_line.startswith('uri:') and 
                            'configuration-service' in uri_line):
                            logger.debug(f"Eliminando sección cloud/config/uri: líneas {i}-{i+2}")
                            changes_made = True
                            i += 3  # Saltar las tres líneas
                            continue
                    
                    # Detectar líneas individuales con patrones específicos
                    elif ('optional:configserver:' in line or 
                          'configuration-service' in line and ':8080' in line):
                        logger.debug(f"Eliminando línea individual: {line.strip()}")
                        changes_made = True
                        i += 1
                        continue
                    
                    # Mantener la línea
                    filtered_lines.append(line)
                    i += 1
                
                content = '\n'.join(filtered_lines)
            
            new_content = content
            
            # Si no hay cambios, retornar
            if not changes_made:
                return "NO_CHANGES"
            
            # Actualizar el archivo si hay cambios - DENTRO del mismo context manager
            import json
            update_data = {
                "message": f"🧹 Eliminar configuración config server de application.yml ({app_name})",
                "content": base64.b64encode(new_content.encode('utf-8')).decode('utf-8'),
                "sha": file_data['sha'],
                "branch": "feature/gluon-migration-config-from-pulse-import"
            }
        
        # Actualizar archivo en una segunda llamada separada
        async with session.put(file_url, 
                             headers={**headers, 'Content-Type': 'application/json'}, 
                             data=json.dumps(update_data)) as put_response:
            if put_response.status in [200, 201]:
                return "CLEANED"
            else:
                logger.error(f"Error al actualizar application.yml: HTTP {put_response.status}")
                return "ERROR"
            
    except Exception as e:
        logger.error(f"Error en clean_application_yml_config_server: {str(e)}")
        return "ERROR"