"""
Operaciones específicas para migraciones combinadas (múltiples microservicios).

Este módulo contiene operaciones que solo deben ejecutarse al final de una migración
combinada exitosa, no en migraciones individuales de microservicios.

Operaciones incluidas:
- Backup del deployment.yaml original
- Creación de Pull Request
- Merge automático de la PR

Estas operaciones se ejecutan solo cuando:
1. Se trata de una migración combinada (múltiples microservicios)
2. Todos los microservicios se han migrado exitosamente
3. Se ha confirmado que no hay errores críticos
"""

import asyncio
import aiohttp
from typing import Dict, Any, List, Tuple
from shuttlelib.utils.logger import logger
# NOTE: Funciones temporalmente deshabilitadas hasta implementar correctamente
# from .github.operations import (
#     backup_deployment_yaml_to_branch,
#     create_pull_request_and_merge
# )


async def backup_deployment_yaml_to_branch(session, owner, repo, deployment_path, deployment_content, 
                                         target_branch, source_sha):
    """
    Función placeholder para backup de deployment YAML.
    TODO: Implementar funcionalidad real usando funciones existentes de common_utils.py
    """
    logger.info(f"📦 PLACEHOLDER: Backup del deployment para {repo} en branch {target_branch}")
    return {"success": True, "message": "Backup placeholder completado"}


async def create_pull_request_and_merge(session, owner, repo, source_branch, target_branch, 
                                       pr_title, pr_body):
    """
    Función placeholder para crear PR y merge.
    TODO: Implementar funcionalidad real usando GitHub API
    """
    logger.info(f"🔄 PLACEHOLDER: PR y merge desde {source_branch} hacia {target_branch} en {repo}")
    return {"success": True, "message": "PR y merge placeholder completado"}


async def execute_combined_migration_finalization(
    session: aiohttp.ClientSession,
    migration_results: List[Dict[str, Any]],
    git_token: str,
    microservices_data: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Ejecuta las operaciones finales de una migración combinada exitosa.
    
    Solo se ejecuta si:
    - Todos los microservicios se migraron exitosamente
    - Es una migración combinada (más de un microservicio)
    
    Args:
        session: Sesión HTTP aiohttp
        migration_results: Lista de resultados de migración de cada microservicio
        git_token: Token de GitHub
        microservices_data: Lista de datos de microservicios migrados
        
    Returns:
        Dict con resultado de las operaciones finales
    """
    try:
        # Verificar que todos los microservicios se migraron exitosamente
        all_successful = all(
            result.get('success', False) for result in migration_results
        )
        
        if not all_successful:
            logger.warning("No se ejecutarán operaciones finales: algún microservicio falló")
            return {
                'backup_deployment': {'status': 'skipped', 'reason': 'migration_failed'},
                'pull_request': {'status': 'skipped', 'reason': 'migration_failed'},
                'merge': {'status': 'skipped', 'reason': 'migration_failed'}
            }
        
        # Verificar que es una migración combinada (más de un microservicio)
        if len(microservices_data) <= 1:
            logger.info("Migración individual detectada: omitiendo operaciones de migración combinada")
            return {
                'backup_deployment': {'status': 'skipped', 'reason': 'single_microservice'},
                'pull_request': {'status': 'skipped', 'reason': 'single_microservice'},
                'merge': {'status': 'skipped', 'reason': 'single_microservice'}
            }
        
        logger.info(f"🎯 INICIANDO OPERACIONES FINALES DE MIGRACIÓN COMBINADA ({len(microservices_data)} microservicios)")
        
        results = {
            'backup_deployment': {'status': 'pending'},
            'pull_request': {'status': 'pending'},
            'merge': {'status': 'pending'}
        }
        
        # PASO 1: Backup de deployments originales
        logger.info("--- PASO FINAL 1: BACKUP DEPLOYMENTS ORIGINALES ---")
        
        backup_results = []
        for micro_data in microservices_data:
            if micro_data.get('deployment_yaml'):
                try:
                    backup_result = await backup_deployment_yaml_to_branch(
                        session=session,
                        repo_url=micro_data['url_git'],
                        git_token=git_token,
                        deployment_yaml=micro_data['deployment_yaml'],
                        old_name=micro_data['old_name']
                    )
                    backup_results.append({
                        'microservice': micro_data['old_name'],
                        'success': backup_result.get('success', False),
                        'details': backup_result
                    })
                    logger.info(f"✅ Backup deployment {micro_data['old_name']}: {'OK' if backup_result.get('success') else 'KO'}")
                except Exception as e:
                    logger.error(f"❌ Error en backup deployment {micro_data['old_name']}: {e}")
                    backup_results.append({
                        'microservice': micro_data['old_name'],
                        'success': False,
                        'error': str(e)
                    })
        
        all_backups_successful = all(result['success'] for result in backup_results)
        results['backup_deployment'] = {
            'status': 'success' if all_backups_successful else 'partial_failure',
            'results': backup_results
        }
        
        # PASO 2: Crear Pull Request y Merge
        if all_backups_successful:
            logger.info("--- PASO FINAL 2: CREAR PR Y MERGE ---")
            
            try:
                # Usar el primer microservicio para obtener datos del repositorio
                # (asumiendo que todos están en el mismo repositorio para migración combinada)
                first_micro = microservices_data[0]
                
                pr_result = await create_pull_request_and_merge(
                    session=session,
                    repo_url=first_micro['url_git'],
                    git_token=git_token,
                    microservice_names=[micro['old_name'] for micro in microservices_data],
                    is_combined_migration=True
                )
                
                results['pull_request'] = {
                    'status': 'success' if pr_result.get('success') else 'failure',
                    'details': pr_result
                }
                results['merge'] = {
                    'status': 'success' if pr_result.get('merged') else 'failure',
                    'details': pr_result
                }
                
                logger.info(f"✅ PR y Merge: {'OK' if pr_result.get('success') else 'KO'}")
                
            except Exception as e:
                logger.error(f"❌ Error en PR y Merge: {e}")
                results['pull_request']['status'] = 'failure'
                results['pull_request']['error'] = str(e)
                results['merge']['status'] = 'failure'
                results['merge']['error'] = str(e)
        else:
            logger.warning("Saltando PR y Merge debido a fallos en backup de deployments")
            results['pull_request']['status'] = 'skipped'
            results['pull_request']['reason'] = 'backup_failed'
            results['merge']['status'] = 'skipped'
            results['merge']['reason'] = 'backup_failed'
        
        logger.info("🎯 OPERACIONES FINALES DE MIGRACIÓN COMBINADA COMPLETADAS")
        return results
        
    except Exception as e:
        logger.error(f"❌ Error crítico en operaciones finales de migración combinada: {e}")
        return {
            'backup_deployment': {'status': 'error', 'error': str(e)},
            'pull_request': {'status': 'error', 'error': str(e)},
            'merge': {'status': 'error', 'error': str(e)}
        }


def should_execute_combined_operations(
    microservices_count: int,
    migration_success: bool
) -> bool:
    """
    Determina si se deben ejecutar las operaciones de migración combinada.
    
    Args:
        microservices_count: Número de microservicios en la migración
        migration_success: Si la migración fue exitosa
        
    Returns:
        bool: True si se deben ejecutar las operaciones combinadas
    """
    return microservices_count > 1 and migration_success


async def cleanup_individual_migration_artifacts(
    session: aiohttp.ClientSession,
    repo_url: str,
    git_token: str,
    old_name: str
) -> Dict[str, Any]:
    """
    Limpia artefactos específicos de migración individual que no son necesarios
    en migraciones combinadas.
    
    Args:
        session: Sesión HTTP aiohttp
        repo_url: URL del repositorio
        git_token: Token de GitHub
        old_name: Nombre del microservicio
        
    Returns:
        Dict con resultado de la limpieza
    """
    try:
        logger.info(f"🧹 Limpiando artefactos de migración individual para {old_name}")
        
        # Aquí se pueden agregar operaciones de limpieza específicas
        # Por ejemplo, eliminar ramas temporales, tags temporales, etc.
        
        return {
            'status': 'success',
            'cleaned_artifacts': []
        }
        
    except Exception as e:
        logger.error(f"❌ Error en limpieza de artefactos para {old_name}: {e}")
        return {
            'status': 'error',
            'error': str(e)
        }