"""
Flujo específico para ConfigMaps de Backend.
Maneja la creación de archivos application.yaml y application-cert.properties.
"""

import aiohttp
from typing import Dict
from shuttlelib.utils.logger import logger
from .common_utils import normalize_git_url
from .github_client import GitHubClient


async def create_backend_config_files(
    config_files_in_memory: Dict[str, str], 
    old_name: str, 
    git_token: str, 
    url_git_cm: str
) -> str:
    """
    Crea archivos de configuración específicos para microservicios Backend.
    
    LÓGICA BACKEND:
    1. Buscar archivo {old_name}-{env}.yml → crear config/cert/application.yaml
    2. Buscar archivo application-{env}.properties → crear config/cert/application-cert.properties
    
    Args:
        config_files_in_memory: Archivos de configuración descargados del config server
        old_name: Nombre del microservicio
        git_token: Token de GitHub
        url_git_cm: URL del repositorio de ConfigMaps
        
    Returns:
        str: Mensaje de resultado de la creación de archivos backend
    """
    try:
        if not config_files_in_memory:
            return "⚠️ No hay archivos de configuración en memoria para procesar"
            
        logger.info(f"⚙️ BACKEND_CONFIG: Iniciando con {len(config_files_in_memory)} archivos")
        # Extraer owner y repo de la URL
        normalized_git_url = normalize_git_url(url_git_cm)
        owner, repo = normalized_git_url.replace('https://github.com/', '').split('/')
                
        # Crear sesión HTTP para GitHubClient
        session = aiohttp.ClientSession()
        
        try:
            # Inicializar cliente GitHub con sesión
            github_client = GitHubClient(git_token, session)
            
            created_files = []
            
            # PASO 1: Buscar archivo {old_name}-{env}.yaml para crear config/cert/application.yaml
            yaml_source_file = None
            yaml_source_content = None
            
            # Patrones para buscar archivos YAML para application.yaml (ORDEN DE PRIORIDAD)
            yaml_patterns = [
                f"{old_name}-dev.yml",
                f"{old_name}-cert.yml", 
                f"{old_name}.yml",
                f"{old_name}-dev.yml",
                f"{old_name}-cert.yml",
                f"{old_name}.yml",
                f"{old_name}-dev.yaml",
                f"{old_name}-cert.yaml", 
                f"{old_name}.yaml",
                f"{old_name}-dev.yaml",
                f"{old_name}-cert.yaml",
                f"{old_name}.yaml"
            ]
                        
            for pattern in yaml_patterns:
                for file_name, file_content in config_files_in_memory.items():
                    if file_name.lower() == pattern.lower():
                        yaml_source_file = file_name
                        yaml_source_content = file_content
                        break
                if yaml_source_file:
                    break
            
            # Si encontramos archivo yml, crear config/cert/application.yaml con su contenido
            if yaml_source_file and yaml_source_content:
                try:
                    app_yaml_path = "config/cert/application.yaml"
                    
                    yaml_result = await github_client.create_or_update_file(
                        owner, 
                        repo, 
                        app_yaml_path,
                        yaml_source_content,
                        f"ConfigMap: Create {app_yaml_path} from {yaml_source_file} [ci skip]",
                        "main"
                    )
                    
                    # Manejar resultado como booleano
                    if yaml_result:
                        created_files.append(f"✅ YAML {app_yaml_path}: OK (desde {yaml_source_file})")
                    else:
                        created_files.append(f"❌ YAML {app_yaml_path}: KO - Error en creación")
                        logger.error(f"❌ BACKEND_CONFIG: Error al crear {app_yaml_path}")
                        
                except Exception as e:
                    logger.error(f"❌ BACKEND_CONFIG: Error creando config/cert/application.yaml: {str(e)}")
                    created_files.append(f"❌ YAML config/cert/application.yaml: KO - Error: {str(e)}")
            else:
                logger.warning(f"⚠️ BACKEND_CONFIG: No se encontró archivo YML para crear config/cert/application.yaml")
                created_files.append(f"⚠️ No se encontró archivo YML para crear config/cert/application.yaml")
            
            # PASO 2: Buscar archivo application*.properties para crear config/cert/application.properties (NUEVO)
            properties_file = None
            properties_content = None
            
            # Patrones para buscar archivos properties (ORDEN DE PRIORIDAD)
            properties_patterns = [
                "application.properties",
                "application-dev.properties",
                "application-cert.properties"
            ]
            
            
            for pattern in properties_patterns:
                for file_name, file_content in config_files_in_memory.items():
                    if file_name.lower() == pattern.lower():
                        properties_file = file_name
                        properties_content = file_content
                        break
                if properties_file:
                    break

            # Si encontramos archivo properties, crear config/cert/application.properties (NUEVO)
            application_properties_created = False
            if properties_file and properties_content:
                try:
                    new_app_properties_path = "config/cert/application.properties"
                    
                    properties_result = await github_client.create_or_update_file(
                        owner, 
                        repo, 
                        new_app_properties_path,
                        properties_content,
                        f"ConfigMap: Create {new_app_properties_path} from {properties_file} [ci skip]",
                        "main"
                    )
                    
                    # Manejar resultado como booleano
                    if properties_result:
                        created_files.append(f"✅ PROPERTIES {new_app_properties_path}: OK (desde {properties_file})")
                        application_properties_created = True
                    else:
                        created_files.append(f"❌ PROPERTIES {new_app_properties_path}: KO - Error en creación")
                        
                except Exception as e:
                    logger.error(f"❌ BACKEND_CONFIG: Error creando config/cert/application.properties: {str(e)}")
                    created_files.append(f"❌ PROPERTIES config/cert/application.properties: KO - Error: {str(e)}")
            else:
                logger.warning(f"⚠️ BACKEND_CONFIG: No se encontró archivo properties para crear config/cert/application.properties")
                created_files.append(f"⚠️ No se encontró archivo properties para crear config/cert/application.properties")
            
            # PASO 3: Si se creó application.properties, borrar application-cert.properties (si existe)
            if application_properties_created:
                try:
                    old_cert_properties_path = "config/cert/application-cert.properties"
                    
                    # Intentar obtener el archivo para verificar si existe
                    existing_file_content, existing_file_sha = await github_client.get_file_content(
                        owner, repo, old_cert_properties_path, "main"
                    )
                    
                    if existing_file_content is not None:
                        # El archivo existe, proceder a borrarlo

                        delete_result = await github_client.delete_file(
                            owner, 
                            repo, 
                            old_cert_properties_path,
                            existing_file_sha,
                            f"ConfigMap: Delete {old_cert_properties_path} - replaced by application.properties [ci skip]",
                            "main"
                        )
                        
                        if delete_result:
                            created_files.append(f"✅ DELETE {old_cert_properties_path}: OK - Borrado correctamente")
                        else:
                            created_files.append(f"❌ DELETE {old_cert_properties_path}: KO - Error en borrado")
                    else:
                        logger.info(f"ℹ️ BACKEND_CONFIG: {old_cert_properties_path} no existe - no es necesario borrarlo")
                        
                except Exception as e:
                    logger.error(f"❌ BACKEND_CONFIG: Error intentando borrar application-cert.properties: {str(e)}")
                    created_files.append(f"❌ DELETE config/cert/application-cert.properties: KO - Error: {str(e)}")
                
            # PASO 4: Mostrar resultado final  
            if created_files:
                result = " | ".join(created_files)
                return result
            else:
                result = f"❌ No se crearon archivos de configuración backend para '{old_name}'"
                logger.warning(f"🏁 BACKEND_CONFIG: {result}")
                return result
                
        finally:
            # Cerrar la sesión HTTP
            await session.close()
        
    except Exception as e:
        logger.error(f"❌ BACKEND_CONFIG: Error general: {str(e)}")
        return f"❌ Error creando archivos de configuración backend: {str(e)}"