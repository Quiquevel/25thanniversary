"""
Módulo de procesamiento OpenShift.
Contiene todas las funciones relacionadas con la obtención y procesamiento de datos de OpenShift.
"""
import os
import yaml
import aiohttp
import traceback
from typing import Dict, Any, Optional, Tuple
from shuttlelib.utils.logger import logger
from shuttlelib.openshift.client import OpenshiftClient
from src.utils.proxy_config import get_proxy_config
# Variables globales
_client = None

def get_openshift_client():
    """
    Obtiene el cliente de OpenShift ya inicializado del sistema usando patrón singleton.
    Evita crear nuevas conexiones a Vault reutilizando el cliente existente.
    Solo se inicializa una vez durante toda la vida del microservicio.
    """
    global _client
    
    # Si ya tenemos un cliente inicializado, lo retornamos (singleton)
    if _client is not None:
        logger.debug("♻️ Reutilizando cliente OpenShift existente (singleton)")
        return _client
    
    try:
        # Prioridad 1: Usar el cliente de ocplib (ya inicializado al arrancar el micro)
        from src.utils.ocplib import ocpClient
        _client = ocpClient
        return _client
    except ImportError:
        logger.warning("⚠️ No se pudo importar ocpClient de ocplib")
    
    # Prioridad 2: Verificar si despliegue_token ya está cargado y tiene cliente  
    try:
        import sys
        if 'src.services.despliegue_token' in sys.modules:
            module = sys.modules['src.services.despliegue_token']
            if hasattr(module, 'get_openshift_client'):
                fallback_client = module.get_openshift_client()
                if fallback_client:
                    _client = fallback_client
                    return _client
    except Exception as e:
        logger.debug(f"No se pudo reutilizar cliente de despliegue_token: {e}")
    
    # Fallback: crear cliente nuevo (no recomendado)
    logger.warning("⚠️ Creando nuevo OpenshiftClient como último recurso (primera vez)")
    entity_id = os.getenv("ENTITY_ID", "spain").lower()
    _client = OpenshiftClient(entity_id=entity_id)
    return _client

# Diccionario para mapear entorno, tipo y región a identificador shuttlelib
SHUTTLE_CLUSTERS = {
    "dev": {
        "intranet": {"bo1": {"cluster": "bks", "region": "bo1"}},
        "azure": {"weu1": {"cluster": "ocp05azure", "region": "weu1", "az": True}},
        "dmz": {"bo1": {"cluster": "bks", "region": "bo1"}},
        "mov": {"bo1": {"cluster": "bks", "region": "bo1"}}
    },
    "pre": {
        "intranet": {
            "bo1": {"cluster": "bks", "region": "bo1"},
            "bo2": {"cluster": "bks", "region": "bo2"}
        },
        "azure": {
            "weu1": {"cluster": "ocp05azure", "region": "weu1", "az": True},
            "weu2": {"cluster": "ocp05azure", "region": "weu2", "az": True}
        },
        "dmz": {
            "bo1": {"cluster": "bks", "region": "bo1"},
            "bo2": {"cluster": "bks", "region": "bo2"}
        },
        "mov": {
            "bo1": {"cluster": "bks", "region": "bo1"},
            "bo2": {"cluster": "bks", "region": "bo2"}
        }
    },
    "pro": {
        "intranet": {
            "bo1": {"cluster": "prodarwin", "region": "bo1"},
            "bo2": {"cluster": "prodarwin", "region": "bo2"}
        },
        "azure": {
            "weu1": {"cluster": "ocp05azure", "region": "weu1", "az": True},
            "weu2": {"cluster": "ocp05azure", "region": "weu2", "az": True}
        },
        "dmz": {
            "bo1": {"cluster": "dmzbdarwin", "region": "bo1"},
            "bo2": {"cluster": "dmzbdarwin", "region": "bo2"}
        },
        "mov": {
            "bo1": {"cluster": "dmz2bmov", "region": "bo1"},
            "bo2": {"cluster": "dmz2bmov", "region": "bo2"}
        }
    }
}


def extract_namespace_from_oam(oam_yaml: Optional[Dict], target_environment: str = "cert") -> Optional[str]:
    """
    Extrae el namespace correcto del OAM para un entorno específico.
    
    Args:
        oam_yaml: Datos del OAM
        target_environment: Entorno objetivo (cert, dev, pre, pro)
        
    Returns:
        Optional[str]: Namespace encontrado en el OAM o None
    """
    if not oam_yaml or not isinstance(oam_yaml, dict):
        return None
    
    try:
        # Buscar environments en diferentes ubicaciones del OAM
        environments = []
        
        if 'raw_data' in oam_yaml and 'environments' in oam_yaml['raw_data']:
            environments = oam_yaml['raw_data']['environments']
        elif 'environments' in oam_yaml:
            environments = oam_yaml['environments']
        elif 'spec' in oam_yaml and 'environments' in oam_yaml['spec']:
            environments = oam_yaml['spec']['environments']
        
        # Buscar el entorno específico
        for env in environments:
            if not isinstance(env, dict):
                continue
                
            env_name = env.get('name', '').lower()
            env_type = env.get('type', '').lower()
            
            # Verificar si coincide con el entorno objetivo
            if (env_name == target_environment.lower() or 
                env_type == target_environment.lower() or
                (target_environment.lower() == 'cert' and env_type == 'certification')):
                
                # Buscar el namespace en las infraestructuras
                infrastructures = env.get('infrastructures', [])
                for infra in infrastructures:
                    if not isinstance(infra, dict):
                        continue
                        
                    # Verificar que sea infrastructure KUBERNETES
                    properties = infra.get('properties', {})
                    infra_type = infra.get('type', '') or properties.get('type', '')
                    
                    if infra_type == 'KUBERNETES':
                        namespace = properties.get('namespace')
                        if namespace:
                            return namespace
        
        logger.warning(f"No se encontró namespace en el OAM para el entorno '{target_environment}'")
        return None
        
    except Exception as e:
        logger.error(f"Error extrayendo namespace del OAM: {str(e)}")
        return None


def determine_cluster_config_from_oam(oam_yaml: Optional[Dict], environment: str = "dev", namespace: str = "") -> Tuple[str, str, str, str]:
    """
    Determina la configuración de cluster basándose en el análisis del OAM.
    Si no hay OAM, intenta determinar basándose en el namespace.
    
    Args:
        oam_yaml: Datos del OAM para analizar
        environment: Entorno (dev, pre, pro)
        namespace: Namespace para determinar cluster cuando no hay OAM
        
    Returns:
        Tuple[str, str, str, str]: (cluster, region, tipo, api_server)
    """
    # Valores por defecto
    cluster_type = "intranet"  # intranet, azure, dmz, mov
    region = "bo1"
    api_server = ""  # URL del API Server extraída del OAM
    oam_detection_success = False  # Flag para saber si el OAM funcionó
    
    if oam_yaml and isinstance(oam_yaml, dict):
        try:
            # Buscar el apiServer en cualquier environment con infraestructura KUBERNETES
            # Los environments pueden estar en: raw_data, root, o spec
            environments = []
            
            # Estrategia 1: En raw_data (formato real del usuario)
            if 'raw_data' in oam_yaml and 'environments' in oam_yaml['raw_data']:
                environments = oam_yaml['raw_data']['environments']
            
            # Estrategia 2: En root del OAM
            elif 'environments' in oam_yaml:
                environments = oam_yaml['environments']
            
            # Estrategia 3: En spec
            elif 'spec' in oam_yaml:
                spec = oam_yaml.get('spec', {})
                environments = spec.get('environments', [])
                if environments:
                    logger.info(f"🔍 Environments encontrados en spec.environments")
                else:
                    logger.info(f"🔍 No se encontraron environments en ninguna ubicación estándar")
            
            else:
                logger.info(f"🔍 No se encontraron environments en ninguna ubicación")
                
            logger.info(f"🔍 Encontrados {len(environments)} environments en el OAM")
            
            # Mapeo de environments para búsqueda inteligente
            env_mapping = {
                "dev": ["cert", "certification", "dev"],
                "cert": ["cert", "certification"],  # Mapeo directo para cert
                "pre": ["pre", "preproduction"],
                "pro": ["pro", "production"]
            }
            
            target_envs = env_mapping.get(environment, [environment])
            
            # ESTRATEGIA 1: Buscar por environment específico
            for env_idx, env in enumerate(environments):
                env_name = env.get('name', '')
                env_type = env.get('type', '')
                
                # Verificar si este environment coincide con el que buscamos
                env_match = (env_name.lower() in [t.lower() for t in target_envs] or 
                            env_type.lower() in [t.lower() for t in target_envs] or
                            any(target.lower() in env_name.lower() for target in target_envs))
                
                if env_match:                    
                    # Buscar en las infraestructuras de este environment
                    infrastructures = env.get('infrastructures', [])
                    
                    for infra_idx, infra in enumerate(infrastructures):
                        infra_id = infra.get('id', '')
                        # El type puede estar directamente en la infrastructure o en properties
                        properties = infra.get('properties', {})
                        infra_type = infra.get('type', '') or properties.get('type', '')
                        
                        if infra_type == 'KUBERNETES':
                            api_server_found = properties.get('apiServer', '')
                            
                            if api_server_found:
                                api_server = api_server_found  # Almacenar para retornar
                                oam_detection_success = True  # Marcamos como exitoso
                                
                                # Determinar tipo y región basados en el apiServer
                                if "ocp05" in api_server_found:
                                    cluster_type = "azure"
                                    if "weu1" in api_server_found:
                                        region = "weu1"
                                    elif "weu2" in api_server_found:
                                        region = "weu2"
                                    else:
                                        region = "weu1"  # Default para azure
                                elif "bo2" in api_server_found:
                                    cluster_type = "intranet"  # Puede ser intranet, dmz, mov
                                    region = "bo2"
                                elif "dmz" in api_server_found.lower():
                                    cluster_type = "dmz"
                                    region = "bo1" if "bo1" in api_server_found else "bo2"
                                elif "mov" in api_server_found.lower():
                                    cluster_type = "mov"
                                    region = "bo1" if "bo1" in api_server_found else "bo2"
                                else:
                                    # Default a intranet bo1
                                    cluster_type = "intranet"
                                    region = "bo1"                                
                                # SALIR INMEDIATAMENTE cuando encontremos un apiServer válido
                                break
                    
                    # Si encontramos algo en este environment, salir del loop principal
                    if oam_detection_success:
                        break
                        
            # ESTRATEGIA 2: Si no encontramos coincidencia específica, buscar el primer KUBERNETES
            if not oam_detection_success:
                logger.warning(f"⚠️ No se encontró environment específico para '{environment}', buscando primer apiServer disponible")
                
                for env_idx, env in enumerate(environments):
                    env_name = env.get('name', '')
                    env_type = env.get('type', '')
                    
                    # Buscar en las infraestructuras de este environment
                    infrastructures = env.get('infrastructures', [])
                    
                    for infra_idx, infra in enumerate(infrastructures):
                        infra_id = infra.get('id', '')
                        properties = infra.get('properties', {})
                        infra_type = infra.get('type', '') or properties.get('type', '')
                        
                        if infra_type == 'KUBERNETES':
                            api_server_found = properties.get('apiServer', '')
                            
                            if api_server_found:
                                logger.warning(f"🔄 Usando primer apiServer encontrado: {api_server_found} (de {env_name})")
                                api_server = api_server_found
                                oam_detection_success = True
                                
                                # Análisis básico del cluster
                                if "ocp05" in api_server_found:
                                    cluster_type = "azure"
                                    region = "weu1"
                                elif "bo2" in api_server_found:
                                    cluster_type = "intranet"
                                    region = "bo2"
                                else:
                                    cluster_type = "intranet"
                                    region = "bo1"
                                
                                break
                    
                    if oam_detection_success:
                        break
                    
        except Exception as e:
            logger.error(f"Error al analizar OAM: {str(e)}")
            logger.error(f"Trazado: {traceback.format_exc()}")
    
    # Si no hay OAM o el análisis OAM falló, intentar detectar por namespace
    if not oam_detection_success:
        if oam_yaml:
            logger.warning("Análisis OAM no encontró configuración válida, usando fallback por namespace")
        else:
            logger.warning("No hay datos OAM disponibles, intentando detectar por namespace")
        
        if namespace:
            # Patrones conocidos para identificar clusters Azure
            azure_patterns = ['sanes', 'sa-', 'anes', 'estocr', 'azure']
            onpremise_patterns = ['bo-', 'co-', 'intranet', 'bks']
            
            namespace_lower = namespace.lower()
            
            # Verificar patrones de Azure (ocp05/weu1)
            if any(pattern in namespace_lower for pattern in azure_patterns):
                cluster_type = "azure"
                region = "weu1"
            # Verificar patrones de OnPremise (bks/bo1)
            elif any(pattern in namespace_lower for pattern in onpremise_patterns):
                cluster_type = "intranet"
                region = "bo1"
            else:
                logger.warning(f"No se pudo determinar cluster por namespace '{namespace}', usando configuración por defecto")
                cluster_type = "intranet"
                region = "bo1"
        else:
            logger.warning("No hay namespace disponible para detectar cluster, usando configuración por defecto")
            cluster_type = "intranet"
            region = "bo1"
    
    # Obtener configuración del cluster desde SHUTTLE_CLUSTERS
    cluster_config = SHUTTLE_CLUSTERS.get(environment, {}).get(cluster_type, {}).get(region, {})
    
    if not cluster_config:
        logger.warning(f"No se encontró configuración para {environment}/{cluster_type}/{region}, usando default")
        cluster_config = {"cluster": "bks", "region": "bo1"}
        cluster_type = "intranet"
        region = "bo1"
    
    cluster = cluster_config["cluster"]
    region = cluster_config["region"]

    return cluster, region, cluster_type, api_server


async def get_deployment_from_openshift(configserver: str, namespace: str, 
                                        oam_yaml: Optional[Dict] = None) -> Tuple[Dict[str, Any], str, Dict[str, Any]]:
    """
    Obtiene el deployment desde OpenShift y extrae información relevante.
    
    Args:
        configserver: Nombre del deployment a buscar (ej: config-server, configuration-service)
        namespace: Namespace exacto donde buscar el deployment (ya debe estar procesado)
        oam_yaml: Datos OAM para determinar configuración del cluster (API server, tokens, etc)
        
    Returns:
        Tuple[Optional[Dict[str, Any]], str, Optional[Dict[str, Any]]]: Tupla con (deployment_data, clean_namespace, raw_deployment)
        Si el deployment no existe, deployment_data y raw_deployment serán None, pero clean_namespace se mantiene.
        
    Raises:
        Exception: Si hay error de conectividad o procesamiento (no por deployment no encontrado)
    """
    try:
        # PASO 1: Extraer namespace directamente del OAM (environment 'cert')
        oam_namespace = extract_namespace_from_oam(oam_yaml, "cert")
        if oam_namespace:
            full_namespace = oam_namespace
        else:
            # Fallback: usar el namespace recibido como parámetro
            full_namespace = namespace
            logger.warning(f"⚠️ No se pudo extraer namespace del OAM, usando parámetro: {full_namespace}")
        
        # PASO 2: Determinar configuración del cluster basándose en el OAM
        environment = "dev"  # Para deployments normalmente dev
        cluster, region, cluster_type, api_server = determine_cluster_config_from_oam(oam_yaml, environment, full_namespace)
        # Inicializar la variable deployment
        deployment = None
        
        # MÉTODO ÚNICO: Solo usar shuttlelib get_resource (método confiable)
        try:
            # Obtener cliente singleton una sola vez
            client = get_openshift_client()

            deployments = await client.get_resource(
                functional_environment=environment,
                cluster=cluster,
                resource="deployments", 
                namespace=full_namespace,  # Usar namespace completo del OAM
                region=region
            )
            
            if deployments and region in deployments:
                # Buscar el deployment específico en la respuesta
                for item in deployments[region].get('items', []):
                    item_name = item.get('metadata', {}).get('name', '')
                    # Match when the desired configserver name is contained inside the actual resource name
                    # (e.g. configserver 'configuration-service' should match 'configuration-service-dev')
                    try:
                        if item_name and configserver and configserver.lower() in item_name.lower():
                            deployment = item
                            break
                    except Exception:
                        # Fallback to strict equality if something unexpected occurs
                        if item_name == configserver:
                            deployment = item
                            break
                        
                if not deployment:
                    logger.warning(f"Deployment '{configserver}' no encontrado en la respuesta de shuttlelib")
            else:
                logger.warning(f"No se obtuvieron deployments para la región {region}")
        
        except Exception as e:
            logger.error(f"Error con shuttlelib get_resource: {str(e)}")
            raise Exception(f"Error al obtener deployment via shuttlelib: {str(e)}")
        
        # Verificar que encontramos el deployment
        if not deployment:
            logger.warning(f"Deployment {configserver} no encontrado en {full_namespace} - probablemente ya fue eliminado")
            # En lugar de lanzar excepción, devolver None para permitir flujo continuo
            # ARREGLAR: clean_namespace debe definirse antes de usarse
            clean_namespace = _clean_namespace(namespace)
            return None, clean_namespace, None
        
        # Extraer información del deployment
        deployment_data = {
            'name': deployment.get('metadata', {}).get('name', configserver),
            'namespace': deployment.get('metadata', {}).get('namespace', namespace),
            'labels': deployment.get('metadata', {}).get('labels', {}),
            'annotations': deployment.get('metadata', {}).get('annotations', {}),
            'spec': deployment.get('spec', {})
        }
        
        # Extraer información de contenedores
        containers = deployment.get('spec', {}).get('template', {}).get('spec', {}).get('containers', [])
        if containers:
            container_info = []
            for container in containers:
                container_data = {
                    'name': container.get('name'),
                    'image': container.get('image'),
                    'ports': container.get('ports', []),
                    'env': container.get('env', []),
                    'resources': container.get('resources', {}),
                    'volumeMounts': container.get('volumeMounts', [])
                }
                container_info.append(container_data)
            
            deployment_data['containers'] = container_info
        
        # Extraer variables de entorno importantes
        env_vars = {}
        for container in containers:
            for env in container.get('env', []):
                env_vars[env.get('name', '')] = env.get('value', '')
        
        deployment_data['environment_variables'] = env_vars
        
        # Limpiar namespace (remover sufijos comunes)
        clean_namespace = _clean_namespace(namespace)

        # Devolver: datos procesados, namespace limpio, y deployment raw completo para backup
        return deployment_data, clean_namespace, deployment
        
    except Exception as e:
        logger.error(f"Error obteniendo deployment desde OpenShift: {str(e)}")
        raise


async def get_secret_from_openshift(secret_name: str, namespace: str, oam_yaml: Optional[Dict] = None) -> Optional[Dict[str, Any]]:
    """
    Obtiene un secret desde OpenShift.
    
    Args:
        secret_name: Nombre del secret a obtener
        namespace: Namespace donde buscar el secret
        oam_yaml: Datos OAM para determinar configuración del cluster
        
    Returns:
        Optional[Dict[str, Any]]: Datos del secret o None si no se encuentra
        
    Raises:
        Exception: Si hay error en la conexión o procesamiento
    """
    try:
        
        # Usar el namespace directamente (ya debe estar procesado)
        full_namespace = namespace
        
        # Determinar configuración del cluster basándose en el OAM
        environment = "dev"  # Para secrets normalmente dev
        cluster, region, cluster_type, api_server = determine_cluster_config_from_oam(oam_yaml, environment, full_namespace)

        secret = None
        
        # MÉTODO 1: Intentar con client.get_resource() (método preferido de shuttlelib)
        try:
            # Obtener cliente singleton una sola vez
            client = get_openshift_client()
            
            secrets = await client.get_resource(
                functional_environment=environment,
                cluster=cluster,
                resource="secrets", 
                namespace=full_namespace,
                region=region
            )
            
            if secrets and region in secrets:
                # Buscar el secret específico en la respuesta
                for item in secrets[region].get('items', []):
                    if item.get('metadata', {}).get('name') == secret_name:
                        secret = item
                        break
                        
                if secret:
                    logger.info(f"Secret '{secret_name}' encontrado via shuttlelib en {cluster}/{region}")
        
        except Exception as e:
            logger.warning(f"Error con shuttlelib get_resource: {str(e)}, intentando llamada directa a API")
        
        # MÉTODO 2: Si shuttlelib falla, llamada directa a la API de Kubernetes
        if not secret:
            try:
                # Usar el cliente OpenShift singleton solo para el token
                client = get_openshift_client()
                
                # Obtener el token para la autenticación  
                cluster_token = client.clusters.get(environment, {}).get(cluster, {}).get(region, {}).get("token")
                                
                if not cluster_token:
                    logger.error(f"No se pudo obtener el token para {environment}, {cluster}, {region}")
                    raise Exception(f"No se pudo obtener el token para el cluster")
                
                # Usar directamente la URL del API Server extraída del OAM
                if api_server:
                    api_url = api_server
                else:
                    # Fallback basado en configuración del cluster
                    if cluster == "ocp05azure" and region == "weu1":
                        api_url = f"https://api.ocp05.san.dev.weu1.azure.paas.cloudcenter.corp:6443"
                    elif cluster == "bks" and region == "bo1":
                        api_url = f"https://api.san01bks.san.dev.bo1.paas.cloudcenter.corp:6443"
                    else:
                        logger.error(f"❌ Cluster no soportado: {cluster}/{region}")
                        raise Exception(f"Cluster {cluster}/{region} no soportado")
                
                # Crear headers para la petición
                headers = {
                    "Authorization": f"Bearer {str(cluster_token)}", 
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                }
                
                # URL para obtener secrets
                req_url = f"{api_url}/api/v1/namespaces/{full_namespace}/secrets/{secret_name}"
                # Only GitHub API needs proxy - all internal corporate domains go direct
                if 'api.github.com' in req_url:
                    proxy_config = get_proxy_config()
                else:
                    proxy_config = {}  # No proxy for OpenShift APIs
                    
                async with aiohttp.ClientSession(**proxy_config) as session:
                    # SSL context para manejar certificados
                    import ssl
                    ssl_context = ssl.create_default_context()
                    ssl_context.check_hostname = False
                    ssl_context.verify_mode = ssl.CERT_NONE
                    
                    async with session.get(
                        url=req_url, 
                        headers=headers,
                        ssl=ssl_context
                    ) as response:
                        status = response.status
                        
                        if status == 200:
                            secret = await response.json()
                        
                        elif status == 401:
                            logger.error(f"Token no autorizado para {full_namespace}")
                            raise Exception(f"Token no autorizado para acceder al namespace {full_namespace}")
                        elif status == 403:
                            logger.error(f"Acceso denegado para {full_namespace}")
                            raise Exception(f"Acceso denegado al namespace {full_namespace}")
                        elif status == 404:
                            logger.warning(f"Secret {secret_name} no encontrado en {full_namespace}")
                            return None  # Secret no existe, no es error crítico
                        else:
                            response_text = await response.text()
                            logger.error(f"Error al obtener secret: {status}, {response_text}")
                            raise Exception(f"Error HTTP {status} al obtener secret")
                            
            except Exception as e:
                logger.error(f"Error en llamada directa a API: {str(e)}")
                raise Exception(f"Error al obtener secret via API directa: {str(e)}")
        
        # Verificar que encontramos el secret
        if not secret:
            logger.warning(f"Secret {secret_name} no encontrado en {full_namespace}")
            return None

        return secret
        
    except Exception as e:
        logger.error(f"Error obteniendo secret desde OpenShift: {str(e)}")
        raise


async def get_oam_from_git(url_oam: str, git_token: str) -> Dict[str, Any]:
    """
    Obtiene el archivo OAM desde un repositorio Git.
    
    Args:
        url_oam: URL del archivo OAM en Git
        git_token: Token de autenticación para Git
        
    Returns:
        Dict[str, Any]: Datos del OAM parseados
        
    Raises:
        Exception: Si no se puede obtener o parsear el archivo OAM
    """
    try:
        # Normalizar URL OAM antes de procesarla
        from ..common_utils import normalize_oam_url
        normalized_url_oam = normalize_oam_url(url_oam)

        # Convertir URL de GitHub web a API URL si es necesario
        from ..common_utils import convert_github_url_to_api
        api_url = convert_github_url_to_api(normalized_url_oam)
        
        headers = {
            'Authorization': f'token {git_token}',
            'Accept': 'application/vnd.github.v3.raw'
        }
        
        proxy_config = get_proxy_config()
        async with aiohttp.ClientSession(**proxy_config) as session:
            async with session.get(api_url, headers=headers) as response:
                if response.status != 200:
                    error_text = await response.text()
                    # Censurar posibles tokens en la respuesta de error
                    safe_error = error_text.replace("Bearer ", "Bearer ***[CENSURADO]***")
                    for token_pattern in ["token", "authorization", "bearer"]:
                        if token_pattern in error_text.lower():
                            safe_error = "***[ERROR CENSURADO - CONTIENE TOKENS]***"
                            break
                    logger.error(f"Error obteniendo OAM: {response.status} - {safe_error}")
                    raise Exception(f"Error HTTP {response.status} al obtener OAM")
                
                content = await response.text()
        
        # Parsear el contenido YAML
        try:
            oam_data = yaml.safe_load(content)
            if not oam_data:
                raise Exception("Contenido OAM vacío o inválido")
        except yaml.YAMLError as e:
            logger.error(f"Error parseando YAML del OAM: {str(e)}")
            raise Exception(f"Error parseando YAML: {str(e)}")
        
        # Validar estructura básica del OAM
        if not isinstance(oam_data, dict):
            raise Exception("El OAM debe ser un objeto YAML válido")

        # Extraer información relevante del OAM
        processed_oam = {
            'apiVersion': oam_data.get('apiVersion', ''),
            'kind': oam_data.get('kind', ''),
            'metadata': oam_data.get('metadata', {}),
            'spec': oam_data.get('spec', {}),
            'raw_data': oam_data  # Mantener datos originales por compatibilidad
        }
        
        return processed_oam
        
    except Exception as e:
        logger.error(f"Error obteniendo OAM desde Git: {str(e)}")
        raise



def _clean_namespace(namespace: str) -> str:
    """
    Limpia el namespace removiendo sufijos comunes y normalizando el formato.
    
    Args:
        namespace: Namespace original
        
    Returns:
        str: Namespace limpio
    """
    if not namespace:
        return namespace
    
    # Remover sufijos comunes
    suffixes_to_remove = ['-pre', '-cert', '-pro', '-dev', '-test', '-prod']
    
    clean = namespace.lower().strip()
    
    for suffix in suffixes_to_remove:
        if clean.endswith(suffix):
            clean = clean[:-len(suffix)]
            break
    
    return clean


class DeploymentData:
    """
    Clase para almacenar y gestionar los datos del deployment y OAM.
    Migrada desde el archivo principal para mantener compatibilidad.
    """
    
    def __init__(self):
        self.deployment_yaml: Optional[Dict[str, Any]] = None
        self.oam_yaml: Optional[Dict[str, Any]] = None
        self.namespace: Optional[str] = None
        self.old_name: Optional[str] = None
        
    def set_deployment(self, deployment_yaml: Optional[Dict[str, Any]]):
        """Establece los datos del deployment."""
        self.deployment_yaml = deployment_yaml
        
    def set_oam(self, oam_yaml: Optional[Dict[str, Any]]):
        """Establece los datos del OAM."""
        self.oam_yaml = oam_yaml
        
    def get_deployment_value(self, path: str, default=None):
        """
        Obtiene un valor del deployment usando una ruta tipo 'spec.containers.0.image'.
        
        Args:
            path: Ruta al valor usando notación de punto
            default: Valor por defecto si no se encuentra
            
        Returns:
            Any: Valor encontrado o default
        """
        if not self.deployment_yaml:
            return default
            
        keys = path.split('.')
        value = self.deployment_yaml
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            elif isinstance(value, list) and key.isdigit():
                idx = int(key)
                if 0 <= idx < len(value):
                    value = value[idx]
                else:
                    return default
            else:
                return default
                
        return value
    
    def get_oam_value(self, path: str, default=None):
        """
        Obtiene un valor del OAM usando una ruta tipo 'spec.components.0.traits'.
        
        Args:
            path: Ruta al valor usando notación de punto
            default: Valor por defecto si no se encuentra
            
        Returns:
            Any: Valor encontrado o default
        """
        if not self.oam_yaml:
            return default
            
        keys = path.split('.')
        value = self.oam_yaml
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            elif isinstance(value, list) and key.isdigit():
                idx = int(key)
                if 0 <= idx < len(value):
                    value = value[idx]
                else:
                    return default
            else:
                return default
                
        return value
