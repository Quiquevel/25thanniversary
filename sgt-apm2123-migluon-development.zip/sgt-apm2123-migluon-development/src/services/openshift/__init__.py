"""
Módulo de procesamiento OpenShift.
Exporta las funciones principales para operaciones con OpenShift y OAM.
"""
from .processor import (
    get_deployment_from_openshift,
    get_oam_from_git,
    get_secret_from_openshift,
    get_openshift_client,
    DeploymentData
)

__all__ = [
    'get_deployment_from_openshift',
    'get_oam_from_git',
    'get_secret_from_openshift',
    'get_openshift_client',
    'DeploymentData'
]
