"""
Módulo para manejar todas las operaciones relacionadas con OpenShift.
"""
import logging
from typing import Dict, Optional, Tuple
import aiohttp
from ..common_utils import get_proxy_config

logger = logging.getLogger(__name__)

class OpenshiftClient:
    def __init__(self, session: aiohttp.ClientSession):
        self.session = session
        self.proxy_config = get_proxy_config()
        
    async def get_deployment(self, api_url: str, namespace: str, deployment_name: str, token: str) -> Optional[Dict]:
        """
        Obtiene un deployment específico de OpenShift.
        
        Args:
            api_url: URL del API de OpenShift
            namespace: Namespace del deployment
            deployment_name: Nombre del deployment
            token: Token de autenticación
            
        Returns:
            Optional[Dict]: Datos del deployment o None si hay error
        """
        try:
            headers = {"Authorization": f"Bearer {token}"}
            url = f"{api_url}/apis/apps/v1/namespaces/{namespace}/deployments/{deployment_name}"
            
            async with self.session.get(url, headers=headers, **self.proxy_config) as response:
                if response.status == 200:
                    return await response.json()
                return None
                
        except Exception as e:
            logger.error(f"Error al obtener deployment {deployment_name}: {str(e)}")
            return None
            
    def extract_cluster_config(self, oam_data: Dict) -> Tuple[str, str, str, str]:
        """
        Extrae la configuración del cluster desde el OAM.
        
        Args:
            oam_data: Datos del OAM
            
        Returns:
            Tuple[str, str, str, str]: (cluster, region, cluster_type, api_server)
        """
        try:
            # Valores por defecto
            cluster = ""
            region = ""
            cluster_type = ""
            api_server = ""
            
            # Extraer del formato raw_data si está disponible
            if "raw_data" in oam_data and "environments" in oam_data["raw_data"]:
                envs = oam_data["raw_data"]["environments"]
            elif "environments" in oam_data:
                envs = oam_data["environments"]
            else:
                return cluster, region, cluster_type, api_server
                
            # Buscar en los environments
            for env in envs:
                if "infrastructures" in env:
                    for infra in env["infrastructures"]:
                        if "properties" in infra:
                            props = infra["properties"]
                            cluster = props.get("cluster", cluster)
                            region = props.get("region", region)
                            cluster_type = props.get("type", cluster_type)
                            api_server = props.get("apiServer", api_server)
                            
                            if all([cluster, region, cluster_type, api_server]):
                                break
                    if all([cluster, region, cluster_type, api_server]):
                        break
                        
            return cluster, region, cluster_type, api_server
            
        except Exception as e:
            logger.error(f"Error al extraer configuración del cluster: {str(e)}")
            return "", "", "", ""
            
    def get_deployment_data(self, deployment_yaml: Dict, key_path: str) -> Optional[str]:
        """
        Obtiene un valor específico del deployment usando una ruta de claves.
        
        Args:
            deployment_yaml: YAML del deployment
            key_path: Ruta de claves separadas por puntos (ej: "spec.template.spec.containers.0.image")
            
        Returns:
            Optional[str]: Valor encontrado o None si no existe
        """
        try:
            current = deployment_yaml
            for key in key_path.split("."):
                if key.isdigit():
                    current = current[int(key)]
                else:
                    current = current.get(key)
                if current is None:
                    return None
            return current
        except Exception as e:
            logger.error(f"Error al obtener dato {key_path} del deployment: {str(e)}")
            return None