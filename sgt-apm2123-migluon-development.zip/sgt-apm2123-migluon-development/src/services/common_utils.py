"""
Módulo de funciones comunes reutilizables entre frontend y backend.
Contiene lógica compartida para evitar duplicación de código.

FUNCIONES PRINCIPALES:
- detect_microservice_type(): Detecta si un repositorio es FRONTEND, BACKEND o CONFIG_MAP
- normalize_git_url(): Normaliza URLs de GitHub
- extract_repo_info(): Extrae owner/repo de URLs
- validate_and_update_dockerfile_with_api_versions(): Validación Docker
"""
import aiohttp
import re
from typing import Dict, Any, Optional, Tuple, List
from shuttlelib.utils.logger import logger
MIGRATION_BACKUP_BRANCH = "feature/gluon-migration-config-from-pulse-import"
from .github_client import GitHubClient
from src.utils.proxy_config import get_proxy_config


def normalize_git_url(git_url: str) -> str:
    """
    Normaliza URLs de Git para manejar tanto URLs completas como nombres de repositorio.
    
    Casos manejados:
    1. https://github.com/santander-group-spain-gln/repo-name → Sin cambios
    2. https://github.com/santander-group-spain-gln/repo-name.git → Sin cambios
    3. repo-name → https://github.com/santander-group-spain-gln/repo-name
    4. repo-name.git → https://github.com/santander-group-spain-gln/repo-name.git
    
    Args:
        git_url: URL de Git completa o solo nombre del repositorio
    
    Returns:
        str: URL completa de GitHub
    """
    git_url = git_url.strip()
    
    # Si ya es una URL completa, devolver sin cambios
    if git_url.startswith("https://github.com/"):
        return git_url
    
    # Si solo es el nombre del repositorio, formar la URL completa
    base_org = "https://github.com/santander-group-spain-gln/"
    return f"{base_org}{git_url}"


def extract_repo_info(git_url: str) -> tuple[str, str]:
    """
    Extrae el owner y nombre del repositorio de una URL de Git.
    
    Args:
        git_url: URL de Git (ya normalizada)
    
    Returns:
        tuple[str, str]: (owner, repo) donde repo ya tiene .git removido si existía
    """
    # Normalizar la URL primero
    normalized_url = normalize_git_url(git_url)
    
    # Extraer owner y repo
    repo_parts = normalized_url.replace("https://github.com/", "").split("/")
    if len(repo_parts) < 2:
        raise ValueError(f"URL de Git inválida: {git_url}")
    
    owner = repo_parts[0]
    repo = repo_parts[1]
    
    # Limpiar extensión .git del nombre del repositorio si existe
    if repo.endswith('.git'):
        repo = repo[:-4]
    
    return owner, repo


def normalize_oam_url(oam_url: str) -> str:
    """
    Normaliza URLs OAM para que siempre apunten al archivo oam-application-definition.yml.
    
    Casos manejados:
    1. https://github.com/user/repo/blob/main/oam-application-definition.yml → Sin cambios
    2. https://github.com/user/repo/ → Agrega /blob/main/oam-application-definition.yml
    3. https://github.com/user/repo → Agrega /blob/main/oam-application-definition.yml
    4. https://github.com/user/repo/blob/main/ → Agrega oam-application-definition.yml
    5. https://github.com/user/repo/tree/main/config/file.yaml → Sin cambios (archivo específico)
    6. san-gascor-oam → https://github.com/santander-group-spain-gln/san-gascor-oam/blob/main/oam-application-definition.yml
    
    Args:
        oam_url: URL del repositorio OAM (con o sin archivo específico) o solo nombre del repositorio
    
    Returns:
        str: URL normalizada que apunta al archivo oam-application-definition.yml
    """
    oam_url = oam_url.strip()
    
    # Si ya contiene el archivo específico, devolver sin cambios
    if "oam-application-definition.yml" in oam_url:
        return oam_url
    
    # Si no es una URL completa (solo nombre del repositorio), formar la URL completa
    if not oam_url.startswith("https://github.com/"):
        base_org = "https://github.com/santander-group-spain-gln/"
        return f"{base_org}{oam_url}/blob/main/oam-application-definition.yml"
    
    # Si es una URL de GitHub, normalizar
    if "github.com" in oam_url:
        # Limpiar la URL base
        base_url = oam_url.rstrip('/')
        
        # Si la URL ya apunta a un archivo específico (contiene extensión), mantenerla
        last_part = base_url.split('/')[-1]
        if '.' in last_part and (last_part.endswith('.yml') or last_part.endswith('.yaml') or 
                               last_part.endswith('.json') or last_part.endswith('.txt')):
            return oam_url
        
        # Si ya tiene /blob/main (al final), solo agregar el archivo
        if base_url.endswith("/blob/main"):
            return f"{base_url}/oam-application-definition.yml"
        
        # Si no tiene /blob/main/, agregarlo junto con el archivo
        return f"{base_url}/blob/main/oam-application-definition.yml"
    
    # Si no es GitHub, devolver tal como está
    return oam_url


def get_ci_id_from_oam(oam_data: Dict[str, Any]) -> Tuple[Optional[str], bool, str]:
    """
    Extrae el ci_id del OAM usando la estructura correcta: environments[].infrastructures[].id
    
    Args:
        oam_data: Datos del OAM procesados
        
    Returns:
        Tuple[ci_id, found, error_msg]: ci_id extraído, si se encontró, mensaje de error
    """
    try:
        if not oam_data:
            return None, False, "Datos OAM vacíos o inválidos"
        
        # Extraer los datos del OAM (puede estar en raw_data o directamente en oam_data)
        oam_yaml = None
        if isinstance(oam_data, dict):
            if 'raw_data' in oam_data:
                oam_yaml = oam_data['raw_data']
            elif 'oam_data' in oam_data:
                oam_yaml = oam_data['oam_data']
            else:
                oam_yaml = oam_data
        
        if not oam_yaml or not isinstance(oam_yaml, dict):
            return None, False, "OAM YAML inválido o vacío"
        
        logger.info("Extrayendo CI ID desde environments[].infrastructures[].id")
        
        # Buscar en environments[].infrastructures[].id
        environments = oam_yaml.get('environments', [])
        
        if not environments:
            return None, False, "No se encontraron environments en el OAM"
        
        # Buscar ci_ids por entorno
        found_ci_ids = {}
        
        for env in environments:
            if not isinstance(env, dict):
                continue
                
            env_name = env.get('name', 'unknown')
            infrastructures = env.get('infrastructures', [])
            
            for infra in infrastructures:
                if not isinstance(infra, dict):
                    continue
                    
                ci_id = infra.get('id')
                if ci_id and isinstance(ci_id, str) and ci_id.strip():
                    # Filtrar solo infraestructuras de tipo KUBERNETES
                    # Buscar type en properties.type o directamente en type
                    infra_type = None
                    infra_properties = infra.get('properties', {})
                    if isinstance(infra_properties, dict):
                        infra_type = infra_properties.get('type')
                    
                    # Si no está en properties.type, buscar directamente en type
                    if not infra_type:
                        infra_type = infra.get('type')
                    
                    if infra_type == 'KUBERNETES':
                        found_ci_ids[env_name] = ci_id.strip()
                        logger.info(f"CI ID encontrado para entorno '{env_name}': {ci_id.strip()}")
                        break
        
        if found_ci_ids:
            # Priorizar entornos en este orden: dev, pre, cert, pro
            priority_envs = ['dev', 'cert', 'pre', 'pro']
            
            for env_name in priority_envs:
                if env_name in found_ci_ids:
                    ci_id = found_ci_ids[env_name]
                    logger.info(f"Usando CI ID del entorno '{env_name}': {ci_id}")
                    return ci_id, True, ""
            
            # Si no encuentra ninguno prioritario, usar el primero disponible
            first_env = list(found_ci_ids.keys())[0]
            ci_id = found_ci_ids[first_env]
            logger.info(f"Usando CI ID del primer entorno disponible '{first_env}': {ci_id}")
            return ci_id, True, ""
        
        # Si no se encuentra, generar error detallado
        env_names = [env.get('name', 'unknown') for env in environments if isinstance(env, dict)]
        error_msg = f"No se encontraron ci_ids en infrastructures de tipo KUBERNETES. Entornos revisados: {env_names}"
        logger.warning(error_msg)
        return None, False, error_msg
        
    except Exception as e:
        error_msg = f"Error extrayendo ci_id del OAM: {str(e)}"
        logger.error(error_msg)
        return None, False, error_msg


def get_ci_id_for_environment(oam_data: Dict[str, Any], target_env: str) -> Optional[str]:
    """
    Extrae el PRIMER ci_id específico para un entorno dado del OAM.
    Para múltiples CI_IDs (como PRO dual cluster), usar get_all_ci_ids_for_environment().
    
    Args:
        oam_data: Datos del OAM procesados
        target_env: Nombre del entorno específico (dev, pre, cert, pro, etc.)
        
    Returns:
        Optional[str]: ci_id para el entorno específico o None si no se encuentra
    """
    try:
        if not oam_data:
            logger.warning("OAM data está vacío")
            return None
        
        # Extraer los datos del OAM
        oam_yaml = None
        if isinstance(oam_data, dict):
            if 'raw_data' in oam_data:
                oam_yaml = oam_data['raw_data']
            elif 'oam_data' in oam_data:
                oam_yaml = oam_data['oam_data']
            else:
                oam_yaml = oam_data
        
        if not oam_yaml or not isinstance(oam_yaml, dict):
            logger.warning("OAM YAML inválido o vacío")
            return None
        
        # Buscar en environments por el nombre específico
        environments = oam_yaml.get('environments', [])
        
        for env in environments:
            if not isinstance(env, dict):
                continue
                
            env_name = env.get('name', '')
            if env_name == target_env:
                infrastructures = env.get('infrastructures', [])
                
                for infra in infrastructures:
                    if not isinstance(infra, dict):
                        continue
                        
                    ci_id = infra.get('id')
                    if ci_id and isinstance(ci_id, str) and ci_id.strip():
                        # Verificar que sea infraestructura KUBERNETES
                        # Buscar type en properties.type o directamente en type
                        infra_type = None
                        infra_properties = infra.get('properties', {})
                        if isinstance(infra_properties, dict):
                            infra_type = infra_properties.get('type')
                        
                        # Si no está en properties.type, buscar directamente en type
                        if not infra_type:
                            infra_type = infra.get('type')
                        
                        if infra_type == 'KUBERNETES':
                            logger.info(f"CI ID encontrado para entorno específico '{target_env}': {ci_id.strip()}")
                            return ci_id.strip()
        
        logger.warning(f"No se encontró ci_id para el entorno específico '{target_env}'")
        return None
        
    except Exception as e:
        logger.error(f"Error extrayendo ci_id para entorno '{target_env}': {str(e)}")
        return None


def get_all_ci_ids_for_environment(oam_data: Dict[str, Any], target_env: str) -> List[str]:
    """
    Extrae TODOS los ci_ids específicos para un entorno dado del OAM.
    Útil para entornos con dual cluster como PRO (CI0000000347 + CI0000000348).
    
    Args:
        oam_data: Datos del OAM procesados
        target_env: Nombre del entorno específico (dev, pre, cert, pro, etc.)
        
    Returns:
        List[str]: Lista de todos los ci_ids para el entorno, o lista vacía si no se encuentra
    """
    try:
        if not oam_data:
            logger.warning("OAM data está vacío")
            return []
        
        # Extraer los datos del OAM
        oam_yaml = None
        if isinstance(oam_data, dict):
            if 'raw_data' in oam_data:
                oam_yaml = oam_data['raw_data']
            elif 'oam_data' in oam_data:
                oam_yaml = oam_data['oam_data']
            else:
                oam_yaml = oam_data
        
        if not oam_yaml or not isinstance(oam_yaml, dict):
            logger.warning("OAM YAML inválido o vacío")
            return []
        
        # Buscar en environments por el nombre específico
        environments = oam_yaml.get('environments', [])
        ci_ids = []
        
        for env in environments:
            if not isinstance(env, dict):
                continue
                
            env_name = env.get('name', '')
            if env_name == target_env:
                infrastructures = env.get('infrastructures', [])
                
                for infra in infrastructures:
                    if not isinstance(infra, dict):
                        continue
                        
                    ci_id = infra.get('id')
                    if ci_id and isinstance(ci_id, str) and ci_id.strip():
                        # Verificar que sea infraestructura KUBERNETES
                        infra_type = None
                        infra_properties = infra.get('properties', {})
                        if isinstance(infra_properties, dict):
                            infra_type = infra_properties.get('type')
                        
                        # Si no está en properties.type, buscar directamente en type
                        if not infra_type:
                            infra_type = infra.get('type')
                        
                        if infra_type == 'KUBERNETES':
                            ci_ids.append(ci_id.strip())
                            logger.info(f"CI ID encontrado para entorno '{target_env}': {ci_id.strip()}")
        
        if ci_ids:
            logger.info(f"Total CI IDs encontrados para entorno '{target_env}': {len(ci_ids)} ({', '.join(ci_ids)})")
        else:
            logger.warning(f"No se encontraron ci_ids para el entorno específico '{target_env}'")
        
        return ci_ids
        
    except Exception as e:
        logger.error(f"Error extrayendo ci_ids para entorno '{target_env}': {str(e)}")
        return []


def get_environment_mapping(oam_data: Dict[str, Any]) -> Dict[str, str]:
    """
    Detecta automáticamente el mapeo de entornos basándose en los ci_ids del OAM.
    
    Args:
        oam_data: Datos del OAM procesados
        
    Returns:
        Dict[str, str]: Mapeo de entornos lógicos a entornos del OAM
    """
    try:
        if not oam_data:
            # Mapeo por defecto si no hay OAM
            return {'dev': 'cert', 'pre': 'pre', 'pro': 'pro'}
        
        # Extraer los datos del OAM
        oam_yaml = None
        if isinstance(oam_data, dict):
            if 'raw_data' in oam_data:
                oam_yaml = oam_data['raw_data']
            elif 'oam_data' in oam_data:
                oam_yaml = oam_data['oam_data']
            else:
                oam_yaml = oam_data
        
        if not oam_yaml or not isinstance(oam_yaml, dict):
            return {'dev': 'cert', 'pre': 'pre', 'pro': 'pro'}
        
        # Buscar entornos y sus ci_ids
        environments = oam_yaml.get('environments', [])
        env_ci_mapping = {}
        
        for env in environments:
            if not isinstance(env, dict):
                continue
                
            env_name = env.get('name', '')
            infrastructures = env.get('infrastructures', [])
            
            for infra in infrastructures:
                if not isinstance(infra, dict):
                    continue
                    
                ci_id = infra.get('id', '')
                if ci_id and isinstance(ci_id, str):
                    infra_properties = infra.get('properties', {})
                    if isinstance(infra_properties, dict):
                        infra_type = infra_properties.get('type')
                        if infra_type == 'KUBERNETES':
                            env_ci_mapping[env_name] = ci_id
                            break
        
        # Detectar mapeo basándose en patrones de ci_id
        mapping = {}
        
        # Buscar entorno que contenga 'dev' en el ci_id para mapear a 'dev'
        for env_name, ci_id in env_ci_mapping.items():
            if 'dev' in ci_id.lower():
                mapping['dev'] = env_name
            elif 'pre' in ci_id.lower():
                mapping['pre'] = env_name  
            elif 'pro' in ci_id.lower():
                mapping['pro'] = env_name
        
        # Mapeo por defecto para entornos no detectados
        if 'dev' not in mapping:
            mapping['dev'] = 'cert'  # cert es el nombre típico para dev en OAM
        if 'pre' not in mapping:
            mapping['pre'] = 'pre'
        if 'pro' not in mapping:
            mapping['pro'] = 'pro'
        
        logger.info(f"Mapeo de entornos detectado: {mapping}")
        return mapping
        
    except Exception as e:
        logger.error(f"Error detectando mapeo de entornos: {str(e)}")
        return {'dev': 'cert', 'pre': 'pre', 'pro': 'pro'}





def extract_docker_image_components(docker_line: str) -> Tuple[Optional[str], Optional[str], Optional[str], Optional[str]]:
    """
    Extrae componentes de una línea FROM de Docker preservando registry y sufijos.
    
    Args:
        docker_line: Línea FROM completa del Dockerfile
        
    Returns:
        Tuple[registry, image_name, version, suffixes]: Componentes extraídos
    """
    try:
        # Limpiar la línea y extraer solo la imagen
        line = docker_line.strip()
        if not line.startswith('FROM'):
            return None, None, None, None
        
        # Separar FROM imagen [AS alias] [otros parámetros]
        parts = line.split(' ')
        if len(parts) < 2:
            return None, None, None, None
        
        full_image = parts[1]
        suffixes = ' '.join(parts[2:]) if len(parts) > 2 else None
        
        # Separar registry, imagen y versión
        # Formato: registry.global.ccc.srvb.bo.paas.cloudcenter.corp/imagen:version
        if '/' in full_image:
            # Tiene registry
            registry_part, image_part = full_image.rsplit('/', 1)
            registry = registry_part
        else:
            # Sin registry explícito
            registry = None
            image_part = full_image
        
        # Separar imagen y versión
        if ':' in image_part:
            image_name, version = image_part.rsplit(':', 1)
        else:
            image_name = image_part
            version = 'latest'
        
        logger.debug(f"Componentes extraídos - Registry: {registry}, Image: {image_name}, Version: {version}, Suffixes: {suffixes}")
        return registry, image_name, version, suffixes
        
    except Exception as e:
        logger.error(f"Error extrayendo componentes de imagen Docker: {str(e)}")
        return None, None, None, None


def build_docker_from_line(registry: Optional[str], image_name: str, new_version: str, suffixes: Optional[str] = None) -> str:
    """
    Construye una nueva línea FROM preservando registry y sufijos.
    
    Args:
        registry: Registry original (puede ser None)
        image_name: Nombre de la imagen base
        new_version: Nueva versión a usar
        suffixes: Sufijos adicionales (AS alias, etc.)
        
    Returns:
        str: Nueva línea FROM completa
    """
    try:
        # Construir la imagen completa
        if registry:
            full_image = f"{registry}/{image_name}:{new_version}"
        else:
            full_image = f"{image_name}:{new_version}"
        
        # Construir la línea completa
        if suffixes and suffixes.strip():
            new_line = f"FROM {full_image} {suffixes}"
        else:
            new_line = f"FROM {full_image}"
        
        logger.debug(f"Nueva línea FROM construida: {new_line}")
        return new_line
        
    except Exception as e:
        logger.error(f"Error construyendo línea FROM: {str(e)}")
        return f"FROM {image_name}:{new_version}"


async def update_dockerfile_image_version(
    github_client: GitHubClient,
    owner: str,
    repo: str,
    new_version: str,
    image_pattern: str = None
) -> bool:
    """
    Actualiza la versión de imagen en Dockerfile preservando registry y sufijos.
    
    Args:
        github_client: Cliente GitHub inicializado
        owner: Propietario del repositorio
        repo: Nombre del repositorio
        new_version: Nueva versión de imagen a usar
        image_pattern: Patrón de imagen a buscar (opcional)
        
    Returns:
        bool: True si se actualizó correctamente
    """
    try:
        # Obtener contenido del Dockerfile
        dockerfile_result = await github_client.get_file_content(owner, repo, "Dockerfile")
        if not dockerfile_result:
            logger.warning("No se encontró Dockerfile")
            return False
        
        dockerfile_content, dockerfile_sha = dockerfile_result
        lines = dockerfile_content.split('\n')
        modified = False
        
        for i, line in enumerate(lines):
            if line.strip().startswith('FROM'):
                # Si hay patrón específico, verificar que coincida
                if image_pattern and image_pattern.lower() not in line.lower():
                    continue
                
                # Extraer componentes de la imagen actual
                registry, image_name, current_version, suffixes = extract_docker_image_components(line)
                
                if image_name and current_version != new_version:
                    # Construir nueva línea preservando registry y sufijos
                    new_line = build_docker_from_line(registry, image_name, new_version, suffixes)
                    
                    logger.info(f"Actualizando Dockerfile: {line.strip()} -> {new_line}")
                    lines[i] = new_line
                    modified = True
                elif image_name:
                    logger.info(f"Dockerfile ya tiene la versión correcta: {current_version}")
                
                # Para la mayoría de casos, solo modificar el primer FROM
                if not image_pattern:
                    break
        
        if modified:
            new_content = '\n'.join(lines)
            
            result = await github_client.update_file(
                owner=owner,
                repo=repo,
                file_path="Dockerfile",
                content=new_content,
                sha=dockerfile_sha,
                commit_message=f"Update image version to {new_version} [ci skip]"
            )
            
            if result["status"] == "success":
                logger.info("Dockerfile actualizado exitosamente")
                return True
            else:
                logger.error(f"Error actualizando Dockerfile: {result.get('error', 'Unknown error')}")
                return False
        
        return True  # No se necesitó modificación
        
    except Exception as e:
        logger.error(f"Error actualizando versión de imagen en Dockerfile: {str(e)}")
        return False


# Función modify_cd_yml_file eliminada - usar modify_values_file_optimized directamente





def format_backup_result(step_name: str, success: bool, already_exists: bool = False, details: str = "") -> str:
    """
    Formatea el resultado de un backup con manejo especial para ya existentes.
    
    Args:
        step_name: Nombre del paso de backup
        success: Si fue exitoso
        already_exists: Si el backup ya existía
        details: Detalles adicionales
        
    Returns:
        str: Línea formateada
    """
    if success and already_exists:
        return f"✅ {step_name}: OK - Ya existente backup"
    elif success:
        return f"✅ {step_name}: OK - {details}" if details else f"✅ {step_name}: OK"
    else:
        return f"❌ {step_name}: KO - {details}" if details else f"❌ {step_name}: KO"


def format_values_result(step_name: str, success: bool, no_changes_needed: bool = False, details: str = "") -> str:
    """
    Formatea el resultado de modificación de values con manejo especial para sin cambios.
    
    Args:
        step_name: Nombre del paso de values
        success: Si fue exitoso
        no_changes_needed: Si no se necesitaron cambios
        details: Detalles adicionales
        
    Returns:
        str: Línea formateada
    """
    if success and no_changes_needed:
        # Usar warning cuando no hay cambios necesarios (archivo ya correcto)
        return f"⚠️ {step_name}: OK - Sin cambios necesarios"
    elif success:
        return f"✅ {step_name}: OK - {details}" if details else f"✅ {step_name}: OK"
    else:
        return f"❌ {step_name}: KO - {details}" if details else f"❌ {step_name}: KO"


def format_general_result(step_name: str, result_type: str, details: str = "") -> str:
    """
    Formatea cualquier resultado de procesamiento de archivos con iconos consistentes.
    
    Args:
        step_name: Nombre del paso (ej: "MODIFICAR DOCKERFILE")
        result_type: "MODIFIED", "NO_CHANGES", "NOT_FOUND", "ERROR", "VERIFIED"
        details: Detalles adicionales
        
    Returns:
        str: Línea formateada con icono apropiado
    """
    if result_type == "MODIFIED":
        return f"✅ {step_name}: OK - Procesado con cambios"
    elif result_type == "NO_CHANGES":
        return f"⚠️ {step_name}: OK - Sin cambios necesarios"
    elif result_type == "NOT_FOUND":
        return f"ℹ️ {step_name}: OK - Archivo no encontrado (no es necesario)"
    elif result_type == "VERIFIED":
        return f"ℹ️ {step_name}: OK - {details}" if details else f"ℹ️ {step_name}: OK - Verificado correctamente"
    elif result_type == "ERROR":
        return f"❌ {step_name}: KO - {details}" if details else f"❌ {step_name}: KO - Error en procesamiento"
    else:
        return f"❓ {step_name}: Estado desconocido - {result_type}"


def format_cd_yml_result(step_name: str, success: bool, ci_id_found: bool = True, oam_error: str = "") -> str:
    """
    Formatea el resultado de modificación de cd.yml con manejo especial para errores de OAM.
    
    Args:
        step_name: Nombre del paso de cd.yml
        success: Si fue exitoso
        ci_id_found: Si se encontró ci_id en el OAM
        oam_error: Error específico del OAM si aplica
        
    Returns:
        str: Línea formateada
    """
    if not ci_id_found:
        error_msg = oam_error if oam_error else "No se encontró ci_id en archivo OAM"
        return f"❌ {step_name}: KO - {error_msg}"
    elif success:
        return f"✅ {step_name}: OK"
    else:
        error_msg = oam_error if oam_error else "Error desconocido"
        return f"❌ {step_name}: KO - {error_msg}"


def generate_migration_summary(
    microservice_type: str,
    old_name: str,
    namespace: str = None,
    steps_completed: int = 0,
    total_steps: int = 0
) -> List[str]:
    """
    Genera el encabezado estándar para respuestas de migración.
    
    Args:
        microservice_type: 'frontend' o 'backend'
        old_name: Nombre original del microservicio
        namespace: Namespace destino (opcional)
        steps_completed: Pasos completados
        total_steps: Total de pasos
        
    Returns:
        List[str]: Líneas de encabezado
    """
    icon = "🎨" if microservice_type.lower() == "frontend" else "⚙️"
    type_name = "FRONTEND" if microservice_type.lower() == "frontend" else "BACKEND"
    
    header = [
        f"{icon} MIGRACIÓN {type_name}: {old_name}",
        ""
    ]
    
    if namespace:
        header.append(f"📍 Namespace destino: {namespace}")
    
    if total_steps > 0:
        progress = f"📊 Progreso: {steps_completed}/{total_steps} pasos completados"
        header.append(progress)
    
    header.append("")
    
    return header


def convert_github_url_to_api(github_url: str) -> str:
    """
    Convierte URL de GitHub web a URL de API.
    Función consolidada que maneja diferentes formatos de URL.
    
    Args:
        github_url: URL de GitHub (web o API)
    
    Returns:
        str: URL de API de GitHub
    """
    if not github_url or "api.github.com" in github_url:
        # Ya es una URL de API o URL vacía
        return github_url
    
    if "github.com" in github_url:
        if "/blob/" in github_url:
            # URL de archivo específico: https://github.com/owner/repo/blob/branch/path
            parts = github_url.split('/')
            if len(parts) >= 7:
                owner = parts[3]
                repo = parts[4]
                branch = parts[6]
                path = '/'.join(parts[7:]) if len(parts) > 7 else ""
                
                if path:
                    return f"https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={branch}"
                else:
                    return f"https://api.github.com/repos/{owner}/{repo}"
        else:
            # URL de repositorio: https://github.com/owner/repo
            parts = github_url.rstrip('/').split('/')
            if len(parts) >= 5:
                owner = parts[3]
                repo = parts[4]
                return f"https://api.github.com/repos/{owner}/{repo}"
    
    return github_url


async def validate_and_update_dockerfile_with_api_versions(
    github_client: GitHubClient,
    owner: str,
    repo: str,
    service_type: str = "backend"
) -> dict:
    """
    Consulta la API de versiones de Santander y actualiza el Dockerfile si hay versiones más nuevas.
    Funciona tanto para BACK (Java) como FRONT (nginx).
    
    Args:
        github_client: Cliente GitHub inicializado
        owner: Propietario del repositorio
        repo: Nombre del repositorio
        service_type: "backend" para Java, "frontend" para nginx
        
    Returns:
        dict: Resultado con información de la validación y actualización
    """
    import aiohttp
    import json
    
    result = {
        'success': False,
        'updated': False,
        'current_version': None,
        'latest_version': None,
        'image_name': None,
        'error': None,
        'details': []
    }
    
    try:
        logger.info(f"🔍 Validando versiones de imagen para {service_type} en {owner}/{repo}")
        
        # Obtener contenido del Dockerfile (de la rama feature/gluon-migration-config-from-pulse-import)
        dockerfile_result = await github_client.get_file_content(owner, repo, "Dockerfile", "feature/gluon-migration-config-from-pulse-import")
        if not dockerfile_result:
            result['error'] = "No se encontró Dockerfile en rama feature/gluon-migration-config-from-pulse-import"
            return result
        
        dockerfile_content, dockerfile_sha = dockerfile_result
        
        # Extraer TODAS las líneas FROM del Dockerfile (puede haber múltiples)
        from_lines = []
        lines = dockerfile_content.split('\n')
        for i, line in enumerate(lines):
            if line.strip().startswith('FROM') and not line.strip().startswith('FROM scratch'):
                from_lines.append((i, line.strip()))
        
        if not from_lines:
            result['error'] = "No se encontraron líneas FROM en Dockerfile"
            return result
        
        logger.info(f"🔍 Encontradas {len(from_lines)} líneas FROM en Dockerfile")
        
        # Extraer componentes de la primera imagen para obtener información base
        first_from_line = from_lines[0][1]
        registry, image_name, current_version, suffixes = extract_docker_image_components(first_from_line)
        
        logger.info(f"🔍 Primera línea FROM encontrada: {first_from_line}")
        logger.info(f"🔍 Componentes extraídos - Registry: {registry}, Image: {image_name}, Version: {current_version}, Suffixes: {suffixes}")
        
        if not image_name or not current_version:
            result['error'] = f"No se pudo extraer imagen/versión de: {first_from_line}"
            return result
        
        result['current_version'] = current_version
        result['image_name'] = image_name
        
        logger.info(f"📦 Imagen actual: {image_name}:{current_version}")
        
        # Consultar API de versiones de Santander
        api_url = "https://image-version.sgtech.gs.corp/api/images"
        
        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(api_url) as response:
                    if response.status != 200:
                        result['error'] = f"Error consultando API: HTTP {response.status}"
                        return result
                    
                    api_data = await response.json()
                    
                    # La API puede devolver directamente lista o dict con 'value'
                    if isinstance(api_data, dict) and 'value' in api_data:
                        images_list = api_data['value']
                    elif isinstance(api_data, list):
                        images_list = api_data
                    else:
                        result['error'] = f"Formato inesperado de API: {type(api_data)}"
                        return result
                    
                    # Buscar la imagen específica en la API
                    target_image = None
                    logger.info(f"🔍 Buscando imagen '{image_name}' en {len(images_list)} imágenes de la API")
                    
                    # Log de todas las imágenes disponibles para debug
                    available_images = [img.get('productName') for img in images_list if img.get('productName')]
                    logger.info(f"🔍 Imágenes disponibles en API: {', '.join(available_images[:10])}{'...' if len(available_images) > 10 else ''}")
                    
                    for img in images_list:
                        if img.get('productName') == image_name:
                            target_image = img
                            break
                    
                    if not target_image:
                        result['error'] = f"Imagen {image_name} no encontrada en API"
                        logger.warning(f"⚠️ Imagen {image_name} no encontrada en API de versiones")
                        logger.warning(f"⚠️ Imágenes Java disponibles: {[img for img in available_images if 'javase' in img]}")
                        return result
                    
                    # Extraer versión más reciente de la API
                    latest_release = target_image.get('lastRelease', '')
                    if ':' in latest_release:
                        latest_version = latest_release.split(':')[-1]
                    else:
                        result['error'] = f"Formato inválido en lastRelease: {latest_release}"
                        return result
                    
                    result['latest_version'] = latest_version
                    update_time = target_image.get('update_time', 'N/A')
                    
                    logger.info(f"🔄 Versión en API: {latest_version} (actualizada: {update_time})")
                    
                    # Comparar versiones
                    if current_version == latest_version:
                        logger.info(f"✅ Dockerfile ya tiene la versión más reciente: {current_version}")
                        result['success'] = True
                        result['details'].append(f"Versión actual ({current_version}) es la más reciente")
                        return result
                    
                    # Hay una nueva versión disponible - actualizar
                    logger.info(f"🆕 Nueva versión disponible: {current_version} -> {latest_version}")
                    
                    # Actualizar TODAS las líneas FROM que usen la misma imagen base
                    lines = dockerfile_content.split('\n')
                    modified = False
                    updates_made = []
                    
                    for line_index, original_from_line in from_lines:
                        # Extraer componentes de cada línea FROM
                        line_registry, line_image_name, line_current_version, line_suffixes = extract_docker_image_components(original_from_line)
                        
                        # Solo actualizar si es la misma imagen que la de la API
                        if line_image_name == image_name:
                            # Construir nueva línea FROM para esta línea específica
                            new_from_line = build_docker_from_line(line_registry, line_image_name, latest_version, line_suffixes)
                            
                            # Actualizar la línea
                            lines[line_index] = new_from_line
                            modified = True
                            updates_made.append(f"{original_from_line} -> {new_from_line}")
                            logger.info(f"📝 Actualizando línea {line_index + 1}: {original_from_line} -> {new_from_line}")
                    
                    if updates_made:
                        logger.info(f"🔄 Total de líneas FROM actualizadas: {len(updates_made)}")
                        result['details'].extend([f"Actualizada: {update}" for update in updates_made])
                    
                    if modified:
                        new_dockerfile_content = '\n'.join(lines)
                        
                        # Actualizar archivo en GitHub
                        commit_message = f"🔄 Actualizar imagen {image_name} de {current_version} a {latest_version} [ci skip]"
                        
                        update_result = await github_client.update_file(
                            owner=owner,
                            repo=repo,
                            file_path="Dockerfile",
                            content=new_dockerfile_content,
                            sha=dockerfile_sha,
                            commit_message=commit_message,
                            branch="feature/gluon-migration-config-from-pulse-import"
                        )
                        
                        if update_result.get('status') == 'success':
                            logger.info(f"✅ Dockerfile actualizado exitosamente")
                            result['success'] = True
                            result['updated'] = True
                            result['details'].append(f"Actualizado de {current_version} a {latest_version}")
                            result['details'].append(f"Commit: {commit_message}")
                        else:
                            result['error'] = f"Error actualizando Dockerfile en GitHub: {update_result.get('message', 'Error desconocido')}"
                    else:
                        result['error'] = "Error modificando contenido del Dockerfile"
                    
            except aiohttp.ClientError as e:
                result['error'] = f"Error de conexión con API: {str(e)}"
            except json.JSONDecodeError as e:
                result['error'] = f"Error parseando respuesta de API: {str(e)}"
                
    except Exception as e:
        result['error'] = f"Error general: {str(e)}"
        logger.error(f"❌ Error validando versiones: {str(e)}")
    
    return result


async def detect_microservice_type(session: aiohttp.ClientSession, owner: str, repo: str, git_token: str) -> str:
    """
    Detecta el tipo de microservicio analizando su estructura de archivos.
    
    CRITERIOS DE DETECCIÓN:
    - FRONTEND: Tiene carpeta /nginx O archivo package.json
    - BACKEND: Tiene pom.xml O carpeta .mvn
    - CONFIG_MAP: No tiene ninguno de los anteriores
    
    Args:
        session: Sesión HTTP aiohttp
        owner: Propietario del repositorio
        repo: Nombre del repositorio  
        git_token: Token de GitHub
        
    Returns:
        str: "FRONTEND", "BACKEND", o "CONFIG_MAP"
    """
    try:
        headers = {
            'Authorization': f'token {git_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # Obtener contenido del directorio raíz
        url = f"https://api.github.com/repos/{owner}/{repo}/contents"
        logger.info(f"🔍 Analizando tipo de microservicio: {owner}/{repo}")
        logger.info(f"📍 URL API: {url}")
        
        async with session.get(url, headers=headers) as response:
            logger.info(f"📊 Response status: {response.status}")
            
            if response.status == 404:
                logger.error(f"❌ Repositorio {owner}/{repo} no encontrado (404)")
                logger.error("⚠️ Esto podría indicar problemas de permisos o que el repositorio no existe")
                # Intentar detección por nombre del repositorio
                if "back" in repo.lower() or "backend" in repo.lower():
                    logger.info(f"🎯 Detectando como BACKEND basado en nombre del repositorio: {repo}")
                    return "BACKEND"
                elif "front" in repo.lower() or "frontend" in repo.lower():
                    logger.info(f"🎯 Detectando como FRONTEND basado en nombre del repositorio: {repo}")
                    return "FRONTEND"
                return "CONFIG_MAP"  # Por defecto si no podemos acceder
            elif response.status == 401:
                logger.error(f"❌ Token no autorizado para {owner}/{repo} (401)")
                logger.error("⚠️ Verifica que el token tiene permisos de 'repo'")
                # Intentar detección por nombre del repositorio
                if "back" in repo.lower() or "backend" in repo.lower():
                    logger.info(f"🎯 Detectando como BACKEND basado en nombre del repositorio: {repo}")
                    return "BACKEND"
                elif "front" in repo.lower() or "frontend" in repo.lower():
                    logger.info(f"🎯 Detectando como FRONTEND basado en nombre del repositorio: {repo}")
                    return "FRONTEND"
                return "CONFIG_MAP"
            elif response.status != 200:
                logger.warning(f"⚠️ Error {response.status} obteniendo contenido del repo {owner}/{repo}")
                error_text = await response.text()
                logger.warning(f"📄 Detalle del error: {error_text}")
                # Intentar detección por nombre del repositorio
                if "back" in repo.lower() or "backend" in repo.lower():
                    logger.info(f"🎯 Detectando como BACKEND basado en nombre del repositorio: {repo}")
                    return "BACKEND"
                elif "front" in repo.lower() or "frontend" in repo.lower():
                    logger.info(f"🎯 Detectando como FRONTEND basado en nombre del repositorio: {repo}")
                    return "FRONTEND"
                return "CONFIG_MAP"
            
            contents = await response.json()
            logger.info(f"✅ Repositorio accesible - {len(contents)} elementos encontrados")
            
        # Buscar indicadores de tipo
        files = []
        folders = []
        
        for item in contents:
            if item['type'] == 'file':
                files.append(item['name'])
            elif item['type'] == 'dir':
                folders.append(item['name'])
        
        logger.info(f"📁 Carpetas encontradas: {folders}")
        logger.info(f"📄 Archivos encontrados: {files}")
        
        # Detectar FRONTEND
        is_frontend = (
            'nginx' in folders or 
            'package.json' in files
        )
        
        if is_frontend:
            logger.info(f"✅ Detectado microservicio FRONTEND en {owner}/{repo}")
            if 'nginx' in folders:
                logger.info(f"   └─ Indicador: carpeta /nginx encontrada")
            if 'package.json' in files:
                logger.info(f"   └─ Indicador: archivo package.json encontrado")
            return "FRONTEND"
        
        # Detectar BACKEND
        is_backend = (
            'pom.xml' in files or 
            '.mvn' in folders
        )
        
        if is_backend:
            logger.info(f"✅ Detectado microservicio BACKEND en {owner}/{repo}")
            if 'pom.xml' in files:
                logger.info(f"   └─ Indicador: archivo pom.xml encontrado")
            if '.mvn' in folders:
                logger.info(f"   └─ Indicador: carpeta .mvn encontrada")
            return "BACKEND"
        
        # Por defecto es CONFIG_MAP
        logger.info(f"⚠️ Detectado CONFIG_MAP en {owner}/{repo} por eliminación")
        logger.info(f"   └─ No se encontraron indicadores de FRONTEND ni BACKEND")
        logger.info(f"   └─ Si esto es incorrecto, verifica permisos del token")
        return "CONFIG_MAP"
        
    except Exception as e:
        logger.error(f"💥 Error detectando tipo de microservicio para {owner}/{repo}: {str(e)}")
        # Para repositorios que claramente son Backend por nombre, intentar detección por naming
        if "back" in repo.lower() or "backend" in repo.lower():
            logger.info(f"🎯 Detectando como BACKEND basado en nombre del repositorio: {repo}")
            return "BACKEND"
        return "CONFIG_MAP"  # Por defecto en caso de error


def fix_encoding_issues(text: str) -> str:
    """
    Corrige problemas de encoding de caracteres especiales y emojis.
    
    Args:
        text: Texto con posibles problemas de encoding
        
    Returns:
        str: Texto con encoding corregido
    """
    # Lista de reemplazos de encoding (caracteres mal codificados -> correctos)
    fixes = [
        # Emojis comunes
        ('âœ…', '✅'),     # Check mark
        ('âŒ', '❌'),      # Cross mark  
        ('âš ï¸', '⚠️'),   # Warning sign
        ('ðŸ"', '🔍'),     # Magnifying glass
        ('ðŸ†"', '🆔'),    # ID button
        ('ðŸ"', '📁'),     # File folder
        ('ðŸŽ¯', '🎯'),     # Direct hit
        ('ðŸ"‹', '📋'),     # Clipboard
        ('ðŸš€', '🚀'),     # Rocket
        ('ðŸ"§', '🔧'),     # Wrench
        ('ðŸ—º', '🗺️'),    # World map
        ('ðŸŒ', '🌐'),     # Globe
        ('ðŸ"Š', '📊'),     # Bar chart
        ('ðŸ"', '📝'),     # Memo
        ('ðŸ"', '🏁'),     # Checkered flag
        ('ðŸ"¦', '📦'),     # Package
        
        # Caracteres especiales
        ('â"œâ"€', '├─'),    # Tree branch
        ('â""â"€', '└─'),    # Tree end branch
        ('Ã³', 'ó'),       # o con tilde
        ('Ã©', 'é'),       # e con tilde
        ('Ã­', 'í'),       # i con tilde
        ('Ã¡', 'á'),       # a con tilde
        ('Ã±', 'ñ'),       # eñe
        ('Ã"', 'Ó'),       # O con tilde mayúscula
        ('Ã‰', 'É'),       # E con tilde mayúscula
        ('MÃšLTIPLES', 'MÚLTIPLES'),
        ('genÃ©rico', 'genérico'),
        ('ObtenciÃ³n', 'Obtención'),
        ('ExtracciÃ³n', 'Extracción'),
        ('DetecciÃ³n', 'Detección'),
        ('ModificaciÃ³n', 'Modificación'),
        ('ValidaciÃ³n', 'Validación'),
        ('extraÃ­do', 'extraído'),
        ('FALLÃ"', 'FALLÓ'),
        ('segÃºn', 'según'),
        ('funciÃ³n', 'función'),
        ('EDICIÃ"N', 'EDICIÓN'),
        ('devolviÃ³', 'devolvió')
    ]
    
    # Aplicar todas las correcciones
    fixed_text = text
    for wrong, correct in fixes:
        fixed_text = fixed_text.replace(wrong, correct)
    
    return fixed_text


async def create_deployment_backup(github_client: GitHubClient, repo_info: dict, raw_deployment: dict, old_name: str = None) -> bool:
    """
    Crea un backup completo del deployment YAML original de OpenShift.
    
    Esta función es común para backends y frontends y crea una copia exacta
    del deployment tal como se obtiene de OpenShift en formato raw.
    
    Args:
        github_client: Cliente de GitHub para operaciones de archivos
        repo_info: Información del repositorio (owner, repo, branch)
        raw_deployment: Deployment completo en formato raw de OpenShift
        old_name: Nombre del deployment original (para el nombre del archivo)
    
    Returns:
        bool: True si el backup se creó exitosamente, False en caso contrario
    """
    try:
        import yaml
        from src.services.respuestas import ResponseFormatter as rf
        
        logger.info("📦 Creando backup completo del deployment YAML...")
        
        # Crear el contenido del backup usando el deployment raw completo
        backup_content = yaml.dump(raw_deployment, default_flow_style=False, allow_unicode=True)
        
        # Definir la ruta del archivo de backup - SIEMPRE debe ser deployment-backup.yaml
        backup_file = "deployment-backup.yaml"
        logger.info(f"📦 Archivo de backup: {backup_file}")
        
        # Crear el archivo de backup en el repositorio
        success = await github_client.create_or_update_file(
            owner=repo_info['owner'],
            repo=repo_info['repo'],
            file_path=backup_file,
            content=backup_content,
            commit_message="🔄 Backup completo del deployment original [ci skip]",
            branch=repo_info['branch']
        )
        
        if success:
            logger.info(f"✅ Backup del deployment creado exitosamente: {backup_file}")
            return True
        else:
            logger.error("❌ Error al crear el archivo de backup del deployment")
            return False
            
    except Exception as e:
        logger.error(f"💥 Error creando backup del deployment: {str(e)}")
        return False


async def trigger_configmap_deploy_workflow(git_token: str, repo_info: dict, 
                                          version: str = "0.0.0", environment: str = "cert", 
                                          environment_type: str = "certification", task_number: str = "") -> bool:
    """
    Ejecuta el workflow de deploy del ConfigMap mediante workflow_dispatch.
    
    Esta función es común para backends y frontends y ejecuta el GitHub Action
    de deploy del ConfigMap con los parámetros especificados.
    
    Args:
        git_token: Token de GitHub para autenticación
        repo_info: Información del repositorio (owner, repo, branch)
        version: Versión a desplegar (por defecto "0.0.0")
        environment: Entorno donde desplegar (por defecto "cert")
        environment_type: Tipo de entorno (por defecto "certification")
        task_number: Número de tarea SNOW (opcional)
    
    Returns:
        bool: True si el workflow se disparó exitosamente, False en caso contrario
    """
    try:
        logger.info(f"🚀 Disparando workflow de deploy del ConfigMap en {repo_info['owner']}/{repo_info['repo']}...")
        logger.info(f"📋 Parámetros: version={version}, environment={environment}, environment-type={environment_type}")
        
        # Parámetros para el workflow_dispatch
        workflow_inputs = {
            "version": version,
            "environment": environment,
            "environment-type": environment_type
        }
        
        # Añadir task_number solo si se proporciona
        if task_number:
            workflow_inputs["task-number"] = task_number
        
        # Headers para la API de GitHub
        headers = {
            'Authorization': f'token {git_token}',
            'Accept': 'application/vnd.github.v3+json',
            'Content-Type': 'application/json'
        }
        
        # URL del endpoint de workflow dispatch
        url = f"https://api.github.com/repos/{repo_info['owner']}/{repo_info['repo']}/actions/workflows/cd.yml/dispatches"
        
        # Payload para el workflow dispatch
        payload = {
            "ref": repo_info.get('branch', 'main'),
            "inputs": workflow_inputs
        }
        
        # Configuración del proxy
        proxy_config = get_proxy_config()
        
        async with aiohttp.ClientSession(**proxy_config, headers=headers) as session:
            async with session.post(url, json=payload) as response:
                if response.status == 204:
                    logger.info(f"✅ Workflow de deploy del ConfigMap disparado exitosamente")
                    logger.info(f"🔄 El deploy se está ejecutando en background...")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"❌ Error disparando workflow: HTTP {response.status} - {error_text}")
                    return False
            
    except Exception as e:
        logger.error(f"💥 Error ejecutando workflow de deploy del ConfigMap: {str(e)}")
        return False


async def wait_for_workflow_completion(git_token: str, repo_info: dict, 
                                     workflow_name: str = "Deploy", timeout_minutes: int = 10) -> Tuple[bool, str]:
    """
    Espera a que se complete un workflow específico en GitHub Actions.
    
    Args:
        git_token: Token de GitHub para autenticación
        repo_info: Información del repositorio (owner, repo, branch)
        workflow_name: Nombre del workflow a esperar (por defecto "Deploy")
        timeout_minutes: Tiempo máximo de espera en minutos (por defecto 10)
    
    Returns:
        Tuple[bool, str]: (éxito, mensaje/estado del workflow)
    """
    try:
        import asyncio
        import time
        
        logger.info(f"⏳ Esperando completación del workflow '{workflow_name}' (timeout: {timeout_minutes} min)...")
        
        start_time = time.time()
        timeout_seconds = timeout_minutes * 60
        
        # Headers para la API de GitHub
        headers = {
            'Authorization': f'token {git_token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        # Configuración del proxy
        proxy_config = get_proxy_config()
        
        while True:
            # URL para obtener workflow runs
            url = f"https://api.github.com/repos/{repo_info['owner']}/{repo_info['repo']}/actions/runs"
            
            async with aiohttp.ClientSession(**proxy_config, headers=headers) as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        runs_data = await response.json()
                        
                        # Buscar el último run del workflow específico
                        for run in runs_data.get('workflow_runs', []):
                            if run.get('name') == workflow_name:
                                status = run.get('status', 'unknown')
                                conclusion = run.get('conclusion', 'unknown')
                                
                                if status == 'completed':
                                    if conclusion == 'success':
                                        logger.info(f"✅ Workflow '{workflow_name}' completado exitosamente")
                                        return True, f"Workflow completado: {conclusion}"
                                    else:
                                        logger.error(f"❌ Workflow '{workflow_name}' falló: {conclusion}")
                                        return False, f"Workflow falló: {conclusion}"
                                
                                logger.info(f"🔄 Workflow '{workflow_name}' en estado: {status}")
                                break
                        else:
                            logger.warning(f"⚠️ No se encontró workflow '{workflow_name}' en ejecución")
                    else:
                        error_text = await response.text()
                        logger.error(f"❌ Error obteniendo estado del workflow: HTTP {response.status} - {error_text}")
            
            # Verificar timeout
            elapsed_time = time.time() - start_time
            if elapsed_time > timeout_seconds:
                logger.warning(f"⏰ Timeout alcanzado esperando workflow '{workflow_name}'")
                return False, f"Timeout después de {timeout_minutes} minutos"
            
            # Esperar antes de la siguiente verificación
            logger.info(f"🔄 Reintentando verificación del workflow en 30s...")
            await asyncio.sleep(30)
            
    except Exception as e:
        logger.error(f"💥 Error esperando completación del workflow: {str(e)}")
        return False, f"Error verificando workflow: {str(e)}"


def evaluate_migration_readiness(deployment_ok: bool, configmap_ok: bool, backup_ok: bool) -> Tuple[bool, str, str]:
    """
    Evalúa si la migración puede continuar basándose en los resultados de los pasos previos.
    
    Lógica de decisión:
    - Deployment OK es CRÍTICO - sin esto no podemos continuar
    - ConfigMap OK es DESEABLE - útil pero no crítico
    - Backup OK es CRÍTICO - necesario para rollback
    
    Args:
        deployment_ok: Si el deployment se obtuvo correctamente de OpenShift
        configmap_ok: Si el deploy del ConfigMap fue exitoso
        backup_ok: Si el backup del deployment se creó correctamente
    
    Returns:
        Tuple[bool, str, str]: (puede_continuar, nivel_riesgo, mensaje_explicativo)
    """
    
    # Casos críticos - NO CONTINUAR
    if not deployment_ok:
        return False, "CRÍTICO", "❌ No se pudo obtener el deployment original - MIGRACIÓN ABORTADA"
    
    if not backup_ok:
        return False, "CRÍTICO", "❌ No se pudo crear backup del deployment - MIGRACIÓN ABORTADA (sin rollback)"
    
    # Casos de éxito - CONTINUAR
    if deployment_ok and configmap_ok and backup_ok:
        return True, "BAJO", "✅ Todos los componentes OK - MIGRACIÓN PUEDE CONTINUAR NORMALMENTE"
    
    # Casos con advertencias - CONTINUAR CON PRECAUCIÓN
    if deployment_ok and not configmap_ok and backup_ok:
        return True, "MEDIO", "⚠️ ConfigMap no actualizado - MIGRACIÓN PUEDE CONTINUAR (requerirá deploy manual del CM)"
    
    # Fallback (no debería llegar aquí)
    return False, "CRÍTICO", "❌ Estado inconsistente - REVISAR MANUALMENTE"


def format_migration_status_message(deployment_ok: bool, configmap_ok: bool, configmap_msg: str, 
                                   backup_ok: bool, delete_ok: bool, delete_msg: str) -> str:
    """
    Formatea un mensaje de estado completo para la migración.
    
    Args:
        deployment_ok: Estado del deployment
        configmap_ok: Estado del ConfigMap
        configmap_msg: Mensaje del ConfigMap
        backup_ok: Estado del backup
        delete_ok: Estado del borrado
        delete_msg: Mensaje del borrado
    
    Returns:
        str: Mensaje formateado con el estado completo
    """
    can_continue, risk_level, evaluation_msg = evaluate_migration_readiness(deployment_ok, configmap_ok, backup_ok)
    
    status_parts = []
    
    # Header basado en el resultado general
    if can_continue and delete_ok:
        status_parts.append("🎉 MIGRACIÓN PREPARADA EXITOSAMENTE")
    elif can_continue and not delete_ok:
        status_parts.append("⚠️ MIGRACIÓN PREPARADA CON ADVERTENCIAS")
    else:
        status_parts.append("❌ MIGRACIÓN NO PUEDE CONTINUAR")
    
    # Detalles de cada componente
    status_parts.append("")
    status_parts.append("📋 RESUMEN DE COMPONENTES:")
    
    # ConfigMap
    if configmap_ok:
        status_parts.append(f"   🟢 ConfigMap: {configmap_msg}")
    else:
        status_parts.append(f"   🟡 ConfigMap: {configmap_msg}")
    
    # Backup
    if backup_ok:
        status_parts.append("   🟢 Backup: Deployment respaldado correctamente")
    else:
        status_parts.append("   🔴 Backup: FALLÓ - Sin backup de rollback")
    
    # Borrado
    if delete_ok:
        status_parts.append(f"   🟢 Cleanup: {delete_msg}")
    else:
        status_parts.append(f"   🟡 Cleanup: {delete_msg}")
    
    # Evaluación final
    status_parts.append("")
    status_parts.append(f"🎯 EVALUACIÓN: {evaluation_msg}")
    status_parts.append(f"📊 NIVEL DE RIESGO: {risk_level}")
    
    if can_continue:
        status_parts.append("🚀 ✅ LA MIGRACIÓN PUEDE CONTINUAR")
    else:
        status_parts.append("🛑 ❌ MIGRACIÓN ABORTADA - REVISAR ERRORES")
    
    return "\n".join(status_parts)
