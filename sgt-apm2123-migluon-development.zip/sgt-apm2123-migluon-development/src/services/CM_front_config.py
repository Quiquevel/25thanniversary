"""
Flujo específico para ConfigMaps de Frontend.
Maneja la creación de archivos config.json y eliminación de application-cert.properties.
"""

import aiohttp
from typing import Dict, Optional
from shuttlelib.utils.logger import logger
from .common_utils import normalize_git_url
from .github_client import GitHubClient


async def create_frontend_config_files(
    config_files_in_memory: Dict[str, str], 
    old_name: str, 
    git_token: str, 
    url_git_cm: str, 
    config_endpoint_filename: Optional[str] = None
) -> str:
    """
    Crea archivos de configuración específicos para microservicios Frontend.
    
    LÓGICA FRONTEND:
    1. Buscar archivo JSON usando CONFIG_END_POINT como prioridad máxima → crear config/cert/config.json
    2. Si se crea config.json exitosamente → eliminar config/cert/application-cert.properties
    
    Args:
        config_files_in_memory: Archivos de configuración descargados del config server
        old_name: Nombre del microservicio
        git_token: Token de GitHub
        url_git_cm: URL del repositorio de ConfigMaps
        config_endpoint_filename: Nombre específico del archivo extraído de CONFIG_END_POINT
        
    Returns:
        str: Mensaje de resultado de la creación de archivos frontend
    """
    try:
        if not config_files_in_memory:
            logger.warning("⚠️ FRONTEND_CONFIG: No hay archivos de configuración en memoria")
            return "⚠️ No hay archivos de configuración en memoria para procesar"
            
        logger.info(f"🖥️ FRONTEND_CONFIG: Iniciando con {len(config_files_in_memory)} archivos")
        logger.info(f"🖥️ FRONTEND_CONFIG: old_name='{old_name}', config_endpoint_filename='{config_endpoint_filename}'")
        
        # Extraer owner y repo de la URL
        normalized_git_url = normalize_git_url(url_git_cm)
        owner, repo = normalized_git_url.replace('https://github.com/', '').split('/')
        
        logger.info(f"🖥️ FRONTEND_CONFIG: GitHub repo={owner}/{repo}")
        
        # Crear sesión HTTP para GitHubClient
        session = aiohttp.ClientSession()
        
        try:
            # Inicializar cliente GitHub con sesión
            github_client = GitHubClient(git_token, session)
            logger.info(f"🖥️ FRONTEND_CONFIG: GitHubClient inicializado correctamente")
            
            created_files = []
            
            # PASO 1: Buscar archivo JSON específico para config.json
            json_source_file = None
            json_source_content = None
            
            # Determinar patrones de búsqueda con CONFIG_END_POINT como prioridad máxima
            json_patterns = []
            
            # PRIORIDAD 1: Archivo específico extraído de CONFIG_END_POINT (95% éxito)
            if config_endpoint_filename:
                json_patterns.append(config_endpoint_filename)
                logger.info(f"🎯 FRONTEND_CONFIG: CONFIG_END_POINT como prioridad máxima: {config_endpoint_filename}")
            else:
                logger.warning(f"⚠️ FRONTEND_CONFIG: config_endpoint_filename es None, usando patrones genéricos")
            
            # PRIORIDAD 2-4: Patrones genéricos basados en archivos disponibles como fallback
            available_files = list(config_files_in_memory.keys())
            base_patterns = []
            for file_name in available_files:
                if file_name.lower().endswith('.json'):
                    base_patterns.append(file_name)
                    logger.info(f"📋 FRONTEND_CONFIG: Añadiendo patrón desde archivo disponible: {file_name}")
            
            # Si no encontramos archivos JSON reales, usar patrones basados en old_name como último recurso
            if not base_patterns:
                base_patterns = [
                    f"{old_name}.json",
                    f"{old_name}-dev.json", 
                    f"{old_name}-cert.json"
                ]
                logger.warning(f"⚠️ FRONTEND_CONFIG: No hay archivos JSON disponibles, usando patrones genéricos")
            
            json_patterns.extend(base_patterns)
            
            # Mostrar patrones con prioridades
            logger.info(f"🔍 FRONTEND_CONFIG: Patrones JSON con prioridades:")
            for i, pattern in enumerate(json_patterns, 1):
                priority_label = "CONFIG_END_POINT" if i == 1 and config_endpoint_filename else "GENÉRICO"
                logger.info(f"     {i}. {pattern} ({priority_label})")
            
            # Buscar archivo JSON usando los patrones
            for pattern in json_patterns:
                logger.info(f"🔍 FRONTEND_CONFIG: Probando patrón JSON '{pattern}'")
                for file_name, file_content in config_files_in_memory.items():
                    if pattern in file_name.lower() or file_name.lower() == pattern.lower():
                        json_source_file = file_name
                        json_source_content = file_content
                        logger.info(f"✅ FRONTEND_CONFIG: Archivo JSON encontrado: {file_name}")
                        break
                if json_source_file:
                    break
            
            # PASO 2: Si encontramos archivo JSON, crear config/cert/config.json
            if json_source_file and json_source_content:
                logger.info(f"📝 FRONTEND_CONFIG: Creando config/cert/config.json desde {json_source_file}")
                try:
                    config_json_path = "config/cert/config.json"
                    
                    json_result = await github_client.create_or_update_file(
                        owner, 
                        repo, 
                        config_json_path,
                        json_source_content,
                        f"ConfigMap: Create {config_json_path} from {json_source_file} [ci skip]",
                        "main"
                    )
                    
                    # Manejar resultado como booleano (GitHubClient devuelve bool)
                    if json_result:
                        created_files.append(f"✅ JSON {config_json_path}: OK (desde {json_source_file})")
                        logger.info(f"✅ FRONTEND_CONFIG: {config_json_path} creado exitosamente desde {json_source_file}")
                        
                        # PASO 3: Borrar application-cert.properties si config.json fue creado
                        logger.info(f"🗑️ FRONTEND_CONFIG: Borrando application-cert.properties ya que se creó config.json")
                        try:
                            # Primero obtener el SHA del archivo a eliminar
                            file_to_delete = "config/cert/application-cert.properties"
                            file_result = await github_client.get_file_content(owner, repo, file_to_delete, "main")
                            
                            if file_result and len(file_result) == 2:
                                # get_file_content devuelve tupla (content, sha)
                                content, sha = file_result
                                logger.info(f"✅ FRONTEND_CONFIG: Archivo encontrado con SHA: {sha[:8]}...")
                                
                                delete_result = await github_client.delete_file(
                                    owner,
                                    repo,
                                    file_to_delete,
                                    sha,
                                    f"ConfigMap: Delete application-cert.properties after creating config.json [ci skip]",
                                    "main"
                                )
                                
                                if delete_result:
                                    created_files.append(f"✅ CLEANUP: application-cert.properties eliminado correctamente")
                                    logger.info(f"✅ FRONTEND_CONFIG: application-cert.properties eliminado correctamente")
                                else:
                                    created_files.append(f"⚠️ CLEANUP: Error al eliminar application-cert.properties")
                                    logger.warning(f"⚠️ FRONTEND_CONFIG: Error al eliminar application-cert.properties")
                            else:
                                created_files.append(f"ℹ️ CLEANUP: application-cert.properties no existe")
                                logger.info(f"ℹ️ FRONTEND_CONFIG: application-cert.properties no existe, no es necesario eliminarlo")
                                
                        except Exception as delete_error:
                            logger.warning(f"⚠️ Error intentando borrar application-cert.properties: {str(delete_error)}")
                            created_files.append(f"⚠️ CLEANUP: Error eliminando application-cert.properties: {str(delete_error)}")
                    else:
                        created_files.append(f"❌ JSON {config_json_path}: KO - Error en creación")
                        logger.error(f"❌ FRONTEND_CONFIG: Error al crear {config_json_path}")
                        
                except Exception as e:
                    logger.error(f"❌ FRONTEND_CONFIG: Error creando config/cert/config.json: {str(e)}")
                    created_files.append(f"❌ JSON config/cert/config.json: KO - Error: {str(e)}")
            else:
                logger.warning(f"⚠️ FRONTEND_CONFIG: No se encontró archivo JSON para crear config/cert/config.json")
                created_files.append(f"⚠️ No se encontró archivo JSON para crear config/cert/config.json")
            
            # PASO 4: Mostrar resultado final  
            logger.info(f"🏁 FRONTEND_CONFIG: Proceso completado. Archivos creados: {len(created_files)}")
            if created_files:
                result = " | ".join(created_files)
                logger.info(f"🏁 FRONTEND_CONFIG: Resultado final: {result}")
                return result
            else:
                result = f"❌ No se crearon archivos de configuración frontend para '{old_name}'"
                logger.warning(f"🏁 FRONTEND_CONFIG: {result}")
                return result
                
        finally:
            # Cerrar la sesión HTTP
            await session.close()
            logger.info(f"🔄 FRONTEND_CONFIG: Sesión HTTP cerrada")
        
    except Exception as e:
        logger.error(f"❌ FRONTEND_CONFIG: Error general: {str(e)}")
        return f"❌ Error creando archivos de configuración frontend: {str(e)}"