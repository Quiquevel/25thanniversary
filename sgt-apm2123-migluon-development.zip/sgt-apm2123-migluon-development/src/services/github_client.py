"""
Cliente GitHub optimizado para centralizar toda la lógica de API.
Elimina duplicación de código y maneja errores consistentemente.
"""
import base64
import aiohttp
import yaml
import re
from typing import Dict, Any, Optional, Tuple
from shuttlelib.utils.logger import logger
from src.utils.proxy_config import get_proxy_config


class GitHubClient:
    """Cliente optimizado para operaciones GitHub API con manejo consistente de errores."""
    
    def __init__(self, token: str, session: aiohttp.ClientSession):
        self.token = token
        self.session = session
        self.headers = {
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json"
        }
        self.branch = "feature/gluon-migration-config-from-pulse-import"
    
    async def get_file_content(self, owner: str, repo: str, file_path: str, 
                              branch: Optional[str] = None) -> Optional[Tuple[str, str]]:
        """
        Obtiene el contenido de un archivo desde GitHub.
        Intenta múltiples ramas si falla la primera.
        
        Returns:
            Tuple[content: str, sha: str] si éxito, None si error
        """
        if branch is None:
            branch = self.branch
            
        # Lista de ramas a probar en orden de prioridad
        branches_to_try = [branch, "/feature/gluon-migration-config-from-pulse-import", "development"]
        
        for try_branch in branches_to_try:
            url = f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}?ref={try_branch}"
            logger.info(f"🔍 Intentando obtener {file_path} de rama {try_branch}...")
            
            try:
                async with self.session.get(url, headers=self.headers) as response:
                    logger.info(f"📋 Respuesta HTTP: {response.status} para rama {try_branch}")
                    if response.status == 200:
                        file_data = await response.json()
                        
                        # Si es una lista, es un directorio, no un archivo
                        if isinstance(file_data, list):
                            # Para directorios, devolvemos un contenido indicativo
                            if try_branch != branch:
                                logger.info(f"Directorio {file_path} encontrado en rama {try_branch} (no en {branch})")
                            return "directory", "directory"
                        
                        # Si es un archivo individual
                        content = base64.b64decode(file_data.get("content")).decode("utf-8")
                        sha = file_data.get("sha")
                        
                        if try_branch != branch:
                            logger.info(f"Archivo {file_path} encontrado en rama {try_branch} (no en {branch})")
                        
                        return content, sha
                    
                    elif response.status == 404:
                        # Archivo no encontrado en esta rama, probar siguiente
                        logger.info(f"⚠️ Archivo {file_path} no encontrado en rama {try_branch}")
                        continue
                    else:
                        # Otro error (403, 401, etc.)
                        error_text = await response.text()
                        logger.error(f"❌ Error {response.status} al obtener {file_path} en {try_branch}: {error_text}")
                        continue
                        
            except Exception as e:
                logger.error(f"❌ Excepción al obtener {file_path} en {try_branch}: {str(e)}")
                continue
        
        logger.error(f"❌ No se pudo obtener {file_path} de ninguna rama: {branches_to_try}")
        return None
    
    async def update_file(self, owner: str, repo: str, file_path: str, content: str, 
                         sha: Optional[str], commit_message: str, 
                         branch: Optional[str] = None) -> Dict[str, Any]:
        """
        Actualiza o crea un archivo en GitHub con manejo robusto de ramas.
        Si sha es None, crea el archivo. Si sha existe, actualiza el archivo.
        
        Returns:
            Dict con status: 'success' | 'error' y detalles apropiados
        """
        if branch is None:
            branch = self.branch
            
        url = f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}"
        
        update_data = {
            "message": commit_message,
            "content": base64.b64encode(content.encode()).decode(),
            "branch": branch
        }
        
        # Solo incluir sha si el archivo existe (actualización)
        if sha is not None:
            update_data["sha"] = sha
            action = "actualizado"
        else:
            action = "creado"
        
        try:
            logger.info(f"� Intentando {action} archivo {file_path} en rama {branch}")
            logger.info(f"� URL: {url}")
            logger.info(f"� SHA: {sha if sha else 'None (nuevo archivo)'}")
            logger.info(f"📄 Content length: {len(update_data['content'])} chars (base64)")
            
            async with self.session.put(url, headers=self.headers, json=update_data) as response:
                logger.info(f"� Response status: {response.status}")
                
                if response.status in [200, 201]:  # 200=Updated, 201=Created
                    logger.info(f"{file_path} {action} con éxito en rama {branch}")
                    return {
                        "status": "success",
                        "file": file_path,
                        "branch": branch,
                        "message": f"Archivo {file_path} {action} correctamente en {branch}"
                    }
                elif response.status == 422:
                    # Posible problema con la rama, intentar con development
                    error_text = await response.text()
                    logger.error(f"❌ Error 422 al {action} {file_path}: {error_text}")
                    if "branch" in error_text.lower() and branch != "development":
                        logger.warning(f"Problema con rama {branch}, intentando con development")
                        update_data["branch"] = "development"
                        
                        async with self.session.put(url, headers=self.headers, json=update_data) as retry_response:
                            if retry_response.status in [200, 201]:  # 200=Updated, 201=Created
                                logger.info(f"{file_path} {action} con éxito en rama development (fallback)")
                                return {
                                    "status": "success",
                                    "file": file_path,
                                    "branch": "development",
                                    "message": f"Archivo {file_path} {action} correctamente en development (fallback)"
                                }
                            else:
                                retry_error = await retry_response.text()
                                logger.error(f"Error en fallback al actualizar {file_path}: {retry_response.status}")
                                return {
                                    "status": "error",
                                    "file": file_path,
                                    "error": f"Error en fallback al actualizar {file_path}: {retry_response.status}"
                                }
                    else:
                        logger.error(f"Error 422 al actualizar {file_path}")
                        return {
                            "status": "error",
                            "file": file_path,
                            "error": f"Error 422 al actualizar {file_path}"
                        }
                else:
                    error_text = await response.text()
                    logger.error(f"🔍 DEBUG: Error response body: {error_text[:500]}...")
                    logger.error(f"Error {response.status} al actualizar {file_path}")
                    return {
                        "status": "error",
                        "file": file_path,
                        "error": f"Error {response.status} al actualizar {file_path}"
                    }
                    
        except Exception as e:
            logger.error(f"Excepción al actualizar {file_path}: {str(e)}")
            return {
                "status": "error",
                "file": file_path,
                "error": f"Excepción al actualizar {file_path}: {str(e)}"
            }
    
    async def get_branch_sha(self, owner: str, repo: str, branch: str) -> Optional[str]:
        """Obtiene el SHA de una rama específica."""
        url = f"https://api.github.com/repos/{owner}/{repo}/git/refs/heads/{branch}"
        
        try:
            async with self.session.get(url, headers=self.headers) as response:
                if response.status != 200:
                    return None
                    
                branch_data = await response.json()
                return branch_data['object']['sha']
                
        except Exception as e:
            logger.error(f"Error al obtener SHA de rama {branch}: {str(e)}")
            return None
    
    async def create_branch(self, owner: str, repo: str, new_branch: str, source_sha: str) -> Dict[str, Any]:
        """Crea una nueva rama desde un SHA específico."""
        url = f"https://api.github.com/repos/{owner}/{repo}/git/refs"
        
        branch_data = {
            "ref": f"refs/heads/{new_branch}",
            "sha": source_sha
        }
        
        try:
            async with self.session.post(url, headers=self.headers, json=branch_data) as response:
                if response.status == 201:
                    logger.info(f"Rama {new_branch} creada exitosamente")
                    return {"status": "success", "branch": new_branch}
                elif response.status == 422:
                    error_text = await response.text()
                    if "Reference already exists" in error_text:
                        logger.info(f"Rama {new_branch} ya existe")
                        return {"status": "success", "branch": new_branch, "already_exists": True}
                    else:
                        return {"status": "error", "message": f"Error al crear rama: {error_text}"}
                else:
                    error_text = await response.text()
                    return {"status": "error", "message": f"Error al crear rama: {error_text}"}
                    
        except Exception as e:
            logger.error(f"Excepción al crear rama {new_branch}: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    async def create_or_update_file(self, owner: str, repo: str, file_path: str, content: str, 
                                   commit_message: str, branch: Optional[str] = None) -> bool:
        """
        Crea un nuevo archivo en GitHub o actualiza uno existente.
        
        Returns:
            bool: True si éxito, False si error
        """
        if branch is None:
            branch = self.branch
            
        url = f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}"
        
        # Primero verificar si el archivo existe
        existing_file = await self.get_file_content(owner, repo, file_path, branch)
        
        create_data = {
            "message": commit_message,
            "content": base64.b64encode(content.encode()).decode(),
            "branch": branch
        }
        
        # Si el archivo existe, agregar el SHA para actualización
        if existing_file:
            _, sha = existing_file
            create_data["sha"] = sha
        
        try:
            async with self.session.put(url, headers=self.headers, json=create_data) as response:
                if response.status in [200, 201]:
                    logger.info(f"Archivo {file_path} {'actualizado' if existing_file else 'creado'} exitosamente")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"Error {'actualizando' if existing_file else 'creando'} {file_path}: {error_text}")
                    return False
                    
        except Exception as e:
            logger.error(f"Excepción {'actualizando' if existing_file else 'creando'} archivo {file_path}: {str(e)}")
            return False
    
    async def delete_file(self, owner: str, repo: str, file_path: str, sha: str, 
                         commit_message: str, branch: Optional[str] = None) -> bool:
        """
        Elimina un archivo en GitHub.
        
        Returns:
            bool: True si éxito, False si error
        """
        if branch is None:
            branch = self.branch
            
        url = f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}"
        
        delete_data = {
            "message": commit_message,
            "sha": sha,
            "branch": branch
        }
        
        try:
            async with self.session.delete(url, headers=self.headers, json=delete_data) as response:
                if response.status == 200:
                    logger.info(f"Archivo {file_path} eliminado exitosamente")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"Error eliminando {file_path}: {error_text}")
                    return False
                    
        except Exception as e:
            logger.error(f"Excepción eliminando archivo {file_path}: {str(e)}")
            return False

    async def list_repository_files(self, owner: str, repo: str, branch: str = "main", path: str = "") -> Optional[list]:
        """
        Lista todos los archivos de un repositorio recursivamente.
        
        Args:
            owner: Propietario del repositorio
            repo: Nombre del repositorio
            branch: Rama a listar (default: main)
            path: Ruta específica a listar (default: raíz)
            
        Returns:
            Lista de archivos con información (path, type, sha, etc.) o None si error
        """
        try:
            all_files = []
            
            # URL para obtener el tree completo recursivamente
            url = f"https://api.github.com/repos/{owner}/{repo}/git/trees/{branch}?recursive=1"
            logger.info(f"🔍 Listando archivos de {owner}/{repo} (rama: {branch})")
            
            async with self.session.get(url, headers=self.headers) as response:
                if response.status == 200:
                    tree_data = await response.json()
                    
                    # Extraer archivos del tree
                    for item in tree_data.get('tree', []):
                        # Solo archivos (no directorios)
                        if item.get('type') == 'blob':
                            file_info = {
                                'path': item.get('path'),
                                'sha': item.get('sha'),
                                'size': item.get('size'),
                                'type': item.get('type'),
                                'url': item.get('url')
                            }
                            
                            # Filtrar por path si se especifica
                            if not path or item.get('path', '').startswith(path):
                                all_files.append(file_info)
                    
                    logger.info(f"✅ Encontrados {len(all_files)} archivos en {owner}/{repo}")
                    return all_files
                    
                elif response.status == 404:
                    logger.warning(f"⚠️ Repositorio o rama no encontrada: {owner}/{repo}:{branch}")
                    return None
                else:
                    error_text = await response.text()
                    logger.error(f"❌ Error listando archivos {owner}/{repo}: {error_text}")
                    return None
                    
        except Exception as e:
            logger.error(f"❌ Excepción listando archivos {owner}/{repo}: {str(e)}")
            return None

    async def trigger_workflow_dispatch(self, owner: str, repo: str, workflow_id: str, 
                                      ref: str, inputs: Dict[str, str]) -> bool:
        """
        Dispara un workflow usando workflow_dispatch.
        
        Args:
            owner: Propietario del repositorio
            repo: Nombre del repositorio
            workflow_id: ID o nombre del archivo del workflow (ej: "cd.yml")
            ref: Branch o tag desde donde ejecutar el workflow
            inputs: Diccionario con los inputs del workflow
            
        Returns:
            bool: True si el workflow se disparó exitosamente, False en caso contrario
        """
        try:
            url = f"https://api.github.com/repos/{owner}/{repo}/actions/workflows/{workflow_id}/dispatches"
            
            payload = {
                "ref": ref,
                "inputs": inputs
            }
            
            logger.info(f"🚀 Disparando workflow {workflow_id} en {owner}/{repo}:{ref}")
            logger.info(f"📋 Inputs: {inputs}")
            
            async with self.session.post(url, headers=self.headers, json=payload) as response:
                if response.status == 204:
                    logger.info(f"✅ Workflow {workflow_id} disparado exitosamente")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"❌ Error disparando workflow {workflow_id}: HTTP {response.status} - {error_text}")
                    return False
                    
        except Exception as e:
            logger.error(f"💥 Excepción disparando workflow {workflow_id}: {str(e)}")
            return False

    async def get_latest_workflow_run_status(self, owner: str, repo: str, 
                                           workflow_name: str) -> Dict[str, str]:
        """
        Obtiene el estado del último workflow run.
        
        Args:
            owner: Propietario del repositorio
            repo: Nombre del repositorio
            workflow_name: Nombre del workflow (ej: "Deploy")
            
        Returns:
            Dict con 'status' y 'conclusion' del workflow run
        """
        try:
            # Obtener la lista de workflow runs
            url = f"https://api.github.com/repos/{owner}/{repo}/actions/runs"
            
            async with self.session.get(url, headers=self.headers) as response:
                if response.status == 200:
                    runs_data = await response.json()
                    
                    # Buscar el último run del workflow específico
                    for run in runs_data.get('workflow_runs', []):
                        if run.get('name') == workflow_name:
                            return {
                                'status': run.get('status', 'unknown'),
                                'conclusion': run.get('conclusion', 'unknown'),
                                'id': run.get('id', ''),
                                'url': run.get('html_url', '')
                            }
                    
                    logger.warning(f"⚠️ No se encontró workflow con nombre '{workflow_name}'")
                    return {'status': 'not_found', 'conclusion': 'not_found'}
                    
                else:
                    error_text = await response.text()
                    logger.error(f"❌ Error obteniendo workflow runs: HTTP {response.status} - {error_text}")
                    return {'status': 'error', 'conclusion': 'error'}
                    
        except Exception as e:
            logger.error(f"💥 Excepción obteniendo estado del workflow: {str(e)}")
            return {'status': 'error', 'conclusion': 'error'}

    async def batch_update_files(self, owner: str, repo: str, file_changes: Dict[str, str], 
                                commit_message: str, branch: Optional[str] = None, dry_run: bool = False) -> Dict[str, Any]:
        """
        Actualiza múltiples archivos en un solo commit usando GitHub Tree API.
        
        Args:
            owner: Propietario del repositorio
            repo: Nombre del repositorio
            file_changes: Dict con {file_path: new_content} para cada archivo a modificar
            commit_message: Mensaje del commit
            branch: Rama (por defecto usa self.branch)
            
        Returns:
            Dict con status y detalles de la operación
        """
        if branch is None:
            branch = self.branch
            
        try:
            # 1. Obtener SHA del último commit de la rama
            ref_url = f"https://api.github.com/repos/{owner}/{repo}/git/ref/heads/{branch}"
            async with self.session.get(ref_url, headers=self.headers) as response:
                if response.status != 200:
                    body = await response.text()
                    logger.error(f"Error obteniendo ref {branch}: HTTP {response.status} - {body[:500]}")
                    return {"status": "error", "error": f"No se pudo obtener referencia de rama {branch}: HTTP {response.status}"}
                ref_data = await response.json()
                logger.debug(f"batch_update_files: ref_data obtenida para {branch}: {str(ref_data)[:2000]}")
                base_commit_sha = ref_data['object']['sha']

            # Obtener el tree SHA del commit base (necesario para crear el tree correctamente)
            commit_url = f"https://api.github.com/repos/{owner}/{repo}/git/commits/{base_commit_sha}"
            async with self.session.get(commit_url, headers=self.headers) as commit_resp:
                if commit_resp.status != 200:
                    body = await commit_resp.text()
                    logger.error(f"Error obteniendo commit {base_commit_sha}: HTTP {commit_resp.status} - {body[:500]}")
                    return {"status": "error", "error": f"No se pudo obtener commit {base_commit_sha}: HTTP {commit_resp.status}"}
                commit_data = await commit_resp.json()
                logger.debug(f"batch_update_files: commit_data obtenida para {base_commit_sha}: {str(commit_data)[:2000]}")
                base_tree_sha = commit_data.get('tree', {}).get('sha')
                if not base_tree_sha:
                    logger.error(f"No se encontró tree SHA en commit {base_commit_sha}")
                    return {"status": "error", "error": f"No se encontró tree SHA en commit {base_commit_sha}"}
            
            # 2. Crear tree con todos los archivos modificados
            tree_items = []
            for file_path, content in file_changes.items():
                # Crear blob para cada archivo
                blob_data = {
                    "content": content,
                    "encoding": "utf-8"
                }
                
                blob_url = f"https://api.github.com/repos/{owner}/{repo}/git/blobs"
                logger.debug(f"batch_update_files: creando blob para {file_path} - payload (primeros 300 chars): {str(content)[:300]}")
                async with self.session.post(blob_url, headers=self.headers, json=blob_data) as blob_response:
                    if blob_response.status != 201:
                        body = await blob_response.text()
                        logger.error(f"Error creando blob para {file_path}: HTTP {blob_response.status} - {body[:1000]}")
                        return {"status": "error", "error": f"Error creando blob para {file_path}: HTTP {blob_response.status}"}
                    blob_result = await blob_response.json()
                    blob_sha = blob_result['sha']
                    logger.debug(f"batch_update_files: blob creado para {file_path} -> sha={blob_sha}")
                
                # Añadir al tree
                tree_items.append({
                    "path": file_path,
                    "mode": "100644",
                    "type": "blob",
                    "sha": blob_sha
                })
            
            # 3. Crear el tree
            tree_data = {
                "base_tree": base_tree_sha,
                "tree": tree_items
            }
            
            tree_url = f"https://api.github.com/repos/{owner}/{repo}/git/trees"
            logger.debug(f"batch_update_files: creando tree con base_tree={base_tree_sha} y {len(tree_items)} items")
            async with self.session.post(tree_url, headers=self.headers, json=tree_data) as tree_response:
                if tree_response.status != 201:
                    body = await tree_response.text()
                    logger.error(f"Error creando tree: HTTP {tree_response.status} - {body[:1000]}")
                    return {"status": "error", "error": "Error creando tree"}
                tree_result = await tree_response.json()
                tree_sha = tree_result.get('sha')
                logger.debug(f"batch_update_files: tree creado -> sha={tree_sha}")
            
            # 4. Crear commit
            commit_data = {
                "message": commit_message,
                "tree": tree_sha,
                "parents": [base_commit_sha]
            }
            
            commit_url = f"https://api.github.com/repos/{owner}/{repo}/git/commits"
            async with self.session.post(commit_url, headers=self.headers, json=commit_data) as commit_response:
                if commit_response.status != 201:
                    body = await commit_response.text()
                    logger.error(f"Error creando commit: HTTP {commit_response.status} - {body[:1000]}")
                    return {"status": "error", "error": f"Error creando commit: HTTP {commit_response.status}"}
                commit_result = await commit_response.json()
                new_commit_sha = commit_result['sha']
                logger.debug(f"batch_update_files: commit creado -> sha={new_commit_sha}")
            
            # 5. Actualizar la referencia de la rama (a menos que sea dry_run)
            update_ref_data = {
                "sha": new_commit_sha
            }
            if dry_run:
                logger.info("DRY-RUN: Se ha creado el commit en memoria pero no se actualizará la referencia de la rama (dry_run=True)")
            else:
                logger.debug(f"batch_update_files: PATCH ref_url={ref_url} update_ref_data={update_ref_data}")
                async with self.session.patch(ref_url, headers=self.headers, json=update_ref_data) as ref_response:
                    body = await ref_response.text()
                    logger.debug(f"batch_update_files: PATCH response status={ref_response.status} body={body[:2000]}")
                    if ref_response.status == 200:
                        logger.info("batch_update_files: referencia de rama actualizada correctamente")
                    else:
                        # Leer body para diagnóstico y devolver error (no realizar fallback)
                        logger.error(f"Error actualizando referencia de rama: HTTP {ref_response.status} - {body[:1000]}")
                        return {"status": "error", "error": f"Error actualizando referencia de rama: HTTP {ref_response.status} - {body[:800]}"}
            
            logger.info(f"✅ Batch commit exitoso: {len(file_changes)} archivos actualizados en commit {new_commit_sha[:7]}")
            return {
                "status": "success", 
                "commit_sha": new_commit_sha,
                "files_updated": len(file_changes),
                "message": f"Actualizados {len(file_changes)} archivos en un commit"
            }
            
        except Exception as e:
            logger.error(f"Error en batch_update_files: {str(e)}")
            return {"status": "error", "error": str(e)}


# Función selective_yaml_update eliminada - usar funciones específicas de modificación YAML


# Factoría para crear clientes optimizados
def create_github_client(token: str, session: aiohttp.ClientSession) -> GitHubClient:
    """Crea una instancia optimizada del cliente GitHub."""
    return GitHubClient(token, session)


def create_github_session_with_proxy(**kwargs) -> aiohttp.ClientSession:
    """
    Crea una sesión aiohttp configurada con proxy para GitHub.
    
    Args:
        **kwargs: Argumentos adicionales para ClientSession
        
    Returns:
        ClientSession configurada con proxy para llamadas a GitHub
    """
    proxy_config = get_proxy_config()
    session_config = {**proxy_config, **kwargs}
    
    return aiohttp.ClientSession(**session_config)
