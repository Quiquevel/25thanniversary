"""
Sistema centralizado de respuestas y mensajes para el proyecto de migración.
Unifica todos los formatos de logging y respuestas para consistencia.
"""
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from shuttlelib.utils.logger import logger


class ResponseFormatter:
    """Formateador centralizado de respuestas para el sistema de migración"""
    
    # Símbolos estándar
    SUCCESS = "✅"
    ERROR = "❌"
    WARNING = "⚠️"
    INFO = "ℹ️"
    PROCESS = "🔄"
    ROCKET = "🚀"
    CONFIG = "⚙️"
    MICROSERVICE = "🔧"
    FRONTEND = "🖥️"
    BACKEND = "⚙️"
    TARGET = "🎯"
    FINISH = "🏁"
    
    @staticmethod
    def header_main_process(process_name: str, app_name: str) -> List[str]:
        """
        Cabecera principal para procesos (ConfigMap, Microservicios)
        
        Args:
            process_name: Nombre del proceso (ej: "MICROSERVICIO CONFIG MAP")
            app_name: Nombre de la aplicación
            
        Returns:
            List[str]: Líneas formateadas
        """
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        return [
            f"\n{ResponseFormatter.CONFIG} DETECTADO Y PROCESADO: {process_name}",
            "=" * 60,
            f"\n{ResponseFormatter.ROCKET} INICIO PROCESO CONFIGMAP - {app_name} - {timestamp}"
        ]
    
    @staticmethod
    def step_result(step_num: int, step_name: str, success: bool, details: str = "") -> List[str]:
        """
        Resultado de un paso específico
        
        Args:
            step_num: Número del paso
            step_name: Nombre descriptivo del paso
            success: Si fue exitoso o no
            details: Detalles adicionales opcionales
            
        Returns:
            List[str]: Líneas formateadas
        """
        symbol = ResponseFormatter.SUCCESS if success else ResponseFormatter.ERROR
        status = "OK" if success else "KO"
        
        lines = [
            f"\n--- PASO {step_num}: {step_name} ---",
            f"{symbol} PASO {step_num}: {status}"
        ]
        
        if details:
            lines.append(f"   {details}")
            
        return lines
    
    @staticmethod
    def microservice_detection(ms_type: str, ms_name: str, reason: str) -> List[str]:
        """
        Detección de tipo de microservicio
        
        Args:
            ms_type: Tipo detectado (FRONTEND, BACKEND, etc.)
            ms_name: Nombre del microservicio
            reason: Razón de la detección
            
        Returns:
            List[str]: Líneas formateadas
        """
        return [
            f"\n--- DETECCIÓN TIPO MICROSERVICIO ---",
            f"{ResponseFormatter.TARGET} Tipo detectado: {ms_type}",
            f"📝 Razón: {reason}"
        ]
    
    @staticmethod
    def frontend_flow_header() -> List[str]:
        """Cabecera específica para flujo frontend"""
        return ["\n=== FLUJO CONFIGMAP FRONTEND ==="]
    
    @staticmethod
    def backend_flow_header() -> List[str]:
        """Cabecera específica para flujo backend"""  
        return ["\n=== FLUJO CONFIGMAP BACKEND ==="]
    
    @staticmethod
    def format_robot_deployertoken_response(result: Dict[str, Any], request_data: Any) -> str:
        """
        Formatea la respuesta del endpoint robot_deployertoken
        
        Args:
            result: Dict con deploy_status, robot_accounts_raw, vault_results, vault_errors
            request_data: Datos de la petición (para harbor/appkey)
            
        Returns:
            str: Respuesta formateada para PlainTextResponse
        """
        if not isinstance(result, dict):
            return str(result)

        lines = []

        # Header con Harbor y Appkey
        lines.append(f"Harbor: {request_data.registry_project}")
        lines.append(f"Appkey: {request_data.appkey}")
        lines.append("")

        # Despliegue token
        lines.append("despliegue token")
        for item in result.get("deploy_status", []):
            env = item.get("environment")
            region = item.get("region")
            status = item.get("status")
            emoji = ResponseFormatter.SUCCESS if status == "OK" else ResponseFormatter.ERROR
            lines.append(f"{emoji} {env} {region}: {status}")

        lines.append("")
        lines.append("robot accounts")

        # Extraer datos para procesamiento
        raw_accounts = result.get("robot_accounts_raw")
        raw_lines = str(raw_accounts).splitlines() if raw_accounts is not None else []
        vault_results = result.get("vault_results", {})
        vault_errors = result.get("vault_errors", [])

        # Map labels to env keys
        env_map = {
            "DEV": "certification",
            "PRE": "preproduction", 
            "PRO": "production",
        }

        # Procesar por entorno
        for label, env_key in env_map.items():
            # Buscar línea específica de robot_accounts_raw relacionada con este env
            robot_msg = None
            for rl in raw_lines:
                if env_key in rl.lower():
                    parts = rl.split(':', 1)
                    robot_msg = parts[1].strip() if len(parts) > 1 else rl.strip()
                    break

            # Determinar si vault guardó credenciales para este env
            saved = any((f"/{env_key}/" in k) and (v == "OK") for k, v in vault_results.items())

            # Buscar errores específicos en vault_errors
            specific_errors = [e for e in vault_errors if env_key in e.lower() or any(name in e.lower() for name in [f"vault-{env_key}", env_key])]
            env_name_map = {"certification": "dev", "preproduction": "pre", "production": "pro"}
            short_name = env_name_map.get(env_key, env_key)
            additional_errors = [e for e in vault_errors if f"vault-{short_name}" in e.lower()]
            all_errors = list(set(specific_errors + additional_errors))

            messages = []
            
            # 1. Verificar si hay errores en robot account creation
            if robot_msg and ('error' in robot_msg.lower() or 'ko' in robot_msg.lower()):
                messages.append("Error al crear la robot account")

            # 2. Si no se guardaron credenciales
            if not saved:
                messages.append("No se guardaron credenciales, al no crear nueva cuenta")

            # 3. Agregar errores específicos de vault_errors
            for se in all_errors:
                s = se.strip()
                # Mapear nombres largos a sufijos cortos
                s = s.replace("vault-certification", "vault-dev")
                s = s.replace("vault-preproduction", "vault-pre")
                s = s.replace("vault-production", "vault-pro")
                if s and s[0].islower():
                    s = s[0].upper() + s[1:]
                messages.append(s)

            # 4. Si hay errores en robot creation pero tokens se guardaron, explicar
            if robot_msg and ('error' in robot_msg.lower() or 'ko' in robot_msg.lower()) and saved:
                messages.append("No se guardaron credenciales, al no crear nueva cuenta")
                if not all_errors:
                    messages.append(f"Robot account 'vault-{short_name}' ya existe en el proyecto")

            # Mostrar resultado
            if messages:
                lines.append(f"{ResponseFormatter.ERROR}HARBOR {label}: {', '.join(messages)}")
            else:
                lines.append(f"{ResponseFormatter.SUCCESS}HARBOR {label}: OK")

        return "\n".join(lines)

    @staticmethod
    def process_completion(process_name: str, app_name: str) -> List[str]:
        """
        Finalización de proceso
        
        Args:
            process_name: Nombre del proceso completado
            app_name: Nombre de la aplicación
            
        Returns:
            List[str]: Líneas formateadas
        """
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        return [
            f"\n{ResponseFormatter.FINISH} PROCESO {process_name} COMPLETADO - {timestamp}"
        ]
    
    @staticmethod
    def migration_header(app_name: str, configmap_url: str, micro_urls: List[str], oam_url: str) -> List[str]:
        """
        Cabecera para migración combinada
        
        Args:
            app_name: Nombre de la aplicación
            configmap_url: URL del ConfigMap
            micro_urls: Lista de URLs de microservicios  
            oam_url: URL del OAM
            
        Returns:
            List[str]: Líneas formateadas
        """
        lines = [
            f"{ResponseFormatter.ROCKET} INICIANDO MIGRACIÓN COMBINADA",
            "=" * 80,
            f"📝 Aplicación: {app_name}",
            f"🗺️ ConfigMap: {configmap_url}",
            f"{ResponseFormatter.MICROSERVICE} Microservicios ({len(micro_urls)}):"
        ]
        
        for i, micro_url in enumerate(micro_urls, 1):
            micro_name = micro_url.split('/')[-1] if '/' in micro_url else micro_url
            lines.append(f"   {i}. {micro_name}")
            
        lines.extend([
            f"🌐 OAM: {oam_url}",
            "=" * 80
        ])
        
        return lines
    
    @staticmethod
    def migration_step_header(step_num: int, step_name: str) -> List[str]:
        """
        Cabecera de paso en migración combinada
        
        Args:
            step_num: Número del paso
            step_name: Nombre del paso
            
        Returns:
            List[str]: Líneas formateadas
        """
        return [
            f"\n🗺️ PASO {step_num}: {step_name}",
            "-" * 60
        ]
    
    @staticmethod
    def microservice_processing_header(repo_idx: int, total_repos: int, micro_name: str) -> List[str]:
        """
        Cabecera para procesamiento de microservicio específico
        
        Args:
            repo_idx: Índice del repositorio actual
            total_repos: Total de repositorios
            micro_name: Nombre del microservicio
            
        Returns:
            List[str]: Líneas formateadas  
        """
        return [f"\n📦 Microservicio {repo_idx}/{total_repos}: {micro_name}"]
    
    @staticmethod
    def deployment_evaluation_header() -> List[str]:
        """Cabecera para evaluación de despliegue automático"""
        return [
            f"\n{ResponseFormatter.ROCKET} PASO 3: EVALUANDO DESPLIEGUE AUTOMÁTICO A DEV",
            "-" * 60
        ]
    
    @staticmethod
    def backup_step_header() -> List[str]:
        """Cabecera para paso de backup y borrado"""
        return [
            "\n🗂️ PASO 4: BACKUP Y BORRADO DEL DEPLOYMENT ORIGINAL",
            "-" * 60
        ]
    
    @staticmethod
    def migration_summary(app_name: str, configmap_url: str, micro_count: int, 
                         micro_urls: List[str], deployment_status: str) -> List[str]:
        """
        Resumen final de migración combinada
        
        Args:
            app_name: Nombre de la aplicación
            configmap_url: URL del ConfigMap
            micro_count: Número de microservicios
            micro_urls: Lista de URLs de microservicios
            deployment_status: Estado del despliegue
            
        Returns:
            List[str]: Líneas formateadas
        """
        lines = [
            "\n" + "=" * 80,
            "📊 RESUMEN DE MIGRACIÓN COMBINADA", 
            "=" * 80,
            f"📝 Aplicación migrada: {app_name}",
            f"🗺️ ConfigMap: {configmap_url}",
            f"{ResponseFormatter.MICROSERVICE} Microservicios procesados: {micro_count}"
        ]
        
        for i, micro_url in enumerate(micro_urls, 1):
            micro_name = micro_url.split('/')[-1] if '/' in micro_url else micro_url
            lines.append(f"   {i}. {micro_name}")
            
        lines.extend([
            f"{ResponseFormatter.ROCKET} Estado despliegue: {deployment_status}",
            "=" * 80
        ])
        
        return lines
    
    @staticmethod
    def deployment_status_banner(deployment_message: str) -> List[str]:
        """
        Banner superior con estado de despliegue
        
        Args:
            deployment_message: Mensaje de estado del despliegue
            
        Returns:
            List[str]: Líneas formateadas
        """
        return [
            "=" * 100,
            f"{ResponseFormatter.ROCKET} {ResponseFormatter.ROCKET} {ResponseFormatter.ROCKET} ESTADO DE DESPLIEGUE A DEV {ResponseFormatter.ROCKET} {ResponseFormatter.ROCKET} {ResponseFormatter.ROCKET}",
            "=" * 100,
            f"           {deployment_message}",
            "=" * 100,
            ""
        ]
    
    @staticmethod
    def error_message(context: str, error_details: str) -> str:
        """
        Mensaje de error formateado
        
        Args:
            context: Contexto donde ocurrió el error
            error_details: Detalles del error
            
        Returns:
            str: Mensaje de error formateado
        """
        return f"{ResponseFormatter.ERROR} Error en {context}: {error_details}"
    
    @staticmethod
    def success_message(context: str, success_details: str = "") -> str:
        """
        Mensaje de éxito formateado
        
        Args:
            context: Contexto de la operación exitosa
            success_details: Detalles adicionales del éxito
            
        Returns:
            str: Mensaje de éxito formateado
        """
        base = f"{ResponseFormatter.SUCCESS} {context}"
        return f"{base}: {success_details}" if success_details else base
    
    @staticmethod
    def warning_message(context: str, warning_details: str) -> str:
        """
        Mensaje de advertencia formateado
        
        Args:
            context: Contexto de la advertencia
            warning_details: Detalles de la advertencia
            
        Returns:
            str: Mensaje de advertencia formateado
        """
        return f"{ResponseFormatter.WARNING} {context}: {warning_details}"
    
    @staticmethod
    def fix_encoding_issues(text: str) -> str:
        """
        Corrige problemas de encoding de caracteres especiales y emojis.
        
        Args:
            text: Texto con posibles problemas de encoding
            
        Returns:
            str: Texto con encoding corregido
        """
        # Lista de reemplazos de encoding (caracteres mal codificados -> correctos)
        fixes = [
            # Emojis comunes
            ('âœ…', '✅'),     # Check mark
            ('âŒ', '❌'),      # Cross mark  
            ('âš ï¸', '⚠️'),    # Warning sign
            ('ðŸ"', '🔍'),     # Magnifying glass
            ('ðŸ†"', '🆔'),    # ID button
            ('ðŸ"', '📁'),     # File folder
            ('ðŸŽ¯', '🎯'),     # Direct hit
            ('ðŸ"‹', '📋'),     # Clipboard
            ('ðŸš€', '🚀'),     # Rocket
            ('ðŸ"§', '🔧'),     # Wrench
            ('ðŸ—º', '🗺️'),    # World map
            ('ðŸŒ', '🌐'),     # Globe
            ('ðŸ"Š', '📊'),     # Bar chart
            ('ðŸ"', '📝'),     # Memo
            ('ðŸ"', '🏁'),     # Checkered flag
            ('ðŸ"¦', '📦'),     # Package
            
            # Caracteres especiales
            ('â"œâ"€', '├─'),    # Tree branch
            ('â""â"€', '└─'),    # Tree end branch
            ('Ã³', 'ó'),       # o con tilde
            ('Ã©', 'é'),       # e con tilde
            ('Ã­', 'í'),       # i con tilde
            ('Ã¡', 'á'),       # a con tilde
            ('Ã±', 'ñ'),       # eñe
            ('Ã"', 'Ó'),       # O con tilde mayúscula
            ('Ã‰', 'É'),       # E con tilde mayúscula
            ('MÃšLTIPLES', 'MÚLTIPLES'),
            ('genÃ©rico', 'genérico'),
            ('ObtenciÃ³n', 'Obtención'),
            ('ExtracciÃ³n', 'Extracción'),
            ('DetecciÃ³n', 'Detección'),
            ('ModificaciÃ³n', 'Modificación'),
            ('ValidaciÃ³n', 'Validación'),
            ('extraÃ­do', 'extraído'),
            ('FALLÃ"', 'FALLÓ'),
            ('segÃºn', 'según'),
            ('funciÃ³n', 'función'),
            ('EDICIÃ"N', 'EDICIÓN'),
            ('devolviÃ³', 'devolvió')
        ]
        
        # Aplicar todas las correcciones
        fixed_text = text
        for wrong, correct in fixes:
            fixed_text = fixed_text.replace(wrong, correct)
        
        return fixed_text


# Instancia global del formateador
response_formatter = ResponseFormatter()


# Funciones de conveniencia para acceso directo
def format_header_main_process(process_name: str, app_name: str) -> List[str]:
    """Función de conveniencia para cabecera de proceso principal"""
    return response_formatter.header_main_process(process_name, app_name)

def format_step_result(step_num: int, step_name: str, success: bool, details: str = "") -> List[str]:
    """Función de conveniencia para resultado de paso"""
    return response_formatter.step_result(step_num, step_name, success, details)

def format_microservice_detection(ms_type: str, ms_name: str, reason: str) -> List[str]:
    """Función de conveniencia para detección de microservicio"""
    return response_formatter.microservice_detection(ms_type, ms_name, reason)

def format_process_completion(process_name: str, app_name: str) -> List[str]:
    """Función de conveniencia para finalización de proceso"""
    return response_formatter.process_completion(process_name, app_name)

def format_success(context: str, details: str = "") -> str:
    """Función de conveniencia para mensaje de éxito"""
    return response_formatter.success_message(context, details)

def format_error(context: str, details: str) -> str:
    """Función de conveniencia para mensaje de error"""
    return response_formatter.error_message(context, details)

def format_warning(context: str, details: str) -> str:
    """Función de conveniencia para mensaje de advertencia"""
    return response_formatter.warning_message(context, details)

def fix_encoding(text: str) -> str:
    """Función de conveniencia para corregir encoding"""
    return response_formatter.fix_encoding_issues(text)


def format_cd_edit_summary(modified_repos: List[str], update_results: Optional[List[str]] = None) -> str:
    """
    Genera un resumen legible para la edición masiva de archivos cd.yml.

    Args:
        modified_repos: Lista de nombres de repos modificados (sin URL).
        update_results: Lista opcional con resultados detallados por repo.

    Returns:
        str: Resumen multilínea listo para mostrar en Swagger/UI.
    """
    lines: List[str] = []
    lines.append("Edicion de ficheros cd.yml")
    if modified_repos:
        lines.append(f"{ResponseFormatter.SUCCESS}Todos los repos modificados correctamente")
        lines.append("")
        lines.append("repos modificados:")
        for r in modified_repos:
            lines.append(f"{ResponseFormatter.SUCCESS}{r}")
    else:
        lines.append(f"{ResponseFormatter.WARNING} No se modificaron repos (revisa update_results para detalles)")

    # Añadir detalles si se proporcionan (opcional) y formatearlos de forma legible
    if update_results:
        lines.append("")
        lines.append("Detalles:")

        # Funciones auxiliares
        def map_env_name(env: str) -> str:
            m = env.lower()
            mapping = {
                'pre': 'dev',
                'development': 'dev',
                'cert': 'cert',
                'pro': 'pro',
                'pro-b': 'pro-b',
                'pro-g': 'pro-g'
            }
            return mapping.get(m, m)

        import re
        for item in update_results:
            try:
                s = str(item)
            except Exception:
                s = repr(item)

            # Extraer repo y mensaje
            m = re.match(r'^[^\w\d]*\s*(?:Error en\s*)?([^:]+):\s*(.*)$', s)
            if m:
                repo = m.group(1).strip()
                msg = m.group(2).strip()
            else:
                # No pudimos parsear, dejar tal cual
                lines.append(s)
                continue

            # Heurísticas para mensajes legibles
            msg_lower = msg.lower()

            # OAM repos: si no tienen .gluon/cd normalmente son saltados
            if ('no .gluon/cd' in msg_lower or 'no .gluon/cd en' in msg_lower) and ('-oam' in repo or repo.endswith('oam')):
                lines.append(f"{ResponseFormatter.WARNING} {repo}: saltado (no es CM ni micro)")
                continue

            # Si el mensaje indica que no hubo cambios útiles
            if ('contenido ya actualizado' in msg_lower or 'sin cambios' in msg_lower or 'no se detectó línea' in msg_lower or 'no se actualizaron cd.yml' in msg_lower):
                lines.append(f"{ResponseFormatter.WARNING} {repo}: Contenido ya actualizado o sin cambios")
                continue

            # Si se listan archivos actualizados, extraer entornos desde las rutas
            if 'actualizados:' in msg_lower or 'actualizados' in msg_lower:
                # Buscar patrones .gluon/cd/{env}/cd.yml
                envs = re.findall(r"\.gluon/cd/([^/]+)/cd\.yml", msg, flags=re.I)
                if envs:
                    # Mapear y deduplicar manteniendo orden
                    seen = set()
                    mapped = []
                    for e in envs:
                        me = map_env_name(e)
                        if me not in seen:
                            seen.add(me)
                            mapped.append(me)

                    # Formatear lista con comas y 'y'
                    if len(mapped) == 1:
                        joined = f".{mapped[0]}"
                    elif len(mapped) == 2:
                        joined = f".{mapped[0]} y .{mapped[1]}"
                    else:
                        joined = ', '.join(f'.{x}' for x in mapped[:-1]) + f" y .{mapped[-1]}"

                    lines.append(f"{ResponseFormatter.SUCCESS} {repo}: Actualizados: {joined}")
                    continue

            # Fallback: mostrar el mensaje original pero limpio
            lines.append(s)

    return "\n".join(lines)


class DockerEntrypointMessages:
    """Mensajes específicos para operaciones de ENTRYPOINT en Docker"""
    
    @staticmethod
    def success_updated(major_version: str) -> str:
        """Mensaje cuando ENTRYPOINT se actualiza correctamente"""
        return f"✅ DOCKERFILE ENTRYPOINT: Actualizado para Darwin v{major_version} (JarLauncher)"
    
    @staticmethod 
    def success_already_configured(major_version: str) -> str:
        """Mensaje cuando ENTRYPOINT ya está configurado"""
        return f"✅ DOCKERFILE ENTRYPOINT: Ya configurado para Darwin v{major_version} (JarLauncher)"
    
    @staticmethod
    def success_not_needed(major_version: str) -> str:
        """Mensaje cuando ENTRYPOINT no es necesario"""
        return f"✅ DOCKERFILE ENTRYPOINT: No necesario para Darwin v{major_version} (>= 4)"
    
    @staticmethod
    def warning_no_darwin_version() -> str:
        """Mensaje cuando no se puede determinar la versión Darwin"""
        return "⚠️ DOCKERFILE ENTRYPOINT: No se pudo determinar versión Darwin"
    
    @staticmethod
    def warning_no_pom() -> str:
        """Mensaje cuando no se encuentra pom.xml"""
        return "⚠️ DOCKERFILE ENTRYPOINT: No se encontró pom.xml"
    
    @staticmethod
    def warning_no_owner_repo() -> str:
        """Mensaje cuando no se puede extraer owner/repo"""
        return "⚠️ DOCKERFILE ENTRYPOINT: No se pudo extraer owner/repo"
    
    @staticmethod
    def error_processing(error_details: str) -> str:
        """Mensaje de error genérico"""
        return f"❌ DOCKERFILE ENTRYPOINT: Error - {error_details}"
    
    @staticmethod
    def error_critical(error_details: str) -> str:
        """Mensaje de error crítico"""
        return f"❌ DOCKERFILE ENTRYPOINT: Error crítico - {error_details}"


# Instancia global para mensajes de ENTRYPOINT
entrypoint_messages = DockerEntrypointMessages()