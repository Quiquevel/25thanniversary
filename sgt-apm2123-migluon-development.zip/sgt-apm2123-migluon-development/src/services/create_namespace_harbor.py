"""
Orquestador para crear namespaces de OpenShift usando la API CaaS de OHE Portal
"""
from shuttlelib.utils.logger import logger
import json
import aiohttp
import ssl
import os


async def create_namespace_orchestrator(clusters: str, appkey: str, alm_team: str, ohe_token: str, region_pre: str, entidad: str, team_alm_gluon: str = None) -> str:
    """
    Orquestador para crear namespaces de OpenShift usando la API CaaS.
    
    Args:
        clusters: Cluster objetivo (intranet, dmz, movilidad, azure) - OBLIGATORIO
        appkey: Clave de aplicación - OBLIGATORIO
        alm_team: Equipo ALM - OBLIGATORIO
        ohe_token: Token OHE - OBLIGATORIO
        region_pre: Región para preproducción - OBLIGATORIO
        entidad: Entidad (san, etc.) - OBLIGATORIO
        team_alm_gluon: Equipo ALM Gluon adicional - OPCIONAL
        
    Returns:
        str: Resultado del proceso
    """
    logger.info(f"🚀 Iniciando creación de namespace para appkey: {appkey}")
    logger.info(f"📋 Configuración - Clusters: {clusters}, ALM Team: {alm_team}, Region PRE: {region_pre}, Entidad: {entidad}")
    if team_alm_gluon:
        logger.info(f"🔧 Team ALM Gluon: {team_alm_gluon}")
    
    try:
        # Usar la función que está funcionando en el otro proyecto
        result = await _create_caas_project(
            clusters=clusters,
            appkey=appkey,
            alm_team=alm_team,
            ohe_token=ohe_token,
            region_pre=region_pre,
            entidad=entidad,
            team_alm_gluon=team_alm_gluon
        )
        
        logger.info(f"✅ Proceso completado para appkey: {appkey}")
        return result
        
    except Exception as e:
        error_msg = f"❌ Error en orquestador para appkey {appkey}: {str(e)}"
        logger.error(error_msg)
        return error_msg


async def _create_caas_project(clusters: str, appkey: str, alm_team: str, ohe_token: str, region_pre: str, entidad: str, team_alm_gluon: str = None) -> str:
    """
    Función de creación de namespace que está funcionando en el otro proyecto.
    Utiliza la API CaaS v1 con tenant ID 'san'.
    
    Args:
        clusters: Cluster objetivo (intranet, dmz, movilidad, azure)
        appkey: Clave de aplicación 
        alm_team: Equipo ALM
        ohe_token: Token de OHE
        region_pre: Región para preproducción
        entidad: Entidad (san)
        team_alm_gluon: Equipo ALM Gluon adicional (opcional)
        
    Returns:
        str: Resultado del proceso de creación
    """
    logger.info(f"🎯 Creando proyecto CaaS para appkey: {appkey}, cluster: {clusters}, entidad: {entidad}")
    if team_alm_gluon:
        logger.info(f"🔧 Team ALM Gluon adicional: {team_alm_gluon}")
    
    try:
        # URL base de la API CaaS v1 (la que está funcionando)
        base_api_url = os.getenv("API_OHE_URL", "https://gateway.apiohe.pre.cloudcenter.corp/caas/api")
        api_endpoint = clusters  # El cluster es el endpoint directo
        gateway_url = f"{base_api_url}/v1/openshift/{api_endpoint}/projects"
        
        logger.info(f"🌐 URL construida: {gateway_url}")
        
        # Generar nombres de namespace (patrón del proyecto que funciona)
        namespace_base = f"sgt-{appkey}"
        
        # Definir usuarios y grupos para el namespace
        users = {
            "admin": ["aplappshuttle"]
        }
        
        groups = {
            "developer": ["sanes_devops-developer"],
            "technical_lead": ["sanes_devops-technical-lead"]
        }
        
        # Añadir team_alm_gluon si se proporciona
        if team_alm_gluon:
            groups["alm_gluon"] = [team_alm_gluon]
        
        # Payload simplificado que está funcionando en el otro proyecto
        caas_payload = {
            "name": namespace_base,
            "displayName": f"SGT {appkey.upper()}",
            "description": f"Namespace SGT para aplicación {appkey} - Equipo ALM {alm_team}",
            "environment": "dev",  # Empezar con dev como en el proyecto que funciona
            "company": "SAN",  # Siempre SAN según el tenant
            "ownedBy": f"SGT_TO_{alm_team}",
            "usedBy": f"SGT {alm_team}",
            "members": {
                "users": users,
                "groups": groups
            },
            "quotas": {
                "requestStorage": 1,
                "memoryLimit": 1,
                "memoryRequest": 1,
                "cpuLimit": 1,
                "cpuRequest": 1,
                "persistentVolumeClaims": 1
            }
        }
        
        # Headers según la implementación que funciona
        gateway_headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': f'Bearer {ohe_token}',
            'Tenant': 'SAN',  # Tenant fijo según el proyecto que funciona
            'External-Requested-By': f'n{appkey[:6].zfill(6)}',
            'User-Agent': 'Migluon-API-Client/1.0'
        }
        
        # Configuración SSL sin proxy (funcionando)
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE
        
        connector = aiohttp.TCPConnector(
            ssl=ssl_context,
            limit=10,
            limit_per_host=5,
            keepalive_timeout=30,
            enable_cleanup_closed=True
        )
        
        timeout = aiohttp.ClientTimeout(total=60, connect=30)
        
        logger.info(f"🚀 Creando namespace {namespace_base}")
        logger.info(f"📡 Usando API CaaS v1 (funcionando)")
        logger.info(f"🔗 URL: {gateway_url}")
        logger.info(f"🎯 API Endpoint: {api_endpoint}")
        logger.info(f"🔑 Tenant: SAN")
        logger.info(f"📦 Payload: {json.dumps(caas_payload, indent=2)}")
        
        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            try:
                async with session.post(gateway_url, json=caas_payload, headers=gateway_headers) as response:
                    response_text = await response.text()
                    
                    logger.info(f"🔍 Status: {response.status}")
                    logger.info(f"📝 Response: {response_text[:500]}...")
                    
                    if response.status in [200, 201, 202]:  # Success
                        logger.info(f"✅ Éxito: Namespace {namespace_base} creado")
                        return f"✅ Namespace {namespace_base} creado exitosamente en {clusters}"
                    elif response.status == 409:  # Conflict - ya existe
                        logger.info(f"ℹ️ Namespace {namespace_base} ya existe")
                        return f"ℹ️ Namespace {namespace_base} ya existe en {clusters}"
                    elif response.status == 401:
                        logger.warning(f"🔐 Error 401: Token inválido o expirado")
                        return f"🔐 Error 401: Token inválido - Verificar autenticación"
                    elif response.status == 403:
                        logger.warning(f"⚠️ Error 403: Permisos insuficientes")
                        return f"⚠️ Error 403: Permisos insuficientes para crear namespace"
                    elif response.status == 404:
                        logger.warning(f"🔍 Error 404: Cluster no encontrado")
                        return f"🔍 Error 404: Cluster {api_endpoint} no encontrado"
                    else:
                        logger.error(f"❌ Error {response.status}: {response_text[:200]}")
                        return f"❌ Error {response.status}: {response_text[:200] if response_text else 'Sin detalles'}"
                        
            except Exception as e:
                logger.error(f"❌ Error conectando con API CaaS: {str(e)}")
                return f"❌ Error de conexión con API CaaS: {str(e)}"
                    
    except Exception as e:
        logger.error(f"❌ Error en _create_caas_project: {str(e)}")
        return f"❌ Error en creación de proyecto: {str(e)}"