"""
Sistema de logs en tiempo real para endpoints de migración.
Utiliza Server-Sent Events (SSE) para streaming de logs.
"""
import asyncio
import json
import time
from typing import Dict, List, Optional
from threading import Lock
from collections import defaultdict

class RealTimeLogs:
    """Gestor de logs en tiempo real usando Server-Sent Events."""
    
    def __init__(self):
        self._logs: Dict[str, List[Dict]] = defaultdict(list)
        self._status: Dict[str, str] = {}
        self._lock = Lock()
        
    def start_process(self, process_id: str, description: str) -> None:
        """Inicia un nuevo proceso de migración."""
        with self._lock:
            self._logs[process_id] = []
            self._status[process_id] = "running"
            self._add_log(process_id, "info", f"🚀 Iniciando: {description}")
    
    def add_log(self, process_id: str, level: str, message: str, details: Optional[Dict] = None) -> None:
        """Añade un log al proceso."""
        with self._lock:
            self._add_log(process_id, level, message, details)
    
    def _add_log(self, process_id: str, level: str, message: str, details: Optional[Dict] = None) -> None:
        """Método interno para añadir logs sin lock."""
        log_entry = {
            "timestamp": time.time(),
            "level": level,
            "message": message,
            "details": details or {}
        }
        self._logs[process_id].append(log_entry)
    
    def finish_process(self, process_id: str, success: bool, final_message: str) -> None:
        """Finaliza un proceso de migración."""
        with self._lock:
            status = "completed" if success else "failed"
            self._status[process_id] = status
            icon = "✅" if success else "❌"
            self._add_log(process_id, "info", f"{icon} {final_message}")
    
    def get_logs(self, process_id: str) -> List[Dict]:
        """Obtiene todos los logs de un proceso."""
        with self._lock:
            return self._logs.get(process_id, []).copy()
    
    def get_status(self, process_id: str) -> Optional[str]:
        """Obtiene el estado de un proceso."""
        with self._lock:
            return self._status.get(process_id)
    
    def get_latest_logs(self, process_id: str, since_timestamp: float = 0) -> List[Dict]:
        """Obtiene logs más recientes desde un timestamp."""
        with self._lock:
            logs = self._logs.get(process_id, [])
            return [log for log in logs if log["timestamp"] > since_timestamp]
    
    def cleanup_old_processes(self, max_age_hours: int = 24) -> None:
        """Limpia procesos antiguos."""
        cutoff_time = time.time() - (max_age_hours * 3600)
        with self._lock:
            to_remove = []
            for process_id, logs in self._logs.items():
                if logs and logs[-1]["timestamp"] < cutoff_time:
                    to_remove.append(process_id)
            
            for process_id in to_remove:
                del self._logs[process_id]
                self._status.pop(process_id, None)

# Instancia global del gestor de logs
realtime_logs = RealTimeLogs()