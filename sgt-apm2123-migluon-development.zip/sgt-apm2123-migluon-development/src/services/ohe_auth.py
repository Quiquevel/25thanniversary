"""
Cliente para autenticación con API-OHE Gateway según documentación oficial
"""
import aiohttp
import base64
import json
import ssl
from shuttlelib.utils.logger import logger


async def get_ohe_api_token_from_basic(basic_token: str, api_url: str) -> str:
    """
    Obtener token de acceso para API-OHE Gateway usando el token Basic del launch.json.
    
    Args:
        basic_token: Token Basic (Base64 de consumer_key:consumer_secret) desde launch.json
        api_url: URL base de la API desde launch.json
        
    Returns:
        str: Access token Bearer válido
        
    Raises:
        Exception: Si no se puede obtener el token
    """
    
    # URL del endpoint de token (directamente en la URL base, no en /caas/api)
    # Según el ejemplo: API_URL + "/token?grant_type=client_credentials"
    base_url = api_url.replace("/caas/api", "")  # Quitar /caas/api si está presente
    token_url = f"{base_url}/token"
    
    # Headers según documentación oficial
    headers = {
        'Authorization': f'Basic {basic_token}',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    
    # Body según documentación
    data = 'grant_type=client_credentials'
    
    logger.info(f"🔐 Solicitando token OAuth2 desde launch.json")
    logger.info(f"URL: {token_url}")
    logger.info(f"Basic token: {basic_token[:20]}...")
    
    # Configuración SSL sin proxy (como en create_namespace_harbor)
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    
    connector = aiohttp.TCPConnector(
        ssl=ssl_context,
        limit=10,
        limit_per_host=5,
        keepalive_timeout=30,
        enable_cleanup_closed=True
    )
    
    timeout = aiohttp.ClientTimeout(total=60, connect=30)
    
    async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
        try:
            # Usar parámetro query como en el ejemplo: ?grant_type=client_credentials
            token_url_with_params = f"{token_url}?grant_type=client_credentials"
            
            async with session.post(token_url_with_params, headers=headers) as response:
                response_text = await response.text()
                
                logger.info(f"Token request - Status: {response.status}")
                
                if response.status == 200:
                    token_data = json.loads(response_text)
                    access_token = token_data.get('access_token')
                    expires_in = token_data.get('expires_in', 3600)
                    
                    logger.info(f"✅ Token OAuth2 obtenido exitosamente")
                    logger.info(f"⏰ Expira en: {expires_in} segundos")
                    logger.info(f"🔑 Access token: {access_token[:20]}...")
                    
                    return access_token
                else:
                    logger.error(f"❌ Error obteniendo token: {response.status}")
                    logger.error(f"Response: {response_text}")
                    raise Exception(f"Error {response.status} obteniendo token: {response_text}")
                    
        except Exception as e:
            logger.error(f"❌ Error conectando para obtener token: {str(e)}")
            raise Exception(f"Error de conexión obteniendo token: {str(e)}")


async def get_ohe_api_token(consumer_key: str, consumer_secret: str, environment: str = "pre") -> str:
    """
    Obtener token de acceso para API-OHE Gateway según documentación oficial.
    
    Args:
        consumer_key: Application consumer key
        consumer_secret: Application consumer secret  
        environment: 'pre' o 'pro' (por defecto: pre)
        
    Returns:
        str: Access token Bearer válido
        
    Raises:
        Exception: Si no se puede obtener el token
    """
    
    # URL según documentación (ajustada para pre/pro)
    if environment == "pro":
        gateway_url = "https://gateway.apiohe.pro.cloudcenter.corp/token"
    else:
        gateway_url = "https://gateway.apiohe.pre.cloudcenter.corp/token"
    
    # Codificar credenciales en Base64 según documentación
    credentials = f"{consumer_key}:{consumer_secret}"
    credentials_b64 = base64.b64encode(credentials.encode()).decode()
    
    # Headers según documentación oficial
    headers = {
        'Authorization': f'Basic {credentials_b64}',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    
    # Body según documentación
    data = {
        'grant_type': 'client_credentials'
    }
    
    logger.info(f"🔐 Solicitando token OAuth2 para API-OHE Gateway ({environment})")
    logger.info(f"URL: {gateway_url}")
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post(gateway_url, headers=headers, data=data) as response:
                response_text = await response.text()
                
                logger.info(f"Token request - Status: {response.status}")
                
                if response.status == 200:
                    token_data = json.loads(response_text)
                    access_token = token_data.get('access_token')
                    expires_in = token_data.get('expires_in', 3600)
                    
                    logger.info(f"✅ Token OAuth2 obtenido exitosamente")
                    logger.info(f"⏰ Expira en: {expires_in} segundos")
                    
                    return access_token
                else:
                    logger.error(f"❌ Error obteniendo token: {response.status}")
                    logger.error(f"Response: {response_text}")
                    raise Exception(f"Error {response.status} obteniendo token: {response_text}")
                    
        except Exception as e:
            logger.error(f"❌ Error conectando para obtener token: {str(e)}")
            raise Exception(f"Error de conexión obteniendo token: {str(e)}")


async def test_ohe_token_generation():
    """
    Test para probar la generación de token según documentación
    """
    
    # Credenciales de ejemplo (tendrías que proporcionar las reales)
    consumer_key = "YOUR_CONSUMER_KEY"
    consumer_secret = "YOUR_CONSUMER_SECRET"
    
    try:
        token = await get_ohe_api_token(consumer_key, consumer_secret, "pre")
        logger.info(f"🎉 Token obtenido: {token[:20]}...")
        return token
    except Exception as e:
        logger.error(f"❌ Error en test: {str(e)}")
        return None


if __name__ == "__main__":
    import asyncio
    asyncio.run(test_ohe_token_generation())