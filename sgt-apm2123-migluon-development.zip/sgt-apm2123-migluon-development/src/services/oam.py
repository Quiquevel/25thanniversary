import os
import yaml
import json
import base64
import aiohttp
from jinja2 import Environment, FileSystemLoader, select_autoescape
from shuttlelib.utils.logger import logger
from src.utils.proxy_config import get_proxy_config

async def edit_oam_with_jinja2(
    appkey: str,
    registry_project: str,
    namespace: str, 
    clusters: str, 
    git_token: str, 
    region_pre: str, 
    url_git: str
) -> dict:
    """
    Edita el archivo oam-application-definition.yml usando plantillas Jinja2.
    Esta es la nueva implementación que reemplaza el uso de múltiples archivos YAML estáticos.
    
    Args:
        appkey (str): Clave de la aplicación.
        registry_project (str): Nombre del proyecto/registro de contenedores.
        namespace (str): Namespace base.
        clusters (str): Tipo de cluster (intranet, dmz, azure).
        git_token (str): Token de acceso a Git.
        region_pre (str): Región para el entorno (bo1, bo2, weu1, weu2).
        url_git (str): URL del repositorio Git.
        
    Returns:
        dict: Resultado de la operación con información sobre los cambios realizados.
    """
    try:
        logger.info(f"🚀 Iniciando edición de OAM con Jinja2 para namespace: {namespace}, clusters: {clusters}, region: {region_pre}")
        
        # Validar combinación de clusters y región
        valid_combinations = {
            'intranet': ['bo1', 'bo2'],
            'dmz': ['bo1', 'bo2'],
            'movilidad': ['bo1', 'bo2'],
            'azure': ['weu1', 'weu2']
        }
        
        if clusters.lower() not in valid_combinations:
            return {
                "status": "error",
                "message": f"Tipo de cluster no válido: {clusters}. Valores permitidos: {list(valid_combinations.keys())}"
            }
            
        if region_pre.lower() not in valid_combinations[clusters.lower()]:
            return {
                "status": "error", 
                "message": f"Región no válida para cluster {clusters}: {region_pre}. Valores permitidos: {valid_combinations[clusters.lower()]}"
            }
        
        # Configurar el entorno Jinja2
        template_dir = os.path.join(os.path.dirname(__file__), 'templates')
        jinja_env = Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=select_autoescape(['html', 'xml']),
            trim_blocks=True,
            lstrip_blocks=True
        )
        
        # Cargar la plantilla OAM unificada
        try:
            template = jinja_env.get_template('oam-application-definition.yml.j2')
            logger.info("✅ Plantilla Jinja2 OAM cargada correctamente")
        except Exception as e:
            return {
                "status": "error",
                "message": f"Error al cargar la plantilla Jinja2: {str(e)}"
            }
        
        # Preparar variables para el template
        # Para clusters=azure, usar la región específica (weu1/weu2) en el template
        template_clusters = region_pre.lower() if clusters.lower() == 'azure' else clusters.lower()
        
        template_vars = {
            'appkey': appkey,
            'registry': registry_project,
            'namespace': namespace,
            'clusters': clusters,
            'region_pre': region_pre.lower()
        }
        
        # Renderizar la plantilla
        try:
            rendered_content = template.render(**template_vars)
            logger.info(f"✅ Plantilla OAM renderizada correctamente ({len(rendered_content)} caracteres)")
            
            # Validar que el YAML generado sea válido
            yaml.safe_load(rendered_content)
            logger.info("✅ YAML generado es válido")
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Error al renderizar la plantilla OAM: {str(e)}"
            }
        
        # Convertir la URL de Git para trabajar con la API de GitHub
        from .common_utils import extract_repo_info
        
        try:
            owner, repo = extract_repo_info(url_git)
        except ValueError as e:
            return {
                "status": "error",
                "message": str(e)
            }
        file_path = "oam-application-definition.yml"
        api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}"
        
        # Preparar los headers para la API de GitHub
        headers = {
            "Authorization": f"token {git_token}",
            "Accept": "application/vnd.github.v3+json"
        }
        
        # Obtener el SHA del archivo actual para poder actualizarlo
        proxy_config = get_proxy_config()
        async with aiohttp.ClientSession(**proxy_config) as session:
            async with session.get(api_url, headers=headers) as response:
                if response.status != 200:
                    # Intentar parsear el body de error para extraer mensajes de GitHub (p.ej. "Bad credentials")
                    error_text = await response.text()
                    gh_msg = None
                    try:
                        error_json = json.loads(error_text)
                        gh_msg = error_json.get('message')
                        error_detail = error_json
                    except Exception:
                        error_detail = error_text

                    logger.error(f"❌ ERROR EDITANDO OAM: No se pudo obtener el archivo OAM. Status: {response.status} - {gh_msg or error_text}")
                    return {
                        "status": "error",
                        "message": f"No se pudo obtener el archivo OAM. Status: {response.status}",
                        "github_message": gh_msg,
                        "details": error_detail
                    }
                
                file_data = await response.json()
                sha = file_data.get("sha")
                
                # Preparar datos para el commit
                commit_data = {
                    "message": f"Actualizar OAM para {namespace} (clusters: {clusters}, region: {region_pre}) - Generado con Jinja2",
                    "content": base64.b64encode(rendered_content.encode()).decode(),
                    "sha": sha
                }
                
                # Realizar el commit para actualizar el archivo
                async with session.put(api_url, headers=headers, json=commit_data) as response:
                    if response.status not in [200, 201]:
                        error_text = await response.text()
                        gh_msg = None
                        try:
                            error_json = json.loads(error_text)
                            gh_msg = error_json.get('message')
                            error_detail = error_json
                        except Exception:
                            error_detail = error_text

                        logger.error(f"❌ ERROR EDITANDO OAM: Error al guardar los cambios en GitHub. Status: {response.status} - {gh_msg or error_text}")
                        return {
                            "status": "error",
                            "message": f"Error al guardar los cambios en GitHub. Status: {response.status}",
                            "github_message": gh_msg,
                            "details": error_detail
                        }
                    
                    commit_result = await response.json()
                    
                    return {
                        "status": "success",
                        "message": f"Archivo OAM actualizado correctamente con Jinja2 en el repositorio {owner}/{repo}",
                        "commit_url": commit_result.get("commit", {}).get("html_url", ""),
                        "template_engine": "Jinja2",
                        "template_vars": template_vars,
                        "clusters": clusters,
                        "region": region_pre,
                        "generated_size": len(rendered_content)
                    }
    
    except Exception as e:
        logger.error(f"❌ Error general al editar archivo OAM con Jinja2: {str(e)}")
        return {
            "status": "error",
            "message": f"Error general al editar archivo OAM con Jinja2: {str(e)}"
        }



async def edit_oam_unified(
    appkey: str,
    registry_project: str,
    namespace: str, 
    clusters: str, 
    git_token: str, 
    region_pre: str, 
    url_git: str
) -> dict:
    """
    Función para editar OAM usando plantillas Jinja2.
    Reemplaza la implementación anterior que usaba archivos YAML estáticos.
    
    Args:
        appkey (str): Clave de la aplicación.
        registry_project (str): Nombre del proyecto/registro de contenedores.
        namespace (str): Namespace base.
        clusters (str): Tipo de cluster (intranet, dmz, azure).
        git_token (str): Token de acceso a Git.
        region_pre (str): Región para el entorno (bo1, bo2, weu1, weu2).
        url_git (str): URL del repositorio Git.
        
    Returns:
        dict: Resultado de la operación.
    """
    logger.info("🆕 Editando OAM usando plantillas Jinja2")
    return await edit_oam_with_jinja2(appkey, registry_project, namespace, clusters, git_token, region_pre, url_git)