from fastapi import APIRouter, HTTPException
from fastapi.responses import PlainTextResponse, JSONResponse
from shuttlelib.utils.logger import logger
from src.services.robot_deployertoken import robot_deployertoken_service
from src.services.oam import edit_oam_unified
from src.services.back_values import update_microservice_values
from src.services.front_values import update_front_microservice_values
from src.services.configmap import configmap_service
from src.services.migration_orchestrator import migration_orchestrator
from src.services.respuestas import ResponseFormatter
from src.services.create_namespace_harbor import create_namespace_orchestrator
from src.services.ohe_auth import get_ohe_api_token_from_basic
from src.models.gitmodel import OamModel, ConfigMapModel, CombinedMigrationModel, MicroModel, AllTasksModel
from src.models.gitmodel import UpdateAllCdProjectModel, CreateNamespaceModel
from src.services.update_all_cd_orchestrator import update_all_cd_project

API_GLNTOOLS = "/api/v1/migluon"

router_parametros = APIRouter(prefix=API_GLNTOOLS)

@router_parametros.post(
    "/edit_oam", 
    description="Edit OAM file with Jinja2 templates", 
    response_description="Resumen en texto plano de lo ocurrido", 
    status_code=200,
    response_class=PlainTextResponse,
    operation_id="edit_oam_auto"
)
async def process_edit_oam(oam_data: OamModel):
    """
    Procesar edición de OAM usando plantillas Jinja2.
    """
    try:
        result = await edit_oam_unified(
            appkey=oam_data.appkey,
            registry_project=oam_data.registry_project,
            namespace=oam_data.namespace,
            clusters=oam_data.clusters,
            git_token=oam_data.git_token,
            region_pre=oam_data.region_pre,
            url_git=oam_data.url_git
        )
        
        # Manejar respuesta correctamente con iconos
        if result.get("status") == "success":
            message = result.get("message", "Archivo OAM editado correctamente")
            formatted_response = f"✅ EDICIÓN OAM COMPLETADA\n\n🎯 {message}\n\n🚀 Proceso finalizado exitosamente"
            return PlainTextResponse(content=formatted_response, status_code=200)
        else:
            # Formatear mensaje legible que incluya github_message (ej. 'Bad credentials')
            error_message = result.get("message", "Error desconocido al editar OAM")
            github_msg = result.get("github_message") or (result.get("details") or {}).get("message")
            if github_msg:
                formatted = f"❌ ERROR EDITANDO OAM: {error_message} - {github_msg}"
            else:
                formatted = f"❌ ERROR EDITANDO OAM: {error_message}"

            logger.error(f"{formatted} | full_result={result}")
            # Devolver texto plano (Swagger y cliente verán el string)
            return PlainTextResponse(content=formatted, status_code=500)
            
    except HTTPException:
        # Re-lanzar HTTPException tal como están
        raise
    except Exception as e:
        logger.error(f"Error en process_edit_oam: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error procesando edición de OAM: {str(e)}")

@router_parametros.post(
    "/robot_deployertoken",
    description="Insert existing robotaccount and password in Vault",
    response_description="Resumen en texto plano de lo ocurrido",
    status_code=200,
    response_class=PlainTextResponse,
    operation_id="robot_deployertoken_insert"
)
async def robot_deployertoken(all_tasks_model: AllTasksModel):
    """
    Procesar todas las tareas necesarias para insertar en Vault.
    """
    result = await robot_deployertoken_service(
        entidad=all_tasks_model.entidad.lower(),
        registry_project=all_tasks_model.registry_project.lower(),
        appkey=all_tasks_model.appkey.lower(),
        namespace=all_tasks_model.namespace.lower(),
        clusters=all_tasks_model.clusters.lower(),
        vault_token=all_tasks_model.vault_token
    )

    # Usar el formateador centralizado de respuestas
    formatter = ResponseFormatter()
    formatted_response = formatter.format_robot_deployertoken_response(
        result=result,
        request_data=all_tasks_model
    )
    
    return PlainTextResponse(content=formatted_response)



@router_parametros.post(
    "/combined_migration",
    description="Procesa todos los ConfigMaps y microservicios de una vez",
    response_description="Resumen en texto plano de lo ocurrido",
    status_code=200,
    response_class=PlainTextResponse,
    operation_id="combined_migration_operations"
)
async def process_combined_migration(migration_data: CombinedMigrationModel):
    """
    FLUJO COMBINADO COMPLETO con pasos adicionales que NO están en el flujo individual:
    1. Procesar ConfigMap
    2. DEPLOY del ConfigMap (solo combinado)
    3. Procesar microservicios  
    4. BACKUP del deployment.yaml (solo combinado)
    5. BORRADO del microservicio en OpenShift (solo combinado)
    """
    import time
    t_total_start = time.perf_counter()
    # PASO 1: Procesar el ConfigMap (igual que individual) + métrica
    t_cm_start = time.perf_counter()
    configmap_result = await configmap_service(
        old_name=migration_data.old_name,
        git_token=migration_data.git_token,
        url_git_cm=migration_data.url_git_cm,
        url_oam=migration_data.url_oam
    )
    t_cm_end = time.perf_counter()

    # PASO 2: DEPLOY del ConfigMap (SOLO EN FLUJO COMBINADO)
    t_deploy_start = time.perf_counter()
    deploy_result = ""
    try:
        from src.services.common_utils import trigger_configmap_deploy_workflow, extract_repo_info
        owner, repo = extract_repo_info(migration_data.url_git_cm)
        repo_info = {'owner': owner, 'repo': repo, 'branch': 'main'}
        deploy_success = await trigger_configmap_deploy_workflow(
            git_token=migration_data.git_token,
            repo_info=repo_info,
            version="0.0.0",
            environment="cert",
            environment_type="certification"
        )
        if deploy_success:
            deploy_result = "\n🚀 DESPLIEGUE DEL CONFIGMAP (SOLO FLUJO COMBINADO):\n✅ Workflow disparado exitosamente\n🔄 Continuando con el flujo (deploy ejecutándose en background)"
        else:
            deploy_result = "\n❌ No se pudo disparar el workflow de deploy"
    except Exception as e:
        deploy_result = f"\n❌ ERROR EN DEPLOY: {str(e)}"
    t_deploy_end = time.perf_counter()

    # PASO 3: Procesar microservicios (igual que individual) con UNA sesión para detecciones
    t_micro_start = time.perf_counter()
    microservices = [url.strip() for url in migration_data.url_git_micro.split(',')]
    microservices = [url for url in microservices if url.strip() != migration_data.url_git_cm.strip()]
    micro_results = []

    if microservices:
        from src.services.common_utils import extract_repo_info, get_proxy_config, detect_microservice_type
        import aiohttp
        proxy_config = get_proxy_config()
        # Reutilizamos sesión para detección de tipo (reduce overhead TCP/SSL)
        async with aiohttp.ClientSession(**proxy_config) as session:
            for micro_url in microservices:
                try:
                    owner, repo = extract_repo_info(micro_url)
                    microservice_type = await detect_microservice_type(session, owner, repo, migration_data.git_token)
                    if microservice_type == "FRONTEND":
                        result = await update_front_microservice_values(
                            old_name=migration_data.old_name,
                            git_token=migration_data.git_token,
                            url_git=micro_url,
                            url_oam=migration_data.url_oam
                        )
                    elif microservice_type == "CONFIG_MAP":
                        result = await configmap_service(
                            old_name=migration_data.old_name,
                            git_token=migration_data.git_token,
                            url_git_cm=micro_url,
                            url_oam=migration_data.url_oam
                        )
                    else:  # BACKEND por defecto
                        result = await update_microservice_values(
                            old_name=migration_data.old_name,
                            git_token=migration_data.git_token,
                            url_git=micro_url,
                            url_oam=migration_data.url_oam
                        )
                    micro_results.append(f"Microservicio {micro_url}: {result}")
                except Exception as e:
                    micro_results.append(f"Error en {micro_url}: {str(e)}")
    t_micro_end = time.perf_counter()

    # PASO 4: BACKUP Y BORRADO (SOLO EN FLUJO COMBINADO)
    t_backup_start = time.perf_counter()
    backup_delete_result = ""
    try:
        from src.services.openshift.processor import get_oam_from_git
        oam_data = await get_oam_from_git(migration_data.url_oam, migration_data.git_token) if migration_data.url_oam else None
        orchestrator = migration_orchestrator
        first_micro_url = microservices[0] if microservices else ""
        backup_success, backup_message = await orchestrator._backup_and_delete_deployment(
            old_name=migration_data.old_name,
            git_token=migration_data.git_token,
            micro_url=first_micro_url,
            oam_data=oam_data
        )
        if backup_success:
            backup_delete_result = f"✅ BACKUP Y BORRADO COMPLETADO:\n{backup_message}"
        else:
            backup_delete_result = f"❌ ERROR EN BACKUP/BORRADO:\n{backup_message}"
    except Exception as e:
        backup_delete_result = f"\n❌ ERROR CRÍTICO EN BACKUP/BORRADO: {str(e)}"
    t_backup_end = time.perf_counter()

    # Ensamblar texto (mismo formato original)
    texto = "=== MIGRACIÓN COMBINADA COMPLETA ===\n\n"
    texto += "PASO 1: PROCESAMIENTO DE CONFIGMAP\n" + "=" * 50 + "\n" + configmap_result + deploy_result + "\n\n"
    if micro_results:
        texto += "PASO 2: PROCESAMIENTO DE MICROSERVICIOS\n" + "=" * 50 + "\n" + "\n".join(micro_results) + "\n\n"
    texto += "PASO 3: BACKUP Y BORRADO (SOLO FLUJO COMBINADO)\n" + "=" * 50 + "\n" + backup_delete_result + "\n\n"

    # PASO 5 (etiquetado original como 4): DEPLOY AUTOMÁTICO A DEV
    if microservices:
        texto += "PASO 4: DEPLOY AUTOMÁTICO A DEV\n" + "=" * 50 + "\n"
        try:
            combined_results = configmap_result + "\n".join(micro_results) + backup_delete_result
            has_critical_errors = any(error_indicator in combined_results.lower() for error_indicator in [
                "❌ error crítico", "❌ configmap:", "❌ error en microservicio"
            ])
            if " ko - " in combined_results.lower():
                if not any(pattern in combined_results.lower() for pattern in ["no encontrado", "ya no existe", "posiblemente migrado"]):
                    has_critical_errors = True
            if not has_critical_errors:
                logger.info("🔍 ✅ Migración evaluada como exitosa - Iniciando deploy automático")
                pr_success, pr_message = await orchestrator._create_deployment_pull_request(migration_data.git_token, microservices)
                if pr_success:
                    texto += f"✅ DEPLOY AUTOMÁTICO INICIADO:\n{pr_message}\n🎉 MIGRACIÓN COMBINADA COMPLETADA CON DEPLOY AUTOMÁTICO\n"
                else:
                    texto += f"❌ ERROR EN DEPLOY AUTOMÁTICO:\n{pr_message}\n⚠️ MIGRACIÓN COMPLETADA PERO REQUIERE DEPLOY MANUAL\n"
            else:
                logger.warning("⚠️ Migración con errores detectados - No se realizará deploy automático")
                texto += "❌ NO SE REALIZA DEPLOY AUTOMÁTICO (ERRORES EN MIGRACIÓN)\n⚠️ Revisa los errores anteriores y realiza deploy manual si es necesario\n"
        except Exception as e:
            logger.error(f"❌ Error crítico en deploy automático: {str(e)}")
            texto += f"❌ ERROR CRÍTICO EN DEPLOY AUTOMÁTICO: {str(e)}\n⚠️ MIGRACIÓN COMPLETADA PERO REQUIERE DEPLOY MANUAL\n"
    else:
        texto += "PASO 4: DEPLOY AUTOMÁTICO OMITIDO\n" + "=" * 50 + "\n" + "❌ NO SE REALIZA DEPLOY A DEV (SIN MICROSERVICIOS)\n"

    # Métricas finales (añadidas al final para diagnóstico; mantenemos output legible)
    t_total_end = time.perf_counter()
    texto += "\n=== MÉTRICAS DE TIEMPO (diagnóstico) ===\n"
    texto += f"ConfigMap: {t_cm_end - t_cm_start:.2f}s | Deploy: {t_deploy_end - t_deploy_start:.2f}s | Microservicios: {t_micro_end - t_micro_start:.2f}s | Backup/Borrado: {t_backup_end - t_backup_start:.2f}s | Total: {t_total_end - t_total_start:.2f}s\n"

    return PlainTextResponse(content=texto)

@router_parametros.post(
    "/update_git_values", 
    description="Update git values of Backend, Frontend and ConfigMap MicroService", 
    response_description="Resumen en texto plano de lo ocurrido", 
    status_code=200,
    response_class=PlainTextResponse,
    operation_id="update_git_values_auto"
)
async def process_update_git_values(micro_data: MicroModel):
    """
    Procesar todas las tareas necesarias para la actualización de valores Git.
    """
    # LOGGING CRÍTICO: Confirmar que este endpoint NO debe ejecutar PRs
    from shuttlelib.utils.logger import logger
    logger.info("🚨 ===== PROCESO UPDATE_GIT_VALUES INICIADO =====")
    logger.info("🚨 ESTE ENDPOINT NO DEBE EJECUTAR PULL REQUESTS")
    logger.info("🚨 SOLO DEBE PROCESAR MIGRACIONES INDIVIDUALES")
    logger.info(f"🚨 Microservicio: {micro_data.url_git}")
    
    # Detectar el tipo de microservicio
    import aiohttp
    from src.utils.proxy_config import get_proxy_config
    from src.services.common_utils import detect_microservice_type, extract_repo_info
    
    proxy_config = get_proxy_config()
    
    try:
        owner, repo = extract_repo_info(micro_data.url_git)
        
        async with aiohttp.ClientSession(**proxy_config) as session:
            microservice_type = await detect_microservice_type(
                session, owner, repo, micro_data.git_token
            )
    except ValueError as e:
        return PlainTextResponse(content=f"Error: {str(e)}")
    
    # Procesar según el tipo detectado
    if microservice_type == "FRONTEND":
        result = await update_front_microservice_values(
            old_name=micro_data.old_name,
            git_token=micro_data.git_token,
            url_git=micro_data.url_git,
            url_oam=micro_data.url_oam
        )
    elif microservice_type == "CONFIG_MAP":
        result = await configmap_service(
            old_name=micro_data.old_name,
            git_token=micro_data.git_token,
            url_git_cm=micro_data.url_git,
            url_oam=micro_data.url_oam
        )
    else:  # BACKEND por defecto
        result = await update_microservice_values(
            old_name=micro_data.old_name,
            git_token=micro_data.git_token,
            url_git=micro_data.url_git,
            url_oam=micro_data.url_oam
        )
    
    # Formatear el resultado
    texto = f"Microservice Type Detected: {microservice_type}\n"
    texto += f"Processing Result:\n{result}"
    
    # LOGGING CRÍTICO: Confirmar que terminamos SIN PR
    logger.info("🚨 ===== PROCESO UPDATE_GIT_VALUES COMPLETADO =====")
    logger.info("🚨 CONFIRMADO: NO SE EJECUTÓ PULL REQUEST")
    logger.info("🚨 SI VES UNA PR DESPUÉS DE ESTO, HAY UN PROBLEMA OCULTO")
    
    return PlainTextResponse(content=texto)


@router_parametros.post(
    "/update_all_cd_proyect",
    description="Orquestador para actualizaciones los ficheros cd.yaml de todos los repositorios de un proyecto",
    response_description="Resumen en texto plano de lo ocurrido",
    status_code=200,
    response_class=PlainTextResponse,
    operation_id="update_all_cd_proyect"
)
async def process_update_all_cd_project(data: UpdateAllCdProjectModel):
    """
    Endpoint que invoca el orquestador `update_all_cd_project`.
    Entrada JSON:
    {
      "git_token": "string",
      "url_oam": "string"
    }
    """
    try:
        result = await update_all_cd_project(git_token=data.git_token, url_oam=data.url_oam)
        # formatear resultado simple
        if isinstance(result, dict):
            texto = "\n".join([f"{k}: {v}" for k, v in result.items()])
        else:
            texto = str(result)
        return PlainTextResponse(content=texto)
    except Exception as e:
        logger.error(f"Error en process_update_all_cd_project: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error procesando update_all_cd_proyect: {str(e)}")

@router_parametros.post(
    "/create_namespace", 
    description="Crear namespaces de OpenShift y registries para dev, pre y pro", 
    response_description="Resultado de la creación de namespaces y registries", 
    status_code=200,
    response_class=PlainTextResponse,
    operation_id="create_namespace"
)
async def create_namespace(data: CreateNamespaceModel):
    """
    Crear namespaces de OpenShift y registries para dev, pre y pro.
    
    🔐 AUTENTICACIÓN AUTOMÁTICA CON OAUTH2:
    El sistema utiliza automáticamente las variables de entorno del launch.json:
    - API_OHE_AUTH: Credenciales Basic (Base64 consumer_key:consumer_secret)
    - API__OHE_URL: URL base de la API
    
    El flujo es:
    1. Toma las credenciales Basic del launch.json
    2. Las usa para obtener un access_token OAuth2 válido
    3. Usa ese access_token para llamar a la API de creación de namespaces
    
    📋 Entrada JSON (todos los parámetros son obligatorios):
    {
      "clusters": "intranet",
      "appkey": "123456", 
      "alm_team": "mi_equipo",
      "region_pre": "bo2",
      "entidad": "san"
    }
    
    🎯 El sistema creará automáticamente namespaces en:
    - DEV: Para desarrollo
    - PRE: Para preproducción  
    - PRO: Para producción (bo1 y bo2)
    """
    try:
        import os
        
        # Obtener credenciales Basic y URL desde variables de entorno
        basic_token = os.getenv("API_OHE_AUTH")
        api_url = os.getenv("API_OHE_URL")
        
        # Validar que tenemos las variables de entorno necesarias
        if not basic_token:
            error_msg = "❌ Error: Variable de entorno 'API_OHE_AUTH' no encontrada en launch.json"
            logger.error(error_msg)
            return PlainTextResponse(content=error_msg, status_code=500)
            
        if not api_url:
            error_msg = "❌ Error: Variable de entorno 'API__OHE_URL' no encontrada en launch.json"
            logger.error(error_msg)
            return PlainTextResponse(content=error_msg, status_code=500)
        
        logger.info(f"🔐 Obteniendo token OAuth2 usando credenciales del launch.json")
        logger.info(f"🌐 API URL: {api_url}")
        
        # Obtener token de acceso real usando las credenciales Basic
        try:
            access_token = await get_ohe_api_token_from_basic(basic_token, api_url)
            logger.info(f"✅ Token de acceso obtenido exitosamente")
        except Exception as token_error:
            error_msg = f"❌ Error obteniendo token OAuth2: {str(token_error)}"
            logger.error(error_msg)
            return PlainTextResponse(content=error_msg, status_code=500)
        
        # Ejecutar orquestador con token de acceso válido
        result = await create_namespace_orchestrator(
            clusters=data.clusters,
            appkey=data.appkey,
            alm_team=data.alm_team,
            ohe_token=access_token,
            region_pre=data.region_pre,
            entidad=data.entidad,
            team_alm_gluon=data.team_alm_gluon
        )
        return PlainTextResponse(content=result)
        
    except Exception as e:
        logger.error(f"Error en create_namespace: {str(e)}")
        error_msg = f"❌ Error creando namespace: {str(e)}"
        return PlainTextResponse(content=error_msg, status_code=500)
