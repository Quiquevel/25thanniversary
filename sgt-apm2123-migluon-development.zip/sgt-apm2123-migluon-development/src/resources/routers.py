from src.handler.external_requests import *
from darwin_composer.DarwinComposer import RouteClass


routers = [
    RouteClass(router_parametros, ["Github"]),
]