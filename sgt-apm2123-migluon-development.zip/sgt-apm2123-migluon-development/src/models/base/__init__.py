"""
Módulo base para todos los modelos.
"""
from pydantic import BaseModel as _BaseModel

class BaseModel(_BaseModel):
    """Modelo base que hereda de Pydantic BaseModel."""
    pass