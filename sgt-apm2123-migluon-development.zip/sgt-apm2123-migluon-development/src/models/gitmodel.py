from pydantic import BaseModel
from typing import Optional

class HarborModel(BaseModel):
    appkey: str
    REGISTRY_USERNAME_DEV: str
    REGISTRY_PASS_DEV: str  
    REGISTRY_USERNAME_PRE: str
    REGISTRY_PASS_PRE: str
    REGISTRY_USERNAME_PRO: str
    REGISTRY_PASS_PRO: str

class RobotModel(BaseModel):
    appkey: str
    registry_project: str
    vault_token: str
    clusters: str

class DespliegueTokenRequest(BaseModel):
    namespace: str = "sanes-namespace"
    clusters: str  # intranet, dmz, azure, mov

class AllTasksModel(BaseModel):
    entidad: str = "san"
    registry_project: str = "sanes-project-san"
    appkey: str
    namespace: str = "sanes-namespace"
    clusters: str
    vault_token: str

class OamModel(BaseModel):
    appkey: str
    registry_project: str = "sanes-project-san"
    namespace: str = "sanes-namespace"
    clusters: str
    git_token: str
    region_pre: str
    url_git: str

class MicroModel(BaseModel):
    old_name: str
    git_token: str
    url_git: str
    url_oam: str

class ConfigMapModel(BaseModel):
    old_name: str
    git_token: str
    url_git_cm: str
    url_oam: str

class CombinedMigrationModel(BaseModel):
    """
    Modelo para operaciones combinadas de migración.
    Procesa ConfigMap primero, luego microservicios automáticamente.
    """
    old_name: str
    git_token: str
    url_git_cm: str      # URL del repositorio ConfigMap
    url_git_micro: str   # URL(s) del/los repositorio(s) de microservicios (separadas por comas si son múltiples)
    url_oam: str

class MigrationStatusResponse(BaseModel):
    """Respuesta del estado de una migración en tiempo real."""
    process_id: str
    status: str  # running, completed, failed
    progress_percentage: int
    current_step: str
    total_steps: int
    started_at: float
    estimated_completion: float = None

class LogEntry(BaseModel):
    """Entrada individual de log."""
    timestamp: float
    level: str  # info, warning, error, success
    message: str
    details: dict = {}

class LogsResponse(BaseModel):
    """Respuesta con logs de un proceso."""
    process_id: str
    status: str
    logs: list[LogEntry]
    has_more: bool = False


class UpdateAllCdProjectModel(BaseModel):
    """Modelo para el endpoint update_all_cd_proyect."""
    git_token: str
    url_oam: str

class CreateNamespaceModel(BaseModel):
    """
    Modelo para crear namespaces de OpenShift y registries para dev, pre y pro.

    """
    # === PARÁMETROS OBLIGATORIOS ===
    clusters: str      # intranet, dmz, movilidad, azure (determina cluster específico)
    appkey: str        # Clave de aplicación (forma parte del nombre del namespace)
    alm_team: str      # Equipo ALM (define grupos de permisos)
    region_pre: str    # bo1/bo2 para On-premise, weu1/weu2 para Azure (obligatorio para cluster PRE)
    entidad: str = "san"      # Entidad como san, etc. (forma parte del nombre del namespace)
    # === PARÁMETROS OPCIONALES ===
    team_alm_gluon: Optional[str] = None  # Equipo ALM Gluon adicional (se añade a los grupos)