"""
Módulo de cliente OpenShift centralizado.
Proporciona una instancia única para todo el microservicio.
"""
from shuttlelib.openshift.client import OpenshiftClient
from shuttlelib.utils.logger import logger

# Variable para la instancia única (inicialización lazy)
_ocp_client_instance = None

def _get_ocp_client():
    """Crea la instancia única de OpenShift client (lazy loading)."""
    global _ocp_client_instance
    if _ocp_client_instance is None:
        try:
            logger.info("Inicializando OpenShift client único (ocplib)")
            _ocp_client_instance = OpenshiftClient(entity_id="spain")
            logger.info("✅ OpenShift client inicializado correctamente")
        except Exception as e:
            logger.error(f"❌ Error inicializando OpenShift client: {e}")
            raise
    return _ocp_client_instance

# Propiedad que actúa como una instancia pero se crea bajo demanda
class _OCPClientProxy:
    """Proxy que crea el cliente solo cuando se accede por primera vez."""
    def __getattr__(self, name):
        client = _get_ocp_client()
        return getattr(client, name)
    
    def __call__(self, *args, **kwargs):
        client = _get_ocp_client()
        return client(*args, **kwargs)

# Esta es la instancia que se exporta - se comporta como OpenshiftClient pero con lazy loading
ocpClient = _OCPClientProxy()