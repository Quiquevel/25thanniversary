"""
Configuración de proxy para todas las peticiones HTTP externas.
Centraliza la configuración del proxy para GitHub y otros servicios externos.
"""
import os
from typing import Optional, Dict, Any
import aiohttp


def get_proxy_url() -> Optional[str]:
    """
    Obtiene la URL del proxy desde las variables de entorno.
    
    Returns:
        URL del proxy si está configurada, None en caso contrario
    """
    # Priorizar git_proxy como variable principal
    proxy_url = os.getenv("git_proxy")
    if proxy_url:
        return proxy_url
    
    # Fallback a otras variables de proxy comunes
    for proxy_var in ["PROXY", "HTTP_PROXY", "http_proxy"]:
        proxy_url = os.getenv(proxy_var)
        if proxy_url:
            return proxy_url
    
    return None


def get_proxy_config() -> Dict[str, Any]:
    """
    Obtiene la configuración completa del proxy para aiohttp.ClientSession.
    
    Returns:
        Diccionario con configuración del proxy para aiohttp
    """
    proxy_url = get_proxy_url()
    
    if proxy_url:
        return {
            "proxy": proxy_url,
            "proxy_auth": None  # Añadir autenticación si es necesaria
        }
    
    return {}


def create_session_with_proxy(**kwargs) -> aiohttp.ClientSession:
    """
    Crea una sesión aiohttp con configuración de proxy automática.
    
    Args:
        **kwargs: Argumentos adicionales para ClientSession
        
    Returns:
        ClientSession configurada con proxy si está disponible
    """
    proxy_config = get_proxy_config()
    
    # Combinar configuración del proxy con argumentos adicionales
    session_config = {**proxy_config, **kwargs}
    
    return aiohttp.ClientSession(**session_config)


async def create_session_context_with_proxy(**kwargs):
    """
    Crea un context manager para sesión aiohttp con proxy.
    
    Args:
        **kwargs: Argumentos adicionales para ClientSession
        
    Returns:
        Context manager para ClientSession con proxy
    """
    proxy_config = get_proxy_config()
    session_config = {**proxy_config, **kwargs}
    
    return aiohttp.ClientSession(**session_config)


# Para retrocompatibilidad y debugging
def get_proxy_info() -> Dict[str, Any]:
    """
    Obtiene información de debug sobre la configuración del proxy.
    
    Returns:
        Información del proxy para debugging
    """
    proxy_url = get_proxy_url()
    
    # Determinar la fuente del proxy
    proxy_source = "none"
    if proxy_url:
        if os.getenv("git_proxy") == proxy_url:
            proxy_source = "git_proxy"
        elif os.getenv("PROXY") == proxy_url:
            proxy_source = "PROXY"
        elif os.getenv("HTTP_PROXY") == proxy_url:
            proxy_source = "HTTP_PROXY"
        elif os.getenv("http_proxy") == proxy_url:
            proxy_source = "http_proxy"
        else:
            proxy_source = "unknown"
    
    return {
        "proxy_configured": proxy_url is not None,
        "proxy_url": proxy_url,
        "proxy_source": proxy_source
    }
