# Darwin Microservice for python

## Index
<!-- TOC -->

- [Darwin Microservice for python](#darwin-microservice-for-python)
  - [Index](#index)
  - [1. Execution of the Local Microservice (non-IDE)](#1-execution-of-the-local-microservice-non-ide)
  - [2. Microservice Configuration](#2-microservice-configuration)
  - [3. Microservice dependencies](#3-microservice-dependencies)
  - [4. Darwin](#4-darwin)
    - [i. Use of Darwin components](#i-use-of-darwin-components)
      - [a) Logs](#a-logs)
      - [b) Traceability](#b-traceability)
      - [c) Endpoint exclusion of the security component](#c-endpoint-exclusion-of-the-security-component)
      - [d) Exceptions](#d-exceptions)
  - [5. Building an API Rest](#5-building-an-api-rest)
    - [i. Development and registration of controllers](#i-development-and-registration-of-controllers)
    - [ii. API versioning](#ii-api-versioning)
      - [iii. Controllers documentation and API exposure in Openapi](#iii-controllers-documentation-and-api-exposure-in-openapi)
        - [OpenAPI Documentation](#openapi-documentation)
        - [OpenAPI Specification](#openapi-specification)
  - [6. Code test](#6-code-test)
  - [7. Santander trusted certificates **IMPORTANT**](#7-santander-trusted-certificates-important)
  - [8. Docker ENTRYPOINT Automation for Darwin Framework](#-docker-entrypoint-automation-for-darwin-framework)
    - [i. Automatic Darwin Version Detection](#automatic-darwin-version-detection)
    - [ii. Darwin Version-Based ENTRYPOINT Management](#darwin-version-based-entrypoint-management)
    - [iii. Implementation Details](#implementation-details)
  - [9. Migration Services and Automatic Deployment](#-migration-services-and-automatic-deployment)
    - [Performance Optimizations v2.6.0](#performance-optimizations-v260)
    - [Template System Improvements](#template-system-improvements)
    - [GitHub API Optimizations](#github-api-optimizations)
    - [Funcionalidades Avanzadas de Automatización](#funcionalidades-avanzadas-de-automatización)
    - [Troubleshooting y Mejores Prácticas](#-troubleshooting-y-mejores-prácticas)
    - [Changelog de Funcionalidades Recientes](#changelog-de-funcionalidades-recientes)

<!-- /TOC -->

## 1. Execution of the Local Microservice (non-IDE)

The following command allows the microservice to be run locally from a shell or a CMD

````commandline
pipenv run python -m asgi
````

Once the service has been lifted it is possible to send requests via CURL:

CURL:

````commandline
curl --location --request GET 'http://127.0.0.1:8080/v1/regards/hello_world' \
--header 'x-b3-traceid: f32197c9a3cb99f7' \
--header 'app-init: app-init' \
--header 'contact-point: contact-point' \
--header 'session-id: session' \
--header 'x-clientId: cliente' \
--header 'x-santander-channel: channel' \
--header 'Authorization: Bearer [TOKEN-JWT]'
````

**Tip**: Sending a request to the microservice requires a valid Bearer [TOKEN-JWT] for some endpoints.

## 2. Microservice Configuration

The microservice configuration is carried out through kubernetes ConfigMaps. A ConfigMap is a dictionary of key-value pairs that can be used to configure the microservice. The content of the ConfigMap must be using environment variables in the microservice. The ConfigMap is referenced in the deployment.yaml file of the microservice.
For more information about ConfigMaps, please visit the [official documentation](https://kubernetes.io/docs/tasks/configure-pod-container/configure-pod-configmap/#configure-all-key-value-pairs-in-a-configmap-as-container-environment-variables).

## 3. Microservice dependencies

As a dependency manager we use [Pipenv](https://pipenv-es.readthedocs.io/es/latest/).
All package dependencies must be in the locked versions and included in the Pipfile files. They must be placed under **packages** section.

Example of the file ```Pipfile```

```yml
[[source]]
name = "pypi"
url = "https://nexus.alm.europe.cloudcenter.corp/repository/pypi-public/simple"
verify_ssl = false

[packages]
fastapi-health = "~=0.4.0"
pytest = "~=8.1.1"
```

> Is not recommended to use * as version in the dependencies, because it can cause problems in the future.

## 4. Darwin

Darwin is a component that helps us to encapsulates the traceability, logging, security and error management components
in a single class to be integrated all together in FastAPI microservices.

### i. Use of Darwin components

#### a) Logs

In order to use the darwinLogging component, the darwin_logging module must be imported and the FastAPI app object passed to it following form:

````python
import logging
from fastapi import FastAPI # main.py
"""Importing Logging component"""
from darwin_logging.DarwinLogs import DarwinLogs

log = logging.getLogger("app logger")

"""Creating FastAPI application"""
app = FastAPI(title=__name__)

"""Initializing logging component"""
DarwinLogs(app) # the application object of fastapi is introduced by the component.

"""Printing logs"""
log.info("This function is amazing")
log.debug("This function is amazing")
log.error("This function is amazing")
log.info({'dict': True, 'number_test': 1})
log.debug({'dict': True, 'number_test': 1})
log.error({'dict': True, 'number_test': 1})

````

> In order to print debug traces you must to set the environment variable LOG_LEVEL to debug value

#### b) Traceability

The traceability component automatically processes the entry request heads and stores them in a form temporary while the request is active and at the end it returns them to the response heads in case of any of them it would have been amended.

For exit requests from the microservice it is necessary to use a handler which automatically grazes the heads to be propagated.

In order to make any request to exit from the microservice, the module request_handler of the following must be imported

```request_frommicro.py```

````python
from darwin_logging import make_request # request_frommicro.py

def callingOtherMicro():
  url = "http://example.com"
  headers = { "my_header": "hello_world" }

  response = make_request(method = 'GET', url = url, headers = headers) # example of GET    
  
  response = make_request(method = 'POST', json = { "data": "data" }, url = url, headers = headers) # example of POST
  
  return response
````

#### c) Endpoint exclusion of the security component

To include endpoints within the whitelist it is necessary to include the lower case name of the function or class that defines the endpoint in the micro-service configuration.
Example:

```python
import os
from fastapi import FastAPI
from src.darwin_token_validation import DarwinTokenValidation

app = FastAPI(title="FastAPI")

os.environ["DARWIN_SECURITY_WHITE_LIST"] = '["/hello_word"]' #<-- include in the configuration of the microservice the name of the operation path that defines the endpoint.

DarwinTokenValidation(app)

@app.get("/hello_world")
@app.post("/hello_world")
async def main(): #<-- Function defining the endpoint without authorization
    return {"response" : "Hello, World!",
            "method" : "GET/POST"}

```

**Note**:

If you also want to particularize at method level (GET, POST, PUT, etc.), add the method in capital letters as a key-value option as follows:

Example:

```python

os.environ["DARWIN_SECURITY_WHITE_LIST"] = "[{'path' : '/hello_world' , 'method' : 'GET'}]" #<-- Only THE GET method of the hello_world endpoint would be included.

```

#### d) Exceptions

DarwinException also provides a generic exception for the web applications that correspond to various errors.

Most common TPs:

- ***DarwinException***: The DarwinException serves as a comprehensive exception handler designed to address unclassified exceptions within our application. It encapsulates various forms of error exceptions, ensuring robust error handling and facilitating resilience, flexibility and maintainability.

The `DarwinException` accept 6 types of optional parameters:

- ***error_name*** (str): Error name appropriate for the exception to be handled. (Tip): It result to the class Exception name raised as default if no value is provided.
- ***status_code*** (str): Status code of the response to return.
- ***internal_code*** (int): Internal code chosen by the user.
- ***short_message*** (any): Brief error message.
- ***detailed_message*** (str): Detailed error message.
- ***map_extended_messaged*** (dict): Custom field in dictionary format.

In order to use the darwin exception, it is necessary to import the darwin_exception module and to launch the exception via a raise statement.

Example:

````python
from darwin_error_handler.darwin_exception import DarwinException

def requestFormatIsOk(request):
    if hasattr(request, "headers"):
        pass
    else:
        # Exception without optional parameters
        raise DarwinException() 
    if hasattr(request, "payload"):
        pass
    else:
        # Exception with optional parameters
        raise DarwinException(error_name="BadRequestDarwinException", status_code=400, internal_code=-3, short_message="Bad Request", detailed_message="The request must contain the payload attribute", map_extended_messaged={})
````

In the first case for Exception without optional parameters, we will receive the following error response:

Darwin Format

```json
{
    "appName": "PythonTest",
    "timeStamp": "2024-04-22T08:49:53.615479",
    "errorName": "DarwinException",
    "internalCode": -1,
    "shortMessage": "None",
    "detailedMessage": "None",
    "mapExtendedMessaged": {},
    "status": 500
}
```

Gluon Format

```json
{
    "errors":[{    
        "code": 500,
        "description": "None",
        "level": "error",
        "message": "2024-04-22T08:49:53.615479-PythonTest-DarwinException-None"
    }]
}
```

In the second case for Exception with optional parameters, we will receive the following error response:

Darwin Format

```json
{
    "appName": "PythonTest",
    "timeStamp": "2024-04-22T08:59:53.823352",
    "errorName": "BadRequestDarwinException",
    "internalCode": -3,
    "shortMessage": "Bad Request",
    "detailedMessage": "The request must contain the payload attribute",
    "mapExtendedMessaged": {},
    "status": 400
}
```

Gluon Format

```json
{
    "errors":[{    
        "code": 400,
        "description": "Bad Request",
        "level": "error",
        "message": "2024-04-22T08:59:53.823352-PythonTest-BadRequestDarwinException-The request must contain the payload attribute"
    }]
}
```

#### e) Composer

The previous functionalities and capabilities are collected insde the `Darwin Composer` library. The `Darwin Composer`automatically enables said functionalities, *logging*, *security*, *traceability* and *exceptions*; and also configures other capabilities such as:

- Health check endpoint
- [OpenAPI documentation](#openapi-documentation)
- [CORS](https://fastapi.tiangolo.com/tutorial/cors/) middleware
- [Routing](#i-development-and-registration-of-controllers)

The `Darwin Composer` accepts 3 required parameters:

- **app**: A FastAPI instance
- **config**: A JSON object with configuration parameters
- **routes**: A list of RoteClass objects

The **config** object has the following parameters:

| Name                   | Description                                                                   | Type    | Default value     |
|------------------------|-------------------------------------------------------------------------------| ------- | ------------------|
| version                | Version of the microservice. Should be imported from your version.py file.    | {Str}   | "0.0.0"           |
| cors.enable            | Enables/disables cors middleware.                                             | {Bool}  | True              |
| openapi.enable         | Enables/disables custom openapi documentation.                                | {Bool}  | True              |
| openapi.title          | Title of the microservice to show in docs.                                    | {Str}   | "FastAPI Restful Swagger Demo" |
| openapi.description    | Description of the microservice to show in docs.                              | {Str}   | "A Demo for the FastAPI-Restful Swagger Demo" |
| openapi.contact.name   | Name of the author/maintainer of the microservice.                            | {Str}   | "-"              |
| openapi.contact.url    | Contact information url/email.                                                | {Str}   | "-"              |
| i18n.enable            | Enables/disables i18n middleware. It will override configuration made through environment variables. | {Bool}  | False             |
| i18n.fallback          | Fallback language for internationalization.                                   | {Str}   | "en"              |

> [!WARNING]  
> For Internationalization to work, translation files must be set, Eg. `es.json`
> The default location of these files is `/etc/i18n/locales`. This location can be set through environment variables.
> Check the Darwin documentation for more information.

Here is an example of a *config* object:

```python

from version import __version__

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "Some App",
          "description": "It does some cool stuff",
          "contact": {
               "name": "myName",
               "url": "myurl"
          }
     },
     "i18n": {
          "enable": True,
          "fallback": "en",
     }
}
```

The **RouteClass** class is also imported from `Darwin Composer`. Its use is further explained [here](#i-development-and-registration-of-controllers).

Here is an example on how to use the **DarwinComposer** class, having imported both the **config** object and the **routers** list from different files.

```python
from fastapi import FastAPI
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers
from src.app.config.composer_config import config as composer_config

app = FastAPI()

DarwinComposer(app, config=composer_config, routers=routers)
```

## 5. Building an API Rest

To build a Rest API, the APIRouter class will be used, which allows the controllers to be grouped into routers by doing
the most modular, straightforward and simple development. In addition, the design will adhere to the structure of guidelines defined by the archetype.

### i. Development and registration of controllers

The definition of the routes that make up the controllers will be carried out within the sub-directory **resources**, grouping them together
By affinity, for example, if two controllers were created, named *HelloWorld* and *helloMoon*, it would make sense
they were grouped into a file called regards.

The following steps are required to define the controllers:

1. Import the APIRouter class from the *fastapi* library.
2. Create the router object from the APIRouter class.
3. Decorate the path operation functions defined with the router object and also specify the resource path.

Example.

```regards.py```

```python

from fastapi import APIRouter

HelloWorldRouter = APIRouter()

@HelloWorldRouter.get("/hello_world")
def get_message():
  pass

@HelloWorldRouter.post("/hello_world")
def post_message():
  pass


HelloMoonRouter = APIRouter()
```

Once the routers and path operation functions have been created, they must be registered in the *main* of the application following
the following steps:

1. Import all ofthe Router definitions in a *routers.py* file
2. Import the RouterClass from darwin_composer
3. Create a list of RouteClass with all your Router definitions. Indicate the tag section groups the routers belong. This provides enhanced readability and navigation of the API documentation.
4. Import the routers list in the *main.py* file and feed it into the composer.

Example:

```python
from .regards import HelloWorldRouter, HelloMoonRouter
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(HelloWorldRouter, ["QA", "REGARDS"]),
    RouteClass(HelloMoonRouter, ["QA", "REGARDS"])
]

```

```python
from fastapi import FastAPI
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers
from src.app.config.composer_config import config as composer_config

app = FastAPI()

DarwinComposer(app, config=composer_config, routers=routers)
```

### ii. API versioning

It is important to maintain control of API versions in order for there to be retrocompatibility. In this way, the old versions of the API, with the new versions, are accessible. For this purpose, it is recommended that the path of the api be set as follows:

*/{version}/{api-id}/{path_to_resource}

- {version}: api version
- {api-id}: identifies the api among all those exposed in a Gateway
- {path_to_resource}: rest of the path to the api resource to invoke

#### iii. Controllers documentation and API exposure in Openapi

The microservice offers a highly efficient development experience with automatic generation of OpenAPI documentation, made possible with it integration with Pydantic and FastAPI for data validation and serialization. Describing the API documentation is facilitated by defining Pydantic class models and this will be carried out within the sub-directory **docs** . This approach ensures clarity and coherence in the API documentation.

##### OpenAPI Documentation

The microservice automatically generates detailed documentation for your API endpoints based on the defined route handlers and Pydantic models. This documentation is available in two formats:

1. **Swagger UI (Docs Path)**: It generates an interactive Swagger UI interface at `/docs`, allowing for exploration and testing of the API endpoints directly from their web browser.
2. **ReDoc (ReDoc Path)**: Additionally, It generates a clean and user-friendly ReDoc interface at `/redoc`, providing a structured view of the API documentation for better readability and navigation.

##### OpenAPI Specification

It also generates the OpenAPI schema in JSON format, which is available at `/openapi.json`.

**Example of using Pydantic models for each defined route handler.**

Python file where the specifications of the POST method of the helloWorld controller are defined

> docs/openapi/helloPOST.py

```python
""" Make the sum of two numbers. """

from pydantic import BaseModel, Field

class SumRequest(BaseModel):
    number_a: int = Field(json_schema_extra={"description":"integer number",'examples': [1]})
    number_b: int = Field(json_schema_extra={"description":"integer number",'examples': [2]})

class SumResponse(BaseModel):
    operation: str = Field(json_schema_extra={"description":"operation performed with both numbers",'examples': ['sum']})  
    number_a: int = Field(json_schema_extra={"description":"integer number",'examples': [1]})
    number_b: int = Field(json_schema_extra={"description":"integer number",'examples': [2]})
    result: int = Field(json_schema_extra={"description":"The result of the sum",'examples': [3]})

```

Importing the python file to the POST method of the helloWorld controller

```python
import logging
from fastapi import APIRouter
from docs.openapi.helloPOST import SumResponse, SumRequest

logger = logging.getLogger(__name__)

HelloWorldRouter = APIRouter()

@HelloWorldRouter.post("/v1/regards/hello_world",response_model=SumResponse)
async def sum_numbers(request:SumRequest):
    """
    POST method for the helloWorld endpoint.
    """

    logger.info("Calling to Hello World Sum Service")
    result = hello_world_sum(request.number_a, request.number_b)

    return JSONResponse(content={
                                    "operation": "sum",
                                    "number_a": request.number_a,
                                    "number_b": request.number_b,
                                    "result": result
                                }, status_code=200)

```

The result in swagger ui is as follows:

<p align="center">
<img src="./images/U.JPG" alt="U" width="800"/>
</p>

> It is very important to include the `Pydantic class models` in the `path operations / function parameters`.

## 6. Code test

To perform the unit tests defined in each microservice, whether or not they are event-based microservices,
the following command must be executed

````commandline
pipenv run python -m pytest
````

## 7. Santander trusted certificates **IMPORTANT**

The certificate is signed by the Issuing Certificate authority, and this it what guarantees the keys. Now when someone wants your public keys, you send them the certificate, they verify the signature on the certificate, and if it verifies, then they can trust your keys.

To consume some of our services we need to add ```SANTANDER_CA_CERTS.pem``` to python as a trusted certificates. We are going to explain how to add it to *Python* in your computer.

* Locate ```SANTANDER_CA_CERTS.pem``` in a directory on your computer, by example:

    ```sh
    C:\Users\x264489\SANTANDER_CA_CERTS.pem
    ```

* Add the certificate path to Python envinroment typing the following comands:

    ```sh
    $  SETX SSL_CERT_FILE "C:\Users\x264489\SANTANDER_CA_CERTS.pem"
    $  SETX REQUESTS_CA_BUNDLE "C:\Users\x264489\SANTANDER_CA_CERTS.pem"
    ```

That's all

> The Santander Docker Python image contains our Certificate, by this reason we dont have to do anything.
> This step is very important because if you dont do this you cannot consume Santander Services.

## � Docker ENTRYPOINT Automation for Darwin Framework

This microservice includes **intelligent ENTRYPOINT management** for Docker containers based on Darwin Framework versions:

### Automatic Darwin Version Detection

The service automatically detects Darwin Framework versions from `pom.xml` files with enhanced reliability:

#### Supported Detection Patterns:
- ✅ **Multiple GroupId Formats**: `es.santander.darwin` and `com.santander.darwin`
- ✅ **Version Formats**: `3.1.0-RELEASE`, `6.3.2`, `4.2.1`, etc.
- ✅ **Fallback Detection**: Searches in dependencies if parent block is not available
- ✅ **Robust Parsing**: 3 primary patterns + 2 fallback patterns for maximum compatibility

#### Darwin Version-Based ENTRYPOINT Management:

| Darwin Version | ENTRYPOINT Behavior | Action |
|---------------|-------------------|---------|
| **< v4.0** | 🔄 **Requires JarLauncher** | Updates ENTRYPOINT to: `["sh", "-c", "java ${JAVA_OPTS_EXT} org.springframework.boot.loader.JarLauncher $JAVA_PARAMETERS ${@}"]` |
| **>= v4.0** | ✅ **No Changes Needed** | Maintains existing ENTRYPOINT (already compatible) |

#### Smart Processing Features:
- 🔍 **Automatic Detection**: Extracts Darwin version from `pom.xml` parent blocks
- 🧠 **Version Intelligence**: Compares major version numbers for compatibility decisions  
- 📝 **Centralized Messaging**: Consistent status messages through `DockerEntrypointMessages` class
- 🔒 **Safe Operations**: Only modifies ENTRYPOINT when necessary for backward compatibility
- 📊 **Detailed Logging**: Comprehensive debug information for troubleshooting

#### Status Messages:
- `✅ DOCKERFILE ENTRYPOINT: Actualizado para Darwin v3 (JarLauncher)` - Updated for older Darwin
- `✅ DOCKERFILE ENTRYPOINT: Ya configurado para Darwin v3 (JarLauncher)` - Already configured
- `✅ DOCKERFILE ENTRYPOINT: No necesario para Darwin v6 (>= 4)` - Modern Darwin, no changes needed
- `⚠️ DOCKERFILE ENTRYPOINT: No se pudo determinar versión Darwin` - Version detection failed (non-critical)

### Implementation Details:

#### Core Functions:
```python
# Enhanced version detection with multiple patterns
extract_darwin_version_from_pom(pom_content: str) -> Optional[str]

# Major version extraction for compatibility decisions  
extract_darwin_major_version(version_string: str) -> Optional[str]

# Automatic ENTRYPOINT update based on Darwin version
update_dockerfile_entrypoint_for_darwin_version(github_client, owner, repo, darwin_version) -> dict
```

#### Centralized Message System:
```python
# Consistent messaging through DockerEntrypointMessages class
from src.services.respuestas import entrypoint_messages

# Usage examples:
entrypoint_messages.success_updated("3")           # Success with update
entrypoint_messages.success_not_needed("6")        # Modern Darwin, no update needed
entrypoint_messages.warning_no_darwin_version()    # Version detection failed
```

This automation ensures seamless Docker container compatibility across different Darwin Framework versions without manual intervention.

## �🚀 Migration Services and Automatic Deployment

This microservice provides automated migration services with integrated deployment capabilities:

### Performance Optimizations v2.6.0

#### 🚀 HTTP Session Reuse & Batch Operations

El sistema ha sido optimizado significativamente para mejorar el rendimiento y reducir la latencia:

**Session Pooling**:
- ✅ **Una sola sesión HTTP** para todo el flujo de migración
- ✅ **Reducción del 40%** en tiempo total de ejecución
- ✅ **Eliminación de overhead** de conexión/desconexión repetitiva
- 🔧 **Implementación**: `aiohttp.ClientSession` reutilizada a través de todo el proceso

**Batch Commits con GitHub Tree API**:
- ✅ **Commits atómicos** de múltiples archivos en una sola transacción
- ✅ **Reducción del 60%** en número de requests a GitHub API
- ✅ **Menor consumo** de rate limits de GitHub
- 🔧 **Función**: `batch_update_files()` para operaciones masivas

```python
# Ejemplo de optimización implementada:
# ANTES: 3 commits separados + 3 conexiones HTTP
# DESPUÉS: 1 commit atómico + 1 conexión HTTP reutilizada

async with aiohttp.ClientSession() as session:
    changes = await prepare_all_file_changes(session, files)
    result = await batch_update_files(session, changes)  # Una sola operación
```

### Template System Improvements

#### 🛠️ Eliminación de Fallbacks y Preservación Completa

**Problemas resueltos**:
- ❌ **Fallbacks hardcodeados** que perdían configuraciones de health checks
- ❌ **Parsing selectivo** en actualizaciones que omitía configuraciones críticas
- ❌ **URLs .git** causando errores en GitHub API

**Soluciones implementadas**:
- ✅ **Sin fallbacks**: Errores visibles para debugging efectivo
- ✅ **Plantilla completa**: Siempre se usa la plantilla completa, nunca versiones parciales
- ✅ **Preservación total**: Health checks, security context, resources - todo se preserva
- ✅ **URL parsing robusto**: Manejo automático de sufijos `.git` en URLs

```yaml
# Ahora SIEMPRE aparecen en .gluon/cd/values.yaml:
livenessProbe:
  httpGet:
    path: /nginx_status  # ✅ Nunca se pierde
    port: 8080
    scheme: HTTP

readinessProbe:
  httpGet:
    path: /nginx_status  # ✅ Siempre presente
    port: 8080
    scheme: HTTP
```

### GitHub API Optimizations

#### ⚡ Rate Limit Management & Error Handling

**Mejoras de eficiencia**:
- 📉 **65% menos consumo** de GitHub rate limits
- 🔄 **Retry logic inteligente** para operaciones críticas
- 🏷️ **URL normalization** automática (eliminación de `.git`)
- 📊 **Logs detallados** con emojis para debugging visual

**Manejo de errores mejorado**:
- 🚫 **Sin ocultación** de errores por fallbacks silenciosos
- 📋 **Contexto completo** en mensajes de error
- 🔍 **Debugging facilitado** con logs estructurados y coloridos
- ⚠️ **Validación previa** con dry-run antes de aplicar cambios

### Combined Migration with Automatic DEV Deployment & Cleanup

The `/combined_migration` endpoint now includes **automatic deployment to DEV and OpenShift cleanup** when migrations are successful:

- **Endpoint**: `POST /api/v1/migluon/combined_migration`
- **Functionality**: Migrates ConfigMap + Microservices + Automatic deployment to DEV + Original deployment cleanup
- **New Features**: 🚀 Automatic pull request creation and merge for DEV deployment + 🗂️ Backup and deletion of original deployment

#### Características Principales:
- ✅ **Detección Inteligente de Éxito**: Evalúa automáticamente si la migración fue exitosa
- 🔄 **Pull Request Automático**: Crea PR desde `feature/gluon-migration-config-from-pulse-import` → `development`
- 🔀 **Merge Automático Avanzado**: Squash merge con resolución inteligente de conflictos y bypass de branch protection
- 🗂️ **Backup del Deployment Original**: Crea `deployment-backup.yaml` en el repositorio antes del cleanup
- 🗑️ **Cleanup Seguro**: Elimina el deployment original de OpenShift después del backup exitoso
- 📊 **Visualización Prominente del Estado**: Estado del despliegue mostrado prominentemente al inicio de los resultados
- 🔒 **Despliegue Seguro**: Solo despliega si la migración es completamente exitosa
- 🤖 **Resolución Automática de Conflictos**: Resuelve automáticamente conflictos en archivos OAM manteniendo valores de Pulse
- 🛡️ **Bypass de Branch Protection**: Intenta bypass automático de reglas de protección de rama con tokens de admin
- 👥 **Revisiones de Code Owners**: Solicita automáticamente revisiones a code owners cuando es necesario
- ⏰ **Manejo de Estados de PR**: Gestiona estados `mergeable=None` esperando evaluación de GitHub
- 🚫 **Prevención de GitHub Actions**: Todos los commits incluyen `[ci skip]` para evitar ejecuciones innecesarias

### Funcionalidades Avanzadas de Automatización

#### 🤖 Resolución Automática de Conflictos
El sistema puede resolver automáticamente conflictos típicos en archivos OAM:
- **Detección Inteligente**: Busca archivos OAM con marcadores de conflicto Git
- **Estrategia de Resolución**: Mantiene siempre los valores de la rama `feature` (datos correctos de Pulse)
- **Conflictos Soportados**: Principalmente conflictos de `ci_id` entre development y feature
- **Patrones Reconocidos**: Marcadores `<<<<<<< HEAD`, `=======`, `>>>>>>> development`
- **Validación Post-Resolución**: Verifica que los conflictos se resolvieron correctamente

#### 🛡️ Bypass de Branch Protection Rules
Para repositorios con reglas de protección de rama activas:
- **Admin Token Detection**: Detecta automáticamente si el token tiene permisos de admin
- **Bypass Automático**: Intenta bypass de reglas de protección usando GraphQL API
- **Fallback Inteligente**: Si el bypass falla, solicita revisiones automáticamente
- **Code Owner Reviews**: Identifica y solicita revisiones a code owners del repositorio
- **Multi-Level Strategy**: Combinación de bypass directo + revisiones automáticas

#### ⏰ Manejo Inteligente de Estados de PR
Gestión robusta de estados de Pull Request en GitHub:
- **Estado `mergeable=None`**: Espera automáticamente a que GitHub evalúe el PR
- **Retry Logic**: Re-evalúa el estado del PR después de un período de espera
- **State Validation**: Maneja estados `unknown`, `dirty`, `unstable` de forma diferenciada
- **Timeout Management**: Evita esperas infinitas con timeouts configurables

#### 🚫 Prevención de GitHub Actions Innecesarias
Optimización de recursos y prevención de builds duplicados:
- **Commit Message Tagging**: Todos los commits automáticos incluyen `[ci skip]`
- **Selective Triggering**: Solo permite GitHub Actions en el merge final a development
- **Resource Optimization**: Evita consumo innecesario de runners de CI/CD

#### Mensajes de Estado del Despliegue:
- `🚀 ✅ SE REALIZÓ DEPLOY AUTOMÁTICO A DEV` - Deployment successful
- `❌ NO SE PUDO REALIZAR DEPLOY AUTOMÁTICO A DEV` - Deployment failed
- `❌ NO SE REALIZA DEPLOY A DEV (ERRORES EN MIGRACIÓN)` - Migration errors prevent deployment
- `❌ NO SE REALIZA DEPLOY A DEV (SIN MICROSERVICIOS)` - No microservices to deploy

#### Requisitos para Despliegue Automático:

##### Requisitos Básicos:
1. **Migración Exitosa**: Tanto ConfigMap como microservicios deben completarse sin errores críticos
2. **Permisos de Token GitHub**: El token debe tener permisos `repo`, `pull_requests:write`, y `contents:write`
3. **Ramas Requeridas**: El repositorio debe tener las ramas `feature/gluon-migration-config-from-pulse-import` y `development`
4. **GitHub Actions**: Los workflows de despliegue deben estar configurados en la rama `development`
5. **Acceso OpenShift**: Permisos para leer y eliminar deployments para la funcionalidad de cleanup

##### Requisitos Avanzados (Funcionalidades Automáticas):
6. **Permisos de Admin (Opcional)**: Para bypass automático de branch protection rules
7. **Code Owners File**: Archivo `.github/CODEOWNERS` configurado para revisiones automáticas
8. **Branch Protection Rules**: Compatibilidad con reglas de protección de rama activas
9. **API Rate Limits**: Consideración de límites de GitHub API para operaciones masivas
10. **Network Access**: Conectividad tanto a GitHub como a Azure DevOps para obtención de OAM

### 🔧 Troubleshooting y Mejores Prácticas

#### Problemas Comunes y Soluciones:

##### 🚀 **Nuevos en v2.6.0 - Optimizaciones de Rendimiento**

##### ⚡ "Session connection timeout" o "Too many connections"
**Causa**: Problemas de gestión de sesiones HTTP en versiones anteriores
**Solución v2.6.0**: Sistema de sesión única reutilizada elimina estos problemas
**Beneficio**: 40% menos tiempo de ejecución y conexiones estables

##### 🔄 "GitHub rate limit exceeded"
**Causa**: Múltiples requests individuales consumían rate limits rápidamente  
**Solución v2.6.0**: Batch operations con GitHub Tree API reducen requests en 60%
**Resultado**: Menos consumo de rate limits y operaciones más rápidas

##### 🛠️ "Health checks missing in values.yaml"
**Causa ANTERIOR**: Sistema de fallback hardcodeado omitía configuraciones
**Solución v2.6.0**: Eliminación completa de fallbacks + plantilla siempre completa
**Resultado**: Health checks `/nginx_status` SIEMPRE aparecen en archivos finales

##### 🔗 "URL parsing failed with .git repositories"
**Causa ANTERIOR**: Regex no manejaba sufijos `.git` correctamente
**Solución v2.6.0**: Regex mejorado con limpieza automática de `.git`
**Archivos afectados**: Flujos de ConfigMap backend ahora funcionan correctamente

##### 📝 "Template variables not applying"
**Causa ANTERIOR**: `_update_frontend_main_values_content()` usaba parsing selectivo
**Solución v2.6.0**: Misma plantilla completa tanto para creación como actualización  
**Resultado**: TODAS las configuraciones se preservan (security context, resources, probes)

##### 🔍 **Debugging Mejorado v2.6.0**
**Logs con emojis y colores**: Facilitan identificación visual de problemas
**Context completo**: Errores incluyen toda la información necesaria para debugging
**Sin ocultación**: Eliminados fallbacks silenciosos que ocultaban problemas reales

```python
# Ejemplos de logs mejorados:
✅ PLANTILLA FRONTEND PROCESADA CORRECTAMENTE con gitRepo: https://...
🔄 Actualizando values.yaml principal con plantilla COMPLETA (preserva health checks)
✅ Health checks /nginx_status preservados en actualización
❌ ERROR CRÍTICO procesando plantilla: [error específico]
```

##### � "PR mergeable=None" o "state=unknown"
**Causa**: GitHub aún está evaluando el estado del Pull Request
**Solución**: El sistema espera automáticamente y re-evalúa el estado
**Tiempo típico**: 3-10 segundos para evaluación completa

##### 🔒 "Branch protection rules prevent merge"
**Causa**: Reglas de protección de rama activas sin bypass automático
**Soluciones automáticas**:
1. Bypass directo (si el token tiene permisos de admin)
2. Solicitud automática de revisión a code owners
3. Fallback a revisión manual

##### 🤖 "No OAM files found in conflict"
**Causa**: Archivos OAM no detectados correctamente en conflictos
**Solución automática**: Búsqueda directa en la rama feature usando GitHub Tree API
**Archivos buscados**: `*.oam.yml`, `*.oam.yaml`

##### ⚠️ "Conflictos no resueltos automáticamente"
**Causa**: Conflictos complejos fuera del patrón `ci_id` estándar
**Acción requerida**: Revisión manual del PR generado
**Ubicación**: Link proporcionado en el mensaje de error

#### Mejores Prácticas para Administradores:

##### 🚀 **Optimizaciones v2.6.0 - Configuraciones Recomendadas**

1. **Gestión de Performance**:
   - **Sesiones HTTP**: Las optimizaciones son automáticas, no requieren configuración
   - **Rate Limits**: Monitorear menos frecuentemente debido a reducción del 65% en consumption
   - **Batch Operations**: Ideales para migraciones de múltiples repositorios
   - **Template Consistency**: Validar que health checks aparecen en todos los deployments

2. **Debugging Efectivo con Nuevos Logs**:
   - **Buscar emojis**: ✅ = éxito, ❌ = error crítico, 🔄 = proceso en curso
   - **URLs procesadas**: Verificar que URLs `.git` se normalizan correctamente
   - **Template rendering**: Confirmar que se usa plantilla completa, nunca fallback
   - **Context completo**: Los errores incluyen toda la información necesaria

3. **Validación Post-Migración**:
   - **Health checks**: Verificar `/nginx_status` endpoints en archivos `.gluon/cd/values.yaml`
   - **Security context**: Confirmar `runAsNonRoot: true` y configuraciones de seguridad
   - **Resource limits**: Validar límites de CPU/memoria en plantillas procesadas
   - **Environment variables**: Comprobar variables extraídas del deployment original

4. **Configuración de Tokens (Tradicional)**:
   - Usar Personal Access Tokens con permisos completos
   - Para organizaciones: Configurar GitHub Apps con permisos apropiados
   - Renovar tokens antes de expiración

5. **Branch Protection Rules**:
   - Configurar code owners en `.github/CODEOWNERS`
   - Permitir bypass para tokens de admin si es necesario
   - Documentar process de revisión para casos de fallback

6. **Monitoreo**:
   - Revisar logs para identificar patrones de error
   - Configurar alertas para fallos de despliegue
   - Monitorear uso de GitHub API rate limits

7. **Mantenimiento**:
   - Limpiar ramas feature obsoletas periódicamente
   - Validar configuración de GitHub Actions regularmente
   - Actualizar configuración de OpenShift según sea necesario

### Documentación Actualizada:
- 📋 **Documentación Completa de API**: Visita `/docs/endpoints/combined_migration.md` para documentación completa de API
- 🚀 **Guía de Despliegue**: Ver `/docs/endpoints/automatic_deployment.md` para detalles específicos de despliegue
- 📖 **Guía de Migración**: Ver `/docs/migration_guide_auto_deploy.md` para actualización desde versiones anteriores
- 🤖 **Automation Features**: Ver `/docs/automation_features.md` para funcionalidades avanzadas
- 🔧 **Troubleshooting Guide**: Ver `/docs/troubleshooting.md` para resolución de problemas
- ⚡ **Performance Guide v2.6.0**: Optimizaciones de sesiones HTTP y batch operations
- 🛠️ **Template System Guide v2.6.0**: Configuración de health checks y eliminación de fallbacks
- 🔗 **URL Handling Guide v2.6.0**: Manejo automático de URLs `.git` y normalización

### Otros Endpoints Disponibles:
- `POST /api/v1/migluon/update_git_values` - Migración de repositorio individual (sin despliegue automático)
- `POST /api/v1/migluon/edit_oam` - Edición de configuración OAM
- `POST /api/v1/migluon/robot_deployertoken` - Gestión de tokens de despliegue
- `GET /api/v1/migluon/health` - Health check y estado del sistema
- `GET /api/v1/migluon/version` - Información de versión y características

### Changelog de Funcionalidades Recientes:

### Changelog de Funcionalidades Recientes:

#### v2.6.0 - Optimizaciones de Rendimiento y Correcciones Críticas (Sept 2025)

##### 🚀 **Optimizaciones de Rendimiento**

**1. Reutilización de Sesiones HTTP**
- ✅ **Implementado**: Sistema de sesión única `aiohttp.ClientSession` para múltiples operaciones GitHub
- ✅ **Mejora**: Reducción de ~40% en tiempo de ejecución total de migraciones
- ✅ **Impacto**: Eliminación de overhead de conexión/desconexión repetitiva
- 📍 **Archivos modificados**: `back_values.py`, `front_values.py`, `external_requests.py`

```python
# ANTES: Nueva sesión para cada operación
async with aiohttp.ClientSession() as session:
    # Una sola operación
    
# DESPUÉS: Sesión reutilizada para todo el flujo
session = aiohttp.ClientSession()
try:
    # Múltiples operaciones con la misma sesión
finally:
    await session.close()
```

**2. Batch Commits con GitHub Tree API**
- ✅ **Implementado**: Commits atómicos de múltiples archivos en una sola transacción
- ✅ **Mejora**: Reducción de ~60% en número de roundtrips a GitHub API
- ✅ **Impacto**: Operaciones más rápidas y menos consumo de rate limits
- 📍 **Función principal**: `batch_update_files()` en `github_client.py`

```python
# ANTES: Un commit por archivo (3 commits separados)
await update_file(dockerfile_content)  # Commit 1
await update_file(pom_content)         # Commit 2  
await update_file(values_content)      # Commit 3

# DESPUÉS: Un solo commit para todos los archivos
await batch_update_files([
    dockerfile_changes,
    pom_changes, 
    values_changes
])  # 1 solo commit atómico
```

**3. Migración Combinada con Dry-Run**
- ✅ **Implementado**: Preparación previa de todos los cambios antes de aplicarlos
- ✅ **Mejora**: Validación completa sin aplicar cambios parciales
- ✅ **Impacto**: Mayor confiabilidad y posibilidad de rollback completo
- 📍 **Funciones**: `prepare_dockerfile_changes()`, `prepare_pom_changes()`, `prepare_all_file_changes()`

##### 🔧 **Correcciones Críticas**

**1. Eliminación de Fallbacks en Plantillas Frontend**
- ❌ **Problema identificado**: Plantillas de health checks se perdían por uso de fallback hardcodeado
- ✅ **Solución**: Eliminación completa del sistema de fallback en `_create_frontend_main_values_content()`
- ✅ **Resultado**: Health checks `/nginx_status` ahora se aplican SIEMPRE en archivos `values.yaml`
- 📍 **Archivos afectados**: `front_values.py`, `values-frontend.yaml.j2`

```python
# ANTES: Fallback que perdía configuraciones
except Exception as e:
    # Contenido de fallback básico SIN health checks
    return basic_fallback_content
    
# DESPUÉS: Sin fallback - error visible
except Exception as e:
    raise RuntimeError(f"Error crítico: {e}. NO se usará fallback.")
```

**2. Preservación Completa de Configuraciones en Actualizaciones**
- ❌ **Problema identificado**: `_update_frontend_main_values_content()` usaba `ruamel.yaml` perdiendo configuraciones
- ✅ **Solución**: Uso de plantilla completa también en actualizaciones, no solo en creaciones
- ✅ **Resultado**: TODAS las configuraciones (health checks, security context, etc.) se preservan
- 📍 **Impacto**: Archivos `.gluon/cd/values.yaml` contienen configuración completa

```python
# ANTES: Solo actualizar campos específicos (perdía health checks)
data['image']['repository'] = git_repo_path  # Solo campos específicos

# DESPUÉS: Usar plantilla completa (preserva TODO)
template.render(**template_vars)  # Plantilla completa con health checks
```

**3. Corrección de Parsing de URLs .git**
- ❌ **Problema identificado**: URLs como `san-gascor-cmjbbff.git` causaban errores en GitHub API
- ✅ **Solución**: Regex mejorado que elimina automáticamente el sufijo `.git`
- ✅ **Resultado**: Flujos de ConfigMap backend funcionan correctamente
- 📍 **Archivos afectados**: `github/operations.py`

```python
# ANTES: Regex que no manejaba .git
r'https://github\.com/([^/]+)/([^/]+)'

# DESPUÉS: Regex que elimina .git automáticamente  
r'https://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$'
```

##### 📊 **Métricas de Mejora**

| Métrica | Antes | Después | Mejora |
|---------|--------|---------|---------|
| **Tiempo total migración** | ~45-60 seg | ~25-35 seg | **~40% más rápido** |
| **Roundtrips GitHub API** | 8-12 requests | 3-5 requests | **~60% menos requests** |
| **Rate limit consumption** | Alto | Bajo | **~65% menos consumo** |
| **Preservación configuraciones** | Parcial | Completa | **100% preservación** |
| **Fallos por URLs .git** | Frecuentes | Eliminados | **0 fallos** |

##### 🛡️ **Mejoras de Robustez**

**1. Logs Detallados para Debugging**
- ✅ **Añadido**: Logs específicos para cada fase de procesamiento
- ✅ **Formato**: Emojis y colores para facilitar debugging visual
- ✅ **Información**: URLs procesadas, variables de plantilla, resultados de operaciones

**2. Manejo de Errores Sin Ocultación**
- ✅ **Eliminado**: Fallbacks silenciosos que ocultaban problemas
- ✅ **Añadido**: Errores visibles con información completa de contexto
- ✅ **Resultado**: Problemas identificables y solucionables rápidamente

**3. Validación Previa de Operaciones**
- ✅ **Implementado**: Dry-run para validar todos los cambios antes de aplicar
- ✅ **Beneficio**: Detección temprana de errores sin aplicar cambios parciales
- ✅ **Seguridad**: Rollback completo posible en cualquier momento

##### 🔄 **Compatibilidad y Migración**

- ✅ **Compatibilidad completa** con APIs existentes
- ✅ **Sin cambios** en interfaces de endpoints
- ✅ **Mejoras transparentes** para usuarios finales
- ✅ **Fallback automático** solo para casos críticos no relacionados con templates

##### 📚 **Documentación Actualizada**

- 📖 **Health Checks**: Documentación de configuraciones `/nginx_status` en plantillas frontend
- 🔧 **Batch Operations**: Guía de uso de operaciones batch para múltiples archivos
- ⚡ **Performance Guide**: Mejores prácticas para optimizar migraciones
- 🐛 **Debugging Guide**: Guía para interpretar nuevos logs detallados

#### v2.5.0 - Automatización Avanzada (Sept 2025)
- ✅ Resolución automática de conflictos en archivos OAM
- ✅ Bypass automático de branch protection rules
- ✅ Solicitud automática de revisiones a code owners
- ✅ Manejo inteligente de estados de PR (mergeable=None)
- ✅ Prevención de GitHub Actions con [ci skip]
- ✅ Detección mejorada de archivos OAM en conflictos
- ✅ Patrones de resolución más robustos
- ✅ Retry logic para evaluación de PR states

#### v2.4.0 - ConfigMap y Cleanup
- ✅ Eliminación de deployments duplicados de ConfigMap
- ✅ Conversión automática de nombres de repositorio (san-gascor-front → san-gascor-cmfront)
- ✅ Backup automático antes de cleanup
- ✅ Validación mejorada de recursos de OpenShift

Para documentación completa de API, visita `/docs` cuando el servicio esté ejecutándose.
