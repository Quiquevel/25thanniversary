# Endpoints de Migración con Logs en Tiempo Real

## Descripción General

Los nuevos endpoints de migración proporcionan logs en tiempo real usando **Server-Sent Events (SSE)**, permitiendo monitorear el progreso de las migraciones directamente desde Swagger UI o desde aplicaciones cliente.

## Endpoints Disponibles

### 1. `/combined_migration_streaming`
**Migración Combinada con Logs en Tiempo Real**

- **Método**: POST
- **Descripción**: Procesa ConfigMap + Microservicios con logs streaming
- **Response**: Server-Sent Events (text/event-stream)

#### Ejemplo de uso en JavaScript:
```javascript
const eventSource = new EventSource('/api/v1/migluon/combined_migration_streaming', {
    method: 'POST',
    body: JSON.stringify({
        old_name: 'mi-aplicacion',
        git_token: 'ghp_xxxxxxxxxxxx',
        url_git_cm: 'https://github.com/usuario/configmap-repo',
        url_git_micro: 'https://github.com/usuario/micro1,https://github.com/usuario/micro2',
        url_oam: 'https://github.com/usuario/oam-repo'
    })
});

eventSource.onmessage = function(event) {
    const data = JSON.parse(event.data);
    console.log(`[${data.type}] ${data.message}`);
};
```

#### Tipos de eventos emitidos:
- `start`: Inicio del proceso
- `phase`: Nueva fase (ConfigMap, Microservicios)
- `progress`: Progreso de la fase actual
- `micro_progress`: Progreso de microservicio individual
- `micro_detection`: Tipo detectado de microservicio
- `micro_complete`: Microservicio completado
- `complete`: Proceso completado
- `error`: Error durante el proceso
- `end`: Fin del stream

### 2. `/update_git_values_streaming`
**Actualización de Microservicio Individual con Logs en Tiempo Real**

- **Método**: POST
- **Descripción**: Procesa un microservicio individual con logs streaming
- **Response**: Server-Sent Events (text/event-stream)

#### Tipos de eventos específicos:
- `detection`: Tipo de microservicio detectado (BACKEND/FRONTEND/CONFIG_MAP)
- `processing`: Progreso del procesamiento específico

### 3. `/migration_status/{process_id}`
**Consulta de Estado de Migración**

- **Método**: GET
- **Descripción**: Obtiene estado actual y logs de un proceso
- **Response**: JSON con estado y logs completos

#### Ejemplo de respuesta:
```json
{
    "process_id": "abc123",
    "status": "running",
    "logs": [
        {
            "timestamp": 1640995200.0,
            "level": "info",
            "message": "🚀 Iniciando migración combinada para mi-aplicacion",
            "details": {}
        }
    ]
}
```

## Uso en Swagger UI

1. **Navega a** `/docs` en tu navegador
2. **Encuentra** los endpoints `*_streaming`
3. **Ejecuta** el endpoint con tus parámetros
4. **Observa** los logs aparecer en tiempo real en la interfaz de Swagger

## Estados de Proceso

- `running`: Proceso en ejecución
- `completed`: Proceso completado exitosamente
- `failed`: Proceso falló con errores
- `not_found`: Process ID no existe

## Ventajas del Sistema

✅ **Monitoreo en Tiempo Real**: Ve exactamente qué está pasando durante la migración  
✅ **Detección de Problemas**: Identifica errores inmediatamente sin esperar al final  
✅ **Progreso Granular**: Seguimiento individual de cada microservicio  
✅ **Compatible con Swagger**: Funciona directamente desde la documentación API  
✅ **Recuperación de Estado**: Consulta logs después de desconexiones  

## Compatibilidad

- ✅ Swagger UI 
- ✅ Navegadores modernos (Chrome, Firefox, Safari)
- ✅ Aplicaciones JavaScript/TypeScript
- ✅ Curl y herramientas CLI
- ✅ Aplicaciones Python con `requests` o `httpx`

## Ejemplo con Curl

```bash
curl -N -H "Accept: text/event-stream" \
  -H "Content-Type: application/json" \
  -X POST \
  -d '{"old_name":"test","git_token":"ghp_xxx","url_git_cm":"...","url_git_micro":"...","url_oam":"..."}' \
  http://localhost:8000/api/v1/migluon/combined_migration_streaming
```

## Notas Técnicas

- Los logs se mantienen en memoria durante 24 horas
- Cada proceso tiene un ID único para seguimiento
- Los streams se cierran automáticamente al completarse
- Compatible con proxies y load balancers que soporten SSE