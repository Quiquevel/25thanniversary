# 🚀 Despliegue Automático a DEV - Combined Migration

## Descripción General
El endpoint `/combined_migration` incluye funcionalidad de **despliegue automático a DEV** que se ejecuta cuando la migración combinada (ConfigMap + Microservicios) se completa exitosamente.

## 🎯 Objetivo
Automatizar completamente el flujo desde la migración hasta el despliegue en DEV, eliminando pasos manuales y asegurando que solo se desplieguen migraciones exitosas.

## 🔄 Flujo Completo

### Fase 1: Migración
```
1. ConfigMap Processing ✅
2. Microservice(s) Processing ✅
```

### Fase 2: Evaluación Automática
```
3. Success Analysis 🤖
   - Analiza logs de migración
   - Cuenta errores vs éxitos
   - Determina viabilidad de despliegue
```

### Fase 3: Despliegue Automático (Si exitoso)
```
4. Pull Request Creation 🔄
   - Branch: feature/gluon-migration-config-from-pulse-import → development
   - Título: "feat: Migración automática desde Pulse - Deploy a DEV"
   - Descripción detallada del cambio

5. Automatic Merge 🔀
   - Squash merge para historial limpio
   - Commit message descriptivo

6. GitHub Actions Trigger 🚀
   - Dispara automáticamente el pipeline de despliegue
   - Deploy a DEV sin intervención manual
```

## 🧠 Lógica de Evaluación de Éxito

### Indicadores de Error (Bloquean despliegue)
- `❌` - Marca de error visual
- `Error en ConfigMap:` - Error específico en ConfigMap
- `Error en microservicio` - Error específico en microservicio
- `KO -` - Indicador de fallo
- `FALLÓ` - Proceso fallido
- `error:` - Error genérico
- `failed` - Fallo en inglés

### Indicadores de Éxito (Permiten despliegue)
- `✅` - Marca de éxito visual
- `OK -` - Indicador de éxito
- `completado` - Proceso completado
- `exitosamente` - Proceso exitoso
- `SUCCESS` - Éxito en inglés

### Algoritmo de Decisión
```python
if errores_criticos > 3:
    return False  # No desplegar
elif exitos > 0:
    return True   # Desplegar
else:
    return False  # Sin suficientes indicadores de éxito
```

## 📊 Estados de Despliegue

### ✅ Despliegue Exitoso
```
🚀 ✅ SE REALIZÓ DEPLOY AUTOMÁTICO A DEV
```
- **Condición**: Migración exitosa + PR creado y mergeado
- **Resultado**: GitHub Actions disparado automáticamente
- **Próximo paso**: Monitorear despliegue en GitHub Actions

### ❌ Despliegue Fallido - Error en Migración
```
❌ NO SE REALIZA DEPLOY A DEV (ERRORES EN MIGRACIÓN)
```
- **Condición**: Errores críticos detectados en ConfigMap o microservicios
- **Resultado**: No se crea pull request
- **Próximo paso**: Revisar y corregir errores, luego reintentar

### ❌ Despliegue Fallido - Error en Pull Request
```
❌ NO SE PUDO REALIZAR DEPLOY AUTOMÁTICO A DEV
```
- **Condición**: Migración exitosa pero fallo en PR/merge
- **Posibles causas**:
  - Branch `feature/gluon-migration-config-from-pulse-import` no existe
  - Branch `development` protegido sin permisos adecuados
  - Token de GitHub sin permisos de PR/merge
  - Conflictos de merge
- **Próximo paso**: Verificar configuración de repositorio y permisos

### ⚠️ Sin Despliegue - Sin Microservicios
```
❌ NO SE REALIZA DEPLOY A DEV (SIN MICROSERVICIOS)
```
- **Condición**: Solo ConfigMap procesado, sin microservicios
- **Resultado**: Comportamiento normal, no es un error
- **Próximo paso**: Si se necesita despliegue, incluir microservicios en la migración

## �️ Nueva Funcionalidad: Backup y Cleanup del Deployment Original

### 5. Proceso de Backup y Limpieza
Después del despliegue exitoso, el sistema realiza automáticamente:

#### 🔍 Obtención del Deployment Original
- Se conecta a OpenShift para obtener el deployment con nombre `old_name`
- Extrae la configuración completa en formato YAML
- Valida que el deployment existe antes de proceder

#### 💾 Creación del Backup
- **Archivo**: `deployment-backup.yaml`
- **Ubicación**: Raíz de la rama `feature/gluon-migration-config-from-pulse-import`
- **Formato**: YAML completo con comentarios descriptivos
- **Contenido**: Deployment tal como estaba en OpenShift antes de la migración

#### 🗑️ Eliminación Segura
- **Verificación**: Solo se elimina después de backup exitoso
- **Método primario**: Cliente OpenShift nativo
- **Método fallback**: API REST de OpenShift
- **Confirmación**: Verifica eliminación exitosa

#### 🔄 Rollback Disponible
- El archivo `deployment-backup.yaml` permite restaurar el deployment original
- Ubicado en el repositorio Git para facilitar acceso
- Mantiene toda la configuración original para rollback completo

### Estados del Proceso de Cleanup
```
✅ BACKUP Y CLEANUP COMPLETADO
- Backup creado exitosamente
- Deployment original eliminado

⚠️ BACKUP EXITOSO, ERROR EN ELIMINACIÓN  
- Backup disponible para rollback
- Deployment original permanece en OpenShift

❌ ERROR EN BACKUP Y CLEANUP
- No se pudo crear backup
- Deployment original permanece intacto
```

## �🔧 Configuración Requerida

### Repositorio de Microservicio
```yaml
Branches requeridos:
- feature/gluon-migration-config-from-pulse-import (source)
- development (target)

Permisos del token:
- repo (acceso completo al repositorio)
- pull_requests:write (crear PRs)
- contents:write (hacer commits)
- metadata:read (leer metadatos)
```

### Configuración OpenShift
```yaml
Acceso requerido:
- deployments:get (leer deployments)
- deployments:delete (eliminar deployments)
- API REST access (fallback)
- Token o certificado válido
```

### GitHub Actions (en branch development)
```yaml
# Ejemplo de workflow básico
name: Deploy to DEV
on:
  push:
    branches: [development]
  pull_request:
    branches: [development]
    types: [closed]

jobs:
  deploy:
    if: github.event.pull_request.merged == true
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to DEV
        run: |
          echo "Deploying to DEV environment..."
          # Aquí va la lógica de despliegue específica
```

## 🔍 Debugging y Troubleshooting

### Verificar Estado del Repositorio
```bash
# Comprobar que existen los branches necesarios
git branch -r | grep feature/gluon-migration-config-from-pulse-import
git branch -r | grep development

# Verificar permisos del token
curl -H "Authorization: token YOUR_TOKEN" \
  https://api.github.com/repos/OWNER/REPO
```

### Logs Importantes
El sistema registra información detallada en cada paso:
- **Evaluación de éxito**: Logs de análisis de resultados
- **Creación de PR**: URL del PR creado, número asignado
- **Merge automático**: Estado del merge, SHA del commit resultante
- **Errores de API**: Respuestas de GitHub API con códigos de error

### Verificar Despliegue
```bash
# Verificar que el PR fue creado y mergeado
https://github.com/OWNER/REPO/pulls?q=is:pr+author:YOUR_BOT+is:merged

# Verificar que GitHub Actions se disparó
https://github.com/OWNER/REPO/actions
```

## 🔐 Consideraciones de Seguridad

### Principio de Menor Privilegio
- Token con permisos mínimos necesarios
- Solo acceso a repositorios específicos de la migración
- No permisos de admin a menos que sea estrictamente necesario

### Validación Previa
- Solo despliega migraciones completamente exitosas
- Análisis automático de logs para detectar problemas
- No bypass manual de validaciones de seguridad

### Trazabilidad Completa
- Cada despliegue automático crea un PR documentado
- Historial completo en GitHub
- Logs detallados para auditoría

### Rollback Seguro
- Branch original preservado intacto
- Posibilidad de rollback inmediato desde GitHub
- No modifica branches críticos (main/master)

## 📈 Métricas y Monitoreo

### Métricas de Éxito
- **Tasa de despliegue automático**: % de migraciones que resultan en despliegue
- **Tiempo total**: Tiempo desde inicio de migración hasta despliegue completado
- **Tasa de éxito de PR**: % de PRs automáticos que se mergean exitosamente

### Alertas Recomendadas
- Fallos consecutivos en despliegue automático
- Errores de permisos de GitHub
- Branches faltantes o mal configurados
- Timeouts en API de GitHub

## 🚀 Beneficios del Despliegue Automático

### Eficiencia
- **Eliminación de pasos manuales**: De migración a despliegue en un solo comando
- **Reducción de tiempo**: Deploy inmediato después de migración exitosa
- **Menos errores humanos**: Proceso completamente automatizado

### Calidad
- **Validación previa**: Solo despliega si la migración fue exitosa
- **Consistencia**: Mismo proceso para todas las migraciones
- **Trazabilidad**: Historial completo de cambios

### Experiencia del Usuario
- **Feedback inmediato**: Estado de despliegue visible al inicio del resultado
- **Información clara**: Mensajes descriptivos sobre el estado del proceso
- **Recuperación fácil**: Instrucciones claras para resolver problemas