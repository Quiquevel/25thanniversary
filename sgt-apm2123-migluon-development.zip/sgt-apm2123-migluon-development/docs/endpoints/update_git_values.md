# Endpoint: /update_git_values

## Descripción General
Punto de entrada unificado para actualizar valores de UN SOLO repositorio git (BACKEND, FRONTEND o CONFIG_MAP) con detección automática de tipo de microservicio.

## Información del Endpoint
- **URL**: `/api/v1/migluon/update_git_values`
- **Método**: `POST`
- **Descripción**: Actualizar valores de UN SOLO repo git (BACKEND, FRONT o CM). Para múltiples repositorios usar /combined_migration
- **Response**: Resultado de la actualización de valores
- **Status Code**: 200
- **Response Class**: PlainTextResponse
- **Operation ID**: `update_git_values_auto`

## ⚠️ IMPORTANTE
Este endpoint procesa **UN SOLO repositorio**. Para procesar un micro y un configmap a la vez usar: `/combined_migration`

## Parámetros de Entrada (MicroModel)
```json
{
  "old_name": "string",
  "git_token": "string",
  "url_git": "string",
  "url_oam": "string"
}
```

### Descripción de Parámetros
- **old_name**: Nombre antguo del microservicio/aplicación a actualizar
- **git_token**: Token de GitHub con permisos de repositorio
- **url_git**: URL del repositorio git a procesar (UN SOLO repositorio)
- **url_oam**: URL del repositorio OAM con configuración de OpenShift

## Validaciones Realizadas

### 1. Validación de URL de Git
```python
try:
    owner, repo = extract_repo_info(micro_data.url_git)
except ValueError as e:
    return PlainTextResponse(content=f"❌ ERROR: {str(e)}")
```
- **Normalización de URL**: Convierte diferentes formatos a formato estándar
- **Extracción de owner/repo**: Separa propietario y nombre del repositorio
- **Validación de formato**: Verifica que la URL sea válida para GitHub

### 2. Detección Automática de Tipo de Microservicio
```python
microservice_type = await detect_microservice_type(
    session, owner, repo, micro_data.git_token
)
```

#### Criterios de Detección
- **FRONTEND**: 
  - ✅ Presencia de carpeta `/nginx`
  - ✅ O presencia de archivo `package.json`
- **BACKEND**:
  - ✅ Presencia de archivo `pom.xml`
  - ✅ O presencia de carpeta `.mvn`
- **CONFIG_MAP**:
  - ⚠️ Ninguno de los indicadores anteriores encontrados

### 3. Validación de Acceso al Repositorio
- **Permisos de token**: Verificación de acceso con token proporcionado
- **Existencia de repositorio**: Confirmación de que el repositorio existe
- **Contenido del repositorio**: Análisis de estructura para detección de tipo

## Procesamiento Detallado por Tipo

### FRONTEND (Detectado)
```python
if microservice_type == "FRONTEND":
    result = await update_front_microservice_values(
        old_name=micro_data.old_name,
        git_token=micro_data.git_token,
        url_git=micro_data.url_git,
        url_oam=micro_data.url_oam
    )
```

#### Validaciones Específicas FRONTEND
- **Configuración nginx**: Validación de archivos de configuración del servidor web
- **Package.json**: Verificación de dependencias y scripts NPM
- **Assets estáticos**: Validación de recursos frontend
- **Dockerfile**: Verificación de imagen nginx con API de versiones de Santander

### BACKEND (Detectado)
```python
if microservice_type == "BACKEND":
    result = await update_microservice_values(
        old_name=micro_data.old_name,
        git_token=micro_data.git_token,
        url_git=micro_data.url_git,
        url_oam=micro_data.url_oam
    )
```

#### Validaciones Específicas BACKEND
- **Archivo pom.xml**: Validación de estructura Maven y dependencias
- **Versiones Java**: Verificación de versiones con API de Santander
- **Configuración Spring**: Validación de archivos application.yml/properties
- **Dockerfile**: Verificación de imagen Java con API de versiones

### CONFIG_MAP (Detectado)
```python
if microservice_type == "CONFIG_MAP":
    result = await configmap_service(
        old_name=micro_data.old_name,
        git_token=micro_data.git_token,
        url_git_cm=micro_data.url_git,
        url_oam=micro_data.url_oam
    )
```

#### Validaciones Específicas CONFIG_MAP
- **Archivos YAML**: Validación de estructura de configuración
- **Configuración por entorno**: Verificación de archivos values.{env}.yaml
- **Secrets y ConfigMaps**: Validación de referencias a configuraciones sensibles

## Funciones Internas Utilizadas

### `detect_microservice_type()`
- **Ubicación**: `src.services.common_utils`
- **Función**: Analiza estructura del repositorio para determinar tipo
- **Algoritmo**: 
  1. Obtiene contenido del directorio raíz via GitHub API
  2. Busca archivos/carpetas indicativos de cada tipo
  3. Retorna tipo detectado basado en criterios

### `extract_repo_info()`
- **Ubicación**: `src.services.common_utils`
- **Función**: Extrae owner y nombre del repositorio de URL
- **Validaciones**: Normaliza URL y valida formato

### `fix_encoding_issues()`
- **Ubicación**: `src.services.common_utils`
- **Función**: Corrige problemas de encoding en respuestas de texto
- **Uso**: Aplicado a todas las respuestas para evitar caracteres corruptos

### Procesadores Especializados
- **`update_front_microservice_values()`**: Para microservicios FRONTEND
- **`update_microservice_values()`**: Para microservicios BACKEND
- **`configmap_service()`**: Para CONFIG_MAP

## Respuestas por Tipo Detectado

### Éxito FRONTEND
```
🎨 DETECTADO Y PROCESADO: MICROSERVICIO FRONTEND
=======================================================
✅ MIGRACIÓN FRONT: [old_name]

[Detalles específicos del procesamiento frontend...]

📦 Imagen nginx actualizada con API de versiones
🔧 Configuración nginx validada
📄 Package.json procesado
✅ Valores actualizados en repositorio
```

### Éxito BACKEND
```
⚙️ DETECTADO Y PROCESADO: MICROSERVICIO BACKEND
=======================================================
✅ MIGRACIÓN BACKEND: [old_name]

[Detalles específicos del procesamiento backend...]

☕ Imagen Java actualizada con API de versiones
📋 POM.xml validado y actualizado
🏗️ Configuración Spring procesada
✅ Valores actualizados en repositorio
```

### Éxito CONFIG_MAP
```
⚙️ DETECTADO Y PROCESADO: MICROSERVICIO CONFIG MAP
=======================================================
✅ MIGRACIÓN CONFIG MAP: [old_name]

[Detalles específicos del procesamiento config map...]

📋 Archivos YAML validados
🔧 Configuración por entorno actualizada
🔐 Referencias a secrets verificadas
✅ Configuración actualizada en repositorio
```

### Error de Detección
```
❌ ERROR: No se pudo determinar el tipo de microservicio para [owner]/[repo]

Posibles causas:
- Repositorio sin indicadores claros de tipo
- Permisos insuficientes del token
- Repositorio vacío o inaccesible

Criterios de detección:
- FRONTEND: carpeta /nginx O archivo package.json
- BACKEND: archivo pom.xml O carpeta .mvn
- CONFIG_MAP: ninguno de los anteriores

⚠️ Verifique la estructura del repositorio y permisos del token.
```

## Casos de Error Comunes

### 1. URL de Git Inválida
- **Síntoma**: `❌ ERROR: URL de Git inválida: [url]`
- **Causa**: Formato de URL no reconocido
- **Solución**: Usar formato estándar de GitHub: `https://github.com/owner/repo`

### 2. Token Sin Permisos
- **Síntoma**: Error 401/403 durante detección
- **Causa**: Token sin permisos de lectura en el repositorio
- **Solución**: Verificar que el token tenga permisos 'repo'

### 3. Repositorio Vacío
- **Síntoma**: Detectado como CONFIG_MAP cuando debería ser otro tipo
- **Causa**: Repositorio sin archivos indicativos
- **Solución**: Añadir archivos base (pom.xml, package.json, etc.)

### 4. Fallo en Procesamiento Específico
- **Síntoma**: Error durante procesamiento del tipo detectado
- **Causa**: Problemas específicos del procesador (BACKEND/FRONTEND/CONFIG_MAP)
- **Solución**: Revisar logs específicos del procesador correspondiente

## Algoritmo de Detección Detallado

### Paso 1: Acceso al Repositorio
```python
url = f"https://api.github.com/repos/{owner}/{repo}/contents"
headers = {'Authorization': f'token {git_token}'}
```

### Paso 2: Análisis de Contenido
```python
# Separar archivos y carpetas
for item in contents:
    if item['type'] == 'file':
        files.append(item['name'])
    elif item['type'] == 'dir':
        folders.append(item['name'])
```

### Paso 3: Aplicación de Criterios
```python
# FRONTEND: nginx/ OR package.json
is_frontend = ('nginx' in folders or 'package.json' in files)

# BACKEND: pom.xml OR .mvn/
is_backend = ('pom.xml' in files or '.mvn' in folders)

# CONFIG_MAP: por eliminación
if not is_frontend and not is_backend:
    return "CONFIG_MAP"
```

## Ventajas de la Detección Automática

### 1. Simplicidad de Uso
- **Sin configuración manual**: El usuario no necesita especificar el tipo
- **Proceso unificado**: Un solo endpoint para todos los tipos
- **Reducción de errores**: Evita clasificación manual incorrecta

### 2. Precisión en Detección
- **Criterios claros**: Indicadores específicos para cada tipo
- **Fallback inteligente**: CONFIG_MAP como opción por defecto
- **Logging detallado**: Información clara sobre criterios aplicados

### 3. Extensibilidad
- **Nuevos criterios**: Fácil añadir nuevos indicadores de tipo
- **Tipos adicionales**: Soporte para nuevos tipos de microservicio
- **Configuración flexible**: Criterios ajustables según necesidades

## Logging
- **Detección**: `✅ Detectado microservicio [TIPO] en owner/repo`
- **Criterios**: `└─ Indicador: [criterio_aplicado]`
- **Procesamiento**: Logs específicos de cada procesador
- **Resultado**: Log del resultado final consolidado

## Casos de Uso
1. **Migración individual**: Actualizar un solo microservicio
2. **Pruebas de concepto**: Validar cambios en un repositorio específico
3. **Actualización específica**: Modificar solo un componente de la aplicación
4. **Debug de procesamiento**: Diagnosticar problemas en un microservicio específico

## Diferencias con /combined_migration
- **Alcance**: Un solo repositorio vs múltiples repositorios
- **Orden**: Sin garantías de orden vs ConfigMap primero garantizado
- **Uso recomendado**: Operaciones individuales vs migraciones completas