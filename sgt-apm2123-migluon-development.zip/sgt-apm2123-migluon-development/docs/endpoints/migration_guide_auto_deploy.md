# 📋 Guía de Migración - Nueva Funcionalidad de Despliegue Automático

## 🚀 ¿Qué hay de nuevo?

## 🚀 Descripción

El flujo `combined_migration` está diseñado para procesar tanto ConfigMaps como microservicios en un solo endpoint, **CON DESPLIEGUE AUTOMÁTICO A DEV y CLEANUP DE DEPLOYMENT ORIGINAL después de migración exitosa**.

### Antes (Versión Anterior)
```
1. Ejecutar /combined_migration
2. Revisar resultados manualmente
3. Crear pull request manualmente (si exitoso)
4. Hacer merge manualmente
5. Esperar despliegue de GitHub Actions
```

### Ahora (Nueva Versión) 🚀
```
1. Ejecutar /combined_migration
2. ✅ AUTOMÁTICO: Evaluación de éxito
3. ✅ AUTOMÁTICO: Creación de pull request
4. ✅ AUTOMÁTICO: Merge del pull request  
5. ✅ AUTOMÁTICO: Disparo de GitHub Actions
6. ✅ AUTOMÁTICO: Backup y borrado del deployment original
```

## 🔄 Cambios en la Respuesta

### Nuevo: Mensaje de Estado Prominente
```
====================================================================================================
🚀 🚀 🚀 ESTADO DE DESPLIEGUE A DEV 🚀 🚀 🚀
====================================================================================================
           🚀 ✅ SE REALIZÓ DEPLOY AUTOMÁTICO A DEV
====================================================================================================
```

### Nuevo: Paso 3 de Despliegue
```
🚀 PASO 3: EVALUANDO DESPLIEGUE AUTOMÁTICO A DEV
------------------------------------------------------------
✅ Migración exitosa detectada - Iniciando pull request automático...
✅ PULL REQUEST CREADO Y MERGEADO EXITOSAMENTE
📍 Repositorio: owner/repo
🔗 PR #123: feat: Migración automática desde Pulse - Deploy a DEV
```

### Nuevo: Paso 4 de Backup y Cleanup
```
🗂️ PASO 4: BACKUP Y BORRADO DEL DEPLOYMENT ORIGINAL
------------------------------------------------------------
✅ Obteniendo deployment original de OpenShift...
✅ Deployment backup creado en GitHub: deployment-backup.yaml
✅ Deployment [old_name] eliminado exitosamente de OpenShift
📁 Backup disponible para rollback si es necesario
```

## 🔧 Requisitos de Configuración

### Token de GitHub - Permisos Adicionales
Si tu token actual no funciona, añade estos permisos:
```
✅ repo (ya existente)
🚀 NUEVO: pull_requests:write (crear PRs)
🚀 NUEVO: contents:write (hacer commits)
```

### Repositorio - Branches Requeridos
Asegúrate de que existen estos branches:
```
✅ feature/gluon-migration-config-from-pulse-import (source branch)
✅ development (target branch)
```

### GitHub Actions - Configuración de Despliegue
Debe haber workflows en el branch `development`:
```yaml
# .github/workflows/deploy-dev.yml
name: Deploy to DEV
on:
  push:
    branches: [development]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Deploy
        run: echo "Deploy to DEV"
```

## 🚨 Cambios Importantes de Comportamiento

### 1. ⏱️ Tiempo de Ejecución Ligeramente Mayor
- **Antes**: ~30-60 segundos
- **Ahora**: ~32-65 segundos (añade ~2-5 segundos para PR automático)

### 2. 🔄 Nuevos Estados de Salida
Ahora hay 4 posibles estados de despliegue:
- `🚀 ✅ SE REALIZÓ DEPLOY AUTOMÁTICO A DEV` (nuevo)
- `❌ NO SE PUDO REALIZAR DEPLOY AUTOMÁTICO A DEV` (nuevo)
- `❌ NO SE REALIZA DEPLOY A DEV (ERRORES EN MIGRACIÓN)` (nuevo)
- `❌ NO SE REALIZA DEPLOY A DEV (SIN MICROSERVICIOS)` (nuevo)

### 3. 📝 Pull Requests Automáticos
Se crearán PRs automáticamente con este formato:
- **Título**: `feat: Migración automática desde Pulse - Deploy a DEV`
- **Branch**: `feature/gluon-migration-config-from-pulse-import` → `development`
- **Merge**: Squash merge automático

## 🔍 Verificación Post-Migración

### Comprobar Estado de Despliegue
1. **En la respuesta del endpoint**: Busca el mensaje de estado al principio
2. **En GitHub**: Verifica que se creó y mergeó el PR automáticamente
3. **En GitHub Actions**: Confirma que se disparó el workflow de despliegue

### Si el Despliegue Automático Falla
```
❌ NO SE PUDO REALIZAR DEPLOY AUTOMÁTICO A DEV
```

**Posibles soluciones**:
1. Verificar que existen los branches necesarios
2. Comprobar permisos del token de GitHub
3. Revisar si `development` tiene branch protection rules
4. Confirmar que no hay conflictos de merge

### Rollback si es Necesario
Si algo sale mal con el despliegue:
1. Ve a GitHub → Tu repositorio → Pull Requests
2. Encuentra el PR automático (título: "feat: Migración automática desde Pulse...")
3. Haz rollback del merge si es necesario

## 🆔 Identificar PRs Automáticos

### Características de los PRs Automáticos
- **Título**: Siempre comienza con `feat: Migración automática desde Pulse`
- **Descripción**: Contiene información detallada de la migración
- **Branch**: Siempre `feature/gluon-migration-config-from-pulse-import` → `development`
- **Autor**: El usuario/bot asociado al token de GitHub utilizado

### Ejemplo de Descripción del PR
```markdown
## 🚀 Migración Automática desde Pulse

Esta migración fue generada automáticamente por el sistema de migración combinada.

### 📋 Cambios incluidos:
- ✅ Migración de ConfigMap
- ✅ Migración de microservicios
- 🔄 Configuración actualizada desde Pulse

### 🎯 Objetivo:
Desplegar automáticamente a DEV tras validación exitosa de todos los componentes.

**Creado automáticamente por:** Sistema de Migración Combinada
```

## 🔧 Troubleshooting Común

### Error: "Branch no existe"
```bash
# Crear el branch si falta
git checkout -b feature/gluon-migration-config-from-pulse-import
git push origin feature/gluon-migration-config-from-pulse-import
```

### Error: "Permisos insuficientes"
1. Ve a GitHub → Settings → Developer settings → Personal access tokens
2. Edita tu token
3. Asegúrate de tener marcado:
   - `repo` (Full control of private repositories)
   - Dentro de `repo`, específicamente `public_repo` si es público

### Error: "Branch protection rules"
Si `development` tiene protección:
1. Ve a Settings → Branches en tu repositorio
2. Edita las reglas de protección para `development`
3. Option 1: Desactiva temporalmente las protecciones
4. Option 2: Añade tu token/usuario como admin
5. Option 3: Habilita "Allow auto-merge"

## 📊 Monitoreo y Métricas

### Nuevas Métricas Disponibles
- **Tasa de despliegue automático**: % de migraciones que resultan en deploy
- **Tiempo de PR automático**: Tiempo para crear y mergear PR
- **Tasa de éxito de merge**: % de PRs automáticos exitosos

### Dashboard Recomendado
```
📈 Migración Combinada - Últimas 24h
├── Migraciones totales: 15
├── Migraciones exitosas: 12
├── Despliegues automáticos: 10
├── Fallos de PR: 2
└── Tiempo promedio: 45 segundos
```

## 🚀 Beneficios de la Nueva Funcionalidad

### Para Desarrolladores
- ⏱️ **Ahorro de tiempo**: No más pasos manuales post-migración
- 🔒 **Mayor seguridad**: Solo despliega si la migración fue exitosa
- 📊 **Mejor visibilidad**: Estado de despliegue claro al inicio del resultado

### Para DevOps
- 🤖 **Automatización completa**: Flujo end-to-end sin intervención manual
- 📋 **Trazabilidad mejorada**: PRs automáticos documentan todos los cambios
- 🔍 **Debugging más fácil**: Logs detallados de todo el proceso

### Para el Negocio
- 🚀 **Faster time-to-market**: Deploy inmediato tras migración exitosa
- 📉 **Menos errores**: Eliminación de pasos manuales propensos a error
- 💰 **Reducción de costos**: Menos tiempo manual de desarrolladores

## ❓ FAQ

### ¿Qué pasa si no quiero despliegue automático?
El despliegue solo ocurre si la migración es exitosa. Si hay errores, no se despliega automáticamente.

### ¿Puedo desactivar el despliegue automático?
Actualmente no hay opción para desactivarlo. Es parte integral del flujo `/combined_migration`.

### ¿Qué pasa si mi repositorio no tiene los branches necesarios?
El sistema reportará un error claro y no realizará el despliegue. Debes crear los branches manualmente.

### ¿El despliegue automático afecta otros branches?
No. Solo crea un PR desde `feature/gluon-migration-config-from-pulse-import` hacia `development`. Otros branches no se ven afectados.

### ¿Qué hago si el PR automático tiene conflictos?
El sistema reportará el error. Debes resolver los conflictos manualmente y luego hacer el merge desde GitHub.

### ¿Puedo modificar el mensaje/título del PR automático?
Actualmente no. Los PRs automáticos usan un formato estándar para consistencia y trazabilidad.