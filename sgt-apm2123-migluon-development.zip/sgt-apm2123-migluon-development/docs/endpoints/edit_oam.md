# Endpoint: /edit_oam

## Descripción General
Edita la configuración OAM (OpenShift Application Management) para el namespace y cluster especificados.

## Información del Endpoint
- **URL**: `/api/v1/migluon/edit_oam`
- **Método**: `POST`
- **Descripción**: Editar configuración OAM
- **Response**: Resultado de la edición OAM
- **Status Code**: 200
- **Response Class**: PlainTextResponse
- **Operation ID**: `edit_oam_configuration`

## Parámetros de Entrada (OamModel)
```json
{
  "appkey": "string",
  "registry_project": "string",
  "namespace": "string",
  "clusters": "string",
  "git_token": "string",
  "region_pre": "string",
  "url_git": "string"
}
```

### Descripción de Parámetros
- **appkey**: Clave de aplicación para identificación
- **registry_project**: Proyecto de registry asociado
- **namespace**: Namespace de Kubernetes donde se aplica la configuración
- **clusters**: Clusters objetivo para la configuración
- **git_token**: Token de GitHub para acceso a repositorios
- **region_pre**: Región de preproducción
- **url_git**: URL del repositorio Git que contiene la configuración OAM

## Validaciones Realizadas

### 1. Validación de Parámetros de Entrada
- **Verificación de campos obligatorios**: Todos los parámetros son requeridos
- **Validación del token de Git**: Se verifica que el token tenga permisos adecuados
- **Validación de la URL de Git**: Se normaliza y valida la estructura de la URL

### 2. Validación de Acceso al Repositorio
- **Acceso al repositorio**: Se verifica que el repositorio sea accesible con el token proporcionado
- **Verificación de permisos**: Se confirma que el token tenga permisos de escritura

### 3. Validación de Configuración OAM
- **Estructura del archivo OAM**: Se valida que el archivo tenga el formato esperado
- **Consistencia de clusters**: Se verifica que los clusters especificados sean válidos
- **Validación de namespace**: Se confirma que el namespace existe y es accesible

## Procesamiento Detallado

### Paso 1: Normalización de Parámetros
```python
# Normalización de URL de Git
normalized_url = normalize_git_url(oam_data.url_git)
owner, repo = extract_repo_info(normalized_url)
```

### Paso 2: Acceso al Repositorio OAM
```python
result = await edit_oam_unified(
    appkey=oam_data.appkey,
    registry_project=oam_data.registry_project,
    namespace=oam_data.namespace,
    clusters=oam_data.clusters,
    git_token=oam_data.git_token,
    region_pre=oam_data.region_pre,
    url_git=oam_data.url_git
)
```

### Paso 3: Procesamiento de Configuración OAM
- **Lectura de configuración existente**: Se obtiene la configuración actual del repositorio
- **Aplicación de cambios**: Se modifican los valores según los parámetros proporcionados
- **Validación de cambios**: Se verifica que los cambios sean consistentes
- **Commit de cambios**: Se suben los cambios al repositorio

## Funciones Internas Utilizadas

### `edit_oam_unified()`
- **Descripción**: Función principal que edita la configuración OAM
- **Responsabilidades**:
  - Acceder al repositorio OAM
  - Modificar la configuración según parámetros
  - Validar cambios antes del commit
  - Aplicar cambios al repositorio

### `normalize_git_url()`
- **Descripción**: Normaliza URLs de Git para formato consistente
- **Entrada**: URL de Git en diversos formatos
- **Salida**: URL normalizada para GitHub API

### `extract_repo_info()`
- **Descripción**: Extrae owner y nombre del repositorio de la URL
- **Entrada**: URL de Git normalizada
- **Salida**: Tupla (owner, repo)

## Validaciones Específicas de OAM

### 1. Validación de Estructura de Configuración
- **Formato YAML**: Se verifica que los archivos de configuración sean YAML válidos
- **Esquema de configuración**: Se valida contra el esquema esperado de OAM
- **Campos obligatorios**: Se verifica la presencia de campos requeridos

### 2. Validación de Consistencia
- **Namespace-Cluster**: Se verifica que la combinación namespace-cluster sea válida
- **Región-Cluster**: Se confirma que la región especificada coincida con el cluster
- **AppKey-Registry**: Se valida la consistencia entre appkey y registry_project

### 3. Validación de Permisos
- **Acceso de escritura**: Se confirma que el token tenga permisos de escritura en el repo
- **Permisos de namespace**: Se verifica acceso al namespace en OpenShift
- **Permisos de cluster**: Se confirma acceso a los clusters especificados

## Respuesta de Éxito
```
✅ CONFIGURACIÓN OAM ACTUALIZADA EXITOSAMENTE

Detalles de la configuración:
- AppKey: [appkey]
- Registry Project: [registry_project]
- Namespace: [namespace]
- Clusters: [clusters]
- Región Pre: [region_pre]

Cambios aplicados:
[Lista de cambios realizados en la configuración]

✅ Cambios committeados al repositorio: [url_git]
```

## Respuesta de Error
```
❌ ERROR EN CONFIGURACIÓN OAM

Tipo de error: [tipo_error]
Detalle: [detalle_error]

Parámetros utilizados:
- AppKey: [appkey]
- Registry Project: [registry_project]
- Namespace: [namespace]
- Clusters: [clusters]
- URL Git: [url_git]

⚠️ Verifique los parámetros y permisos, luego reintente.
```

## Casos de Error Comunes

### 1. Token de Git Inválido
- **Síntoma**: Error 401 al acceder al repositorio
- **Solución**: Verificar que el token tenga permisos de 'repo'

### 2. Repositorio OAM No Encontrado
- **Síntoma**: Error 404 al acceder al repositorio
- **Solución**: Verificar que la URL del repositorio sea correcta

### 3. Configuración OAM Inválida
- **Síntoma**: Errores de validación de esquema
- **Solución**: Revisar la estructura de los archivos de configuración

### 4. Permisos Insuficientes
- **Síntoma**: Error de permisos al modificar configuración
- **Solución**: Verificar permisos del token en el repositorio y cluster

## Logging
- **Inicio**: Registro de parámetros recibidos
- **Accesos**: Log de accesos a repositorio y cluster
- **Cambios**: Registro detallado de modificaciones realizadas
- **Resultado**: Log del resultado final (éxito/error)

## Casos de Uso
1. **Actualización de configuración de deployment**: Modificar parámetros de despliegue
2. **Cambio de región o cluster**: Migrar configuración entre entornos
3. **Actualización de credenciales**: Modificar referencias a secrets y configmaps
4. **Sincronización de configuración**: Alinear configuración OAM con cambios en la aplicación

## Consideraciones de Seguridad
- El token de Git debe tener permisos mínimos necesarios (solo 'repo')
- Los cambios se validan antes de ser aplicados
- Se mantiene un log completo de todas las modificaciones
- Los datos sensibles se manejan de forma segura sin exposición en logs