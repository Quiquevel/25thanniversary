# Endpoint: /robot_deployertoken

## Descripción General
Inserta credenciales de robot account existente y contraseña en Vault para proyectos de registry específicos.

## Información del Endpoint
- **URL**: `/api/v1/migluon/robot_deployertoken`
- **Método**: `POST`
- **Descripción**: Insert existing robotaccount and password in Vault
- **Response**: Resumen en texto plano de lo ocurrido
- **Status Code**: 200
- **Response Class**: PlainTextResponse
- **Operation ID**: `robot_deployertoken_insert`

## Parámetros de Entrada (AllTasksModel)
```json
{
  "registry_project": "string",
  "appkey": "string", 
  "namespace": "string",
  "clusters": "string",
  "vault_token": "string"
}
```

### Descripción de Parámetros
- **registry_project**: Nombre del proyecto de registry (convertido a minúsculas)
- **appkey**: Clave de aplicación (convertido a minúsculas)
- **namespace**: Namespace de Kubernetes (convertido a minúsculas)
- **clusters**: Clusters donde se desplegará (convertido a minúsculas)
- **vault_token**: Token de Vault para autenticación

## Validaciones Realizadas

### 1. Validación del Token de Vault (CRÍTICA)
- **Ubicación**: Inicio del proceso, antes de cualquier operación
- **Función**: `validate_vault_token(vault_token)`
- **Comportamiento**:
  - ✅ **Si es válido**: Continúa con la ejecución
  - ❌ **Si es inválido**: Termina inmediatamente sin crear recursos
- **Motivo**: Evitar crear recursos huérfanos que no se puedan almacenar en Vault

### 2. Conversión de Parámetros
- Todos los parámetros string se convierten a minúsculas:
  - `registry_project.lower()`
  - `appkey.lower()`
  - `namespace.lower()`
  - `clusters.lower()`

## Procesamiento Detallado

### Paso 1: Validación de Token de Vault
```python
vault_validation = validate_vault_token(vault_token)
if not vault_validation.get("valid", False):
    return error_message  # Termina sin ejecutar operaciones
```

### Paso 2: Creación de Robot Accounts
```python
result = await create_robot_accounts_by_env_type(
    registry_project=registry_project,
    appkey=appkey,
    clusters=clusters,
    vault_token=vault_token
)
```

## Funciones Internas Utilizadas

### `robot_deployertoken_service()`
- **Descripción**: Orquestador principal del proceso
- **Responsabilidades**:
  - Validar token de Vault
  - Coordinar creación de robot accounts
  - Formatear respuesta final

### `validate_vault_token()`
- **Descripción**: Valida que el token de Vault sea funcional
- **Retorna**: Dict con `{"valid": bool, "error": str}`

### `create_robot_accounts_by_env_type()`
- **Descripción**: Crea robot accounts para los tipos de entorno especificados
- **Parámetros**: registry_project, appkey, clusters, vault_token
- **Retorna**: Resumen en texto plano del proceso

## Respuesta de Éxito
```
✅ Token de Vault validado correctamente
🔐 Creando robot accounts para proyecto: [registry_project]
📦 AppKey: [appkey]
🌐 Clusters: [clusters]
📍 Namespace: [namespace]

[Detalles del proceso de creación de robot accounts...]

✅ Proceso completado exitosamente
```

## Respuesta de Error
```
❌ ERROR CRÍTICO: Token de Vault inválido

Detalle del error: [error_message]

⚠️ No se ejecutaron operaciones para evitar crear recursos huérfanos.
⚠️ Verifique el token de Vault y vuelva a intentar.

Parámetros de la solicitud:
- Registry Project: [registry_project]
- AppKey: [appkey]
- Namespace: [namespace]
- Clusters: [clusters]
```

## Logging
- **Éxito**: `"✅ Token de Vault validado - procediendo con la ejecución"`
- **Error**: `"❌ VALIDACIÓN VAULT FALLIDA: [error]"`

## Casos de Uso
1. **Configuración inicial de CI/CD**: Preparar credenciales para pipeline de deployment
2. **Rotación de credenciales**: Actualizar robot accounts existentes
3. **Setup de nuevos proyectos**: Configurar acceso automatizado a registries

## Consideraciones de Seguridad
- El token de Vault se valida antes de cualquier operación
- Los parámetros se normalizan para evitar inconsistencias
- No se crean recursos sin confirmación de almacenamiento en Vault