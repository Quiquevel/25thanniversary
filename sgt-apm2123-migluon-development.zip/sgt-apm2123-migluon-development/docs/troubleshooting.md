# 🔧 Guía de Troubleshooting - Sistema de Migración MigLuon

## Tabla de Contenidos
- [Problemas de Deployment y Startup](#problemas-de-deployment-y-startup)
- [Problemas de Pull Request](#problemas-de-pull-request)
- [Errores de Branch Protection](#errores-de-branch-protection)
- [Conflictos no Resueltos](#conflictos-no-resueltos)
- [Problemas de Token y Permisos](#problemas-de-token-y-permisos)
- [Errores de API y Conectividad](#errores-de-api-y-conectividad)
- [Problemas de OpenShift](#problemas-de-openshift)
- [Logs y Debugging](#logs-y-debugging)

## Problemas de Deployment y Startup

### 🐳 "debug_startup.py: No such file or directory"

#### Síntomas
```
=== ENTRYPOINT DEBUG ===
Current directory: /opt/produban
Python version: Python 3.11.13
Environment: PRO
Darwin AppKey:
=== RUNNING DEBUG SCRIPT ===
python: can't open file '/opt/produban/debug_startup.py': [Errno 2] No such file or directory
```

#### Causa
El ENTRYPOINT del contenedor Docker está intentando ejecutar un archivo `debug_startup.py` que fue eliminado durante refactorizaciones o limpiezas de código.

#### Solución Aplicada
Se ha actualizado el `entrypoint.sh` para verificar la existencia del archivo antes de ejecutarlo:

```bash
# Verificación condicional del debug script
if [ -f "debug_startup.py" ]; then
    echo "=== RUNNING DEBUG SCRIPT ==="
    python debug_startup.py
else
    echo "ℹ️ Debug script not found, skipping..."
fi
```

#### Prevención
- Revisar `entrypoint.sh` antes de eliminar archivos de startup
- Mantener sincronizado el ENTRYPOINT con los archivos disponibles
- Usar verificaciones condicionales para archivos opcionales

### 🚢 "Container fails to start in OpenShift"

#### Síntomas Comunes
```
# Pod no inicia correctamente
CrashLoopBackOff
Error: failed to start container

# Logs de container
ModuleNotFoundError: No module named 'src'
ImportError: cannot import name 'app' from 'src.app.main'
```

#### Diagnóstico
```bash
# Verificar logs del pod
oc logs pod-name -f

# Verificar estructura de archivos en el container
oc exec pod-name -- ls -la /opt/produban/

# Verificar variables de entorno
oc exec pod-name -- env | grep -E "(ENVIRONMENT|DARWIN|PYTHONPATH)"
```

#### Soluciones Comunes
1. **Verificar PYTHONPATH**: Asegurar que `/opt/produban` está en el PYTHONPATH
2. **Revisar estructura de archivos**: Confirmar que `src/` existe y tiene `__init__.py`
3. **Validar imports**: Verificar que todos los módulos importados existen

### 🔧 "Gunicorn configuration errors"

#### Síntomas
```
[ERROR] Invalid configuration
[ERROR] Can't connect to host
[ERROR] Worker timeout
```

#### Verificación de Configuración
```python
# Verificar gunicorn_config.py
bind = "0.0.0.0:8080"
workers = 4
worker_class = "uvicorn.workers.UvicornWorker"
timeout = 30
keepalive = 2
```

#### Solución
- Verificar que el puerto 8080 esté disponible
- Ajustar número de workers según recursos disponibles
- Revisar timeout según complejidad de la aplicación

## Problemas de Pull Request

### 🚫 "PR mergeable=None" o "state=unknown"

#### Síntomas
```
🔍 Estado del PR #11: mergeable=None, state=unknown
⏳ GitHub aún está evaluando PR #11, esperando...
```

#### Causa
GitHub necesita tiempo para evaluar el estado del Pull Request, especialmente en repositorios grandes o con muchas validaciones.

#### Solución Automática
El sistema esperará automáticamente 5 segundos y re-evaluará el estado.

#### Solución Manual
```bash
# Verificar estado del PR manualmente
curl -H "Authorization: token YOUR_TOKEN" \
  "https://api.github.com/repos/OWNER/REPO/pulls/PR_NUMBER"
```

#### Prevención
- Asegurar que el repositorio tenga configuraciones de GitHub Actions optimizadas
- Reducir el número de validaciones obligatorias si es posible

### 🔄 "PR created but not merged automatically"

#### Síntomas
```
✅ Pull request creado: #11
❌ No se pudo hacer merge automático
```

#### Causas Posibles
1. **Branch Protection Rules activas**
2. **Conflictos no detectados inicialmente**
3. **Validaciones de CI/CD pendientes**
4. **Permisos insuficientes**

#### Diagnóstico
```python
# Verificar estado completo del PR
GET /repos/{owner}/{repo}/pulls/{pr_number}

# Verificar branch protection
GET /repos/{owner}/{repo}/branches/{branch}/protection
```

#### Soluciones
1. **Automática**: El sistema intentará bypass o solicitará revisiones
2. **Manual**: Revisar y aprobar el PR manualmente

## Errores de Branch Protection

### 🛡️ "Branch protection rules prevent merge"

#### Síntomas
```
🛡️ Intentando bypass de branch protection para PR #11
❌ Bypass fallido: Required status checks not satisfied
👥 Solicitando revisión automática a code owners
```

#### Diagnóstico
```bash
# Verificar reglas de protección
curl -H "Authorization: token YOUR_TOKEN" \
  "https://api.github.com/repos/OWNER/REPO/branches/development/protection"
```

#### Estrategias de Resolución

##### 1. Bypass Automático (Requiere Admin)
```json
{
  "error": "bypass_failed",
  "reason": "insufficient_permissions",
  "action": "fallback_to_reviews"
}
```

##### 2. Revisiones Automáticas
```json
{
  "requested_reviewers": ["code-owner-1", "code-owner-2"],
  "team_reviewers": ["admin-team"]
}
```

##### 3. Configuración Recomendada
```yaml
# .github/CODEOWNERS
* @admin-team
/oam.yml @infra-team @pulse-team
/src/config/ @config-team @security-team
```

#### Solución Manual
1. Aprobar el PR como code owner
2. Configurar bypass temporal para tokens de servicio
3. Ajustar reglas de protección si es necesario

## Conflictos no Resueltos

### 🤖 "No OAM files found in conflict"

#### Síntomas
```
⚠️ No se encontraron archivos OAM en los files del PR
🔍 Buscando archivos OAM directamente en la rama feature...
⚠️ No se encontraron archivos OAM en la rama feature
```

#### Causas Posibles
1. **Archivos OAM no modificados en el PR**
2. **Naming convention diferente** (ej: `application.yml` en lugar de `oam.yml`)
3. **Archivos en subdirectorios no detectados**

#### Diagnóstico
```bash
# Buscar archivos OAM manualmente
curl -H "Authorization: token YOUR_TOKEN" \
  "https://api.github.com/repos/OWNER/REPO/git/trees/feature/gluon-migration-config-from-pulse-import?recursive=1" \
  | jq '.tree[] | select(.path | contains("oam"))'
```

#### Solución
1. **Verificar naming convention**: Asegurar que los archivos sigan el patrón `*.oam.yml` o `*.oam.yaml`
2. **Búsqueda manual**: Localizar archivos de configuración manualmente
3. **Configuración personalizada**: Ajustar patrones de búsqueda si es necesario

### 🔧 "Conflictos complejos no resueltos"

#### Síntomas
```
🔧 Detectados marcadores de conflicto en oam.yml, resolviendo...
❌ Conflictos no pudieron ser resueltos automáticamente
```

#### Tipos de Conflictos Complejos
```yaml
# Conflicto multi-línea
<<<<<<< feature/gluon-migration-config-from-pulse-import
- ci_id: "12345"
  name: "new-app-name"
  version: "2.0.0"
=======
- ci_id: "67890"
  name: "old-app-name"
  version: "1.0.0"
>>>>>>> development

# Conflicto anidado
spec:
  <<<<<<< feature/gluon-migration-config-from-pulse-import
  replicas: 3
  =======
  replicas: 1
  >>>>>>> development
```

#### Solución Manual
1. **Acceder al PR**: Usar el link proporcionado en el error
2. **Resolver conflicts**: Usar la interfaz de GitHub o Git CLI
3. **Mantener valores de Pulse**: Siempre priorizar valores de la rama feature

## Problemas de Token y Permisos

### 🔑 "Bad credentials" o "401 Unauthorized"

#### Síntomas
```
❌ Token no autorizado para wam-santander/repo-name (401)
⚠️ Verifica que el token tiene permisos de 'repo'
```

#### Verificación de Token
```bash
# Verificar permisos del token
curl -H "Authorization: token YOUR_TOKEN" \
  "https://api.github.com/user" \
  -I | grep X-OAuth-Scopes
```

#### Permisos Requeridos
```
Scopes requeridos:
- repo (acceso completo a repositorios)
- pull_requests:write (crear y modificar PRs)
- contents:write (modificar archivos)
- admin:org (para bypass de branch protection - opcional)
```

#### Solución
1. **Renovar token**: Generar nuevo Personal Access Token
2. **Verificar scopes**: Asegurar que tiene todos los permisos necesarios
3. **GitHub App**: Considerar usar GitHub App para permisos más granulares

### 👥 "Organization membership required"

#### Síntomas
```
❌ No tienes permisos de admin en la organización
🛡️ Bypass de branch protection no disponible
```

#### Verificación
```bash
# Verificar membresía en organización
curl -H "Authorization: token YOUR_TOKEN" \
  "https://api.github.com/orgs/ORGANIZATION/members/USERNAME"
```

#### Solución
1. **Solicitar membresía**: Contactar administradores de la organización
2. **Usar GitHub App**: Configurar GitHub App con permisos de organización
3. **Fallback manual**: Usar proceso de revisión manual

## Errores de API y Conectividad

### 🌐 "Rate limit exceeded"

#### Síntomas
```
❌ GitHub API rate limit exceeded
⏰ Reset time: 2025-09-23T21:30:00Z
```

#### Monitoreo
```bash
# Verificar límites actuales
curl -H "Authorization: token YOUR_TOKEN" \
  "https://api.github.com/rate_limit"
```

#### Solución
1. **Esperar reset**: Automático según el timestamp indicado
2. **Usar múltiples tokens**: Rotar entre diferentes tokens
3. **Optimizar requests**: Reducir llamadas API innecesarias

### 📡 "Connection timeout" o "Network error"

#### Síntomas
```
❌ Error de conectividad: Connection timeout
🔄 Reintentando en 30 segundos...
```

#### Diagnóstico
```bash
# Verificar conectividad
ping api.github.com
curl -I https://api.github.com

# Verificar DNS
nslookup api.github.com
```

#### Solución
1. **Verificar firewall**: Asegurar que puertos 80/443 estén abiertos
2. **Proxy configuration**: Configurar proxy corporativo si es necesario
3. **Retry automático**: El sistema reintentará automáticamente

## Problemas de OpenShift

### 🚢 "Deployment not found for cleanup"

#### Síntomas
```
🗑️ Iniciando cleanup de deployment: old-app-name
❌ Deployment old-app-name no encontrado en OpenShift
```

#### Causas Posibles
1. **Deployment ya eliminado**
2. **Nombre de deployment incorrecto**
3. **Namespace incorrecto**
4. **Permisos insuficientes en OpenShift**

#### Diagnóstico
```bash
# Verificar deployments en namespace
oc get deployments -n target-namespace

# Buscar por labels
oc get deployments -l app=old-app-name -A
```

#### Solución
1. **Verificación manual**: Confirmar si el deployment existe
2. **Skip cleanup**: Continuar sin cleanup si no es crítico
3. **Ajustar namespace**: Verificar namespace correcto

### 🔐 "OpenShift authentication failed"

#### Síntomas
```
❌ Error autenticando con OpenShift
🔑 Token o certificados inválidos
```

#### Solución
```bash
# Verificar token de OpenShift
oc whoami
oc auth can-i delete deployments

# Renovar token si es necesario
oc login --token=NEW_TOKEN
```

## Logs y Debugging

### 📋 Habilitación de Logs Detallados

#### Configuración
```python
import logging

# Configurar nivel de log
logging.getLogger("migration_orchestrator").setLevel(logging.DEBUG)
logging.getLogger("github_operations").setLevel(logging.DEBUG)
```

#### Variables de Entorno
```env
LOG_LEVEL=DEBUG
GITHUB_API_DEBUG=true
OPENSHIFT_DEBUG=true
```

### 🔍 Logs Clave para Troubleshooting

#### Estados de PR
```
🔍 Estado del PR #11: mergeable=false, state=dirty
⏳ GitHub aún está evaluando PR #11, esperando...
🔍 Estado actualizado del PR #11: mergeable=true, state=clean
```

#### Resolución de Conflictos
```
🔧 Detectados marcadores de conflicto en oam.yml, resolviendo...
✅ Conflictos resueltos en oam.yml
📋 Encontrados 2 archivos OAM: ['src/oam.yml', 'config/app.oam.yaml']
```

#### Branch Protection
```
🛡️ Intentando bypass de branch protection para PR #11
✅ Bypass exitoso - PR merged automáticamente
👥 Solicitando revisión automática a code owners: ['@admin-team']
```

### 📊 Métricas de Diagnóstico

#### Tiempo de Ejecución
```
⏰ Tiempo total de migración: 45.2 segundos
⏰ Tiempo de resolución de conflictos: 12.1 segundos
⏰ Tiempo de merge automático: 8.3 segundos
```

#### Tasas de Éxito
```
📈 Resolución automática de conflictos: 85% (17/20)
📈 Bypass de branch protection: 70% (14/20)
📈 Merge automático exitoso: 90% (18/20)
```

## 🆘 Escalación y Soporte

### Cuándo Escalar
1. **Errores persistentes** después de seguir troubleshooting
2. **Problemas de permisos** que requieren intervención administrativa
3. **Fallos sistemáticos** que afectan múltiples migraciones

### Información para Soporte
```yaml
incident_info:
  timestamp: "2025-09-23T20:52:39Z"
  operation: "combined_migration"
  repository: "wam-santander/ms-luon-gluo-app-san-gascor-front"
  pr_number: 11
  error_type: "branch_protection_bypass_failed"
  token_permissions: ["repo", "pull_requests:write"]
  github_api_rate_limit: "4750/5000"
  logs: |
    🛡️ Intentando bypass de branch protection para PR #11
    ❌ Bypass fallido: Required status checks not satisfied
    👥 Solicitando revisión automática a code owners
```

### Contactos de Soporte
- **GitHub Issues**: Crear issue en el repositorio del proyecto
- **Internal Support**: Contactar equipo de DevOps/SRE
- **Documentation**: Consultar `/docs` para información adicional

---

*Última actualización: Septiembre 2025*
*Para soporte adicional, consultar la documentación completa en `/docs`*