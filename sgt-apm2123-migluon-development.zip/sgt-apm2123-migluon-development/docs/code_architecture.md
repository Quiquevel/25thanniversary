# Arquitectura del Código - sgt-apm2123-migluon

## Resumen
Este documento describe la arquitectura actual del microservicio después de las optimizaciones de código realizadas en septiembre 2025.

## Estructura del Proyecto

```
src/
├── app/              # Configuración principal de la aplicación
├── handler/          # Controladores de endpoints
├── services/         # Lógica de negocio
│   ├── openshift/    # Integración con OpenShift
│   ├── git/          # Operaciones Git
│   └── utils/        # Utilidades compartidas
├── models/           # Modelos de datos
├── resources/        # Recursos y routers
└── utils/            # Utilidades generales
```

## Endpoints Principales

### API v1 - `/api/v1/migluon/`

| Endpoint | Método | Descripción |
|----------|--------|-------------|
| `/deploy-oam-yaml` | POST | Despliega configuración OAM YAML |
| `/deploy-config-map` | POST | Despliega ConfigMap |
| `/combined-migration` | POST | Migración combinada de servicios |
| `/deploy-micro` | POST | Despliega microservicio |
| `/all-tasks` | GET | Obtiene todas las tareas |

## Módulos Principales

### 1. Handler Layer (`src/handler/`)
- **`external_requests.py`**: Controlador principal de endpoints
- **Importaciones optimizadas**: Uso de importaciones específicas en lugar de wildcards
- **Modelos importados**: OamModel, ConfigMapModel, CombinedMigrationModel, MicroModel, AllTasksModel

### 2. Services Layer (`src/services/`)

#### OpenShift Integration (`src/services/openshift/`)
- **`processor.py`**: Procesamiento de deployments y OAM
- **`DeploymentData`**: Clase para gestión de datos de deployment y OAM
- **Funciones principales**:
  - `get_deployment_from_openshift()`
  - `get_oam_from_git()`
  - `get_secret_from_openshift()`
  - `get_openshift_client()`

#### Migration Services
- **`migration_orchestrator.py`**: Orquestación de migraciones
- **`back_values.py`**: Gestión de valores backend
- **`front_values.py`**: Gestión de valores frontend
- **`file_processors.py`**: Procesamiento de archivos

### 3. Models Layer (`src/models/`)
- Definición de modelos de datos para validación y serialización
- Integración con Pydantic para validación automática

## Optimizaciones Recientes (v2.1.2)

### ✅ Mejoras Implementadas

1. **Importaciones Optimizadas**
   - Eliminadas importaciones wildcard (`from module import *`)
   - Reemplazadas por importaciones específicas
   - Mejora en rendimiento y legibilidad

2. **Limpieza de Código**
   - Eliminados archivos de desarrollo obsoletos
   - Removidas funciones duplicadas
   - Consolidación de utilidades comunes

3. **Estructura Mejorada**
   - Mejor organización de imports
   - Eliminación de dependencias no utilizadas
   - Código más mantenible

### 🔧 Componentes Clave Preservados

- **`DeploymentData`**: Clase esencial para gestión de datos
- **Funcionalidad completa**: Todos los endpoints operativos
- **Compatibilidad**: Sin cambios breaking en la API

## Patrones de Diseño

### 1. Singleton Pattern
- Instancias globales: `deployment_data`, `front_deployment_data`
- Uso compartido entre módulos para consistencia

### 2. Factory Pattern
- Creación de clientes OpenShift
- Generación de modelos según tipo de operación

### 3. Service Layer Pattern
- Separación clara entre controladores y lógica de negocio
- Servicios especializados por dominio (OpenShift, Git, etc.)

## Dependencias Principales

### Runtime Dependencies
- FastAPI: Framework web
- Pydantic: Validación de datos
- PyYAML: Procesamiento YAML
- Requests: Cliente HTTP
- OpenShift Python Client: Integración K8s/OpenShift

### Development Dependencies
- Pytest: Testing framework
- Black: Code formatter
- Pipenv: Gestión de dependencias

## Consideraciones de Mantenimiento

### ✅ Buenas Prácticas Implementadas
- Importaciones explícitas y específicas
- Documentación de funciones y clases
- Separación de responsabilidades
- Manejo de errores consistente

### 📋 Recomendaciones Futuras
- Implementar type hints completos
- Añadir más tests unitarios
- Documentar APIs con OpenAPI
- Considerar refactoring de funciones muy largas

## Versionado

- **Versión Actual**: 2.1.2
- **Fecha**: 23 septiembre 2025
- **Cambios**: Optimización de código y limpieza estructural

---

*Documento actualizado automáticamente tras optimización de código*