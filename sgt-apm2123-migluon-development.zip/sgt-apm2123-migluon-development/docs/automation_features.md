# 🤖 Funcionalidades de Automatización Avanzada

## Resumen

Este documento describe las funcionalidades avanzadas de automatización implementadas en el sistema de migración MigLuon, incluyendo resolución automática de conflictos, bypass de branch protection rules, y manejo inteligente de estados de Pull Request.

## 🔧 Resolución Automática de Conflictos

### Descripción General
El sistema puede detectar y resolver automáticamente conflictos típicos en archivos OAM durante el proceso de merge de Pull Requests.

### Tipos de Conflictos Soportados

#### 1. Conflictos de `ci_id`
```yaml
# Conflicto típico detectado:
<<<<<<< feature/gluon-migration-config-from-pulse-import
- ci_id: "12345-pulse-value"
=======
- ci_id: "67890-old-value"
>>>>>>> development

# Resolución automática (mantiene valor de Pulse):
- ci_id: "12345-pulse-value"
```

### Algoritmo de Detección
1. **Búsqueda en PR Files**: Busca archivos OAM en los files del Pull Request
2. **Búsqueda Directa**: Si no encuentra, busca directamente en la rama feature usando GitHub Tree API
3. **Patrones de Archivos**: `*.oam.yml`, `*.oam.yaml`

### Estrategia de Resolución
- **Prioridad**: Siempre mantiene valores de la rama `feature` (datos correctos de Pulse)
- **Marcadores Soportados**: `<<<<<<< HEAD`, `<<<<<<< feature/*`, `=======`, `>>>>>>> development`
- **Limpieza**: Elimina todos los marcadores de conflicto residuales

### Implementación Técnica
```python
def _resolve_oam_conflicts(self, content: str) -> str:
    """
    Resuelve conflictos específicos en archivos OAM.
    Mantiene siempre la versión de la rama feature.
    """
    # Patrones múltiples para diferentes tipos de conflicto
    patterns = [
        # Feature branch específica
        r'<<<<<<< feature/gluon-migration-config-from-pulse-import\n(.*?- ci_id: [^\n]+)\n=======\n.*?- ci_id: [^\n]+\n>>>>>>> development',
        # HEAD genérico
        r'<<<<<<< HEAD\n(.*?- ci_id: [^\n]+)\n=======\n.*?- ci_id: [^\n]+\n>>>>>>> development'
    ]
```

## 🛡️ Bypass de Branch Protection Rules

### Descripción General
Sistema multi-nivel para superar reglas de protección de rama en repositorios con configuraciones restrictivas.

### Estrategias de Bypass

#### 1. Bypass Directo (Nivel Admin)
```python
# Usando GraphQL API para bypass directo
mutation {
  mergePullRequest(input: {
    pullRequestId: "PR_ID"
    mergeMethod: SQUASH
    authorEmail: "automation@company.com"
    expectedHeadOid: "commit_sha"
    bypassProtectionRules: true
  }) {
    pullRequest {
      merged
      mergedAt
    }
  }
}
```

#### 2. Solicitud Automática de Revisiones
```python
# Fallback: Solicitar revisión a code owners
POST /repos/{owner}/{repo}/pulls/{pull_number}/requested_reviewers
{
  "reviewers": ["code-owner-1", "code-owner-2"],
  "team_reviewers": ["team-admins"]
}
```

### Detección de Permisos
1. **Admin Token Check**: Verifica si el token tiene permisos de administrador
2. **Organization Membership**: Valida membresía en grupos con permisos especiales
3. **Fallback Strategy**: Si no tiene permisos admin, usa estrategia de revisiones

### Configuración Requerida
```yaml
# .github/CODEOWNERS
* @admin-team @code-owners
/oam.yml @infra-team
/src/config/ @config-team
```

## ⏰ Manejo Inteligente de Estados de PR

### Estados de Pull Request en GitHub

#### Estados Posibles
- `mergeable: true` - PR listo para merge
- `mergeable: false` - PR con conflictos
- `mergeable: null` - GitHub aún evaluando

#### Estados de Mergeable State
- `clean` - Sin conflictos, listo para merge
- `dirty` - Con conflictos
- `unstable` - Tests fallando
- `unknown` - Estado no determinado aún

### Lógica de Manejo
```python
# Esperar evaluación de GitHub
if mergeable is None or mergeable_state == 'unknown':
    logger.info("⏳ GitHub aún está evaluando PR, esperando...")
    await asyncio.sleep(5)
    
    # Re-verificar estado
    pr_recheck = await get_pr_status()
    mergeable = pr_recheck.get('mergeable', True)
    mergeable_state = pr_recheck.get('mergeable_state', 'unknown')

# Resolver conflictos si es necesario
if mergeable is False or mergeable_state in ['dirty', 'unstable']:
    resolve_success = await self._resolve_merge_conflicts()
```

### Timeouts y Reintentos
- **Timeout inicial**: 5 segundos para evaluación
- **Timeout máximo**: 30 segundos para casos complejos
- **Reintentos**: Hasta 3 intentos de re-evaluación

## 🚫 Prevención de GitHub Actions

### Problema Identificado
Los commits automáticos de migración activaban GitHub Actions innecesariamente, consumiendo recursos de CI/CD.

### Solución Implementada
```python
# Todos los commits automáticos incluyen [ci skip]
commit_message = f"feat: Migrar configuración desde Pulse - {microservice_name} [ci skip]"
merge_commit_message = f"feat: Deploy automático - {app_name} [ci skip]"
conflict_resolution_message = f"fix: Resolver conflictos automáticamente - mantener ci_id de Pulse [ci skip]"
```

### Beneficios
- **Reducción de Recursos**: Evita builds innecesarios
- **Optimización de Tiempo**: Acelera el proceso de migración
- **Selective Triggering**: Solo permite CI/CD en el merge final

## 📊 Métricas y Monitoreo

### Métricas Clave
- **Tasa de Resolución Automática**: % de conflictos resueltos sin intervención manual
- **Tiempo de Bypass**: Tiempo promedio para superar branch protection
- **Éxito de Merge Automático**: % de PRs merged automáticamente

### Logs de Auditoría
```python
logger.info(f"🔧 Detectados marcadores de conflicto en {file_path}, resolviendo...")
logger.info(f"✅ Conflictos resueltos en {file_path}")
logger.info(f"🛡️ Intentando bypass de branch protection para PR #{pr_number}")
logger.info(f"👥 Solicitando revisión automática a code owners")
```

## 🔧 Configuración y Personalización

### Variables de Entorno
```env
# Timeouts
GITHUB_PR_EVALUATION_TIMEOUT=30
CONFLICT_RESOLUTION_TIMEOUT=60

# Retry settings
MAX_PR_STATE_RETRIES=3
RETRY_DELAY_SECONDS=5

# Branch protection
BYPASS_PROTECTION_RULES=true
AUTO_REQUEST_REVIEWS=true
```

### Configuración de Repositorio
```json
{
  "conflict_resolution": {
    "enabled": true,
    "patterns": ["*.oam.yml", "*.oam.yaml"],
    "strategy": "keep_feature_values"
  },
  "branch_protection": {
    "bypass_enabled": true,
    "fallback_to_reviews": true,
    "required_reviewers": 1
  }
}
```

## 🚨 Limitaciones y Consideraciones

### Limitaciones Actuales
1. **Tipos de Conflicto**: Solo maneja conflictos de `ci_id` en archivos OAM
2. **Branch Names**: Diseñado específicamente para `feature/gluon-migration-config-from-pulse-import`
3. **GitHub API Limits**: Sujeto a rate limits de GitHub API

### Consideraciones de Seguridad
1. **Token Permissions**: Requiere tokens con permisos elevados para bypass
2. **Audit Trail**: Todos los bypasses quedan registrados en logs
3. **Fallback Safety**: Siempre tiene fallback a revisión manual

### Planes Futuros
- **Soporte Multi-Conflicto**: Manejo de conflictos en múltiples tipos de archivo
- **Machine Learning**: Aprendizaje de patrones de conflicto específicos
- **Integration Testing**: Simulación de conflictos para testing automatizado

---

*Última actualización: Septiembre 2025*
*Versión del sistema: v2.5.0*