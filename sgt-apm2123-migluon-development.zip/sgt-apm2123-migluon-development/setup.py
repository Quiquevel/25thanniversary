import setuptools
from version import __version__

setuptools.setup(
    name = "migluon",
    version = __version__,
    author = "Jonh Doe",
    author_email = "jonhdoe@mail.com",
    description = "Python package to do very cool stuff",
    long_description = "Long description of the microservice",
    long_description_content_type = "text/markdown",
    url = "http://mypythonpackage.com",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
        "ruamel.yaml",
        "aiohttp",
        "pytest",
        "pytest-asyncio",
        "pytest-mock",
        "pytest-cov",
        "jinja2",
    ],
    python_requires = '>=3.9',
)
