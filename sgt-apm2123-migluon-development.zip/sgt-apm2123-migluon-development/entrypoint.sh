#!/bin/bash

set -e  # Exit on any error

echo "=== ENTRYPOINT STARTUP ==="
echo "Current directory: $(pwd)"
echo "Python version: $(python --version)"
echo "Environment: $ENVIRONMENT"
echo "Darwin AppKey: $DARWIN_APPKEY"

# Basic health checks
echo "=== BASIC HEALTH CHECKS ==="
if [ ! -f "asgi.py" ]; then
    echo "❌ asgi.py not found!"
    exit 1
fi

if [ ! -f "gunicorn_config.py" ]; then
    echo "❌ gunicorn_config.py not found!"
    exit 1
fi

echo "✅ Required files found"
echo "=== STARTING GUNICORN ==="

# Add more verbose logging and error handling
exec gunicorn asgi:app \
    -c gunicorn_config.py \
    --capture-output \
    --enable-stdio-inheritance \
    --log-file=- \
    --access-logfile=- \
    --error-logfile=-
