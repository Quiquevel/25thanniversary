import setuptools
from version import __version__

setuptools.setup(
    name = "capacitywrite",
    version = __version__,
    author = "Francisco Javier Fuentes",
    author_email = "jonhdoe@mail.com",
    description = "Measure namespace capacity through CPU and MEMORY usage",
    long_description = "Microservice for measuring capacity and resource updating",
    long_description_content_type = "text/markdown",
    url = "http://mypythonpackage.com",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
    ],
    python_requires = '>=3.9',
)
