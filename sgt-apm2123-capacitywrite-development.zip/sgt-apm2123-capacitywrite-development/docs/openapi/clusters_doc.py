"""
This module contains the data model for user accounts.
"""

from pydantic import Field
from typing import Optional
from src.models.clusters import Clusters

class Cluster(Clusters):
    cluster: str = Field(default="string",json_schema_extra={"description":"cluster",'example':['prodarwin','sgt01.sgt.pro','gsc04.gsc.pro']})
    region: Optional[str] = Field(default="string",json_schema_extra={"description":"region",'example':['bo1','cn1']})
    namespace: Optional[str] = Field(default="string",json_schema_extra={"description":"namespaces",'example':['san-apreli-pro']})