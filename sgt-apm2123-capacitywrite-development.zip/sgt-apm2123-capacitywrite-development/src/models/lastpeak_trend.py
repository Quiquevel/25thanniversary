"""
This module contains the data model for user accounts.
"""

from pydantic import BaseModel, Field
from typing import Optional

class indicador(BaseModel):
    cluster: Optional[str] = None
    region: Optional[str] = None
    indicador: Optional[str] = None