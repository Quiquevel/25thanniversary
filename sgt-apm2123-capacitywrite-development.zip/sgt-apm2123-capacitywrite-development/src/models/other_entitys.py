"""
This module contains the data model for user accounts.
"""

from pydantic import BaseModel

class OthersEntitys(BaseModel):
    entityName: str
    cluster: str
    region: str = None
    namespace: str = None