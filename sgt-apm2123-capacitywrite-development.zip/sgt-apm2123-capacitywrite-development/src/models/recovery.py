"""
This module contains the data model for user accounts.
"""

from pydantic import BaseModel, Field
from typing import Optional

class Recovery(BaseModel):
    cluster: str
    dayWeek: str
    initialHour: str = 'yyyy-mm-ddThh:mm:ss.000Z'
    finalHour: str = 'yyyy-mm-ddThh:mm:ss.000Z'
    region: Optional[str] = None
    namespaceList: Optional[list] = None