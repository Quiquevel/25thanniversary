"""
This module contains the data model for user accounts.
"""

from pydantic import BaseModel, Field
from typing import Optional

class recomend(BaseModel):
    cluster: Optional[str] = None
    namespace: Optional[str] = None