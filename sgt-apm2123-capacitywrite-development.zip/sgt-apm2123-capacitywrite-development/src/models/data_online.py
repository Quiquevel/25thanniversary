"""
This module contains the data model for user accounts.
"""

from pydantic import BaseModel, Field

class dataonline(BaseModel):
    cluster: str
    namespace: str
    microservice: str