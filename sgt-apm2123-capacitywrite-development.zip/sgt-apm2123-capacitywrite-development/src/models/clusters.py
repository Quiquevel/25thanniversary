"""
This module contains the data model for user accounts.
"""

from pydantic import BaseModel, Field
from typing import Optional

class Clusters(BaseModel):
    cluster: str = Field(default="string",json_schema_extra={"description":"cluster"})
    region: Optional[str] = None
    namespace: Optional[str] = None