"""
This module contains the data model for user accounts.
"""

from pydantic import BaseModel, Field
from typing import Optional

class Clean(BaseModel):
    funtionality: str
    object: Optional[str] = None
    identificador: Optional[str] = None