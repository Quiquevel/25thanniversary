from .extract_resources import extract_resources
from .lastpeak import lastpeak
from .trend import trend
from .recomender import recomender
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(extract_resources,["resources"]),
    RouteClass(lastpeak,["lastpeak"]),
    RouteClass(trend,["trend"]),
    RouteClass(recomender,["recomender"]),
]