"""
This module contains the implementation of the FastAPI resources for the xxxxxxxxx and xxxxxxxxx endpoints.
"""

from fastapi import APIRouter
from fastapi.responses import JSONResponse
from src.services import Trend
import urllib3
from src.models.lastpeak_trend import indicador

urllib3.disable_warnings()

trend = APIRouter(tags=["trend"],prefix="/api/v1/sre-capacity")


@trend.post("/trend")
async def capacity_trend(reqs: indicador):
    """
    Endpoint for trends and desviations.
    
    This endpoint receives a request with the following parameters:
    - cluster: Optional[str]
    - region: Optional[str]
    - indicador: Optional[str]
    
    It returns a JSON response with the result of the trends.
    
    """
    return await Trend.getcapacitytrend(reqs.cluster,reqs.region,reqs.indicador)



@trend.post("/dump-WeekTrend")
async def dumpweektrend():
    """
    Endpoint for dump historical trend week colletions.

    No input parameters required.
    
    """
    return await Trend.historicalWeekTrend()
