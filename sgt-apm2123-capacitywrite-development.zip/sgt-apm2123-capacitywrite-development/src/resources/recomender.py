"""
This module contains the implementation of the FastAPI resources for the xxxxxxxxx and xxxxxxxxx endpoints.
"""

from fastapi import APIRouter
from fastapi.responses import JSONResponse
from src.services import Recomender
import urllib3
from src.models.recomender import recomend
from src.models.data_online import dataonline

urllib3.disable_warnings()

recomender = APIRouter(tags=["recomender"],prefix="/api/v1/sre-capacity")

@recomender.post("/recomender")
async def capacity_recomender(reqs: recomend):
    """
    Endpoint for recomender configurations.
    
    This endpoint receives a request with the following parameters:
    - cluster: Optional[str]
    - namespace: Optional[str]
    
    It returns a JSON response with the result of the recomendation.
    
    """
    return await Recomender.getcapacityrecomender(reqs.cluster,reqs.namespace)



@recomender.post("/dataOnlineRecomender")
async def dataonline_recomender(reqs: dataonline):
    """
    Endpoint for extract data online and calculate benefits.
    
    This endpoint receives a request with the following parameters:
    - cluster: str
    - namespace: str
    - microservice: str
    
    It returns a JSON response with the result of the recomendation.
    
    """
    return await Recomender.configOnline(reqs.cluster,reqs.namespace,reqs.microservice)



@recomender.post("/exportDiferentConf-Reco")
async def export_diferent_recomender(reqs: recomend):
    """
    Endpoint for export excel different between configuration & recomender.
    
    This endpoint receives a request with the following parameters:
    - cluster: str
    - namespace: str
    
    It returns a JSON response with the result.
    
    """
    return await Recomender.exportdifferentrecommendation(reqs.namespace,reqs.cluster)
