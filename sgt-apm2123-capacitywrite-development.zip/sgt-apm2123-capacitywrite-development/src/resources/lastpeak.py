"""
This module contains the implementation of the FastAPI resources for the xxxxxxxxx and xxxxxxxxx endpoints.
"""

from fastapi import APIRouter
from fastapi.responses import JSONResponse
from src.services import LastPeak
import urllib3
from src.models.lastpeak_trend import indicador

urllib3.disable_warnings()

lastpeak = APIRouter(tags=["lastpeak"],prefix="/api/v1/sre-capacity")

@lastpeak.post("/lastpeak")
async def capacity_lastpeak_resources(reqs: indicador):
    """
    Endpoint allows view the peaks of de last week's resources.
    Allows you to see the weekly and online peaks of both namespaces and microservices.
    
    This endpoint receives a request with the following parameters:
    - cluster: Optional[str]
    - region: Optional[str]
    - indicador: Optional[str]
    
    It returns a JSON response with the result of the peaks.
    
    """
    return await LastPeak.getcapacitylastpeak(reqs.cluster,reqs.region,reqs.indicador)



@lastpeak.get("/DescriptionLastPeak")
async def description_lastpeak():
    """
    Endpoint for getting description of the Lastpeak fields.

    No input parameters required.
    It returns a JSON response with the description of the Lastpeak fields.

    """
    return await LastPeak.getDescriptionLastPeak()



@lastpeak.post("/dump-WeekLastPeak")
async def dumpweeklastpeak():
    """
    Endpoint for dump historical lastPeak week colletions.

    No input parameters required.
    
    """
    return await LastPeak.historicalWeekPeak()



@lastpeak.post("/dump-WeekLastPeakMicroservice")
async def dumpweeklastpeakmicroservice():
    """
    Endpoint for dump historical lastPeak week colletions for microservices.

    No input parameters required.
    
    """
    return await LastPeak.historicalWeekPeakMicroservices()
