"""
This module contains the implementation of the FastAPI resources for the xxxxxxxxx and xxxxxxxxx endpoints.
"""

from fastapi import APIRouter
from src.services import Estructural,Online, Week, RecoveryInfoBeforeDaysOpenshift, IaaS_VRops, capacityClusterNamespace
import urllib3
from src.models.clusters import Clusters
from src.models.recovery import Recovery
from src.models.clean import Clean
from docs.openapi.clusters_doc import Cluster

urllib3.disable_warnings()

extract_resources = APIRouter(tags=["resources"],prefix="/api/v1/sre-capacity")

@extract_resources.post("/online",response_model=Cluster)
async def get_capacityonline(reqs: Clusters):
    """
    Endpoint for getting resources for CPU and MEMORY from elastic (use) and openshift (request-limit-hpa) from the last 15 minutes of the last pull.
    
    This endpoint receives a request with the following parameters:
    - cluster: str
    - region: Optional[str]
    - namespace: Optional[str]
    
    It returns a JSON response with the result of the resources.
    
    """
    return await Online.get_capacity_online(reqs.cluster,reqs.region,reqs.namespace)



@extract_resources.post("/week")
async def get_capacityweek(reqs: Clusters,response_model=Cluster):
    """
    Endpoint for getting resources for CPU and MEMORY from elastic (use) and openshift (request-limit-hpa) every day from 7:00 AM to 3:00 PM.
    
    This endpoint receives a request with the following parameters:
    - cluster: str
    - region: Optional[str]
    - namespace: Optional[str]
    
    It returns a JSON response with the result of the resources.
    
    """
    return await Week.get_capacity_week(reqs.cluster,reqs.region,reqs.namespace)



@extract_resources.post("/RecoveryInfoBeforeDaysOpenshift")
async def get_data(reqs: Recovery):
    """
    Endpoint for getting resources for CPU and MEMORY from elastic (use) and openshift (request-limit-hpa) every day from 7:00 AM to 3:00 PM of a specific day.
    
    This endpoint receives a request with the following parameters:
    - cluster: str
    - region: Optional[str]
    - namespace: Optional[str]
    
    It returns a JSON response with the result of the resources.
    
    """
    return await RecoveryInfoBeforeDaysOpenshift.get_capacity_week(reqs.cluster,reqs.dayWeek,reqs.initialHour,reqs.finalHour,reqs.region,reqs.namespaceList)



@extract_resources.post("/capacityClusterNamespace")
async def capacity_capacityclusternamespace():
    """
    Endpoint for getting capacity for cluster and namespaces from PaaS.
    
    No input parameters required.    
    It returns a JSON response with the result of the capacity.
    
    """
    return await capacityClusterNamespace.capacity_cluster()



@extract_resources.post("/iaas")
async def capacity_iaas():
    """
    Endpoint for getting resources for CPU and MEMORY from IAAS.
    
    No input parameters required.    
    It returns a JSON response with the result of the resources.
    
    """
    return await IaaS_VRops.get_iaas()



@extract_resources.get("/DescriptionOnline")
async def desciption_online():
    """
    Endpoint for getting description of the capacity online fields.

    No input parameters required.
    It returns a JSON response with the description of the fields.

    """
    return await Online.getDescriptionOnline()



@extract_resources.post("/dump-mongo")
async def dumpmongo():
    """
    Endpoint for dump colletions WEEK COLLECTION TO WEEK-OLD COLLECTION.

    No input parameters required.
    
    """
    return await Estructural.dumpDataMongoWeekToWeelOld()


@extract_resources.post("/clean-colections",response_model=Clean)
async def cleandata(reqs: Clean):
    """
    Endpoint for CLEAN COLLECTIONS.

    funtionality: str (e.g., "recomender", "lastpeak", "trend").

    objets: Optional[str] (e.g., "namespace", "microservice") <--- Only required for lastpeak.
    
    identificador: Optional[str] (e.g., "online", "week") <--- Only required for lastpeak and trend.
    
    """
    return await Estructural.cleaning_data(reqs.funtionality,reqs.object,reqs.identificador)


@extract_resources.post("/metrics_AKS")
async def metricsAKS():
    """
    Endpoint for endpoint to extract metrics from the AKS cluster.

    No input parameters required.
    
    """
    return await Estructural.metrics_AKS()
