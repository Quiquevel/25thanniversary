from shuttlelib.utils.logger import logger
import os
from src.services.Estructural import get_clusters,client,mg    

async def getcapacitytrend(cluster=None, region=None, indicador=None):
    functionalEnvironment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    '''
    if cluster == None and region == None and indicador == None:
        mg.change_collection(os.getenv("COLLECTION_SRE_TREND"))
        mg.delete_all_data()
    elif cluster == None and region == None and indicador == 'online':
        mg.change_collection(os.getenv("COLLECTION_SRE_TREND_ONLINE"))
        mg.delete_all_data()'
    '''
    match cluster:
        case None:
            clusters = await client.get_resource(resource="clusters",functional_environment=functionalEnvironment,cluster=None)
            for clust in clusters:
                try:
                    match region:
                        case None:
                            clustlist, clusterlistcomplete = await get_clusters()
                            reg = next((diccionario['region'] for diccionario in clustlist if clust in diccionario.values()), None)
                            '''
                            if clust == "azure" or clust == "ocp05azure" or clust == "dmzbazure":
                                regionlist = ['weu1', 'weu2']
                            elif clust == 'ocppro01.gsc.pro':
                                regionlist = ['weu']
                            elif clust == 'ocpgnr.gsc.pro':
                                regionlist = ['weu1']
                            elif clust == "sgt01.sgt.pro" or clust == "sgt01.sgt.dmzb" or clust == "gsc04.gsc.pro" or clust == "gsc04.gsc.dmzb":
                                regionlist = ['cn1', 'cn2']
                            elif clust == 'csa02.csa.pro' or clust == "gluon01.mex.pro" or clust == "grav01.mex.pro" or clust == "mex02.mex.pro" or clust == "mex02.mex.dmzb" or clust == "ocp01.mex.pro" or clust == "ocp02.mex.pro" or clust == "ocp03.mex.pro" or clust == "ocp04.mex.pro" or clust == "ocp05.mex.pro" or clust == "ocp06.mex.pro" or clust == "plard01.mex.pro" or clust == "str01.mex.pro" or clust == "gscmx01.gscmx.pro":
                                regionlist = ['mx1', 'mx2']
                            else:
                                regionlist = ['bo1', 'bo2']
                            '''
                            trend_namespace = []
                            for rlist in reg:
                                try:
                                    # Find cluster/region in bbdd
                                    if indicador == "online":
                                        mg.change_collection(os.getenv("COLLECTION_WEEK"))
                                    else:
                                        mg.change_collection(os.getenv("COLLECTION"))
                                    documents = list(mg.find({f"cluster": clust, f"region": rlist}))
                                    if documents:
                                        for docu in documents:
                                            try:
                                                del docu['_id']
                                                del docu['timestamp']
                                                uid = docu['uid']
                                                logger.info(f"########## Cluster {clust} - Region {rlist} ##########")
                                                logger.info(f"Namespace: {docu['namespace']}")
                                                if clust == "confluent":
                                                    trendnamespace = await trendConfluent(docu, indicador, uid)
                                                else:
                                                    trendnamespace = await trend(docu, indicador, uid)
                                                trend_namespace.append(trendnamespace)
                                            except:
                                                continue
                                except:
                                    continue   
                        case _:
                            # Find cluster/region in bbdd
                            trend_namespace = []
                            if indicador == "online":
                                mg.change_collection(os.getenv("COLLECTION_WEEK"))
                            else:
                                mg.change_collection(os.getenv("COLLECTION"))
                            documents = list(mg.find({f"cluster": clust, f"region": region}))
                            if documents:
                                for docu in documents:
                                    del docu['_id']
                                    del docu['timestamp']
                                    uid = docu['uid']
                                    logger.info(f"########## Cluster {clust} - Region {region} ##########")
                                    logger.info(f"Namespace: {docu['namespace']}")
                                    if clust == "confluent":
                                        trendnamespace = await trendConfluent(docu, indicador, uid)
                                    else:
                                        trendnamespace = await trend(docu, indicador, uid)
                                    trend_namespace.append(trendnamespace)
                            else:
                                logger.info(f"Data not found")
                except:
                    continue
        case _:
            match region:
                case None:
                    clustlist, clusterlistcomplete = await get_clusters()
                    reg = next((diccionario['region'] for diccionario in clustlist if cluster in diccionario.values()), None)
                    '''
                    if cluster == "azure" or cluster == "ocp05azure" or cluster == "dmzbazure":
                        regionlist = ['weu1', 'weu2']
                    elif cluster == 'ocppro01.gsc.pro':
                        regionlist = ['weu']
                    elif cluster == 'ocpgnr.gsc.pro':
                        regionlist = ['weu1']
                    elif cluster == "sgt01.sgt.pro" or cluster == "sgt01.sgt.dmzb" or cluster == "gsc04.gsc.pro" or cluster == "gsc04.gsc.dmzb":
                        regionlist = ['cn1', 'cn2']
                    elif cluster == 'csa02.csa.pro' or cluster == "gluon01.mex.pro" or cluster == "grav01.mex.pro" or cluster == "mex02.mex.pro" or cluster == "mex02.mex.dmzb" or cluster == "ocp01.mex.pro" or cluster == "ocp02.mex.pro" or cluster == "ocp03.mex.pro" or cluster == "ocp04.mex.pro" or cluster == "ocp05.mex.pro" or cluster == "ocp06.mex.pro" or cluster == "plard01.mex.pro" or cluster == "str01.mex.pro" or cluster == "gscmx01.gscmx.pro":
                        regionlist = ['mx1', 'mx2']
                    else:
                        regionlist = ['bo1', 'bo2']
                    '''
                    trend_namespace = []
                    for rlist in reg:
                        # Find cluster/region in bbdd
                        if indicador == "online":
                            mg.change_collection(os.getenv("COLLECTION_WEEK"))
                        else:
                            mg.change_collection(os.getenv("COLLECTION"))
                        documents = list(mg.find({f"cluster": cluster, f"region": rlist}))
                        if documents:
                            for docu in documents:
                                del docu['_id']
                                del docu['timestamp']
                                uid = docu['uid']
                                logger.info(f"########## Cluster {cluster} - Region {rlist} ##########")
                                logger.info(f"Namespace: {docu['namespace']}")
                                if cluster == "confluent":
                                    trendnamespace = await trendConfluent(docu, indicador, uid)
                                else:
                                    trendnamespace = await trend(docu, indicador, uid)
                                trend_namespace.append(trendnamespace)    
                case _:
                    # Find cluster/region in bbdd
                    trend_namespace = []
                    if indicador == "online":
                        mg.change_collection(os.getenv("COLLECTION_WEEK"))
                    else:
                        mg.change_collection(os.getenv("COLLECTION"))
                    documents = list(mg.find({f"cluster": cluster, f"region": region}))
                    if documents:
                        for docu in documents:
                            del docu['_id']
                            del docu['timestamp']
                            uid = docu['uid']
                            logger.info(f"########## Cluster {cluster} - Region {region} ##########")
                            logger.info(f"Namespace: {docu['namespace']}")
                            if cluster == "confluent":
                                trendnamespace = await trendConfluent(docu, indicador, uid)
                            else:
                                trendnamespace = await trend(docu, indicador, uid)
                            trend_namespace.append(trendnamespace)
                    else:
                        logger.info(f"Data not found")
    return trend_namespace


async def trendConfluent(docu, indicador, uid):
    trend_Microservices = []
    trend_Namespace = []
    marcador = False
    trendnamespace = {
        "uid": uid,
        "namespace": docu['namespace'],
        "region": docu['region'],
        "cluster": docu['cluster'],
        "marcador": marcador,
        "fechaReferenceDay": "referenceDay",
        "useCPUreferenceDay": 0,
        "useMEMreferenceDay": 0,
        "riskCPUreferenceDay": 0,
        "riskMEMreferenceDay": 0,
        "fechaD+1": "D+1",
        "useCPUD+1": 0,
        "useMEMD+1": 0,
        "riskCPUD+1": 0,
        "riskMEMD+1": 0,
        "fechaD+2": "D+2",
        "useCPUD+2": 0,
        "useMEMD+2": 0,
        "riskCPUD+2": 0,
        "riskMEMD+2": 0,
        "fechaD+3": "D+3",
        "useCPUD+3": 0,
        "useMEMD+3": 0,
        "riskCPUD+3": 0,
        "riskMEMD+3": 0,
        "fechaD+4": "D+4",
        "useCPUD+4": 0,
        "useMEMD+4": 0,
        "riskCPUD+4": 0,
        "riskMEMD+4": 0,
        "fechaD+5": "D+5",
        "useCPUD+5": 0,
        "useMEMD+5": 0,
        "riskCPUD+5": 0,
        "riskMEMD+5": 0,
        "fechaD+6": "D+6",
        "useCPUD+6": 0,
        "useMEMD+6": 0,
        "riskCPUD+6": 0,
        "riskMEMD+6": 0,
        "microservices": 0
    }
    trend_Namespace.append(trendnamespace)

    trendMicroservice = {
        "microservice": "microservices",
        "fechaReferenceDay": "referenceDay",
        "useCPUMicReferenceDay": 0,
        "useMEMMicReferenceDay": 0,
        "useMEMPromedioReferenceDay": 0,
        "useMEMAverageReferenceDay": 0,
        "riskCPUMicReferenceDay": 0,
        "riskMEMMicReferenceDay": 0,
        "fechaD+1": "D+1",
        "useCPUMicD+1": 0,
        "useCPUMicD+1Bruto": 0,
        "useMEMMicD+1Bruto": 0,
        "useMEMMicD+1": 0,
        "useMEMPromedioMicD+1": 0,
        "useMEMPromedioMicD+1Bruto": 0,
        "useMEMAverageMicD+1": 0,
        "riskCPUMicD+1": 0,
        "riskMEMMicD+1": 0,
        "posibleCausesCPUD+1": "posibleCausesCPUD+1",
        "posibleCausesMEMD+1": "posibleCausesMEMD+1",
        "fechaD+2": "D+2",
        "useCPUMicD+2": 0,
        "useCPUMicD+2Bruto": 0,
        "useMEMMicD+2Bruto": 0,
        "useMEMMicD+2": 0,
        "useMEMPromedioMicD+2": 0,
        "useMEMPromedioMicD+2Bruto": 0,
        "useMEMAverageMicD+2": 0,
        "riskCPUMicD+2": 0,
        "riskMEMMicD+2": 0,
        "posibleCausesCPUD+2": "posibleCausesCPUD+2",
        "posibleCausesMEMD+2": "posibleCausesMEMD+2",
        "fechaD+3": "D+3",
        "useCPUMicD+3": 0,
        "useCPUMicD+3Bruto": 0,
        "useMEMMicD+3Bruto": 0,
        "useMEMMicD+3": 0,
        "useMEMPromedioMicD+3": 0,
        "useMEMPromedioMicD+3Bruto": 0,
        "useMEMAverageMicD+3": 0,
        "riskCPUMicD+3": 0,
        "riskMEMMicD+3": 0,
        "posibleCausesCPUD+3": "posibleCausesCPUD+3",
        "posibleCausesMEMD+3": "posibleCausesMEMD+3",
        "fechaD+4": "D+4",
        "useCPUMicD+4": 0,
        "useCPUMicD+4Bruto": 0,
        "useMEMMicD+4Bruto": 0,
        "useMEMMicD+4": 0,
        "useMEMPromedioMicD+4": 0,
        "useMEMPromedioMicD+4Bruto": 0,
        "useMEMAverageMicD+4": 0,
        "riskCPUMicD+4": 0,
        "riskMEMMicD+4": 0,
        "posibleCausesCPUD+4": "posibleCausesCPUD+4",
        "posibleCausesMEMD+4": "posibleCausesMEMD+4",
        "fechaD+5": "D+5",
        "useCPUMicD+5": 0,
        "useCPUMicD+5Bruto": 0,
        "useMEMMicD+5Bruto": 0,
        "useMEMMicD+5": 0,
        "useMEMPromedioMicD+5": 0,
        "useMEMPromedioMicD+5Bruto": 0,
        "useMEMAverageMicD+5": 0,
        "riskCPUMicD+5": 0,
        "riskMEMMicD+5": 0,
        "posibleCausesCPUD+5": "posibleCausesCPUD+5",
        "posibleCausesMEMD+5": "posibleCausesMEMD+5",
        "fechaD+6": "D+6",
        "useCPUMicD+6": 0,
        "useCPUMicD+6Bruto": 0,
        "useMEMMicD+6Bruto": 0,
        "useMEMMicD+6": 0,
        "useMEMPromedioMicD+6": 0,
        "useMEMPromedioMicD+6Bruto": 0,
        "useMEMAverageMicD+6": 0,
        "riskCPUMicD+6": 0,
        "riskMEMMicD+6": 0,
        "posibleCausesCPUD+6": "posibleCausesCPUD+6",
        "posibleCausesMEMD+6": "posibleCausesMEMD+6"
    }
    date = docu['date']
    for day in date:
        try:
            dia = day["nameday"]
            match dia:
                case "Monday":
                    fecha = day['date']
                    MondayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            item["fechaReferenceDay"] = MondayfechaMMDD
                            item["useCPUreferenceDay"] = round(day["totalUseNamespaceCPU"],1)
                            item["useMEMreferenceDay"] = round(day["totalUseNamespaceMEM"],1)
                            item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            if micro['hpa'] == None:
                                useMEMAverageReferenceDay = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                            else:
                                useMEMAverageReferenceDay = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)

                            trendMicroservice = {
                                "microservice": micro["microservice"],
                                "fechaReferenceDay": MondayfechaMMDD,
                                "useCPUMicReferenceDay": micro["totalUseMicroserviceCPU"],
                                "useMEMMicReferenceDay": micro["totalUseMicroserviceMEM"],
                                "useMEMPromedioReferenceDay": micro["averageUseMicroserviceMEM"],
                                "useMEMAverageReferenceDay": useMEMAverageReferenceDay,
                                "riskCPUMicReferenceDay": micro["totalRiskCPUMicroservice"],
                                "riskMEMMicReferenceDay": micro["totalRiskMemoryMicroservice"],
                                "fechaD+1": "D+1",
                                "useCPUMicD+1": 0,
                                "useCPUMicD+1Bruto": 0,
                                "useMEMMicD+1Bruto": 0,
                                "useMEMMicD+1": 0,
                                "useMEMPromedioMicD+1": 0,
                                "useMEMPromedioMicD+1Bruto": 0,
                                "useMEMAverageMicD+1": 0,
                                "riskCPUMicD+1": 0,
                                "riskMEMMicD+1": 0,
                                "posibleCausesCPUD+1": "posibleCausesCPUD+1",
                                "posibleCausesMEMD+1": "posibleCausesMEMD+1",
                                "fechaD+2": "D+2",
                                "useCPUMicD+2": 0,
                                "useCPUMicD+2Bruto": 0,
                                "useMEMMicD+2Bruto": 0,
                                "useMEMMicD+2": 0,
                                "useMEMPromedioMicD+2": 0,
                                "useMEMPromedioMicD+2Bruto": 0,
                                "useMEMAverageMicD+2": 0,
                                "riskCPUMicD+2": 0,
                                "riskMEMMicD+2": 0,
                                "posibleCausesCPUD+2": "posibleCausesCPUD+2",
                                "posibleCausesMEMD+2": "posibleCausesMEMD+2",
                                "fechaD+3": "D+3",
                                "useCPUMicD+3": 0,
                                "useCPUMicD+3Bruto": 0,
                                "useMEMMicD+3Bruto": 0,
                                "useMEMMicD+3": 0,
                                "useMEMPromedioMicD+3": 0,
                                "useMEMPromedioMicD+3Bruto": 0,
                                "useMEMAverageMicD+3": 0,
                                "riskCPUMicD+3": 0,
                                "riskMEMMicD+3": 0,
                                "posibleCausesCPUD+3": "posibleCausesCPUD+3",
                                "posibleCausesMEMD+3": "posibleCausesMEMD+3",
                                "fechaD+4": "D+4",
                                "useCPUMicD+4": 0,
                                "useCPUMicD+4Bruto": 0,
                                "useMEMMicD+4Bruto": 0,
                                "useMEMMicD+4": 0,
                                "useMEMPromedioMicD+4": 0,
                                "useMEMPromedioMicD+4Bruto": 0,
                                "useMEMAverageMicD+4": 0,
                                "riskCPUMicD+4": 0,
                                "riskMEMMicD+4": 0,
                                "posibleCausesCPUD+4": "posibleCausesCPUD+4",
                                "posibleCausesMEMD+4": "posibleCausesMEMD+4",
                                "fechaD+5": "D+5",
                                "useCPUMicD+5": 0,
                                "useCPUMicD+5Bruto": 0,
                                "useMEMMicD+5Bruto": 0,
                                "useMEMMicD+5": 0,
                                "useMEMPromedioMicD+5": 0,
                                "useMEMPromedioMicD+5Bruto": 0,
                                "useMEMAverageMicD+5": 0,
                                "riskCPUMicD+5": 0,
                                "riskMEMMicD+5": 0,
                                "posibleCausesCPUD+5": "posibleCausesCPUD+5",
                                "posibleCausesMEMD+5": "posibleCausesMEMD+5",
                                "fechaD+6": "D+6",
                                "useCPUMicD+6": 0,
                                "useCPUMicD+6Bruto": 0,
                                "useMEMMicD+6Bruto": 0,
                                "useMEMMicD+6": 0,
                                "useMEMPromedioMicD+6": 0,
                                "useMEMPromedioMicD+6Bruto": 0,
                                "useMEMAverageMicD+6": 0,
                                "riskCPUMicD+6": 0,
                                "riskMEMMicD+6": 0,
                                "posibleCausesCPUD+6": "posibleCausesCPUD+6",
                                "posibleCausesMEMD+6": "posibleCausesMEMD+6"
                            }
                            trend_Microservices.append(trendMicroservice)

                            for item in trend_Namespace:
                                item["microservices"] = trend_Microservices
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                    else:
                        next
                    
                case "Tuesday":
                    fecha = day['date']
                    TuesdayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == TuesdayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+1"] = TuesdayfechaMMDD
                            item["useCPUD+1"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+1"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+1"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+1"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)

                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
                    
                    microservices = day["microservices"]

                    if len(trend_Microservices) == 0:
                        for micro in microservices:
                            try:
                                if micro['hpa'] == None:
                                    useMEMAverageReferenceDay = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                else:
                                    useMEMAverageReferenceDay = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)         

                                trendMicroservice = {
                                    "microservice": micro["microservice"],
                                    "fechaReferenceDay": TuesdayfechaMMDD,
                                    "useCPUMicReferenceDay": micro["totalUseMicroserviceCPU"],
                                    "useMEMMicReferenceDay": micro["totalUseMicroserviceMEM"],
                                    "useMEMPromedioReferenceDay": micro["averageUseMicroserviceMEM"],
                                    "useMEMAverageReferenceDay": useMEMAverageReferenceDay,
                                    "riskCPUMicReferenceDay": micro["totalRiskCPUMicroservice"],
                                    "riskMEMMicReferenceDay": micro["totalRiskMemoryMicroservice"],
                                    "fechaD+1": TuesdayfechaMMDD,
                                    "useCPUMicD+1": 0,
                                    "useCPUMicD+1Bruto": 0,
                                    "useMEMMicD+1Bruto": 0,
                                    "useMEMMicD+1": 0,
                                    "useMEMPromedioMicD+1": 0,
                                    "useMEMPromedioMicD+1Bruto": 0,
                                    "useMEMAverageMicD+1": 0,
                                    "riskCPUMicD+1": 0,
                                    "riskMEMMicD+1": 0,
                                    "posibleCausesCPUD+1": "posibleCausesCPUD+1",
                                    "posibleCausesMEMD+1": "posibleCausesMEMD+1",
                                    "fechaD+2": "D+2",
                                    "useCPUMicD+2": 0,
                                    "useCPUMicD+2Bruto": 0,
                                    "useMEMMicD+2Bruto": 0,
                                    "useMEMMicD+2": 0,
                                    "useMEMPromedioMicD+2": 0,
                                    "useMEMPromedioMicD+2Bruto": 0,
                                    "useMEMAverageMicD+2": 0,
                                    "riskCPUMicD+2": 0,
                                    "riskMEMMicD+2": 0,
                                    "posibleCausesCPUD+2": "posibleCausesCPUD+2",
                                    "posibleCausesMEMD+2": "posibleCausesMEMD+2",
                                    "fechaD+3": "D+3",
                                    "useCPUMicD+3": 0,
                                    "useCPUMicD+3Bruto": 0,
                                    "useMEMMicD+3Bruto": 0,
                                    "useMEMMicD+3": 0,
                                    "useMEMPromedioMicD+3": 0,
                                    "useMEMPromedioMicD+3Bruto": 0,
                                    "useMEMAverageMicD+3": 0,
                                    "riskCPUMicD+3": 0,
                                    "riskMEMMicD+3": 0,
                                    "posibleCausesCPUD+3": "posibleCausesCPUD+3",
                                    "posibleCausesMEMD+3": "posibleCausesMEMD+3",
                                    "fechaD+4": "D+4",
                                    "useCPUMicD+4": 0,
                                    "useCPUMicD+4Bruto": 0,
                                    "useMEMMicD+4Bruto": 0,
                                    "useMEMMicD+4": 0,
                                    "useMEMPromedioMicD+4": 0,
                                    "useMEMPromedioMicD+4Bruto": 0,
                                    "useMEMAverageMicD+4": 0,
                                    "riskCPUMicD+4": 0,
                                    "riskMEMMicD+4": 0,
                                    "posibleCausesCPUD+4": "posibleCausesCPUD+4",
                                    "posibleCausesMEMD+4": "posibleCausesMEMD+4",
                                    "fechaD+5": "D+5",
                                    "useCPUMicD+5": 0,
                                    "useCPUMicD+5Bruto": 0,
                                    "useMEMMicD+5Bruto": 0,
                                    "useMEMMicD+5": 0,
                                    "useMEMPromedioMicD+5": 0,
                                    "useMEMPromedioMicD+5Bruto": 0,
                                    "useMEMAverageMicD+5": 0,
                                    "riskCPUMicD+5": 0,
                                    "riskMEMMicD+5": 0,
                                    "posibleCausesCPUD+5": "posibleCausesCPUD+5",
                                    "posibleCausesMEMD+5": "posibleCausesMEMD+5",
                                    "fechaD+6": "D+6",
                                    "useCPUMicD+6": 0,
                                    "useCPUMicD+6Bruto": 0,
                                    "useMEMMicD+6Bruto": 0,
                                    "useMEMMicD+6": 0,
                                    "useMEMPromedioMicD+6": 0,
                                    "useMEMPromedioMicD+6Bruto": 0,
                                    "useMEMAverageMicD+6": 0,
                                    "riskCPUMicD+6": 0,
                                    "riskMEMMicD+6": 0,
                                    "posibleCausesCPUD+6": "posibleCausesCPUD+6",
                                    "posibleCausesMEMD+6": "posibleCausesMEMD+6"
                                }
                                trend_Microservices.append(trendMicroservice)
                            except:
                                logger.info(f"Something has gone wrong {dia}")
                                continue

                        for micro in microservices:
                            try:                    
                                for refDay in trend_Microservices:
                                    try:
                                        if micro["microservice"] == refDay["microservice"]:
                                            if refDay["fechaReferenceDay"] == "referenceDay":
                                                refDay["fechaReferenceDay"] = TuesdayfechaMMDD
                                            if refDay["useCPUMicReferenceDay"] == 0:
                                                refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                            if refDay["useMEMMicReferenceDay"] == 0:
                                                refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                            if refDay["useMEMPromedioReferenceDay"] == 0:
                                                refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                            if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                            if refDay["riskCPUMicReferenceDay"] == 0:
                                                refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                            if refDay["riskMEMMicReferenceDay"] == 0:
                                                refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]
                                            
                                            refDay["useCPUMicD+1"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                            refDay["useCPUMicD+1Bruto"] = micro["totalUseMicroserviceCPU"]
                                            refDay["useMEMMicD+1Bruto"] = micro["totalUseMicroserviceMEM"]
                                            refDay["useMEMMicD+1"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                            refDay["useMEMPromedioMicD+1Bruto"] = micro["averageUseMicroserviceMEM"]
                                            refDay["useMEMPromedioMicD+1"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                            if micro['hpa'] == None:
                                                refDay["useMEMAverageMicD+1"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                            else:
                                                refDay["useMEMAverageMicD+1"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                            refDay["riskCPUMicD+1"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                            refDay["riskMEMMicD+1"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                            refDay['fechaD+1'] = TuesdayfechaMMDD

                                            if os.getenv("ENTITY_ID") == "spain":
                                                refDay["posibleCausesCPUD+1"] = "posibleCausesCPUD+1"
                                                refDay["posibleCausesMEMD+1"] = "posibleCausesMEMD+1"
                                            
                                            if refDay["useCPUMicD+1"] > 300:
                                                marcador = True

                                            if refDay["useMEMMicD+1"] > 500:
                                                marcador = True

                                            for item in trend_Namespace:
                                                item["microservices"] = trend_Microservices

                                            break
                                    except:
                                        logger.info(f"Something has gone wrong {dia}")
                                        continue
                            except:
                                logger.info(f"Something has gone wrong {dia}")
                                continue

                    else:

                        for micro in microservices:
                            try:
                                for refDay in trend_Microservices:
                                    try:
                                        if micro["microservice"] == refDay["microservice"]:
                                            if refDay["fechaReferenceDay"] == "referenceDay":
                                                refDay["fechaReferenceDay"] = TuesdayfechaMMDD
                                            if refDay["useCPUMicReferenceDay"] == 0:
                                                refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                            if refDay["useMEMMicReferenceDay"] == 0:
                                                refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                            if refDay["useMEMPromedioReferenceDay"] == 0:
                                                refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                            if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                            if refDay["riskCPUMicReferenceDay"] == 0:
                                                refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                            if refDay["riskMEMMicReferenceDay"] == 0:
                                                refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                            refDay["useCPUMicD+1"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                            refDay["useCPUMicD+1Bruto"] = micro["totalUseMicroserviceCPU"]
                                            refDay["useMEMMicD+1Bruto"] = micro["totalUseMicroserviceMEM"]
                                            refDay["useMEMMicD+1"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                            refDay["useMEMPromedioMicD+1Bruto"] = micro["averageUseMicroserviceMEM"]
                                            refDay["useMEMPromedioMicD+1"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                            if micro['hpa'] == None:
                                                refDay["useMEMAverageMicD+1"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                            else:
                                                refDay["useMEMAverageMicD+1"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                            refDay["riskCPUMicD+1"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                            refDay["riskMEMMicD+1"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                            refDay['fechaD+1'] = TuesdayfechaMMDD

                                            if os.getenv("ENTITY_ID") == "spain":
                                                refDay["posibleCausesCPUD+1"] = "posibleCausesCPUD+1"
                                                refDay["posibleCausesMEMD+1"] = "posibleCausesMEMD+1"

                                            if refDay["useCPUMicD+1"] > 300:
                                                marcador = True

                                            if refDay["useMEMMicD+1"] > 500:
                                                marcador = True

                                            for item in trend_Namespace:
                                                item["microservices"] = trend_Microservices

                                            break
                                    except:
                                        logger.info(f"Something has gone wrong {dia}")
                                        continue
                            except:
                                logger.info(f"Something has gone wrong {dia}")
                                continue

                case "Wednesday":
                    fecha = day['date']
                    WednesdayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == WednesdayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)


                            item["fechaD+2"] = WednesdayfechaMMDD
                            item["useCPUD+2"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+2"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+2"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+2"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
                        
                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            for refDay in trend_Microservices:
                                try:                 
                                    if micro["microservice"] == refDay["microservice"]:
                                        if refDay["fechaReferenceDay"] == "referenceDay":
                                            refDay["fechaReferenceDay"] = WednesdayfechaMMDD
                                        if item["useCPUreferenceDay"] == 0:
                                            item["useCPUreferenceDay"] = day["totalUseMicroserviceCPU"]
                                        if item["useMEMreferenceDay"] == 0:
                                            item["useMEMreferenceDay"] = day["totalUseMicroserviceMEM"]
                                        if refDay["useMEMPromedioReferenceDay"] == 0:
                                            refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                        if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                        if item["riskCPUreferenceDay"] == 0:
                                            item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseMicroserviceCPU"]),1)
                                        if item["riskMEMreferenceDay"] == 0:
                                            item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseMicroserviceMEM"]),1)

                                        refDay["useCPUMicD+2"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                        refDay["useCPUMicD+2Bruto"] = micro["totalUseMicroserviceCPU"]
                                        refDay["useMEMMicD+2Bruto"] = micro["totalUseMicroserviceMEM"]
                                        refDay["useMEMMicD+2"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                        refDay["useMEMPromedioMicD+2"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                        refDay["useMEMPromedioMicD+2Bruto"] = micro["averageUseMicroserviceMEM"]
                                        if micro['hpa'] == None:
                                            refDay["useMEMAverageMicD+2"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                        else:
                                            refDay["useMEMAverageMicD+2"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                        refDay["riskCPUMicD+2"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                        refDay["riskMEMMicD+2"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                        refDay['fechaD+2'] = WednesdayfechaMMDD

                                        if os.getenv("ENTITY_ID") == "spain":
                                            refDay["posibleCausesCPUD+2"] = "posibleCausesCPUD+2"
                                            refDay["posibleCausesMEMD+2"] = "posibleCausesMEMD+2"

                                        if refDay["useCPUMicD+2"] > 300:
                                            marcador = True

                                        if refDay["useMEMMicD+2"] > 500:
                                            marcador = True

                                        for item in trend_Namespace:
                                            item["microservices"] = trend_Microservices

                                        break
                                except:
                                    logger.info(f"Something has gone wrong {dia}")
                                    continue
                        except:
                                logger.info(f"Something has gone wrong {dia}")
                                continue

                case "Thursday":
                    fecha = day['date']
                    ThursdayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == ThursdayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+3"] = ThursdayfechaMMDD
                            item["useCPUD+3"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+3"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+3"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+3"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
                        
                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            for refDay in trend_Microservices:
                                try:
                                    if micro["microservice"] == refDay["microservice"]:
                                        if refDay["fechaReferenceDay"] == "referenceDay":
                                            refDay["fechaReferenceDay"] = ThursdayfechaMMDD
                                        if refDay["useCPUMicReferenceDay"] == 0:
                                            refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                        if refDay["useMEMMicReferenceDay"] == 0:
                                            refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                        if refDay["useMEMPromedioReferenceDay"] == 0:
                                            refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                        if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                        if refDay["riskCPUMicReferenceDay"] == 0:
                                            refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                        if refDay["riskMEMMicReferenceDay"] == 0:
                                            refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                        refDay["useCPUMicD+3"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                        refDay["useCPUMicD+3Bruto"] = micro["totalUseMicroserviceCPU"]
                                        refDay["useMEMMicD+3Bruto"] = micro["totalUseMicroserviceMEM"]
                                        refDay["useMEMMicD+3"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                        refDay["useMEMPromedioMicD+3"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                        refDay["useMEMPromedioMicD+3Bruto"] = micro["averageUseMicroserviceMEM"]
                                        if micro['hpa'] == None:
                                            refDay["useMEMAverageMicD+3"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                        else:
                                            refDay["useMEMAverageMicD+3"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                        refDay["riskCPUMicD+3"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                        refDay["riskMEMMicD+3"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                        refDay['fechaD+3'] = ThursdayfechaMMDD

                                        if os.getenv("ENTITY_ID") == "spain":
                                            refDay["posibleCausesCPUD+3"] = "posibleCausesCPUD+3"
                                            refDay["posibleCausesMEMD+3"] = "posibleCausesMEMD+3"

                                        if refDay["useCPUMicD+3"] > 300:
                                            marcador = True

                                        if refDay["useMEMMicD+3"] > 500:
                                            marcador = True

                                        for item in trend_Namespace:
                                            item["microservices"] = trend_Microservices

                                        break 
                                except:
                                    logger.info(f"Something has gone wrong {dia}")
                                    continue
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                case "Friday":
                    fecha = day['date']
                    FridayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == FridayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+4"] = FridayfechaMMDD
                            item["useCPUD+4"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+4"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+4"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+4"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            for refDay in trend_Microservices:
                                try:
                                    if micro["microservice"] == refDay["microservice"]:
                                        if refDay["fechaReferenceDay"] == "referenceDay":
                                            refDay["fechaReferenceDay"] = FridayfechaMMDD
                                        if refDay["useCPUMicReferenceDay"] == 0:
                                            refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                        if refDay["useMEMMicReferenceDay"] == 0:
                                            refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                        if refDay["useMEMPromedioReferenceDay"] == 0:
                                            refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                        if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                        if refDay["riskCPUMicReferenceDay"] == 0:
                                            refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                        if refDay["riskMEMMicReferenceDay"] == 0:
                                            refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                        refDay["useCPUMicD+4"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                        refDay["useCPUMicD+4Bruto"] = micro["totalUseMicroserviceCPU"]
                                        refDay["useMEMMicD+4Bruto"] = micro["totalUseMicroserviceMEM"]
                                        refDay["useMEMMicD+4"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                        refDay["useMEMPromedioMicD+4Bruto"] = micro["averageUseMicroserviceMEM"]
                                        refDay["useMEMPromedioMicD+4"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                        if micro['hpa'] == None:
                                            refDay["useMEMAverageMicD+4"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                        else:
                                            refDay["useMEMAverageMicD+4"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                        refDay["riskCPUMicD+4"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                        refDay["riskMEMMicD+4"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                        refDay['fechaD+4'] = FridayfechaMMDD

                                        if os.getenv("ENTITY_ID") == "spain":
                                            refDay["posibleCausesCPUD+4"] = "posibleCausesCPUD+4"
                                            refDay["posibleCausesMEMD+4"] = "posibleCausesMEMD+4"

                                        if refDay["useCPUMicD+4"] > 300:
                                            marcador = True

                                        if refDay["useMEMMicD+4"] > 500:
                                            marcador = True

                                        for item in trend_Namespace:
                                            item["microservices"] = trend_Microservices    

                                        break
                                except:
                                    logger.info(f"Something has gone wrong {dia}")
                                    continue
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                case "Saturday":
                    fecha = day['date']
                    SaturdayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == SaturdayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+5"] = SaturdayfechaMMDD
                            item["useCPUD+5"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+5"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+5"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+5"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            for refDay in trend_Microservices:
                                try:
                                    if micro["microservice"] == refDay["microservice"]:
                                        if refDay["fechaReferenceDay"] == "referenceDay":
                                            refDay["fechaReferenceDay"] = SaturdayfechaMMDD
                                        if refDay["useCPUMicReferenceDay"] == 0:
                                            refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                        if refDay["useMEMMicReferenceDay"] == 0:
                                            refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                        if refDay["useMEMPromedioReferenceDay"] == 0:
                                            refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                        if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                        if refDay["riskCPUMicReferenceDay"] == 0:
                                            refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                        if refDay["riskMEMMicReferenceDay"] == 0:
                                            refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]        

                                        refDay["useCPUMicD+5"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                        refDay["useCPUMicD+5Bruto"] = micro["totalUseMicroserviceCPU"]
                                        refDay["useMEMMicD+5Bruto"] = micro["totalUseMicroserviceMEM"]
                                        refDay["useMEMMicD+5"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                        refDay["useMEMPromedioMicD+5Bruto"] = micro["averageUseMicroserviceMEM"]
                                        refDay["useMEMPromedioMicD+5"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                        if micro['hpa'] == None:
                                            refDay["useMEMAverageMicD+5"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                        else:
                                            refDay["useMEMAverageMicD+5"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                        refDay["riskCPUMicD+5"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                        refDay["riskMEMMicD+5"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                        refDay['fechaD+5'] = SaturdayfechaMMDD

                                        if os.getenv("ENTITY_ID") == "spain":
                                            refDay["posibleCausesCPUD+5"] = "posibleCausesCPUD+5"
                                            refDay["posibleCausesMEMD+5"] = "posibleCausesMEMD+5"

                                        if refDay["useCPUMicD+5"] > 300:
                                            marcador = True

                                        if refDay["useMEMMicD+5"] > 500:
                                            marcador = True

                                        for item in trend_Namespace:
                                            item["microservices"] = trend_Microservices

                                        break
                                except:
                                    logger.info(f"Something has gone wrong {dia}")
                                    continue
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                case "Sunday":
                    fecha = day['date']
                    SundayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == SundayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+6"] = SundayfechaMMDD
                            item["useCPUD+6"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+6"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+6"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+6"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            for refDay in trend_Microservices:
                                try:
                                    if micro["microservice"] == refDay["microservice"]:
                                        if item ["fechaReferenceDay"] == "referenceDay":
                                            item ["fechaReferenceDay"] == SundayfechaMMDD
                                        if refDay["useCPUMicReferenceDay"] == 0:
                                            refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                        if refDay["useMEMMicReferenceDay"] == 0:
                                            refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                        if refDay["useMEMPromedioReferenceDay"] == 0:
                                            refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                        if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                        if refDay["riskCPUMicReferenceDay"] == 0:
                                            refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                        if refDay["riskMEMMicReferenceDay"] == 0:
                                            refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                        refDay["useCPUMicD+6"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                        refDay["useCPUMicD+6Bruto"] = micro["totalUseMicroserviceCPU"]
                                        refDay["useMEMMicD+6Bruto"] = micro["totalUseMicroserviceMEM"]
                                        refDay["useMEMMicD+6"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                        refDay["useMEMPromedioMicD+6Bruto"] = micro["averageUseMicroserviceMEM"]
                                        refDay["useMEMPromedioMicD+6"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                        if micro['hpa'] == None:
                                            refDay["useMEMAverageMicD+6"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                        else:
                                            refDay["useMEMAverageMicD+6"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                        refDay["riskCPUMicD+6"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                        refDay["riskMEMMicD+6"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                        refDay['fechaD+6'] = SundayfechaMMDD

                                        if os.getenv("ENTITY_ID") == "spain":
                                            refDay["posibleCausesCPUD+6"] = "posibleCausesCPUD+6"
                                            refDay["posibleCausesMEMD+6"] = "posibleCausesMEMD+6"

                                        if refDay["useCPUMicD+6"] > 300:
                                            marcador = True

                                        if refDay["useMEMMicD+6"] > 500:
                                            marcador = True

                                        for item in trend_Namespace:
                                            item["microservices"] = trend_Microservices

                                        break
                                except:
                                    logger.info(f"Something has gone wrong {dia}")
                                    continue
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
        except:
            logger.info(f"Something has gone wrong {day}")
            continue

    if indicador == "online":
        mg.change_collection(os.getenv("COLLECTION_SRE_TREND_ONLINE"))
    else:
        mg.change_collection(os.getenv("COLLECTION_SRE_TREND"))
    querydbresultsmemory = mg.find({f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" })
    findnamespacememory = [x for x in querydbresultsmemory]
    if len(findnamespacememory) == 0:                                
        mg.add_data(data=trendnamespace)
    else:
        for trend in trendnamespace.items():
            if trend[0] == 'uid':
                uid = trend[1]

            if trend[0] == 'namespace':
                namespace = trend[1]
            if trend[0] == 'region':
                region = trend[1]
            if trend[0] == 'cluster':
                cluster = trend[1]

            if trend[0] == 'marcador':
                marcador = trend[1]
            
            if trend[0] == 'fechaReferenceDay':
                fechaReferenceDay = trend[1]

            if trend[0] == 'useCPUreferenceDay':
                useCPUreferenceDay = trend[1]
            if trend[0] == 'useMEMreferenceDay':
                useMEMreferenceDay = trend[1]    
            if trend[0] == 'riskCPUreferenceDay':
                riskCPUreferenceDay = trend[1]
            if trend[0] == 'riskMEMreferenceDay':
                riskMEMreferenceDay = trend[1]

            if trend[0] == 'fechaD+1':
                fechaCPUD1 = trend[1]
            
            if trend[0] == 'useCPUD+1':
                useCPUD1 = trend[1]
            if trend[0] == 'useMEMD+1':
                useMEMD1 = trend[1]    
            if trend[0] == 'riskCPUD+1':
                riskCPUD1 = trend[1]
            if trend[0] == 'riskMEMD+1':
                riskMEMD1 = trend[1]

            if trend[0] == 'fechaD+2':
                fechaCPUD2 = trend[1]
            
            if trend[0] == 'useCPUD+2':
                useCPUD2 = trend[1]
            if trend[0] == 'useMEMD+2':
                useMEMD2 = trend[1]    
            if trend[0] == 'riskCPUD+2':
                riskCPUD2 = trend[1]
            if trend[0] == 'riskMEMD+2':
                riskMEMD2 = trend[1]

            if trend[0] == 'fechaD+3':
                fechaCPUD3 = trend[1]
            
            if trend[0] == 'useCPUD+3':
                useCPUD3 = trend[1]
            if trend[0] == 'useMEMD+3':
                useMEMD3 = trend[1]    
            if trend[0] == 'riskCPUD+3':
                riskCPUD3 = trend[1]
            if trend[0] == 'riskMEMD+3':
                riskMEMD3 = trend[1]

            if trend[0] == 'fechaD+4':
                fechaCPUD4 = trend[1]
            
            if trend[0] == 'useCPUD+4':
                useCPUD4 = trend[1]
            if trend[0] == 'useMEMD+4':
                useMEMD4 = trend[1]    
            if trend[0] == 'riskCPUD+4':
                riskCPUD4 = trend[1]
            if trend[0] == 'riskMEMD+4':
                riskMEMD4 = trend[1]

            if trend[0] == 'fechaD+5':
                fechaCPUD5 = trend[1]
            
            if trend[0] == 'useCPUD+5':
                useCPUD5 = trend[1]
            if trend[0] == 'useMEMD+5':
                useMEMD5 = trend[1]    
            if trend[0] == 'riskCPUD+5':
                riskCPUD5 = trend[1]
            if trend[0] == 'riskMEMD+5':
                riskMEMD5 = trend[1]

            if trend[0] == 'fechaD+6':
                fechaCPUD6 = trend[1]
            
            if trend[0] == 'useCPUD+6':
                useCPUD6 = trend[1]
            if trend[0] == 'useMEMD+6':
                useMEMD6 = trend[1]    
            if trend[0] == 'riskCPUD+6':
                riskCPUD6 = trend[1]
            if trend[0] == 'riskMEMD+6':
                riskMEMD6 = trend[1]            
            
            if trend[0] == 'microservices':
                microservices = trend[1]
                
        mg.update_one(
            { f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" },
            
            { '$set': {
                f"uid": uid,
                f"namespace": namespace,
                f"region": region,
                f"cluster": cluster,
                f"marcador": marcador,
                f"fechaReferenceDay": fechaReferenceDay,
                f"useCPUreferenceDay": useCPUreferenceDay,
                f"useMEMreferenceDay": useMEMreferenceDay,
                f"riskCPUreferenceDay": riskCPUreferenceDay,
                f"riskMEMreferenceDay": riskMEMreferenceDay,
                f"fechaD+1": fechaCPUD1,
                f"useCPUD+1": useCPUD1,
                f"useMEMD+1": useMEMD1,
                f"riskCPUD+1": riskCPUD1,
                f"riskMEMD+1": riskMEMD1,
                f"fechaD+2": fechaCPUD2,
                f"useCPUD+2": useCPUD2,
                f"useMEMD+2": useMEMD2,
                f"riskCPUD+2": riskCPUD2,
                f"riskMEMD+2": riskMEMD2,
                f"fechaD+3": fechaCPUD3,
                f"useCPUD+3": useCPUD3,
                f"useMEMD+3": useMEMD3,
                f"riskCPUD+3": riskCPUD3,
                f"riskMEMD+3": riskMEMD3,
                f"fechaD+4": fechaCPUD4,
                f"useCPUD+4": useCPUD4,
                f"useMEMD+4": useMEMD4,
                f"riskCPUD+4": riskCPUD4,
                f"riskMEMD+4": riskMEMD4,
                f"fechaD+5": fechaCPUD5,
                f"useCPUD+5": useCPUD5,
                f"useMEMD+5": useMEMD5,
                f"riskCPUD+5": riskCPUD5,
                f"riskMEMD+5": riskMEMD5,
                f"fechaD+6": fechaCPUD6,
                f"useCPUD+6": useCPUD6,
                f"useMEMD+6": useMEMD6,
                f"riskCPUD+6": riskCPUD6,
                f"riskMEMD+6": riskMEMD6,
                f"microservices": microservices
                } 
            }  
        ) 
        
    return trendnamespace


async def trend(docu, indicador, uid):
    trend_Microservices = []
    trend_Namespace = []
    marcador = False
    trendnamespace = {
        "uid": uid,
        "namespace": docu['namespace'],
        "region": docu['region'],
        "cluster": docu['cluster'],
        "marcador": marcador,
        "fechaReferenceDay": "referenceDay",
        "useCPUreferenceDay": 0,
        "useMEMreferenceDay": 0,
        "riskCPUreferenceDay": 0,
        "riskMEMreferenceDay": 0,
        "fechaD+1": "D+1",
        "useCPUD+1": 0,
        "useMEMD+1": 0,
        "riskCPUD+1": 0,
        "riskMEMD+1": 0,
        "fechaD+2": "D+2",
        "useCPUD+2": 0,
        "useMEMD+2": 0,
        "riskCPUD+2": 0,
        "riskMEMD+2": 0,
        "fechaD+3": "D+3",
        "useCPUD+3": 0,
        "useMEMD+3": 0,
        "riskCPUD+3": 0,
        "riskMEMD+3": 0,
        "fechaD+4": "D+4",
        "useCPUD+4": 0,
        "useMEMD+4": 0,
        "riskCPUD+4": 0,
        "riskMEMD+4": 0,
        "fechaD+5": "D+5",
        "useCPUD+5": 0,
        "useMEMD+5": 0,
        "riskCPUD+5": 0,
        "riskMEMD+5": 0,
        "fechaD+6": "D+6",
        "useCPUD+6": 0,
        "useMEMD+6": 0,
        "riskCPUD+6": 0,
        "riskMEMD+6": 0,
        "microservices": 0
    }
    trend_Namespace.append(trendnamespace)

    trendMicroservice = {
        "microservice": "microservice",
        "fechaReferenceDay": "referenceDay",
        "useCPUMicReferenceDay": 0,
        "useMEMMicReferenceDay": 0,
        "useMEMPromedioReferenceDay": 0,
        "useMEMAverageReferenceDay": 0,
        "riskCPUMicReferenceDay": 0,
        "riskMEMMicReferenceDay": 0,
        "fechaD+1": "D+1",
        "useCPUMicD+1": 0,
        "useCPUMicD+1Bruto": 0,
        "useMEMMicD+1Bruto": 0,
        "useMEMMicD+1": 0,
        "useMEMPromedioMicD+1": 0,
        "useMEMPromedioMicD+1Bruto": 0,
        "useMEMAverageMicD+1": 0,
        "riskCPUMicD+1": 0,
        "riskMEMMicD+1": 0,
        "possibleCausesCPUD+1": "posibleCausesCPUD+1",
        "possibleCausesMEMD+1": "posibleCausesMEMD+1",
        "fechaD+2": "D+2",
        "useCPUMicD+2": 0,
        "useCPUMicD+2Bruto": 0,
        "useMEMMicD+2Bruto": 0,
        "useMEMMicD+2": 0,
        "useMEMPromedioMicD+2": 0,
        "useMEMPromedioMicD+2Bruto": 0,
        "useMEMAverageMicD+2": 0,
        "riskCPUMicD+2": 0,
        "riskMEMMicD+2": 0,
        "possibleCausesCPUD+2": "posibleCausesCPUD+2",
        "possibleCausesMEMD+2": "posibleCausesMEMD+2",
        "fechaD+3": "D+3",
        "useCPUMicD+3": 0,
        "useCPUMicD+3Bruto": 0,
        "useMEMMicD+3Bruto": 0,
        "useMEMMicD+3": 0,
        "useMEMPromedioMicD+3": 0,
        "useMEMPromedioMicD+3Bruto": 0,
        "useMEMAverageMicD+3": 0,
        "riskCPUMicD+3": 0,
        "riskMEMMicD+3": 0,
        "possibleCausesCPUD+3": "posibleCausesCPUD+3",
        "possibleCausesMEMD+3": "posibleCausesMEMD+3",
        "fechaD+4": "D+4",
        "useCPUMicD+4": 0,
        "useCPUMicD+4Bruto": 0,
        "useMEMMicD+4Bruto": 0,
        "useMEMMicD+4": 0,
        "useMEMPromedioMicD+4": 0,
        "useMEMPromedioMicD+4Bruto": 0,
        "useMEMAverageMicD+4": 0,
        "riskCPUMicD+4": 0,
        "riskMEMMicD+4": 0,
        "possibleCausesCPUD+4": "posibleCausesCPUD+4",
        "possibleCausesMEMD+4": "posibleCausesMEMD+4",
        "fechaD+5": "D+5",
        "useCPUMicD+5": 0,
        "useCPUMicD+5Bruto": 0,
        "useMEMMicD+5Bruto": 0,
        "useMEMMicD+5": 0,
        "useMEMPromedioMicD+5": 0,
        "useMEMPromedioMicD+5Bruto": 0,
        "useMEMAverageMicD+5": 0,
        "riskCPUMicD+5": 0,
        "riskMEMMicD+5": 0,
        "possibleCausesCPUD+5": "posibleCausesCPUD+5",
        "possibleCausesMEMD+5": "posibleCausesMEMD+5",
        "fechaD+6": "D+6",
        "useCPUMicD+6": 0,
        "useCPUMicD+6Bruto": 0,
        "useMEMMicD+6Bruto": 0,
        "useMEMMicD+6": 0,
        "useMEMPromedioMicD+6": 0,
        "useMEMPromedioMicD+6Bruto": 0,
        "useMEMAverageMicD+6": 0,
        "riskCPUMicD+6": 0,
        "riskMEMMicD+6": 0,
        "possibleCausesCPUD+6": "posibleCausesCPUD+6",
        "possibleCausesMEMD+6": "posibleCausesMEMD+6"
    }
    date = docu['date']
    for day in date:
        try:
            dia = day["nameday"]

            match dia:
                case "Monday":
                    fecha = day['date']
                    MondayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            item["fechaReferenceDay"] = MondayfechaMMDD
                            item["useCPUreferenceDay"] = round(day["totalUseNamespaceCPU"],1)
                            item["useMEMreferenceDay"] = round(day["totalUseNamespaceMEM"],1)
                            item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            if micro["blockProduction"] == "production":
                                microT = micro["microservice"]
                                if "-green" in microT:
                                    microTues = microT[:-6]
                                elif "-g" in microT:
                                    microTues = microT[:-2]
                                elif "-blue" in microT:
                                    microTues = microT[:-5]
                                elif "-b" in microT:
                                    microTues = microT[:-2]
                                else:
                                    microTues = micro["microservice"]

                                if micro['hpa'] == None:
                                    useMEMAverageReferenceDay = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                else:
                                    useMEMAverageReferenceDay = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)

                                trendMicroservice = {
                                    "microservice": microTues,
                                    "fechaReferenceDay": MondayfechaMMDD,
                                    "useCPUMicReferenceDay": micro["totalUseMicroserviceCPU"],
                                    "useMEMMicReferenceDay": micro["totalUseMicroserviceMEM"],
                                    "useMEMPromedioReferenceDay": micro["averageUseMicroserviceMEM"],
                                    "useMEMAverageReferenceDay": useMEMAverageReferenceDay,
                                    "riskCPUMicReferenceDay": micro["totalRiskCPUMicroservice"],
                                    "riskMEMMicReferenceDay": micro["totalRiskMemoryMicroservice"],
                                    "fechaD+1": "D+1",
                                    "useCPUMicD+1": 0,
                                    "useCPUMicD+1Bruto": 0,
                                    "useMEMMicD+1Bruto": 0,
                                    "useMEMMicD+1": 0,
                                    "useMEMPromedioMicD+1": 0,
                                    "useMEMPromedioMicD+1Bruto": 0,
                                    "useMEMAverageMicD+1": 0,
                                    "riskCPUMicD+1": 0,
                                    "riskMEMMicD+1": 0,
                                    "possibleCausesCPUD+1": "posibleCausesCPUD+1",
                                    "possibleCausesMEMD+1": "posibleCausesMEMD+1",
                                    "fechaD+2": "D+2",
                                    "useCPUMicD+2": 0,
                                    "useCPUMicD+2Bruto": 0,
                                    "useMEMMicD+2Bruto": 0,
                                    "useMEMMicD+2": 0,
                                    "useMEMPromedioMicD+2": 0,
                                    "useMEMPromedioMicD+2Bruto": 0,
                                    "useMEMAverageMicD+2": 0,
                                    "riskCPUMicD+2": 0,
                                    "riskMEMMicD+2": 0,
                                    "possibleCausesCPUD+2": "posibleCausesCPUD+2",
                                    "possibleCausesMEMD+2": "posibleCausesMEMD+2",
                                    "fechaD+3": "D+3",
                                    "useCPUMicD+3": 0,
                                    "useCPUMicD+3Bruto": 0,
                                    "useMEMMicD+3Bruto": 0,
                                    "useMEMMicD+3": 0,
                                    "useMEMPromedioMicD+3": 0,
                                    "useMEMPromedioMicD+3Bruto": 0,
                                    "useMEMAverageMicD+3": 0,
                                    "riskCPUMicD+3": 0,
                                    "riskMEMMicD+3": 0,
                                    "possibleCausesCPUD+3": "posibleCausesCPUD+3",
                                    "possibleCausesMEMD+3": "posibleCausesMEMD+3",
                                    "fechaD+4": "D+4",
                                    "useCPUMicD+4": 0,
                                    "useCPUMicD+4Bruto": 0,
                                    "useMEMMicD+4Bruto": 0,
                                    "useMEMMicD+4": 0,
                                    "useMEMPromedioMicD+4": 0,
                                    "useMEMPromedioMicD+4Bruto": 0,
                                    "useMEMAverageMicD+4": 0,
                                    "riskCPUMicD+4": 0,
                                    "riskMEMMicD+4": 0,
                                    "possibleCausesCPUD+4": "posibleCausesCPUD+4",
                                    "possibleCausesMEMD+4": "posibleCausesMEMD+4",
                                    "fechaD+5": "D+5",
                                    "useCPUMicD+5": 0,
                                    "useCPUMicD+5Bruto": 0,
                                    "useMEMMicD+5Bruto": 0,
                                    "useMEMMicD+5": 0,
                                    "useMEMPromedioMicD+5": 0,
                                    "useMEMPromedioMicD+5Bruto": 0,
                                    "useMEMAverageMicD+5": 0,
                                    "riskCPUMicD+5": 0,
                                    "riskMEMMicD+5": 0,
                                    "possibleCausesCPUD+5": "posibleCausesCPUD+5",
                                    "possibleCausesMEMD+5": "posibleCausesMEMD+5",
                                    "fechaD+6": "D+6",
                                    "useCPUMicD+6": 0,
                                    "useCPUMicD+6Bruto": 0,
                                    "useMEMMicD+6Bruto": 0,
                                    "useMEMMicD+6": 0,
                                    "useMEMPromedioMicD+6": 0,
                                    "useMEMPromedioMicD+6Bruto": 0,
                                    "useMEMAverageMicD+6": 0,
                                    "riskCPUMicD+6": 0,
                                    "riskMEMMicD+6": 0,
                                    "possibleCausesCPUD+6": "posibleCausesCPUD+6",
                                    "possibleCausesMEMD+6": "posibleCausesMEMD+6"
                                }
                                trend_Microservices.append(trendMicroservice)

                                for item in trend_Namespace:
                                    item["microservices"] = trend_Microservices
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
                    else:
                        next
                    
                case "Tuesday":
                    fecha = day['date']
                    TuesdayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == TuesdayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+1"] = TuesdayfechaMMDD
                            item["useCPUD+1"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+1"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+1"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+1"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
                    
                    microservices = day["microservices"]

                    if len(trend_Microservices) == 0:
                        for micro in microservices:
                            try:
                                microT = micro["microservice"]
                                if "-green" in microT:
                                    microTues = microT[:-6]
                                elif "-g" in microT:
                                    microTues = microT[:-2]
                                elif "-blue" in microT:
                                    microTues = microT[:-5]
                                elif "-b" in microT:
                                    microTues = microT[:-2]
                                else:
                                    microTues = micro["microservice"]

                                if micro['hpa'] == None:
                                    useMEMAverageReferenceDay = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                else:
                                    useMEMAverageReferenceDay = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)

                                trendMicroservice = {
                                    "microservice": microTues,
                                    "fechaReferenceDay": TuesdayfechaMMDD,
                                    "useCPUMicReferenceDay": micro["totalUseMicroserviceCPU"],
                                    "useMEMMicReferenceDay": micro["totalUseMicroserviceMEM"],
                                    "useMEMPromedioReferenceDay": micro["averageUseMicroserviceMEM"],
                                    "useMEMAverageReferenceDay": useMEMAverageReferenceDay,
                                    "riskCPUMicReferenceDay": micro["totalRiskCPUMicroservice"],
                                    "riskMEMMicReferenceDay": micro["totalRiskMemoryMicroservice"],
                                    "fechaD+1": TuesdayfechaMMDD,
                                    "useCPUMicD+1": 0,
                                    "useCPUMicD+1Bruto": 0,
                                    "useMEMMicD+1Bruto": 0,
                                    "useMEMMicD+1": 0,
                                    "useMEMPromedioMicD+1": 0,
                                    "useMEMPromedioMicD+1Bruto": 0,
                                    "useMEMAverageMicD+1": 0,
                                    "riskCPUMicD+1": 0,
                                    "riskMEMMicD+1": 0,
                                    "possibleCausesCPUD+1": "posibleCausesCPUD+1",
                                    "possibleCausesMEMD+1": "posibleCausesMEMD+1",
                                    "fechaD+2": "D+2",
                                    "useCPUMicD+2": 0,
                                    "useCPUMicD+2Bruto": 0,
                                    "useMEMMicD+2Bruto": 0,
                                    "useMEMMicD+2": 0,
                                    "useMEMPromedioMicD+2": 0,
                                    "useMEMPromedioMicD+2Bruto": 0,
                                    "useMEMAverageMicD+2": 0,
                                    "riskCPUMicD+2": 0,
                                    "riskMEMMicD+2": 0,
                                    "possibleCausesCPUD+2": "posibleCausesCPUD+2",
                                    "possibleCausesMEMD+2": "posibleCausesMEMD+2",
                                    "fechaD+3": "D+3",
                                    "useCPUMicD+3": 0,
                                    "useCPUMicD+3Bruto": 0,
                                    "useMEMMicD+3Bruto": 0,
                                    "useMEMMicD+3": 0,
                                    "useMEMPromedioMicD+3": 0,
                                    "useMEMPromedioMicD+3Bruto": 0,
                                    "useMEMAverageMicD+3": 0,
                                    "riskCPUMicD+3": 0,
                                    "riskMEMMicD+3": 0,
                                    "possibleCausesCPUD+3": "posibleCausesCPUD+3",
                                    "possibleCausesMEMD+3": "posibleCausesMEMD+3",
                                    "fechaD+4": "D+4",
                                    "useCPUMicD+4": 0,
                                    "useCPUMicD+4Bruto": 0,
                                    "useMEMMicD+4Bruto": 0,
                                    "useMEMMicD+4": 0,
                                    "useMEMPromedioMicD+4": 0,
                                    "useMEMPromedioMicD+4Bruto": 0,
                                    "useMEMAverageMicD+4": 0,
                                    "riskCPUMicD+4": 0,
                                    "riskMEMMicD+4": 0,
                                    "possibleCausesCPUD+4": "posibleCausesCPUD+4",
                                    "possibleCausesMEMD+4": "posibleCausesMEMD+4",
                                    "fechaD+5": "D+5",
                                    "useCPUMicD+5": 0,
                                    "useCPUMicD+5Bruto": 0,
                                    "useMEMMicD+5Bruto": 0,
                                    "useMEMMicD+5": 0,
                                    "useMEMPromedioMicD+5": 0,
                                    "useMEMPromedioMicD+5Bruto": 0,
                                    "useMEMAverageMicD+5": 0,
                                    "riskCPUMicD+5": 0,
                                    "riskMEMMicD+5": 0,
                                    "possibleCausesCPUD+5": "posibleCausesCPUD+5",
                                    "possibleCausesMEMD+5": "posibleCausesMEMD+5",
                                    "fechaD+6": "D+6",
                                    "useCPUMicD+6": 0,
                                    "useCPUMicD+6Bruto": 0,
                                    "useMEMMicD+6Bruto": 0,
                                    "useMEMMicD+6": 0,
                                    "useMEMPromedioMicD+6": 0,
                                    "useMEMPromedioMicD+6Bruto": 0,
                                    "useMEMAverageMicD+6": 0,
                                    "riskCPUMicD+6": 0,
                                    "riskMEMMicD+6": 0,
                                    "possibleCausesCPUD+6": "posibleCausesCPUD+6",
                                    "possibleCausesMEMD+6": "posibleCausesMEMD+6"
                                }
                                trend_Microservices.append(trendMicroservice)
                            except:
                                logger.info(f"Something has gone wrong {dia}")
                                continue

                        for micro in microservices:
                            try:
                                microT = micro["microservice"]
                                if "-green" in microT:
                                    microTues = microT[:-6]
                                elif "-g" in microT:
                                    microTues = microT[:-2]
                                elif "-blue" in microT:
                                    microTues = microT[:-5]
                                elif "-b" in microT:
                                    microTues = microT[:-2]
                                else:
                                    microTues = micro["microservice"]
                            
                                if micro["blockProduction"] == "production":
                                    for refDay in trend_Microservices:
                                        if microTues == refDay["microservice"]:
                                            if refDay["fechaReferenceDay"] == "referenceDay":
                                                refDay["fechaReferenceDay"] = TuesdayfechaMMDD
                                            if refDay["useCPUMicReferenceDay"] == 0:
                                                refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                            if refDay["useMEMMicReferenceDay"] == 0:
                                                refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                            if refDay["useMEMPromedioReferenceDay"] == 0:
                                                refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                            if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                            if refDay["riskCPUMicReferenceDay"] == 0:
                                                refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                            if refDay["riskMEMMicReferenceDay"] == 0:
                                                refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]
                                            
                                            refDay["useCPUMicD+1"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                            refDay["useCPUMicD+1Bruto"] = micro["totalUseMicroserviceCPU"]
                                            refDay["useMEMMicD+1Bruto"] = micro["totalUseMicroserviceMEM"]
                                            refDay["useMEMMicD+1"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                            refDay["useMEMPromedioMicD+1Bruto"] = micro["averageUseMicroserviceMEM"]
                                            refDay["useMEMPromedioMicD+1"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                            if micro['hpa'] == None:
                                                refDay["useMEMAverageMicD+1"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                            else:
                                                refDay["useMEMAverageMicD+1"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                            refDay["riskCPUMicD+1"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                            refDay["riskMEMMicD+1"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                            refDay['fechaD+1'] = TuesdayfechaMMDD
                                            
                                            if os.getenv("ENTITY_ID") == "spain":
                                                refDay['possibleCausesCPUD+1'] = micro['possibleCasesCPU']
                                                refDay['possibleCausesMEMD+1'] = micro['possibleCasesMEM']
                                            
                                            if refDay["useCPUMicD+1"] > 300:
                                                marcador = True

                                            if refDay["useMEMMicD+1"] > 500:
                                                marcador = True

                                            for item in trend_Namespace:
                                                item["microservices"] = trend_Microservices

                                            break
                                else:
                                    next           
                            except:
                                logger.info(f"Something has gone wrong {dia}")
                                continue
                    else:

                        for micro in microservices:
                            try:
                                microT = micro["microservice"]
                                if "-green" in microT:
                                    microTues = microT[:-6]
                                elif "-g" in microT:
                                    microTues = microT[:-2]
                                elif "-blue" in microT:
                                    microTues = microT[:-5]
                                elif "-b" in microT:
                                    microTues = microT[:-2]
                                else:
                                    microTues = micro["microservice"]
                            
                                if micro["blockProduction"] == "production":
                                    for refDay in trend_Microservices:
                                        if microTues == refDay["microservice"]:
                                            if refDay["fechaReferenceDay"] == "referenceDay":
                                                refDay["fechaReferenceDay"] = TuesdayfechaMMDD
                                            if refDay["useCPUMicReferenceDay"] == 0:
                                                refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                            if refDay["useMEMMicReferenceDay"] == 0:
                                                refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                            if refDay["useMEMPromedioReferenceDay"] == 0:
                                                refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                            if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageMicD+1"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                            if refDay["riskCPUMicReferenceDay"] == 0:
                                                refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                            if refDay["riskMEMMicReferenceDay"] == 0:
                                                refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                            refDay["useCPUMicD+1"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                            refDay["useCPUMicD+1Bruto"] = micro["totalUseMicroserviceCPU"]
                                            refDay["useMEMMicD+1Bruto"] = micro["totalUseMicroserviceMEM"]
                                            refDay["useMEMMicD+1"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                            refDay["useMEMPromedioMicD+1Bruto"] = micro["averageUseMicroserviceMEM"]
                                            refDay["useMEMPromedioMicD+1"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                            if micro['hpa'] == None:
                                                refDay["useMEMAverageMicD+1"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                            else:
                                                refDay["useMEMAverageMicD+1"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                            refDay["riskCPUMicD+1"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                            refDay["riskMEMMicD+1"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                            refDay['fechaD+1'] = TuesdayfechaMMDD

                                            if os.getenv("ENTITY_ID") == "spain":
                                                refDay['possibleCausesCPUD+1'] = micro['possibleCasesCPU']
                                                refDay['possibleCausesMEMD+1'] = micro['possibleCasesMEM']

                                            if refDay["useCPUMicD+1"] > 300:
                                                marcador = True

                                            if refDay["useMEMMicD+1"] > 500:
                                                marcador = True

                                            for item in trend_Namespace:
                                                item["microservices"] = trend_Microservices

                                            break
                                else:
                                    next
                            except:
                                logger.info(f"Something has gone wrong {dia}")
                                continue

                case "Wednesday":
                    fecha = day['date']
                    WednesdayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == WednesdayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+2"] = WednesdayfechaMMDD
                            item["useCPUD+2"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+2"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+2"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+2"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            if micro["blockProduction"] == "production":
                                for refDay in trend_Microservices:
                                    try:
                                        microT = micro["microservice"]
                                        if "-green" in microT:
                                            microTues = microT[:-6]
                                        elif "-g" in microT:
                                            microTues = microT[:-2]
                                        elif "-blue" in microT:
                                            microTues = microT[:-5]
                                        elif "-b" in microT:
                                            microTues = microT[:-2]
                                        else:
                                            microTues = micro["microservice"]

                                        if microTues == refDay["microservice"]:
                                            if refDay["fechaReferenceDay"] == "referenceDay":
                                                refDay["fechaReferenceDay"] = WednesdayfechaMMDD
                                            if refDay["useCPUMicReferenceDay"] == 0:
                                                refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                            if refDay["useMEMMicReferenceDay"] == 0:
                                                refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                            if refDay["useMEMPromedioReferenceDay"] == 0:
                                                refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                            if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                            if refDay["riskCPUMicReferenceDay"] == 0:
                                                refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                            if refDay["riskMEMMicReferenceDay"] == 0:
                                                refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                            refDay["useCPUMicD+2"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                            refDay["useCPUMicD+2Bruto"] = micro["totalUseMicroserviceCPU"]
                                            refDay["useMEMMicD+2Bruto"] = micro["totalUseMicroserviceMEM"]
                                            refDay["useMEMMicD+2"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                            refDay["useMEMPromedioMicD+2Bruto"] = micro["averageUseMicroserviceMEM"]
                                            refDay["useMEMPromedioMicD+2"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                            if micro['hpa'] == None:
                                                refDay["useMEMAverageMicD+2"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                            else:
                                                refDay["useMEMAverageMicD+2"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                            refDay["riskCPUMicD+2"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                            refDay["riskMEMMicD+2"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                            refDay['fechaD+2'] = WednesdayfechaMMDD

                                            if os.getenv("ENTITY_ID") == "spain":
                                                refDay['possibleCausesCPUD+2'] = micro['possibleCasesCPU']
                                                refDay['possibleCausesMEMD+2'] = micro['possibleCasesMEM']

                                            if refDay["useCPUMicD+2"] > 300:
                                                marcador = True

                                            if refDay["useMEMMicD+2"] > 500:
                                                marcador = True

                                            for item in trend_Namespace:
                                                item["microservices"] = trend_Microservices

                                            break
                                    except:
                                        logger.info(f"Something has gone wrong {dia}")
                                        continue
                            else:
                                next
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                case "Thursday":
                    fecha = day['date']
                    ThursdayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == ThursdayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+3"] = ThursdayfechaMMDD
                            item["useCPUD+3"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+3"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+3"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+3"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            if micro["blockProduction"] == "production":
                                for refDay in trend_Microservices:
                                    try:
                                        microT = micro["microservice"]
                                        if "-green" in microT:
                                            microTues = microT[:-6]
                                        elif "-g" in microT:
                                            microTues = microT[:-2]
                                        elif "-blue" in microT:
                                            microTues = microT[:-5]
                                        elif "-b" in microT:
                                            microTues = microT[:-2]
                                        else:
                                            microTues = micro["microservice"]

                                        if microTues == refDay["microservice"]:
                                            if refDay["fechaReferenceDay"] == "referenceDay":
                                                refDay["fechaReferenceDay"] = ThursdayfechaMMDD
                                            if refDay["useCPUMicReferenceDay"] == 0:
                                                refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                            if refDay["useMEMMicReferenceDay"] == 0:
                                                refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                            if refDay["useMEMPromedioReferenceDay"] == 0:
                                                refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                            if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                            if refDay["riskCPUMicReferenceDay"] == 0:
                                                refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                            if refDay["riskMEMMicReferenceDay"] == 0:
                                                refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                            refDay["useCPUMicD+3"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                            refDay["useCPUMicD+3Bruto"] = micro["totalUseMicroserviceCPU"]
                                            refDay["useMEMMicD+3Bruto"] = micro["totalUseMicroserviceMEM"]
                                            refDay["useMEMMicD+3"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                            refDay["useMEMPromedioMicD+3Bruto"] = micro["averageUseMicroserviceMEM"]
                                            refDay["useMEMPromedioMicD+3"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                            if micro['hpa'] == None:
                                                refDay["useMEMAverageMicD+3"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                            else:
                                                refDay["useMEMAverageMicD+3"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                            refDay["riskCPUMicD+3"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                            refDay["riskMEMMicD+3"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                            refDay['fechaD+3'] = ThursdayfechaMMDD

                                            if os.getenv("ENTITY_ID") == "spain":
                                                refDay['possibleCausesCPUD+3'] = micro['possibleCasesCPU']
                                                refDay['possibleCausesMEMD+3'] = micro['possibleCasesMEM']

                                            if refDay["useCPUMicD+3"] > 300:
                                                marcador = True

                                            if refDay["useMEMMicD+3"] > 500:
                                                marcador = True

                                            for item in trend_Namespace:
                                                item["microservices"] = trend_Microservices

                                            break
                                    except:
                                        logger.info(f"Something has gone wrong {dia}")
                                        continue
                            else:
                                next     
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                case "Friday":
                    fecha = day['date']
                    FridayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == FridayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+4"] = FridayfechaMMDD
                            item["useCPUD+4"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+4"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+4"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+4"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            if micro["blockProduction"] == "production":
                                for refDay in trend_Microservices:
                                    try:
                                        microT = micro["microservice"]
                                        if "-green" in microT:
                                            microTues = microT[:-6]
                                        elif "-g" in microT:
                                            microTues = microT[:-2]
                                        elif "-blue" in microT:
                                            microTues = microT[:-5]
                                        elif "-b" in microT:
                                            microTues = microT[:-2]
                                        else:
                                            microTues = micro["microservice"]

                                        if microTues == refDay["microservice"]:
                                            if refDay["fechaReferenceDay"] == "referenceDay":
                                                refDay["fechaReferenceDay"] = FridayfechaMMDD
                                            if refDay["useCPUMicReferenceDay"] == 0:
                                                refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                            if refDay["useMEMMicReferenceDay"] == 0:
                                                refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                            if refDay["useMEMPromedioReferenceDay"] == 0:
                                                refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                            if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                            if refDay["riskCPUMicReferenceDay"] == 0:
                                                refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                            if refDay["riskMEMMicReferenceDay"] == 0:
                                                refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                            refDay["useCPUMicD+4"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                            refDay["useCPUMicD+4Bruto"] = micro["totalUseMicroserviceCPU"]
                                            refDay["useMEMMicD+4Bruto"] = micro["totalUseMicroserviceMEM"]
                                            refDay["useMEMMicD+4"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                            refDay["useMEMPromedioMicD+4Bruto"] = micro["averageUseMicroserviceMEM"]
                                            refDay["useMEMPromedioMicD+4"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                            if micro['hpa'] == None:
                                                refDay["useMEMAverageMicD+4"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                            else:
                                                refDay["useMEMAverageMicD+4"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                            refDay["riskCPUMicD+4"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                            refDay["riskMEMMicD+4"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                            refDay['fechaD+4'] = FridayfechaMMDD

                                            if os.getenv("ENTITY_ID") == "spain":
                                                refDay['possibleCausesCPUD+4'] = micro['possibleCasesCPU']
                                                refDay['possibleCausesMEMD+4'] = micro['possibleCasesMEM']

                                            if refDay["useCPUMicD+4"] > 300:
                                                marcador = True

                                            if refDay["useMEMMicD+4"] > 500:
                                                marcador = True

                                            for item in trend_Namespace:
                                                item["microservices"] = trend_Microservices    


                                            break
                                    except:
                                        logger.info(f"Something has gone wrong {dia}")
                                        continue
                            else:
                                next
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                case "Saturday":
                    fecha = day['date']
                    SaturdayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == SaturdayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+5"] = SaturdayfechaMMDD
                            item["useCPUD+5"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+5"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+5"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+5"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            if micro["blockProduction"] == "production":
                                for refDay in trend_Microservices:
                                    try:
                                        microT = micro["microservice"]
                                        if "-green" in microT:
                                            microTues = microT[:-6]
                                        elif "-g" in microT:
                                            microTues = microT[:-2]
                                        elif "-blue" in microT:
                                            microTues = microT[:-5]
                                        elif "-b" in microT:
                                            microTues = microT[:-2]
                                        else:
                                            microTues = micro["microservice"]

                                        if microTues == refDay["microservice"]:
                                            if refDay["fechaReferenceDay"] == "referenceDay":
                                                refDay["fechaReferenceDay"] = SaturdayfechaMMDD
                                            if refDay["useCPUMicReferenceDay"] == 0:
                                                refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                            if refDay["useMEMMicReferenceDay"] == 0:
                                                refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                            if refDay["useMEMPromedioReferenceDay"] == 0:
                                                refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                            if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                            if refDay["riskCPUMicReferenceDay"] == 0:
                                                refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                            if refDay["riskMEMMicReferenceDay"] == 0:
                                                refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                            refDay["useCPUMicD+5"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                            refDay["useCPUMicD+5Bruto"] = micro["totalUseMicroserviceCPU"]
                                            refDay["useMEMMicD+5Bruto"] = micro["totalUseMicroserviceMEM"]
                                            refDay["useMEMMicD+5"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                            refDay["useMEMPromedioMicD+5Bruto"] = micro["averageUseMicroserviceMEM"]
                                            refDay["useMEMPromedioMicD+5"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                            if micro['hpa'] == None:
                                                refDay["useMEMAverageMicD+5"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                            else:
                                                refDay["useMEMAverageMicD+5"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                            refDay["riskCPUMicD+5"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                            refDay["riskMEMMicD+5"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                            refDay['fechaD+5'] = SaturdayfechaMMDD

                                            if os.getenv("ENTITY_ID") == "spain":
                                                refDay['possibleCausesCPUD+5'] = micro['possibleCasesCPU']
                                                refDay['possibleCausesMEMD+5'] = micro['possibleCasesMEM']

                                            if refDay["useCPUMicD+5"] > 300:
                                                marcador = True

                                            if refDay["useMEMMicD+5"] > 500:
                                                marcador = True

                                            for item in trend_Namespace:
                                                item["microservices"] = trend_Microservices

                                            break
                                    except:
                                        logger.info(f"Something has gone wrong {dia}")
                                        continue
                            else:
                                next
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                case "Sunday":
                    fecha = day['date']
                    SundayfechaMMDD = str(fecha).replace("-","/")
                    for item in trend_Namespace:
                        try:
                            if item ["fechaReferenceDay"] == "referenceDay":
                                item ["fechaReferenceDay"] == SundayfechaMMDD
                            if item["useCPUreferenceDay"] == 0:
                                item["useCPUreferenceDay"] = day["totalUseNamespaceCPU"]
                            if item["useMEMreferenceDay"] == 0:
                                item["useMEMreferenceDay"] = day["totalUseNamespaceMEM"]
                            if item["riskCPUreferenceDay"] == 0:
                                item["riskCPUreferenceDay"] = round((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]),1)
                            if item["riskMEMreferenceDay"] == 0:
                                item["riskMEMreferenceDay"] = round((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]),1)

                            item["fechaD+6"] = SundayfechaMMDD
                            item["useCPUD+6"] = round((day["totalUseNamespaceCPU"] - item["useCPUreferenceDay"]),1)
                            item["useMEMD+6"] = round((day["totalUseNamespaceMEM"] - item["useMEMreferenceDay"]),1)
                            item["riskCPUD+6"] = round(((day["totalLimitNamespaceCPU"] - day["totalUseNamespaceCPU"]) - item["riskCPUreferenceDay"]),1)
                            item["riskMEMD+6"] = round(((day["totalLimitNamespaceMEM"] - day["totalUseNamespaceMEM"]) - item["riskMEMreferenceDay"]),1)
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue

                    microservices = day["microservices"]
                    for micro in microservices:
                        try:
                            if micro["blockProduction"] == "production":
                                for refDay in trend_Microservices:
                                    try:
                                        microT = micro["microservice"]
                                        if "-green" in microT:
                                            microTues = microT[:-6]
                                        elif "-g" in microT:
                                            microTues = microT[:-2]
                                        elif "-blue" in microT:
                                            microTues = microT[:-5]
                                        elif "-b" in microT:
                                            microTues = microT[:-2]
                                        else:
                                            microTues = micro["microservice"]

                                        if microTues == refDay["microservice"]:
                                            if refDay["fechaReferenceDay"] == "referenceDay":
                                                refDay["fechaReferenceDay"] = SundayfechaMMDD
                                            if refDay["useCPUMicReferenceDay"] == 0:
                                                refDay["useCPUMicReferenceDay"] = micro["totalUseMicroserviceCPU"]
                                            if refDay["useMEMMicReferenceDay"] == 0:
                                                refDay["useMEMMicReferenceDay"] = micro["totalUseMicroserviceMEM"]
                                            if refDay["useMEMPromedioReferenceDay"] == 0:
                                                refDay["useMEMPromedioReferenceDay"] = micro["averageUseMicroserviceMEM"]
                                            if refDay["useMEMAverageReferenceDay"] == 0:
                                                if micro['hpa'] == None:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice'],1)
                                                else:
                                                    refDay["useMEMAverageReferenceDay"] = round(micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas'],1)
                                            if refDay["riskCPUMicReferenceDay"] == 0:
                                                refDay["riskCPUMicReferenceDay"] = micro["totalRiskCPUMicroservice"]
                                            if refDay["riskMEMMicReferenceDay"] == 0:
                                                refDay["riskMEMMicReferenceDay"] = micro["totalRiskMemoryMicroservice"]

                                            refDay["useCPUMicD+6"] = round((micro["totalUseMicroserviceCPU"] - refDay["useCPUMicReferenceDay"]),1)
                                            refDay["useCPUMicD+6Bruto"] = micro["totalUseMicroserviceCPU"]
                                            refDay["useMEMMicD+6Bruto"] = micro["totalUseMicroserviceMEM"]
                                            refDay["useMEMMicD+6"] = round((micro["totalUseMicroserviceMEM"] - refDay["useMEMMicReferenceDay"]),1)
                                            refDay["useMEMPromedioMicD+6Bruto"] = micro["averageUseMicroserviceMEM"]
                                            refDay["useMEMPromedioMicD+6"] = round((micro["averageUseMicroserviceMEM"] - refDay["useMEMPromedioReferenceDay"]),1)
                                            if micro['hpa'] == None:
                                                refDay["useMEMAverageMicD+6"] = round((micro["totalUseMicroserviceMEM"] / micro ['replicasMicroservice']) - refDay["useMEMAverageReferenceDay"],1)
                                            else:
                                                refDay["useMEMAverageMicD+6"] = round((micro["totalUseMicroserviceMEM"] / micro['hpa']['minReplicas']) - refDay["useMEMAverageReferenceDay"],1)
                                            refDay["riskCPUMicD+6"] = round((micro["totalRiskCPUMicroservice"] - refDay["riskCPUMicReferenceDay"]),1)
                                            refDay["riskMEMMicD+6"] = round((micro["totalRiskMemoryMicroservice"] - refDay["riskMEMMicReferenceDay"]),1)

                                            refDay['fechaD+6'] = SundayfechaMMDD

                                            if os.getenv("ENTITY_ID") == "spain":
                                                refDay['possibleCausesCPUD+6'] = micro['possibleCasesCPU']
                                                refDay['possibleCausesMEMD+6'] = micro['possibleCasesMEM']

                                            if refDay["useCPUMicD+6"] > 300:
                                                marcador = True

                                            if refDay["useMEMMicD+6"] > 500:
                                                marcador = True

                                            for item in trend_Namespace:
                                                item["microservices"] = trend_Microservices
            
                                            break
                                    except:
                                        logger.info(f"Something has gone wrong {dia}")
                                        continue
                            else:
                                next       
                        except:
                            logger.info(f"Something has gone wrong {dia}")
                            continue
        except:
            logger.info(f"Something has gone wrong {day}")
            continue

    if indicador == "online":
        mg.change_collection(os.getenv("COLLECTION_SRE_TREND_ONLINE"))
    else:
        mg.change_collection(os.getenv("COLLECTION_SRE_TREND"))
    querydbresultsmemory = mg.find({f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" })
    findnamespacememory = [x for x in querydbresultsmemory]
    if len(findnamespacememory) == 0:                                
        mg.add_data(data=trendnamespace)
    else:
        for trend in trendnamespace.items():
            if trend[0] == 'uid':
                uid = trend[1]

            if trend[0] == 'namespace':
                namespace = trend[1]
            if trend[0] == 'region':
                region = trend[1]
            if trend[0] == 'cluster':
                cluster = trend[1]

            if trend[0] == 'marcador':
                marcador = trend[1]

            if trend[0] == 'fechaReferenceDay':
                fechaReferenceDay = trend[1]

            if trend[0] == 'useCPUreferenceDay':
                useCPUreferenceDay = trend[1]
            if trend[0] == 'useMEMreferenceDay':
                useMEMreferenceDay = trend[1]    
            if trend[0] == 'riskCPUreferenceDay':
                riskCPUreferenceDay = trend[1]
            if trend[0] == 'riskMEMreferenceDay':
                riskMEMreferenceDay = trend[1]

            if trend[0] == 'fechaD+1':
                fechaCPUD1 = trend[1]

            if trend[0] == 'useCPUD+1':
                useCPUD1 = trend[1]
            if trend[0] == 'useMEMD+1':
                useMEMD1 = trend[1]    
            if trend[0] == 'riskCPUD+1':
                riskCPUD1 = trend[1]
            if trend[0] == 'riskMEMD+1':
                riskMEMD1 = trend[1]

            if trend[0] == 'fechaD+2':
                fechaCPUD2 = trend[1]

            if trend[0] == 'useCPUD+2':
                useCPUD2 = trend[1]
            if trend[0] == 'useMEMD+2':
                useMEMD2 = trend[1]    
            if trend[0] == 'riskCPUD+2':
                riskCPUD2 = trend[1]
            if trend[0] == 'riskMEMD+2':
                riskMEMD2 = trend[1]

            if trend[0] == 'fechaD+3':
                fechaCPUD3 = trend[1]

            if trend[0] == 'useCPUD+3':
                useCPUD3 = trend[1]
            if trend[0] == 'useMEMD+3':
                useMEMD3 = trend[1]    
            if trend[0] == 'riskCPUD+3':
                riskCPUD3 = trend[1]
            if trend[0] == 'riskMEMD+3':
                riskMEMD3 = trend[1]

            if trend[0] == 'fechaD+4':
                fechaCPUD4 = trend[1]

            if trend[0] == 'useCPUD+4':
                useCPUD4 = trend[1]
            if trend[0] == 'useMEMD+4':
                useMEMD4 = trend[1]    
            if trend[0] == 'riskCPUD+4':
                riskCPUD4 = trend[1]
            if trend[0] == 'riskMEMD+4':
                riskMEMD4 = trend[1]

            if trend[0] == 'fechaD+5':
                fechaCPUD5 = trend[1]

            if trend[0] == 'useCPUD+5':
                useCPUD5 = trend[1]
            if trend[0] == 'useMEMD+5':
                useMEMD5 = trend[1]    
            if trend[0] == 'riskCPUD+5':
                riskCPUD5 = trend[1]
            if trend[0] == 'riskMEMD+5':
                riskMEMD5 = trend[1]

            if trend[0] == 'fechaD+6':
                fechaCPUD6 = trend[1]

            if trend[0] == 'useCPUD+6':
                useCPUD6 = trend[1]
            if trend[0] == 'useMEMD+6':
                useMEMD6 = trend[1]    
            if trend[0] == 'riskCPUD+6':
                riskCPUD6 = trend[1]
            if trend[0] == 'riskMEMD+6':
                riskMEMD6 = trend[1]

            if trend[0] == 'microservices':
                microservices = trend[1]

        mg.update_one(
            { f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" },
            
            { '$set': {
                f"uid": uid,
                f"namespace": namespace,
                f"region": region,
                f"cluster": cluster,
                f"marcador": marcador,
                f"fechaReferenceDay": fechaReferenceDay,
                f"useCPUreferenceDay": useCPUreferenceDay,
                f"useMEMreferenceDay": useMEMreferenceDay,
                f"riskCPUreferenceDay": riskCPUreferenceDay,
                f"riskMEMreferenceDay": riskMEMreferenceDay,
                f"fechaD+1": fechaCPUD1,
                f"useCPUD+1": useCPUD1,
                f"useMEMD+1": useMEMD1,
                f"riskCPUD+1": riskCPUD1,
                f"riskMEMD+1": riskMEMD1,
                f"fechaD+2": fechaCPUD2,
                f"useCPUD+2": useCPUD2,
                f"useMEMD+2": useMEMD2,
                f"riskCPUD+2": riskCPUD2,
                f"riskMEMD+2": riskMEMD2,
                f"fechaD+3": fechaCPUD3,
                f"useCPUD+3": useCPUD3,
                f"useMEMD+3": useMEMD3,
                f"riskCPUD+3": riskCPUD3,
                f"riskMEMD+3": riskMEMD3,
                f"fechaD+4": fechaCPUD4,
                f"useCPUD+4": useCPUD4,
                f"useMEMD+4": useMEMD4,
                f"riskCPUD+4": riskCPUD4,
                f"riskMEMD+4": riskMEMD4,
                f"fechaD+5": fechaCPUD5,
                f"useCPUD+5": useCPUD5,
                f"useMEMD+5": useMEMD5,
                f"riskCPUD+5": riskCPUD5,
                f"riskMEMD+5": riskMEMD5,
                f"fechaD+6": fechaCPUD6,
                f"useCPUD+6": useCPUD6,
                f"useMEMD+6": useMEMD6,
                f"riskCPUD+6": riskCPUD6,
                f"riskMEMD+6": riskMEMD6,
                f"microservices": microservices
                } 
            }    
        ) 
        
    return trendnamespace


async def historicalWeekTrend():
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK5"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK4"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK5"))
    for d in datos:       
        cont += 1                         
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK4"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK3"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK4"))
    for d in datos:       
        cont += 1                         
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK3"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK2"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK3"))
    for d in datos:     
        cont += 1                           
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK2"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK1"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK2"))
    for d in datos:        
        cont += 1                        
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK1"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_TREND_WEEK1"))
    for d in datos:    
        cont += 1                            
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")