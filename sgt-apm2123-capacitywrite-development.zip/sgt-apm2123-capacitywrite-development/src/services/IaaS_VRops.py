import json
import logging
from queue import Empty
from time import time
from typing import Any
from confluent_kafka import KafkaException, Producer, Consumer
from src.services.Estructural import mg
import os

def error_cb(kafka_error):
        logging.error(f"{kafka_error.name()}, {kafka_error.str()}")

def delivery_cb(err, msg):
    if err:
        logging.error(f'{err}')

class QueueException(Exception):
  pass

class KafkaConsumer:

  def __init__ (self, kafka_conf:dict):
    self.host = kafka_conf.get('host')
    self.kafka_conf = kafka_conf
    self.consumers = {}

  def get(self, topic_name: str, block: bool = True, timeout = 1.0) -> str:
    """
    Get a message from topic in queue Service
    """
    msg = None
    if block:
      timeout = 9999

    consumer = self.consumers.get(topic_name)
    if not consumer:
      consumer_kafka_conf = {
        'bootstrap.servers': self.host,
        'group.id': topic_name,
        'auto.offset.reset': 'earliest'
      }
      user = self.kafka_conf.get('user')
      password = self.kafka_conf.get('pass')
      if user and password:
        consumer_kafka_conf['sasl.mechanism'] = 'PLAIN'
        consumer_kafka_conf['security.protocol'] = 'SASL_SSL'
        consumer_kafka_conf['sasl.username'] = user
        consumer_kafka_conf['sasl.password'] = password
      else:
        consumer_kafka_conf['security.protocol'] = 'SSL'
        consumer_kafka_conf['ssl.ca.location'] = self.kafka_conf.get('ca_cert')
        consumer_kafka_conf['ssl.key.location'] = self.kafka_conf.get('kafka_key')
        consumer_kafka_conf['ssl.certificate.location'] = self.kafka_conf.get('kafka_cert')
      consumer = Consumer(consumer_kafka_conf)
      consumer.subscribe([topic_name])
      self.consumers[topic_name] = consumer

    try:
      msg = consumer.poll(timeout=timeout)
      while msg:
        #if not msg:
          #msg = consumer.poll(timeout=timeout)
          #msg.value().decode('UTF-8')
        #else:
          #block = False
          #msg.value().decode('UTF-8')
          

        data = msg.value().decode('UTF-8')

        x = data.split(',')

        for a in x:
            y = a.split(':')
            if 'Name' in a:
                for i in y:
                    Name = i
            if 'CPU Avg Use' in a:
                for i in y:
                    CPUAvg = i
            if 'CPU Max Use' in a:
                for i in y:
                    CPUMax = i
            if 'Memory Avg Use' in a:
                for i in y:
                    MemoryAvg = i
            if 'Memory Max Use' in a:
                for i in y:
                    MemoryMax = i
         
        datos = {
            "Name": Name,
            "CPU Avg Use": CPUAvg,
            "CPU Max Use": CPUMax,
            "Memory Avg Use": MemoryAvg,
            "Memory Max Use": MemoryMax,
        }

        print(datos)

        mg.change_collection(os.getenv("COLLECTION_IAAS_VROPS"))
        #querydbresultsmemory = mg.find({f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" })
        #findnamespacememory = [x for x in querydbresultsmemory]
        #if len(findnamespacememory) == 0:                                
        mg.add_data(data=datos)
        #else:
            # mg.update_one(
                #{ f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" },
                
                # { 
                # }
                #)

        msg = consumer.poll(timeout=timeout)
      if msg and not msg.error():
        logging.info(f"Received message from topic {topic_name} with key {msg.key}")
    except Empty as empty:
      raise Empty(f"Queue empty can not get message for the topic {topic_name} for reason {empty}")
    except Exception as expection:
      raise QueueException(f"Error trying to get message in the Queue Service for the topic {topic_name} for reason {expection}")

    return json.loads(msg.value().decode('UTF-8'))


if __name__ == '__main__':
    kafka_conf = {
        "host": "WTSLCCLENGP0007_NAT.UNIX.WTES.CORP:9095,WTSLCCLENGP0008_NAT.UNIX.WTES.CORP:9095,WTSLCCLENGP0011_NAT.UNIX.WTES.CORP:9095,WTSLCCLENGP0012_NAT.UNIX.WTES.CORP:9095",
        #"host": "<WTSLCCLENGP0007_NAT.UNIX.WTES.CORP>,<WTSLCCLENGP0008_NAT.UNIX.WTES.CORP>,<WTSLCCLENGP0011_NAT.UNIX.WTES.CORP>,<WTSLCCLENGP0012_NAT.UNIX.WTES.CORP>",
        #"host": ['WTSLCCLENGP0007_NAT.UNIX.WTES.CORP','WTSLCCLENGP0008_NAT.UNIX.WTES.CORP','WTSLCCLENGP0011_NAT.UNIX.WTES.CORP','WTSLCCLENGP0012_NAT.UNIX.WTES.CORP'],
        "ca_cert": "santander_combined.pem",
        "kafka_cert": "kafka_cert.pem",
        "kafka_key": "kafka_key.pem",
        "topic": "pro_elk_alma_vrops_sanes_metrics",
        "user": "alma_elk_vrops_sanes_read",
        "pass":"6Orehea&"
    }
    service = KafkaConsumer(kafka_conf)
    event = service.get(kafka_conf.get("topic"))
    print(event)


async def get_iaas():
    kafka_conf = {
        "host": "WTSLCCLENGP0007_NAT.UNIX.WTES.CORP:9095,WTSLCCLENGP0008_NAT.UNIX.WTES.CORP:9095,WTSLCCLENGP0011_NAT.UNIX.WTES.CORP:9095,WTSLCCLENGP0012_NAT.UNIX.WTES.CORP:9095",
        "ca_cert": "santander_combined.pem",
        "kafka_cert": "kafka_cert.pem",
        "kafka_key": "kafka_key.pem",
        "topic": "pro_elk_alma_vrops_sanes_metrics",
        "user": "alma_elk_vrops_sanes_read",
        "pass":"6Orehea&"
    }
    service = KafkaConsumer(kafka_conf)
    event = service.get(kafka_conf.get("topic"))

    return event