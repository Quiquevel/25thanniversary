from shuttlelib.openshift.client import OpenshiftClient
from shuttlelib.utils.logger import logger
from fastapi import HTTPException
from shuttlelib.db.mongo import MongoClient
import json
import os, aiohttp
import datetime
import pytz
import re


mg = MongoClient()
entity = (os.getenv("ENTITY_ID")).lower()
client = OpenshiftClient(entity_id=entity)

URLBOADILLA = os.environ.get('URLELASTICBOADILLA')
URLAZURE = os.environ.get("URLELASTICAZURE")
URLCANTABRIA = os.environ.get('URLELASTICCANTABRIA')
APIKEYCANTABRIA = os.environ.get ('APIKEYCANTABRIA')
URLCHILE = os.environ.get('URLELASTICCHILE')
APIKEYCHILE = os.environ.get ('APIKEYCHILE')
USERBOADILLA = os.environ.get ('USERBOADILLA')
APIKEYBOADILLA = os.environ.get ('APIKEYBOADILLA')
USERAZURE = os.environ.get ('USERAZURE')
APIKEYAZURE = os.environ.get ('APIKEYAZURE')
URLBOADILLADEVPRE = os.environ.get('URLELASTICBOADILLADEVPRE')
URLAZUREDEVPRE = os.environ.get("URLELASTICAZUREDEVPRE")
USERBOADILLADEVPRE = os.environ.get ('USERBOADILLADEVPRE')
APIKEYBOADILLADEVPRE = os.environ.get ('APIKEYBOADILLADEVPRE')
USERAZUREDEVPRE = os.environ.get ('USERAZUREDEVPRE')
APIKEYAZUREDEVPRE = os.environ.get ('APIKEYAZUREDEVPRE')
URLMEXICO = os.environ.get('URLELASTICMEXICO')
APIKEYMEXICO = os.environ.get ('APIKEYMEXICO')
        
async def get_index_elastic(identificador, locator):
    """
    Returns the Elasticsearch index path based on the given identificador and locator.

    Parameters:
    - identificador (str): online or week type of search.
    - locator (str): resources or event.

    Returns:
    - str: The Elasticsearch index path.

    """
    if locator == 'event':
        return "/gpw/_search"
    else:
        if identificador == 'online':
            return "/capacity/_async_search"
        else:
            return "/archive-capacity/_async_search"


async def extraer_cluster(url):
    # Busca el patrón entre 'api.' y '.paas'
    match = re.search(r'api\.([^.]+(?:\.[^.]+){3,4})\.paas', url)
    if match:
        nombre = match.group(1)
        # Si termina en '.azure', lo quitamos
        if nombre.endswith('.azure'):
            nombre = nombre[:-6]
        return nombre
    return None


async def get_clusters():
    functional_environment=os.getenv("ENVIRONMENT")

    clusters = await client.get_resource(resource="clusters", functional_environment=functional_environment, cluster=None)
    cluster_list = []
    cluster_list_complete = []
    for cluster in clusters.keys():
        regions = list(clusters[cluster].keys())
        cluster_list.append({"name": cluster, "region": regions})

        for region in regions:
            url = list(clusters[cluster][region].values())[2]
            cluster_list_complete.append({"name": cluster, "region": region, "url": url})

    return cluster_list, cluster_list_complete


async def elastic_call(identificador, environment, locator, cluster, query, iden):
    """
    Makes an asynchronous call to an Elasticsearch cluster based on the provided parameters.

    Args:
        identificador (str): online or week type of search.
        environment (str): pro or dev.
        locator (str): resources or event.
        cluster (str): The cluster for the call.
        namespace (str): The namespace for the call.
        query (str): The query to be sent to Elasticsearch.

    Returns:
        list: A list of Elasticsearch hits.

    Raises:
        Exception: If the Elasticsearch is not available.

    """
    logger.info("#### Connecting with elastic ####")
    retries = 20
    id_elastic = await get_index_elastic(identificador=identificador, locator=locator)

    if environment == "pro":
        if cluster == "ocp05.san.pro.weu1" or cluster == "ocp05.san.pro.weu2" or cluster == "ocppro01.gsc.pro.weu" or cluster == "ocpgnr.gsc.pro.weu1":
            url = URLAZURE
            apikey = APIKEYAZURE
        elif cluster == "sgt01.sgt.pro.cn1" or cluster == "sgt01.sgt.pro.cn2" or cluster == "gsc04.gsc.pro.cn1" or cluster == "gsc04.gsc.pro.cn2" or cluster == "sgt01.sgt.dmzb.cn1" or cluster == "sgt01.sgt.dmzb.cn2" or cluster == "gsc04.gsc.dmzb.cn1" or cluster == "gsc04.gsc.dmzb.cn2" or cluster == "scq01.scq.pro.cn1" or cluster == "scq01.scq.pro.cn2" or cluster == "scq01.scq.dmzb.cn1" or cluster == "scq01.scq.dmzb.cn2":
            url = URLCANTABRIA
            apikey = APIKEYCANTABRIA
        elif cluster == "csa02.csa.pro.mx1" or cluster == "csa02.csa.pro.mx2" or cluster == "gluon01.mex.pro.mx1" or cluster == "gluon01.mex.pro.mx2" or cluster == "grav01.mex.pro.mx1" or cluster == "grav01.mex.pro.mx2" or cluster == "mex02.mex.pro.mx1" or cluster == "mex02.mex.pro.mx2" or cluster == "mex02.mex.dmzb.mx1" or cluster == "mex02.mex.dmzb.mx2" or cluster == "ocp01.mex.pro.mx1" or cluster == "ocp01.mex.pro.mx2" or cluster == "ocp02.mex.pro.mx1" or cluster == "ocp02.mex.pro.mx2" or cluster == "ocp03.mex.pro.mx1" or cluster == "ocp03.mex.pro.mx2" or cluster == "ocp04.mex.pro.mx1" or cluster == "ocp04.mex.pro.mx2" or cluster == "ocp05.mex.pro.mx1" or cluster == "ocp05.mex.pro.mx2" or cluster == "ocp06.mex.pro.mx1" or cluster == "ocp06.mex.pro.mx2" or cluster == "plard01.mex.pro.mx1" or cluster == "plard01.mex.pro.mx2" or cluster == "str01.mex.pro.mx1" or cluster == "str01.mex.pro.mx2" or cluster == "gscmx01.gscmx.pro.mx1" or cluster == "gscmx01.gscmx.pro.mx2":
            url = URLMEXICO
            apikey = APIKEYMEXICO
        else:
            url = URLBOADILLA
            apikey = APIKEYBOADILLA
            ca = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + 'santander-ca-root.crt'
    else:
        if cluster == "san.dev.weu1" or cluster == "ocp01.san.pre.weu1" or cluster == "ocp01.san.pre.weu2":
            url = URLAZUREDEVPRE
            apikey = APIKEYAZUREDEVPRE
        else:
            url = URLBOADILLADEVPRE
            apikey = APIKEYBOADILLADEVPRE
            ca = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + 'santander-ca-root.crt'
    
    request_url = url + id_elastic
    headers = {'Authorization': "ApiKey "+str(apikey),'Accept': 'application/json','Content-type': 'application/json'}
    for _ in  range(retries):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(request_url,ssl=False,headers=headers,data=query) as resp:
                    res = await resp.json()
                    if id_elastic == "/gpw/_search":
                        try:
                            ps= res['hits']['hits']
                        except:
                            ps= []
                    else:
                        if identificador == 'online':
                            if iden == None:
                                try:
                                    ps= res['response']['hits']['hits']
                                except:
                                    ps= []
                            else:
                                try:
                                    ps= [res['response']['aggregations']['timeseries']['buckets'][1]["3bd772c0-5cc9-11ec-b347-453bc8c37d73"]["value"]]
                                except:
                                    ps= []
                        else:
                            try:
                                ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                            except:
                                ps= []
        except aiohttp.ClientError as e:
            logger.error(f"Elastic not available: {e}")
            json_object = []
            return json_object
        if len(ps) != 0:
            break
    return ps


async def elastic_gpw(environment, clustertraduc, namespace, initialHour=None, finalHour=None, iden=None):
    """
    Retrieves GPW event from Elastic.

    Args:
        environment (str): The environment to retrieve the GPW event from, pro or dev.
        clustertraduc (str): The translated cluster name.
        namespace (str): The namespace to retrieve the GPW event from.

    Returns:
        ps: The result of the Elastic call.
    """
    logger.info("#### Get GPW event from elastic ####")

    if initialHour != None and finalHour!=None:
        fechas = []
        fechas.append(initialHour)
        fechas.append(finalHour)
    else:
        fechas = await timer(event=True)    

    fecha_inicio = fechas[0]
    #fecha_fin = fechas[1]+datetime.timedelta(hours=1)
    fecha_fin = datetime.datetime.strptime(fechas[1], '%Y-%m-%dT%H:%M:%S.%fZ')
    fecha_fin = str(fecha_fin)+'.000Z'
    fecha_fin = fecha_fin.replace(" ", "T")

    query = "pod-event-per-project - week"
    query_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + query + ".json"

    with open(query_file) as file:
        ES_QUERY = "".join(line.rstrip() for line in file)

    ES_QUERY = str(ES_QUERY)\
        .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
        .replace('$OPENSHIFT_NAMESPACE', namespace)\
        .replace('$FECHA_INICIO', fecha_inicio)\
        .replace('$FECHA_FIN', fecha_fin)

    ps = await elastic_call(identificador='week', environment=environment, locator='event', cluster=clustertraduc, query=ES_QUERY, iden=iden)
    return ps


async def elastic(identificador, environment, clustertraduc, namespace, iden=None):
    """
    Retrieves resources from Elastic.

    Args:
        identificador (str): online or week type of search.
        environment (str): The environment, pro or dev.
        clustertraduc (str): The cluster name.
        namespace (str): The namespace.

    Returns:
        ps: The result of the Elastic call.
    """
    logger.info("#### Get resources from elastic ####")

    if identificador == "online":
        if iden == "allocatable-cpu":
            query = "allocatable-cpu-cluster"
        elif iden == "allocatable-memory":
            query = "allocatable-memory-cluster"
        elif iden == "request-cpu-cluster":
            query = "request-cpu-cluster"
        elif iden == "request-memory-cluster":
            query = "request-memory-cluster"
        elif iden == "use-cpu-cluster":
            query = "use-cpu-cluster"
        elif iden == "use-memory-cluster":
            query = "use-memory-cluster"
        elif iden == "request-cpu-namespace":
            query = "request-cpu-namespace"
        elif iden == "request-memory-namespace":
            query = "request-memory-namespace"
        elif iden == "use-cpu-namespace":
            query = "use-cpu-namespace"
        elif iden == "use-memory-namespace":
            query = "use-memory-namespace"
        else:
            query = "cpu-and-memory-per-project - online"

        query_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + query + ".json"

        with open(query_file) as file:
            ES_QUERY = "".join(line.rstrip() for line in file)

        if iden == None:
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
                .replace('$OPENSHIFT_NAMESPACE', namespace)
        elif "cluster" in iden or "allocatable" in iden:
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
                .replace('$FECHA_INICIO', fecha_inicio)\
                .replace('$FECHA_FIN', fecha_fin)
        elif "namespace" in iden:
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
                .replace('$OPENSHIFT_NAMESPACE', namespace)\
                .replace('$FECHA_INICIO', fecha_inicio)\
                .replace('$FECHA_FIN', fecha_fin)

    else:
        fechas = await timer(namespace=namespace)

        fecha_inicio = fechas[0]
        fecha_fin = fechas[1]

        query = "cpu-and-memory-per-project - week"
        query_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + query + ".json"

        with open(query_file) as file:
            ES_QUERY = "".join(line.rstrip() for line in file)

        ES_QUERY = str(ES_QUERY)\
            .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
            .replace('$OPENSHIFT_NAMESPACE', namespace)\
            .replace('$FECHA_INICIO', fecha_inicio)\
            .replace('$FECHA_FIN', fecha_fin)
    
    ps = await elastic_call(identificador=identificador, environment=environment, locator='resources', cluster=clustertraduc, query=ES_QUERY,iden=iden)
    return ps


async def elasticOLD(identificador,environment,clustertraduc,namespace):
    logger.info("#### Connecting with elastic ####")

    if identificador == "online":
        query = "cpu-and-memory-per-project - online"
        query_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + query + ".json"

        with open(query_file) as file:
                ES_QUERY = "".join(line.rstrip() for line in file)

        if "per-project" in query:
            ELASTIC_QUERY_SCOPE = 'project'
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
                .replace('$OPENSHIFT_NAMESPACE', namespace)
        elif "per-cluster" in query:
            ELASTIC_QUERY_SCOPE = 'cluster'
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', namespace)
    else:
        fechas = await timer()
        fecha_inicio = fechas[0]
        fecha_fin = fechas[1]

        query = "cpu-and-memory-per-project - week"
        query_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + query + ".json"

        with open(query_file) as file:
                ES_QUERY = "".join(line.rstrip() for line in file)

        if "per-project" in query:
            ELASTIC_QUERY_SCOPE = 'project'
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
                .replace('$OPENSHIFT_NAMESPACE', namespace)\
                .replace('$FECHA_INICIO',fecha_inicio)\
                .replace('$FECHA_FIN',fecha_fin)
        elif "per-cluster" in query:
            ELASTIC_QUERY_SCOPE = 'cluster'
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', namespace)
    

    if environment == "pro":
        if clustertraduc == "ocp01.san.pro.weu1" or clustertraduc == "ocp02.san.pro.weu2" or clustertraduc == "ocp03.san.pro.weu1" or clustertraduc == "ocp05.san.pro.weu1" or clustertraduc == "ocp05.san.pro.weu2":
            if identificador == 'online':
                request_url = URLAZURE + "/capacity/_async_search"
            else:
                request_url = URLAZURE + "/archive-capacity/_async_search"
            headers = {'Authorization': "ApiKey "+str(APIKEYAZURE),'Accept': 'application/json','Content-type': 'application/json'}
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                        res = await resp.json()
            except:
                logger.info("Elastic not available")
                json_object = []
                return json_object
            
            Ps= res['response']['hits']['hits']

            retries = 0
            while len(Ps) == 0:
                retries += 1
                if retries < 20:
                    async with aiohttp.ClientSession() as session:
                        async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                            res = await resp.json()

                    Ps= res['response']['hits']['hits']
                else:
                    Ps= res['response']['hits']['hits']
                    break
        else:
            ca = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + 'santander-ca-root.crt'
            if identificador == 'online':
                request_url = URLBOADILLA + "/capacity/_async_search"
            else:
                request_url = URLBOADILLA + "/archive-capacity/_async_search"
            
            headers = {'Authorization': "ApiKey "+str(APIKEYBOADILLA),'Accept': 'application/json','Content-type': 'application/json'}
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                        res = await resp.json()
            except:
                logger.info("Elastic not available")
                json_object = []
                return json_object
            
            Ps= res['response']['hits']['hits']
            
            retries = 0
            while len(Ps) == 0:
                retries = retries + 1
                if retries < 20:
                    async with aiohttp.ClientSession() as session:
                        async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                            res = await resp.json()
                    Ps= res['response']['hits']['hits']
                else:
                    Ps= res['response']['hits']['hits']
                    break
    else:
        if clustertraduc == "san.dev.weu1" or clustertraduc == "ocp01.san.pre.weu1" or clustertraduc == "ocp01.san.pre.weu2":
            request_url = URLAZUREDEVPRE + "/archive-capacity/_async_search"
            headers = {'Authorization': "ApiKey "+str(APIKEYAZUREDEVPRE),'Accept': 'application/json','Content-type': 'application/json'}
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                        res = await resp.json()
            except:
                logger.info("Elastic not available")
                json_object = []
                return json_object
            
            Ps= res['response']['hits']['hits']

            retries = 0
            while len(Ps) == 0:
                retries = retries + 1
                if retries < 20:
                    async with aiohttp.ClientSession() as session:
                        async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                            res = await resp.json()
                    Ps= res['response']['hits']['hits']
                else:
                    Ps= res['response']['hits']['hits']
                    break
        else:
            ca = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + 'santander-ca-root.crt'
            request_url = URLBOADILLADEVPRE + "/archive-capacity/_async_search"
            headers = {'Authorization': "ApiKey "+str(APIKEYBOADILLADEVPRE),'Accept': 'application/json','Content-type': 'application/json'}
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                        res = await resp.json()
            except:
                logger.info("Elastic not available")
                json_object = []
                return json_object
            Ps = res['response']['hits']['hits']
            
            retries = 0
            while len(Ps) == 0:
                retries = retries + 1
                if retries < 20:
                    async with aiohttp.ClientSession() as session:
                        async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                            res = await resp.json()
                    Ps= res['response']['hits']['hits']
                else:
                    Ps= res['response']['hits']['hits']
                    break
    
    return Ps


async def get_timezone_and_schedule():
    """
    Obtiene la zona horaria y el horario de servicio basado en el ENTITY_ID definido globalmente

    Returns:
        tuple: Una tupla con la zona horaria (str), hora inicial (int) y hora final (int).
    """
    entity = os.getenv("ENTITY_ID").lower()
    environment = os.getenv("ENVIRONMENT").lower()
    timezone = os.getenv("TZ")
    file = "service_schedule"
    config_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + file + "_" + environment + ".json"


    try:
        # Cargar el archivo JSON
        with open(config_file, 'r') as file:
            config_data = json.load(file)

        # Buscar la configuración para el ENTITY_ID
        if entity in config_data:
            initial_hour = config_data[entity].get("initial_hour", 0)
            final_hour = config_data[entity].get("final_hour", 23)
            exception = config_data[entity].get("exception", [])
            return timezone, initial_hour, final_hour, exception
        else:
            raise ValueError(f"ENTITY_ID '{entity}' no encontrado en el archivo de configuración.")

    except FileNotFoundError:
        raise FileNotFoundError(f"El archivo de configuración '{config_file}' no existe.")
    except json.JSONDecodeError:
        raise ValueError(f"El archivo de configuración '{config_file}' no es un JSON válido.")


async def date_time_global(date: datetime.date, timezone: str):
    """
    Asynchronously converts a given date and time to a UTC timestamp string.
    Args:
        date (datetime.date): The date to be converted.
    Returns:
        str: The UTC timestamp string in the format '%Y-%m-%dT%H:%M:%S.%fZ' if the time is valid.
    Raises:
        ValueError: If the date or time format is incorrect.
    """
    time_zone = pytz.timezone(timezone)
    date_format = '%Y-%m-%dT%H:%M:%S.%f'
    
    date_local = time_zone.localize(datetime.datetime.strptime(date, date_format))

    date_utc = date_local.astimezone(pytz.utc).strftime(date_format)[:-3] + 'Z'

    return date_utc


async def timer(initial_date: datetime.date = None, initial_time: int = None, final_date: datetime.date = None, final_time: int = None, event : bool = False, namespace=None):
    """
    Asynchronous function to calculate and return the UTC timestamps for a given time range.
    Args:
        initial_date (datetime.date, optional): The starting date. Defaults to today's date if not provided.
        initial_time (int, optional): The starting hour (0-23). Defaults to a predefined schedule if not provided.
        final_date (datetime.date, optional): The ending date. Defaults to today's date if not provided.
        final_time (int, optional): The ending hour (0-23). Defaults to a predefined schedule if not provided.
        event (bool, optional): If True, extends the final time by one hour, adjusting the date if necessary. Defaults to False.
    Returns:
        tuple: A tuple containing two datetime objects in UTC:
            - initial_date_utc: The UTC timestamp for the start of the range.
            - final_date_utc: The UTC timestamp for the end of the range.
    Raises:
        ValueError: If `initial_time` or `final_time` is not within the valid range (0-23).
    Notes:
        - The function retrieves the timezone and default schedule using `get_timezone_and_schedule`.
        - The `date_time_global` function is used to convert local timestamps to UTC.
    """


    timezone, ini_time, fin_time, exception = await get_timezone_and_schedule()

    if exception != []:
        for ex in exception:
            namesp = ex["namespace"].split(",")
            for n in namesp:
                if namespace == n:
                    ini_time = ex["ini_hour"]
                    fin_time = ex["fin_hour"]
                    ini_date = initial_date if initial_date else datetime.date.today()
                    fin_date = final_date if final_date else datetime.date.today()
                    break
            else:
                ini_date = initial_date if initial_date else datetime.date.today()
                fin_date = final_date if final_date else datetime.date.today()
                ini_time = initial_time if initial_time else ini_time
                fin_time = final_time if final_time else fin_time
    else:
        ini_date = initial_date if initial_date else datetime.date.today()
        fin_date = final_date if final_date else datetime.date.today()
        ini_time = initial_time if initial_time else ini_time
        fin_time = final_time if final_time else fin_time

    if ini_time <= 0 or ini_time > 23:
        logger.error("Initial time is not valid")
        return None

    if fin_time <= 0 or fin_time > 23:
        logger.error("Final time is not valid")
        return None

    if event == True:
        fin_time = fin_time + 1
        if fin_time > 23:
            fin_time = 0
            fin_date = fin_date + datetime.timedelta(days=1)

    initial_date_str = ini_date.strftime(f'%Y-%m-%dT{ini_time}:00:00.000')
    final_date_str = fin_date.strftime(f'%Y-%m-%dT{fin_time}:00:00.000')

    initial_date_utc = await date_time_global(initial_date_str, timezone)   
    final_date_utc = await date_time_global(final_date_str, timezone)

    return initial_date_utc, final_date_utc


async def dayweek():
    #dia = datetime.date.today().weekday()
    fechaDay = datetime.datetime.now(pytz.timezone(os.getenv("TZ")))
    fecha = fechaDay.strftime('%Y-%m-%d')
    fech = datetime.datetime.strptime(fecha, '%Y-%m-%d')
    dia = datetime.datetime.weekday(fech)

    match dia:
        case 0:
            diasemana = "Monday"
        case 1:
            diasemana = "Tuesday"
        case 2:
            diasemana = "Wednesday"
        case 3:
            diasemana = "Thursday"
        case 4:
            diasemana = "Friday"
        case 5:
            diasemana = "Saturday"
        case 6:
            diasemana = "Sunday"
        case None:
            diasemana = None

    return diasemana


async def calcularTotalNamespace(mcList,identificador):
    logger.info(f"Calculating namespace CPU totals")
    usogenCPU = 0
    averageCPU = 0
    opCPUgen = 0
    riskCPUgen = 0
    totreplicas = 0
    reqgenCPU = 0
    limgenCPU = 0
    date = []
    spec = {}
    dia = await dayweek()
    if len(mcList) == 0:
        logger.info(f"Microservice without pods")
        return date, totreplicas, mcList
    else:
        for micro in mcList:
            totreplicas += micro["replicasMicroservice"]
            usogenCPU += micro["totalUseMicroserviceCPU"]
            averageCPU += micro["AverageUseMicroserviceCPU"]
            reqgenCPU += micro["totalRequestMicroserviceCPU"]
            limgenCPU += micro["totalLimitMicroserviceCPU"]

        opCPUgen = int(reqgenCPU - usogenCPU)
        riskCPUgen = int(limgenCPU - usogenCPU)

        #Pasar de milicores a cores
        usogenCPUNam = round(usogenCPU/1000,3)
        averageCPUNam = round(averageCPU/1000,3)
        opCPUgenNam = round(opCPUgen/1000,3)
        riskCPUgenNam = round(riskCPUgen/1000,3)
        reqgenCPUNam = round(reqgenCPU/1000,3)
        limgenCPUNam = round(limgenCPU/1000,3)

        logger.info(f"Calculating namespace MEMORY totals")
        usogenMem = 0 
        avegenMem = 0
        reqgen = 0
        limgen = 0

        for micro in mcList:
            if micro["totalUseMicroserviceMEM"] == 0:
                usogenMem += 0
            else:
                usogenMem += int(micro["totalUseMicroserviceMEM"])

            if micro["averageUseMicroserviceMEM"] == 0:
                avegenMem += 0
            else:
                avegenMem += int(micro["averageUseMicroserviceMEM"])

            if micro["totalRequestMicroserviceMEM"] == 0:
                reqgen += 0
            else:
                reqgen += int(micro["totalRequestMicroserviceMEM"])

            if micro["totalLimitMicroserviceMEM"] == 0:
                limgen += 0
            else:
                limgen += int(micro["totalLimitMicroserviceMEM"])

        opMemgenNam = int(reqgen - usogenMem)
        riskMemgenNam = int(limgen - usogenMem)

        #Convertir de MiB a GiB
        usogenMemNam = round(usogenMem/1024,3)
        avegenMemNam = round(avegenMem/1024,3)
        opMemgenMemNam = round(opMemgenNam/1024,3)
        riskMemgenMemNam =  round(riskMemgenNam/1024,3)
        reqgenMemNam = round(reqgen/1024,3)
        limgenMemNam = round(limgen/1024,3)


        if identificador == "online":
            fechaH = datetime.datetime.now(pytz.timezone(os.getenv("TZ")))
            fechaHora = fechaH.strftime('%Y-%m-%d  %H:%M:%S')
            spec = {
                "dateHour": fechaHora,
                "totalUseNamespaceCPU": usogenCPUNam,
                "averageUseNamespaceCPU": averageCPUNam,
                "totalRequestNamespaceCPU": reqgenCPUNam,
                "totalLimitNamespaceCPU": limgenCPUNam,
                "totalOptimizationCPUNamespace": opCPUgenNam,
                "totalRiskCPUNamespace": riskCPUgenNam,
                "totalUseNamespaceMEM": usogenMemNam,
                "averageUseNamespaceMEM": avegenMemNam,
                "totalRequestNamespaceMEM": reqgenMemNam,
                "totalLimitNamespaceMEM": limgenMemNam,
                "totalOptimizationMemoryNamespace": opMemgenMemNam,
                "totalRiskMemoryNamespace": riskMemgenMemNam,
                "microservices": mcList
            }
            return spec, totreplicas, mcList
        else:
            #fechaDay = datetime.date.today()
            fechaDay = datetime.datetime.now(pytz.timezone(os.getenv("TZ")))
            fecha = fechaDay.strftime('%Y-%m-%d')
            spec = {
                "nameday": dia,
                "date": fecha,
                "totalUseNamespaceCPU": usogenCPUNam,
                "totalAverageNamespaceCPU": averageCPUNam,
                "totalRequestNamespaceCPU": reqgenCPUNam,
                "totalLimitNamespaceCPU": limgenCPUNam,
                "totalOptimizationCPUNamespace": opCPUgenNam,
                "totalRiskCPUNamespace": riskCPUgenNam,
                "totalUseNamespaceMEM": usogenMemNam,
                "totalAverageNamespaceMEM":avegenMemNam,
                "totalRequestNamespaceMEM": reqgenMemNam,
                "totalLimitNamespaceMEM": limgenMemNam,
                "totalOptimizationMemoryNamespace": opMemgenMemNam,
                "totalRiskMemoryNamespace": riskMemgenMemNam,
                "microservices": mcList
            }
            date.append(spec)
            return date, totreplicas, mcList


async def blockproductive(mg,namespace,cluster,region,microservice):
    querydbresultsmemory = mg.find({f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" })
    findnamespacememory = [x for x in querydbresultsmemory]
    if len(findnamespacememory) == 0:                                
        blockprod = None
    else:
        micList = findnamespacememory[0]["microservices"]
        for mc in micList:
            mic = mc["microservice"]
            if microservice==mic:
                blockprod = mc["productionBlock"]
                logger.info(f"Production block extraction completed") 
                break
            else: 
                blockprod = None
                
    return blockprod


async def hpass(region,dc,hpaData):
    microser = dc["metadata"]["name"]
    if len(hpaData[region]["items"]) == 0:
        hpa = None
    else:
        for hp in hpaData[region]["items"]:
            microhpa = hp["metadata"]["name"]
            microhpatarget = hp['spec']['scaleTargetRef']['name']
            if microser == microhpa or microser == microhpatarget:
                try:
                    currentCPUUsage = hp['status']['currentCPUUtilizationPercentage']
                except KeyError:
                    currentCPUUsage = None
                try:
                    lastScaleTime = hp['status']['lastScaleTime']
                except KeyError:
                    lastScaleTime = None

                currentReplicas = hp['status']['currentReplicas']
                desiredReplicas = hp['status']['desiredReplicas']
                minReplicas = hp["spec"]["minReplicas"]
                maxReplicas = hp["spec"]["maxReplicas"]

                try:
                    targetCPUUtilizationPercentage = hp["spec"]["targetCPUUtilizationPercentage"]
                except KeyError:
                    targetCPUUtilizationPercentage = None

                ableToScale = None
                messageAbleToScale = None
                scalingActive = None
                messageScalingActive = None
                try:
                    hpaconditions = json.loads(hp['metadata']['annotations']['autoscaling.alpha.kubernetes.io/conditions'])
                except:
                    hpaconditions = []
                    ableToScale = None
                    message = None

                for condition in hpaconditions:
                    if condition["type"] == "ScalingActive":
                        scalingActive = condition["status"]
                        messageScalingActive = condition["message"]
                    if condition["type"] == "AbleToScale":
                        ableToScale = condition["status"]
                        messageAbleToScale = condition["message"]
                
                minMaxReplicas = str(minReplicas) + '-' + str(maxReplicas)

                hpa = {
                    "hpaName": microhpa,
                    "minReplicas": minReplicas,
                    "maxReplicas": maxReplicas,
                    "minMaxReplicas": minMaxReplicas,
                    "targetCPUUtilizationPercentage": targetCPUUtilizationPercentage,
                    "lastScaleTime": lastScaleTime,
                    "currentReplicas": currentReplicas,
                    "desiredReplicas": desiredReplicas,
                    "currentCPUUsage": currentCPUUsage,
                    "scalingActive": scalingActive,
                    "messageScalingActive": messageScalingActive,
                    "ableToScale": ableToScale,
                    "messageAbleToScale": messageAbleToScale
                }
                break
            else:
                hpa = None
    logger.info(f"HPA extraction completed")
    return hpa


async def dumpDataMongoWeekToWeelOld():
    mg.change_collection(os.getenv("COLLECTION"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_WEEK"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION"))
    for d in datos:
        cont = cont + 1
        namespace = d['namespace']
        cluster = d['cluster']
        region = d['region']  
        querydbresultsmemory = mg.find({f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" })
        findnamespacememory = [x for x in querydbresultsmemory]
        if len(findnamespacememory) == 0:                                
            mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")
    if numreg == cont:
        logger.info("Document dump ok")
        mg.change_collection(os.getenv("COLLECTION_WEEK"))
        mg.delete_all_data()
    else:
        logger.info(f"Something has gone wrong, document {cont}")


async def formatearcpu(cpu):
    if cpu == None:
        cpuformat = None
        next
    elif "m" in cpu:
        cpuformat = int(cpu[:-1])
    else:
        cpuformat = int(cpu) * 1000
    return cpuformat


def load_domain_mappings():
    domain_mappings_json = os.getenv('DOMAIN_MAPPINGS')
    if domain_mappings_json:
        return json.loads(domain_mappings_json)
    return {}

DOMAIN_MAPPINGS = load_domain_mappings()


async def traductorcluster(environment,region,cluster):
    match region:
        case "bo1":
            match cluster:
                case "prodarwin":
                    clustertraduc = "san01darwin.san.pro.bo1"               
                case "dmzbdarwin":
                    clustertraduc = "san01darwin.san.dmzb.bo1"
                case "probks":
                    clustertraduc = "san01bks.san.pro.bo1"
                case "dmzbbks":
                    clustertraduc = "san01bks.san.dmzb.bo1"
                case "confluent":
                    clustertraduc = "san01confluent.san.pro.bo1"
                case "dmz2bmov":
                    clustertraduc = "san01mov.san.dmz2b.bo1"
                case "bks":
                    if environment == "dev":
                        clustertraduc = "san01bks.san.dev.bo1" 
                    else:
                        clustertraduc = "san01bks.san.pre.bo1"
                case "scg01.scg.pro":
                    clustertraduc = "scg01.scg.pro.bo1"
                case "scg01.scg.dmzb":
                    clustertraduc = "scg01.scg.dmzb.bo1"
        case "bo2":
            match cluster:
                case "prodarwin":
                    clustertraduc = "san01darwin.san.pro.bo2"
                case "dmzbdarwin":
                    clustertraduc = "san01darwin.san.dmzb.bo2"
                case "probks":
                    clustertraduc = "san01bks.san.pro.bo2"
                case "dmzbbks":
                    clustertraduc = "san01bks.san.dmzb.bo2"
                case "confluent":
                    clustertraduc = "san01confluent.san.pro.bo2"
                case "dmz2bmov":
                    clustertraduc = "san01mov.san.dmz2b.bo2"
                case "bks":
                    clustertraduc = "san01bks.san.pre.bo2"
                case "scg01.scg.pro":
                    clustertraduc = "scg01.scg.pro.bo1"
                case "scg01.scg.dmzb":
                    clustertraduc = "scg01.scg.dmzb.bo1"
        case "weu1":
            match cluster:
                case "azure":
                    if environment == "dev":
                        clustertraduc = "san.dev.weu1"
                    elif environment == "pre":
                        clustertraduc = "ocp01.san.pre.weu1"
                    else:
                        clustertraduc = "ocp01.san.pro.weu1"
                case "ocp05azure":
                    if environment == "pre":
                        clustertraduc = "ocp05.san.pre.weu1"
                    else:
                        clustertraduc = "ocp05.san.pro.weu1"
                case "dmzbazure":
                    clustertraduc = "ocp03.san.pro.weu1"
                case "ocpgnr.gsc.pro":
                    clustertraduc = "ocpgnr.gsc.pro.weu1"
        case "weu2":
            match cluster:
                case "azure":
                    if environment == "pre":
                        clustertraduc = "ocp01.san.pre.weu2"
                    else:
                        clustertraduc = "ocp02.san.pro.weu2"
                case "ocp05azure":
                    if environment == "pre":
                        clustertraduc = "ocp05.san.pre.weu2"
                    else:
                        clustertraduc = "ocp05.san.pro.weu2"
        case "weu":
            match cluster:
                case "ocppro01.gsc.pro":
                    clustertraduc = "ocppro01.gsc.pro.weu"
        case "cn1":
            match cluster:
                case "sgt01.sgt.pro":
                    if environment == "pro":
                        clustertraduc = "sgt01.sgt.pro.cn1"
                case "sgt01.sgt.dmzb":
                    if environment == "pro":
                        clustertraduc = "sgt01.sgt.dmzb.cn1"
                case "gsc04.gsc.pro":
                    if environment == "pro":
                        clustertraduc = "gsc04.gsc.pro.cn1"
                case "gsc04.gsc.dmzb":
                    if environment == "pro":
                        clustertraduc = "gsc04.gsc.dmzb.cn1"
        case "cn2":
            match cluster:
                case "sgt01.sgt.pro":
                    if environment == "pro":
                        clustertraduc = "sgt01.sgt.pro.cn2"
                case "sgt01.sgt.dmzb":
                    if environment == "pro":
                        clustertraduc = "sgt01.sgt.dmzb.cn2"
                case "gsc04.gsc.pro":
                    if environment == "pro":
                        clustertraduc = "gsc04.gsc.pro.cn2"
                case "gsc04.gsc.dmzb":
                    if environment == "pro":
                        clustertraduc = "gsc04.gsc.dmzb.cn2"

        case "mx1":
            match cluster:
                case "csa02.csa.pro":
                    if environment == "pro":
                        clustertraduc = "csa02.csa.pro.mx1"
                case "gluon01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "gluon01.mex.pro.mx1"
                case "grav01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "grav01.mex.pro.mx1"
                case "mex02.mex.pro":
                    if environment == "pro":
                        clustertraduc = "mex02.mex.pro.mx1"
                case "mex02.mex.dmzb":
                    if environment == "pro":
                        clustertraduc = "mex02.mex.dmzb.mx1"
                case "ocp01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp01.mex.pro.mx1"
                case "ocp02.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp02.mex.pro.mx1"
                case "ocp03.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp03.mex.pro.mx1"
                case "ocp04.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp04.mex.pro.mx1"
                case "ocp05.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp05.mex.pro.mx1"
                case "ocp06.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp06.mex.pro.mx1"
                case "plard01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "plard01.mex.pro.mx1"
                case "str01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "str01.mex.pro.mx1"
                case "gscmx01.gscmx.pro":
                    if environment == "pro":
                        clustertraduc = "gscmx01.gscmx.pro.mx1"
        
        case "mx2":
            match cluster:
                case "csa02.csa.pro":
                    if environment == "pro":
                        clustertraduc = "csa02.csa.pro.mx2"
                case "gluon01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "gluon01.mex.pro.mx2"
                case "grav01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "grav01.mex.pro.mx2"
                case "mex02.mex.pro":
                    if environment == "pro":
                        clustertraduc = "mex02.mex.pro.mx2"
                case "mex02.mex.dmzb":
                    if environment == "pro":
                        clustertraduc = "mex02.mex.dmzb.mx2"
                case "ocp01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp01.mex.pro.mx2"
                case "ocp02.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp02.mex.pro.mx2"
                case "ocp03.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp03.mex.pro.mx2"
                case "ocp04.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp04.mex.pro.mx2"
                case "ocp05.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp05.mex.pro.mx2"
                case "ocp06.mex.pro":
                    if environment == "pro":
                        clustertraduc = "ocp06.mex.pro.mx2"
                case "plard01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "plard01.mex.pro.mx2"
                case "str01.mex.pro":
                    if environment == "pro":
                        clustertraduc = "str01.mex.pro.mx2"
                case "gscmx01.gscmx.pro":
                    if environment == "pro":
                        clustertraduc = "gscmx01.gscmx.pro.mx2"

    return clustertraduc


async def totalusomicro(podDict):
    f = 0
    d = 0
    c = 0
    e = 0
    if len(podDict) == 0:
        exit
    else:
        for t in podDict:
            for e in t["use"].items():
                if e[0] == "CPUUsage":
                    f = f + int(e[1])
                if e[0] == "OptimizationCPUPod":
                    d = d + int(e[1])
                if e[0] == "RiskCPUPod":
                    c = c + int(e[1])
    
    g = 0
    h = 0
    i = 0
    e = 0
    if len(podDict) == 0:
        exit
    else:
        for t in podDict:
            for e in t["use"].items():
                if e[0] == "MemoryUsage+Cache":
                    g = g + float(e[1])
                if e[0] == "OptimizationMemoryPod":
                    h = h + float(e[1])
                if e[0] == "RiskMemoryPod":
                    i = i + float(e[1])

    return f,d,c,g,h,i


async def totalusomicro_maxhpa(poddict,hpa):
    f,d,c,g,h,i = 0,0,0,0,0,0
    if len(poddict) == 0:
        return f,d,c,g,h,i
    else:
        poddict_ordenado = sorted(poddict, key=lambda x: str(x["lifeTimePod"]), reverse=True)
        contador = 0
        for t in poddict_ordenado:
            if contador >= hpa:
                break
            for e in t["use"].items():
                match e[0]:
                    case "CPUUsage":
                        f += int(e[1])
                    case "OptimizationCPUPod":
                        d += int(e[1])
                    case "RiskCPUPod":
                        c += int(e[1])
                    case "MemoryUsage+Cache":
                        g = g + float(e[1])
                    case "OptimizationMemoryPod":
                        h = h + float(e[1])
                    case "RiskMemoryPod":
                        i = i + float(e[1])
            contador += 1
            if contador >= hpa:
                break

    return f,d,c,g,h,i


async def formatearmemory(memoryNow):
    if memoryNow != None:
        if "KiB" in memoryNow:
            memoryNow = float(memoryNow[:-3])*2**10
        elif "Ki" in memoryNow:
            memoryNow = int(memoryNow[:-2])*2**10
        elif "MiB" in memoryNow:
            memoryNow = float(memoryNow[:-3])*2**20              
        elif "Mi" in memoryNow:
            memoryNow = int(memoryNow[:-2])*2**20
        elif "GiB" in memoryNow:
            memoryNow = float(memoryNow[:-3])*2**30
        elif "Gi" in memoryNow:
            memoryNow = int(memoryNow[:-2])*2**30
        elif "TiB" in memoryNow:
            memoryNow = float(memoryNow[:-3])*2**40 
        elif "Ti" in memoryNow:
            memoryNow = int(memoryNow[:-2])*2**40  
        elif "PiB" in memoryNow:
            memoryNow = float(memoryNow[:-3])*2**50
        elif "Pi" in memoryNow:
            memoryNow = int(memoryNow[:-2])*2**50   
        elif "B" in memoryNow or "b" in memoryNow:
            memoryNow = float(memoryNow[:-1])*1             
        elif "K" in memoryNow or "k" in memoryNow:
            memoryNow = int(memoryNow[:-1])*1000
        elif "M" in memoryNow or "m" in memoryNow:
            memoryNow = int(memoryNow[:-1])*1000*1000
        elif "G" in memoryNow or "g" in memoryNow:
            memoryNow = int(memoryNow[:-1])*1000*1000*1000
        elif "T" in memoryNow or "t" in memoryNow:
            memoryNow = int(memoryNow[:-1])*1000*1000*1000*1000
        else:
            memoryNow = int(memoryNow)
    return memoryNow


async def control_errores(region,cluster,environment):
    #Introducir un cluster que no exista en el entorno
    if (environment == "dev" and (cluster == "prodarwin" or cluster == "dmzbdarwin" or cluster == "confluent" or cluster == "proohe" or cluster == "dmzbohe")):
        raise HTTPException(status_code=400, detail=f"Invalid cluster for environment: {environment}")
    elif (environment == "pre" and (cluster == "prodarwin" or cluster == "dmzbdarwin" or cluster == "confluent" or cluster == "proohe" or cluster == "dmzbohe")):
        raise HTTPException(status_code=400, detail=f"Invalid cluster for environment: {cluster}")

    #Introducir una region que no exista en el cluster
    if (cluster =="azure" and (region == "bo1" or region == "bo2")):
        raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
    elif (cluster =="ocp05azure" and (region == "bo1" or region == "bo2")):
        raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
    elif (cluster =="dmzbazure" and (region == "bo1" or region == "bo2")):
        raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
    elif (cluster =="prodarwin" and (region == "weu1" or region == "weu2")):
        raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
    elif (cluster =="dmzbdarwin" and (region == "weu1" or region == "weu2")):
        raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
    elif (cluster =="probks" and (region == "weu1" or region == "weu2")):
        raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")   
    elif (cluster =="dmzbbks" and (region == "weu1" or region == "weu2")):
            raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
    elif (cluster =="confluent" and (region == "weu1" or region == "weu2")):
        raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")


async def dateMissing():
    environment = os.getenv("ENVIRONMENT")
    namespacesList = []
    namespaceMissingDict = {}
    namespaceMissingList = []
    
    clusterList = ['confluent','azure','ocp05azure','dmzbazure','dmz2bmov','prodarwin','dmzbdarwin','probks','dmzbbks']

    day = await dayweek()

    mg.change_collection(os.getenv("COLLECTION_WEEK"))

    for cluster in clusterList:
        if cluster == "azure" or cluster == "ocp05azure" or cluster == "dmzbazure":
            regionlist = ['weu1', 'weu2']
        else:
            regionlist = ['bo1', 'bo2']

        for region in regionlist:
            namespaceMissingClusterList = []
            namespaceMissingMonday = []
            namespaceMissingTuesday = []
            namespaceMissingWednesday = []
            namespaceMissingThursday = []
            namespaceMissingFriday = []
            namespaceMissingSaturday = []
            namespaceMissingSunday = []
            namespacesList= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=region)
            for namespace in namespacesList[region]['items']:
                nmspace = namespace['metadata']['name']
                nameDayList = []
                document = mg.find_one({f"namespace":nmspace, f"cluster":cluster, f"region":region})
                if document != None:
                    dateList = document["date"]
                    for date in dateList:
                        nameday = date["nameday"]
                        nameDayList.append(nameday)                      
                    match day:
                        case 'Monday':
                            if "Monday" in nameDayList:
                                pass
                            else:
                                namespaceMissingMonday.append(nmspace)

                        case 'Tuesday':
                            if "Monday" in nameDayList:
                                pass
                            else:
                                namespaceMissingMonday.append(nmspace)

                            if "Tuesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingTuesday.append(nmspace)

                        case 'Wednesday':
                            if "Monday" in nameDayList:
                                pass
                            else:
                                namespaceMissingMonday.append(nmspace)

                            if "Tuesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingTuesday.append(nmspace)

                            if "Wednesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingWednesday.append(nmspace)
                        
                        case 'Thursday':
                            if "Monday" in nameDayList:
                                pass
                            else:
                                namespaceMissingMonday.append(nmspace)

                            if "Tuesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingTuesday.append(nmspace)

                            if "Wednesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingWednesday.append(nmspace)

                            if "Thursday" in nameDayList:
                                pass
                            else:
                                namespaceMissingThursday.append(nmspace)

                        case 'Friday':
                            if "Monday" in nameDayList:
                                pass
                            else:
                                namespaceMissingMonday.append(nmspace)

                            if "Tuesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingTuesday.append(nmspace)

                            if "Wednesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingWednesday.append(nmspace)

                            if "Thursday" in nameDayList:
                                pass
                            else:
                                namespaceMissingThursday.append(nmspace)

                            if "Friday" in nameDayList:
                                pass
                            else:
                                namespaceMissingFriday.append(nmspace)

                        case 'Saturday':
                            if "Monday" in nameDayList:
                                pass
                            else:
                                namespaceMissingMonday.append(nmspace)

                            if "Tuesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingTuesday.append(nmspace)

                            if "Wednesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingWednesday.append(nmspace)

                            if "Thursday" in nameDayList:
                                pass
                            else:
                                namespaceMissingThursday.append(nmspace)

                            if "Friday" in nameDayList:
                                pass
                            else:
                                namespaceMissingFriday.append(nmspace)
                            
                            if "Saturday" in nameDayList:
                                pass
                            else:
                                namespaceMissingSaturday.append(nmspace)

                        case 'Sunday':
                            if "Monday" in nameDayList:
                                pass
                            else:
                                namespaceMissingMonday.append(nmspace)

                            if "Tuesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingTuesday.append(nmspace)

                            if "Wednesday" in nameDayList:
                                pass
                            else:
                                namespaceMissingWednesday.append(nmspace)

                            if "Thursday" in nameDayList:
                                pass
                            else:
                                namespaceMissingThursday.append(nmspace)

                            if "Friday" in nameDayList:
                                pass
                            else:
                                namespaceMissingFriday.append(nmspace)
                            
                            if "Saturday" in nameDayList:
                                pass
                            else:
                                namespaceMissingSaturday.append(nmspace)

                            if "Sunday" in nameDayList:
                                pass
                            else:
                                namespaceMissingSunday.append(nmspace)
                            
                else:
                    namespaceMissingClusterList.append(nmspace)

            namespaceMissingDict = {
                "cluster": cluster,
                "region": region,
                "namespaceMissing": namespaceMissingClusterList,
                "Monday": namespaceMissingMonday,
                "Tuesday": namespaceMissingTuesday,
                "Wednesday": namespaceMissingWednesday,
                "Thursday": namespaceMissingThursday,
                "Friday": namespaceMissingFriday,
                "Saturday": namespaceMissingSaturday,
                "Sunday": namespaceMissingSunday,
            }
            namespaceMissingList.append(namespaceMissingDict)


    return namespaceMissingList


async def compareSwitch():
    switch = []
    
    Monday = []

    elastic = []
    openshift = []

    for mon in Monday:
        if mon in switch:
            elastic.append(mon)
        else:
            openshift.append(mon)

    return elastic,openshift


async def getSwitchStatus():
    functionalEnvironment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    if functionalEnvironment == 'pro':
        logger.debug("Get namespaces with Switch = True")
        url = os.getenv("SWITCH_API_URI")
        path = os.getenv("SWITCH_API_PATH")
        request_url = url + path
        headers = {"Accept": "application/json"}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(request_url, headers=headers, ssl=False) as answer:
                    switchedanswer = await answer.json()
                    logger.debug(f"Response: {answer.status}, {answer.reason}")
                    if answer.status == 200:
                        resultswitch = list(set([ r["namespace"] for r in switchedanswer if r["switch"] == True ]))
                        logger.debug(f"answer switch 'True': {resultswitch}")
                        return resultswitch
                    else:
                        resultswitch = ['no-switch']
                        logger.debug(f"answer: {resultswitch}")
                        return resultswitch
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {request_url} ")
            resultswitch = ['no-switch']
            return resultswitch
        except:
            logger.error(f"{request_url} could not be retrieved. Skipping...")
            resultswitch = ['no-switch']
            return resultswitch
    else:
        resultswitch = ['no-switch']
        logger.debug(f"Answer: {resultswitch}")
        return resultswitch


async def services(environment,cluster,namespace,microservice):
    micr = None
    micro = None
    microb = None
    microg = None

    try:
        services=await client.get_resource(functional_environment=environment,cluster=cluster,resource="services",namespace=namespace)
    except: 
        services = []
    
    for serv in services:
        if services[serv] == 403:
            next
        else:
            if len(services[serv]["items"]) == 0:
                next
            else:
                contBlue = 0
                contGreen = 0
                exclusion = [
                    'config',
                    'gateway',
                    'datagrid',
                    'sts',
                    'pkm',
                    'nhb-libs',
                    'nginx-nhb',
                    'moneyplan',
                    'corporate',
                    'security',
                    'trace',
                    'decomisado'
                ]
                
                for ex in exclusion:
                    if ex in microservice:
                    #or 'gateway' in microservice or 'datagrid' in microservice:
                        for service in services[serv]["items"]:
                            if 'b-g-' in service['metadata']['name']:
                                try:
                                    mic = service['spec']['selector']['app_name']
                                except:
                                    try:
                                        mic = service['spec']['selector']['app']
                                    except:
                                        try:
                                            mic = service['spec']['selector']['app.kubernetes.io/instance']
                                        except:
                                            try:
                                                mic = service['spec']['selector']['app.kubernetes.io/name']
                                            except:
                                                mic = service['metadata']['labels']['app_name']

                                if '-blue' in mic or mic[-2] == '-' and mic[-1] == 'b':
                                    contBlue += 1
                                elif '-green' in mic or mic[-2] == '-' and mic[-1] == 'g':
                                    contGreen += 1
                                else:
                                    pass
                    
                        if contBlue > contGreen:
                            if namespace == 'san-nweb-emp-pro':
                                if 'datagrid' in microservice or 'arq' in microservice:
                                    micr = microservice
                                    micro = microservice
                                    microb = microservice
                                    #microg = microservice
                                else:
                                    micr = microservice
                                    micro = microservice + '-b'
                                    microb = microservice + '-blue'
                                    #microg = microservice + '-green'
                            else:
                                micr = microservice
                                micro = microservice + '-b'
                                microb = microservice + '-blue'
                                #microg = microservice + '-green'
                        else:
                            if namespace == 'san-nweb-emp-pro':
                                if 'datagrid' in microservice or 'arq' in microservice:
                                    micr = microservice
                                    micro = microservice
                                    #microb = microservice
                                    microg = microservice
                                else:
                                    micr = microservice
                                    micro = microservice + '-g'
                                    #microb = microservice + '-blue'
                                    microg = microservice + '-green'
                            else:
                                micr = microservice
                                micro = microservice + '-g'
                                #microb = microservice + '-blue'
                                microg = microservice + '-green'
                        break

                for service in services[serv]["items"]:
                    srv = 'b-g-' + microservice
                    if srv == service['metadata']['name']:
                        #micr = microservice
                        try:
                            micro = service['spec']['selector']['app_name']
                        except:
                            try:
                                mic = service['spec']['selector']['app']
                            except:
                                try:
                                    mic = service['spec']['selector']['app.kubernetes.io/instance']
                                except:
                                    try:
                                        mic = service['spec']['selector']['app.kubernetes.io/name']
                                    except:
                                        mic = service['metadata']['labels']['app_name']
                        #microb = microservice + '-blue'
                        #microg = microservice + '-green'
                        break
                    #else:
                if micro == None:
                    for service in services[serv]["items"]:
                        if 'b-g-' in service['metadata']['name']:
                            try:
                                mic = service['spec']['selector']['app_name']
                            except:
                                try:
                                    mic = service['spec']['selector']['app']
                                except:
                                    try:
                                        mic = service['spec']['selector']['app.kubernetes.io/instance']
                                    except:
                                        try:
                                            mic = service['spec']['selector']['app.kubernetes.io/name']
                                        except:
                                            mic = service['metadata']['labels']['app_name']
                                        

                            if '-blue' in mic or mic[-2] == '-' and mic[-1] == 'b':
                                contBlue += 1
                            elif '-green' in mic or mic[-2] == '-' and mic[-1] == 'g':
                                contGreen += 1
                            else:
                                pass
                        else:
                            mic = service['metadata']['name']
                            
                            if '-blue' in mic or mic[-2] == '-' and mic[-1] == 'b':
                                contBlue += 1
                            elif '-green' in mic or mic[-2] == '-' and mic[-1] == 'g':
                                contGreen += 1
                            else:
                                pass
                
                    if contBlue > contGreen:
                        if namespace == 'san-nweb-emp-pro':
                            if 'datagrid' in microservice or 'arq' in microservice:
                                micr = microservice
                                micro = microservice
                                microb = microservice
                                #microg = microservice
                            else:
                                micr = microservice
                                micro = microservice + '-b'
                                microb = microservice + '-blue'
                                #microg = microservice + '-green'
                        else:
                            micr = microservice
                            micro = microservice + '-b'
                            microb = microservice + '-blue'
                            #microg = microservice + '-green'
                    else:
                        if namespace == 'san-nweb-emp-pro':
                            if 'datagrid' in microservice or 'arq' in microservice:
                                micr = microservice
                                micro = microservice
                                #microb = microservice
                                microg = microservice
                            else:
                                micr = microservice
                                micro = microservice + '-g'
                                #microb = microservice + '-blue'
                                microg = microservice + '-green'
                        else:
                            micr = microservice
                            micro = microservice + '-g'
                            #microb = microservice + '-blue'
                            microg = microservice + '-green'
                    break
    return micr,micro,microb,microg           


async def update_extractinfo_blockProduction(cluster,region,namespace):
    
    urlapi = os.getenv("API_EXTRACTINFO_URL") #set api url where the information will be extracted
    path = os.getenv("API_EXTRACTINFO_PATH") #set api path

    body = {
        "functionalEnvironment": "pro",
        "cluster": cluster,
        "region": region,
        "namespacesList": [
            namespace
        ],
        "objectsList": [
            "productionBlock"
        ]
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(urlapi+path, json=body, ssl=False) as resp:
            logger.debug(f"API {urlapi+path} with response status: {resp.status}, cluster: {cluster}, region: {region}, namespace: {namespace}")
            if resp.status == 200:
                data = await resp.text()
                return json.loads(data)
            else:
                return None


async def get_event_week(environment, clustertraduc, namespace, initialHour=None,finalHour=None):
    """
    Retrieves event data for a given week.

    Args:
        environment (str): The environment to retrieve event data from.
        clustertraduc (str): The cluster to retrieve event data from.
        namespace (str): The namespace to retrieve event data from.

    Returns:
        dict: A dictionary containing lifetime of every with event.

    """
    if initialHour != None and finalHour!=None:
        date = []
        date.append(initialHour)
        date.append(finalHour)
    else:
        date = await timer()
    #initial_time = date[0]
    #final_time = date[1]
    initial_time = datetime.datetime.strptime(date[0], '%Y-%m-%dT%H:%M:%S.%fZ')
    final_time = datetime.datetime.strptime(date[1], '%Y-%m-%dT%H:%M:%S.%fZ')
    event_list = {}
    pod_list = {}
    zero_time = datetime.timedelta(0)

    ps = await elastic_gpw(environment=environment, clustertraduc=clustertraduc, namespace=namespace,initialHour=initialHour,finalHour=finalHour)

    for n in ps: 
        pod_name = n['_source']['kubernetes']['event']['involved_object']['name'] 
        pod_event = n['_source']['kubernetes']['event']['reason'] 
        time = n['_source']['@timestamp']
        if pod_name not in event_list:
            event_list[pod_name] = {}
        temp_date = datetime.datetime.strptime(time, '%Y-%m-%dT%H:%M:%S.%fZ')

        event_list[pod_name][pod_event] = temp_date

    for pod in event_list:
        if 'AddedInterface' not in event_list[pod]:
            event_list[pod]['AddedInterface'] = initial_time
        elif 'Killing' not in event_list[pod]:
            event_list[pod]['Killing'] = final_time
       
        if event_list[pod]['AddedInterface'] >= final_time:
            pod_list[pod] = zero_time
        elif event_list[pod]['Killing'] > final_time:
            pod_list[pod] = final_time - event_list[pod]['AddedInterface']
        else:        
            pod_list[pod] = event_list[pod]['Killing'] - event_list[pod]['AddedInterface']

    return pod_list


async def get_pod_lifetime(podname, pod_list):
    """
    Get the lifetime of a pod.

    Args:
        podname (str): The name of the pod.
        pod_list (dict): A dictionary containing pod names as keys and their lifetimes as values.

    Returns:
        datetime.time: The lifetime of the pod as a time object.

    """
    date = await timer()
    #initial_time = date[0]
    #final_time = date[1]
    initial_time = datetime.datetime.strptime(date[0], '%Y-%m-%dT%H:%M:%S.%fZ')
    final_time = datetime.datetime.strptime(date[1], '%Y-%m-%dT%H:%M:%S.%fZ')
    date_diff = final_time - initial_time
 
    if podname in pod_list:
        return pod_list[podname]
    else:
        return date_diff