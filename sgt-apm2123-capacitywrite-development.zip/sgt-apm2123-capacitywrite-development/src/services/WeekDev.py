from shuttlelib.helper.keys import get_enviroment
from shuttlelib.utils.logger import logger
import os, aiohttp
import datetime
from src.services.Estructural import traductorcluster,elastic,hpass,blockproductive,calcularTotalNamespace,control_errores,formatearcpu,formatearmemory,totalusomicro,client,mg
       

async def get_capacity_week(cluster,region=None,namespace=None):
    environment = 'dev'
    cpumemoryList = []
    nsSinDatos = []

    fecha = datetime.datetime.now()
    print(f"Inicio {cluster}: ", fecha)
    match region:
        case None:
            reg = get_enviroment(environment)
            for rg in reg[cluster]:
                nsSinConexion = []
                nsSinDCoDeploy = []
                nsSinReplicas = []
                match namespace:
                    case None:
                        try:
                            ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=rg)
                            for i in ns[rg]["items"]:
                                try:
                                    nmspace = i["metadata"]["name"]
                                    uid = i["metadata"]["uid"]
                                    logger.info(f"*******Starting to extract data from {cluster}-{nmspace}-{rg}*******")
                                    dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=rg)
                                    deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=rg)
                                    hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=rg)
                                    pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=rg)

                                    if dc[rg] == 403 or deployments[rg] == 403 or hpas[rg] == 403 or pods[rg] == 403:
                                        cpumemoryList = [[],0,[]]
                                        nsSinConexion.append(nmspace)
                                    elif len(dc[rg]["items"]) == 0 and len(deployments[rg]["items"]) == 0:
                                        cpumemoryList = [[],0,[]]
                                        nsSinDCoDeploy.append(nmspace)
                                    else:
                                        if len(pods[rg]["items"]) == 0:
                                            cpumemoryList = [[],0,[]]
                                            nsSinReplicas.append(nmspace)
                                        else:
                                            cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,pods=pods,namespace=nmspace,region=rg,cluster=cluster)

                                    if len(cpumemoryList[0]) == 0:
                                        cpumemoryList = f"All namespace microservices {nmspace}, they are off"
                                        nsSinReplicas.append(nmspace)
                                    else:
                                        await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=rg,namespace=nmspace,uid=uid)
                                        logger.info(f"******* Extraction completed for {cluster}---{nmspace}---{rg} *******")
                                except:
                                    logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                                    continue
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against {environment+cluster+rg} ")
                            continue
                        except:
                            logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                            continue
                    case _:
                        try:
                            ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=rg)
                            for i in ns[rg]["items"]:
                                nmspace = i["metadata"]["name"]
                                if nmspace==namespace:
                                    uid = i["metadata"]["uid"]
                                    break

                            logger.info(f"******* Starting to extract data from {cluster}---{namespace}---{rg} *******")
                            dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=rg)
                            deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=rg)
                            hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=rg)
                            pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=rg)

                            if dc[rg] == 403 or deployments[rg] == 403 or hpas[rg] == 403 or pods[rg] == 403:
                                cpumemoryList = [[],0,[]]
                                nsSinConexion.append(namespace)
                            elif len(dc[rg]["items"]) == 0 and len(deployments[rg]["items"]) == 0:
                                cpumemoryList = [[],0,[]]
                                nsSinDCoDeploy.append(namespace)
                            else:
                                if len(pods[rg]["items"]) == 0:
                                    cpumemoryList = [[],0,[]]
                                    nsSinReplicas.append(namespace)
                                else:
                                    cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,pods=pods,namespace=namespace,region=rg,cluster=cluster)

                            if len(cpumemoryList[0]) == 0:
                                cpumemoryList = f"All namespace microservices {namespace}, they are off"
                                nsSinReplicas.append(namespace)
                            else:
                                logger.info(f"Saving data")
                                await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=rg,namespace=namespace,uid=uid)
                                logger.info(f"******* Extraction completed for {cluster}---{namespace}---{rg} *******")
                            
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against {environment+cluster+rg} ")
                            continue
                        except:
                            logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                            continue
                nsSinDCoDeployUnicos = list(set(nsSinDCoDeploy))
                nsSinConexionUnicos = list(set(nsSinConexion)) 
                nsSinReplicasUnicos = list(set(nsSinReplicas))   
                namesSinDat = {
                    "cluster": cluster,
                    "region": rg,
                    "namespacesSinDcoDeploy": nsSinDCoDeployUnicos,
                    "namespaceSinConexion": nsSinConexionUnicos,
                    "namespaceSinReplicas": nsSinReplicasUnicos
                }
                nsSinDatos.append(namesSinDat)
        case _:
            nsSinConexion = []
            nsSinDCoDeploy = []
            nsSinReplicas = []
            match namespace:
                case None:
                    await control_errores(region,cluster,environment) 
                    try:
                        ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=region)
                        for i in ns[region]["items"]:
                            try:
                                nmspace = i["metadata"]["name"]
                                if nmspace == 'knative-eventing':
                                    continue
                                else:
                                    uid = i["metadata"]["uid"]
                                    logger.info(f"******* Starting to extract data from {cluster}---{nmspace}---{region} *******")
                                    dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=region)
                                    deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=region)
                                    hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=region)
                                    pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=region)

                                    if dc[region] == 403 or deployments[region] == 403 or hpas[region] == 403 or pods[region] == 403:
                                        cpumemoryList = [[],0,[]]
                                        nsSinConexion.append(nmspace)
                                    elif len(dc[region]["items"]) == 0 and len(deployments[region]["items"]) == 0:
                                        cpumemoryList = [[],0,[]]
                                        nsSinDCoDeploy.append(nmspace)
                                    else:
                                        if len(pods[region]["items"]) == 0:
                                            cpumemoryList = [[],0,[]]
                                            nsSinReplicas.append(nmspace)
                                        else:
                                            cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,pods=pods,namespace=nmspace,region=region,cluster=cluster)

                                    if len(cpumemoryList[0]) == 0:
                                        cpumemoryList = f"All namespace microservices {namespace}, they are off"
                                        nsSinReplicas.append(nmspace)
                                    else:
                                        await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=region,namespace=nmspace,uid=uid)
                                        logger.info(f"******* Extraction completed for {cluster}---{nmspace}---{region} *******")
                            except:
                                logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                                continue
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {environment+cluster+region} ")
                        next
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        next
                case _:
                    try:
                        ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=region)
                        for i in ns[region]["items"]:
                            nmspace = i["metadata"]["name"]
                            if nmspace==namespace:
                                uid = i["metadata"]["uid"]
                                break
                        logger.info(f"******* Starting to extract data from {cluster}---{namespace}---{region} *******")
                        dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=region)
                        deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=region)
                        hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=region)
                        pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=region)

                        if dc[region] == 403 or deployments[region] == 403 or hpas[region] == 403 or pods[region] == 403:
                            cpumemoryList = [[],0,[]]
                            nsSinConexion.append(namespace)
                        elif len(dc[region]["items"]) == 0 and len(deployments[region]["items"]) == 0:
                            cpumemoryList = [[],0,[]]
                            nsSinDCoDeploy.append(namespace)
                        else:
                            if len(pods[region]["items"]) == 0:
                                cpumemoryList = [[],0,[]]
                                nsSinReplicas.append(namespace)
                            else:
                                cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,pods=pods,namespace=namespace,region=region,cluster=cluster)

                        if len(cpumemoryList[0]) == 0:
                            cpumemoryList = f"All namespace microservices {namespace}, they are off"
                            nsSinReplicas.append(namespace)
                        else:
                            logger.info(f"Saving data")
                            await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=region,namespace=namespace,uid=uid)
                            logger.info(f"******* Extraction completed for {cluster}---{namespace}---{region} *******")
                        
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {environment+cluster+region} ")
                        next
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        next
            nsSinDCoDeployUnicos = list(set(nsSinDCoDeploy))
            nsSinConexionUnicos = list(set(nsSinConexion)) 
            nsSinReplicasUnicos = list(set(nsSinReplicas))
            namesSinDat = {
                "cluster": cluster,
                "region": region,
                "namespacesSinDcoDeploy": nsSinDCoDeploy,
                "namespaceSinConexion": nsSinConexion,
                "namespaceSinReplicas": nsSinReplicas
            }
            nsSinDatos.append(namesSinDat)
    fecha2 = datetime.datetime.now()
    print(f"Fin {cluster}: ", fecha2)
    return nsSinDatos


async def get_data_week(hpas,environment,deploymentconfigs,deployments,pods,namespace,region,cluster):
    mcList = []
    identificador = "week"
    #Traducimos el cluster para poder pasarle a elastic el formato correcto
    clustertraduc = await traductorcluster(environment=environment,region=region,cluster=cluster)

    #Llamamos a elastic para trear los datos de uso que necesitamos
    Ps = await elastic(identificador=identificador,environment=environment,clustertraduc=clustertraduc,namespace=namespace)

    mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))
    if len(deploymentconfigs[region]["items"]) == 0:
        next
        totalName = ['',0,'']
    else:
        logger.info(f"########################## Extracting deploymentconfigs  ##########################")
        if len(deploymentconfigs[region]["items"]) == 0:
            next
        else:
            for deco in deploymentconfigs[region]["items"]:
                #Recogemos el namespace y el microservicio del deploy config
                microservice = deco["metadata"]["name"]
                try:
                    replicas = deco["status"]["replicas"]
                except:
                    replicas = deco["spec"]["replicas"]

                if replicas == 0:
                    next
                else:
                    logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                    logger.info("------ Starting data extraction ------")
                    hpasNam = await hpass(region,deco,hpas)
                    infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                    if cluster != 'confluent':
                        if infonamesp == "production":
                            #Extraccion de datos y calculo de totales a nivel microservicio
                            mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deco,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador))
                        else:
                            continue
                    else:
                        mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deco,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador))
        logger.info(f"########################## Deploymentconfigs extraction completed  ##########################")

    if len(deployments[region]["items"]) == 0:
        next
        totalName = ['',0,'']
    else:
        logger.info(f"########################## Extracting deployments  ##########################")
        for deploy in deployments[region]["items"]:
            #Recogemos el namespace y el microservicio del deploy config
            microservice = deploy["metadata"]["name"]
            try:
                replicas = deploy["status"]["replicas"]
            except:
                replicas = deploy["spec"]["replicas"]

            if replicas == 0:
                next
            else:
                logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                logger.info("------ Starting data extraction ------")
                hpasNam = await hpass(region,deploy,hpas)
                #Extraccion de datos y calculo de totales a nivel microservicio
                infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                if cluster != 'confluent':
                    
                    mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deploy,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador))
           

                else:
                    mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deploy,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador))
        logger.info(f"########################## Deployments extraction completed  ##########################")

    totalName = await calcularTotalNamespace(mcList,identificador)


    if cluster == 'confluent':
        blueList = []
        greenList = []
        for dat1 in totalName[2]:
            microblue = dat1['microservice']
            if '-blue' in microblue or microblue[-2] == '-' and microblue[-1] == 'b':
                blue = {
                    'microservice': dat1['microservice'],
                    'replicas': dat1['replicasMicroservice'],
                    'useMEM': dat1['totalUseMicroserviceMEM']
                }
                blueList.append(blue)
        blueListsort = sorted(blueList, key=lambda registro: registro['microservice'])
        for dat1 in totalName[2]:
            microgreen = dat1['microservice']
            if '-green' in dat1['microservice'] or microgreen[-2] == '-' and microgreen[-1] == 'g':
                green = {
                    'microservice': dat1['microservice'],
                    'replicas': dat1['replicasMicroservice'],
                    'useMEM': dat1['totalUseMicroserviceMEM']
                }
                greenList.append(green)
        greenListsort = sorted(greenList, key=lambda registro: registro['microservice'])

        if len(blueListsort) == 0 and len(greenListsort) == 0:
            bp = ''
        elif len(blueListsort) != 0 and len(greenListsort) == 0:
            bp = 'blue'
        elif len(blueListsort) == 0 and len(greenListsort) != 0:
            bp = 'green'
        else:
            for b in blueListsort:
                microb = b['microservice']
                if "-green" in microb:
                    microBSinSufijo = microb[:-6]
                elif "-g" in microb:
                    microBSinSufijo = microb[:-2]
                elif "-blue" in microb:
                    microBSinSufijo = microb[:-5]
                elif "-b" in microb:
                    microBSinSufijo = microb[:-2]
                else:
                    microBSinSufijo = microb["microservice"]

                for g in greenListsort:
                    microg = g['microservice']
                    if "-green" in microg:
                        microGSinSufijo = microg[:-6]
                    elif "-g" in microg:
                        microGSinSufijo = microg[:-2]
                    elif "-blue" in microg:
                        microGSinSufijo = microg[:-5]
                    elif "-b" in microg:
                        microGSinSufijo = microg[:-2]
                    else:
                        microGSinSufijo = microg["microservice"]
                    
                    if microBSinSufijo == microGSinSufijo:
                        replicasb = b['replicas']
                        replicasg = g['replicas']
                        if replicasb > replicasg:
                            bp = 'blue'
                        elif replicasb < replicasg:
                            bp = 'green'
                        else:
                            useMemB = b['useMEM']
                            useMemG = g['useMEM']
                            if useMemB > useMemG:
                                bp = 'blue'
                            elif useMemB < useMemG:
                                bp = 'green'

        
        listBorrar = []
        if bp == 'green':
            for dat1 in totalName[2]:
                microblue = dat1['microservice']
                if '-blue' in microblue or microblue[-2] == '-' and microblue[-1] == 'b':
                    dat1['blockProduction'] = 'ocu'
                    listBorrar.append(dat1)
                else:
                    dat1['blockProduction'] = 'production'

            for borrar in listBorrar:
                micBorrar = borrar['microservice']
                for dat1 in totalName[2]:
                    microse = dat1['microservice']
                    if micBorrar == microse:
                        totalName[2].remove(dat1)

        elif bp == 'blue':
            for dat1 in totalName[2]:
                microgreen = dat1['microservice']
                if '-green' in microgreen or microgreen[-2] == '-' and microgreen[-1] == 'g':
                    dat1['blockProduction'] = 'ocu'
                    listBorrar.append(dat1)
                else:
                    dat1['blockProduction'] = 'production'

            for borrar in listBorrar:
                micBorrar = borrar['microservice']
                for dat1 in totalName[2]:
                    microse = dat1['microservice']
                    if micBorrar == microse:
                        totalName[2].remove(dat1)
        else:
            pass
        
    return totalName


async def week_data_processing(environment,hpa,cluster,region,namespace,dc,blocProd,microservice,pods,Ps,identificador):
    mcList = [] #List que contendra de microservicios
    pds = {}
    podNameList = [] #Lista que contendra los pods
    #Recogemos CPU Request
    try:
        cpu_Request = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["cpu"]
    except:
        cpu_Request = None

    #Recogemos CPU Limit
    try:
        cpu_Limit = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["cpu"]
    except:
        cpu_Limit = None

    #Formateo de datos a milicores
    cpuReq = await formatearcpu(cpu_Request)
    cpuLim = await formatearcpu(cpu_Limit)

    #Recogemos MEMORY Request
    try:
        memory_Request = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["memory"]
    except:
        memory_Request = None

    #Recogemos MEMORY Limit
    try:
        memory_Limit = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["memory"]
    except:
        memory_Limit = None

    #Formateo de datos a MiB-GiB
    if memory_Request == None:
        memReqformat = None
    else:
        #Convertimos los datos en bytes
        memReq = await formatearmemory(memory_Request)
         #Convertimos los datos en MiB
        memReqformat = int(memReq/1048576)

    if memory_Limit == None:
        memLimformat = None
    else:
        #Convertimos los datos en bytes
        memLim = await formatearmemory(memory_Limit)
        #Convertimos los datos en MiB
        memLimformat = int(memLim/1048576)

    logger.info(f"Openshift extraction completed")

    replicas = dc["spec"]["replicas"] #Comprobamos si hay replicas
    availablereplicas = 0
    unavailableReplicas = 0
    try:
        availablereplicas = dc["status"]["availableReplicas"]  #Comprobamos si estan disponibles
    except:
        unavailableReplicas = dc["status"]["unavailableReplicas"]  #Comprobamos si estan disponibles

    try:
        unavailableReplicas = dc["status"]["unavailableReplicas"]  #Comprobamos si estan disponibles
    except:
        availablereplicas = dc["status"]["availableReplicas"]  #Comprobamos si estan disponibles

    if availablereplicas == 0 or unavailableReplicas != 0:
        next
    else:
        cont = 0
        for pod in pods[region]["items"]:
            try:
                podName = pod["metadata"]["name"]
            except KeyError:
                podName = None

            try:
                referenceName = pod["metadata"]["ownerReferences"][0]["name"]
            except KeyError:
                referenceName = None
            
            if referenceName != None:
                microPodName = referenceName[:referenceName.rfind('-')]
            else:
                microPodName = None

            if "-deploy" in podName:
                next
            else:
                #Comparamos nombre del microservicio del pod con el nombre del microservicio del namespace
                if microservice == microPodName:
                    cont = 1                    
                    try:
                        cpu_pod_Request = pod["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                    except:
                        cpu_pod_Request = None
                    try:
                        cpu_pod_Limit = pod["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                    except:
                        cpu_pod_Limit = None

                    #Formatemos los datos a milicores
                    cpuPodReq = await formatearcpu(cpu_pod_Request)
                    cpuPodLim = await formatearcpu(cpu_pod_Limit)

                    #Si no tiene configurado Request coge la configuración por defecto
                    if cpu_Request == None:
                        cpupodr = cpuPodReq  #Volcamos el valor para luego proceder al calculo o formateo, ya que despues al llevar la coletilla "por defecto" y ser str no se puede hacer calculos
                        #cpuPodReq = str(cpuPodReq) + " (Default configuration)"
                    
                    #Si no tiene configurado Limit coge la configuración por defecto
                    if cpu_Limit == None:
                        cpupodl = cpuPodLim  #Volcamos el valor para luego proceder al calculo o formateo, ya que despues al llevar la coletilla "por defecto" y ser str no se puede hacer calculos
                        #cpuPodLim = str(cpuPodLim) + " (Default configuration)"

                    try:
                        memory_pod_Request = pod["spec"]["containers"][0]["resources"]["requests"]["memory"]
                    except:
                        memory_pod_Request = None
                    try:
                        memory_pod_Limit = pod["spec"]["containers"][0]["resources"]["limits"]["memory"]
                    except:
                        memory_pod_Limit = None

                    memPodReq = await formatearmemory(memory_pod_Request)
                    memPodReqformat = int(memPodReq/1048576)
                    memPodLim = await formatearmemory(memory_pod_Limit)
                    memPodLimformat = int(memPodLim/1048576)

                    if memory_Request == None:
                        memPodr = memPodReqformat
                        #memPodReqformat = str(memPodReqformat) + " (Default configuration)"
                    
                    if memory_Limit == None:
                        memPodl = memPodLimformat
                        #memPodLimformat = str(memPodLimformat) + " (Default configuration)"

                    if len(Ps) == 0:
                        clustertraduc = await traductorcluster(region=region, cluster=cluster)
                        Ps = await elastic(identificador=identificador,environment=environment,clustertraduc=clustertraduc,namespace=namespace)

                    if len(Ps) == 0:
                        next
                    else:            
                        use = [] 
                        usage = {}
                        conta = 0
                        max = 0
                        maxMem = 0
                        logger.info(f"Processing elastic data from {podName}")

                        for n in Ps: #Recorremos los datos que hemos traido de elastic para tratarlos.
                            conta = conta + 1
                            try:
                                pod_name = n['_source']['kubernetes']['pod']['name'] #Nombre del pod de elastic
                            except:
                                pod_name = ''
                            
                            if podName == pod_name: #Comprobamos que le pod de openshift y el pod de elastic es el mismo
                                try:
                                    cp_usage = n['_source']['kubernetes']['pod']['cpu']['usage']['nanocores']['percentiles']['95'] #Extraermos el uso
                                except:
                                    cp_usage = 0 #Sino encontramos uso lo marcamos como uso 0

                                if cp_usage == None:
                                    cpu_usage = 0
                                else:
                                    cpu_usage = round(cp_usage / 1000000) #El uso en nanocores lo pasamos a milicores y redondeamos para quitar decimales

                                if cpu_usage > max:
                                    max = cpu_usage
                                
                                #Calulamos el ahorro (request-uso)
                                #if "Default" in str(cpuPodReq):
                                    #ahorrocpu = int(cpupodr) - cpu_usage
                                #else:
                                ahorrocpu = int(cpuPodReq) - cpu_usage

                                #Calulamos el riesgo (limit-uso)
                                #if "Default" in str(cpuPodLim):
                                    #riesgocpu = int(cpupodl) - cpu_usage
                                #else:
                                riesgocpu = int(cpuPodLim) - cpu_usage                               
                                    

                                #logger.info(f"Extrayendo el uso de MEMORIA del pod {podName}")
                                try:
                                    mem_working_set = n['_source']['kubernetes']['pod']['memory']['usage']['bytes']['total']['max']
                                except:
                                    mem_working_set = 0

                                if mem_working_set == 0:
                                    memory_working_setformat = 0
                                else:
                                    if mem_working_set == None:
                                        memory_working_setformat = 0
                                    else:
                                        memory_working_setformat = int(mem_working_set/1048576)

                                    if memory_working_setformat > maxMem:
                                        maxMem = memory_working_setformat

                                #Calulamos el ahorro (request-uso)
                                #if "Default" in str(memPodReqformat):
                                    #ahorromemavg = int(memPodr - memory_working_setformat)
                                #else:
                                ahorromemavg = int(memPodReqformat - memory_working_setformat)

                                #Calulamos el riesgo (limit-uso)
                                #if "Default" in str(memPodLimformat):
                                    #riesgomemavg = int(memPodl - memory_working_setformat)
                                #else:
                                riesgomemavg = int(memPodLimformat - memory_working_setformat)

                                #Montamos el diccionario de uso del pod
                                usage = {
                                    "CPUUsage": cpu_usage,
                                    "OptimizationCPUPod": ahorrocpu,
                                    "RiskCPUPod": riesgocpu,
                                    "MemoryUsage+Cache": memory_working_setformat,
                                    "OptimizationMemoryPod": ahorromemavg,
                                    "RiskMemoryPod": riesgomemavg,
                                }

                                #Lo añadimos a una lista, esta contiene todos los usos encontrados en elastic de un unico pod
                                use.append(usage)
                                
                        cpuPoReq = await formatearcpu(cpu_pod_Request)
                        cpuPoLim = await formatearcpu(cpu_pod_Limit)
                        if len(use) == 0:
                            cpu_usage = 0
                            max = cpu_usage

                            ahorrocpu = int(cpuPoReq - cpu_usage)
                            riesgocpu = int(cpuPoLim - cpu_usage)

                            memory_working_setformat = 0
                            ahorro_avg = int(memPodReqformat - memory_working_setformat)
                            riesgo_avg = int(memPodLimformat - memory_working_setformat)

                            usage = {
                                    "CPUUsage": cpu_usage,
                                    "OptimizationCPUPod": ahorrocpu,
                                    "RiskCPUPod": riesgocpu,
                                    "MemoryUsage+Cache": memory_working_setformat,
                                    "OptimizationMemoryPod": ahorro_avg,
                                    "RiskMemoryPod": riesgo_avg,
                                }
                            use.append(usage)
                            for d in use:
                                resultado = d
                        else:    
                            for d in use:
                                if d["CPUUsage"] >= max:
                                    usage_cpu = d["CPUUsage"]
                                    ahorro_cpu = d["OptimizationCPUPod"]
                                    risk_cpu = d["RiskCPUPod"]
                            
                            for d in use:
                                if d["MemoryUsage+Cache"] >= maxMem:
                                    usage_mem = d["MemoryUsage+Cache"]
                                    ahorro_mem = d["OptimizationMemoryPod"]
                                    risk_mem = d["RiskMemoryPod"]

                            usage = {
                                    "CPUUsage": usage_cpu,
                                    "OptimizationCPUPod": ahorro_cpu,
                                    "RiskCPUPod": risk_cpu,
                                    "MemoryUsage+Cache": usage_mem,
                                    "OptimizationMemoryPod": ahorro_mem,
                                    "RiskMemoryPod": risk_mem,
                                }

                        pds = {
                            "Pod": podName,     
                            "cpuRequestPod": cpuPodReq,
                            "cpuLimitPod": cpuPodLim,
                            "memoryRequestPod": memPodReqformat,
                            "memoryLimitPod": memPodLimformat,
                            "use":usage
                            }
                        podNameList.append(pds)
                        logger.info("Processing data completed")
                else:
                    if cont == 1:
                        cont = 0
                        break
                    else:
                        next

        
        if len(Ps) == 0:
            next
        else:
            logger.info("Calculating microservice CPU totals")
            #Calcular los totales del microservicio

            usoTotal = await totalusomicro(podDict=podNameList)
            usoTotalMicCPU = usoTotal[0]
            usoMedioCPU = int(usoTotalMicCPU / replicas)
            if cpuReq == None:
                requestTotalCPU = int(cpupodr * replicas)
                OpCPUmic = int(requestTotalCPU - usoTotalMicCPU)
            else:
                requestTotalCPU = int(cpuReq * replicas)
                OpCPUmic = int(requestTotalCPU - usoTotalMicCPU)
                
            if cpuLim == None:
                limitTotalCPU = int(cpupodl * replicas)
                RiskCPUmic = int(limitTotalCPU - usoTotalMicCPU)
            else:
                limitTotalCPU = int(cpuLim * replicas)
                RiskCPUmic = int(limitTotalCPU - usoTotalMicCPU)
            
            #Calcular los totales del microservicio
            logger.info("Calculating microservice MEMORY totals")
    
            if availablereplicas == 0:
                usoTotalMic = 0
                usoMedioMicro = 0
                opMemMicc = 0
                riskMemMicc = 0
                requestTotal = 0
                limitTotal = 0
            else:
                if "we cannot extract information" in podNameList:
                    usoTotalMic = 0
                    usoMedioMicro = 0
                    requestTotal = 0
                    limitTotal = 0
                    opMemMicc = 0
                    riskMemMicc = 0
                else:
                    usoTotalMic = usoTotal[3]
                    if usoTotalMic == 0:
                        usoTotalMic = 0
                        usoMedioMicro = 0
                        opMemMicc = 0
                        riskMemMicc = 0
                        requestTotal = 0
                        limitTotal = 0
                    else:
                        usoMedioMicro = int(usoTotalMic / replicas)
                    if memReqformat == None:
                        requestTotal = int(memPodr) * int(replicas)
                        opMemMicc = int(requestTotal - usoTotalMic)
                    else:
                        requestTotal = int(memReqformat * replicas)
                        opMemMicc = int(requestTotal - usoTotalMic)
                        
                    if memLimformat == None:
                        limitTotal = int(memPodl * replicas)
                        riskMemMicc = int(limitTotal - usoTotalMic)
                    else:
                        limitTotal = int(memLimformat * replicas)
                        riskMemMicc = int(limitTotal - usoTotalMic)

            mc = {
                "microservice": microservice,
                "blockProduction": blocProd,
                "replicasMicroservice": replicas,
                "cpuRequestMicroservice": cpuPoReq,
                "cpuLimitMicroservice": cpuPoLim,
                "totalUseMicroserviceCPU": usoTotalMicCPU,
                "AverageUseMicroserviceCPU": usoMedioCPU,
                "totalRequestMicroserviceCPU": requestTotalCPU,
                "totalLimitMicroserviceCPU": limitTotalCPU,
                "totalOptimizationCPUMicroservice": OpCPUmic,
                "totalRiskCPUMicroservice": RiskCPUmic,
                "memoryRequestMicroservice": memPodReqformat,
                "memoryLimitMicroservice": memPodLimformat,
                "totalUseMicroserviceMEM": usoTotalMic,
                "averageUseMicroserviceMEM": usoMedioMicro,
                "totalRequestMicroserviceMEM": requestTotal,
                "totalLimitMicroserviceMEM": limitTotal,
                "totalOptimizationMemoryMicroservice": opMemMicc,
                "totalRiskMemoryMicroservice": riskMemMicc,
                "hpa": hpa,
                "pods": podNameList
            }

            mcList.append(mc)
    logger.info("------ Data extraction completed ------")
    return mcList


async def guardarMongoWeek(datgen,environment,namespace,cluster,region,uid):
    dateList = []
    mm = datgen[0]
    totrep = datgen[1]

    datosgen = {
        "uid": uid,
        "environment": environment,
        "cluster": cluster,
        "region": region,
        "namespace": namespace,
        "totalReplicasNamespace": totrep,
        "date": mm
    }

    #Inserccion Mongo
    mg.change_collection(os.getenv("COLLECTION_WEEK_DEV"))
    querydbresultsmemory = mg.find({f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" })
    findnamespacememory = [x for x in querydbresultsmemory]
    if len(findnamespacememory) == 0:                                
        mg.add_data(data=datosgen)
    else:

        dateList = findnamespacememory[0]["date"]
        nameday = mm[0]["nameday"]

        for n in dateList:
            if n["nameday"] == nameday:
                cont = 0
                n["totalUseNamespaceCPU"] = mm[0]["totalUseNamespaceCPU"]
                n["totalRequestNamespaceCPU"] = mm[0]["totalRequestNamespaceCPU"]
                n["totalAverageNamespaceCPU"] = mm[0]["totalAverageNamespaceCPU"]
                n["totalLimitNamespaceCPU"] = mm[0]["totalLimitNamespaceCPU"]
                n["totalOptimizationCPUNamespace"] = mm[0]["totalOptimizationCPUNamespace"]
                n["totalRiskCPUNamespace"] = mm[0]["totalRiskCPUNamespace"]
                n["totalUseNamespaceMEM"] = mm[0]["totalUseNamespaceMEM"]
                n["totalAverageNamespaceMEM"] = mm[0]["totalAverageNamespaceMEM"]
                n["totalRequestNamespaceMEM"] = mm[0]["totalRequestNamespaceMEM"]
                n["totalLimitNamespaceMEM"] = mm[0]["totalLimitNamespaceMEM"]
                n["totalOptimizationMemoryNamespace"] = mm[0]["totalOptimizationMemoryNamespace"]
                n["totalRiskMemoryNamespace"] = mm[0]["totalRiskMemoryNamespace"]
                n["microservices"] = mm[0]["microservices"]
                break
            else:
                cont = 1

        if cont == 1:
            dateList.extend(mm)

        mg.update_one(
            { f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" },
            
            { '$set': {
                f"date" : dateList }
            }
            )
        mg.update_one(
            { f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" },
            
            { '$set': {
                f"totalReplicasNamespace" : totrep }
            }
            )


