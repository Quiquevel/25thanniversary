from shuttlelib.openshift.client import OpenshiftClient
from shuttlelib.utils.logger import logger
from fastapi import HTTPException
from shuttlelib.db.mongo import MongoClient
import os, aiohttp
import pytz
import datetime
import json
import re
import math
from datetime import datetime as dtt

mg = MongoClient()
entity = (os.getenv("ENTITY_ID")).lower()
client = OpenshiftClient(entity_id=entity)

URLMEXICO = os.environ.get('URLELASTICMEXICO')
APIKEYMEXICO = os.environ.get ('APIKEYMEXICO')
URLCANTABRIA = os.environ.get('URLELASTICCANTABRIA')
APIKEYCANTABRIA = os.environ.get ('APIKEYCANTABRIA')
URLCHILE = os.environ.get('URLELASTICCHILE')
APIKEYCHILE = os.environ.get ('APIKEYCHILE')
URLBOADILLA = os.environ.get('URLELASTICBOADILLA')
APIKEYBOADILLA = os.environ.get ('APIKEYBOADILLA')
URLAZURE = os.environ.get("URLELASTICAZURE")
APIKEYAZURE = os.environ.get ('APIKEYAZURE')
URLBOADILLADEVPRE = os.environ.get('URLELASTICBOADILLADEVPRE')
APIKEYBOADILLADEVPRE = os.environ.get ('APIKEYBOADILLADEVPRE')
URLCANTABRIADEVPRE = os.environ.get('URLELASTICCANTABRIADEVPRE')
APIKEYCANTABRIADEVPRE = os.environ.get ('APIKEYCANTABRIADEVPRE')
URLAZUREDEVPRE = os.environ.get("URLELASTICAZUREDEVPRE")
APIKEYAZUREDEVPRE = os.environ.get ('APIKEYAZUREDEVPRE')

ELASTIC_REPLACE_CLUSTER ='$OPENSHIFT_CLUSTER'
ELASTIC_REPLACE_NAMESPACE ='$OPENSHIFT_NAMESPACE'


async def cleaning_data(funtionality,object=None,identificador=None):
    environment = os.getenv("ENVIRONMENT")
    if funtionality == "recomender":
        mg.change_collection(os.getenv("COLLECTION_RECOMENDER"))
    elif funtionality == "lastpeak":
        if object == "namespace":
            if identificador == "online":
                mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_ONLINE"))
            else:
                mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK"))
        else:
            if identificador == "online":
                mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_ONLINE"))
            else:
                mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE"))
    else:
        if identificador == "online":
            mg.change_collection(os.getenv("COLLECTION_SRE_TREND_ONLINE"))
        else:
            mg.change_collection(os.getenv("COLLECTION_SRE_TREND"))
        
    listDelete = []

    datos = mg.read_data()
    if identificador == "online":
        mg.change_collection(os.getenv("COLLECTION_WEEK"))
    else:
        mg.change_collection(os.getenv("COLLECTION"))
    totalreg = len(datos)
    registro = 0
    for datRec in datos:
        registro = registro + 1
        logger.info(f"Register {registro} of {totalreg}")
        documents = list(mg.find({f"cluster": datRec["cluster"]}))

        if documents:
            document = list(mg.find({f"cluster": datRec["cluster"], f"namespace": datRec["namespace"]}))
            if document:
                microservices = datRec["microservices"]
                for mic in microservices:
                    micro = mic["microservice"]
                    microg = micro + "-g"
                    microb = micro + "-b"
                    microgreen = micro + "-green"
                    microblue = micro + "-blue"
                    docu = list(mg.find({f"cluster": datRec["cluster"], f"namespace": datRec["namespace"], f"date.microservices.microservice": micro}))
                    docug = list(mg.find({f"cluster": datRec["cluster"], f"namespace": datRec["namespace"], f"date.microservices.microservice": microg}))
                    docub = list(mg.find({f"cluster": datRec["cluster"], f"namespace": datRec["namespace"], f"date.microservices.microservice": microb}))
                    docugreen = list(mg.find({f"cluster": datRec["cluster"], f"namespace": datRec["namespace"], f"date.microservices.microservice": microgreen}))
                    docublue = list(mg.find({f"cluster": datRec["cluster"], f"namespace": datRec["namespace"], f"date.microservices.microservice": microblue}))
                    if docu or docug or docub or docugreen or docublue:
                        pass
                    else:
                        logger.info(f"Microservice {micro} not found in cluster {datRec['cluster']} and namespace {datRec['namespace']}")
                        clustlist, clusterlistcomplete = await get_clusters()
                        reg = next((diccionario['region'] for diccionario in clustlist if datRec['cluster'] in diccionario.values()), None)
                        for rg in reg:
                            pods= await client.get_resource(functional_environment=environment,cluster=datRec['cluster'],resource="pods",namespace=datRec['namespace'],region=rg)
                            if len(pods[rg]["items"]) == 0:
                                logger.info(f"Microservice {datRec['microservice']} of namespace {datRec['namespace']} not pods in Openshift in region {rg} of cluster {datRec['cluster']}")
                                dictdelete = {
                                    "cluster": datRec["cluster"],
                                    "namespace": datRec["namespace"],
                                    "region": rg,
                                    "microservice": micro
                                }
                                listDelete.append(dictdelete)
                            else:
                                exitPod = False
                                for pod in pods[rg]["items"]:
                                    if pod["spec"]["containers"][0]["name"] == micro:
                                        logger.info(f"Pods found in Microservice {micro} - cluster {datRec['cluster']} - namespace {datRec['namespace']}")
                                        exitPod = True
                                    else:
                                        exitPod = False

                                if exitPod == False:
                                    logger.info(f"Pods not found in Microservice {micro} - cluster {datRec['cluster']} - namespace {datRec['namespace']}")
                                    dictdelete = {
                                        "cluster": datRec["cluster"],
                                        "namespace": datRec["namespace"],
                                        "region": rg,
                                        "microservice": micro
                                    }
                                    listDelete.append(dictdelete)
                        
            else:
                logger.info(f"Namespace {datRec['namespace']} not found for cluster {datRec['cluster']}")
                if funtionality == "recomender":
                    dictdelete = {
                        "cluster": datRec["cluster"],
                        "namespace": datRec["namespace"],
                        "region": None,
                        "microservice": None
                    }
                    listDelete.append(dictdelete)
                else:
                    dictdelete = {
                        "cluster": datRec["cluster"],
                        "namespace": datRec["namespace"],
                        "region": datRec["region"],
                        "microservice": None
                    }
                    listDelete.append(dictdelete)
        else:
            logger.info(f"Document not found for cluster {datRec['cluster']}")
            if funtionality == "recomender":
                dictdelete = {
                    "cluster": datRec["cluster"],
                    "namespace": datRec["namespace"],
                    "region": None,
                    "microservice": None
                }
                listDelete.append(dictdelete)
            else:
                dictdelete = {
                    "cluster": datRec["cluster"],
                    "namespace": datRec["namespace"],   
                    "region": datRec["region"],
                    "microservice": None
                }
                listDelete.append(dictdelete)

    
    if funtionality == "recomender":
        mg.change_collection(os.getenv("COLLECTION_RECOMENDER"))
    elif funtionality == "lastpeak":
        if object == "namespace":
            if identificador == "online":
                mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_ONLINE"))
            else:
                mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK"))
        else:
            if identificador == "online":
                mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_ONLINE"))
            else:
                mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE"))
    else:
        if identificador == "online":
            mg.change_collection(os.getenv("COLLECTION_SRE_TREND_ONLINE"))
        else:
            mg.change_collection(os.getenv("COLLECTION_SRE_TREND"))
    
    for doc in listDelete:
        logger.info(f"Deleting document {doc['cluster']} - {doc['namespace']}")
        try:
            if doc['microservice'] == None:
                mg.delete_one({f"cluster": doc['cluster'], f"namespace": doc['namespace']})
            else:
                mg.delete_one({f"cluster": doc['cluster'], f"namespace": doc['namespace'], f"microservices.microservice": doc['microservice']})
        except Exception as e:
            logger.error(f"Error deleting document {doc}: {e}")
            raise HTTPException(status_code=500, detail=f"Error deleting document {doc}: {e}")
        
    return listDelete


async def parse_cpu(valor):
    if valor.endswith('n'):
        return int(valor[:-1]) / 1_000_000
    elif valor.endswith('u'):
        return int(valor[:-1]) / 1_000
    elif valor.endswith('m'):
        return int(valor[:-1])
    else:
        return int(valor) * 1000
    

async def parse_memoria(valor):
    """
    Convierte un valor de memoria con unidad (por ejemplo, '2048Ki', '2Gi', '512Mi') a MiB.
    Si no tiene unidad, se asume que está en KiB.
    """
    if isinstance(valor, (int, float)):
        # Si ya es numérico, se asume KiB
        return round(float(valor) / 1024, 2)
    valor = str(valor).strip()
    if valor.endswith("Ki"):
        return round(float(valor[:-2]) / 1024, 2)
    elif valor.endswith("Mi"):
        return round(float(valor[:-2]), 2)
    elif valor.endswith("Gi"):
        return round(float(valor[:-2]) * 1024, 2)
    elif valor.endswith("Ti"):
        return round(float(valor[:-2]) * 1024 * 1024, 2)
    elif valor.endswith("Pi"):
        return round(float(valor[:-2]) * 1024 * 1024 * 1024, 2)
    else:
        # Si no tiene unidad, se asume KiB
        return round(float(valor) / 1024, 2)


async def metrics_AKS():
    weekyear = {}
    dayweek = []
    night = []
    morning = []
    afternoon = []
    namespaces = await info_AKS(optionparameter='namespaces')

    for namespace in namespaces:
        metrics = await info_AKS(optionparameter='metrics_k8s', namespace=namespace)

        if len(metrics["items"]) == 0:
            continue
        else:
            for metric in metrics["items"]:
                number_accumulations = 0
                names_pod = metric["metadata"]["name"]
                partes = names_pod.split('-')
                # Busca desde el final el primer grupo de 4 o más caracteres alfanuméricos
                for i in range(len(partes)-1, 0, -1):
                    if len(partes[i]) >= 4 and partes[i].isalnum():
                        continue
                    else:
                        name_microservice = '-'.join(partes[:i])
                if "node-agent" in names_pod or "innd1weuaksbckendcrit002" in names_pod:
                    name_microservice = '-'.join(partes[:-1]) if len(partes) > 1 else names_pod
                else:
                    name_microservice = '-'.join(partes[:-2]) if len(partes) > 2 else names_pod

                name_namespace = metric["metadata"]["namespace"]
                hour_metric = metric["metadata"]["creationTimestamp"]

                # Convierte a objeto datetime (soporta formato ISO con Z)
                dt = dtt.fromisoformat(hour_metric.replace("Z", "+00:00"))
                hora = dt.hour
                minuto = dt.minute

                if 0 <= hora < 7:
                    tag = "night"
                elif 7 <= hora < 15 or (hora == 15 and minuto == 0):
                    tag = "morning"
                else:
                    tag = "afternoon"

                logger.info(f"Namespace: {name_namespace} - Microservice: {name_microservice} - Pod: {names_pod}")

                use_cpu = metric["containers"][0]["usage"]["cpu"]
                use_cpu_format = math.ceil(await parse_cpu(use_cpu))

                use_memory = metric["containers"][0]["usage"]["memory"]
                use_memory_format = await parse_memoria(use_memory)

                year = datetime.date.today().year

                dias_semana = {
                    0: "Lunes",
                    1: "Martes",
                    2: "Miércoles",
                    3: "Jueves",
                    4: "Viernes",
                    5: "Sábado",
                    6: "Domingo"
                }

                day = dias_semana[datetime.date.today().weekday()]

                weekYear = datetime.date.today().isocalendar()[1]

                # Lunes de la semana
                inicio = datetime.date.fromisocalendar(year, weekYear, 1)
                # Domingo de la semana
                fin = datetime.date.fromisocalendar(year, weekYear, 7)

                fecha_inicio = inicio.strftime('%Y-%m-%d')
                fecha_fin = fin.strftime('%Y-%m-%d')


                mg.change_collection(os.getenv("COLLECTION_METRICS_AKS"))
                querydbresultsmemory = mg.find({f"week {weekYear}.dayWeek.dayWeek": day, f"week {weekYear}.dayWeek.{tag}.namespace": name_namespace, f"week {weekYear}.dayWeek.{tag}.microservice": name_microservice,f"week {weekYear}.dayWeek.{tag}.pods.pod": names_pod })
                findnamespacememory = [x for x in querydbresultsmemory]
                if len(findnamespacememory) == 0:                                
                    use_cpu_milicores_accumulated = use_cpu_format
                    use_memory_MiB_accumulated = use_memory_format
                    use_cpu_milicores_peak = use_cpu_format
                    use_memory_MiB_peak = use_memory_format
                    number_accumulations = number_accumulations + 1
                    use_cpu_milicores_average = int(use_cpu_milicores_accumulated / number_accumulations)
                    use_memory_MiB_average = round(float(use_memory_MiB_accumulated / number_accumulations),2)
                else:
                    pods_mongo = findnamespacememory[0][f"week {weekYear}"]["dayWeek"][0][tag][0]["pods"]
                    for pods in pods_mongo:
                        if pods["pod"] == names_pod:
                            number_accumulations = pods["number_accumulations"]
                            use_cpu_milicores_accumulated = pods["used_cpu_milicores_accumulated"]
                            use_memory_MiB_accumulated = pods["used_memory_MiB_accumulated"]
                            use_cpu_milicores_peak = pods["used_cpu_milicores_peak"]
                            use_memory_MiB_peak = pods["used_memory_MiB_peak"]
                            break

                    number_accumulations = number_accumulations + 1
                    use_cpu_milicores_accumulated = use_cpu_milicores_accumulated + use_cpu_format
                    use_memory_MiB_accumulated = use_memory_MiB_accumulated + use_memory_format

                    use_cpu_milicores_average = int(use_cpu_milicores_accumulated / number_accumulations)
                    use_memory_MiB_average = round(float(use_memory_MiB_accumulated / number_accumulations),2)

                    if use_cpu_format > use_cpu_milicores_peak:
                        use_cpu_milicores_peak = use_cpu_format
                    

                    if use_memory_format > use_memory_MiB_peak:
                        use_memory_MiB_peak = use_memory_format


                metrics_pod_dict = {
                    "pod": names_pod,
                    "date": hour_metric,
                    "used_cpu_milicores_online": use_cpu_format,
                    "used_memory_MiB_online": use_memory_format,
                    "number_accumulations": number_accumulations,
                    "used_cpu_milicores_accumulated": use_cpu_milicores_accumulated,
                    "used_memory_MiB_accumulated": use_memory_MiB_accumulated,
                    "used_cpu_milicores_peak": use_cpu_milicores_peak,
                    "used_memory_MiB_peak": use_memory_MiB_peak,
                    "use_cpu_milicores_average": use_cpu_milicores_average,
                    "use_memory_MiB_average": use_memory_MiB_average
                }
                metrics_pod_list = []
                metrics_pod_list.append(metrics_pod_dict)

                metrics_aks_dict = [{
                    "cluster": "AKS",
                    "namespace": name_namespace,
                    "microservice": name_microservice,
                    "pods": metrics_pod_list,
                    }]       

                dayweekList = [
                    {
                        "dayWeek": day,
                        "date": datetime.date.today().strftime('%Y-%m-%d'),
                        f"{tag}": metrics_aks_dict
                    }  
                ]                 
                
                weekyear = {
                        "weekYear": weekYear,
                        "date": fecha_inicio + " - " + fecha_fin,
                        "dayWeek": dayweekList
                    }
            
                weekyearDict = {
                    f"week {weekYear}": weekyear
                }                          

                mg.change_collection(os.getenv("COLLECTION_METRICS_AKS"))
                querydbresultsmemory = mg.find({f"weekYear.weekYear": weekYear,f"week {weekYear}.dayWeek.{tag}.namespace": name_namespace, f"week {weekYear}.dayWeek.{tag}.microservice":name_microservice })
                findnamespacememory = [x for x in querydbresultsmemory]
                if len(findnamespacememory) == 0:
                    '''
                    # Clasifica por franja horaria
                    if 0 <= hora < 7:
                        mg.add_data(data=nightDict)
                    elif 7 <= hora < 15 or (hora == 15 and minuto == 0):
                        mg.add_data(data=morningDict)
                    else:                               
                        mg.add_data(data=afternoonDict)
                    '''
                    mg.add_data(data=weekyear)
                else:
                    querydbresultsmemory = mg.find({f"week {weekYear}.dayWeek.dayWeek": day,f"week {weekYear}.dayWeek.{tag}.namespace": name_namespace, f"week {weekYear}.dayWeek.{tag}.microservice": name_microservice,f"week {weekYear}.dayWeek.{tag}.pods.pod": names_pod })
                    findnamespacememory = [x for x in querydbresultsmemory]
                    if len(findnamespacememory) == 0:
                        mg._collection.update_one(
                            {
                                f"week {weekYear}.dayWeek.dayWeek": day,
                                f"week {weekYear}.dayWeek.{tag}.namespace": name_namespace,
                                f"week {weekYear}.dayWeek.{tag}.microservice": name_microservice
                            },
                            {
                                "$push": {
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods": metrics_pod_dict
                                }
                            },
                            array_filters=[
                                {"dw.dayWeek": day},
                                {"ts.namespace": name_namespace, "ts.microservice": name_microservice}
                            ]
                        )
                    else:
                        mg._collection.update_one(
                            {
                                f"week {weekYear}.dayWeek.dayWeek": day,
                                f"week {weekYear}.dayWeek.{tag}.namespace": name_namespace,
                                f"week {weekYear}.dayWeek.{tag}.microservice": name_microservice,
                                f"week {weekYear}.dayWeek.{tag}.pods.pod": names_pod
                            },
                            {
                                "$set": {
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].date": hour_metric,
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].used_cpu_milicores_online": use_cpu_format,
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].used_memory_MiB_online": use_memory_format,
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].number_accumulations": number_accumulations,
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].used_cpu_milicores_accumulated": use_cpu_milicores_accumulated,
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].used_memory_MiB_accumulated": use_memory_MiB_accumulated,
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].used_cpu_milicores_peak": use_cpu_milicores_peak,
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].used_memory_MiB_peak": use_memory_MiB_peak,
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].use_cpu_milicores_average": use_cpu_milicores_average,
                                    f"week {weekYear}.dayWeek.$[dw].{tag}.$[ts].pods.$[p].use_memory_MiB_average": use_memory_MiB_average
                                }
                            },
                            array_filters=[
                                {"dw.dayWeek": day},
                                {"ts.namespace": name_namespace, "ts.microservice": name_microservice},
                                {"p.pod": names_pod}
                            ]
                        )
                    


async def info_AKS(optionparameter,namespace=None,resource=None):
    urlapi = os.getenv("API_AKS_URL") #set api url where the information will be extracted
    path = os.getenv("API_AKS_PATH") #set api path
    option = f'/{optionparameter}'

    body = None

    match optionparameter:
        case 'namespaces':
            body = {
            }
        case 'resources':
            body = {
                'resource': resource,
                'namespace': namespace
            }
        case 'metrics_k8s':
            body = {
                'namespace': namespace
            }

    async with aiohttp.ClientSession() as session:
        async with session.post(urlapi+path+option, json=body, ssl=False) as resp:
            data = await resp.text()
            return json.loads(data)
            
                    

async def get_index_elastic(identificador, locator):
    """
    Returns the Elasticsearch index path based on the given identificador and locator.

    Parameters:
    - identificador (str): online or week type of search.
    - locator (str): resources or event.

    Returns:
    - str: The Elasticsearch index path.

    """
    if locator == 'event':
        return "/gpw/_search"
    else:
        if identificador == 'online':
            return "/capacity/_async_search"
        else:
            return "/archive-capacity/_async_search"


async def extraer_cluster(url):
    # Busca el patrón entre 'api.' y '.paas'
    match = re.search(r'api\.([^.]+(?:\.[^.]+){3,4})\.paas', url)
    if match:
        nombre = match.group(1)
        # Si termina en '.azure', lo quitamos
        if nombre.endswith('.azure'):
            nombre = nombre[:-6]
        return nombre
    return None


async def get_clusters():
    functional_environment=os.getenv("ENVIRONMENT")

    clusters = await client.get_resource(resource="clusters", functional_environment=functional_environment, cluster=None)
    cluster_list = []
    cluster_list_complete = []
    for cluster in clusters.keys():
        regions = list(clusters[cluster].keys())
        cluster_list.append({"name": cluster, "region": regions})

        for region in regions:
            url = list(clusters[cluster][region].values())[2]
            cluster_list_complete.append({"name": cluster, "region": region, "url": url})

    return cluster_list, cluster_list_complete


async def elastic_call(identificador, environment, locator, cluster, query, iden):
    """
    Makes an asynchronous call to an Elasticsearch cluster based on the provided parameters.

    Args:
        identificador (str): online or week type of search.
        environment (str): pro, pre or dev.
        locator (str): resources or event.
        cluster (str): The cluster for the call.
        namespace (str): The namespace for the call.
        query (str): The query to be sent to Elasticsearch.

    Returns:
        list: A list of Elasticsearch hits.

    Raises:
        Exception: If the Elasticsearch is not available.

    """
    logger.info("#### Connecting with elastic ####")
    retry_mapping = { "event": 5, "resources": 20 }
    id_elastic = await get_index_elastic(identificador=identificador, locator=locator)

    match environment:
        case "pro" if "pro.weu" in cluster or "pro.zu" in cluster:
            url = URLAZURE
            apikey = APIKEYAZURE
        case "pro" if "pro.cl" in cluster or "dmzb.cl" in cluster:
            url = URLCHILE
            apikey = APIKEYCHILE
        case "pro" if "pro.uk" in cluster or "dmzb.uk" in cluster:
            url = URLCANTABRIA
            apikey = APIKEYCANTABRIA
        case "pro" if "pro.cn" in cluster or "dmzb.cn" in cluster:
            url = URLCANTABRIA
            apikey = APIKEYCANTABRIA
        case "pro" if "pro.mx" in cluster or "dmzb.mx" in cluster:
            url = URLMEXICO
            apikey = APIKEYMEXICO
        case "pro" if "pro.bo" in cluster or "dmzb.bo" in cluster or "dmz2b.bo" in cluster:
            url = URLBOADILLA
            apikey = APIKEYBOADILLA
            ca = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + 'santander-ca-root.crt'
        case "pre" | "dev" if "wue" in cluster:
            url = URLAZUREDEVPRE
            apikey = APIKEYAZUREDEVPRE            
        case "dev" | "pre" if "dev.cn" in cluster or "pre.cn" in cluster:
            url = URLCANTABRIADEVPRE
            apikey = APIKEYCANTABRIADEVPRE
        case "dev" | "pre" if "dev.uk" in cluster or "pre.uk" in cluster:
            url = URLBOADILLADEVPRE
            apikey = APIKEYBOADILLADEVPRE
        case "dev" | "pre" if "dev.cl" in cluster or "pre.cl" in cluster:
            url = URLBOADILLADEVPRE
            apikey = APIKEYBOADILLADEVPRE
        case "dev" | "pre" if "dev.bo" in cluster or "pre.bo" in cluster:
            url = URLBOADILLADEVPRE
            apikey = APIKEYBOADILLADEVPRE
            ca = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + 'santander-ca-root.crt'      

    
    request_url = url + id_elastic
    headers = {'Authorization': "ApiKey "+str(apikey),'Accept': 'application/json','Content-type': 'application/json'}
    ps = []
    retry_count = 0
    while retry_count < retry_mapping[locator] and len(ps) == 0:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(request_url,ssl=False,headers=headers,data=query) as resp:
                    res = await resp.json()
                    if  locator == "event":
                        try:
                            ps= res['hits']['hits']
                        except:
                            ps = []
                    else:
                        if identificador == 'online':
                            if iden == None:
                                try:
                                    ps= res['response']['hits']['hits']
                                except:
                                    ps = []
                            else:
                                try:
                                    ps= res['response']['aggregations']['timeseries']['buckets'][1]["3bd772c0-5cc9-11ec-b347-453bc8c37d73"]["value"]
                                except:
                                    ps = []
                        else:
                            try:
                                ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                            except:
                                ps = []
        except aiohttp.ClientError as e:
            logger.error(f"Elastic not available: {e}")
            json_object = []
            return json_object
        retry_count += 1
    return ps


async def elastic_gpw(environment, clustertraduc, namespace, initialHour=None, finalHour=None, iden=None):
    """
    Retrieves GPW event from Elastic.

    Args:
        environment (str): The environment to retrieve the GPW event from, pro or dev.
        clustertraduc (str): The translated cluster name.
        namespace (str): The namespace to retrieve the GPW event from.

    Returns:
        ps: The result of the Elastic call.
    """
    logger.info("#### Get GPW event from elastic ####")

    if initialHour != None and finalHour!=None:
        fechas = []
        fechas.append(initialHour)
        fechas.append(finalHour)
    else:
        fechas = await timer(event=True)    

    fecha_inicio = fechas[0]
    #fecha_fin = fechas[1]+datetime.timedelta(hours=1)
    fecha_fin = datetime.datetime.strptime(fechas[1], '%Y-%m-%dT%H:%M:%S.%fZ')
    fecha_fin = str(fecha_fin)+'.000Z'
    fecha_fin = fecha_fin.replace(" ", "T")

    query = "pod-event-per-project - week"
    query_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + query + ".json"

    with open(query_file) as file:
        ES_QUERY = "".join(line.rstrip() for line in file)

    ES_QUERY = str(ES_QUERY)\
        .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
        .replace('$OPENSHIFT_NAMESPACE', namespace)\
        .replace('$FECHA_INICIO', fecha_inicio)\
        .replace('$FECHA_FIN', fecha_fin)

    ps = await elastic_call(identificador='week', environment=environment, locator='event', cluster=clustertraduc, query=ES_QUERY, iden=iden)
    return ps


async def elastic(identificador, environment, clustertraduc, namespace, iden=None):
    """
    Retrieves resources from Elastic.

    Args:
        identificador (str): online or week type of search.
        environment (str): The environment, pro or dev.
        clustertraduc (str): The cluster name.
        namespace (str): The namespace.

    Returns:
        ps: The result of the Elastic call.
    """
    logger.info("#### Get resources from elastic ####")

    if identificador == "online":
        if iden == "allocatable-cpu":
            query = "allocatable-cpu-cluster"
        elif iden == "allocatable-memory":
            query = "allocatable-memory-cluster"
        elif iden == "request-cpu-cluster":
            query = "request-cpu-cluster"
        elif iden == "request-memory-cluster":
            query = "request-memory-cluster"
        elif iden == "use-cpu-cluster":
            query = "use-cpu-cluster"
        elif iden == "use-memory-cluster":
            query = "use-memory-cluster"
        elif iden == "request-cpu-namespace":
            query = "request-cpu-namespace"
        elif iden == "request-memory-namespace":
            query = "request-memory-namespace"
        elif iden == "use-cpu-namespace":
            query = "use-cpu-namespace"
        elif iden == "use-memory-namespace":
            query = "use-memory-namespace"
        else:
            query = "cpu-and-memory-per-project - online"

        query_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + query + ".json"

        with open(query_file) as file:
            ES_QUERY = "".join(line.rstrip() for line in file)

        if iden == None:
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
                .replace('$OPENSHIFT_NAMESPACE', namespace)
        elif "cluster" in iden or "allocatable" in iden:
            fechas = await timer(namespace=namespace)

            fecha_inicio = fechas[0]
            fecha_fin = fechas[1]
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
                .replace('$FECHA_INICIO', fecha_inicio)\
                .replace('$FECHA_FIN', fecha_fin)
        elif "namespace" in iden:
            ES_QUERY = str(ES_QUERY)\
                .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
                .replace('$OPENSHIFT_NAMESPACE', namespace)\
                .replace('$FECHA_INICIO', fecha_inicio)\
                .replace('$FECHA_FIN', fecha_fin)

    else:
        fechas = await timer(namespace=namespace)

        fecha_inicio = fechas[0]
        fecha_fin = fechas[1]

        query = "cpu-and-memory-per-project - week"
        query_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + query + ".json"

        with open(query_file) as file:
            ES_QUERY = "".join(line.rstrip() for line in file)

        ES_QUERY = str(ES_QUERY)\
            .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
            .replace('$OPENSHIFT_NAMESPACE', namespace)\
            .replace('$FECHA_INICIO', fecha_inicio)\
            .replace('$FECHA_FIN', fecha_fin)
    
    ps = await elastic_call(identificador=identificador, environment=environment, locator='resources', cluster=clustertraduc, query=ES_QUERY,iden=iden)
    return ps


async def get_timezone_and_schedule():
    """
    Obtiene la zona horaria y el horario de servicio basado en el ENTITY_ID definido globalmente

    Returns:
        tuple: Una tupla con la zona horaria (str), hora inicial (int) y hora final (int).
    """
    entity = os.getenv("ENTITY_ID").lower()
    environment = os.getenv("ENVIRONMENT").lower()
    timezone = os.getenv("TZ")
    file = "service_schedule"
    config_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + file + "_" + environment + ".json"


    try:
        # Cargar el archivo JSON
        with open(config_file, 'r') as file:
            config_data = json.load(file)

        # Buscar la configuración para el ENTITY_ID
        if entity in config_data:
            initial_hour = config_data[entity].get("initial_hour", 0)
            final_hour = config_data[entity].get("final_hour", 23)
            exception = config_data[entity].get("exception", [])
            return timezone, initial_hour, final_hour, exception
        else:
            raise ValueError(f"ENTITY_ID '{entity}' no encontrado en el archivo de configuración.")

    except FileNotFoundError:
        raise FileNotFoundError(f"El archivo de configuración '{config_file}' no existe.")
    except json.JSONDecodeError:
        raise ValueError(f"El archivo de configuración '{config_file}' no es un JSON válido.")


async def date_time_global(date: datetime.date, timezone: str):
    """
    Asynchronously converts a given date and time to a UTC timestamp string.
    Args:
        date (datetime.date): The date to be converted.
    Returns:
        str: The UTC timestamp string in the format '%Y-%m-%dT%H:%M:%S.%fZ' if the time is valid.
    Raises:
        ValueError: If the date or time format is incorrect.
    """
    time_zone = pytz.timezone(timezone)
    date_format = '%Y-%m-%dT%H:%M:%S.%f'
    
    date_local = time_zone.localize(datetime.datetime.strptime(date, date_format))

    date_utc = date_local.astimezone(pytz.utc).strftime(date_format)[:-3] + 'Z'

    return date_utc


async def timer(initial_date: datetime.date = None, initial_time: int = None, final_date: datetime.date = None, final_time: int = None, event : bool = False, namespace=None):
    """
    Asynchronous function to calculate and return the UTC timestamps for a given time range.
    Args:
        initial_date (datetime.date, optional): The starting date. Defaults to today's date if not provided.
        initial_time (int, optional): The starting hour (0-23). Defaults to a predefined schedule if not provided.
        final_date (datetime.date, optional): The ending date. Defaults to today's date if not provided.
        final_time (int, optional): The ending hour (0-23). Defaults to a predefined schedule if not provided.
        event (bool, optional): If True, extends the final time by one hour, adjusting the date if necessary. Defaults to False.
    Returns:
        tuple: A tuple containing two datetime objects in UTC:
            - initial_date_utc: The UTC timestamp for the start of the range.
            - final_date_utc: The UTC timestamp for the end of the range.
    Raises:
        ValueError: If `initial_time` or `final_time` is not within the valid range (0-23).
    Notes:
        - The function retrieves the timezone and default schedule using `get_timezone_and_schedule`.
        - The `date_time_global` function is used to convert local timestamps to UTC.
    """


    timezone, ini_time, fin_time, exception = await get_timezone_and_schedule()

    if exception != []:
        for ex in exception:
            namesp = ex["namespace"].split(",")
            for n in namesp:
                if namespace == n:
                    ini_time = ex["ini_hour"]
                    fin_time = ex["fin_hour"]
                    ini_date = initial_date if initial_date else datetime.date.today()
                    fin_date = final_date if final_date else datetime.date.today()
                    break
            else:
                ini_date = initial_date if initial_date else datetime.date.today()
                fin_date = final_date if final_date else datetime.date.today()
                ini_time = initial_time if initial_time else ini_time
                fin_time = final_time if final_time else fin_time
    else:
        ini_date = initial_date if initial_date else datetime.date.today()
        fin_date = final_date if final_date else datetime.date.today()
        ini_time = initial_time if initial_time else ini_time
        fin_time = final_time if final_time else fin_time

    if ini_time <= 0 or ini_time > 23:
        logger.error("Initial time is not valid")
        return None

    if fin_time <= 0 or fin_time > 23:
        logger.error("Final time is not valid")
        return None

    if event == True:
        fin_time = fin_time + 1
        if fin_time > 23:
            fin_time = 0
            fin_date = fin_date + datetime.timedelta(days=1)

    initial_date_str = ini_date.strftime(f'%Y-%m-%dT{ini_time}:00:00.000')
    final_date_str = fin_date.strftime(f'%Y-%m-%dT{fin_time}:00:00.000')

    initial_date_utc = await date_time_global(initial_date_str, timezone)   
    final_date_utc = await date_time_global(final_date_str, timezone)

    return initial_date_utc, final_date_utc


async def dayweek():
    """
    Returns the name of the current day of the week.

    Returns:
        str: The name of the current day of the week (e.g., "Monday", "Tuesday", etc.).
            Returns None if the current day cannot be determined.
    """
    dia = datetime.date.today().weekday()

    match dia:
        case 0:
            diasemana = "Monday"
        case 1:
            diasemana = "Tuesday"
        case 2:
            diasemana = "Wednesday"
        case 3:
            diasemana = "Thursday"
        case 4:
            diasemana = "Friday"
        case 5:
            diasemana = "Saturday"
        case 6:
            diasemana = "Sunday"
        case None:
            diasemana = None

    return diasemana


#calcularTotalNamespace(mcList,identificador) -> renombrar a calcular_total_namespace(mc_list,identificador):
async def calcularTotalNamespace(mc_list,identificador):
    """
    Calculate the total CPU and memory usage, requests, and limits for a given namespace.
    Args:
        mc_list (list): List of microservices with their respective CPU and memory usage, requests, and limits.
        identificador (str): Identifier to determine the type of calculation ("online" or other).
    Returns:
        tuple: If identificador is "online", returns a dictionary with the calculated totals and the list of microservices.
                Otherwise, returns a list containing a dictionary with the calculated totals, the total number of replicas, and the list of microservices.
    The returned dictionary contains the following keys:
        - "dateHour" or "date": The current date and time or just the date.
        - "nameday": The day of the week.
        - "totalUseNamespaceCPU": Total CPU usage in cores.
        - "averageUseNamespaceCPU": Average CPU usage in cores.
        - "totalRequestNamespaceCPU": Total CPU requests in cores.
        - "totalLimitNamespaceCPU": Total CPU limits in cores.
        - "totalOptimizationCPUNamespace": Total CPU optimization potential in cores.
        - "totalRiskCPUNamespace": Total CPU risk in cores.
        - "totalUseNamespaceMEM": Total memory usage in GiB.
        - "averageUseNamespaceMEM": Average memory usage in GiB.
        - "totalRequestNamespaceMEM": Total memory requests in GiB.
        - "totalLimitNamespaceMEM": Total memory limits in GiB.
        - "totalOptimizationMemoryNamespace": Total memory optimization potential in GiB.
        - "totalRiskMemoryNamespace": Total memory risk in GiB.
        - "microservices": The list of microservices.
    """
    logger.info("Calculating namespace CPU totals")
    usogen_cpu= 0
    average_cpu = 0
    op_cpu_gen = 0
    risk_cpu_gen = 0
    totreplicas = 0
    reqgen_cpu = 0
    limgen_cpu = 0
    date = []
    spec = {}
    dia = await dayweek()
    if len(mc_list) == 0:
        logger.info("Microservice without pods")
        return date, totreplicas, mc_list
    else:
        for micro in mc_list:
            totreplicas += micro["replicasMicroservice"]
            usogen_cpu += micro["totalUseMicroserviceCPU"]
            average_cpu += micro["AverageUseMicroserviceCPU"]
            reqgen_cpu += micro["totalRequestMicroserviceCPU"]
            limgen_cpu += micro["totalLimitMicroserviceCPU"]

        op_cpu_gen = int(reqgen_cpu - usogen_cpu)
        risk_cpu_gen = int(limgen_cpu - usogen_cpu)

        #Pasar de milicores a cores
        usogen_cpu_nam = round(usogen_cpu/1000,3)
        average_cpu_nam = round(average_cpu/1000,3)
        op_cpu_gen_nam = round(op_cpu_gen/1000,3)
        risk_cpu_gen_nam = round(risk_cpu_gen/1000,3)
        reqgen_cpu_nam = round(reqgen_cpu/1000,3)
        limgen_cpu_nam = round(limgen_cpu/1000,3)

        logger.info("Calculating namespace MEMORY totals")
        usogen_mem = 0 
        avegen_mem = 0
        reqgen = 0
        limgen = 0

        for micro in mc_list:
            # No es necesario verificar si el valor es 0, ya que int(0) devuelve 0 aunque no sea una cadena
            usogen_mem += int(micro["totalUseMicroserviceMEM"])
            avegen_mem += int(micro["averageUseMicroserviceMEM"])
            reqgen += int(micro["totalRequestMicroserviceMEM"])
            limgen += int(micro["totalLimitMicroserviceMEM"])

        op_mem_gen_nam = int(reqgen - usogen_mem)
        risk_mem_gen_nam = int(limgen - usogen_mem)

        #Convertir de MiB a GiB
        usogen_mem_nam = round(usogen_mem/1024,3)
        avegen_mem_nam = round(avegen_mem/1024,3)
        op_mem_gen_mem_nam = round(op_mem_gen_nam/1024,3)
        risk_mem_gen_mem_nam =  round(risk_mem_gen_nam/1024,3)
        req_gen_mem_nam = round(reqgen/1024,3)
        lim_gen_mem_nam = round(limgen/1024,3)


        if identificador == "online":
            fecha_h = datetime.datetime.now(pytz.timezone(os.getenv("TZ")))
            fecha_hora = fecha_h.strftime('%Y-%m-%d  %H:%M:%S')
            spec = {
                "dateHour": fecha_hora,
                "totalUseNamespaceCPU": usogen_cpu_nam,
                "averageUseNamespaceCPU": average_cpu_nam,
                "totalRequestNamespaceCPU": reqgen_cpu_nam,
                "totalLimitNamespaceCPU": limgen_cpu_nam,
                "totalOptimizationCPUNamespace": op_cpu_gen_nam,
                "totalRiskCPUNamespace": risk_cpu_gen_nam,
                "totalUseNamespaceMEM": usogen_mem_nam,
                "averageUseNamespaceMEM": avegen_mem_nam,
                "totalRequestNamespaceMEM": req_gen_mem_nam,
                "totalLimitNamespaceMEM": lim_gen_mem_nam,
                "totalOptimizationMemoryNamespace": op_mem_gen_mem_nam,
                "totalRiskMemoryNamespace": risk_mem_gen_mem_nam,
                "microservices": mc_list
            }
            return spec, totreplicas, mc_list
        else:
            fecha_day = datetime.datetime.now(pytz.timezone(os.getenv("TZ")))
            fecha = fecha_day.strftime('%Y-%m-%d')
            spec = {
                "nameday": dia,
                "date": fecha,
                "totalUseNamespaceCPU": usogen_cpu_nam,
                "totalAverageNamespaceCPU": average_cpu_nam,
                "totalRequestNamespaceCPU": reqgen_cpu_nam,
                "totalLimitNamespaceCPU": limgen_cpu_nam,
                "totalOptimizationCPUNamespace": op_cpu_gen_nam,
                "totalRiskCPUNamespace": risk_cpu_gen_nam,
                "totalUseNamespaceMEM": usogen_mem_nam,
                "totalAverageNamespaceMEM":avegen_mem_nam,
                "totalRequestNamespaceMEM": req_gen_mem_nam,
                "totalLimitNamespaceMEM": lim_gen_mem_nam,
                "totalOptimizationMemoryNamespace": op_mem_gen_mem_nam,
                "totalRiskMemoryNamespace": risk_mem_gen_mem_nam,
                "microservices": mc_list
            }
            date.append(spec)
            return date, totreplicas, mc_list


async def blockproductive(mg, namespace, cluster, region, microservice):
    """
    Retrieves the production block value for a given microservice in a specific namespace, cluster, and region.

    Parameters:
    - mg: The database connection object.
    - namespace: The namespace of the microservice.
    - cluster: The cluster of the microservice.
    - region: The region of the microservice.
    - microservice: The name of the microservice.

    Returns:
    - The production block value for the specified microservice, or None if the microservice is not found.
    """
    querydbresultsmemory = mg.find({"namespace": namespace,"cluster": f"{cluster}", "region": f"{region}"})
    findnamespacememory = [x for x in querydbresultsmemory]
    if len(findnamespacememory) == 0:
        blockprod = None
    else:
        mic_list = findnamespacememory[0]["microservices"]
        for mc in mic_list:
            mic = mc["microservice"]
            if microservice == mic:
                blockprod = mc["productionBlock"]
                logger.info("Production block extraction completed")
                break
            else:
                blockprod = None

    return blockprod


async def data_validation(diccionario, *claves):
    """
    Validates the data in a dictionary based on a series of keys.

    Args:
        diccionario (dict): The dictionary to validate.
        *claves (str): Variable number of keys to traverse the dictionary.

    Returns:
        Any: The value corresponding to the last key in the series, or None if any key is not found or if a non-dictionary value is encountered.

    """
    valor = diccionario
    for clave in claves:
        if isinstance(valor, dict):
            valor = valor.get(clave, None)
        else:
            return None
    return valor


async def hpa_condition(condition_type, hpa_conditions):
    """
    Retrieves the status of a Horizontal Pod Autoscaler condition.

    Args:
        condition_type (str): The type of condition to retrieve.
        hpa_conditions (list): The list of conditions from the HPA.

    Returns:
        tuple: A tuple containing the status and message of the condition.

    If the condition is found in the list of HPA conditions, the function returns a tuple containing the status and message of the condition.
    If the condition is not found, the function returns (None, None).

    """
    for condition in hpa_conditions:
        if condition["type"] == condition_type:
            return condition["status"], condition["message"]
    return None, None


async def hpass(region, dc, hpa_data):
    """
    Extracts and processes Horizontal Pod Autoscaler (HPA) data for a given region and deployment configuration.
    Args:
        region (str): The region from which to extract HPA data.
        dc (dict): The deployment configuration containing metadata.
        hpa_data (dict): The HPA data containing items to be processed.
    Returns:
        dict or None: A dictionary containing processed HPA data if a matching HPA is found, otherwise None.
    The returned dictionary contains the following keys:
        - hpaName (str): The name of the HPA.
        - minReplicas (int): The minimum number of replicas.
        - maxReplicas (int): The maximum number of replicas.
        - minMaxReplicas (str): A string representation of the min and max replicas.
        - targetCPUUtilizationPercentage (int): The target CPU utilization percentage.
        - lastScaleTime (str): The last time the HPA was scaled.
        - currentReplicas (int): The current number of replicas.
        - desiredReplicas (int): The desired number of replicas.
        - currentCPUUsage (int): The current CPU utilization percentage.
        - scalingActive (bool): Whether scaling is currently active.
        - messageScalingActive (str): Message related to scaling activity.
        - ableToScale (bool): Whether the HPA is able to scale.
        - messageAbleToScale (str): Message related to the ability to scale.
    Logs:
        Logs an info message when HPA extraction is completed.
    """

    if len(hpa_data[region]["items"]) == 0:
        logger.info("HPA extraction completed")
        return None

    microser = dc["metadata"]["name"]
    for hp in hpa_data[region]["items"]:
        microhpa = hp["metadata"]["name"]
        microhpatarget = hp['spec']['scaleTargetRef']['name']
        hpa = None
        if microser == microhpa or microser == microhpatarget:
            current_cou_usage = await data_validation(hp,'status','currentCPUUtilizationPercentage')
            last_scale_time = await data_validation(hp,'status','lastScaleTime')
            current_replicas = await data_validation(hp,'status','currentReplicas')
            desired_replicas = await data_validation(hp,'status','desiredReplicas')
            min_replicas = await data_validation(hp,'spec','minReplicas')
            max_replicas = await data_validation(hp,'spec','maxReplicas')
            target_cpu_utilization_percentage = await data_validation(hp,'spec','targetCPUUtilizationPercentage')

            able_to_scale = None
            message_able_to_scale = None
            scaling_active = None
            message_scaling_active = None
            hpaconditions = json.loads(await data_validation(hp,'metadata','annotations','autoscaling.alpha.kubernetes.io/conditions'))

            scaling_active, message_scaling_active = await hpa_condition("ScalingActive", hpaconditions)
            able_to_scale, message_able_to_scale = await hpa_condition("AbleToScale", hpaconditions)
            
            min_max_replicas = str(min_replicas) + '-' + str(max_replicas)

            hpa = {
                "hpaName": microhpa,
                "minReplicas": min_replicas,
                "maxReplicas": max_replicas,
                "minMaxReplicas": min_max_replicas,
                "targetCPUUtilizationPercentage": target_cpu_utilization_percentage,
                "lastScaleTime": last_scale_time,
                "currentReplicas": current_replicas,
                "desiredReplicas": desired_replicas,
                "currentCPUUsage": current_cou_usage,
                "scalingActive": scaling_active,
                "messageScalingActive": message_scaling_active,
                "ableToScale": able_to_scale,
                "messageAbleToScale": message_able_to_scale
            }
            break

    logger.info("HPA extraction completed")
    return hpa


#dumpDataMongoWeekToWeelOld() -> renombrar a dump_data_mongo_week_to_week_old():
async def dumpDataMongoWeekToWeelOld():
    """
    Dump data from one MongoDB collection to another, week to week.

    This function reads data from a MongoDB collection specified by the environment variable "COLLECTION_WEEK",
    and dumps it into another MongoDB collection specified by the environment variable "COLLECTION".
    It first deletes all data from the target collection, then iterates over the data from the source collection.
    For each document, it checks if a document with the same namespace, cluster, and region exists in the target collection.
    If not, it adds the document to the target collection.
    Finally, if all documents are successfully dumped, it deletes all data from the source collection.

    Note: This function assumes that the necessary environment variables are properly set.

    Returns:
        None
    """
    mg.change_collection(os.getenv("COLLECTION"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_WEEK"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION"))
    for d in datos:
        cont = cont + 1
        namespace = d['namespace']
        cluster = d['cluster']
        region = d['region']  
        querydbresultsmemory = mg.find({"namespace": namespace, "cluster":f"{cluster}", "region":f"{region}" })
        findnamespacememory = [x for x in querydbresultsmemory]
        if len(findnamespacememory) == 0:                                
            mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")
    if numreg == cont:
        logger.info("Document dump ok")
        mg.change_collection(os.getenv("COLLECTION_WEEK"))
        mg.delete_all_data()
    else:
        logger.info(f"Something has gone wrong, document {cont}")


async def formatearcpu(cpu):
    """
    Formats the CPU value.

    Args:
        cpu (str): The CPU value to be formatted.

    Returns:
        int: The formatted CPU value.

    """
    if cpu == None:
        cpuformat = None
    elif "m" in cpu:
        cpuformat = int(cpu[:-1])
    else:
        cpuformat = int(cpu) * 1000
    return cpuformat


async def traductorcluster(environment, region, cluster):
    """
    Translates the given environment, region, and cluster into a final cluster name.

    Args:
        environment (str): The environment name.
        region (str): The region name.
        cluster (str): The cluster name.

    Returns:
        str: The final cluster name.

    Raises:
        KeyError: If the cluster name is not found in the cluster_mapping dictionary.
    """
    cluster_mapping = {
        "prodarwin": "san01darwin.san.",
        "dmzbdarwin": "san01darwin.san.dmzb.",
        "probks": "san01bks.san.",
        "dmzbbks": "san01bks.san.dmzb.",
        "confluent": "san01confluent.san.",
        "dmz2bmov": "san01mov.san.dmz2b.",
        "bks": "san01bks.san.",
        "dev": "san.",
        "azure": "ocp01.san.",
        "ocp05azure": "ocp05.san.",
        "ocpgnr.gsc.pro": "ocpgnr.gsc.",
        "gsc04.gsc.pro": "gsc04.gsc.",
        "sgt01.sgt.pro": "sgt01.sgt.",
        "ocppro01.gsc.pro": "ocppro01.gsc",
        "iag01.sgt.dev": "iag01.sgt.",
        "gpdev01.sgt.dev": "gpdev01.sgt.",
        "gpcert01.sgt.dev": "gpcert01.sgt.",
        "sgt01.sgt.dev": "sgt01.sgt."
    }

    final_cluster = None

    if "dmz" in cluster:
        final_cluster = cluster_mapping[cluster] + region
    else:
        final_cluster = cluster_mapping[cluster] + environment + "." + region 


    return final_cluster
    

async def totalusomicro(pod_dict):
    """
    Calculate the total usage of CPU and memory for microservices.

    Args:
        pod_dict (dict): A dictionary containing the usage information of microservices.

    Returns:
        tuple: A tuple containing the total CPU usage, optimization CPU usage, risk CPU usage,
               memory usage with cache, optimization memory usage, and risk memory usage.
    """
    cpu_usage = 0
    optimization_cpu_pod = 0
    risk_cpu_pod = 0
    memory_usage_cache = 0
    optimization_memory_pod = 0
    risk_memory_pod = 0
    if len(pod_dict) != 0:
        for t in pod_dict:
            for e in t["use"].items():
                match e[0]:
                    case "CPUUsage":
                        cpu_usage += int(e[1])
                    case "OptimizationCPUPod":
                        optimization_cpu_pod += int(e[1])
                    case "RiskCPUPod":
                        risk_cpu_pod += int(e[1])
                    case "MemoryUsage+Cache":
                        memory_usage_cache += float(e[1])
                    case "OptimizationMemoryPod":
                        optimization_memory_pod += float(e[1])
                    case "RiskMemoryPod":
                        risk_memory_pod += float(e[1])

    return cpu_usage, optimization_cpu_pod, risk_cpu_pod, memory_usage_cache, optimization_memory_pod, risk_memory_pod


async def totalusomicro_maxhpa(poddict,hpa):
    """
    Calculate the total usage metrics for a given number of pods.
    This asynchronous function processes a dictionary of pod usage data and calculates
    the total CPU usage, optimization CPU pod, risk CPU pod, memory usage cache,
    optimization memory pod, and risk memory pod for a specified number of pods.
    Args:
        poddict (list): A list of dictionaries where each dictionary contains usage metrics for a pod.
        hpa (int): The maximum number of pods to consider for the calculation.
    Returns:
        tuple: A tuple containing the following six elements:
            - cpu_usage (int): Total CPU usage.
            - optimization_cpu_pod (int): Total optimization CPU pod.
            - risk_cpu_pod (int): Total risk CPU pod.
            - memory_usage_cache (float): Total memory usage cache.
            - optimization_memory_pod (float): Total optimization memory pod.
            - risk_memory_pod (float): Total risk memory pod.
    """
    cpu_usage = 0
    optimization_cpu_pod = 0
    risk_cpu_pod = 0
    memory_usage_cache = 0
    optimization_memory_pod = 0
    risk_memory_pod = 0
    if len(poddict) == 0:
        return cpu_usage, optimization_cpu_pod, risk_cpu_pod, memory_usage_cache, optimization_memory_pod, risk_memory_pod
    else:
        poddict_ordenado = sorted(poddict, key=lambda x: str(x["lifeTimePod"]), reverse=True)
        contador = 0
        for t in poddict_ordenado:
            if contador >= hpa:
                break
            for e in t["use"].items():
                match e[0]:
                    case "CPUUsage":
                        cpu_usage += int(e[1])
                    case "OptimizationCPUPod":
                        optimization_cpu_pod += int(e[1])
                    case "RiskCPUPod":
                        risk_cpu_pod += int(e[1])
                    case "MemoryUsage+Cache":
                        memory_usage_cache += float(e[1])
                    case "OptimizationMemoryPod":
                        optimization_memory_pod += float(e[1])
                    case "RiskMemoryPod":
                        risk_memory_pod += float(e[1])
            contador += 1
            if contador >= hpa:
                break

    return cpu_usage, optimization_cpu_pod, risk_cpu_pod, memory_usage_cache, optimization_memory_pod, risk_memory_pod


async def formatearmemory(memory_now):
    """
    Converts a memory value with unit into a numeric value in bytes.

    Args:
        memory_now (str): The memory value with unit (e.g., '8GB', '512MB').

    Returns:
        float or int: The converted memory value in bytes.

    Raises:
        None

    Example:
        >>> formatearmemory('8GB')
        8589934592
        >>> formatearmemory('512MB')
        536870912
    """
    if memory_now != None:
        for i, char in enumerate(memory_now):
            if not char.isdigit():
                inicio = i
                break
        memory_unit = memory_now[inicio:].strip()
        match memory_unit:
            case "KiB":
                memory_now = float(memory_now[:-3])*2**10
            case "Ki":
                memory_now = int(memory_now[:-2])*2**10
            case "MiB":
                memory_now = float(memory_now[:-3])*2**20              
            case "Mi":
                memory_now = int(memory_now[:-2])*2**20
            case "GiB":
                memory_now = float(memory_now[:-3])*2**30
            case "Gi":
                memory_now = int(memory_now[:-2])*2**30
            case "TiB":
                memory_now = float(memory_now[:-3])*2**40 
            case "Ti":
                memory_now = int(memory_now[:-2])*2**40  
            case "PiB":
                memory_now = float(memory_now[:-3])*2**50
            case "Pi":
                memory_now = int(memory_now[:-2])*2**50   
            case "B" | "b":
                memory_now = float(memory_now[:-1])*1             
            case "K" | "k":
                memory_now = int(memory_now[:-1])*1000
            case "M" | "m":
                memory_now = int(memory_now[:-1])*1000*1000
            case "G" |  "g":
                memory_now = int(memory_now[:-1])*1000*1000*1000
            case "T" | "t":
                memory_now = int(memory_now[:-1])*1000*1000*1000*1000
            case _:
                memory_now = int(memory_now)
    return memory_now


async def control_errores(region, cluster, environment):
    """
    Check for invalid combinations of region, cluster, and environment.

    Args:
        region (str): The region of the cluster.
        cluster (str): The name of the cluster.
        environment (str): The environment (dev, pre, etc.).

    Raises:
        HTTPException: If an invalid combination of region, cluster, and environment is detected.

    """
    # Introducir un cluster que no exista en el entorno
    invalid_clusters_dev = ["prodarwin", "dmzbdarwin", "confluent", "proohe", "dmzbohe"]
    invalid_clusters_pre = ["prodarwin", "dmzbdarwin", "confluent", "proohe", "dmzbohe"]
    invalid_regions_azure = ["bo1", "bo2"]
    invalid_regions_ocp05azure = ["bo1", "bo2"]
    invalid_regions_dmzbazure = ["bo1", "bo2"]
    invalid_regions_prodarwin = ["weu1", "weu2"]
    invalid_regions_dmzbdarwin = ["weu1", "weu2"]
    invalid_regions_probks = ["weu1", "weu2"]
    invalid_regions_dmzbbks = ["weu1", "weu2"]
    invalid_regions_confluent = ["weu1", "weu2"]

    match environment:
        case "dev" if cluster in invalid_clusters_dev:
            raise HTTPException(status_code=400, detail=f"Invalid cluster for environment: {environment}")
        case "pre" if cluster in invalid_clusters_pre:
            raise HTTPException(status_code=400, detail=f"Invalid cluster for environment: {environment}")

    match cluster:
        case "azure" if region in invalid_regions_azure:
            raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
        case  "ocp05azure" if region in invalid_regions_ocp05azure:
            raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
        case  "dmzbazure" if region in invalid_regions_dmzbazure:
            raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
        case  "prodarwin" if region in invalid_regions_prodarwin:
            raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
        case  "dmzbdarwin" if region in invalid_regions_dmzbdarwin:
            raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
        case  "probks" if region in invalid_regions_probks:
            raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
        case  "dmzbbks" if region in invalid_regions_dmzbbks:
            raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")
        case  "confluent" if region in invalid_regions_confluent:
            raise HTTPException(status_code=400, detail=f"Invalid region for cluster: {cluster}")


async def get_selector_app(service):
    """
    Asynchronously retrieves the application selector from a given service specification.

    This function attempts to extract the application name from the service's specification
    by checking multiple possible keys in a specific order:
    1. 'app_name'
    2. 'app'
    3. 'app.kubernetes.io/instance'
    4. 'app.kubernetes.io/name'

    If none of these keys are found, the function returns None.

    Args:
        service (dict): A dictionary representing the service specification.

    Returns:
        str or None: The application name if found, otherwise None.
    """
    mic = None
    try:
        mic = service['spec']['selector']['app_name']
    except Exception:
        try:
            mic = service['spec']['selector']['app']
        except Exception:
            try:
                mic = service['spec']['selector']['app.kubernetes.io/instance']
            except Exception:
                mic = service['spec']['selector']['app.kubernetes.io/name']
    return mic


async def process_services(services, serv, namespace, microservice):
    """
    Process the services to determine the appropriate microservice suffix.

    Args:
        services (dict): The dictionary containing service information.
        serv (str): The service key to process.
        namespace (str): The namespace of the microservice.
        microservice (str): The name of the microservice.

    Returns:
        tuple: A tuple containing micr, micro, microb, and microg.
    """
    cont_blue = 0
    cont_green = 0
    micr = None
    micro = None
    microb = None
    microg = None

    for service in services[serv]["items"]:
        if 'b-g-' in service['metadata']['name']:
            mic = await get_selector_app(service)
            if '-blue' in mic or mic.endswith('-b'):
                cont_blue += 1
            elif '-green' in mic or mic.endswith('-g'):
                cont_green += 1

    if namespace == 'san-nweb-emp-pro' and ('datagrid' in microservice or 'arq' in microservice):
        micr = microservice
        micro = microservice
        microb = microservice
    elif cont_blue > cont_green:
        micr = microservice
        micro = microservice + '-b'
        microb = microservice + '-blue'
    else:
        micr = microservice
        micro = microservice + '-g'
        microg = microservice + '-green'

    return micr, micro, microb, microg

   
async def services(environment,cluster,namespace,microservice):
    """
    Asynchronously retrieves and processes services for a given environment, cluster, namespace, and microservice.
    Args:
        environment (str): The functional environment to query.
        cluster (str): The cluster to query.
        namespace (str): The namespace to query.
        microservice (str): The microservice to query.
    Returns:
        tuple: A tuple containing:
            - micr: Processed service information (type depends on `process_services` function).
            - micro: Selector app information (type depends on `get_selector_app` function).
            - microb: Processed service information (type depends on `process_services` function).
            - microg: Processed service information (type depends on `process_services` function).
    """
    services=await client.get_resource(functional_environment=environment,cluster=cluster,resource="services",namespace=namespace)
    micr = None
    micro = None
    microb = None
    microg = None

    exclusion = [
        'config',
        'gateway',
        'datagrid',
        'sts',
        'pkm',
        'nhb-libs',
        'nginx-nhb',
        'moneyplan',
        'corporate',
        'security',
        'trace',
        'decomisado'
    ]
    srv = 'b-g-' + microservice

    for serv in services:
        if services[serv] != 403 and len(services[serv]["items"]) != 0:

            for service in services[serv]["items"]:
                if srv == service['metadata']['name']:
                    micro = await get_selector_app(service)
                    break
                
            if any(ex in microservice for ex in exclusion) or micro is None:
                micr, micro, microb, microg = await process_services(services=services, serv=serv, namespace=namespace, microservice=microservice)

    return micr,micro,microb,microg  


async def get_event_week(environment, clustertraduc, namespace, initialHour=None,finalHour=None):
    """
    Retrieves event data for a given week.

    Args:
        environment (str): The environment to retrieve event data from.
        clustertraduc (str): The cluster to retrieve event data from.
        namespace (str): The namespace to retrieve event data from.

    Returns:
        dict: A dictionary containing lifetime of every with event.

    """
    if initialHour != None and finalHour!=None:
        date = []
        date.append(initialHour)
        date.append(finalHour)
    else:
        date = await timer()
    #initial_time = date[0]
    #final_time = date[1]
    initial_time = datetime.datetime.strptime(date[0], '%Y-%m-%dT%H:%M:%S.%fZ')
    final_time = datetime.datetime.strptime(date[1], '%Y-%m-%dT%H:%M:%S.%fZ')
    event_list = {}
    pod_list = {}
    zero_time = datetime.timedelta(0)

    ps = await elastic_gpw(environment=environment, clustertraduc=clustertraduc, namespace=namespace,initialHour=initialHour,finalHour=finalHour)

    for n in ps: 
        pod_name = n['_source']['kubernetes']['event']['involved_object']['name'] 
        pod_event = n['_source']['kubernetes']['event']['reason'] 
        time = n['_source']['@timestamp']
        if pod_name not in event_list:
            event_list[pod_name] = {}
        temp_date = datetime.datetime.strptime(time, '%Y-%m-%dT%H:%M:%S.%fZ')

        event_list[pod_name][pod_event] = temp_date

    for pod in event_list:
        if 'AddedInterface' not in event_list[pod]:
            event_list[pod]['AddedInterface'] = initial_time
        elif 'Killing' not in event_list[pod]:
            event_list[pod]['Killing'] = final_time
       
        if event_list[pod]['AddedInterface'] >= final_time:
            pod_list[pod] = zero_time
        elif event_list[pod]['Killing'] > final_time:
            pod_list[pod] = final_time - event_list[pod]['AddedInterface']
        else:        
            pod_list[pod] = event_list[pod]['Killing'] - event_list[pod]['AddedInterface']

    return pod_list


async def get_pod_lifetime(podname, pod_list):
    """
    Get the lifetime of a pod.

    Args:
        podname (str): The name of the pod.
        pod_list (dict): A dictionary containing pod names as keys and their lifetimes as values.

    Returns:
        datetime.time: The lifetime of the pod as a time object.

    """
    date = await timer()
    #initial_time = date[0]
    #final_time = date[1]
    initial_time = datetime.datetime.strptime(date[0], '%Y-%m-%dT%H:%M:%S.%fZ')
    final_time = datetime.datetime.strptime(date[1], '%Y-%m-%dT%H:%M:%S.%fZ')
    date_diff = final_time - initial_time
 
    if podname in pod_list:
        return pod_list[podname]
    else:
        return date_diff