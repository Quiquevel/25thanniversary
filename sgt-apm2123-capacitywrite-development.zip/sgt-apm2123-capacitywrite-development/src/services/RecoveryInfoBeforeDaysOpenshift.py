from shuttlelib.helper.keys import get_enviroment
from shuttlelib.utils.logger import logger
from fastapi import HTTPException
import os, aiohttp
import datetime
from src.services.Estructural import traductorcluster,hpass,blockproductive,control_errores,formatearcpu,formatearmemory,totalusomicro,get_clusters,client,mg,URLAZURE,APIKEYAZURE,APIKEYBOADILLA,URLBOADILLA,URLCANTABRIA,APIKEYCANTABRIA,URLMEXICO,APIKEYMEXICO,URLCANTABRIADEVPRE,APIKEYCANTABRIADEVPRE,get_event_week,extraer_cluster
from src.services.Week import get_pod_lifetime,possible_problems
       

async def get_capacity_week(cluster,dayWeek,initialHour,finalHour,region=None,namespaceList=None):
    environment = os.getenv("ENVIRONMENT")
    cpumemoryList = []
    nsSinDatos = []
    nsSinConexion = []
    fecha = datetime.datetime.now()
    print(f"Inicio {cluster}: ", fecha)
    match region:
        case None:
            clustlist, clusterlistcomplete = await get_clusters()
            reg = next((diccionario['region'] for diccionario in clustlist if cluster in diccionario.values()), None)
            '''
            if cluster == 'sgt01.sgt.pro':
                reg = {'sgt01.sgt.pro':['cn1','cn2']}
            elif cluster == 'sgt01.sgt.dmzb':
                reg = {'sgt01.sgt.dmzb':['cn1','cn2']}
            elif cluster == 'gsc04.gsc.pro':
                reg = {'gsc04.gsc.pro':['cn1','cn2']}
            elif cluster == 'gsc04.gsc.dmzb':
                reg = {'gsc04.gsc.dmzb':['cn1','cn2']}
            elif cluster == 'ocppro01.gsc.pro':
                reg = {'ocppro01.gsc.pro':['weu']}
            elif cluster == 'ocpgnr.gsc.pro':
                reg = {'ocpgnr.gsc.pro':['weu1']}
            elif cluster == 'csa02.csa.pro':
                reg = {'csa02.csa.pro':['mx1','mx2']}
            elif cluster == 'gluon01.mex.pro':
                reg = {'gluon01.mex.pro':['mx1','mx2']}
            elif cluster == 'grav01.mex.pro':
                reg = {'grav01.mex.pro':['mx1','mx2']}
            elif cluster == 'mex02.mex.pro':
                reg = {'mex02.mex.pro':['mx1','mx2']}
            elif cluster == 'mex02.mex.dmzb':
                reg = {'mex02.mex.dmzb':['mx1','mx2']}
            elif cluster == 'ocp01.mex.pro':
                reg = {'ocp01.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp02.mex.pro':
                reg = {'ocp02.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp03.mex.pro':
                reg = {'ocp03.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp04.mex.pro':
                reg = {'ocp04.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp05.mex.pro':
                reg = {'ocp05.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp06.mex.pro':
                reg = {'ocp06.mex.pro':['mx1','mx2']}
            elif cluster == 'plard01.mex.pro':
                reg = {'plard01.mex.pro':['mx1','mx2']}
            elif cluster == 'str01.mex.pro':
                reg = {'str01.mex.pro':['mx1','mx2']}
            elif cluster == 'gscmx01.gscmx.pro':
                reg = {'gscmx01.gscmx.pro':['mx1','mx2']}
            elif cluster == 'scg01.scg.pro':
                reg = {'scg01.scg.pro':['bo1','bo2']}
            elif cluster == 'scg01.scg.dmzb':
                reg = {'scg01.scg.dmzb':['bo1','bo2']}
            else:
                reg = get_enviroment(environment)
            '''
            #for rg in reg[cluster]:
            for rg in reg:
                url = next((dic['url'] for dic in clusterlistcomplete if cluster in dic.values() and rg in dic.values()), None)
                machine = await extraer_cluster(url)
                match namespaceList:
                    case None:
                        try:
                            ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=rg)
                            for i in ns[rg]["items"]:
                                try:
                                    nmspace = i["metadata"]["name"]
                                    uid = i["metadata"]["uid"]
                                    logger.info(f"*******Starting to extract data from {cluster}-{nmspace}-{rg}*******")
                                    dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=rg)
                                    deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=rg)
                                    statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=nmspace,region=rg)
                                    hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=rg)
                                    pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=rg)
                                    cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=nmspace,region=rg,cluster=cluster,dayWeek=dayWeek,initialHour=initialHour,finalHour=finalHour,machine=machine)

                                    if len(cpumemoryList[0]) == 0:
                                        cpumemoryList = f"All namespace microservices {nmspace}, they are off"
                                    else:
                                        await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=rg,namespace=nmspace,uid=uid)
                                        logger.info(f"******* Extraction completed for {cluster}---{nmspace}---{rg} *******")
                                except:
                                    logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                                    continue
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against {environment+cluster+rg} ")
                            continue
                        except:
                            logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                            continue
                    case _:
                        for namespace in namespaceList:
                            ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=rg)
                            for i in ns[rg]["items"]:
                                nmspace = i["metadata"]["name"]
                                if nmspace==namespace:
                                    uid = i["metadata"]["uid"]
                                    break
                            try:
                                logger.info(f"******* Starting to extract data from {cluster}---{namespace}---{rg} *******")
                                dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=rg)
                                deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=rg)
                                statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=namespace,region=rg)
                                hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=rg)
                                pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=rg)
                                cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=namespace,region=rg,cluster=cluster,dayWeek=dayWeek,initialHour=initialHour,finalHour=finalHour,machine=machine)

                                if len(cpumemoryList[0]) == 0:
                                    cpumemoryList = f"All namespace microservices {namespace}, they are off"
                                else:
                                    logger.info(f"Saving data")
                                    await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=rg,namespace=namespace,uid=uid)
                                    logger.info(f"******* Extraction completed for {cluster}---{namespace}---{rg} *******")
                                
                            except aiohttp.client_exceptions.ServerTimeoutError:
                                logger.error(f"Timeout detected against {environment+cluster+rg} ")
                                continue
                            except:
                                logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                                continue          
        case _:
            clustlist, clusterlistcomplete = await get_clusters()
            url = next((dic['url'] for dic in clusterlistcomplete if cluster in dic.values() and region in dic.values()), None)
            machine = await extraer_cluster(url)
            match namespaceList:
                case None:
                    await control_errores(region,cluster,environment) 
                    try:
                        ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=region)
                        for i in ns[region]["items"]:
                            try:
                                nmspace = i["metadata"]["name"]
                                uid = i["metadata"]["uid"]
                                logger.info(f"******* Starting to extract data from {cluster}---{nmspace}---{region} *******")
                                dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=region)
                                deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=region)
                                statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=nmspace,region=region)
                                hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=region)
                                pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=region)
                                cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=nmspace,region=region,cluster=cluster,dayWeek=dayWeek,initialHour=initialHour,finalHour=finalHour,machine=machine)

                                if len(cpumemoryList[0]) == 0:
                                    cpumemoryList = f"All namespace microservices {namespace}, they are off"
                                else:
                                    await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=region,namespace=nmspace,uid=uid)
                                    logger.info(f"******* Extraction completed for {cluster}---{nmspace}---{region} *******")
                            except:
                                logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                                next
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {environment+cluster+region} ")
                        next
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        next
                case _:
                    for namespace in namespaceList:
                        try:
                            ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=region)
                            for i in ns[region]["items"]:
                                nmspace = i["metadata"]["name"]
                                if nmspace==namespace:
                                    uid = i["metadata"]["uid"]
                                    break

                            logger.info(f"******* Starting to extract data from {cluster}---{namespace}---{region} *******")
                            dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=region)
                            deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=region)
                            statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=namespace,region=region)
                            hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=region)
                            pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=region)

                            #status = await update_extractinfo_blockProduction(cluster,region,namespace)

                            cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=namespace,region=region,cluster=cluster,dayWeek=dayWeek,initialHour=initialHour,finalHour=finalHour,machine=machine)

                            if len(cpumemoryList[0]) == 0:
                                cpumemoryList = f"All namespace microservices {namespace}, they are off"
                                if dc[region] == 403 or deployments[region] == 403 or hpas[region] == 403 or pods[region] == 403:
                                    nsSinConexion.append(namespace)
                                else:
                                    nsSinDatos.append(namespace)
                            else:
                                logger.info(f"Saving data")
                                await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=region,namespace=namespace,uid=uid)
                                logger.info(f"******* Extraction completed for {cluster}---{namespace}---{region} *******")
                            
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against {environment+cluster+region} ")
                            next
                        except:
                            logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                            next
    fecha2 = datetime.datetime.now()
    namesSinDat = {
        "cluster": cluster,
        "region": region,
        "namespacesSinDatos": nsSinDatos,
        "namespaceSinConexion": nsSinConexion
    }
    print(f"Fin {cluster}: ", fecha2)
    return cpumemoryList,namesSinDat


async def get_data_week(hpas,environment,deploymentconfigs,deployments,statefulsets,pods,namespace,region,cluster,dayWeek,initialHour,finalHour,machine):
    mcList = []
    entity = os.getenv("ENTITY_ID")
    
    #Traducimos el cluster para poder pasarle a elastic el formato correcto
    #clustertraduc = await traductorcluster(environment=environment,region=region,cluster=cluster)

    #Llamamos a elastic para trear los datos de uso que necesitamos
    Ps = await elasticRecovery(clustertraduc=machine,namespace=namespace,initialHour=initialHour,finalHour=finalHour)
    ps_event = await get_event_week(environment=environment,clustertraduc=machine,namespace=namespace,initialHour=initialHour,finalHour=finalHour)

    if deploymentconfigs[region] == 403:
        next
        totalName = ['',0,'']
    else:
        if len(deploymentconfigs[region]["items"]) == 0:
            next
            totalName = ['',0,'']
        else:
            logger.info(f"########################## Extracting deploymentconfigs  ##########################")
            for deco in deploymentconfigs[region]["items"]:
                mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))
                #Recogemos el namespace y el microservicio del deploy config
                microservice = deco["metadata"]["name"]
                try:
                    replicas = deco["status"]["replicas"]
                except:
                    replicas = deco["spec"]["replicas"]

                if replicas == 0:
                    next
                else:
                    logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                    logger.info("------ Starting data extraction ------")
                    hpasNam = await hpass(region,deco,hpas)
                    infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                    if entity == 'spain' and environment == "pro":
                        if cluster != 'confluent':
                            if infonamesp == "production":
                                #Extraccion de datos y calculo de totales a nivel microservicio
                                mcList.extend(await week_data_processing(hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deco,microservice=microservice,pods=pods,Ps=Ps,initialHour=initialHour,finalHour=finalHour,ps_event=ps_event,machine=machine))
                            else:
                                continue
                        else:
                            mcList.extend(await week_data_processing(hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deco,microservice=microservice,pods=pods,Ps=Ps,initialHour=initialHour,finalHour=finalHour,ps_event=ps_event,machine=machine))
                    else:
                        mcList.extend(await week_data_processing(hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deco,microservice=microservice,pods=pods,Ps=Ps,initialHour=initialHour,finalHour=finalHour,ps_event=ps_event,machine=machine))

            logger.info(f"########################## Deploymentconfigs extraction completed  ##########################")

    if deployments[region] == 403:
        next
        totalName = ['',0,'']
    else:
        if len(deployments[region]["items"]) == 0:
            next
            totalName = ['',0,'']
        else:
            logger.info(f"########################## Extracting deployments  ##########################")
            for deploy in deployments[region]["items"]:
                mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))
                #Recogemos el namespace y el microservicio del deploy config
                microservice = deploy["metadata"]["name"]
                try:
                    replicas = deploy["status"]["replicas"]
                except:
                    replicas = deploy["spec"]["replicas"]

                if replicas == 0:
                    next
                else:
                    logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                    logger.info("------ Starting data extraction ------")
                    hpasNam = await hpass(region,deploy,hpas)
                    infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                    if entity == 'spain' and environment == "pro":
                        if cluster != 'confluent':
                            if infonamesp == "production":
                                #Extraccion de datos y calculo de totales a nivel microservicio
                                mcList.extend(await week_data_processing(hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deploy,microservice=microservice,pods=pods,Ps=Ps,initialHour=initialHour,finalHour=finalHour,ps_event=ps_event,machine=machine))
                            else:
                                continue
                        else:
                            mcList.extend(await week_data_processing(hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deploy,microservice=microservice,pods=pods,Ps=Ps,initialHour=initialHour,finalHour=finalHour,ps_event=ps_event,machine=machine))
                    else:
                        mcList.extend(await week_data_processing(hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deploy,microservice=microservice,pods=pods,Ps=Ps,initialHour=initialHour,finalHour=finalHour,ps_event=ps_event,machine=machine))
            logger.info(f"########################## Deployments extraction completed  ##########################")

    if len(statefulsets[region]["items"]) == 0:
        next
        totalName = ['',0,'']
    else:
        logger.info(f"########################## Extracting statefulsets  ##########################")
        for statef in statefulsets[region]["items"]:
            mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))
            #Recogemos el namespace y el microservicio del deploy config
            microservice = statef["metadata"]["name"]
            try:
                replicas = statef["status"]["replicas"]
            except:
                replicas = statef["spec"]["replicas"]

            if replicas == 0:
                next
            else:
                logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                logger.info("------ Starting data extraction ------")
                hpasNam = await hpass(region,statef,hpas)
                #Extraccion de datos y calculo de totales a nivel microservicio
                infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                if entity == 'spain' and environment == "pro":
                    if entity == 'spain' and environment == "pro":
                        if cluster != 'confluent':
                            if infonamesp == "production":
                                #Extraccion de datos y calculo de totales a nivel microservicio
                                mcList.extend(await week_data_processing(hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=statef,microservice=microservice,pods=pods,Ps=Ps,initialHour=initialHour,finalHour=finalHour,ps_event=ps_event,machine=machine))
                            else:
                                continue
                        else:
                            mcList.extend(await week_data_processing(hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=statef,microservice=microservice,pods=pods,Ps=Ps,initialHour=initialHour,finalHour=finalHour,ps_event=ps_event,machine=machine))
                    else:
                        mcList.extend(await week_data_processing(hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=statef,microservice=microservice,pods=pods,Ps=Ps,initialHour=initialHour,finalHour=finalHour,ps_event=ps_event,machine=machine))
                
        logger.info(f"########################## Deployments extraction completed  ##########################")

    totalName = await calcularTotalNamespaceRecovery(mcList,dayWeek,initialHour)
        
    return totalName


async def week_data_processing(hpa,blockprod,cluster,region,namespace,dc,microservice,pods,Ps,initialHour,finalHour,ps_event,machine):
    total_lifetime_time = datetime.timedelta(0)
    environment = os.getenv("ENVIRONMENT")
    mcList = [] #List que contendra de microservicios
    pds = {}
    podNameList = [] #Lista que contendra los pods
    #Recogemos CPU Request
    try:
        cpu_Request = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["cpu"]
    except:
        cpu_Request = None

    #Recogemos CPU Limit
    try:
        cpu_Limit = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["cpu"]
    except:
        cpu_Limit = None

    #Formateo de datos a milicores
    cpuReq = await formatearcpu(cpu_Request)
    cpuLim = await formatearcpu(cpu_Limit)

    #Recogemos MEMORY Request
    try:
        memory_Request = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["memory"]
    except:
        memory_Request = None

    #Recogemos MEMORY Limit
    try:
        memory_Limit = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["memory"]
    except:
        memory_Limit = None

    #Formateo de datos a MiB-GiB
    if memory_Request == None:
        memReqformat = None
    else:
        #Convertimos los datos en bytes
        memReq = await formatearmemory(memory_Request)
         #Convertimos los datos en MiB
        memReqformat = int(memReq/1048576)

    if memory_Limit == None:
        memLimformat = None
    else:
        #Convertimos los datos en bytes
        memLim = await formatearmemory(memory_Limit)
        #Convertimos los datos en MiB
        memLimformat = int(memLim/1048576)

    logger.info(f"Openshift extraction completed")

    try:
        uid = dc["metadata"]["uid"]  
    except:
        uid = None

    replicas = dc["spec"]["replicas"] #Comprobamos si hay replicas
    availablereplicas = 0
    unavailableReplicas = 0
    try:
        availablereplicas = dc["status"]["availableReplicas"]  #Comprobamos si estan disponibles
    except:
        unavailableReplicas = dc["status"]["unavailableReplicas"]  #Comprobamos si estan disponibles

    try:
        unavailableReplicas = dc["status"]["unavailableReplicas"]  #Comprobamos si estan disponibles
    except:
        availablereplicas = dc["status"]["availableReplicas"]  #Comprobamos si estan disponibles
    
    if availablereplicas == 0 or unavailableReplicas != 0:
        next
    else:
        cont = 0
        for pod in pods[region]["items"]:
            try:
                podName = pod["metadata"]["name"]
            except KeyError:
                podName = None

            try:
                referenceName = pod["metadata"]["ownerReferences"][0]["name"]
            except KeyError:
                referenceName = None
            
            if pod["metadata"]["ownerReferences"][0]["kind"] == "StatefulSet":
                microPodName = podName[:podName.rfind('-')]
            else:
                if referenceName != None:
                    microPodName = referenceName[:referenceName.rfind('-')]
                else:
                    microPodName = None

            if "-deploy" in podName:
                next
            else:           
                #Comparamos nombre del microservicio del pod con el nombre del microservicio del namespace
                if microservice == microPodName:
                    cont = 1
                    #Sacamos el nombre del pod
                    podName = pod["metadata"]["name"]
                    #Si el pod tiene -deploy en el nombre nos los saltamos ya que ese pod no esta correcto
                    if "-deploy" in podName:
                        next
                    else:
                        #Extraemos los datos de cpu del pod
                        try:
                            cpu_pod_Request = pod["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                        except:
                            cpu_pod_Request = None
                        try:
                            cpu_pod_Limit = pod["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                        except:
                            cpu_pod_Limit = None

                        #Formatemos los datos a milicores
                        cpuPodReq = await formatearcpu(cpu_pod_Request)
                        cpuPodLim = await formatearcpu(cpu_pod_Limit)

                        #Si no tiene configurado Request coge la configuración por defecto
                        if cpu_Request == None:
                            cpupodr = cpuPodReq  #Volcamos el valor para luego proceder al calculo o formateo, ya que despues al llevar la coletilla "por defecto" y ser str no se puede hacer calculos
                            #cpuPodReq = str(cpuPodReq) + " (Default configuration)"
                        
                        #Si no tiene configurado Limit coge la configuración por defecto
                        if cpu_Limit == None:
                            cpupodl = cpuPodLim  #Volcamos el valor para luego proceder al calculo o formateo, ya que despues al llevar la coletilla "por defecto" y ser str no se puede hacer calculos
                            #cpuPodLim = str(cpuPodLim) + " (Default configuration)"

                        try:
                            memory_pod_Request = pod["spec"]["containers"][0]["resources"]["requests"]["memory"]
                        except:
                            memory_pod_Request = None
                        try:
                            memory_pod_Limit = pod["spec"]["containers"][0]["resources"]["limits"]["memory"]
                        except:
                            memory_pod_Limit = None

                        memPodReq = await formatearmemory(memory_pod_Request)
                        memPodReqformat = int(memPodReq/1048576)
                        memPodLim = await formatearmemory(memory_pod_Limit)
                        memPodLimformat = int(memPodLim/1048576)

                        if memory_Request == None:
                            memPodr = memPodReqformat
                            #memPodReqformat = str(memPodReqformat) + " (Default configuration)"
                        
                        if memory_Limit == None:
                            memPodl = memPodLimformat
                            #memPodLimformat = str(memPodLimformat) + " (Default configuration)"

                        try:
                            restartPod = pod['status']['containerStatuses'][0]['restartCount']
                        except:
                            restartPod = None

                        if len(Ps) == 0:
                            #clustertraduc = await traductorcluster(environment=environment,region=region,cluster=cluster)
                            Ps = await elasticRecovery(clustertraduc=machine,namespace=namespace,initialHour=initialHour,finalHour=finalHour)

                        if len(Ps) == 0:
                            next
                        else:            
                            use = [] 
                            usage = {}
                            conta = 0
                            max = 0
                            maxMem = 0
                            logger.info(f"Processing elastic data from {podName}")

                            for n in Ps: #Recorremos los datos que hemos traido de elastic para tratarlos.
                                conta = conta + 1
                                try:
                                    #pod_name = n['_source']['kubernetes']['pod']['name'] #Nombre del pod de elastic
                                    pod_name = n['key']
                                except:
                                    pod_name = ''
                                
                                if podName == pod_name: #Comprobamos que le pod de openshift y el pod de elastic es el mismo
                                    try:
                                        cpu_usage = round(n['1']['values'][0]['value'],3) #Extraermos el uso
                                    except:
                                        cpu_usage = 0

                                    #if cp_usage == None:
                                        #cpu_usage = 0
                                    #else:
                                        #cpu_usage = round(cp_usage / 1000000) #El uso en nanocores lo pasamos a milicores y redondeamos para quitar decimales

                                    #if cpu_usage > max:
                                        #max = cpu_usage
                                    
                                    #Calulamos el ahorro (request-uso)
                                    if "Default" in str(cpuPodReq):
                                        ahorrocpu = int(cpupodr) - cpu_usage
                                    else:
                                        ahorrocpu = int(cpuPodReq) - cpu_usage

                                    #Calulamos el riesgo (limit-uso)
                                    if "Default" in str(cpuPodLim):
                                        riesgocpu = int(cpupodl) - cpu_usage
                                    else:
                                        riesgocpu = int(cpuPodLim) - cpu_usage                               
                                        

                                    #logger.info(f"Extrayendo el uso de MEMORIA del pod {podName}")
                                    try:
                                        #mem_working_set = n['_source']['kubernetes']['pod']['memory']['usage']['bytes']['total']['max']
                                        memory_working_setformat = int(n['13']['value'])
                                    except:
                                        memory_working_setformat = 0

                                    #if mem_working_set == 0:
                                        #memory_working_setformat = 0
                                    #else:
                                        #if mem_working_set == None:
                                            #memory_working_setformat = 0
                                        #else:
                                            #memory_working_setformat = int(mem_working_set/1048576)

                                        #if memory_working_setformat > maxMem:
                                            #maxMem = memory_working_setformat

                                    #Calulamos el ahorro (request-uso)
                                    if "Default" in str(memPodReqformat):
                                        ahorromemavg = int(memPodr - memory_working_setformat)
                                    else:
                                        ahorromemavg = int(memPodReqformat - memory_working_setformat)

                                    #Calulamos el riesgo (limit-uso)
                                    if "Default" in str(memPodLimformat):
                                        riesgomemavg = int(memPodl - memory_working_setformat)
                                    else:
                                        riesgomemavg = int(memPodLimformat - memory_working_setformat)

                                    #Montamos el diccionario de uso del pod
                                    usage = {
                                        "CPUUsage": cpu_usage,
                                        "OptimizationCPUPod": ahorrocpu,
                                        "RiskCPUPod": riesgocpu,
                                        "MemoryUsage+Cache": memory_working_setformat,
                                        "OptimizationMemoryPod": ahorromemavg,
                                        "RiskMemoryPod": riesgomemavg,
                                    }

                                    #Lo añadimos a una lista, esta contiene todos los usos encontrados en elastic de un unico pod
                                    use.append(usage)
                                    
                            cpuPoReq = await formatearcpu(cpu_pod_Request)
                            cpuPoLim = await formatearcpu(cpu_pod_Limit)

                            '''
                            if len(use) == 0:
                                cpu_usage = 0
                                max = cpu_usage

                                ahorrocpu = int(cpuPoReq - cpu_usage)
                                riesgocpu = int(cpuPoLim - cpu_usage)

                                memory_working_setformat = 0
                                ahorro_avg = int(memPodReqformat - memory_working_setformat)
                                riesgo_avg = int(memPodLimformat - memory_working_setformat)

                                usage = {
                                        "CPUUsage": cpu_usage,
                                        "OptimizationCPUPod": ahorrocpu,
                                        "RiskCPUPod": riesgocpu,
                                        "MemoryUsage+Cache": memory_working_setformat,
                                        "OptimizationMemoryPod": ahorro_avg,
                                        "RiskMemoryPod": riesgo_avg,
                                    }
                                use.append(usage)
                                for d in use:
                                    resultado = d
                            else:    
                                for d in use:
                                    if d["CPUUsage"] >= max:
                                        usage_cpu = d["CPUUsage"]
                                        ahorro_cpu = d["OptimizationCPUPod"]
                                        risk_cpu = d["RiskCPUPod"]
                                
                                for d in use:
                                    if d["MemoryUsage+Cache"] >= maxMem:
                                        usage_mem = d["MemoryUsage+Cache"]
                                        ahorro_mem = d["OptimizationMemoryPod"]
                                        risk_mem = d["RiskMemoryPod"]

                                usage = {
                                        "CPUUsage": usage_cpu,
                                        "OptimizationCPUPod": ahorro_cpu,
                                        "RiskCPUPod": risk_cpu,
                                        "MemoryUsage+Cache": usage_mem,
                                        "OptimizationMemoryPod": ahorro_mem,
                                        "RiskMemoryPod": risk_mem,
                                    }
                            '''
                            podlifetime = await get_pod_lifetime(podname=podName, pod_list=ps_event)
                            total_lifetime_time += podlifetime
                            pds = {
                                "Pod": podName,
                                "restartPod": restartPod,
                                "lifeTimePod": str(podlifetime),
                                "cpuRequestPod": cpuPodReq,
                                "cpuLimitPod": cpuPodLim,
                                "memoryRequestPod": memPodReqformat,
                                "memoryLimitPod": memPodLimformat,
                                "use":usage
                                }
                            
                            if pds["lifeTimePod"] == "0:00:00":
                                next
                            else:
                                podNameList.append(pds)

                            logger.info("Processing data completed")
                else:
                    if cont == 1:
                        cont = 0
                        break
                    else:
                        next

        
        if len(Ps) == 0:
            next
        else:
            logger.info("Calculating microservice CPU totals")
            #Calcular los totales del microservicio

            usoTotal = await totalusomicro(pod_dict=podNameList)
            usoTotalMicCPU = usoTotal[0]
            usoMedioCPU = int(usoTotalMicCPU / replicas)
            if cpuReq == None:
                requestTotalCPU = int(cpupodr * replicas)
                OpCPUmic = int(requestTotalCPU - usoTotalMicCPU)
            else:
                requestTotalCPU = int(cpuReq * replicas)
                OpCPUmic = int(requestTotalCPU - usoTotalMicCPU)
                
            if cpuLim == None:
                limitTotalCPU = int(cpupodl * replicas)
                RiskCPUmic = int(limitTotalCPU - usoTotalMicCPU)
            else:
                limitTotalCPU = int(cpuLim * replicas)
                RiskCPUmic = int(limitTotalCPU - usoTotalMicCPU)
            
            #Calcular los totales del microservicio
            logger.info("Calculating microservice MEMORY totals")
    
            if availablereplicas == 0:
                usoTotalMic = 0
                usoMedioMicro = 0
                opMemMicc = 0
                riskMemMicc = 0
                requestTotal = 0
                limitTotal = 0
            else:
                if "we cannot extract information" in podNameList:
                    usoTotalMic = 0
                    usoMedioMicro = 0
                    requestTotal = 0
                    limitTotal = 0
                    opMemMicc = 0
                    riskMemMicc = 0
                else:
                    usoTotalMic = usoTotal[3]
                    if usoTotalMic == 0:
                        usoTotalMic = 0
                        usoMedioMicro = 0
                        opMemMicc = 0
                        riskMemMicc = 0
                        requestTotal = 0
                        limitTotal = 0
                    else:
                        usoMedioMicro = int(usoTotalMic / replicas)
                    if memReqformat == None:
                        requestTotal = int(memPodr) * int(replicas)
                        opMemMicc = int(requestTotal - usoTotalMic)
                    else:
                        requestTotal = int(memReqformat * replicas)
                        opMemMicc = int(requestTotal - usoTotalMic)
                        
                    if memLimformat == None:
                        limitTotal = int(memPodl * replicas)
                        riskMemMicc = int(limitTotal - usoTotalMic)
                    else:
                        limitTotal = int(memLimformat * replicas)
                        riskMemMicc = int(limitTotal - usoTotalMic)

            logger.info("Calculating microservice average running pods")
            average_pods = round((total_lifetime_time.total_seconds() / (8*60*60)), 1)

            mc = {
                "uid": uid,
                "microservice": microservice,
                "blockProduction": blockprod,
                "replicasMicroservice": replicas,
                "cpuRequestMicroservice": cpuPoReq,
                "cpuLimitMicroservice": cpuPoLim,
                "totalUseMicroserviceCPU": usoTotalMicCPU,
                "AverageUseMicroserviceCPU": usoMedioCPU,
                "totalRequestMicroserviceCPU": requestTotalCPU,
                "totalLimitMicroserviceCPU": limitTotalCPU,
                "totalOptimizationCPUMicroservice": OpCPUmic,
                "totalRiskCPUMicroservice": RiskCPUmic,
                "memoryRequestMicroservice": memPodReqformat,
                "memoryLimitMicroservice": memPodLimformat,
                "totalUseMicroserviceMEM": usoTotalMic,
                "averageUseMicroserviceMEM": usoMedioMicro,
                "totalRequestMicroserviceMEM": requestTotal,
                "totalLimitMicroserviceMEM": limitTotal,
                "totalOptimizationMemoryMicroservice": opMemMicc,
                "totalRiskMemoryMicroservice": riskMemMicc,
                "averageLivePod": average_pods,
                "hpa": hpa,
                "pods": podNameList
            }

            if memory_Limit == None:
                memory_Limit = memory_pod_Limit

            if os.getenv("ENTITY_ID") == "spain":
                await possible_problems(namespace,cluster,region,dc,mc,memory_Limit)

            mcList.append(mc)

    logger.info("------ Data extraction completed ------")
    return mcList


async def guardarMongoWeek(datgen,environment,namespace,cluster,region,uid):
    dateList = []
    mm = datgen[0]
    totrep = datgen[1]

    datosgen = {
        "uid": uid,
        "environment": environment,
        "cluster": cluster,
        "region": region,
        "namespace": namespace,
        "totalReplicasNamespace": totrep,
        "date": mm
    }

    #Inserccion Mongo
    if mg.server_info():
        mg.change_collection(os.getenv("COLLECTION_WEEK"))
        querydbresultsmemory = mg.find({f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" })
        findnamespacememory = [x for x in querydbresultsmemory]
        if len(findnamespacememory) == 0:                                
            mg.add_data(data=datosgen)
        else:

            dateList = findnamespacememory[0]["date"]
            nameday = mm[0]["nameday"]

            for n in dateList:
                if n["nameday"] == nameday:
                    cont = 0
                    n["date"] = mm[0]["date"]
                    n["totalUseNamespaceCPU"] = mm[0]["totalUseNamespaceCPU"]
                    n["totalRequestNamespaceCPU"] = mm[0]["totalRequestNamespaceCPU"]
                    n["totalAverageNamespaceCPU"] = mm[0]["totalAverageNamespaceCPU"]
                    n["totalLimitNamespaceCPU"] = mm[0]["totalLimitNamespaceCPU"]
                    n["totalOptimizationCPUNamespace"] = mm[0]["totalOptimizationCPUNamespace"]
                    n["totalRiskCPUNamespace"] = mm[0]["totalRiskCPUNamespace"]
                    n["totalUseNamespaceMEM"] = mm[0]["totalUseNamespaceMEM"]
                    n["totalAverageNamespaceMEM"] = mm[0]["totalAverageNamespaceMEM"]
                    n["totalRequestNamespaceMEM"] = mm[0]["totalRequestNamespaceMEM"]
                    n["totalLimitNamespaceMEM"] = mm[0]["totalLimitNamespaceMEM"]
                    n["totalOptimizationMemoryNamespace"] = mm[0]["totalOptimizationMemoryNamespace"]
                    n["totalRiskMemoryNamespace"] = mm[0]["totalRiskMemoryNamespace"]
                    n["microservices"] = mm[0]["microservices"]
                    break
                else:
                    cont = 1

            if cont == 1:
                dateList.extend(mm)

            mg.update_one(
                { f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" },
                
                { '$set': {
                    f"date" : dateList }
                }
                )
            mg.update_one(
                { f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" },
                
                { '$set': {
                    f"totalReplicasNamespace" : totrep }
                }
                )

        await orderWeekly(cluster,region,namespace)

    else:
        logger.info('Could not connect to MongoDB')
        raise HTTPException(status_code=500, detail=f"Could not connect to MongoDB")


async def elasticRecovery(clustertraduc,namespace,initialHour,finalHour):
    logger.info("#### Connecting with elastic ####")

    fecha_inicio = initialHour
    fecha_fin = finalHour

    query = "cpu-and-memory-per-project - week"
    query_file = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + "data" + os.path.sep + query + ".json"

    with open(query_file) as file:
            ES_QUERY = "".join(line.rstrip() for line in file)

    if "per-project" in query:
        ELASTIC_QUERY_SCOPE = 'project'
        ES_QUERY = str(ES_QUERY)\
            .replace('$OPENSHIFT_CLUSTER', clustertraduc)\
            .replace('$OPENSHIFT_NAMESPACE', namespace)\
            .replace('$FECHA_INICIO',fecha_inicio)\
            .replace('$FECHA_FIN',fecha_fin)
    elif "per-cluster" in query:
        ELASTIC_QUERY_SCOPE = 'cluster'
        ES_QUERY = str(ES_QUERY)\
            .replace('$OPENSHIFT_CLUSTER', namespace)
    

    if clustertraduc == "ocp05.san.pro.weu1" or clustertraduc == "ocp05.san.pro.weu2" or clustertraduc == "ocppro01.gsc.pro.weu" or clustertraduc == "ocpgnr.gsc.pro.weu1":
        request_url = URLAZURE + "/archive-capacity/_async_search"
        headers = {'Authorization': "ApiKey "+str(APIKEYAZURE),'Accept': 'application/json','Content-type': 'application/json'}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                    res = await resp.json()
        except:
            logger.info("Elastic not available")
            json_object = []
            return json_object
        
        try:
            Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
        except:
            Ps= []

        retries = 0
        while len(Ps) == 0:
            retries += 1
            if retries < 20:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                        res = await resp.json()

                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
            else:
                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
                break
    elif clustertraduc == "sgt01.sgt.pro.cn1" or clustertraduc == "sgt01.sgt.pro.cn2" or clustertraduc == "gsc04.gsc.pro.cn1" or clustertraduc == "gsc04.gsc.pro.cn2" or clustertraduc == "sgt01.sgt.dmzb.cn1" or clustertraduc == "sgt01.sgt.dmzb.cn2" or clustertraduc == "gsc04.gsc.dmzb.cn1" or clustertraduc == "gsc04.gsc.dmzb.cn2" or clustertraduc == "scq01.scq.pro.cn1" or clustertraduc == "scq01.scq.pro.cn2" or clustertraduc == "scq01.scq.dmzb.cn1" or clustertraduc == "scq01.scq.dmzb.cn2" or clustertraduc == "scita.scq.pro.cn1" or clustertraduc == "scita.scq.pro.cn2" or clustertraduc == "scbnl.scq.pro.cn1" or clustertraduc == "scbnl.scq.pro.cn2" or clustertraduc == "scita.scq.dmzb.cn1" or clustertraduc == "scita.scq.dmzb.cn2" or clustertraduc == "scbnl.scq.dmzb.cn1" or clustertraduc == "scbnl.scq.dmzb.cn2":
        request_url = URLCANTABRIA + "/archive-capacity/_async_search"
        headers = {'Authorization': "ApiKey "+str(APIKEYCANTABRIA),'Accept': 'application/json','Content-type': 'application/json'}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                    res = await resp.json()
        except:
            logger.info("Elastic not available")
            json_object = []
            return json_object
        try:
            Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
        except:
            Ps= []

        retries = 0
        while len(Ps) == 0:
            retries += 1
            if retries < 20:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                        res = await resp.json()
                
                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
            else:
                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
                break
    elif clustertraduc == "sgt01.sgt.dev.cn1" or clustertraduc == "sgt01.sgt.dev.cn2" or clustertraduc == "iag01.sgt.dev.cn1" or clustertraduc == "iag01.sgt.dev.cn2" or clustertraduc == "gpdev01.sgt.dev.cn1" or clustertraduc == "gpdev01.sgt.dev.cn2" or clustertraduc == "gpcert01.sgt.dev.cn1" or clustertraduc == "gpcert01.sgt.dev.cn2":
        request_url = URLCANTABRIADEVPRE + "/archive-capacity/_async_search"
        headers = {'Authorization': "ApiKey "+str(APIKEYCANTABRIADEVPRE),'Accept': 'application/json','Content-type': 'application/json'}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                    res = await resp.json()
        except:
            logger.info("Elastic not available")
            json_object = []
            return json_object
        try:
            Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
        except:
            Ps= []

        retries = 0
        while len(Ps) == 0:
            retries += 1
            if retries < 20:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                        res = await resp.json()
                
                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
            else:
                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
                break
    elif clustertraduc == "csa02.csa.pro.mx1" or clustertraduc == "csa02.csa.pro.mx2" or clustertraduc == "gluon01.mex.pro.mx1" or clustertraduc == "gluon01.mex.pro.mx2" or clustertraduc == "grav01.mex.pro.mx1" or clustertraduc == "grav01.mex.pro.mx2" or clustertraduc == "mex02.mex.pro.mx1" or clustertraduc == "mex02.mex.pro.mx2" or clustertraduc == "mex02.mex.dmzb.mx1" or clustertraduc == "mex02.mex.dmzb.mx2" or clustertraduc == "ocp01.mex.pro.mx1" or clustertraduc == "ocp01.mex.pro.mx2" or clustertraduc == "ocp02.mex.pro.mx1" or clustertraduc == "ocp02.mex.pro.mx2" or clustertraduc == "ocp03.mex.pro.mx1" or clustertraduc == "ocp03.mex.pro.mx2" or clustertraduc == "ocp04.mex.pro.mx1" or clustertraduc == "ocp04.mex.pro.mx2" or clustertraduc == "ocp05.mex.pro.mx1" or clustertraduc == "ocp05.mex.pro.mx2" or clustertraduc == "ocp06.mex.pro.mx1" or clustertraduc == "ocp06.mex.pro.mx2" or clustertraduc == "plard01.mex.pro.mx1" or clustertraduc == "plard01.mex.pro.mx2" or clustertraduc == "str01.mex.pro.mx1" or clustertraduc == "str01.mex.pro.mx2" or clustertraduc == "gscmx01.gscmx.pro.mx1" or clustertraduc == "gscmx01.gscmx.pro.mx2":
        request_url = URLMEXICO + "/archive-capacity/_async_search"
        headers = {'Authorization': "ApiKey "+str(APIKEYMEXICO),'Accept': 'application/json','Content-type': 'application/json'}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                    res = await resp.json()
        except:
            logger.info("Elastic not available")
            json_object = []
            return json_object
        try:
            Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
        except:
            Ps= []

        retries = 0
        while len(Ps) == 0:
            retries += 1
            if retries < 20:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                        res = await resp.json()
                
                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
            else:
                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
                break
    else:
        ca = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + 'santander-ca-root.crt'
        request_url = URLBOADILLA + "/archive-capacity/_async_search"
        headers = {'Authorization': "ApiKey "+str(APIKEYBOADILLA),'Accept': 'application/json','Content-type': 'application/json'}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                    res = await resp.json()
        except:
            logger.info("Elastic not available")
            json_object = []
            return json_object
        
        try:
            Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
        except:
            Ps= []
        
        retries = 0
        while len(Ps) == 0:
            retries = retries + 1
            if retries < 20:
                async with aiohttp.ClientSession() as session:
                    async with session.post(request_url,ssl=False,headers=headers,data=ES_QUERY) as resp:
                        res = await resp.json()
                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
            else:
                try:
                    Ps= res['response']['aggregations']['2']['buckets'][0]['3']['buckets'][0]['4']['buckets']
                except:
                    Ps= []
                break

    return Ps


async def calcularTotalNamespaceRecovery(mcList,dayWeek,initialHour):
    logger.info(f"Calculating namespace CPU totals")
    usogenCPU = 0
    averageCPU = 0
    opCPUgen = 0
    riskCPUgen = 0
    totreplicas = 0
    reqgenCPU = 0
    limgenCPU = 0
    date = []
    spec = {}
    if len(mcList) == 0:
        logger.info(f"Microservice without pods or block production is hidden")
        return date, totreplicas, mcList
    else:
        for micro in mcList:
            totreplicas += micro["replicasMicroservice"]
            usogenCPU += micro["totalUseMicroserviceCPU"]
            averageCPU += micro["AverageUseMicroserviceCPU"]
            reqgenCPU += micro["totalRequestMicroserviceCPU"]
            limgenCPU += micro["totalLimitMicroserviceCPU"]

        opCPUgen = int(reqgenCPU - usogenCPU)
        riskCPUgen = int(limgenCPU - usogenCPU)

        #Pasar de milicores a cores
        usogenCPUNam = round(usogenCPU/1000,3)
        averageCPUNam = round(averageCPU/1000,3)
        opCPUgenNam = round(opCPUgen/1000,3)
        riskCPUgenNam = round(riskCPUgen/1000,3)
        reqgenCPUNam = round(reqgenCPU/1000,3)
        limgenCPUNam = round(limgenCPU/1000,3)

        logger.info(f"Calculating namespace MEMORY totals")
        usogenMem = 0 
        avegenMem = 0
        reqgen = 0
        limgen = 0

        for micro in mcList:
            if micro["totalUseMicroserviceMEM"] == 0:
                usogenMem += 0
            else:
                usogenMem += int(micro["totalUseMicroserviceMEM"])

            if micro["averageUseMicroserviceMEM"] == 0:
                avegenMem += 0
            else:
                avegenMem += int(micro["averageUseMicroserviceMEM"])

            if micro["totalRequestMicroserviceMEM"] == 0:
                reqgen += 0
            else:
                reqgen += int(micro["totalRequestMicroserviceMEM"])

            if micro["totalLimitMicroserviceMEM"] == 0:
                limgen += 0
            else:
                limgen += int(micro["totalLimitMicroserviceMEM"])

        opMemgenNam = int(reqgen - usogenMem)
        riskMemgenNam = int(limgen - usogenMem)

        #Convertir de MiB a GiB
        usogenMemNam = round(usogenMem/1024,3)
        avegenMemNam = round(avegenMem/1024,3)
        opMemgenMemNam = round(opMemgenNam/1024,3)
        riskMemgenMemNam =  round(riskMemgenNam/1024,3)
        reqgenMemNam = round(reqgen/1024,3)
        limgenMemNam = round(limgen/1024,3)

        #fechaDay = datetime.date.today()
        fecha = initialHour[:10]
        spec = {
            "nameday": dayWeek,
            "date": fecha,
            "totalUseNamespaceCPU": usogenCPUNam,
            "totalAverageNamespaceCPU": averageCPUNam,
            "totalRequestNamespaceCPU": reqgenCPUNam,
            "totalLimitNamespaceCPU": limgenCPUNam,
            "totalOptimizationCPUNamespace": opCPUgenNam,
            "totalRiskCPUNamespace": riskCPUgenNam,
            "totalUseNamespaceMEM": usogenMemNam,
            "totalAverageNamespaceMEM":avegenMemNam,
            "totalRequestNamespaceMEM": reqgenMemNam,
            "totalLimitNamespaceMEM": limgenMemNam,
            "totalOptimizationMemoryNamespace": opMemgenMemNam,
            "totalRiskMemoryNamespace": riskMemgenMemNam,
            "microservices": mcList
        }
        date.append(spec)
        return date, totreplicas, mcList

     
async def orderWeekly(cluster,region,namespace):
    orderDateList = []
    dateList = []
    if mg.server_info():
        mg.change_collection(os.getenv("COLLECTION_WEEK"))
        querydbresultsmemory = mg.find({f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" })
        findnamespacememory = [x for x in querydbresultsmemory]
        if len(findnamespacememory) == 0:                                
            pass
        else:
            dateList = findnamespacememory[0]["date"]
            for date in dateList:
                nameday = date["nameday"]
                if nameday == "Monday":
                    orderDateList.append(date)
                    dateList.remove(date)
                    continue
                else:
                    continue
            
            for date in dateList:
                nameday = date["nameday"]
                if nameday == "Tuesday":
                    orderDateList.append(date)
                    dateList.remove(date)
                    continue
                else:
                    continue

            for date in dateList:
                nameday = date["nameday"]
                if nameday == "Wednesday":
                    orderDateList.append(date)
                    dateList.remove(date)
                    continue
                else:
                    continue

            for date in dateList:
                nameday = date["nameday"]
                if nameday == "Thursday":
                    orderDateList.append(date)
                    dateList.remove(date)
                    continue
                else:
                    continue
            
            for date in dateList:
                nameday = date["nameday"]
                if nameday == "Friday":
                    orderDateList.append(date)
                    dateList.remove(date)
                    continue
                else:
                    continue
            
            for date in dateList:
                nameday = date["nameday"]
                if nameday == "Saturday":
                    orderDateList.append(date)
                    dateList.remove(date)
                    continue
                else:
                    continue

            for date in dateList:
                nameday = date["nameday"]
                if nameday == "Sunday":
                    orderDateList.append(date)
                    dateList.remove(date)
                    continue
                else:
                    continue
                
            mg.update_one(
                { f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" },
                
                { '$set': {
                    f"date" : orderDateList }
                }
                )
