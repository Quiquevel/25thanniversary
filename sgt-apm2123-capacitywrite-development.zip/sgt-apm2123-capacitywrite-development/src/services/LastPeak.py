from shuttlelib.utils.logger import logger
import os
from src.services.Estructural import get_clusters,dayweek,client,mg
        

async def getcapacitylastpeak(cluster=None, region=None, indicador=None):
    functionalEnvironment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    '''
    if cluster == None and region == None and indicador == None:
        mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK"))
        mg.delete_all_data()
    elif cluster == None and region == None and indicador == 'microservice':
        mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE"))
        mg.delete_all_data()
    elif cluster == None and region == None and indicador == 'online-microservice':
        mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_ONLINE"))
        mg.delete_all_data()
    elif cluster == None and region == None and indicador == 'online':
        mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_ONLINE"))
        mg.delete_all_data()
    '''
    match cluster:
        case None:
            clusters = await client.get_resource(resource="clusters",functional_environment=functionalEnvironment,cluster=None)
            for clust in clusters:
                match region:
                    case None:
                        clustlist, clusterlistcomplete = await get_clusters()
                        reg = next((diccionario['region'] for diccionario in clustlist if clust in diccionario.values()), None)
                        '''
                        if clust == "azure" or clust == "ocp05azure" or clust == "dmzbazure":
                            regionlist = ['weu1', 'weu2']
                        elif clust == 'ocppro01.gsc.pro':
                            regionlist = ['weu']
                        elif clust == 'ocpgnr.gsc.pro':
                            regionlist = ['weu1']
                        elif clust == "sgt01.sgt.pro" or clust == "sgt01.sgt.dmzb" or clust == "gsc04.gsc.pro" or clust == "gsc04.gsc.dmzb":
                            regionlist = ['cn1', 'cn2']
                        elif clust == 'csa02.csa.pro' or clust == "gluon01.mex.pro" or clust == "grav01.mex.pro" or clust == "mex02.mex.pro" or clust == "mex02.mex.dmzb" or clust == "ocp01.mex.pro" or clust == "ocp02.mex.pro" or clust == "ocp03.mex.pro" or clust == "ocp04.mex.pro" or clust == "ocp05.mex.pro" or clust == "ocp06.mex.pro" or clust == "plard01.mex.pro" or clust == "str01.mex.pro" or clust == "gscmx01.gscmx.pro":
                            regionlist = ['mx1', 'mx2']
                        else:
                            regionlist = ['bo1', 'bo2']
                        '''
                        namespace_max_scores = []
                        for rlist in reg:
                            if indicador == "online" or indicador == 'online-microservice':
                                mg.change_collection(os.getenv("COLLECTION_WEEK"))
                            else:
                                mg.change_collection(os.getenv("COLLECTION"))
                            # Find cluster/region in bbdd
                            documents = list(mg.find({f"cluster": clust, f"region": rlist}))
                            if documents:
                                for docu in documents:
                                    del docu['_id']
                                    del docu['timestamp']
                                    uid = docu['uid']
                                    logger.info(f"########## Cluster {clust} - Region {rlist} ##########")
                                    logger.info(f"Namespace: {docu['namespace']}")
                                    detailnamespace_max_peak = await lastpeak(docu, indicador, uid)
                                    namespace_max_scores.append(detailnamespace_max_peak)
                    case _:
                        # Find cluster/region in bbdd
                        if indicador == "online" or indicador == 'online-microservice':
                            mg.change_collection(os.getenv("COLLECTION_WEEK"))
                        else:
                            mg.change_collection(os.getenv("COLLECTION"))
                        documents = list(mg.find({f"cluster": clust, f"region": region}))
                        if documents:
                            namespace_max_scores = []
                            for docu in documents:
                                del docu['_id']
                                del docu['timestamp']
                                uid = docu['uid']
                                logger.info(f"########## Cluster {clust} - Region {region} ##########")
                                logger.info(f"Namespace: {docu['namespace']}")
                                detailnamespace_max_peak = await lastpeak(docu, indicador, uid)
                                namespace_max_scores.append(detailnamespace_max_peak)
                        else:
                            logger.info(f"Data not found")
        case _:
            match region:
                case None:
                    clustlist, clusterlistcomplete = await get_clusters()
                    reg = next((diccionario['region'] for diccionario in clustlist if cluster in diccionario.values()), None)
                    '''
                    if cluster == "azure" or cluster == "ocp05azure" or cluster == "dmzbazure":
                        regionlist = ['weu1', 'weu2']
                    elif clusters == 'ocppro01.gsc.pro':
                        regionlist = ['weu']
                    elif cluster == 'ocpgnr.gsc.pro':
                        regionlist = ['weu1']
                    elif cluster == "sgt01.sgt.pro" or cluster == "sgt01.sgt.dmzb" or cluster == "gsc04.gsc.pro" or cluster == "gsc04.gsc.dmzb":
                        regionlist = ['cn1', 'cn2']
                    elif cluster == 'csa02.csa.pro' or cluster == "gluon01.mex.pro" or cluster == "grav01.mex.pro" or cluster == "mex02.mex.pro" or cluster == "mex02.mex.dmzb" or cluster == "ocp01.mex.pro" or cluster == "ocp02.mex.pro" or cluster == "ocp03.mex.pro" or cluster == "ocp04.mex.pro" or cluster == "ocp05.mex.pro" or cluster == "ocp06.mex.pro" or cluster == "plard01.mex.pro" or cluster == "str01.mex.pro" or clust == "gscmx01.gscmx.pro":
                        regionlist = ['mx1', 'mx2']
                    else:
                        regionlist = ['bo1', 'bo2']
                    '''
                    namespace_max_scores = []
                    for rlist in reg:
                        if indicador == "online" or indicador == 'online-microservice':
                            mg.change_collection(os.getenv("COLLECTION_WEEK"))
                        else:
                            mg.change_collection(os.getenv("COLLECTION"))
                        # Find cluster/region in bbdd
                        documents = list(mg.find({f"cluster": cluster, f"region": rlist}))
                        if documents:
                            for docu in documents:
                                del docu['_id']
                                del docu['timestamp']
                                uid = docu['uid']
                                logger.info(f"########## Cluster {cluster} - Region {rlist} ##########")
                                logger.info(f"Namespace: {docu['namespace']}")
                                detailnamespace_max_peak = await lastpeak(docu, indicador, uid)
                                namespace_max_scores.append(detailnamespace_max_peak)
                case _:
                    # Find cluster/region in bbdd
                    if indicador == "online" or indicador == 'online-microservice':
                        mg.change_collection(os.getenv("COLLECTION_WEEK"))
                    else:
                        mg.change_collection(os.getenv("COLLECTION"))
                    documents = list(mg.find({f"cluster": cluster, f"region": region}))
                    if documents:
                        namespace_max_scores = []
                        for docu in documents:
                            del docu['_id']
                            del docu['timestamp']
                            uid = docu['uid']
                            logger.info(f"########## Cluster {cluster} - Region {region} ##########")
                            logger.info(f"Namespace: {docu['namespace']}")
                            detailnamespace_max_peak = await lastpeak(docu, indicador, uid)
                            namespace_max_scores.append(detailnamespace_max_peak)

                    else:
                        logger.info(f"Data not found")
    return namespace_max_scores


async def lastpeak(docu, indicador, uid):
    marcador = False
    if indicador == 'online':
        detailmicro_max_peak_CPU = []
        detailmicro_max_peak_MEM = []
        detailmicro_max_peak = []

        date = docu['date']
        day = await dayweek()
        di = False
        for d in date:
            dia = d['nameday']
            if day == dia:
                di = True
                break

        if di == True:
            for d in date:
                dia = d['nameday']
                if day == dia:
                    max_peak_useCPU = d['totalUseNamespaceCPU']
                    max_peak_averageCPU = d['totalAverageNamespaceCPU']
                    max_peak_useMEM = d['totalUseNamespaceMEM']
                    max_peak_averageMEM = d['totalAverageNamespaceMEM']
                    max_peak_requestCPU = d['totalRequestNamespaceCPU']
                    max_peak_requestMEM = d['totalRequestNamespaceMEM']
                    max_peak_limitCPU = d['totalLimitNamespaceCPU']
                    max_peak_limitMEM = d['totalLimitNamespaceMEM']
                    max_peak_riskCPU = d['totalRiskCPUNamespace']
                    max_peak_riskMemory = d['totalRiskMemoryNamespace']
                    max_peak_optimizationCPU = d['totalOptimizationCPUNamespace']
                    max_peak_optimizationMemory = d['totalOptimizationMemoryNamespace']

                    microservicesPeak = d['microservices']
                    for micro in microservicesPeak:
                        try:
                            uidMicro = micro['uid']
                            microservice = micro['microservice']
                            if micro['hpa'] == None:
                                replicas = micro['replicasMicroservice']
                                replicasMin = "N/A"
                                replicasMax = "N/A"
                            else:
                                hpa = micro['hpa']
                                replicasMin = hpa['minReplicas']
                                replicasMax = hpa['maxReplicas']
                                replicas = hpa['minReplicas']
                            max_peak_useCPUMic = micro['totalUseMicroserviceCPU']
                            max_peak_averageCPUMic = micro['AverageUseMicroserviceCPU']
                            requestCPU = micro['totalRequestMicroserviceCPU']
                            limitCPU = micro ['totalLimitMicroserviceCPU']
                            limitCPUIndividual  = micro['cpuLimitMicroservice']
                            optimizationCPU = micro['totalOptimizationCPUMicroservice']
                            if micro['hpa'] == None:
                                optimizationCPUReplicasMin = int(micro['totalOptimizationCPUMicroservice'] / replicas)
                            else:
                                optimizationCPUReplicasMin = int(micro['totalOptimizationCPUMicroservice'] / replicasMin)
                            riskCPU = micro ['totalRiskCPUMicroservice']
                            max_peak_useMEMMic = micro['totalUseMicroserviceMEM']
                            max_peak_averageMEMMic = micro['averageUseMicroserviceMEM']
                            requestMEM = micro['totalRequestMicroserviceMEM']
                            limitMEM = micro['totalLimitMicroserviceMEM']
                            limitMEMIndividual = micro['memoryLimitMicroservice']
                            optimizationMEM = micro['totalOptimizationMemoryMicroservice']
                            if micro['hpa'] == None:
                                optimizationMEMReplicasMin = int(micro['totalOptimizationMemoryMicroservice'] / replicas)
                            else:
                                optimizationMEMReplicasMin = int(micro['totalOptimizationMemoryMicroservice'] / replicasMin)
                            riskMEM = micro['totalRiskMemoryMicroservice']
                            pods = micro['pods']

                            if os.getenv("ENTITY_ID") == "spain":
                                possibleCausesCPU = micro['possibleCasesCPU']
                                possibleCausesMEM = micro['possibleCasesMEM']
                            else:
                                possibleCausesCPU = None
                                possibleCausesMEM = None

                            if riskCPU < 750 or riskMEM < 500:
                                marcador = True
                                                        
                            if optimizationCPU < -80 or optimizationCPU > 80:
                                marcador = True

                            if optimizationMEM < -500 or optimizationMEM > 500:
                                marcador = True

                            percentajeFreeCPU = round((riskCPU * 100)/limitCPU,1)
                            percentajeFreeMEM = round((riskMEM * 100)/limitMEM,1)

                            detailmicroservice_max_peak = {
                                "uid": uidMicro,
                                "microservice": microservice,
                                "replicasBase": replicas,
                                "replicasMin": replicasMin,
                                "replicasMax": replicasMax,
                                "max_peak_useCPU": max_peak_useCPUMic,
                                "max_peak_averageCPU": max_peak_averageCPUMic,
                                "max_peak_useMEM": max_peak_useMEMMic,
                                "max_peak_averageMEM": max_peak_averageMEMMic,
                                "requestCPU": requestCPU,
                                "requestMEM": requestMEM,
                                "limitCPU": limitCPU,
                                "limitCPUIndividual": limitCPUIndividual,
                                "limitMEM": limitMEM,
                                "limitMEMIndividual": limitMEMIndividual,
                                "optimizationCPU": optimizationCPU,
                                "optimizationCPUReplicasMin": optimizationCPUReplicasMin,
                                "optimizationMEM": optimizationMEM,
                                "optimizationMEMReplicasMin": optimizationMEMReplicasMin,
                                "riskCPU": riskCPU,
                                "riskMEM": riskMEM,
                                "percentajeFreeCPU": percentajeFreeCPU,
                                "percentajeFreeMEM": percentajeFreeMEM,
                                "pods": pods,
                                "possibleCausesCPU": possibleCausesCPU,
                                "possibleCausesMEM": possibleCausesMEM
                            }
                            detailmicro_max_peak.append(detailmicroservice_max_peak)

                        except:
                            logger.info(f"Algo ha ido mal en microservicesPeakCPU")
                            continue
            
            detailnamespace_max_peak = {
                "uid": uid,
                "namespace": docu['namespace'],
                "region": docu['region'],
                "cluster": docu['cluster'],
                "max_peak_useCPU": max_peak_useCPU,
                "max_peak_averageCPU": max_peak_averageCPU,
                "max_peak_useMEM": max_peak_useMEM,
                "max_peak_averageMEM": max_peak_averageMEM,
                "max_peak_requestCPU": max_peak_requestCPU,
                "max_peak_requestMEM": max_peak_requestMEM,
                "max_peak_limitCPU": max_peak_limitCPU,
                "max_peak_limitMEM": max_peak_limitMEM,
                "max_peak_riskCPU": max_peak_riskCPU,
                "max_peak_riskMemory": max_peak_riskMemory,
                "max_peak_optimizationCPU": max_peak_optimizationCPU,
                "max_peak_optimizationMemory": max_peak_optimizationMemory,
                "marcador": marcador,
                "microservices": detailmicro_max_peak
            }
            
            mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_ONLINE"))
            querydbresultsmemory = mg.find({f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" })
            findnamespacememory = [x for x in querydbresultsmemory]
            if len(findnamespacememory) == 0:                                
                mg.add_data(data=detailnamespace_max_peak)
            else:
                mg.update_one(
                    { f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" },
                    
                    { '$set': {
                        f"uid": uid,
                        f"namespace": docu['namespace'],
                        f"region": docu['region'],
                        f"cluster": docu['cluster'],
                        f"max_peak_useCPU": max_peak_useCPU,
                        f"max_peak_averageCPU": max_peak_averageCPU,
                        f"max_peak_useMEM": max_peak_useMEM,
                        f"max_peak_averageMEM": max_peak_averageMEM,
                        f"max_peak_requestCPU": max_peak_requestCPU,
                        f"max_peak_requestMEM": max_peak_requestMEM,
                        f"max_peak_limitCPU": max_peak_limitCPU,
                        f"max_peak_limitMEM": max_peak_limitMEM,
                        f"max_peak_riskCPU": max_peak_riskCPU,
                        f"max_peak_riskMemory": max_peak_riskMemory,
                        f"max_peak_optimizationCPU": max_peak_optimizationCPU,
                        f"max_peak_optimizationMemory": max_peak_optimizationMemory,
                        f"marcador": marcador,
                        f"microservices": detailmicro_max_peak }
                    }
                    )
            return detailnamespace_max_peak
        else:
            mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_ONLINE"))
            mg.delete_one({f"namespace": docu['namespace']})

    elif indicador == 'microservice':
        microservices = []
        micListMaxPeak = []
        for doc in docu['date']:
            microserv = doc['microservices']
            for m in microserv:
                uidMicro = m['uid']
                mi = m['microservice']
                lastChar = mi[-2] + mi[-1]
                if '-b-' in mi or '-g-' in mi:
                    microsinsuf = mi
                elif "-green" in mi:
                    microsinsuf = mi[:-6]
                #elif "-g" in mi:
                    #microsinsuf = mi[:-2]
                elif "-blue" in mi:
                    microsinsuf = mi[:-5]
                elif lastChar == '-b' or lastChar == '-g':
                    microsinsuf = mi[:-2]
                #elif "-b" in mi:
                    #microsinsuf = mi[:-2]
                else:
                    microsinsuf = m["microservice"]

                m["microservice"] = microsinsuf
                
                microservices.append(m)

        for mic in microservices:
            uidMicro = mic['uid']
            microserv = mic['microservice']
            logger.info(f"Microservice: {microserv}")
            micrList = [dato for dato in microservices if dato['microservice'] == microserv]
            hpaMic = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['hpa']
            if hpaMic == None:
                replicas = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['replicasMicroservice']
            else:
                replicas = hpaMic['maxReplicas']
            microservicesPeakCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalUseMicroserviceCPU']
            microservicesPeakCPUAverage = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['AverageUseMicroserviceCPU']
            microservicesriskCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalRiskCPUMicroservice']
            microservicesOptimizationCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalOptimizationCPUMicroservice']
            microservicesRequestCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalRequestMicroserviceCPU']
            microservicesLimitCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalLimitMicroserviceCPU']
            microservicesLimitCPUIndividual = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['cpuLimitMicroservice']
            microservicesPeakMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalUseMicroserviceMEM']
            microservicesPeakMEMAverage = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['averageUseMicroserviceMEM']
            microserviceRiskMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalRiskMemoryMicroservice']
            microserviceOptmizationMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalOptimizationMemoryMicroservice']
            microserviceRequestMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalRequestMicroserviceMEM']
            microserviceLimitMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalLimitMicroserviceMEM']
            microservicesLimitMEMIndividual = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['memoryLimitMicroservice']
            if os.getenv("ENTITY_ID") == "spain":
                possibleCausesCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['possibleCasesCPU']
                possibleCausesMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['possibleCasesMEM']
            else:
                possibleCausesCPU = None
                possibleCausesMEM = None
            averageLivePodCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['averageLivePod']
            averageLivePodMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['averageLivePod']
            podsC = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['pods']
            podsM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['pods']

            poods = []

            if len(podsC) >= len(podsM):
                for pC in podsC:
                    podC = pC['Pod']
                    logger.info(f"PodC1: {podC}")
                    
                    restart = pC['restartPod']
                    lifeTimePod = pC['lifeTimePod']
                    cpuRequestPod = pC['cpuRequestPod']
                    cpuLimitPod = pC['cpuLimitPod']
                    useC = pC['use']

                    if len(useC) == 0:
                        CPUUsage = 0
                        OptimizationCPUPod = 0
                        RiskCPUPod = 0
                    else:
                        CPUUsage = useC['CPUUsage']
                        OptimizationCPUPod = useC['OptimizationCPUPod']
                        RiskCPUPod = useC['RiskCPUPod']

                        data = [dato for dato in podsM if dato['Pod'] == podC]
                        if len(data) != 0:

                            memoryRequestPod = data[0]['memoryRequestPod']
                            memoryLimitPod = data[0]['memoryLimitPod']
                            useM = data[0]['use']

                            if len(useM) == 0:
                                MemoryUsageCache = 0
                                OptimizationMemoryPod = 0
                                RiskMemoryPod = 0
                            else:
                                MemoryUsageCache = useM['MemoryUsage+Cache']
                                OptimizationMemoryPod = useM['OptimizationMemoryPod']
                                RiskMemoryPod = useM['RiskMemoryPod']

                                use = {
                                    "CPUUsage": CPUUsage,
                                    "OptimizationCPUPod": OptimizationCPUPod,
                                    "RiskCPUPod": RiskCPUPod,
                                    "MemoryUsage+Cache": MemoryUsageCache,
                                    "OptimizationMemoryPod": OptimizationMemoryPod,
                                    "RiskMemoryPod": RiskMemoryPod
                                }

                                podDict = {
                                    "PodCPU": podC,
                                    "PodMEM": data[0]['Pod'],
                                    "Pod": podC,
                                    "restartPod": restart,
                                    "lifeTimePod": lifeTimePod,
                                    "cpuRequestPod": cpuRequestPod,
                                    "cpuLimitPod": cpuLimitPod,
                                    "memoryRequestPod": memoryRequestPod,
                                    "memoryLimitPod": memoryLimitPod,
                                    "use": use
                                }

                                poods.append(podDict)


                        else:
                            for pM in podsM:
                                podM = pM['Pod']
                                logger.info(f"PodM1: {podM}")
                                restart = pM['restartPod']
                                dati = data = [dato for dato in poods if dato['PodMEM'] == podM]
                                if len(dati) != 0:
                                    pass
                                else:
                                    memoryRequestPod = pM['memoryRequestPod']
                                    memoryLimitPod = pM['memoryLimitPod']
                                    useM = pM['use']
                                    if len(useM) == 0:
                                        MemoryUsageCache = 0
                                        OptimizationMemoryPod = 0
                                        RiskMemoryPod = 0
                                    else:
                                        MemoryUsageCache = useM['MemoryUsage+Cache']
                                        OptimizationMemoryPod = useM['OptimizationMemoryPod']
                                        RiskMemoryPod = useM['RiskMemoryPod']

                                        use = {
                                            "CPUUsage": CPUUsage,
                                            "OptimizationCPUPod": OptimizationCPUPod,
                                            "RiskCPUPod": RiskCPUPod,
                                            "MemoryUsage+Cache": MemoryUsageCache,
                                            "OptimizationMemoryPod": OptimizationMemoryPod,
                                            "RiskMemoryPod": RiskMemoryPod
                                        }

                                        podDict = {
                                            "PodCPU": podC,
                                            "PodMEM": podM,
                                            "Pod": podC + ' // ' + podM,
                                            "restartPod": restart,
                                            "lifeTimePod": lifeTimePod,
                                            "cpuRequestPod": cpuRequestPod,
                                            "cpuLimitPod": cpuLimitPod,
                                            "memoryRequestPod": memoryRequestPod,
                                            "memoryLimitPod": memoryLimitPod,
                                            "use": use
                                        }

                                        poods.append(podDict)
                                        break
            else:
                for pM in podsM:
                    podM = pM['Pod']
                    logger.info(f"PodM2: {podM}")
                    restart = pM['restartPod']
                    lifeTimePod = pM['lifeTimePod']
                    memoryRequestPod = pM['memoryRequestPod']
                    memoryLimitPod = pM['memoryLimitPod']
                    useM = pM['use']

                    if len(useM) == 0:
                        MemoryUsageCache = 0
                        OptimizationMemoryPod = 0
                        RiskMemoryPod = 0
                    else:
                        MemoryUsageCache = useM['MemoryUsage+Cache']
                        OptimizationMemoryPod = useM['OptimizationMemoryPod']
                        RiskMemoryPod = useM['RiskMemoryPod']


                        data = [dato for dato in podsC if dato['Pod'] == podM]
                        if len(data) != 0:

                            cpuRequestPod = data[0]['cpuRequestPod']
                            cpuLimitPod = data[0]['cpuLimitPod']
                            useC = data[0]['use']

                            if len(useC) == 0:
                                CPUUsage = 0
                                OptimizationCPUPod = 0
                                RiskCPUPod = 0
                            else:
                                CPUUsage = useC['CPUUsage']
                                OptimizationCPUPod = useC['OptimizationCPUPod']
                                RiskCPUPod = useC['RiskCPUPod']

                                use = {
                                    "CPUUsage": CPUUsage,
                                    "OptimizationCPUPod": OptimizationCPUPod,
                                    "RiskCPUPod": RiskCPUPod,
                                    "MemoryUsage+Cache": MemoryUsageCache,
                                    "OptimizationMemoryPod": OptimizationMemoryPod,
                                    "RiskMemoryPod": RiskMemoryPod
                                }

                                podDict = {
                                    "PodCPU": data[0]['Pod'],
                                    "PodMEM": podM,
                                    "Pod": podM,
                                    "restartPod": restart,
                                    "lifeTimePod": lifeTimePod,
                                    "cpuRequestPod": cpuRequestPod,
                                    "cpuLimitPod": cpuLimitPod,
                                    "memoryRequestPod": memoryRequestPod,
                                    "memoryLimitPod": memoryLimitPod,
                                    "use": use
                                }

                                poods.append(podDict)


                        else:
                            for pC in podsC:
                                podC = pC['Pod']
                                logger.info(f"PodC2: {podC}")
                                restart = pC['restartPod']
                                dati = data = [dato for dato in poods if dato['PodCPU'] == podC]
                                if len(dati) != 0:
                                    pass
                                else:
                                    cpuRequestPod = pC['cpuRequestPod']
                                    cpuLimitPod = pC['cpuLimitPod']
                                    useC = pC['use']
                                    if len(useC) == 0:
                                        CPUUsage = 0
                                        OptimizationCPUPod = 0
                                        RiskCPUPod = 0
                                    else:
                                        CPUUsage = useC['CPUUsage']
                                        OptimizationCPUPod = useC['OptimizationCPUPod']
                                        RiskCPUPod = useC['RiskCPUPod']

                                        use = {
                                            "CPUUsage": CPUUsage,
                                            "OptimizationCPUPod": OptimizationCPUPod,
                                            "RiskCPUPod": RiskCPUPod,
                                            "MemoryUsage+Cache": MemoryUsageCache,
                                            "OptimizationMemoryPod": OptimizationMemoryPod,
                                            "RiskMemoryPod": RiskMemoryPod
                                        }

                                        podDict = {
                                            "PodCPU": podC,
                                            "PodMEM": podM,
                                            "Pod": podC + ' // ' + podM,
                                            "restartPod": restart,
                                            "lifeTimePod": lifeTimePod,
                                            "cpuRequestPod": cpuRequestPod,
                                            "cpuLimitPod": cpuLimitPod,
                                            "memoryRequestPod": memoryRequestPod,
                                            "memoryLimitPod": memoryLimitPod,
                                            "use": use
                                        }

                                        poods.append(podDict)
                                        break                            
            if microservicesLimitCPU == 0:
                percentajeFreeCPU = 'N/A'
            else:
                percentajeFreeCPU = round((microservicesriskCPU * 100)/microservicesLimitCPU,1)

            if microserviceLimitMEM == 0:
                percentajeFreeMEM = 'N/A'
            else:
                percentajeFreeMEM = round((microserviceRiskMEM * 100)/microserviceLimitMEM,1)

            microserviceRiskMEMPromedio = microservicesLimitMEMIndividual - microservicesPeakMEMAverage

            micDictMaxPeak = {
                "uid": uidMicro,
                "microservice": microserv,
                "region": docu['region'],
                "replicasMax": replicas,
                "max_peak_useCPU": microservicesPeakCPU,
                "max_peak_averageCPU": microservicesPeakCPUAverage,
                "riskCPU": microservicesriskCPU,
                "optimizationCPU": microservicesOptimizationCPU,
                "requestCPU": microservicesRequestCPU,
                "limitCPU": microservicesLimitCPU,
                "limitCPUIndividual": microservicesLimitCPUIndividual,
                "max_peak_useMEM": microservicesPeakMEM,
                "max_peak_averageMEM": microservicesPeakMEMAverage,
                "riskMEM": microserviceRiskMEM,
                "optimizationMEM": microserviceOptmizationMEM,
                "requestMEM": microserviceRequestMEM,
                "riskMEMPromedio": microserviceRiskMEMPromedio,
                "limitMEM": microserviceLimitMEM,
                "limitMEMIndividual": microservicesLimitMEMIndividual,
                "percentajeFreeCPU": percentajeFreeCPU,
                "percentajeFreeMEM": percentajeFreeMEM,
                "averageLivePodCPU": averageLivePodCPU,
                "averageLivePodMEM": averageLivePodMEM,
                "pods": poods,
                "possibleCausesCPU": possibleCausesCPU,
                "possibleCausesMEM": possibleCausesMEM
            }
            micListMaxPeak.append(micDictMaxPeak)

        micListMaxPeakUnicos = []
        uidTemp = []
        uidTempUnicos = []
        #[micListMaxPeakUnicos.append(dato) for dato in micListMaxPeak if dato not in micListMaxPeakUnicos]
        for dato in micListMaxPeak:
            uidTempDict = {
                "uid": dato['uid'],
                "microservice": dato['microservice']
            }
            uidTemp.append(uidTempDict)
            del dato['uid']
            if dato not in micListMaxPeakUnicos:
                micListMaxPeakUnicos.append(dato)
        [uidTempUnicos.append(dato) for dato in uidTemp if dato not in uidTempUnicos] 
        for micUnico in micListMaxPeakUnicos:
            nomMic = micUnico['microservice']
            for ud in uidTempUnicos:
                namMic = ud['microservice']
                if nomMic == namMic:
                    micUnico['uid'] = ud['uid']
                    break

        detailnamespace_max_peak = {
            "namespace": docu['namespace'],
            "region": docu['region'],
            "cluster": docu['cluster'],
            "microservices": micListMaxPeakUnicos
        }
        
        mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE"))
        querydbresultsmemory = mg.find({f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" })
        findnamespacememory = [x for x in querydbresultsmemory]
        if len(findnamespacememory) == 0:                                
            mg.add_data(data=detailnamespace_max_peak)
        else:
            mg.update_one(
                { f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" },
                
                { '$set': {
                    f"namespace": docu['namespace'],
                    f"region": docu['region'],
                    f"cluster": docu['cluster'],
                    f"microservices": micListMaxPeakUnicos
                    }
                }
                )

        return detailnamespace_max_peak
    
    elif indicador == 'online-microservice':
        microservices = []
        micListMaxPeak = []

        date = docu['date']
        day = await dayweek()
        di = False
        for d in date:
            dia = d['nameday']
            if day == dia:
                di = True
                break

        if di == True:
            for d in date:
                dia = d['nameday']
                if day == dia:

                    #for doc in docu[dia]:
                    microservices = d['microservices']
                    '''
                    for m in microserv:
                        mi = m['microservice']
                        if '-b-' in mi or '-g-' in mi:
                            microsinsuf = mi
                        elif "-green" in mi:
                            microsinsuf = mi[:-6]
                        elif "-g" in mi:
                            microsinsuf = mi[:-2]
                        elif "-blue" in mi:
                            microsinsuf = mi[:-5]
                        elif "-b" in mi:
                            microsinsuf = mi[:-2]
                        else:
                            microsinsuf = m["microservice"]

                        m["microservice"] = microsinsuf
                        
                        microservices.append(m)
                        '''
                    for mic in microservices:
                        uidMicro = mic['uid']
                        microserv = mic['microservice']
                        micrList = [dato for dato in microservices if dato['microservice'] == microserv]
                        hpaMic = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['hpa']
                        if hpaMic == None:
                            replicas = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['replicasMicroservice']
                        else:
                            replicas = hpaMic['maxReplicas']
                        microservicesPeakCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalUseMicroserviceCPU']
                        microservicesPeakCPUAverage = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['AverageUseMicroserviceCPU']
                        microservicesriskCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalRiskCPUMicroservice']
                        microservicesOptimizationCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalOptimizationCPUMicroservice']
                        microservicesRequestCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalRequestMicroserviceCPU']
                        microservicesLimitCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['totalLimitMicroserviceCPU']
                        microservicesLimitCPUIndividual = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['cpuLimitMicroservice']
                        microservicesPeakMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalUseMicroserviceMEM']
                        microservicesPeakMEMAverage = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['averageUseMicroserviceMEM']
                        microserviceRiskMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalRiskMemoryMicroservice']
                        microserviceOptmizationMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalOptimizationMemoryMicroservice']
                        microserviceRequestMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalRequestMicroserviceMEM']
                        microserviceLimitMEM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['totalLimitMicroserviceMEM']
                        microservicesLimitMEMIndividual = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['memoryLimitMicroservice']
                        if os.getenv("ENTITY_ID") == "spain":
                            possibleCausesCPU = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['possibleCasesCPU']
                            possibleCausesMEM = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['possibleCasesMEM']
                        else:
                            possibleCausesCPU = None
                            possibleCausesMEM = None
                        podsC = max(micrList, key=lambda x:x['totalUseMicroserviceCPU'])['pods']
                        podsM = max(micrList, key=lambda x:x['totalUseMicroserviceMEM'])['pods']


                        poods = []
                        for pC in podsC:
                            podC = pC['Pod']
                            cpuRequestPod = pC['cpuRequestPod']
                            cpuLimitPod = pC['cpuLimitPod']
                            useC = pC['use']

                            if len(useC) == 0:
                                CPUUsage = 0
                                OptimizationCPUPod = 0
                                RiskCPUPod = 0
                            else:
                                CPUUsage = useC['CPUUsage']
                                OptimizationCPUPod = useC['OptimizationCPUPod']
                                RiskCPUPod = useC['RiskCPUPod']

                                for pM in podsM:
                                    podM = pM['Pod']
                                    if podC == podM:
                                        memoryRequestPod = pM['memoryRequestPod']
                                        memoryLimitPod = pM['memoryLimitPod']
                                        useM = pM['use']

                                        if len(useC) == 0:
                                            MemoryUsageCache = 0
                                            OptimizationMemoryPod = 0
                                            RiskMemoryPod = 0
                                        else:
                                            MemoryUsageCache = useM['MemoryUsage+Cache']
                                            OptimizationMemoryPod = useM['OptimizationMemoryPod']
                                            RiskMemoryPod = useM['RiskMemoryPod']

                                            use = {
                                                "CPUUsage": CPUUsage,
                                                "OptimizationCPUPod": OptimizationCPUPod,
                                                "RiskCPUPod": RiskCPUPod,
                                                "MemoryUsage+Cache": MemoryUsageCache,
                                                "OptimizationMemoryPod": OptimizationMemoryPod,
                                                "RiskMemoryPod": RiskMemoryPod
                                            }

                                            podDict = {
                                                "Pod": podC,
                                                "cpuRequestPod": cpuRequestPod,
                                                "cpuLimitPod": cpuLimitPod,
                                                "memoryRequestPod": memoryRequestPod,
                                                "memoryLimitPod": memoryLimitPod,
                                                "use": use
                                            }

                                            poods.append(podDict)

                        if microservicesLimitCPUIndividual == 0:
                            percentajeFreeCPU = 'N/A'
                        else:
                            percentajeFreeCPU = round(100 - ((microservicesPeakCPU / (microservicesLimitCPUIndividual * replicas)) * 100),1)

                        if microservicesLimitMEMIndividual == 0:
                            percentajeFreeMEM = 'N/A'
                        else:
                            percentajeFreeMEM = round(100 - ((microservicesPeakMEM / (microservicesLimitMEMIndividual * replicas)) * 100),1)

                        micDictMaxPeak = {
                            "uid": uidMicro,
                            "microservice": microserv,
                            "region": docu['region'],
                            "replicasMax": replicas,
                            "max_peak_useCPU": microservicesPeakCPU,
                            "max_peak_averageCPU": microservicesPeakCPUAverage,
                            "riskCPU": microservicesriskCPU,
                            "optimizationCPU": microservicesOptimizationCPU,
                            "requestCPU": microservicesRequestCPU,
                            "limitCPU": microservicesLimitCPU,
                            "limitCPUIndividual": microservicesLimitCPUIndividual,
                            "max_peak_useMEM": microservicesPeakMEM,
                            "max_peak_averageMEM": microservicesPeakMEMAverage,
                            "riskMEM": microserviceRiskMEM,
                            "optimizationMEM": microserviceOptmizationMEM,
                            "requestMEM": microserviceRequestMEM,
                            "limitMEM": microserviceLimitMEM,
                            "limitMEMIndividual": microservicesLimitMEMIndividual,
                            "percentajeFreeCPU": percentajeFreeCPU,
                            "percentajeFreeMEM": percentajeFreeMEM,
                            "pods": poods,
                            "possibleCausesCPU": possibleCausesCPU,
                            "possibleCausesMEM": possibleCausesMEM
                        }
                        micListMaxPeak.append(micDictMaxPeak)

                    micListMaxPeakUnicos = []
                    [micListMaxPeakUnicos.append(dato) for dato in micListMaxPeak if dato not in micListMaxPeakUnicos]

                    detailnamespace_max_peak = {
                        "namespace": docu['namespace'],
                        "region": docu['region'],
                        "cluster": docu['cluster'],
                        "microservices": micListMaxPeakUnicos
                    }
                    
                    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_ONLINE"))
                    querydbresultsmemory = mg.find({f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" })
                    findnamespacememory = [x for x in querydbresultsmemory]
                    if len(findnamespacememory) == 0:                                
                        mg.add_data(data=detailnamespace_max_peak)
                    else:
                        mg.update_one(
                            { f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" },
                            
                            { '$set': {
                                f"namespace": docu['namespace'],
                                f"region": docu['region'],
                                f"cluster": docu['cluster'],
                                f"microservices": micListMaxPeakUnicos
                                }
                            }
                            )

                    return detailnamespace_max_peak
    
    else:
        detailmicro_max_peak_CPU = []
        detailmicro_max_peak_MEM = []
        detailmicro_max_peak = []
        max_peak_useCPU = max(docu['date'], key=lambda x:x['totalUseNamespaceCPU'])['totalUseNamespaceCPU']
        max_peak_averageCPU = max(docu['date'], key=lambda x:x['totalAverageNamespaceCPU'])['totalAverageNamespaceCPU']
        max_peak_useMEM = max(docu['date'], key=lambda x:x['totalUseNamespaceMEM'])['totalUseNamespaceMEM']
        max_peak_averageMEM = max(docu['date'], key=lambda x:x['totalAverageNamespaceMEM'])['totalAverageNamespaceMEM']
        max_peak_requestCPU = max(docu['date'], key=lambda x:x['totalRequestNamespaceCPU'])['totalRequestNamespaceCPU']
        max_peak_requestMEM = max(docu['date'], key=lambda x:x['totalRequestNamespaceMEM'])['totalRequestNamespaceMEM']
        max_peak_limitCPU = max(docu['date'], key=lambda x:x['totalLimitNamespaceCPU'])['totalLimitNamespaceCPU']
        max_peak_limitMEM = max(docu['date'], key=lambda x:x['totalLimitNamespaceMEM'])['totalLimitNamespaceMEM']

        max_peak_riskCPU = round((max_peak_limitCPU - max_peak_useCPU) ,3)
        max_peak_riskMemory = round((max_peak_limitMEM - max_peak_useMEM) ,3)
        max_peak_optimizationCPU = round((max_peak_requestCPU - max_peak_useCPU) ,3)
        max_peak_optimizationMemory = round((max_peak_requestMEM - max_peak_useMEM) ,3)

        microservicesPeakCPU = max(docu['date'], key=lambda x:x['totalUseNamespaceCPU'])['microservices']
        for micro in microservicesPeakCPU:
            try:
                uidMicro = micro['uid']
                microservice = micro['microservice']
                if micro['hpa'] == None:
                    replicasCPU = micro['replicasMicroservice']
                else:
                    hpa = micro['hpa']
                    replicasCPU = hpa['maxReplicas']
                max_peak_useCPUMic = micro['totalUseMicroserviceCPU']
                max_peak_averageCPUMic = micro['AverageUseMicroserviceCPU']
                requestCPU = micro['totalRequestMicroserviceCPU']
                limitCPU = micro['totalLimitMicroserviceCPU']
                limitCPUIndividual = micro['cpuLimitMicroservice']
                optimizationCPU = micro['totalOptimizationCPUMicroservice']
                riskCPU = micro ['totalRiskCPUMicroservice']
                podsCPU = micro['pods']
                if os.getenv("ENTITY_ID") == "spain":
                    possibleCausesCPU = micro['possibleCasesCPU']
                    possibleCausesMEM = micro['possibleCasesMEM']
                else:
                    possibleCausesCPU = None
                    possibleCausesMEM = None

                detailmicroservice_max_peak_CPU = {
                    "uid": uidMicro,
                    "microservice": microservice,
                    "replicasCPU": replicasCPU,
                    "max_peak_useCPUMic": max_peak_useCPUMic,
                    "max_peak_averageCPUMic": max_peak_averageCPUMic,
                    "requestCPU": requestCPU,
                    "limitCPU": limitCPU,
                    "limitCPUIndividual": limitCPUIndividual,
                    "optimizationCPU": optimizationCPU,
                    "riskCPU": riskCPU,
                    "podsCPU": podsCPU,
                    "possibleCausesCPU": possibleCausesCPU,
                    "possibleCausesMEM": possibleCausesMEM
                }
                detailmicro_max_peak_CPU.append(detailmicroservice_max_peak_CPU)
            except:
                logger.info(f"Something has gone wrong in microservicesPeakCPU")
                continue
        
        microservicesPeakMEM = max(docu['date'], key=lambda x:x['totalUseNamespaceMEM'])['microservices']
        for micro in microservicesPeakMEM:
            try:
                uidMicro = micro['uid']
                microservice = micro['microservice']
                if micro['hpa'] == None:
                    replicasMEM = micro['replicasMicroservice']
                else:
                    hpa = micro['hpa']
                    replicasMEM = hpa['maxReplicas']
                max_peak_useMEMMic = micro['totalUseMicroserviceMEM']
                max_peak_averageMEMMic = micro['averageUseMicroserviceMEM']
                requestMEM = micro['totalRequestMicroserviceMEM']
                limitMEM = micro ['totalLimitMicroserviceMEM']
                limitMEMIndividual = micro['memoryLimitMicroservice']
                optimizationMEM = micro['totalOptimizationMemoryMicroservice']
                riskMEM = micro ['totalRiskMemoryMicroservice']
                podsMEM = micro['pods']

                detailmicroservice_max_peak_MEM = {
                    "uid": uidMicro,
                    "microservice": microservice,
                    "replicasMEM": replicasMEM,
                    "max_peak_useMEMMic": max_peak_useMEMMic,
                    "max_peak_averageMEMMic": max_peak_averageMEMMic,
                    "requestMEM": requestMEM,
                    "limitMEM": limitMEM,
                    "limitMEMIndividual": limitMEMIndividual,
                    "optimizationMEM": optimizationMEM,
                    "riskMEM": riskMEM,
                    "podsMEM": podsMEM
                }
                detailmicro_max_peak_MEM.append(detailmicroservice_max_peak_MEM)
            except:
                logger.info(f"Something has gone wrong in microservicesPeakMEM")
                continue

        
        for datoCPU in detailmicro_max_peak_CPU:
            try:
                microserCPU = datoCPU['microservice']
                cpuPods = datoCPU['podsCPU']
                if "-green" in microserCPU:
                    microCPUSinSufijo = microserCPU[:-6]
                elif "-g" in microserCPU:
                    microCPUSinSufijo = microserCPU[:-2]
                elif "-blue" in microserCPU:
                    microCPUSinSufijo = microserCPU[:-5]
                elif "-b" in microserCPU:
                    microCPUSinSufijo = microserCPU[:-2]
                else:
                    microCPUSinSufijo = datoCPU["microservice"]

                for datoMEM in detailmicro_max_peak_MEM:
                    try:
                        microserMEM = datoMEM['microservice']
                        memPods = datoMEM['podsMEM']
                        if "-green" in microserMEM:
                            microMEMSinSufijo = microserMEM[:-6]
                        elif "-g" in microserMEM:
                            microMEMSinSufijo = microserMEM[:-2]
                        elif "-blue" in microserMEM:
                            microMEMSinSufijo = microserMEM[:-5]
                        elif "-b" in microserMEM:
                            microMEMSinSufijo = microserMEM[:-2]
                        else:
                            microMEMSinSufijo = datoMEM["microservice"]

                        poods = []
                        if microCPUSinSufijo == microMEMSinSufijo:
                            microser = microserCPU
                            if datoCPU['replicasCPU'] == datoMEM['replicasMEM']:
                                replicas = datoCPU['replicasCPU']
                            else:
                                replicas = "error"
                            max_peak_useCPUMicroser = datoCPU['max_peak_useCPUMic']
                            max_peak_averageCPUMicroser = datoCPU['max_peak_averageCPUMic']
                            requestCPUMicroser = datoCPU['requestCPU']
                            limitCPUMicroser = datoCPU ['limitCPU']
                            limitCPUMicroserIndividual = datoCPU ['limitCPUIndividual']
                            optimizationCPUMicroser = datoCPU['optimizationCPU']
                            riskCPUMicroser = datoCPU ['riskCPU']
                            max_peak_useMEMMicroser = datoMEM['max_peak_useMEMMic']
                            max_peak_averageMEMMicroser = datoMEM['max_peak_averageMEMMic']
                            requestMEMMicroser = datoMEM['requestMEM']
                            limitMEMMicroser = datoMEM ['limitMEM']
                            limitMEMMicroserIndividual = datoMEM ['limitMEMIndividual']
                            optimizationMEMMicroser = datoMEM['optimizationMEM']
                            riskMEMMimcroser = datoMEM ['riskMEM']
                            
                            for pC in cpuPods:
                                podC = pC['Pod']
                                cpuRequestPod = pC['cpuRequestPod']
                                cpuLimitPod = pC['cpuLimitPod']
                                useC = pC['use']

                                CPUUsage = useC['CPUUsage']
                                OptimizationCPUPod = useC['OptimizationCPUPod']
                                RiskCPUPod = useC['RiskCPUPod']

                                for pM in memPods:
                                    podM = pM['Pod']
                                    if podC == podM:
                                        memoryRequestPod = pM['memoryRequestPod']
                                        memoryLimitPod = pM['memoryLimitPod']
                                        useM = pM['use']

                                        MemoryUsageCache = useM['MemoryUsage+Cache']
                                        OptimizationMemoryPod = useM['OptimizationMemoryPod']
                                        RiskMemoryPod = useM['RiskMemoryPod']

                                        use = {
                                            "CPUUsage": CPUUsage,
                                            "OptimizationCPUPod": OptimizationCPUPod,
                                            "RiskCPUPod": RiskCPUPod,
                                            "MemoryUsage+Cache": MemoryUsageCache,
                                            "OptimizationMemoryPod": OptimizationMemoryPod,
                                            "RiskMemoryPod": RiskMemoryPod
                                        }

                                        podDict = {
                                            "Pod": podC,
                                            "cpuRequestPod": cpuRequestPod,
                                            "cpuLimitPod": cpuLimitPod,
                                            "memoryRequestPod": memoryRequestPod,
                                            "memoryLimitPod": memoryLimitPod,
                                            "use": use
                                        }

                                        poods.append(podDict)

                            pods = poods

                            if riskCPU < 750 or riskMEM < 500:
                                marcador = True
                                                        
                            if optimizationCPU < -80 or optimizationCPU > 80:
                                marcador = True

                            if optimizationMEM < -500 or optimizationMEM > 500:
                                marcador = True

                            percentajeFreeCPU = round((riskCPUMicroser * 100)/limitCPUMicroser,1)
                            percentajeFreeMEM = round((riskMEMMimcroser * 100)/limitMEMMicroser,1)

                            detailmicroservice_max_peak = {
                                "uid": uidMicro,
                                "microservice": microser,
                                "replicasMax": replicas,
                                "max_peak_useCPU": max_peak_useCPUMicroser,
                                "max_peak_averageCPU": max_peak_averageCPUMicroser,
                                "max_peak_useMEM": max_peak_useMEMMicroser,
                                "max_peak_averageMEM": max_peak_averageMEMMicroser,
                                "requestCPU": requestCPUMicroser,
                                "requestMEM": requestMEMMicroser,
                                "limitCPU": limitCPUMicroser,
                                "limitCPUIndividual": limitCPUMicroserIndividual,
                                "limitMEM": limitMEMMicroser,
                                "limitMEMIndividual": limitMEMMicroserIndividual,
                                "optimizationCPU": optimizationCPUMicroser,
                                "optimizationMEM": optimizationMEMMicroser,
                                "riskCPU": riskCPUMicroser,
                                "riskMEM": riskMEMMimcroser,
                                "percentajeFreeCPU": percentajeFreeCPU,
                                "percentajeFreeMEM": percentajeFreeMEM,
                                "pods": pods
                            }
                            detailmicro_max_peak.append(detailmicroservice_max_peak)

                            break
                    except:
                        logger.info(f"Something has gone wrong in detailmicro_max_peak_MEM")
                        continue
            except:
                logger.info(f"Something has gone wrong in detailmicro_max_peak_CPU")
                continue

        detailnamespace_max_peak = {
            "uid": uid,
            "namespace": docu['namespace'],
            "region": docu['region'],
            "cluster": docu['cluster'],
            "max_peak_useCPU": max_peak_useCPU,
            "max_peak_averageCPU": max_peak_averageCPU,
            "max_peak_useMEM": max_peak_useMEM,
            "max_peak_averageMEM": max_peak_averageMEM,
            "max_peak_requestCPU": max_peak_requestCPU,
            "max_peak_requestMEM": max_peak_requestMEM,
            "max_peak_limitCPU": max_peak_limitCPU,
            "max_peak_limitMEM": max_peak_limitMEM,
            "max_peak_riskCPU": max_peak_riskCPU,
            "max_peak_riskMemory": max_peak_riskMemory,
            "max_peak_optimizationCPU": max_peak_optimizationCPU,
            "max_peak_optimizationMemory": max_peak_optimizationMemory,
            "marcador": marcador,
            "microservices": detailmicro_max_peak
        }
        
        mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK"))
        querydbresultsmemory = mg.find({f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" })
        findnamespacememory = [x for x in querydbresultsmemory]
        if len(findnamespacememory) == 0:                                
            mg.add_data(data=detailnamespace_max_peak)
        else:
            mg.update_one(
                { f"namespace": docu['namespace'], f"cluster":f"{docu['cluster']}", f"region":f"{docu['region']}" },
                
                { '$set': {
                    f"uid": uid,
                    f"namespace" : docu['namespace'],
                    f"region" :  docu['region'],
                    f"cluster": docu['cluster'],
                    f"max_peak_useCPU": max_peak_useCPU,
                    f"max_peak_averageCPU": max_peak_averageCPU,
                    f"max_peak_useMEM": max_peak_useMEM,
                    f"max_peak_averageMEM": max_peak_averageMEM,
                    f"max_peak_requestCPU": max_peak_requestCPU,
                    f"max_peak_requestMEM": max_peak_requestMEM,
                    f"max_peak_limitCPU": max_peak_limitCPU,
                    f"max_peak_limitMEM": max_peak_limitMEM,
                    f"max_peak_riskCPU": max_peak_riskCPU,
                    f"max_peak_riskMemory": max_peak_riskMemory,
                    f"max_peak_optimizationCPU": max_peak_optimizationCPU,
                    f"max_peak_optimizationMemory": max_peak_optimizationMemory,
                    f"marcador": marcador,
                    f"microservices": detailmicro_max_peak
                    }
                }
                )

        return detailnamespace_max_peak


async def getDescriptionLastPeak():
    logger.debug(f'Getting descriptions for Last Peak')

    DesctiptionsLastPeak = [
        {
            "nametoshow": "Use CPU (95th Percentile)",
            "description": f"Total CPU used per namespace or microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "Use Memory (max+cache)",
            "description": f"Total memory used per namespace or microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "Request CPU",
            "description": f"Total CPU reservation per namespace or microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "Request Memory",
            "description": f"Total memory reservation per namespace or microservice.",
            "subdescription": ""         
        },{
            "nametoshow": "Limit CPU",
            "description": "Total limit CPU per namespace or microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "Limit Memory",
            "description": "Total limit memory per namespace or microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "Optimization CPU",
            "description": "Total theoretical CPU savings that could be achieved at the namespace or microservice level if the reserve is optimized versus use. Subtract usage from request.",
            "subdescription": "CPU Optimization column in red when the value is less than -100 and greater than 100." 
        },{
            "nametoshow": "Optimization Memory",
            "description": "Total theoretical memory savings that could be achieved at the namespace or microservice level if the reservation is optimized versus use. Subtract usage from request.",
            "subdescription": "Memory Optimization column in red when the value is less than -750 and greater than 750." 
        },{
            "nametoshow": "Risk CPU",
            "description": "Indicates the total amount of CPU limit that we have left before exhausting all resources at the namespace or microservice level. Subtract usage from limit.",
            "subdescription": "CPU Risk column in red when the value is less than 400." 
        },{
            "nametoshow": "Risk Memory",
            "description": "Indicates the total amount of memory limit that we have left before exhausting all resources at the namespace or microservice level. Subtract usage from limit.",       
            "subdescription": "Memory Risk column in red when the value is less than 250." 
        }
    ]

    return DesctiptionsLastPeak


async def historicalWeekPeak():
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK5"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK4"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK5"))
    for d in datos:
        cont += 1                             
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK4"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK3"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK4"))
    for d in datos:
        cont += 1                    
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK3"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK2"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK3"))
    for d in datos:    
        cont += 1                            
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK2"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK1"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK2"))
    for d in datos:  
        cont += 1                              
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK1"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_WEEK1"))
    for d in datos:       
        cont += 1                         
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")


async def historicalWeekPeakMicroservices():
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK5"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK4"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK5"))
    for d in datos:     
        cont += 1                           
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK4"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK3"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK4"))
    for d in datos:         
        cont += 1                       
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK3"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK2"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK3"))
    for d in datos:    
        cont += 1                            
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK2"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK1"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK2"))
    for d in datos:    
        cont += 1                            
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")

    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK1"))
    mg.delete_all_data()
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE"))
    datos = mg.read_data()
    numreg = len(datos)
    cont = 0
    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE_WEEK1"))
    for d in datos:
        cont += 1                                
        mg.add_data(data=d)
        logger.info(f"Document {cont} of {numreg} recorded ok")
