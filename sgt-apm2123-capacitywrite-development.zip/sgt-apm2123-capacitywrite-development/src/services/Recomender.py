from shuttlelib.utils.logger import logger
import os, aiohttp
import json
import asyncio
from src.services.Estructural import client,mg,hpass,formatearcpu,formatearmemory,services,get_clusters,cleaning_data


async def getcapacityrecomender(cluster=None, namespace=None):
    functionalEnvironment = os.getenv("ENVIRONMENT") #set the environment where the information will be extracted
    #if cluster == None and namespace == None:
        #mg.change_collection(os.getenv("COLLECTION_RECOMENDER"))
        #mg.delete_all_data()
    
    #limpiar = await cleaning_data()
    detailNamespaceRecomenderList = []
    match cluster:
        case None:
            clusters = await client.get_resource(resource="clusters",functional_environment=functionalEnvironment,cluster=None)
            for clust in clusters:
                if clust == "azure" or clust == "dmzbazure":
                    pass
                else:
                    match namespace:
                        case None:
                            try:
                                nas= await client.get_resource(functional_environment=functionalEnvironment,cluster=clust,resource="namespaces")
                            except aiohttp.client_exceptions.ServerTimeoutError:
                                logger.error(f"Timeout detected against {clust} ")
                                nas = {}
                            namespaces = []
                            for region in nas:
                                if nas[region] == 401:
                                    pass
                                else:
                                    for space in nas[region]["items"]:
                                        names = space['metadata']['name']
                                        namespaces.append(names)

                            ns = list(set(namespaces))                     

                            for nspace in ns:
                                #namesp = nspace['metadata']['name']
                                mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE"))
                                # Find namespace/cluster/region in bbdd
                                documents = list(mg.find({f"namespace": nspace, f"cluster": clust}))
                                uso_pico_list = []
                                if documents:
                                    micros1 = None
                                    micros2 = None
                                    for docu in documents:
                                        del docu['_id']
                                        del docu['timestamp']
                                        if docu['region'] == "bo1" or docu['region'] == "weu1" or docu['region'] == "cn1" or docu['region'] == "mx1" or docu['region'] == "weu":
                                            micros1 = docu['microservices']
                                        if docu['region'] == "bo2" or docu['region'] == "weu2" or docu['region'] == "cn2" or docu['region'] == "mx2":
                                            micros2 = docu['microservices']

                                    if micros1 != None and micros2 == None:
                                        for mic1 in micros1:
                                            micro1 = mic1["microservice"]
                                            usoCPU1Total = mic1['max_peak_useCPU']
                                            usoCPU1 = mic1["max_peak_averageCPU"]
                                            usoMEM1Total = mic1['max_peak_useCPU']
                                            usoMEM1 = mic1["max_peak_useMEM"]
                                        
                                            uso_pico = {
                                                "microservice": micro1,
                                                "usoPicoCPUTotal": usoCPU1Total,
                                                "usoPicoCPU": usoCPU1,
                                                "usoPicoMEMTotal": usoMEM1Total,
                                                "usoPicoMEM": usoMEM1
                                            }
                                            uso_pico_list.append(uso_pico)
                                    
                                    if micros1 == None and micros2 !=None:
                                        for mic2 in micros2:
                                            micro2 = mic2["microservice"]
                                            usoCPU2Total = mic2['max_peak_useCPU']
                                            usoCPU2 = mic2["max_peak_averageCPU"]
                                            usoMEM2Total = mic2['max_peak_useCPU']
                                            usoMEM2 = mic2["max_peak_averageMEM"]
                                        
                                            uso_pico = {
                                                "microservice": micro2,
                                                "usoPicoCPUTotal": usoCPU2Total,
                                                "usoPicoCPU": usoCPU2,
                                                "usoPicoMEMTotal": usoMEM2Total,
                                                "usoPicoMEM": usoMEM2
                                            }
                                            uso_pico_list.append(uso_pico)
                                    
                                    if micros1 != None and micros2 !=None:
                                        if len(micros1) == len(micros2):
                                            contMicros1 = 0
                                            for mic1 in micros1:
                                                contMicros2 = 0
                                                contMicros1 += 1
                                                micro1 = mic1["microservice"]
                                                if micro1.endswith("-green"):
                                                    micro1SinSufijo = micro1[:-6]
                                                elif micro1.endswith("-g"):
                                                    micro1SinSufijo = micro1[:-2]
                                                elif micro1.endswith("-blue"):
                                                    micro1SinSufijo = micro1[:-5]
                                                elif micro1.endswith("-b"):
                                                    micro1SinSufijo = micro1[:-2]
                                                else:
                                                    micro1SinSufijo = micro1
                                                usoCPU1Total = mic1['max_peak_useCPU']
                                                usoCPU1 = mic1["max_peak_averageCPU"]
                                                usoMEM1Total = mic1['max_peak_useMEM']
                                                usoMEM1 = mic1["max_peak_averageMEM"]
                                                for mic2 in micros2:
                                                    contMicros2 += 1
                                                    micro2 = mic2["microservice"]
                                                    if micro2.endswith("-green"):
                                                        micro2SinSufijo = micro2[:-6]
                                                    elif micro2.endswith("-g"):
                                                        micro2SinSufijo = micro2[:-2]
                                                    elif micro2.endswith("-blue"):
                                                        micro2SinSufijo = micro2[:-5]
                                                    elif micro2.endswith("-b"):
                                                        micro2SinSufijo = micro2[:-2]
                                                    else:
                                                        micro2SinSufijo = micro2
                                                    usoCPU2Total = mic2['max_peak_useCPU']
                                                    usoCPU2 = mic2["max_peak_averageCPU"]
                                                    usoMEM2Total = mic2['max_peak_useMEM']
                                                    usoMEM2 = mic2["max_peak_averageMEM"]
                                                    if micro1SinSufijo == micro2SinSufijo:
                                                        if usoCPU1 > usoCPU2:
                                                            usoCPU = usoCPU1
                                                            usoCPUTotal = usoCPU1Total
                                                        elif usoCPU1 < usoCPU2:
                                                            usoCPU = usoCPU2
                                                            usoCPUTotal = usoCPU2Total
                                                        else:
                                                            usoCPU = usoCPU1
                                                            usoCPUTotal = usoCPU1Total

                                                        if usoMEM1 > usoMEM2:
                                                            usoMEM = usoMEM1
                                                            usoMEMTotal = usoMEM1Total
                                                        elif usoMEM1 < usoMEM2:
                                                            usoMEM = usoMEM2
                                                            usoMEMTotal = usoMEM2Total
                                                        else:
                                                            usoMEM = usoMEM1
                                                            usoMEMTotal = usoMEM1Total

                                                        uso_pico = {
                                                            "microservice": micro1,
                                                            "usoPicoCPUTotal": usoCPUTotal,
                                                            "usoPicoCPU": usoCPU,
                                                            "usoPicoMEMTotal": usoMEMTotal,
                                                            "usoPicoMEM": usoMEM
                                                        }
                                                        uso_pico_list.append(uso_pico)
                                                    else:
                                                        pass
                                        elif len(micros1) > len(micros2):
                                            contMicros1 = 0
                                            for mic1 in micros1:
                                                contMicros2 = 0
                                                contMicros1 += 1
                                                micro1 = mic1["microservice"]
                                                if micro1.endswith("-green"):
                                                    micro1SinSufijo = micro1[:-6]
                                                elif micro1.endswith("-g"):
                                                    micro1SinSufijo = micro1[:-2]
                                                elif micro1.endswith("-blue"):
                                                    micro1SinSufijo = micro1[:-5]
                                                elif micro1.endswith("-b"):
                                                    micro1SinSufijo = micro1[:-2]
                                                else:
                                                    micro1SinSufijo = micro1
                                                usoCPU1Total = mic1['max_peak_useCPU']
                                                usoCPU1 = mic1["max_peak_averageCPU"]
                                                usoMEM1Total = mic1['max_peak_useMEM']
                                                usoMEM1 = mic1["max_peak_averageMEM"]
                                                igual = False
                                                for mic2 in micros2:
                                                    contMicros2 += 1
                                                    micro2 = mic2["microservice"]
                                                    if micro2.endswith("-green"):
                                                        micro2SinSufijo = micro2[:-6]
                                                    elif micro2.endswith("-g"):
                                                        micro2SinSufijo = micro2[:-2]
                                                    elif micro2.endswith("-blue"):
                                                        micro2SinSufijo = micro2[:-5]
                                                    elif micro2.endswith("-b"):
                                                        micro2SinSufijo = micro2[:-2]
                                                    else:
                                                        micro2SinSufijo = micro2
                                                    usoCPU2Total = mic2['max_peak_useCPU']
                                                    usoCPU2 = mic2["max_peak_averageCPU"]
                                                    usoMEM2Total = mic2['max_peak_useMEM']
                                                    usoMEM2 = mic2["max_peak_averageMEM"]
                                                    if micro1SinSufijo == micro2SinSufijo:
                                                        igual = True
                                                        if usoCPU1 > usoCPU2:
                                                            usoCPU = usoCPU1
                                                            usoCPUTotal = usoCPU1Total
                                                        elif usoCPU1 < usoCPU2:
                                                            usoCPU = usoCPU2
                                                            usoCPUTotal = usoCPU2Total
                                                        else:
                                                            usoCPU = usoCPU1
                                                            usoCPUTotal = usoCPU1Total

                                                        if usoMEM1 > usoMEM2:
                                                            usoMEM = usoMEM1
                                                            usoMEMTotal = usoMEM1Total
                                                        elif usoMEM1 < usoMEM2:
                                                            usoMEM = usoMEM2
                                                            usoMEMTotal = usoMEM2Total
                                                        else:
                                                            usoMEM = usoMEM1
                                                            usoMEMTotal = usoMEM1Total

                                                        uso_pico = {
                                                            "microservice": micro1,
                                                            "usoPicoCPUTotal": usoCPUTotal,
                                                            "usoPicoCPU": usoCPU,
                                                            "usoPicoMEMTotal": usoMEMTotal,
                                                            "usoPicoMEM": usoMEM
                                                        }
                                                        uso_pico_list.append(uso_pico)
                                                    else:
                                                        if len(micros2) == contMicros2 and igual == False:
                                                            uso_pico = {
                                                            "microservice": micro1,
                                                            "usoPicoCPUTotal": usoCPU1Total,
                                                            "usoPicoCPU": usoCPU1,
                                                            "usoPicoMEMTotal": usoMEM1Total,
                                                            "usoPicoMEM": usoMEM1
                                                            }
                                                            uso_pico_list.append(uso_pico)
                                                            
                                        else:
                                            contMicros2 = 0
                                            for mic2 in micros2:
                                                contMicros1 = 0
                                                contMicros2 += 1
                                                micro2 = mic2["microservice"]
                                                if micro2.endswith("-green"):
                                                    micro2SinSufijo = micro2[:-6]
                                                elif micro2.endswith("-g"):
                                                    micro2SinSufijo = micro2[:-2]
                                                elif micro2.endswith("-blue"):
                                                    micro2SinSufijo = micro2[:-5]
                                                elif micro2.endswith("-b"):
                                                    micro2SinSufijo = micro2[:-2]
                                                else:
                                                    micro2SinSufijo = micro2
                                                usoCPU2Total = mic2['max_peak_useCPU']
                                                usoCPU2 = mic2["max_peak_averageCPU"]
                                                usoMEM2Total = mic2['max_peak_useMEM']
                                                usoMEM2 = mic2["max_peak_averageMEM"]
                                                igual = False
                                                for mic1 in micros1:
                                                    contMicros1 += 1
                                                    micro1 = mic1["microservice"]
                                                    if micro1.endswith("-green"):
                                                        micro1SinSufijo = micro1[:-6]
                                                    elif micro1.endswith("-g"):
                                                        micro1SinSufijo = micro1[:-2]
                                                    elif micro1.endswith("-blue"):
                                                        micro1SinSufijo = micro1[:-5]
                                                    elif micro1.endswith("-b"):
                                                        micro1SinSufijo = micro1[:-2]
                                                    else:
                                                        micro1SinSufijo = micro1
                                                    usoCPU1Total = mic1['max_peak_useCPU']
                                                    usoCPU1 = mic1["max_peak_averageCPU"]
                                                    usoMEM1Total = mic1['max_peak_useMEM']
                                                    usoMEM1 = mic1["max_peak_averageMEM"]
                                                    if micro2SinSufijo == micro1SinSufijo:
                                                        igual = True
                                                        if usoCPU2 > usoCPU1:
                                                            usoCPU = usoCPU2
                                                            usoCPUTotal = usoCPU2Total
                                                        elif usoCPU2 < usoCPU1:
                                                            usoCPU = usoCPU1
                                                            usoCPUTotal = usoCPU1Total
                                                        else:
                                                            usoCPU = usoCPU2
                                                            usoCPUTotal = usoCPU2Total

                                                        if usoMEM2 > usoMEM1:
                                                            usoMEM = usoMEM2
                                                            usoMEMTotal = usoMEM2Total
                                                        elif usoMEM2 < usoMEM1:
                                                            usoMEM = usoMEM1
                                                            usoMEMTotal = usoMEM1Total
                                                        else:
                                                            usoMEM = usoMEM2
                                                            usoMEMTotal = usoMEM2Total

                                                        uso_pico = {
                                                            "microservice": micro2,
                                                            "usoPicoCPUTotal": usoCPUTotal,
                                                            "usoPicoCPU": usoCPU,
                                                            "usoPicoMEMTotal": usoMEMTotal,
                                                            "usoPicoMEM": usoMEM
                                                        }
                                                        uso_pico_list.append(uso_pico)
                                                    else:
                                                        if len(micros1) == contMicros1 and igual == False:
                                                            uso_pico = {
                                                            "microservice": micro2,
                                                            "usoPicoCPUTotal": usoCPU2Total,
                                                            "usoPicoCPU": usoCPU2,
                                                            "usoPicoMEMTotal": usoMEM2Total,
                                                            "usoPicoMEM": usoMEM2
                                                            }
                                                            uso_pico_list.append(uso_pico)
                                                            

                                    detailNamespaceRecomenderList.append(await recomender(clust,uso_pico_list,nspace))
                                
                        case _:
                            mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE"))
                            # Find namespace/cluster/region in bbdd
                            documents = list(mg.find({f"namespace": namespace, f"cluster": clust}))
                            uso_pico_list = []
                            if documents:
                                micros1 = None
                                micros2 = None
                                for docu in documents:
                                    del docu['_id']
                                    del docu['timestamp']
                                    if docu['region'] == "bo1" or docu['region'] == "weu1" or docu['region'] == "cn1" or docu['region'] == "mx1" or docu['region'] == "weu":
                                        micros1 = docu['microservices']
                                    if docu['region'] == "bo2" or docu['region'] == "weu2" or docu['region'] == "cn2" or docu['region'] == "mx2":
                                        micros2 = docu['microservices']

                                if micros1 != None and micros2 == None:
                                    for mic1 in micros1:
                                        micro1 = mic1["microservice"]
                                        usoCPU1Total = mic1['max_peak_useCPU']
                                        usoCPU1 = mic1["max_peak_averageCPU"]
                                        usoMEM1Total = mic1['max_peak_useCPU']
                                        usoMEM1 = mic1["max_peak_useMEM"]
                                    
                                        uso_pico = {
                                            "microservice": micro1,
                                            "usoPicoCPUTotal": usoCPU1Total,
                                            "usoPicoCPU": usoCPU1,
                                            "usoPicoMEMTotal": usoMEM1Total,
                                            "usoPicoMEM": usoMEM1
                                        }
                                        uso_pico_list.append(uso_pico)
                                
                                if micros1 == None and micros2 !=None:
                                    for mic2 in micros2:
                                        micro2 = mic2["microservice"]
                                        usoCPU2Total = mic2['max_peak_useCPU']
                                        usoCPU2 = mic2["max_peak_averageCPU"]
                                        usoMEM2Total = mic2['max_peak_useCPU']
                                        usoMEM2 = mic2["max_peak_averageMEM"]
                                    
                                        uso_pico = {
                                            "microservice": micro2,
                                            "usoPicoCPUTotal": usoCPU2Total,
                                            "usoPicoCPU": usoCPU2,
                                            "usoPicoMEMTotal": usoMEM2Total,
                                            "usoPicoMEM": usoMEM2
                                        }
                                        uso_pico_list.append(uso_pico)
                                
                                if micros1 != None and micros2 !=None:
                                    if len(micros1) == len(micros2):
                                        contMicros1 = 0
                                        for mic1 in micros1:
                                            contMicros2 = 0
                                            contMicros1 += 1
                                            micro1 = mic1["microservice"]
                                            if micro1.endswith("-green"):
                                                micro1SinSufijo = micro1[:-6]
                                            elif micro1.endswith("-g"):
                                                micro1SinSufijo = micro1[:-2]
                                            elif micro1.endswith("-blue"):
                                                micro1SinSufijo = micro1[:-5]
                                            elif micro1.endswith("-b"):
                                                micro1SinSufijo = micro1[:-2]
                                            else:
                                                micro1SinSufijo = micro1
                                            usoCPU1Total = mic1['max_peak_useCPU']
                                            usoCPU1 = mic1["max_peak_averageCPU"]
                                            usoMEM1Total = mic1['max_peak_useMEM']
                                            usoMEM1 = mic1["max_peak_averageMEM"]
                                            for mic2 in micros2:
                                                contMicros2 += 1
                                                micro2 = mic2["microservice"]
                                                if micro2.endswith("-green"):
                                                    micro2SinSufijo = micro2[:-6]
                                                elif micro2.endswith("-g"):
                                                    micro2SinSufijo = micro2[:-2]
                                                elif micro2.endswith("-blue"):
                                                    micro2SinSufijo = micro2[:-5]
                                                elif micro2.endswith("-b"):
                                                    micro2SinSufijo = micro2[:-2]
                                                else:
                                                    micro2SinSufijo = micro2
                                                usoCPU2Total = mic2['max_peak_useCPU']
                                                usoCPU2 = mic2["max_peak_averageCPU"]
                                                usoMEM2Total = mic2['max_peak_useMEM']
                                                usoMEM2 = mic2["max_peak_averageMEM"]
                                                if micro1SinSufijo == micro2SinSufijo:
                                                    if usoCPU1 > usoCPU2:
                                                        usoCPU = usoCPU1
                                                        usoCPUTotal = usoCPU1Total
                                                    elif usoCPU1 < usoCPU2:
                                                        usoCPU = usoCPU2
                                                        usoCPUTotal = usoCPU2Total
                                                    else:
                                                        usoCPU = usoCPU1
                                                        usoCPUTotal = usoCPU1Total

                                                    if usoMEM1 > usoMEM2:
                                                        usoMEM = usoMEM1
                                                        usoMEMTotal = usoMEM1Total
                                                    elif usoMEM1 < usoMEM2:
                                                        usoMEM = usoMEM2
                                                        usoMEMTotal = usoMEM2Total
                                                    else:
                                                        usoMEM = usoMEM1
                                                        usoMEMTotal = usoMEM1Total

                                                    uso_pico = {
                                                        "microservice": micro1,
                                                        "usoPicoCPUTotal": usoCPUTotal,
                                                        "usoPicoCPU": usoCPU,
                                                        "usoPicoMEMTotal": usoMEMTotal,
                                                        "usoPicoMEM": usoMEM
                                                    }
                                                    uso_pico_list.append(uso_pico)
                                                else:
                                                    pass
                                    elif len(micros1) > len(micros2):
                                        contMicros1 = 0
                                        for mic1 in micros1:
                                            contMicros2 = 0
                                            contMicros1 += 1
                                            micro1 = mic1["microservice"]
                                            if micro1.endswith("-green"):
                                                micro1SinSufijo = micro1[:-6]
                                            elif micro1.endswith("-g"):
                                                micro1SinSufijo = micro1[:-2]
                                            elif micro1.endswith("-blue"):
                                                micro1SinSufijo = micro1[:-5]
                                            elif micro1.endswith("-b"):
                                                micro1SinSufijo = micro1[:-2]
                                            else:
                                                micro1SinSufijo = micro1
                                            usoCPU1Total = mic1['max_peak_useCPU']
                                            usoCPU1 = mic1["max_peak_averageCPU"]
                                            usoMEM1Total = mic1['max_peak_useMEM']
                                            usoMEM1 = mic1["max_peak_averageMEM"]
                                            igual = False
                                            for mic2 in micros2:
                                                contMicros2 += 1
                                                micro2 = mic2["microservice"]
                                                if micro2.endswith("-green"):
                                                    micro2SinSufijo = micro2[:-6]
                                                elif micro2.endswith("-g"):
                                                    micro2SinSufijo = micro2[:-2]
                                                elif micro2.endswith("-blue"):
                                                    micro2SinSufijo = micro2[:-5]
                                                elif micro2.endswith("-b"):
                                                    micro2SinSufijo = micro2[:-2]
                                                else:
                                                    micro2SinSufijo = micro2
                                                usoCPU2Total = mic2['max_peak_useCPU']
                                                usoCPU2 = mic2["max_peak_averageCPU"]
                                                usoMEM2Total = mic2['max_peak_useMEM']
                                                usoMEM2 = mic2["max_peak_averageMEM"]
                                                if micro1SinSufijo == micro2SinSufijo:
                                                    igual = True
                                                    if usoCPU1 > usoCPU2:
                                                        usoCPU = usoCPU1
                                                        usoCPUTotal = usoCPU1Total
                                                    elif usoCPU1 < usoCPU2:
                                                        usoCPU = usoCPU2
                                                        usoCPUTotal = usoCPU2Total
                                                    else:
                                                        usoCPU = usoCPU1
                                                        usoCPUTotal = usoCPU1Total

                                                    if usoMEM1 > usoMEM2:
                                                        usoMEM = usoMEM1
                                                        usoMEMTotal = usoMEM1Total
                                                    elif usoMEM1 < usoMEM2:
                                                        usoMEM = usoMEM2
                                                        usoMEMTotal = usoMEM2Total
                                                    else:
                                                        usoMEM = usoMEM1
                                                        usoMEMTotal = usoMEM1Total

                                                    uso_pico = {
                                                        "microservice": micro1,
                                                        "usoPicoCPUTotal": usoCPUTotal,
                                                        "usoPicoCPU": usoCPU,
                                                        "usoPicoMEMTotal": usoMEMTotal,
                                                        "usoPicoMEM": usoMEM
                                                    }
                                                    uso_pico_list.append(uso_pico)
                                                else:
                                                    if len(micros2) == contMicros2 and igual == False:
                                                        uso_pico = {
                                                        "microservice": micro1,
                                                        "usoPicoCPUTotal": usoCPU1Total,
                                                        "usoPicoCPU": usoCPU1,
                                                        "usoPicoMEMTotal": usoMEM1Total,
                                                        "usoPicoMEM": usoMEM1
                                                        }
                                                        uso_pico_list.append(uso_pico)
                                                        
                                    else:
                                        contMicros2 = 0
                                        for mic2 in micros2:
                                            contMicros1 = 0
                                            contMicros2 += 1
                                            micro2 = mic2["microservice"]
                                            if micro2.endswith("-green"):
                                                micro2SinSufijo = micro2[:-6]
                                            elif micro2.endswith("-g"):
                                                micro2SinSufijo = micro2[:-2]
                                            elif micro2.endswith("-blue"):
                                                micro2SinSufijo = micro2[:-5]
                                            elif micro2.endswith("-b"):
                                                micro2SinSufijo = micro2[:-2]
                                            else:
                                                micro2SinSufijo = micro2
                                            usoCPU2Total = mic2['max_peak_useCPU']
                                            usoCPU2 = mic2["max_peak_averageCPU"]
                                            usoMEM2Total = mic2['max_peak_useMEM']
                                            usoMEM2 = mic2["max_peak_averageMEM"]
                                            igual = False
                                            for mic1 in micros1:
                                                contMicros1 += 1
                                                micro1 = mic1["microservice"]
                                                if micro1.endswith("-green"):
                                                    micro1SinSufijo = micro1[:-6]
                                                elif micro1.endswith("-g"):
                                                    micro1SinSufijo = micro1[:-2]
                                                elif micro1.endswith("-blue"):
                                                    micro1SinSufijo = micro1[:-5]
                                                elif micro1.endswith("-b"):
                                                    micro1SinSufijo = micro1[:-2]
                                                else:
                                                    micro1SinSufijo = micro1
                                                usoCPU1Total = mic1['max_peak_useCPU']
                                                usoCPU1 = mic1["max_peak_averageCPU"]
                                                usoMEM1Total = mic1['max_peak_useMEM']
                                                usoMEM1 = mic1["max_peak_averageMEM"]
                                                if micro2SinSufijo == micro1SinSufijo:
                                                    igual = True
                                                    if usoCPU2 > usoCPU1:
                                                        usoCPU = usoCPU2
                                                        usoCPUTotal = usoCPU2Total
                                                    elif usoCPU2 < usoCPU1:
                                                        usoCPU = usoCPU1
                                                        usoCPUTotal = usoCPU1Total
                                                    else:
                                                        usoCPU = usoCPU2
                                                        usoCPUTotal = usoCPU2Total

                                                    if usoMEM2 > usoMEM1:
                                                        usoMEM = usoMEM2
                                                        usoMEMTotal = usoMEM2Total
                                                    elif usoMEM2 < usoMEM1:
                                                        usoMEM = usoMEM1
                                                        usoMEMTotal = usoMEM1Total
                                                    else:
                                                        usoMEM = usoMEM2
                                                        usoMEMTotal = usoMEM2Total

                                                    uso_pico = {
                                                        "microservice": micro2,
                                                        "usoPicoCPUTotal": usoCPUTotal,
                                                        "usoPicoCPU": usoCPU,
                                                        "usoPicoMEMTotal": usoMEMTotal,
                                                        "usoPicoMEM": usoMEM
                                                    }
                                                    uso_pico_list.append(uso_pico)
                                                else:
                                                    if len(micros1) == contMicros1 and igual == False:
                                                        uso_pico = {
                                                        "microservice": micro2,
                                                        "usoPicoCPUTotal": usoCPU2Total,
                                                        "usoPicoCPU": usoCPU2,
                                                        "usoPicoMEMTotal": usoMEM2Total,
                                                        "usoPicoMEM": usoMEM2
                                                        }
                                                        uso_pico_list.append(uso_pico)

                                detailNamespaceRecomenderList.append(await recomender(clust,uso_pico_list,namespace))
                


        case _:
            match namespace:
                case None:
                    nas= await client.get_resource(functional_environment=functionalEnvironment,cluster=cluster,resource="namespaces")
                    namespaces = []
                    for region in nas:
                        for space in nas[region]["items"]:
                            names = space['metadata']['name']
                            namespaces.append(names)

                        ns = list(set(namespaces))

                    for nspace in ns:
                        #namesp = nspace['metadata']['name']
                        mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE"))
                        # Find namespace/cluster/region in bbdd
                        documents = list(mg.find({f"namespace": nspace, f"cluster": cluster}))
                        uso_pico_list = []
                        if documents:
                            micros1 = None
                            micros2 = None
                            for docu in documents:
                                del docu['_id']
                                del docu['timestamp']
                                if docu['region'] == "bo1" or docu['region'] == "weu1" or docu['region'] == "cn1" or docu['region'] == "mx1" or docu['region'] == "weu":
                                    micros1 = docu['microservices']
                                if docu['region'] == "bo2" or docu['region'] == "weu2" or docu['region'] == "cn2" or docu['region'] == "mx2":
                                    micros2 = docu['microservices']

                            if micros1 != None and micros2 == None:
                                for mic1 in micros1:
                                    micro1 = mic1["microservice"]
                                    usoCPU1Total = mic1['max_peak_useCPU']
                                    usoCPU1 = mic1["max_peak_averageCPU"]
                                    usoMEM1Total = mic1['max_peak_useCPU']
                                    usoMEM1 = mic1["max_peak_useMEM"]
                                
                                    uso_pico = {
                                        "microservice": micro1,
                                        "usoPicoCPUTotal": usoCPU1Total,
                                        "usoPicoCPU": usoCPU1,
                                        "usoPicoMEMTotal": usoMEM1Total,
                                        "usoPicoMEM": usoMEM1
                                    }
                                    uso_pico_list.append(uso_pico)
                            
                            if micros1 == None and micros2 !=None:
                                for mic2 in micros2:
                                    micro2 = mic2["microservice"]
                                    usoCPU2Total = mic2['max_peak_useCPU']
                                    usoCPU2 = mic2["max_peak_averageCPU"]
                                    usoMEM2Total = mic2['max_peak_useCPU']
                                    usoMEM2 = mic2["max_peak_averageMEM"]
                                
                                    uso_pico = {
                                        "microservice": micro2,
                                        "usoPicoCPUTotal": usoCPU2Total,
                                        "usoPicoCPU": usoCPU2,
                                        "usoPicoMEMTotal": usoMEM2Total,
                                        "usoPicoMEM": usoMEM2
                                    }
                                    uso_pico_list.append(uso_pico)
                            
                            if micros1 != None and micros2 !=None:
                                if len(micros1) == len(micros2):
                                    contMicros1 = 0
                                    for mic1 in micros1:
                                        contMicros2 = 0
                                        contMicros1 += 1
                                        micro1 = mic1["microservice"]
                                        if micro1.endswith("-green"):
                                            micro1SinSufijo = micro1[:-6]
                                        elif micro1.endswith("-g"):
                                            micro1SinSufijo = micro1[:-2]
                                        elif micro1.endswith("-blue"):
                                            micro1SinSufijo = micro1[:-5]
                                        elif micro1.endswith("-b"):
                                            micro1SinSufijo = micro1[:-2]
                                        else:
                                            micro1SinSufijo = micro1
                                        usoCPU1Total = mic1['max_peak_useCPU']
                                        usoCPU1 = mic1["max_peak_averageCPU"]
                                        usoMEM1Total = mic1['max_peak_useMEM']
                                        usoMEM1 = mic1["max_peak_averageMEM"]
                                        for mic2 in micros2:
                                            contMicros2 += 1
                                            micro2 = mic2["microservice"]
                                            if micro2.endswith("-green"):
                                                micro2SinSufijo = micro2[:-6]
                                            elif micro2.endswith("-g"):
                                                micro2SinSufijo = micro2[:-2]
                                            elif micro2.endswith("-blue"):
                                                micro2SinSufijo = micro2[:-5]
                                            elif micro2.endswith("-b"):
                                                micro2SinSufijo = micro2[:-2]
                                            else:
                                                micro2SinSufijo = micro2
                                            usoCPU2Total = mic2['max_peak_useCPU']
                                            usoCPU2 = mic2["max_peak_averageCPU"]
                                            usoMEM2Total = mic2['max_peak_useMEM']
                                            usoMEM2 = mic2["max_peak_averageMEM"]
                                            if micro1SinSufijo == micro2SinSufijo:
                                                if usoCPU1 > usoCPU2:
                                                    usoCPU = usoCPU1
                                                    usoCPUTotal = usoCPU1Total
                                                elif usoCPU1 < usoCPU2:
                                                    usoCPU = usoCPU2
                                                    usoCPUTotal = usoCPU2Total
                                                else:
                                                    usoCPU = usoCPU1
                                                    usoCPUTotal = usoCPU1Total

                                                if usoMEM1 > usoMEM2:
                                                    usoMEM = usoMEM1
                                                    usoMEMTotal = usoMEM1Total
                                                elif usoMEM1 < usoMEM2:
                                                    usoMEM = usoMEM2
                                                    usoMEMTotal = usoMEM2Total
                                                else:
                                                    usoMEM = usoMEM1
                                                    usoMEMTotal = usoMEM1Total

                                                uso_pico = {
                                                    "microservice": micro1,
                                                    "usoPicoCPUTotal": usoCPUTotal,
                                                    "usoPicoCPU": usoCPU,
                                                    "usoPicoMEMTotal": usoMEMTotal,
                                                    "usoPicoMEM": usoMEM
                                                }
                                                uso_pico_list.append(uso_pico)
                                            else:
                                                pass
                                elif len(micros1) > len(micros2):
                                    contMicros1 = 0
                                    for mic1 in micros1:
                                        contMicros2 = 0
                                        contMicros1 += 1
                                        micro1 = mic1["microservice"]
                                        if micro1.endswith("-green"):
                                            micro1SinSufijo = micro1[:-6]
                                        elif micro1.endswith("-g"):
                                            micro1SinSufijo = micro1[:-2]
                                        elif micro1.endswith("-blue"):
                                            micro1SinSufijo = micro1[:-5]
                                        elif micro1.endswith("-b"):
                                            micro1SinSufijo = micro1[:-2]
                                        else:
                                            micro1SinSufijo = micro1
                                        usoCPU1Total = mic1['max_peak_useCPU']
                                        usoCPU1 = mic1["max_peak_averageCPU"]
                                        usoMEM1Total = mic1['max_peak_useMEM']
                                        usoMEM1 = mic1["max_peak_averageMEM"]
                                        igual = False
                                        for mic2 in micros2:
                                            contMicros2 += 1
                                            micro2 = mic2["microservice"]
                                            if micro2.endswith("-green"):
                                                micro2SinSufijo = micro2[:-6]
                                            elif micro2.endswith("-g"):
                                                micro2SinSufijo = micro2[:-2]
                                            elif micro2.endswith("-blue"):
                                                micro2SinSufijo = micro2[:-5]
                                            elif micro2.endswith("-b"):
                                                micro2SinSufijo = micro2[:-2]
                                            else:
                                                micro2SinSufijo = micro2
                                            usoCPU2Total = mic2['max_peak_useCPU']
                                            usoCPU2 = mic2["max_peak_averageCPU"]
                                            usoMEM2Total = mic2['max_peak_useMEM']
                                            usoMEM2 = mic2["max_peak_averageMEM"]
                                            if micro1SinSufijo == micro2SinSufijo:
                                                igual = True
                                                if usoCPU1 > usoCPU2:
                                                    usoCPU = usoCPU1
                                                    usoCPUTotal = usoCPU1Total
                                                elif usoCPU1 < usoCPU2:
                                                    usoCPU = usoCPU2
                                                    usoCPUTotal = usoCPU2Total
                                                else:
                                                    usoCPU = usoCPU1
                                                    usoCPUTotal = usoCPU1Total

                                                if usoMEM1 > usoMEM2:
                                                    usoMEM = usoMEM1
                                                    usoMEMTotal = usoMEM1Total
                                                elif usoMEM1 < usoMEM2:
                                                    usoMEM = usoMEM2
                                                    usoMEMTotal = usoMEM2Total
                                                else:
                                                    usoMEM = usoMEM1
                                                    usoMEMTotal = usoMEM1Total

                                                uso_pico = {
                                                    "microservice": micro1,
                                                    "usoPicoCPUTotal": usoCPUTotal,
                                                    "usoPicoCPU": usoCPU,
                                                    "usoPicoMEMTotal": usoMEMTotal,
                                                    "usoPicoMEM": usoMEM
                                                }
                                                uso_pico_list.append(uso_pico)
                                            else:
                                                if len(micros2) == contMicros2 and igual == False:
                                                    uso_pico = {
                                                    "microservice": micro1,
                                                    "usoPicoCPUTotal": usoCPU1Total,
                                                    "usoPicoCPU": usoCPU1,
                                                    "usoPicoMEMTotal": usoMEM1Total,
                                                    "usoPicoMEM": usoMEM1
                                                    }
                                                    uso_pico_list.append(uso_pico)
                                                    
                                else:
                                    contMicros2 = 0
                                    for mic2 in micros2:
                                        contMicros1 = 0
                                        contMicros2 += 1
                                        micro2 = mic2["microservice"]
                                        if micro2.endswith("-green"):
                                            micro2SinSufijo = micro2[:-6]
                                        elif micro2.endswith("-g"):
                                            micro2SinSufijo = micro2[:-2]
                                        elif micro2.endswith("-blue"):
                                            micro2SinSufijo = micro2[:-5]
                                        elif micro2.endswith("-b"):
                                            micro2SinSufijo = micro2[:-2]
                                        else:
                                            micro2SinSufijo = micro2
                                        usoCPU2Total = mic2['max_peak_useCPU']
                                        usoCPU2 = mic2["max_peak_averageCPU"]
                                        usoMEM2Total = mic2['max_peak_useMEM']
                                        usoMEM2 = mic2["max_peak_averageMEM"]
                                        igual = False
                                        for mic1 in micros1:
                                            contMicros1 += 1
                                            micro1 = mic1["microservice"]
                                            if micro1.endswith("-green"):
                                                micro1SinSufijo = micro1[:-6]
                                            elif micro1.endswith("-g"):
                                                micro1SinSufijo = micro1[:-2]
                                            elif micro1.endswith("-blue"):
                                                micro1SinSufijo = micro1[:-5]
                                            elif micro1.endswith("-b"):
                                                micro1SinSufijo = micro1[:-2]
                                            else:
                                                micro1SinSufijo = micro1
                                            usoCPU1Total = mic1['max_peak_useCPU']
                                            usoCPU1 = mic1["max_peak_averageCPU"]
                                            usoMEM1Total = mic1['max_peak_useMEM']
                                            usoMEM1 = mic1["max_peak_averageMEM"]
                                            if micro2SinSufijo == micro1SinSufijo:
                                                igual = True
                                                if usoCPU2 > usoCPU1:
                                                    usoCPU = usoCPU2
                                                    usoCPUTotal = usoCPU2Total
                                                elif usoCPU2 < usoCPU1:
                                                    usoCPU = usoCPU1
                                                    usoCPUTotal = usoCPU1Total
                                                else:
                                                    usoCPU = usoCPU2
                                                    usoCPUTotal = usoCPU2Total

                                                if usoMEM2 > usoMEM1:
                                                    usoMEM = usoMEM2
                                                    usoMEMTotal = usoMEM2Total
                                                elif usoMEM2 < usoMEM1:
                                                    usoMEM = usoMEM1
                                                    usoMEMTotal = usoMEM1Total
                                                else:
                                                    usoMEM = usoMEM2
                                                    usoMEMTotal = usoMEM2Total

                                                uso_pico = {
                                                    "microservice": micro2,
                                                    "usoPicoCPUTotal": usoCPUTotal,
                                                    "usoPicoCPU": usoCPU,
                                                    "usoPicoMEMTotal": usoMEMTotal,
                                                    "usoPicoMEM": usoMEM
                                                }
                                                uso_pico_list.append(uso_pico)
                                            else:
                                                if len(micros1) == contMicros1 and igual == False:
                                                    uso_pico = {
                                                    "microservice": micro2,
                                                    "usoPicoCPUTotal": usoCPU2Total,
                                                    "usoPicoCPU": usoCPU2,
                                                    "usoPicoMEMTotal": usoMEM2Total,
                                                    "usoPicoMEM": usoMEM2
                                                    }
                                                    uso_pico_list.append(uso_pico)

                            detailNamespaceRecomenderList.append(await recomender(cluster,uso_pico_list,nspace))

                case _:
                    mg.change_collection(os.getenv("COLLECTION_SRE_LASTPEAK_MICROSERVICE"))
                    # Find namespace/cluster/region in bbdd
                    documents = list(mg.find({f"namespace": namespace, f"cluster": cluster}))
                    uso_pico_list = []
                    if documents:
                        micros1 = None
                        micros2 = None
                        for docu in documents:
                            del docu['_id']
                            del docu['timestamp']
                            if docu['region'] == "bo1" or docu['region'] == "weu1" or docu['region'] == "cn1" or docu['region'] == "mx1" or docu['region'] == "weu":
                                micros1 = docu['microservices']
                            if docu['region'] == "bo2" or docu['region'] == "weu2" or docu['region'] == "cn2" or docu['region'] == "mx2":
                                micros2 = docu['microservices']

                        if micros1 != None and micros2 == None:
                            for mic1 in micros1:
                                micro1 = mic1["microservice"]
                                usoCPU1Total = mic1['max_peak_useCPU']
                                usoCPU1 = mic1["max_peak_averageCPU"]
                                usoMEM1Total = mic1['max_peak_useMEM']
                                usoMEM1 = mic1["max_peak_averageMEM"]
                            
                                uso_pico = {
                                    "microservice": micro1,
                                    "usoPicoCPUTotal": usoCPU1Total,
                                    "usoPicoCPU": usoCPU1,
                                    "usoPicoMEMTotal": usoMEM1Total,
                                    "usoPicoMEM": usoMEM1
                                }
                                uso_pico_list.append(uso_pico)
                        
                        if micros1 == None and micros2 !=None:
                            for mic2 in micros2:
                                micro2 = mic2["microservice"]
                                usoCPU2Total = mic2['max_peak_useCPU']
                                usoCPU2 = mic2["max_peak_averageCPU"]
                                usoMEM2Total = mic2['max_peak_useCPU']
                                usoMEM2 = mic2["max_peak_averageMEM"]
                            
                                uso_pico = {
                                    "microservice": micro2,
                                    "usoPicoCPUTotal": usoCPU2Total,
                                    "usoPicoCPU": usoCPU2,
                                    "usoPicoMEMTotal": usoMEM2Total,
                                    "usoPicoMEM": usoMEM2
                                }
                                uso_pico_list.append(uso_pico)
                        
                        if micros1 != None and micros2 !=None:
                            if len(micros1) == len(micros2):
                                contMicros1 = 0
                                for mic1 in micros1:
                                    contMicros2 = 0
                                    contMicros1 += 1
                                    micro1 = mic1["microservice"]
                                    if micro1.endswith("-green"):
                                        micro1SinSufijo = micro1[:-6]
                                    elif micro1.endswith("-g"):
                                        micro1SinSufijo = micro1[:-2]
                                    elif micro1.endswith("-blue"):
                                        micro1SinSufijo = micro1[:-5]
                                    elif micro1.endswith("-b"):
                                        micro1SinSufijo = micro1[:-2]
                                    else:
                                        micro1SinSufijo = micro1
                                    usoCPU1Total = mic1['max_peak_useCPU']
                                    usoCPU1 = mic1["max_peak_averageCPU"]
                                    usoMEM1Total = mic1['max_peak_useMEM']
                                    usoMEM1 = mic1["max_peak_averageMEM"]
                                    for mic2 in micros2:
                                        contMicros2 += 1
                                        micro2 = mic2["microservice"]
                                        if micro2.endswith("-green"):
                                            micro2SinSufijo = micro2[:-6]
                                        elif micro2.endswith("-g"):
                                            micro2SinSufijo = micro2[:-2]
                                        elif micro2.endswith("-blue"):
                                            micro2SinSufijo = micro2[:-5]
                                        elif micro2.endswith("-b"):
                                            micro2SinSufijo = micro2[:-2]
                                        else:
                                            micro2SinSufijo = micro2
                                        usoCPU2Total = mic2['max_peak_useCPU']
                                        usoCPU2 = mic2["max_peak_averageCPU"]
                                        usoMEM2Total = mic2['max_peak_useMEM']
                                        usoMEM2 = mic2["max_peak_averageMEM"]
                                        if micro1SinSufijo == micro2SinSufijo:
                                            if usoCPU1 > usoCPU2:
                                                usoCPU = usoCPU1
                                                usoCPUTotal = usoCPU1Total
                                            elif usoCPU1 < usoCPU2:
                                                usoCPU = usoCPU2
                                                usoCPUTotal = usoCPU2Total
                                            else:
                                                usoCPU = usoCPU1
                                                usoCPUTotal = usoCPU1Total

                                            if usoMEM1 > usoMEM2:
                                                usoMEM = usoMEM1
                                                usoMEMTotal = usoMEM1Total
                                            elif usoMEM1 < usoMEM2:
                                                usoMEM = usoMEM2
                                                usoMEMTotal = usoMEM2Total
                                            else:
                                                usoMEM = usoMEM1
                                                usoMEMTotal = usoMEM1Total

                                            uso_pico = {
                                                "microservice": micro1,
                                                "usoPicoCPUTotal": usoCPUTotal,
                                                "usoPicoCPU": usoCPU,
                                                "usoPicoMEMTotal": usoMEMTotal,
                                                "usoPicoMEM": usoMEM
                                            }
                                            uso_pico_list.append(uso_pico)
                                        else:
                                            pass
                                            if docu['namespace'] == 'sanes-pruebas-pro-pro':
                                                if usoCPU1 > usoCPU2:
                                                    usoCPU = usoCPU1
                                                    microser = micro1
                                                    usoCPUTotal = usoCPU1Total
                                                elif usoCPU1 < usoCPU2:
                                                    usoCPU = usoCPU2
                                                    microser = micro2
                                                    usoCPUTotal = usoCPU2Total
                                                else:
                                                    usoCPU = usoCPU1
                                                    microser = micro1
                                                    usoCPUTotal = usoCPU1Total

                                                if usoMEM1 > usoMEM2:
                                                    usoMEM = usoMEM1
                                                    microser = micro1
                                                    usoMEMTotal = usoMEM1Total
                                                elif usoMEM1 < usoMEM2:
                                                    usoMEM = usoMEM2
                                                    microser = micro2
                                                    usoMEMTotal = usoMEM2Total
                                                else:
                                                    usoMEM = usoMEM1
                                                    microser = micro1
                                                    usoMEMTotal = usoMEM1Total

                                                uso_pico = {
                                                    "microservice": microser,
                                                    "usoPicoCPUTotal": usoCPUTotal,
                                                    "usoPicoCPU": usoCPU,
                                                    "usoPicoMEMTotal": usoMEMTotal,
                                                    "usoPicoMEM": usoMEM
                                                }
                                                uso_pico_list.append(uso_pico)

                            elif len(micros1) > len(micros2):
                                contMicros1 = 0
                                for mic1 in micros1:
                                    contMicros2 = 0
                                    contMicros1 += 1
                                    micro1 = mic1["microservice"]
                                    if micro1.endswith("-green"):
                                        micro1SinSufijo = micro1[:-6]
                                    elif micro1.endswith("-g"):
                                        micro1SinSufijo = micro1[:-2]
                                    elif micro1.endswith("-blue"):
                                        micro1SinSufijo = micro1[:-5]
                                    elif micro1.endswith("-b"):
                                        micro1SinSufijo = micro1[:-2]
                                    else:
                                        micro1SinSufijo = micro1
                                    usoCPU1Total = mic1['max_peak_useCPU']
                                    usoCPU1 = mic1["max_peak_averageCPU"]
                                    usoMEM1Total = mic1['max_peak_useMEM']
                                    usoMEM1 = mic1["max_peak_averageMEM"]
                                    igual = False
                                    for mic2 in micros2:
                                        contMicros2 += 1
                                        micro2 = mic2["microservice"]
                                        if micro2.endswith("-green"):
                                            micro2SinSufijo = micro2[:-6]
                                        elif micro2.endswith("-g"):
                                            micro2SinSufijo = micro2[:-2]
                                        elif micro2.endswith("-blue"):
                                            micro2SinSufijo = micro2[:-5]
                                        elif micro2.endswith("-b"):
                                            micro2SinSufijo = micro2[:-2]
                                        else:
                                            micro2SinSufijo = micro2
                                        usoCPU2Total = mic2['max_peak_useCPU']
                                        usoCPU2 = mic2["max_peak_averageCPU"]
                                        usoMEM2Total = mic2['max_peak_useMEM']
                                        usoMEM2 = mic2["max_peak_averageMEM"]
                                        if micro1SinSufijo == micro2SinSufijo:
                                            igual = True
                                            if usoCPU1 > usoCPU2:
                                                usoCPU = usoCPU1
                                                usoCPUTotal = usoCPU1Total
                                            elif usoCPU1 < usoCPU2:
                                                usoCPU = usoCPU2
                                                usoCPUTotal = usoCPU2Total
                                            else:
                                                usoCPU = usoCPU1
                                                usoCPUTotal = usoCPU1Total

                                            if usoMEM1 > usoMEM2:
                                                usoMEM = usoMEM1
                                                usoMEMTotal = usoMEM1Total
                                            elif usoMEM1 < usoMEM2:
                                                usoMEM = usoMEM2
                                                usoMEMTotal = usoMEM2Total
                                            else:
                                                usoMEM = usoMEM1
                                                usoMEMTotal = usoMEM1Total

                                            uso_pico = {
                                                "microservice": micro1,
                                                "usoPicoCPUTotal": usoCPUTotal,
                                                "usoPicoCPU": usoCPU,
                                                "usoPicoMEMTotal": usoMEMTotal,
                                                "usoPicoMEM": usoMEM
                                            }
                                            uso_pico_list.append(uso_pico)
                                        else:
                                            if len(micros2) == contMicros2 and igual == False:
                                                uso_pico = {
                                                "microservice": micro1,
                                                "usoPicoCPUTotal": usoCPU1Total,
                                                "usoPicoCPU": usoCPU1,
                                                "usoPicoMEMTotal": usoMEM1Total,
                                                "usoPicoMEM": usoMEM1
                                                }
                                                uso_pico_list.append(uso_pico)
                                                
                            else:
                                contMicros2 = 0
                                for mic2 in micros2:
                                    contMicros1 = 0
                                    contMicros2 += 1
                                    micro2 = mic2["microservice"]
                                    if micro2.endswith("-green"):
                                        micro2SinSufijo = micro2[:-6]
                                    elif micro2.endswith("-g"):
                                        micro2SinSufijo = micro2[:-2]
                                    elif micro2.endswith("-blue"):
                                        micro2SinSufijo = micro2[:-5]
                                    elif micro2.endswith("-b"):
                                        micro2SinSufijo = micro2[:-2]
                                    else:
                                        micro2SinSufijo = micro2
                                    usoCPU2Total = mic2['max_peak_useCPU']
                                    usoCPU2 = mic2["max_peak_averageCPU"]
                                    usoMEM2Total = mic2['max_peak_useMEM']
                                    usoMEM2 = mic2["max_peak_averageMEM"]
                                    igual = False
                                    for mic1 in micros1:
                                        contMicros1 += 1
                                        micro1 = mic1["microservice"]
                                        if micro1.endswith("-green"):
                                            micro1SinSufijo = micro1[:-6]
                                        elif micro1.endswith("-g"):
                                            micro1SinSufijo = micro1[:-2]
                                        elif micro1.endswith("-blue"):
                                            micro1SinSufijo = micro1[:-5]
                                        elif micro1.endswith("-b"):
                                            micro1SinSufijo = micro1[:-2]
                                        else:
                                            micro1SinSufijo = micro1
                                        usoCPU1Total = mic1['max_peak_useCPU']
                                        usoCPU1 = mic1["max_peak_averageCPU"]
                                        usoMEM1Total = mic1['max_peak_useMEM']
                                        usoMEM1 = mic1["max_peak_averageMEM"]
                                        if micro2SinSufijo == micro1SinSufijo:
                                            igual = True
                                            if usoCPU2 > usoCPU1:
                                                usoCPU = usoCPU2
                                                usoCPUTotal = usoCPU2Total
                                            elif usoCPU2 < usoCPU1:
                                                usoCPU = usoCPU1
                                                usoCPUTotal = usoCPU1Total
                                            else:
                                                usoCPU = usoCPU2
                                                usoCPUTotal = usoCPU2Total

                                            if usoMEM2 > usoMEM1:
                                                usoMEM = usoMEM2
                                                usoMEMTotal = usoMEM2Total
                                            elif usoMEM2 < usoMEM1:
                                                usoMEM = usoMEM1
                                                usoMEMTotal = usoMEM1Total
                                            else:
                                                usoMEM = usoMEM2
                                                usoMEMTotal = usoMEM2Total

                                            uso_pico = {
                                                "microservice": micro2,
                                                "usoPicoCPUTotal": usoCPUTotal,
                                                "usoPicoCPU": usoCPU,
                                                "usoPicoMEMTotal": usoMEMTotal,
                                                "usoPicoMEM": usoMEM
                                            }
                                            uso_pico_list.append(uso_pico)
                                        else:
                                            if len(micros1) == contMicros1 and igual == False:
                                                uso_pico = {
                                                "microservice": micro2,
                                                "usoPicoCPUTotal": usoCPU2Total,
                                                "usoPicoCPU": usoCPU2,
                                                "usoPicoMEMTotal": usoMEM2Total,
                                                "usoPicoMEM": usoMEM2
                                                }
                                                uso_pico_list.append(uso_pico)   
                            uso_pico_listUnicos = eliminar_duplicados_diccionarios(uso_pico_list)
                        detailNamespaceRecomenderList.append(await recomender(cluster,uso_pico_listUnicos,namespace))
             
    return detailNamespaceRecomenderList


def eliminar_duplicados_diccionarios(lista_diccionarios):
    """Elimina duplicados de una lista de diccionarios.

    Args:
        lista_diccionarios: La lista de diccionarios a procesar.

    Returns:
        Una nueva lista con los diccionarios únicos.
    """
    diccionarios_unicos = set()
    for dic in lista_diccionarios:
        diccionarios_unicos.add(tuple(dic.items()))  # Agregar diccionarios como tuplas
    return [dict(tupla) for tupla in diccionarios_unicos]


async def recomender(cluster,lista,namespace):
    environment = os.getenv("ENVIRONMENT")
    detailMicroserviceRecomenderList = []
    detailNamespaceRecomenderList = []
    useCPUAverage = None
    commentCPUUse = None
    recomenderCPURequest = None
    commentCPURequest = None
    recomenderCPULimit = None
    commentCPULimit = None
    useMEMAverage = None
    commentMEMUse = None
    recomenderMEMRequest = None
    recomenderMEMRequestInt = None
    recomenderMEMLimit = None
    recomenderMEMLimitInt = None
    commentMEM = None
    recomenderHPA = None
    recomenderminReplicas = None
    recomendermaxReplicas = None
    recomendertarget = None
    commentHPA = None
    replicasBase = None
    isJava1 = False
    isJava2 = False
    mg.change_collection(os.getenv("COLLECTION_SRE_MICROSERVICES"))
    logger.info(f"########## Cluster-Region: {cluster} ##########")
    logger.info(f"########## Namespace: {namespace} ##########")
    
    for reg in lista:
        useCPUAverage = None
        commentCPUUse = None
        recomenderCPURequest = None
        commentCPURequest = None
        recomenderCPULimit = None
        commentCPULimit = None
        useMEMAverage = None
        commentMEMUse = None
        recomenderMEMRequest = None
        recomenderMEMRequestInt = None
        recomenderMEMLimit = None
        recomenderMEMLimitInt = None
        commentMEM = None
        recomenderHPA = None
        recomenderminReplicas = None
        recomendermaxReplicas = None
        recomendertarget = None
        commentHPA = None
        replicasBase = None
        isJava1 = False
        isJava2 = False
        microservice = reg['microservice']
        '''
        if '-b-' in microservice or '-g-' in microservice:
            microsinsuf = microservice
        elif "-green" in microservice:
            microsinsuf = microservice[:-6]
        elif "-g" in microservice:
            microsinsuf = microservice[:-2]
        elif "-blue" in microservice:
            microsinsuf = microservice[:-5]
        elif "-b" in microservice:
            microsinsuf = microservice[:-2]
        else:
            microsinsuf = reg["microservice"]
            '''
        useCPUAverage = reg['usoPicoCPU']
        usoCPUTotal = reg['usoPicoCPUTotal']
        useMEMAverage = reg['usoPicoMEM']
        usoMEMTotal = reg['usoPicoMEMTotal']
        logger.info(f"++++++++++ Microservice: {microservice} ++++++++++")

        commentCPUUse = useCPUAverage
        commentMEMUse = usoMEMTotal

        '''
        #Recomender CPU Request
        if usoCPUTotal < 50:
            recomenderCPURequest = 50
            commentCPURequest = None
        elif usoCPUTotal >= 50 and usoCPUTotal < 100:
            recomenderCPURequest = 100
            commentCPURequest = None
        elif usoCPUTotal >= 100 and usoCPUTotal < 120:
            recomenderCPURequest = 120
            commentCPURequest = None
        elif usoCPUTotal >= 120 and usoCPUTotal < 150:
            recomenderCPURequest = 150
            commentCPURequest = None
        elif usoCPUTotal >= 150 and usoCPUTotal < 200:
            recomenderCPURequest = 200
            commentCPURequest = None
        elif usoCPUTotal >= 200 and usoCPUTotal < 250:
            recomenderCPURequest = 250
            commentCPURequest = None
        elif usoCPUTotal >= 250 and usoCPUTotal < 300:
            recomenderCPURequest = 300
            commentCPURequest = None
        elif usoCPUTotal >= 300 and usoCPUTotal < 350:
            recomenderCPURequest = 350
            commentCPURequest = None
        elif usoCPUTotal >= 350 and usoCPUTotal < 450:
            recomenderCPURequest = 500
            commentCPURequest = "Review replicas"
        elif usoCPUTotal >= 450 and usoCPUTotal <= 600:
            recomenderCPURequest = 600
            commentCPURequest = "Review replicas"
        elif usoCPUTotal > 600:
            recomenderCPURequest = "Problem"
            commentCPURequest = "Review use"
            recomenderHPA = "NO"
            recomenderminReplicas = "N/A"
            recomendermaxReplicas = "N/A"
            recomendertarget = "N/A"
            commentHPA = "Capacity Problem / Auto-scaling is not recommended"
        else:
            recomenderCPURequest = "N/A"
            commentCPURequest = None
            recomenderHPA = "NO"
            recomenderminReplicas = "N/A"
            recomendermaxReplicas = "N/A"
            recomendertarget = "N/A"
            commentHPA = None
        '''
        service = await services(environment,cluster,namespace,microservice)


        #Recomender CPU Request
        if usoCPUTotal < 20:
            recomenderCPURequest = 50
            commentCPURequest = None
        elif usoCPUTotal >= 20 and usoCPUTotal < 80:
            recomenderCPURequest = 50
            commentCPURequest = None
        elif usoCPUTotal >= 80 and usoCPUTotal < 200:
            recomenderCPURequest = 100
            commentCPURequest = None
        elif usoCPUTotal >= 200 and usoCPUTotal < 360:
            recomenderCPURequest = 120
            commentCPURequest = None
        elif usoCPUTotal >= 360 and usoCPUTotal < 450:
            recomenderCPURequest = 150
            commentCPURequest = None
        elif usoCPUTotal >= 450 and usoCPUTotal < 800:
            recomenderCPURequest = 200
            commentCPURequest = None
        elif usoCPUTotal >= 800 and usoCPUTotal < 1250:
            recomenderCPURequest = 250
            commentCPURequest = None
        elif usoCPUTotal >= 1250 and usoCPUTotal < 1800:
            recomenderCPURequest = 300
            commentCPURequest = None
        elif usoCPUTotal >= 1800 and usoCPUTotal < 2100:
            recomenderCPURequest = 350
            commentCPURequest = None
        elif usoCPUTotal >= 2100 and usoCPUTotal < 3600:
            recomenderCPURequest = 450
            commentCPURequest = None
        elif usoCPUTotal >= 3600 and usoCPUTotal < 5000:
            recomenderCPURequest = 500
            commentCPURequest = "Review replicas"
        elif usoCPUTotal >= 5000 and usoCPUTotal < 7200:
            recomenderCPURequest = 600
            commentCPURequest = "Review replicas"
        elif usoCPUTotal >= 7200:
            recomenderCPURequest = "Problem"
            commentCPURequest = "Review use"
            recomenderHPA = "NO"
            recomenderminReplicas = "N/A"
            recomendermaxReplicas = "N/A"
            recomendertarget = "N/A"
            commentHPA = "Capacity Problem / Auto-scaling is not recommended"
        else:
            recomenderCPURequest = "N/A"
            commentCPURequest = None
            recomenderHPA = "NO"
            recomenderminReplicas = "N/A"
            recomendermaxReplicas = "N/A"
            recomendertarget = "N/A"
            commentHPA = None

        '''
        services=await client.get_resource(functional_environment=environment,cluster=cluster,resource="services",namespace=namespace)
        for serv in services:
            if len(services[serv]["items"]) == 0:
                next
            else:
                contBlue = 0
                contGreen = 0
                exclusion = [
                    'config',
                    'gateway',
                    'datagrid',
                    'sts',
                    'pkm',
                    'nhb-libs',
                    'nginx-nhb',
                    'moneyplan',
                    'corporate',
                    'security',
                    'trace',
                    'decomisado'
                ]
                
                for ex in exclusion:
                    if ex in microservice:
                    #or 'gateway' in microservice or 'datagrid' in microservice:
                        for service in services[serv]["items"]:
                            if 'b-g-' in service['metadata']['name']:
                                try:
                                    mic = service['spec']['selector']['app_name']
                                except:
                                    mic = service['spec']['selector']['app']
                                if '-blue' in mic or mic[-2] == '-' and mic[-1] == 'b':
                                    contBlue += 1
                                elif '-green' in mic or mic[-2] == '-' and mic[-1] == 'g':
                                    contGreen += 1
                                else:
                                    pass
                    
                        if contBlue > contGreen:
                            if namespace == 'san-nweb-emp-pro':
                                if 'datagrid' in microservice or 'arq' in microservice:
                                    micr = microservice
                                    micro = microservice
                                    microb = microservice
                                    microg = microservice
                                else:
                                    micr = microservice
                                    micro = microservice + '-b'
                                    microb = microservice + '-blue'
                                    microg = microservice + '-green'
                            else:
                                micr = microservice
                                micro = microservice + '-b'
                                microb = microservice + '-blue'
                                microg = microservice + '-green'
                        else:
                            if namespace == 'san-nweb-emp-pro':
                                if 'datagrid' in microservice or 'arq' in microservice:
                                    micr = microservice
                                    micro = microservice
                                    microb = microservice
                                    microg = microservice
                                else:
                                    micr = microservice
                                    micro = microservice + '-g'
                                    microb = microservice + '-blue'
                                    microg = microservice + '-green'
                            else:
                                micr = microservice
                                micro = microservice + '-g'
                                microb = microservice + '-blue'
                                microg = microservice + '-green'
                        break
                for service in services[serv]["items"]:
                    srv = 'b-g-' + microservice
                    if srv == service['metadata']['name']:
                        micr = microservice
                        try:
                            micro = service['spec']['selector']['app_name']
                        except:
                            micro = service['spec']['selector']['app']
                        microb = microservice + '-blue'
                        microg = microservice + '-green'
                        break
                    else:
                        for service in services[serv]["items"]:
                            if 'b-g-' in service['metadata']['name']:
                                try:
                                    mic = service['spec']['selector']['app_name']
                                except:
                                    mic = service['spec']['selector']['app']
                                if '-blue' in mic or mic[-2] == '-' and mic[-1] == 'b':
                                    contBlue += 1
                                elif '-green' in mic or mic[-2] == '-' and mic[-1] == 'g':
                                    contGreen += 1
                                else:
                                    pass
                    
                        if contBlue > contGreen:
                            if namespace == 'san-nweb-emp-pro':
                                if 'datagrid' in microservice or 'arq' in microservice:
                                    micr = microservice
                                    micro = microservice
                                    microb = microservice
                                    microg = microservice
                                else:
                                    micr = microservice
                                    micro = microservice + '-b'
                                    microb = microservice + '-blue'
                                    microg = microservice + '-green'
                            else:
                                micr = microservice
                                micro = microservice + '-b'
                                microb = microservice + '-blue'
                                microg = microservice + '-green'
                        else:
                            if namespace == 'san-nweb-emp-pro':
                                if 'datagrid' in microservice or 'arq' in microservice:
                                    micr = microservice
                                    micro = microservice
                                    microb = microservice
                                    microg = microservice
                                else:
                                    micr = microservice
                                    micro = microservice + '-g'
                                    microb = microservice + '-blue'
                                    microg = microservice + '-green'
                            else:
                                micr = microservice
                                micro = microservice + '-g'
                                microb = microservice + '-blue'
                                microg = microservice + '-green'
                        break
                        '''       


        micr = service[0]
        micro = service[1]
        microb = service[2]
        microg = service[3]

        documen = []
        documen1 = list(mg.find({f"namespace": namespace, f"cluster": cluster, f"name": micro}))
        documen2 = list(mg.find({f"namespace": namespace, f"cluster": cluster, f"name": microb}))
        #documen3 = list(mg.find({f"namespace": namespace, f"cluster": cluster, f"name": micG}))
        documen4 = list(mg.find({f"namespace": namespace, f"cluster": cluster, f"name": microg}))
        documen5 = list(mg.find({f"namespace": namespace, f"cluster": cluster, f"name": micr}))
        if documen1:
            documen.extend(documen1)
        elif documen2:
            documen.extend(documen2)
        #if documen3:
            #documen.extend(documen3)
        elif documen4:
            documen.extend(documen4)
        else:
            documen.extend(documen5)

        if len(documen) == 0:
            documen = list(mg.find({f"namespace": namespace, f"cluster": cluster}))
        if documen:
            #micList = documen[0]["microservices"]
            #if micList:
            for mc in documen:
                '''
                mic = mc["name"]
                if '-b-' in mic or '-g-' in mic:
                    microsinsuf = mic
                elif "-green" in mic:
                    microsinsuf = mic[:-6]
                elif "-g" in mic:
                    microsinsuf = mic[:-2]
                elif "-blue" in mic:
                    microsinsuf = mic[:-5]
                elif "-b" in mic:
                    microsinsuf = mic[:-2]
                else:
                    microsinsuf = mc["microservice"]
                    '''
                #if microservice==microsinsuf:
                if mc['region'] == 'bo1' or mc['region'] == 'weu1' or mc['region'] == 'cn1':
                    isJavabo1 = mc["javadict"]
                    try:
                        isJava1 = isJavabo1['isjava']
                    except:
                        isJava1 = isJavabo1['is_java']
                else:
                    isJavabo2 = mc["javadict"]
                    try:
                        isJava2 = isJavabo2['isjava']
                    except:
                        isJava2 = isJavabo2['is_java']
                
            if isJava1 == True and isJava2 == True:
                isJava = True
            elif isJava1 == True and isJava2 == False:
                isJava = True
            elif isJava1 == False and isJava2 == True:
                isJava = True
            else:
                isJava = False

            #if microservice == "front-error-logger":
                #isJava = False
            if isJava == True:
                #Recomender MEM REquest y MEM Limit para micros java
                if useMEMAverage < 500:
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "1907 MiB"
                        recomenderMEMRequestInt = 1907
                        recomenderMEMLimit = "3814 MiB"
                        recomenderMEMLimitInt = 3814
                    else:  
                        commentMEM = "MaxRAM 50"
                        recomenderMEMRequest = "500 MiB"
                        recomenderMEMRequestInt = 500
                        recomenderMEMLimit = "1000 MiB"
                        recomenderMEMLimitInt = 1000
                elif useMEMAverage < 975:
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "1907 MiB"
                        recomenderMEMRequestInt = 1907
                        recomenderMEMLimit = "3814 MiB"
                        recomenderMEMLimitInt = 3814
                    else:
                        commentMEM = "MaxRAM 65"
                        recomenderMEMRequest = "975 MiB"
                        recomenderMEMRequestInt = 975
                        recomenderMEMLimit = "1500 MiB"
                        recomenderMEMLimitInt = 1500
                elif useMEMAverage < 1400:
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "1907 MiB"
                        recomenderMEMRequestInt = 1907
                        recomenderMEMLimit = "3814 MiB"
                        recomenderMEMLimitInt = 3814
                    else:
                        commentMEM = "MaxRAM 70"
                        recomenderMEMRequest = "1400 MiB"
                        recomenderMEMRequestInt = 1400
                        recomenderMEMLimit = "2000 MiB"
                        recomenderMEMLimitInt = 2000
                elif useMEMAverage <= 2300:
                    #Poner memory leak
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "2861 MiB"
                        recomenderMEMRequestInt = 2861
                        recomenderMEMLimit = "5722 MiB"
                        recomenderMEMLimitInt = 5722
                    else:
                        if usoCPUTotal >= 800:
                            commentMEM = "MaxRAM 75"
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "2861 MiB"
                            recomenderMEMLimitInt = 2861
                        elif usoCPUTotal < 800:
                            commentMEM = "Possible Memory Leak"
                            recomenderMEMRequest = "Possible Memory Leak"
                            recomenderMEMRequestInt = "Problem"
                            recomenderMEMLimit = "Possible Memory Leak"
                            recomenderMEMLimitInt = "Problem"
                elif useMEMAverage > 2300:
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "2861 MiB"
                        recomenderMEMRequestInt = 2861
                        recomenderMEMLimit = "5722 MiB"
                        recomenderMEMLimitInt = 5722
                    else:
                        recomenderMEMRequest = "Possible Memory Leak"
                        recomenderMEMRequestInt = "Problem"
                        recomenderMEMLimit = "Possible Memory Leak"
                        recomenderMEMLimitInt = "Problem"
                        commentMEM = "Possible Memory Leak"
                else:
                    recomenderMEMRequest = None
                    recomenderMEMLimit = None
                    commentMEM = None

                if "config" in microservice:
                    recomenderCPULimit = 750
                    #commentCPULimit = "HC Readiness to 60sg + HC Liveness to 90sg"
                    commentCPULimit = None

                    recomenderHPA = "NO"
                    recomenderminReplicas = "N/A"
                    recomendermaxReplicas = "N/A"
                    recomendertarget = "N/A"
                    commentHPA = None

                    if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem':
                        valorMEM = 'N/A'
                        recomenderminReplicas = "N/A"
                        recomendermaxReplicas = "N/A"
                        recomendertarget = "N/A"
                        replicasBase = "N/A"
                        commentHPA = None
                    else:
                        match recomenderCPURequest:
                            case 50:
                                replicasBase = 2
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 100:
                                replicasBase = 2
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 120:
                                replicasBase = 3
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 150:
                                replicasBase = 3
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 200:
                                replicasBase = 4
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 250:
                                replicasBase = 5
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 300:
                                replicasBase = 6
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 350:
                                replicasBase = 6
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 450:
                                replicasBase = 8
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 500:
                                replicasBase = 10
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 600:
                                replicasBase = 12
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case "Problem":
                                replicasBase = "N/A"
                                valorMEM = "N/A"

                elif "datagrid" in microservice:
                    recomenderCPULimit = 1000
                    commentCPULimit = None

                    recomenderHPA = "NO"
                    recomenderminReplicas = "N/A"
                    recomendermaxReplicas = "N/A"
                    recomendertarget = "N/A"
                    commentHPA = None

                    if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem':
                        valorMEM = 'N/A'
                        recomenderminReplicas = "N/A"
                        recomendermaxReplicas = "N/A"
                        recomendertarget = "N/A"
                        commentHPA = None
                        replicasBase = "N/A"
                    else:
                        match recomenderCPURequest:
                            case 50:
                                replicasBase = 2
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 100:
                                replicasBase = 2
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 120:
                                replicasBase = 3
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 150:
                                replicasBase = 3
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 200:
                                replicasBase = 4
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 250:
                                replicasBase = 5
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 300:
                                replicasBase = 6
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 350:
                                replicasBase = 6
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 450:
                                replicasBase = 8
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 500:
                                replicasBase = 10
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 600:
                                replicasBase = 12
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case "Problem":
                                replicasBase = "N/A"
                                valorMEM = "N/A"
                else:
                    recomenderCPULimit = 1000
                    #commentCPULimit = "HC Readiness to 60sg + HC Liveness to 120sg"
                    commentCPULimit = None

                    if "gateway" in microservice:
                        recomenderCPULimit = 750
                        #commentCPULimit = "HC Readiness to 60sg + HC Liveness to 90sg"
                        commentCPULimit = None

                    if cluster == "probks" or cluster == "dmzbbks" or cluster == "confluent":
                        recomenderHPA = "NO"
                        recomenderminReplicas = "N/A"
                        recomendermaxReplicas = "N/A"
                        recomendertarget = "N/A"
                        commentHPA = None
                        replicasBase = "N/A"
                        valorMEM = "N/A"
                    else:
                        if cluster == "dmz2bmov":
                            if namespace == "sanes-homebankmovilidad-pro" or namespace == "sanes-movilidadempdmz2-pro" or namespace =="sanes-movilidadretaildmz2-pro":
                                recomenderHPA = "NO"
                                recomenderminReplicas = "N/A"
                                recomendermaxReplicas = "N/A"
                                recomendertarget = "N/A"
                                commentHPA = None
                                replicasBase = "N/A"
                                valorMEM = "N/A"
                            else:
                                if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem':
                                    valorMEM = 'N/A'
                                    replicasBase = "N/A"
                                    recomenderminReplicas = "N/A"
                                    recomendermaxReplicas = "N/A"
                                    recomendertarget = "N/A"
                                    commentHPA = None
                                else:
                                    match recomenderCPURequest:
                                        case 50:
                                            if usoCPUTotal < 20:
                                                recomenderHPA = "YES"
                                                if "gateway" in microservice:
                                                    recomenderminReplicas = 2
                                                    replicasBase = 2
                                                else:
                                                    recomenderminReplicas = 1
                                                    replicasBase = 1
                                                recomendermaxReplicas = 4
                                                recomendertarget = "100%"
                                                commentHPA = None
                                                valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                            else:
                                                replicasBase = 2
                                                recomenderHPA = "YES"
                                                recomenderminReplicas = 2
                                                recomendermaxReplicas = 8
                                                recomendertarget = "100%"
                                                commentHPA = None
                                                valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 100:
                                            replicasBase = 2
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 2
                                            recomendermaxReplicas = 10
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 120:
                                            replicasBase = 3
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 3
                                            recomendermaxReplicas = 10
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 150:
                                            replicasBase = 3
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 3
                                            recomendermaxReplicas = 12
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 200:
                                            replicasBase = 4
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 4
                                            recomendermaxReplicas = 16
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 250:
                                            replicasBase = 5
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 5
                                            recomendermaxReplicas = 20
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 300:
                                            replicasBase = 6
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 6
                                            recomendermaxReplicas = 24
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 350:
                                            replicasBase = 6
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 6
                                            recomendermaxReplicas = 24
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 450:
                                            replicasBase = 8
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 8
                                            recomendermaxReplicas = 30
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 500:
                                            replicasBase = 10
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 10
                                            recomendermaxReplicas = 40
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 600:
                                            replicasBase = 12
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 12
                                            recomendermaxReplicas = 50
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case "Problem":
                                            recomenderHPA = "NO"
                                            recomenderminReplicas = "N/A"
                                            recomendermaxReplicas = "N/A"
                                            recomendertarget = "N/A"
                                            commentHPA = None
                                            replicasBase = "N/A"
                                            valorMEM = "N/A"
                        else:
                            if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem':
                                valorMEM = 'N/A'
                                match recomenderCPURequest:
                                    case 50:
                                        if usoCPUTotal < 20:
                                            recomenderHPA = "YES"
                                            if "gateway" in microservice:
                                                recomenderminReplicas = 2
                                                replicasBase = 2
                                            else:
                                                recomenderminReplicas = 1
                                                replicasBase = 1
                                            recomendermaxReplicas = 4
                                            recomendertarget = "100%"
                                            commentHPA = None
                                        else:
                                            replicasBase = 2
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 2
                                            recomendermaxReplicas = 8
                                            recomendertarget = "100%"
                                            commentHPA = None
                                    case 100:
                                        replicasBase = 2
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 2
                                        recomendermaxReplicas = 10
                                        recomendertarget = "100%"
                                        commentHPA = None
                                    case 120:
                                        replicasBase = 3
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 3
                                        recomendermaxReplicas = 10
                                        recomendertarget = "100%"
                                        commentHPA = None
                                    case 150:
                                        replicasBase = 3
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 3
                                        recomendermaxReplicas = 12
                                        recomendertarget = "100%"
                                        commentHPA = None
                                    case 200:
                                        replicasBase = 4
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 4
                                        recomendermaxReplicas = 16
                                        recomendertarget = "100%"
                                        commentHPA = None
                                    case 250:
                                        replicasBase = 5
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 5
                                        recomendermaxReplicas = 20
                                        recomendertarget = "100%"
                                        commentHPA = None
                                    case 300:
                                        replicasBase = 6
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 6
                                        recomendermaxReplicas = 24
                                        recomendertarget = "120%"
                                        commentHPA = None
                                    case 350:
                                        replicasBase = 6
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 6
                                        recomendermaxReplicas = 24
                                        recomendertarget = "120%"
                                        commentHPA = None
                                    case 450:
                                        replicasBase = 8
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 8
                                        recomendermaxReplicas = 30
                                        recomendertarget = "120%"
                                        commentHPA = None
                                    case 500:
                                        replicasBase = 10
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 10
                                        recomendermaxReplicas = 40
                                        recomendertarget = "120%"
                                        commentHPA = None
                                    case 600:
                                        replicasBase = 12
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 12
                                        recomendermaxReplicas = 50
                                        recomendertarget = "120%"
                                        commentHPA = None
                                    case "Problem":
                                        recomenderHPA = "NO"
                                        recomenderminReplicas = "N/A"
                                        recomendermaxReplicas = "N/A"
                                        recomendertarget = "N/A"
                                        commentHPA = None
                                        replicasBase = "N/A"
                                        valorMEM = "N/A"
                            else:
                                match recomenderCPURequest:
                                    case 50:
                                        if usoCPUTotal < 20:
                                            recomenderHPA = "YES"
                                            if "gateway" in microservice:
                                                recomenderminReplicas = 2
                                                replicasBase = 2
                                            else:
                                                recomenderminReplicas = 1
                                                replicasBase = 1
                                            recomendermaxReplicas = 4
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        else:
                                            replicasBase = 2
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 2
                                            recomendermaxReplicas = 8
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 100:
                                        replicasBase = 2
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 2
                                        recomendermaxReplicas = 10
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 120:
                                        replicasBase = 3
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 3
                                        recomendermaxReplicas = 10
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 150:
                                        replicasBase = 3
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 3
                                        recomendermaxReplicas = 12
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 200:
                                        replicasBase = 4
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 4
                                        recomendermaxReplicas = 16
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 250:
                                        replicasBase = 5
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 5
                                        recomendermaxReplicas = 20
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 300:
                                        replicasBase = 6
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 6
                                        recomendermaxReplicas = 24
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 350:
                                        replicasBase = 6
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 6
                                        recomendermaxReplicas = 24
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 450:
                                        replicasBase = 8
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 8
                                        recomendermaxReplicas = 30
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 500:
                                        replicasBase = 10
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 10
                                        recomendermaxReplicas = 40
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 600:
                                        replicasBase = 12
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 12
                                        recomendermaxReplicas = 50
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case "Problem":
                                        recomenderHPA = "NO"
                                        recomenderminReplicas = "N/A"
                                        recomendermaxReplicas = "N/A"
                                        recomendertarget = "N/A"
                                        commentHPA = None
                                        replicasBase = "N/A"
                                        valorMEM = "N/A"
            else:
                #Recomender MEM Request y MEM Limit para micros no java
                if useMEMAverage < 500:
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "1907 MiB"
                        recomenderMEMRequestInt = 1907
                        recomenderMEMLimit = "3814 MiB"
                        recomenderMEMLimitInt = 3814
                    else:  
                        commentMEM = None
                        recomenderMEMRequest = "500 MiB"
                        recomenderMEMRequestInt = 500
                        recomenderMEMLimit = "1000 MiB"
                        recomenderMEMLimitInt = 1000
                elif useMEMAverage < 975:
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "1907 MiB"
                        recomenderMEMRequestInt = 1907
                        recomenderMEMLimit = "3814 MiB"
                        recomenderMEMLimitInt = 3814
                    else:
                        commentMEM = None
                        recomenderMEMRequest = "975 MiB"
                        recomenderMEMRequestInt = 975
                        recomenderMEMLimit = "1500 MiB"
                        recomenderMEMLimitInt = 1500
                elif useMEMAverage < 1400:
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "1907 MiB"
                        recomenderMEMRequestInt = 1907
                        recomenderMEMLimit = "3814 MiB"
                        recomenderMEMLimitInt = 3814
                    else:
                        commentMEM = None
                        recomenderMEMRequest = "1400 MiB"
                        recomenderMEMRequestInt = 1400
                        recomenderMEMLimit = "2000 MiB"
                        recomenderMEMLimitInt = 2000
                elif useMEMAverage <= 2300:
                    #Poner memory leak
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "2861 MiB"
                        recomenderMEMRequestInt = 2861
                        recomenderMEMLimit = "5722 MiB"
                        recomenderMEMLimitInt = 5722
                    else:
                        if usoCPUTotal >= 800:
                            commentMEM = "MaxRAM 75"
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "2861 MiB"
                            recomenderMEMLimitInt = 2861
                        elif usoCPUTotal < 800:
                            commentMEM = "Possible Memory Leak"
                            recomenderMEMRequest = "Possible Memory Leak"
                            recomenderMEMRequestInt = "Problem"
                            recomenderMEMLimit = "Possible Memory Leak"
                            recomenderMEMLimitInt = "Problem"
                elif useMEMAverage > 2300:
                    if 'datagrid' in microservice:
                        commentMEM = None
                        recomenderMEMRequest = "2861 MiB"
                        recomenderMEMRequestInt = 2861
                        recomenderMEMLimit = "5722 MiB"
                        recomenderMEMLimitInt = 5722
                    else:
                        recomenderMEMRequest = "Possible Memory Leak"
                        recomenderMEMRequestInt = "Problem"
                        recomenderMEMLimit = "Possible Memory Leak"
                        recomenderMEMLimitInt = "Problem"
                        commentMEM = "Possible Memory Leak"
                else:
                    recomenderMEMRequest = None
                    recomenderMEMLimit = None
                    commentMEM = None

                if "config" in microservice:
                    recomenderCPULimit = 750
                    #commentCPULimit = "HC Readiness to 60sg + HC Liveness to 90sg"
                    commentCPULimit = None

                    recomenderHPA = "NO"
                    recomenderminReplicas = "N/A"
                    recomendermaxReplicas = "N/A"
                    recomendertarget = "N/A"
                    commentHPA = None

                    if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem':
                        valorMEM = 'N/A'
                    else:
                        match recomenderCPURequest:
                            case 50:
                                replicasBase = 2
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 100:
                                replicasBase = 2
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 120:
                                replicasBase = 3
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 150:
                                replicasBase = 3
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 200:
                                replicasBase = 4
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 250:
                                replicasBase = 5
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 300:
                                replicasBase = 6
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 350:
                                replicasBase = 6
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 450:
                                replicasBase = 8
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 500:
                                replicasBase = 10
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 600:
                                replicasBase = 12
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case "Problem":
                                replicasBase = "N/A"
                                valorMEM = "N/A"

                    if useMEMAverage < 500:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "3814 MiB"
                            recomenderMEMLimitInt = 3814
                        else:  
                            commentMEM = "MaxRAM 50"
                            recomenderMEMRequest = "500 MiB"
                            recomenderMEMRequestInt = 500
                            recomenderMEMLimit = "1000 MiB"
                            recomenderMEMLimitInt = 1000
                    elif useMEMAverage < 975:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "3814 MiB"
                            recomenderMEMLimitInt = 3814
                        else:
                            commentMEM = "MaxRAM 65"
                            recomenderMEMRequest = "975 MiB"
                            recomenderMEMRequestInt = 975
                            recomenderMEMLimit = "1500 MiB"
                            recomenderMEMLimitInt = 1500
                    elif useMEMAverage < 1400:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "3814 MiB"
                            recomenderMEMLimitInt = 3814
                        else:
                            commentMEM = "MaxRAM 70"
                            recomenderMEMRequest = "1400 MiB"
                            recomenderMEMRequestInt = 1400
                            recomenderMEMLimit = "2000 MiB"
                            recomenderMEMLimitInt = 2000
                    elif useMEMAverage <= 2300:
                        #Poner memory leak
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "2861 MiB"
                            recomenderMEMRequestInt = 2861
                            recomenderMEMLimit = "5722 MiB"
                            recomenderMEMLimitInt = 5722
                        else:
                            if usoCPUTotal >= 800:
                                commentMEM = "MaxRAM 75"
                                recomenderMEMRequest = "1907 MiB"
                                recomenderMEMRequestInt = 1907
                                recomenderMEMLimit = "2861 MiB"
                                recomenderMEMLimitInt = 2861
                            elif usoCPUTotal < 800:
                                commentMEM = "Possible Memory Leak"
                                recomenderMEMRequest = "Possible Memory Leak"
                                recomenderMEMRequestInt = "Problem"
                                recomenderMEMLimit = "Possible Memory Leak"
                                recomenderMEMLimitInt = "Problem"
                    elif useMEMAverage > 2300:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "2861 MiB"
                            recomenderMEMRequestInt = 2861
                            recomenderMEMLimit = "5722 MiB"
                            recomenderMEMLimitInt = 5722
                        else:
                            recomenderMEMRequest = "Possible Memory Leak"
                            recomenderMEMRequestInt = "Problem"
                            recomenderMEMLimit = "Possible Memory Leak"
                            recomenderMEMLimitInt = "Problem"
                            commentMEM = "Possible Memory Leak"
                    else:
                        recomenderMEMRequest = None
                        recomenderMEMLimit = None
                        commentMEM = None


                elif "gateway" in microservice:
                    recomenderCPULimit = 750
                    #commentCPULimit = "HC Readiness to 60sg + HC Liveness to 90sg"
                    commentCPULimit = None

                    if cluster == "probks" or cluster == "dmzbbks" or cluster == "confluent":
                        recomenderHPA = "NO"
                        recomenderminReplicas = "N/A"
                        recomendermaxReplicas = "N/A"
                        recomendertarget = "N/A"
                        commentHPA = None
                    else:
                        if cluster == "dmz2bmov":
                            if namespace == "sanes-homebankmovilidad-pro" or namespace == "sanes-movilidadempdmz2-pro" or namespace =="sanes-movilidadretaildmz2-pro":
                                recomenderHPA = "NO"
                                recomenderminReplicas = "N/A"
                                recomendermaxReplicas = "N/A"
                                recomendertarget = "N/A"
                                commentHPA = None
                            else:
                                if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem':
                                    valorMEM = 'N/A'
                                else:
                                    match recomenderCPURequest:
                                        case 50:
                                            if usoCPUTotal < 20:
                                                recomenderHPA = "YES"
                                                if "gateway" in microservice:
                                                    recomenderminReplicas = 2
                                                    replicasBase = 2
                                                else:
                                                    recomenderminReplicas = 1
                                                    replicasBase = 1
                                                recomendermaxReplicas = 4
                                                recomendertarget = "100%"
                                                commentHPA = None
                                                valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                            else:
                                                replicasBase = 2
                                                recomenderHPA = "YES"
                                                recomenderminReplicas = 2
                                                recomendermaxReplicas = 8
                                                recomendertarget = "100%"
                                                commentHPA = None
                                                valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 100:
                                            replicasBase = 2
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 2
                                            recomendermaxReplicas = 10
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 120:
                                            replicasBase = 3
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 3
                                            recomendermaxReplicas = 10
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 150:
                                            replicasBase = 3
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 3
                                            recomendermaxReplicas = 12
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 200:
                                            replicasBase = 4
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 4
                                            recomendermaxReplicas = 16
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 250:
                                            replicasBase = 5
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 5
                                            recomendermaxReplicas = 20
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 300:
                                            replicasBase = 6
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 6
                                            recomendermaxReplicas = 24
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 350:
                                            replicasBase = 6
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 6
                                            recomendermaxReplicas = 24
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 450:
                                            replicasBase = 8
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 8
                                            recomendermaxReplicas = 30
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 500:
                                            replicasBase = 10
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 10
                                            recomendermaxReplicas = 40
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case 600:
                                            replicasBase = 12
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 12
                                            recomendermaxReplicas = 50
                                            recomendertarget = "120%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        case "Problem":
                                            recomenderHPA = "NO"
                                            recomenderminReplicas = "N/A"
                                            recomendermaxReplicas = "N/A"
                                            recomendertarget = "N/A"
                                            commentHPA = None
                                            replicasBase = "N/A"
                                            valorMEM = "N/A"
                        else:
                            if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem':
                                valorMEM = 'N/A'
                            else:
                                match recomenderCPURequest:
                                    case 50:
                                        if usoCPUTotal < 20:
                                            recomenderHPA = "YES"
                                            if "gateway" in microservice:
                                                recomenderminReplicas = 2
                                                replicasBase = 2
                                            else:
                                                recomenderminReplicas = 1
                                                replicasBase = 1
                                            recomendermaxReplicas = 4
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                        else:
                                            replicasBase = 2
                                            recomenderHPA = "YES"
                                            recomenderminReplicas = 2
                                            recomendermaxReplicas = 8
                                            recomendertarget = "100%"
                                            commentHPA = None
                                            valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 100:
                                        replicasBase = 2
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 2
                                        recomendermaxReplicas = 10
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 120:
                                        replicasBase = 3
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 3
                                        recomendermaxReplicas = 10
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 150:
                                        replicasBase = 3
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 3
                                        recomendermaxReplicas = 12
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 200:
                                        replicasBase = 4
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 4
                                        recomendermaxReplicas = 16
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 250:
                                        replicasBase = 5
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 5
                                        recomendermaxReplicas = 20
                                        recomendertarget = "100%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 300:
                                        replicasBase = 6
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 6
                                        recomendermaxReplicas = 24
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 350:
                                        replicasBase = 6
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 6
                                        recomendermaxReplicas = 24
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 450:
                                        replicasBase = 8
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 8
                                        recomendermaxReplicas = 30
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 550:
                                        replicasBase = 10
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 10
                                        recomendermaxReplicas = 40
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case 600:
                                        replicasBase = 12
                                        recomenderHPA = "YES"
                                        recomenderminReplicas = 12
                                        recomendermaxReplicas = 50
                                        recomendertarget = "120%"
                                        commentHPA = None
                                        valorMEM = recomenderMEMLimitInt * recomenderminReplicas
                                    case "Problem":
                                        recomenderHPA = "NO"
                                        recomenderminReplicas = "N/A"
                                        recomendermaxReplicas = "N/A"
                                        recomendertarget = "N/A"
                                        commentHPA = None
                                        replicasBase = "N/A"
                                        valorMEM = "N/A"

                    if useMEMAverage < 500:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "3814 MiB"
                            recomenderMEMLimitInt = 3814
                        else:  
                            commentMEM = "MaxRAM 50"
                            recomenderMEMRequest = "500 MiB"
                            recomenderMEMRequestInt = 500
                            recomenderMEMLimit = "1000 MiB"
                            recomenderMEMLimitInt = 1000
                    elif useMEMAverage < 975:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "3814 MiB"
                            recomenderMEMLimitInt = 3814
                        else:
                            commentMEM = "MaxRAM 65"
                            recomenderMEMRequest = "975 MiB"
                            recomenderMEMRequestInt = 975
                            recomenderMEMLimit = "1500 MiB"
                            recomenderMEMLimitInt = 1500
                    elif useMEMAverage < 1400:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "3814 MiB"
                            recomenderMEMLimitInt = 3814
                        else:
                            commentMEM = "MaxRAM 70"
                            recomenderMEMRequest = "1400 MiB"
                            recomenderMEMRequestInt = 1400
                            recomenderMEMLimit = "2000 MiB"
                            recomenderMEMLimitInt = 2000
                    elif useMEMAverage <= 2300:
                        #Poner memory leak
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "2861 MiB"
                            recomenderMEMRequestInt = 2861
                            recomenderMEMLimit = "5722 MiB"
                            recomenderMEMLimitInt = 5722
                        else:
                            if usoCPUTotal >= 800:
                                commentMEM = "MaxRAM 75"
                                recomenderMEMRequest = "1907 MiB"
                                recomenderMEMRequestInt = 1907
                                recomenderMEMLimit = "2861 MiB"
                                recomenderMEMLimitInt = 2861
                            elif usoCPUTotal < 800:
                                commentMEM = "Possible Memory Leak"
                                recomenderMEMRequest = "Possible Memory Leak"
                                recomenderMEMRequestInt = "Problem"
                                recomenderMEMLimit = "Possible Memory Leak"
                                recomenderMEMLimitInt = "Problem"
                    elif useMEMAverage > 2300:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "2861 MiB"
                            recomenderMEMRequestInt = 2861
                            recomenderMEMLimit = "5722 MiB"
                            recomenderMEMLimitInt = 5722
                        else:
                            recomenderMEMRequest = "Possible Memory Leak"
                            recomenderMEMRequestInt = "Problem"
                            recomenderMEMLimit = "Possible Memory Leak"
                            recomenderMEMLimitInt = "Problem"
                            commentMEM = "Possible Memory Leak"
                    else:
                        recomenderMEMRequest = None
                        recomenderMEMLimit = None
                        commentMEM = None

                elif "datagrid" in microservice:
                    recomenderCPULimit = 1000
                    commentCPULimit = None

                    recomenderHPA = "NO"
                    recomenderminReplicas = "N/A"
                    recomendermaxReplicas = "N/A"
                    recomendertarget = "N/A"
                    commentHPA = None

                    if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem':
                        valorMEM = 'N/A'
                    else:
                        match recomenderCPURequest:
                            case 50:
                                replicasBase = 2
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 100:
                                replicasBase = 2
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 120:
                                replicasBase = 3
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 150:
                                replicasBase = 3
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 200:
                                replicasBase = 4
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 250:
                                replicasBase = 5
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 300:
                                replicasBase = 6
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 350:
                                replicasBase = 6
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 450:
                                replicasBase = 8
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 500:
                                replicasBase = 10
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case 600:
                                replicasBase = 12
                                valorMEM = recomenderMEMLimitInt * replicasBase
                            case "Problem":
                                replicasBase = "N/A"
                                valorMEM = "N/A"

                    if useMEMAverage < 500:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "3814 MiB"
                            recomenderMEMLimitInt = 3814
                        else:  
                            commentMEM = None
                            recomenderMEMRequest = "500 MiB"
                            recomenderMEMRequestInt = 500
                            recomenderMEMLimit = "1000 MiB"
                            recomenderMEMLimitInt = 1000
                    elif useMEMAverage < 975:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "3814 MiB"
                            recomenderMEMLimitInt = 3814
                        else:
                            commentMEM = None
                            recomenderMEMRequest = "975 MiB"
                            recomenderMEMRequestInt = 975
                            recomenderMEMLimit = "1500 MiB"
                            recomenderMEMLimitInt = 1500
                    elif useMEMAverage < 1400:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "1907 MiB"
                            recomenderMEMRequestInt = 1907
                            recomenderMEMLimit = "3814 MiB"
                            recomenderMEMLimitInt = 3814
                        else:
                            commentMEM = None
                            recomenderMEMRequest = "1400 MiB"
                            recomenderMEMRequestInt = 1400
                            recomenderMEMLimit = "2000 MiB"
                            recomenderMEMLimitInt = 2000
                    elif useMEMAverage <= 2300:
                        #Poner memory leak
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "2861 MiB"
                            recomenderMEMRequestInt = 2861
                            recomenderMEMLimit = "5722 MiB"
                            recomenderMEMLimitInt = 5722
                        else:
                            if usoCPUTotal >= 800:
                                commentMEM = "MaxRAM 75"
                                recomenderMEMRequest = "1907 MiB"
                                recomenderMEMRequestInt = 1907
                                recomenderMEMLimit = "2861 MiB"
                                recomenderMEMLimitInt = 2861
                            elif usoCPUTotal < 800:
                                commentMEM = "Possible Memory Leak"
                                recomenderMEMRequest = "Possible Memory Leak"
                                recomenderMEMRequestInt = "Problem"
                                recomenderMEMLimit = "Possible Memory Leak"
                                recomenderMEMLimitInt = "Problem"
                    elif useMEMAverage > 2300:
                        if 'datagrid' in microservice:
                            commentMEM = None
                            recomenderMEMRequest = "2861 MiB"
                            recomenderMEMRequestInt = 2861
                            recomenderMEMLimit = "5722 MiB"
                            recomenderMEMLimitInt = 5722
                        else:
                            recomenderMEMRequest = "Possible Memory Leak"
                            recomenderMEMRequestInt = "Problem"
                            recomenderMEMLimit = "Possible Memory Leak"
                            recomenderMEMLimitInt = "Problem"
                            commentMEM = "Possible Memory Leak"
                    else:
                        recomenderMEMRequest = None
                        recomenderMEMLimit = None
                        commentMEM = None

                else:
                    if usoCPUTotal < 50:
                        recomenderCPURequest = 50
                        commentCPURequest = None
                        replicasBase = 2
                    elif usoCPUTotal >= 50 and usoCPUTotal < 200:
                        recomenderCPURequest = 50
                        commentCPURequest = None
                        replicasBase = 4
                    elif usoCPUTotal >= 200 and usoCPUTotal < 400:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 4
                    elif usoCPUTotal >= 400 and usoCPUTotal < 600:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 6
                    elif usoCPUTotal >= 600 and usoCPUTotal < 800:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 8
                    elif usoCPUTotal >= 800 and usoCPUTotal < 1200:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 10
                    elif usoCPUTotal >= 1200 and usoCPUTotal < 1400:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 14
                    elif usoCPUTotal >= 1400 and usoCPUTotal < 1600:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 16
                    elif usoCPUTotal >= 1600 and usoCPUTotal < 1800:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 18
                    elif usoCPUTotal >= 1800 and usoCPUTotal < 2000:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 20
                    elif usoCPUTotal >= 2000 and usoCPUTotal < 2200:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 22
                    elif usoCPUTotal >= 2200 and usoCPUTotal < 2600:
                        recomenderCPURequest = 100
                        commentCPURequest = None
                        replicasBase = 24
                    elif usoCPUTotal >= 2600 and usoCPUTotal < 3000:
                        recomenderCPURequest = 110
                        commentCPURequest = "Review replicas"
                        replicasBase = 25
                    elif usoCPUTotal >= 3000 and usoCPUTotal < 3200:
                        recomenderCPURequest = 120
                        commentCPURequest = "Review replicas"
                        replicasBase = 26
                    elif usoCPUTotal >= 3200 and usoCPUTotal < 3500:
                        recomenderCPURequest = 120
                        commentCPURequest = "Review replicas"
                        replicasBase = 27
                    elif usoCPUTotal >= 3500:
                        recomenderCPURequest = "Problem"
                        commentCPURequest = "Review use"
                        replicasBase = "Problem"
                        recomenderHPA = "NO"
                        recomenderminReplicas = "N/A"
                        recomendermaxReplicas = "N/A"
                        recomendertarget = "N/A"
                        commentHPA = "Capacity Problem / Auto-scaling is not recommended"
                    else:
                        recomenderCPURequest = "N/A"
                        commentCPURequest = None
                        replicasBase = "N/A"
                        recomenderHPA = "NO"
                        recomenderminReplicas = "N/A"
                        recomendermaxReplicas = "N/A"
                        recomendertarget = "N/A"
                        commentHPA = None

                recomenderCPULimit = 750
                #commentCPULimit = "HC Readiness to 60sg + HC Liveness to 90sg"
                commentCPULimit = None

                recomenderHPA = "NO"
                recomenderminReplicas = "N/A"
                recomendermaxReplicas = "N/A"
                recomendertarget = "N/A"
                commentHPA = None

                if cluster == "probks" or cluster == "dmzbbks" or cluster == "confluent":
                    recomenderHPA = "NO"
                    recomenderminReplicas = "N/A"
                    recomendermaxReplicas = "N/A"
                    recomendertarget = "N/A"
                    commentHPA = None
                    replicasBase = "N/A"
                    valorMEM = "N/A"

                if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem' or replicasBase == "Problem" or replicasBase == "N/A":
                    valorMEM = 'N/A'
                else:
                    if recomenderMEMLimitInt == None or recomenderMEMLimitInt == 'Problem' or replicasBase == "Problem" or replicasBase == "N/A":
                        valorMEM = 'N/A'
                    else:
                        if recomenderCPURequest == "Problem":
                            valorMEM = "Problem"
                        else:
                            valorMEM = recomenderMEMLimitInt * replicasBase
                        ''' 
                        match recomenderCPURequest:
                                case 50:
                                    if usoCPUTotal < 20:
                                        replicasBase = 1
                                        valorMEM = recomenderMEMLimitInt * replicasBase
                                    else:
                                        replicasBase = 2
                                        valorMEM = recomenderMEMLimitInt * replicasBase
                                case 100:
                                    replicasBase = 2
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case 120:
                                    replicasBase = 3
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case 150:
                                    replicasBase = 3
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case 200:
                                    replicasBase = 4
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case 250:
                                    replicasBase = 5
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case 300:
                                    replicasBase = 6
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case 350:
                                    replicasBase = 6
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case 450:
                                    replicasBase = 8
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case 500:
                                    replicasBase = 10
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case 600:
                                    replicasBase = 12
                                    valorMEM = recomenderMEMLimitInt * replicasBase
                                case "Problem":
                                    replicasBase = "N/A"
                                    valorMEM = "N/A"
                                    '''
            
        else:
            #Recomender MEM Request y MEM Limit para micros no java
            if useMEMAverage < 500:
                if 'datagrid' in microservice:
                    commentMEM = None
                    recomenderMEMRequest = "1907 MiB"
                    recomenderMEMRequestInt = 1907
                    recomenderMEMLimit = "3814 MiB"
                    recomenderMEMLimitInt = 3814
                else:  
                    commentMEM = "MaxRAM 50"
                    recomenderMEMRequest = "500 MiB"
                    recomenderMEMRequestInt = 500
                    recomenderMEMLimit = "1000 MiB"
                    recomenderMEMLimitInt = 1000
            elif useMEMAverage < 975:
                if 'datagrid' in microservice:
                    commentMEM = None
                    recomenderMEMRequest = "1907 MiB"
                    recomenderMEMRequestInt = 1907
                    recomenderMEMLimit = "3814 MiB"
                    recomenderMEMLimitInt = 3814
                else:
                    commentMEM = "MaxRAM 65"
                    recomenderMEMRequest = "975 MiB"
                    recomenderMEMRequestInt = 975
                    recomenderMEMLimit = "1500 MiB"
                    recomenderMEMLimitInt = 1500
            elif useMEMAverage < 1400:
                if 'datagrid' in microservice:
                    commentMEM = None
                    recomenderMEMRequest = "1907 MiB"
                    recomenderMEMRequestInt = 1907
                    recomenderMEMLimit = "3814 MiB"
                    recomenderMEMLimitInt = 3814
                else:
                    commentMEM = "MaxRAM 70"
                    recomenderMEMRequest = "1400 MiB"
                    recomenderMEMRequestInt = 1400
                    recomenderMEMLimit = "2000 MiB"
                    recomenderMEMLimitInt = 2000
            elif useMEMAverage <= 2300:
                #Poner memory leak
                if 'datagrid' in microservice:
                    commentMEM = None
                    recomenderMEMRequest = "2861 MiB"
                    recomenderMEMRequestInt = 2861
                    recomenderMEMLimit = "5722 MiB"
                    recomenderMEMLimitInt = 5722
                else:
                    if usoCPUTotal >= 800:
                        commentMEM = "MaxRAM 75"
                        recomenderMEMRequest = "1907 MiB"
                        recomenderMEMRequestInt = 1907
                        recomenderMEMLimit = "2861 MiB"
                        recomenderMEMLimitInt = 2861
                    elif usoCPUTotal < 800:
                        commentMEM = "Possible Memory Leak"
                        recomenderMEMRequest = "Possible Memory Leak"
                        recomenderMEMRequestInt = "Problem"
                        recomenderMEMLimit = "Possible Memory Leak"
                        recomenderMEMLimitInt = "Problem"
            elif useMEMAverage > 2300:
                if 'datagrid' in microservice:
                    commentMEM = None
                    recomenderMEMRequest = "2861 MiB"
                    recomenderMEMRequestInt = 2861
                    recomenderMEMLimit = "5722 MiB"
                    recomenderMEMLimitInt = 5722
                else:
                    recomenderMEMRequest = "Possible Memory Leak"
                    recomenderMEMRequestInt = "Problem"
                    recomenderMEMLimit = "Possible Memory Leak"
                    recomenderMEMLimitInt = "Problem"
                    commentMEM = "Possible Memory Leak"
            else:
                recomenderMEMRequest = None
                recomenderMEMLimit = None
                commentMEM = None

            recomenderCPULimit = 1000
            #commentCPULimit = "HC Readiness to 60sg + HC Liveness to 120sg"
            commentCPULimit = None

            recomenderHPA = "NO"
            recomenderminReplicas = "N/A"
            recomendermaxReplicas = "N/A"
            recomendertarget = "N/A"

            replicasBase = "N/A"
            valorMEM = "N/A"
                
            if commentHPA == None:
                commentHPA = None

        if valorMEM == "N/A":
            pass
        else:
            if valorMEM < usoMEMTotal:
                recomenderMEMRequest = "Check Memory USE before down MIN PODs"
                recomenderMEMLimit = "Check Memory USE before down MIN PODs"
                commentMEM = "Check Memory USE before down MIN PODs"
                recomenderMEMRequestInt = 'Check Memory USE before down MIN PODs'
                recomenderMEMLimitInt = 'Check Memory USE before down MIN PODs'

        detailMicroserveRecomender = {
            "microservice": microservice,
            "useCPU(95Percentil))": usoCPUTotal,
            "commentCPUUse": commentCPUUse,
            "recomenderCPURequest": recomenderCPURequest,
            "commentCPURequest": commentCPURequest,
            "recomenderCPULimit": recomenderCPULimit,
            "commentCPULimit": commentCPULimit,
            "useMEM(Max+cache))": useMEMAverage,
            "commentMEMUse": commentMEMUse,
            "recomenderMEMRequest": recomenderMEMRequest,
            "recomenderMEMRequestInt": recomenderMEMRequestInt,
            "recomenderMEMLimit": recomenderMEMLimit,
            "recomenderMEMLimitInt": recomenderMEMLimitInt,
            "commentMEM": commentMEM,
            "replicasBase": replicasBase,
            "recomenderHPAImplemented": recomenderHPA,
            "recomenderMINReplicas": recomenderminReplicas,
            "recomenderMAXReplicas": recomendermaxReplicas,
            "recomenderTarget": recomendertarget,
            "commentHPA": commentHPA
        }
        detailMicroserviceRecomenderList.append(detailMicroserveRecomender)

    
    detailNamespaceRecomender = {
        "cluster": cluster,
        "namespace": namespace,
        "microservices": detailMicroserviceRecomenderList
    }
    detailNamespaceRecomenderList = detailNamespaceRecomender

    mg.change_collection(os.getenv("COLLECTION_RECOMENDER"))
    querydbresultsmemory = mg.find({f"namespace":namespace, f"cluster":cluster})
    findnamespacememory = [x for x in querydbresultsmemory]
    if len(findnamespacememory) == 0:                                
        mg.add_data(data=detailNamespaceRecomenderList)
    else:
        mg.update_one(
            { f"namespace":namespace, f"cluster":cluster},
            
            { '$set': {
                f"cluster": cluster,
                f"namespace": namespace,
                f"microservices": detailMicroserviceRecomenderList
                }
            }
            ) 

    return detailNamespaceRecomenderList


async def configOnline(cluster,nmspace,microservice):
    environment = os.getenv("ENVIRONMENT")
    deployConfig = False
    deployment = False
    data1 = {}
    data2 = {}
    dataListBenefit = []
    dataListActual = []
    dataListRecomender = []
    #namespace = nmspace + '-pro'

    clustlist, clusterlistcomplete = await get_clusters()
    reg = next((diccionario['region'] for diccionario in clustlist if cluster in diccionario.values()), None)

    '''
    if cluster == "azure" or cluster == "ocp05azure" or cluster == "dmzbazure":
        reg = ['weu1', 'weu2']
    elif cluster == 'ocppro01.gsc.pro':
        reg = ['weu']
    elif cluster == 'ocpgnr.gsc.pro':
        reg = ['weu1']
    elif cluster == "sgt01.sgt.pro" or cluster == "gsc04.gsc.pro":
        reg = ['cn1', 'cn2']
    elif cluster == 'csa02.csa.pro' or cluster == "gluon01.mex.pro" or cluster == "grav01.mex.pro" or cluster == "mex02.mex.pro" or cluster == "mex02.mex.dmzb" or cluster == "ocp01.mex.pro" or cluster == "ocp02.mex.pro" or cluster == "ocp03.mex.pro" or cluster == "ocp04.mex.pro" or cluster == "ocp05.mex.pro" or cluster == "ocp06.mex.pro" or cluster == "plard01.mex.pro" or cluster == "str01.mex.pro"  or cluster == "gscmx01.gscmx.pro":
        reg = ['mx1', 'mx2']
    else:
        reg = ['bo1', 'bo2']
    '''

    dataOnline = []
    for rlist in reg:
        logger.info(f"*******Starting to extract data from {cluster}-{nmspace}-{rlist}*******")
        dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=rlist)
        deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=rlist)
        hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=rlist)
        pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=rlist)
        
        service = await services(environment,cluster,nmspace,microservice)

        micr = service[0]
        micro = service[1]
        microb = service[2]
        microg = service[3]

        if len(dc[rlist]["items"]) == 0:
            next
        else:
            logger.info(f"########################## Extracting deploymentconfigs ##########################")
            for deco in dc[rlist]["items"]:
                replicas = 0
                deployConfig = True
                microdc = deco["metadata"]["name"]
                marcador = True
                #if cluster == 'confluent':
                    #micr = microdc
                    #micro = microdc
                    #microb = microdc
                    #microg = microdc
                if micro == microdc or microb == microdc or microg == microdc or micr == microdc:
                    logger.info(f"++++++++++++ Namespace: {nmspace} --- Microservice {microdc} ++++++++++++")
                    hpasMic = await hpass(rlist,deco,hpas)
                    if hpasMic != None:
                        del hpasMic['hpaName']
                        del hpasMic['lastScaleTime']
                        del hpasMic['currentReplicas']
                        del hpasMic['desiredReplicas']
                        del hpasMic['currentCPUUsage']
                        del hpasMic['scalingActive']
                        del hpasMic['messageScalingActive']
                        del hpasMic['ableToScale']
                        del hpasMic['messageAbleToScale']

                    cpu_RequestPod = 0
                    cpu_LimitPod = 0
                    memory_RequestPod = 0
                    memory_LimitPod = 0
                    for pod in pods[rlist]["items"]:
                        try:
                            referenceName = pod["metadata"]["ownerReferences"][0]["name"]
                        except KeyError:
                            referenceName = None
                        
                        if referenceName != None:
                            microPodName = referenceName[:referenceName.rfind('-')]
                        else:
                            microPodName = None

                        if microPodName == microdc:
                            try:
                                cpu_RequestPod = pod["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                            except:
                                cpu_RequestPod = 0

                            #Recogemos CPU Limit
                            try:
                                cpu_LimitPod = pod["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                            except:
                                cpu_LimitPod = 0

                            try:
                                memory_RequestPod = pod["spec"]["containers"][0]["resources"]["requests"]["memory"]
                            except:
                                memory_RequestPod = 0

                            #Recogemos MEMORY Limit
                            try:
                                memory_LimitPod = pod["spec"]["containers"][0]["resources"]["limits"]["memory"]
                            except:
                                memory_LimitPod = 0

                            break

                    try:
                        replicas = deco["status"]["replicas"]
                    except:
                        replicas = deco["spec"]["replicas"]

                    try:
                        cpu_Request = deco["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                    except:
                        cpu_Request = cpu_RequestPod

                    #Recogemos CPU Limit
                    try:
                        cpu_Limit = deco["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                    except:
                        cpu_Limit = cpu_LimitPod

                    #Formateo de datos a milicores
                    cpuReq = await formatearcpu(cpu_Request)
                    cpuLim = await formatearcpu(cpu_Limit)

                    #Recogemos MEMORY Request
                    try:
                        memory_Request = deco["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["memory"]
                    except:
                        memory_Request = memory_RequestPod

                    #Recogemos MEMORY Limit
                    try:
                        memory_Limit = deco["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["memory"]
                    except:
                        memory_Limit = memory_LimitPod

                    #Formateo de datos a MiB-GiB
                    if memory_Request == 0:
                        memReqformat = 0
                    else:
                        #Convertimos los datos en bytes
                        memReq = await formatearmemory(memory_Request)
                        #Convertimos los datos en MiB
                        memReqformat = int(memReq/1048576)

                    if memory_Limit == 0:
                        memLimformat = 0
                    else:
                        #Convertimos los datos en bytes
                        memLim = await formatearmemory(memory_Limit)
                        #Convertimos los datos en MiB
                        memLimformat = int(memLim/1048576)
                    
                    maxRam = await maxRAM(micro,deco,memory_Limit,memLimformat)

                    break
                else:
                    try:
                        replicas = deco["status"]["replicas"]
                    except:
                        replicas = deco["spec"]["replicas"]

                    if replicas != 0:
                        marcador = True    

            logger.info(f"########################## Deploymentconfigs extraction completed ##########################")


        if len(deployments[rlist]["items"]) == 0:
            next
        else:
            logger.info(f"########################## Extracting deployments ##########################")
            for deploy in deployments[rlist]["items"]:
                replicas = 0
                marcador = True
                microdeploy = deploy["metadata"]["name"]
                #if cluster == 'confluent':
                    #micr = microdeploy
                    #micro = microdeploy
                    #microb = microdeploy
                    #microg = microdeploy
                if micro == microdeploy or microb == microdeploy or microg == microdeploy or micr == microdeploy:
                    logger.info(f"++++++++++++ Namespace: {nmspace} --- Microservice {microdeploy} ++++++++++++")
                    hpasMic = await hpass(rlist,deploy,hpas)
                    if hpasMic != None:
                        del hpasMic['hpaName']
                        del hpasMic['lastScaleTime']
                        del hpasMic['currentReplicas']
                        del hpasMic['desiredReplicas']
                        del hpasMic['currentCPUUsage']
                        del hpasMic['ableToScale']
                        del hpasMic['messageAbleToScale']
                        del hpasMic['scalingActive']
                        del hpasMic['messageScalingActive']
                        del hpasMic['minMaxReplicas']

                    cpu_RequestPod = 0
                    cpu_LimitPod = 0
                    memory_RequestPod = 0
                    memory_LimitPod = 0
                    for pod in pods[rlist]["items"]:
                        try:
                            referenceName = pod["metadata"]["ownerReferences"][0]["name"]
                        except KeyError:
                            referenceName = None
                        
                        if referenceName != None:
                            microPodName = referenceName[:referenceName.rfind('-')]
                        else:
                            microPodName = None

                        if microPodName == microdeploy:
                            try:
                                cpu_RequestPod = pod["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                            except:
                                cpu_RequestPod = 0

                            #Recogemos CPU Limit
                            try:
                                cpu_LimitPod = pod["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                            except:
                                cpu_LimitPod = 0

                            try:
                                memory_RequestPod = pod["spec"]["containers"][0]["resources"]["requests"]["memory"]
                            except:
                                memory_RequestPod = 0

                            #Recogemos MEMORY Limit
                            try:
                                memory_LimitPod = pod["spec"]["containers"][0]["resources"]["limits"]["memory"]
                            except:
                                memory_LimitPod = 0

                            break

                    try:
                        replicas = deploy["status"]["replicas"]
                    except:
                        replicas = deploy["spec"]["replicas"]

                    try:
                        cpu_Request = deploy["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                    except:
                        #cpu_Request = None
                        cpu_Request = cpu_RequestPod

                    #Recogemos CPU Limit
                    try:
                        cpu_Limit = deploy["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                    except:
                        #cpu_Limit = None
                        cpu_Limit = cpu_LimitPod

                    #Formateo de datos a milicores
                    cpuReq = await formatearcpu(cpu_Request)
                    cpuLim = await formatearcpu(cpu_Limit)

                    #Recogemos MEMORY Request
                    try:
                        memory_Request = deploy["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["memory"]
                    except:
                        #memory_Request = None
                        memory_Request = memory_RequestPod

                    #Recogemos MEMORY Limit
                    try:
                        memory_Limit = deploy["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["memory"]
                    except:
                        #memory_Limit = None
                        memory_Limit = memory_LimitPod

                    #Formateo de datos a MiB-GiB
                    #if memory_Request == None:
                        #memReqformat = None
                    if memory_Request == 0:
                        memReqformat = 0
                    else:
                        #Convertimos los datos en bytes
                        memReq = await formatearmemory(memory_Request)
                        #Convertimos los datos en MiB
                        memReqformat = int(memReq/1048576)

                    #if memory_Limit == None:
                        #memLimformat = None
                    if memory_Limit == 0:
                        memLimformat = 0
                    else:
                        #Convertimos los datos en bytes
                        memLim = await formatearmemory(memory_Limit)
                        #Convertimos los datos en MiB
                        memLimformat = int(memLim/1048576)

                    maxRam, commentMaxRAM = await maxRAM(micro,deploy,memory_Limit,memLimformat)
                    break
                else:
                    try:
                        replicas = deploy["status"]["replicas"]
                    except:
                        replicas = deploy["spec"]["replicas"]

                    if replicas != 0:
                        marcador = True
                logger.info(f"########################## Deployments extraction completed ##########################")

        if marcador != False:
            if rlist == 'bo1' or rlist == 'weu1' or rlist == 'cn1' or rlist == 'mx1' or rlist == 'weu':
                data1 = {
                    "cluster": cluster,
                    "region": rlist,
                    "namespace": nmspace,
                    "microservice": micro,
                    "replicas": replicas,
                    "cpuRequest": cpuReq,
                    "cpuLimit": cpuLim,
                    "memoryRequest": memReqformat,
                    "memoryLimit": memLimformat,
                    "maxRam": maxRam,
                    "hpa": hpasMic
                }
                dataOnline.append(data1)

            if rlist == 'bo2' or rlist == 'weu2' or rlist == 'cn2' or rlist == 'mx2':
                data2 = {
                    "cluster": cluster,
                    "region": rlist,
                    "namespace": nmspace,
                    "microservice": micro,
                    "replicas": replicas,
                    "cpuRequest": cpuReq,
                    "cpuLimit": cpuLim,
                    "memoryRequest": memReqformat,
                    "memoryLimit": memLimformat,
                    "maxRam": maxRam,
                    "hpa": hpasMic
                }
                dataOnline.append(data2)

    if len(data1) != 0 and len(data2) != 0:
        for dat1 in dataOnline:
            if dat1['region'] == "bo1" or dat1['region'] == "weu1" or dat1['region'] == "cn1" or dat1['region'] == "mx1" or rlist == 'weu':
                replicas1 = dat1['replicas']
                cpuRequest1 = dat1['cpuRequest']
                cpuLimit1 = dat1['cpuLimit']
                memoryRequest1 = dat1['memoryRequest']
                memoryLimit1 = dat1['memoryLimit']
                maxRam1 = dat1['maxRam']
                hpa1 = dat1['hpa']
            else:
                replicas2 = dat1['replicas']
                cpuRequest2 = dat1['cpuRequest']
                cpuLimit2 = dat1['cpuLimit']
                memoryRequest2 = dat1['memoryRequest']
                memoryLimit2 = dat1['memoryLimit']
                maxRam2 = dat1['maxRam']
                hpa2 = dat1['hpa']

                if replicas1 == replicas2:
                    replicas = True
                else:
                    replicas = False

                if cpuRequest1 == cpuRequest2:
                    cpuRequest = True
                else:
                    cpuRequest = False
                if cpuLimit1 == cpuLimit2:
                    cpuLimit = True
                else:
                    cpuLimit = False
                if memoryRequest1 == memoryRequest2:
                    memoryRequest = True
                else:
                    memoryRequest = False
                if memoryLimit1 == memoryLimit2:
                    memoryLimit = True
                else:
                    memoryLimit = False
                if maxRam1 == maxRam2:
                    maxRam = True
                else:
                    maxRam = False
                if hpa1 == hpa2:
                    hpa = True
                else:
                    hpa = False
        
        if replicas == True and cpuRequest == True and cpuLimit == True and memoryRequest == True and memoryLimit == True and maxRam == True and hpa == True:
            iguales = True
        else:
            iguales = False

        if iguales == True:
            lastChar = micro[-2] + micro[-1]
            if "-green" in micro:
                microSinSufijo = micro[:-6]
            elif lastChar == '-b' or lastChar == '-g':
                microSinSufijo = micro[:-2]
            elif "-blue" in micro:
                microSinSufijo = micro[:-5]
            else:
                microSinSufijo = micro

            if hpa1 == None:
                hpaImplemented = "NO"
                minReplicas = "N/A"
                maxReplicas = "N/A"
                target = "N/A"
                targetString = "N/A"
            else:
                hpaImplemented = "YES"
                minReplicas = hpa1['minReplicas']
                maxReplicas = hpa1['maxReplicas']
                target = hpa1['targetCPUUtilizationPercentage']
                targetString = str(target) + '%'
                #if minReplicas == maxReplicas:
                replicas1 = minReplicas
                #else:
                    #replicas1 = "N/A"

            configActual = {
                "indicator": "actual",
                "microservice": microSinSufijo,
                "replicas": replicas1,
                "cpuRequest": cpuRequest1,
                "cpuLimit": cpuLimit1,
                "memoryRequest": memoryRequest1,
                "memoryRequestString": str(memoryRequest1) + ' MiB',
                "memoryLimit": memoryLimit1,
                "memoryLimitString": str(memoryLimit1) + ' MiB',
                "maxRAM": 'MaxRAM ' + str(maxRam1),
                "hpaImplemented": hpaImplemented,
                "minReplicas": minReplicas,
                "maxReplicas": maxReplicas,
                "target": target,
                "targetString": targetString
            }
            dataListActual.append(configActual)
        else:
            lastChar = micro[-2] + micro[-1]
            if "-green" in micro:
                microSinSufijo = micro[:-6]
            elif lastChar == '-b' or lastChar == '-g':
                microSinSufijo = micro[:-2]
            elif "-blue" in micro:
                microSinSufijo = micro[:-5]
            else:
                microSinSufijo = micro

            if replicas1 <= replicas2:
                replicas = replicas2
            else:
                replicas = replicas1

            if cpuRequest1 <= cpuRequest2:
                cpuRequest = cpuRequest2
            else:
                cpuRequest = cpuRequest1

            if cpuLimit1 <= cpuLimit2:
                cpuLimit = cpuLimit2
            else:
                cpuLimit = cpuLimit1

            if memoryRequest1 <= memoryRequest2:
                memoryRequest = memoryRequest2
            else:
                memoryRequest = memoryRequest1

            if memoryLimit1 <= memoryLimit2:
                memoryLimit = memoryLimit2
                maxRam = maxRam2
            else:
                memoryLimit = memoryLimit1
                maxRam = maxRam1

            if hpa1 == None and hpa2 == None:
                hpaImplemented = "NO"
                minReplicas = "N/A"
                maxReplicas = "N/A"
                target = "N/A"
                targetString = "N/A"
            elif hpa1 == hpa2:
                hpaImplemented = "YES"
                minReplicas = hpa2['minReplicas']
                maxReplicas = hpa2['maxReplicas']
                target = hpa2['targetCPUUtilizationPercentage']
                targetString = str(target) + '%'
            else:
                hpaImplemented = "YES"
                if hpa1 == None and hpa2 != None:
                    minReplicas = hpa2['minReplicas']
                    maxReplicas = hpa2['maxReplicas']
                    target = hpa2['targetCPUUtilizationPercentage']
                    targetString = str(target) + '%'
                elif hpa1 != None and hpa2 == None:
                    minReplicas = hpa1['minReplicas']
                    maxReplicas = hpa1['maxReplicas']
                    target = hpa1['targetCPUUtilizationPercentage']
                    targetString = str(target) + '%'
                else:
                    if hpa1['minReplicas'] <= hpa2['minReplicas']:
                        minReplicas = hpa2['minReplicas']
                    else:
                        minReplicas = hpa1['minReplicas']

                    if hpa1['maxReplicas'] <= hpa2['maxReplicas']:
                        maxReplicas = hpa2['maxReplicas']
                    else:
                        maxReplicas = hpa1['maxReplicas']
                    
                    if hpa1['targetCPUUtilizationPercentage'] <= hpa2['targetCPUUtilizationPercentage']:
                        target = hpa2['targetCPUUtilizationPercentage']
                        targetString = str(target) + '%'
                    else:
                        target = hpa1['targetCPUUtilizationPercentage']
                        targetString = str(target) + '%'

            configActual = {
                "indicator": "actual",
                "microservice": microSinSufijo,
                "replicas": replicas,
                "cpuRequest": cpuRequest,
                "cpuLimit": cpuLimit,
                "memoryRequest": memoryRequest,
                "memoryRequestString": str(memoryRequest) + ' MiB',
                "memoryLimit": memoryLimit,
                "memoryLimitString": str(memoryLimit) + ' MiB',
                "maxRAM": 'MaxRAM ' + str(maxRam),
                "hpaImplemented": hpaImplemented,
                "minReplicas": minReplicas,
                "maxReplicas": maxReplicas,
                "target": target,
                "targetString": targetString
            }
            dataListActual.append(configActual)

        dataRecomender = await info_recomender(cluster,nmspace)
        #mg.change_collection(os.getenv("COLLECTION_RECOMENDER"))
        #dataRecomender = mg.find_one({f"namespace": nmspace, f"cluster": cluster})
    

        #for dataR in dataRecomender:
        mics = dataRecomender[0]['microservices']
        for m in mics:
            if microSinSufijo == m['microservice']:
                recomenderCPURequest = m['recomenderCPURequest']
                recomenderCPULimit = m['recomenderCPULimit']
                recomenderMEMRequest = m['recomenderMEMRequest']
                recomenderMEMLimit = m['recomenderMEMLimit']
                if recomenderMEMRequest == 'Problem':
                    recomenderMEMRequestInt = 'Problem'
                else:
                    recomenderMEMRequestInt = m['recomenderMEMRequestInt']

                if recomenderMEMLimit == 'Problem':
                    recomenderMEMLimitInt = 'Problem'
                else:
                    recomenderMEMLimitInt = m['recomenderMEMLimitInt']

                recomenderMaxRam = m['commentMEM']
                if recomenderMaxRam == "MaxRAM 50":
                    recomenderMaxRamInt = 50
                elif recomenderMaxRam == "MaxRAM 65":
                    recomenderMaxRamInt = 65
                elif recomenderMaxRam == "MaxRAM 70":
                    recomenderMaxRamInt = 70
                elif recomenderMaxRam == "MaxRAM 70 + review replicas":
                    recomenderMaxRamInt = 70
                else:
                    recomenderMaxRam = "N/A"
                    recomenderMaxRamInt = "N/A"
                recomenderReplicasBase = m['replicasBase']
                recomenderReplicasMin = m['recomenderMINReplicas']
                recomenderReplicasMax = m['recomenderMAXReplicas']
                recomenderTarget = m['recomenderTarget']
                if recomenderTarget == "100%":
                    recomenderTargetInt = 100
                elif recomenderTarget == "120%":
                    recomenderTargetInt = 120
                else:
                    recomenderTarget = "N/A"
                    recomenderTargetInt = "N/A"

                recomenderActual = {
                    "indicator": "recomendado",
                    "microservice": m['microservice'],
                    "replicas": m['replicasBase'],
                    "cpuRequest": m['recomenderCPURequest'],
                    "cpuLimit": m['recomenderCPULimit'],
                    "memoryRequest": recomenderMEMRequestInt,
                    "memoryLimit": recomenderMEMLimitInt,
                    "maxRAM": recomenderMaxRamInt,
                    "minReplicas": m['recomenderMINReplicas'],
                    "maxReplicas": m['recomenderMAXReplicas'],
                    "target": recomenderTargetInt
                }
                dataListRecomender.append(recomenderActual)
                break

        for dataa in dataListActual:
            #if data['indicator'] == "actual":
            replicasActual = dataa['replicas']
            cpuRequestActual = dataa['cpuRequest']
            cpuLimitActual = dataa['cpuLimit']
            memoryRequestActual = dataa['memoryRequest']
            memoryLimitActual = dataa['memoryLimit']
            maxRamActual = dataa['maxRAM']
            minReplicasActual = dataa['minReplicas']
            maxReplicasActual = dataa['maxReplicas']
            targetActual = dataa['target']
            #else:
        
        for datar in dataListRecomender:
            recoReplicas = datar.get(datar['replicas'], 'N/A')
            recoCpuRequest = datar['cpuRequest']
            recoCpuLimit = datar['cpuLimit']
            recoMemoryRequest = datar['memoryRequest']
            recoMemoryLimit = datar['memoryLimit']
            recoMaxRam = datar['maxRAM']
            recoMinReplicas = datar['minReplicas']
            recoMaxReplicas = datar['maxReplicas']
            recoTarget = datar['target']

        if recoReplicas != "N/A":
            requestCPUrecomen = recoCpuRequest * recoReplicas
            if recoMemoryRequest == 'Problem':
                requestMEMrecomen = 'N/A'
            else:
                requestMEMrecomen = recoMemoryRequest * recoReplicas
            limitCPUrecomen = recoCpuLimit * recoReplicas
            if recoMemoryLimit == 'Problem':
                limitMEMrecomen = 'N/A'
            else:
                limitMEMrecomen = recoMemoryLimit * recoReplicas
        else:
            if recoCpuRequest == 'Problem':
                requestCPUrecomen = 'N/A'
            else:
                if recoMinReplicas == 'N/A':
                    requestCPUrecomen = 'N/A'
                else:
                    requestCPUrecomen = recoCpuRequest * recoMinReplicas
            if recoMemoryRequest == 'Problem':
                requestMEMrecomen = 'N/A'
            else:
                if recoMinReplicas == 'N/A':
                    requestMEMrecomen = 'N/A'
                else:
                    requestMEMrecomen = recoMemoryRequest * recoMinReplicas

            if recoCpuLimit == 'Problem':
                limitCPUrecomen = 'N/A'
            else:
                if recoMinReplicas == 'N/A':
                    limitCPUrecomen = 'N/A'
                else:
                    limitCPUrecomen = recoCpuLimit * recoMinReplicas

            if recoMemoryLimit == 'Problem':
                limitMEMrecomen = 'N/A'
            else:
                if recoMinReplicas == 'N/A':
                    limitMEMrecomen = 'N/A'
                else:
                    limitMEMrecomen = recoMemoryLimit * recoMinReplicas

        if cpuRequestActual == None:
            requestCPUactual = 'N/A'
        else:
            if minReplicasActual != "N/A":
                requestCPUactual = cpuRequestActual * minReplicasActual
            else:
                requestCPUactual = cpuRequestActual * replicasActual
        
        if memoryRequestActual == None:
            requestMEMactual = 'N/A'
        else:
            if minReplicasActual != "N/A":
                requestMEMactual = memoryRequestActual * minReplicasActual
            else:
                requestMEMactual = memoryRequestActual * replicasActual

        if cpuLimitActual == None:
            limitCPUactual = 'N/A'
        else:
            if minReplicasActual != "N/A":
                limitCPUactual = cpuLimitActual * minReplicasActual
            else:
                limitCPUactual = cpuLimitActual * replicasActual

        if memoryLimitActual == None:
            limitMEMactual = 'N/A'
        else:
            if minReplicasActual != "N/A":
                limitMEMactual = memoryLimitActual * minReplicasActual
            else:
                limitMEMactual = memoryLimitActual * replicasActual

        if requestCPUrecomen == 'N/A':
            beneficioRequestCPU = 'N/A'
        else:
            if requestCPUactual == 'N/A':
                beneficioRequestCPU = 'N/A'
            else:
                beneficioRequestCPU = requestCPUrecomen - requestCPUactual

        if requestMEMrecomen == 'N/A':
            beneficioRequestMEM = 'N/A'
        else:
            if requestMEMactual == 'N/A':
                beneficioRequestMEM = 'N/A'
            else:
                if 'Check' in str(requestMEMrecomen) or 'Possible' in str(requestMEMrecomen):
                    beneficioRequestMEM = 'N/A'
                else:
                    beneficioRequestMEM = requestMEMrecomen - requestMEMactual
                    #beneficioRequestMEM = str(beneficioRequestMEMInt) + ' MiB'

        if limitCPUrecomen == 'N/A':
            beneficioLimitCPU = 'N/A'
        else:
            if limitCPUactual == 'N/A':
                beneficioLimitCPU = 'N/A'
            else:
                beneficioLimitCPU = limitCPUrecomen - limitCPUactual

        if limitMEMrecomen == 'N/A':
            beneficoLimitMEM = 'N/A'
        else:
            if limitMEMactual == 'N/A':
                beneficoLimitMEM = 'N/A'
            else:
                if 'Check' in str(limitMEMrecomen) or 'Possible' in str(limitMEMrecomen):
                    beneficoLimitMEM = 'N/A'
                else:
                    beneficoLimitMEM = limitMEMrecomen - limitMEMactual
                #beneficoLimitMEM = str(beneficoLimitMEMInt) + ' MiB'

        if recoReplicas != 'N/A':
            if replicasActual != 'N/A':
                beneficioReplicasBase = recoReplicas - replicasActual
            else:
                replicasActual = 0
                beneficioReplicasBase = recoReplicas - replicasActual
        else:
            beneficioReplicasBase = "N/A"
        
        if recoMinReplicas == "N/A" or recoMaxReplicas == "N/A" or recoTarget == "N/A":
            beneficioMinReplicas = "N/A"
            beneficioMaxReplicas = "N/A"
            beneficioTarget = "N/A"
            beneficioTargetString = "N/A"
            '''
            if minReplicasActual == 'N/A' or maxReplicasActual == 'N/A' or targetActual == 'N/A':
                beneficioMinReplicas = "N/A"
                beneficioMaxReplicas = "N/A"
                beneficioTarget = "N/A"
                beneficioTargetString = "N/A"
            else:
                beneficioMinReplicas = recoMinReplicas - minReplicasActual
                beneficioMaxReplicas = recoMaxReplicas - maxReplicasActual
                beneficioTarget = recoTarget - targetActual
                beneficioTargetString = str(beneficioTarget) + '%'
                '''
        else:
            if minReplicasActual == 'N/A' or maxReplicasActual == 'N/A' or targetActual == 'N/A':
                minReplicasActual = 0
                maxReplicasActual = 0
                targetActual = 0
            
            beneficioMinReplicas = recoMinReplicas - minReplicasActual
            beneficioMaxReplicas = recoMaxReplicas - maxReplicasActual
            beneficioTarget = recoTarget - targetActual
            beneficioTargetString = str(beneficioTarget) + '%'
        
        dictBenefit = {
            "beneficioRequestCPU": beneficioRequestCPU,
            "beneficioRequestMEM": beneficioRequestMEM,
            "beneficioLimitCPU": beneficioLimitCPU,
            "beneficoLimitMEM": beneficoLimitMEM,
            "beneficioReplicasBase": beneficioReplicasBase,
            "beneficioMinReplicas": beneficioMinReplicas,
            "beneficioMaxReplicas": beneficioMaxReplicas,
            "beneficioTarget": beneficioTargetString
        }
        dataListBenefit.append(dictBenefit)
    elif len(data1) != 0 and len(data2) == 0:
        for dat1 in dataOnline:
            replicas1 = dat1['replicas']
            cpuRequest1 = dat1['cpuRequest']
            cpuLimit1 = dat1['cpuLimit']
            memoryRequest1 = dat1['memoryRequest']
            memoryLimit1 = dat1['memoryLimit']
            maxRam1 = dat1['maxRam']
            hpa1 = dat1['hpa']
        
        lastChar = micro[-2] + micro[-1]
        if "-green" in micro:
            microSinSufijo = micro[:-6]
        elif lastChar == '-b' or lastChar == '-g':
            microSinSufijo = micro[:-2]
        elif "-blue" in micro:
            microSinSufijo = micro[:-5]
        else:
            microSinSufijo = micro

        if hpa1 == None:
            hpaImplemented = "NO"
            minReplicas = "N/A"
            maxReplicas = "N/A"
            target = "N/A"
            targetString = "N/A"
        else:
            hpaImplemented = "YES"
            minReplicas = hpa1['minReplicas']
            maxReplicas = hpa1['maxReplicas']
            target = hpa1['targetCPUUtilizationPercentage']
            targetString = str(target) + '%'
            #if minReplicas == maxReplicas:
            replicas1 = minReplicas
            #else:
                #replicas1 = "N/A"

        configActual = {
            "indicator": "actual",
            "microservice": microSinSufijo,
            "replicas": replicas1,
            "cpuRequest": cpuRequest1,
            "cpuLimit": cpuLimit1,
            "memoryRequest": memoryRequest1,
            "memoryRequestString": str(memoryRequest1) + ' MiB',
            "memoryLimit": memoryLimit1,
            "memoryLimitString": str(memoryLimit1) + ' MiB',
            "maxRAM": 'MaxRAM ' + str(maxRam1),
            "hpaImplemented": hpaImplemented,
            "minReplicas": minReplicas,
            "maxReplicas": maxReplicas,
            "target": target,
            "targetString": targetString
        }
        dataListActual.append(configActual)
        
        dataRecomender = await info_recomender(cluster,nmspace)
        #mg.change_collection(os.getenv("COLLECTION_RECOMENDER"))
        #dataRecomender = mg.find_one({f"namespace": nmspace, f"cluster": cluster})
    

        #for dataR in dataRecomender:
        mics = dataRecomender[0]['microservices']
        for m in mics:
            if microSinSufijo == m['microservice']:
                recomenderCPURequest = m['recomenderCPURequest']
                recomenderCPULimit = m['recomenderCPULimit']
                recomenderMEMRequest = m['recomenderMEMRequest']
                recomenderMEMLimit = m['recomenderMEMLimit']
                if recomenderMEMRequest == 'Problem':
                    recomenderMEMRequestInt = 'Problem'
                else:
                    recomenderMEMRequestInt = m['recomenderMEMRequestInt']

                if recomenderMEMLimit == 'Problem':
                    recomenderMEMLimitInt = 'Problem'
                else:
                    recomenderMEMLimitInt = m['recomenderMEMLimitInt']

                recomenderMaxRam = m['commentMEM']
                if recomenderMaxRam == "MaxRAM 50":
                    recomenderMaxRamInt = 50
                elif recomenderMaxRam == "MaxRAM 65":
                    recomenderMaxRamInt = 65
                elif recomenderMaxRam == "MaxRAM 70":
                    recomenderMaxRamInt = 70
                elif recomenderMaxRam == "MaxRAM 70 + review replicas":
                    recomenderMaxRamInt = 70
                else:
                    recomenderMaxRam = "N/A"
                    recomenderMaxRamInt = "N/A"
                recomenderReplicasBase = m['replicasBase']
                recomenderReplicasMin = m['recomenderMINReplicas']
                recomenderReplicasMax = m['recomenderMAXReplicas']
                recomenderTarget = m['recomenderTarget']
                if recomenderTarget == "100%":
                    recomenderTargetInt = 100
                elif recomenderTarget == "120%":
                    recomenderTargetInt = 120
                else:
                    recomenderTarget = "N/A"
                    recomenderTargetInt = "N/A"

                recomenderActual = {
                    "indicator": "recomendado",
                    "microservice": m['microservice'],
                    "replicas": m['replicasBase'],
                    "cpuRequest": m['recomenderCPURequest'],
                    "cpuLimit": m['recomenderCPULimit'],
                    "memoryRequest": recomenderMEMRequestInt,
                    "memoryLimit": recomenderMEMLimitInt,
                    "maxRAM": recomenderMaxRamInt,
                    "minReplicas": m['recomenderMINReplicas'],
                    "maxReplicas": m['recomenderMAXReplicas'],
                    "target": recomenderTargetInt
                }
                dataListRecomender.append(recomenderActual)
                break

        for dataa in dataListActual:
            #if data['indicator'] == "actual":
            replicasActual = dataa['replicas']
            cpuRequestActual = dataa['cpuRequest']
            cpuLimitActual = dataa['cpuLimit']
            memoryRequestActual = dataa['memoryRequest']
            memoryLimitActual = dataa['memoryLimit']
            maxRamActual = dataa['maxRAM']
            minReplicasActual = dataa['minReplicas']
            maxReplicasActual = dataa['maxReplicas']
            targetActual = dataa['target']
            #else:
        
        for datar in dataListRecomender:
            recoReplicas = datar.get(datar['replicas'], 'N/A')
            recoCpuRequest = datar['cpuRequest']
            recoCpuLimit = datar['cpuLimit']
            recoMemoryRequest = datar['memoryRequest']
            recoMemoryLimit = datar['memoryLimit']
            recoMaxRam = datar['maxRAM']
            recoMinReplicas = datar['minReplicas']
            recoMaxReplicas = datar['maxReplicas']
            recoTarget = datar['target']

        if recoReplicas != "N/A":
            requestCPUrecomen = recoCpuRequest * recoReplicas
            if recoMemoryRequest == 'Problem':
                requestMEMrecomen = 'N/A'
            else:
                requestMEMrecomen = recoMemoryRequest * recoReplicas
            limitCPUrecomen = recoCpuLimit * recoReplicas
            if recoMemoryLimit == 'Problem':
                limitMEMrecomen = 'N/A'
            else:
                limitMEMrecomen = recoMemoryLimit * recoReplicas
        else:
            if recoCpuRequest == 'Problem':
                requestCPUrecomen = 'N/A'
            else:
                if recoMinReplicas == 'N/A':
                    requestCPUrecomen = 'N/A'
                else:
                    requestCPUrecomen = recoCpuRequest * recoMinReplicas
            if recoMemoryRequest == 'Problem':
                requestMEMrecomen = 'N/A'
            else:
                if recoMinReplicas == 'N/A':
                    requestMEMrecomen = 'N/A'
                else:
                    requestMEMrecomen = recoMemoryRequest * recoMinReplicas

            if recoCpuLimit == 'Problem':
                limitCPUrecomen = 'N/A'
            else:
                if recoMinReplicas == 'N/A':
                    limitCPUrecomen = 'N/A'
                else:
                    limitCPUrecomen = recoCpuLimit * recoMinReplicas

            if recoMemoryLimit == 'Problem':
                limitMEMrecomen = 'N/A'
            else:
                if recoMinReplicas == 'N/A':
                    limitMEMrecomen = 'N/A'
                else:
                    limitMEMrecomen = recoMemoryLimit * recoMinReplicas

        if cpuRequestActual == None:
            requestCPUactual = 'N/A'
        else:
            if minReplicasActual != "N/A":
                requestCPUactual = cpuRequestActual * minReplicasActual
            else:
                requestCPUactual = cpuRequestActual * replicasActual
        
        if memoryRequestActual == None:
            requestMEMactual = 'N/A'
        else:
            if minReplicasActual != "N/A":
                requestMEMactual = memoryRequestActual * minReplicasActual
            else:
                requestMEMactual = memoryRequestActual * replicasActual

        if cpuLimitActual == None:
            limitCPUactual = 'N/A'
        else:
            if minReplicasActual != "N/A":
                limitCPUactual = cpuLimitActual * minReplicasActual
            else:
                limitCPUactual = cpuLimitActual * replicasActual

        if memoryLimitActual == None:
            limitMEMactual = 'N/A'
        else:
            if minReplicasActual != "N/A":
                limitMEMactual = memoryLimitActual * minReplicasActual
            else:
                limitMEMactual = memoryLimitActual * replicasActual

        if requestCPUrecomen == 'N/A':
            beneficioRequestCPU = 'N/A'
        else:
            if requestCPUactual == 'N/A':
                beneficioRequestCPU = 'N/A'
            else:
                beneficioRequestCPU = requestCPUrecomen - requestCPUactual

        if requestMEMrecomen == 'N/A':
            beneficioRequestMEM = 'N/A'
        else:
            if requestMEMactual == 'N/A':
                beneficioRequestMEM = 'N/A'
            else:
                if 'Check' in str(requestMEMrecomen) or 'Possible' in str(requestMEMrecomen):
                    beneficioRequestMEM = 'N/A'
                else:
                    beneficioRequestMEM = requestMEMrecomen - requestMEMactual
                    #beneficioRequestMEM = str(beneficioRequestMEMInt) + ' MiB'

        if limitCPUrecomen == 'N/A':
            beneficioLimitCPU = 'N/A'
        else:
            if limitCPUactual == 'N/A':
                beneficioLimitCPU = 'N/A'
            else:
                beneficioLimitCPU = limitCPUrecomen - limitCPUactual

        if limitMEMrecomen == 'N/A':
            beneficoLimitMEM = 'N/A'
        else:
            if limitMEMactual == 'N/A':
                beneficoLimitMEM = 'N/A'
            else:
                if 'Check' in str(limitMEMrecomen) or 'Possible' in str(limitMEMrecomen):
                    beneficoLimitMEM = 'N/A'
                else:
                    beneficoLimitMEM = limitMEMrecomen - limitMEMactual
                #beneficoLimitMEM = str(beneficoLimitMEMInt) + ' MiB'

        if recoReplicas != 'N/A':
            if replicasActual != 'N/A':
                beneficioReplicasBase = recoReplicas - replicasActual
            else:
                replicasActual = 0
                beneficioReplicasBase = recoReplicas - replicasActual
        else:
            beneficioReplicasBase = "N/A"
        
        if recoMinReplicas == "N/A" or recoMaxReplicas == "N/A" or recoTarget == "N/A":
            beneficioMinReplicas = "N/A"
            beneficioMaxReplicas = "N/A"
            beneficioTarget = "N/A"
            beneficioTargetString = "N/A"
            '''
            if minReplicasActual == 'N/A' or maxReplicasActual == 'N/A' or targetActual == 'N/A':
                beneficioMinReplicas = "N/A"
                beneficioMaxReplicas = "N/A"
                beneficioTarget = "N/A"
                beneficioTargetString = "N/A"
            else:
                beneficioMinReplicas = recoMinReplicas - minReplicasActual
                beneficioMaxReplicas = recoMaxReplicas - maxReplicasActual
                beneficioTarget = recoTarget - targetActual
                beneficioTargetString = str(beneficioTarget) + '%'
                '''
        else:
            if minReplicasActual == 'N/A' or maxReplicasActual == 'N/A' or targetActual == 'N/A':
                minReplicasActual = 0
                maxReplicasActual = 0
                targetActual = 0
            
            beneficioMinReplicas = recoMinReplicas - minReplicasActual
            beneficioMaxReplicas = recoMaxReplicas - maxReplicasActual
            beneficioTarget = recoTarget - targetActual
            beneficioTargetString = str(beneficioTarget) + '%'
        
        dictBenefit = {
            "beneficioRequestCPU": beneficioRequestCPU,
            "beneficioRequestMEM": beneficioRequestMEM,
            "beneficioLimitCPU": beneficioLimitCPU,
            "beneficoLimitMEM": beneficoLimitMEM,
            "beneficioReplicasBase": beneficioReplicasBase,
            "beneficioMinReplicas": beneficioMinReplicas,
            "beneficioMaxReplicas": beneficioMaxReplicas,
            "beneficioTarget": beneficioTargetString
        }
        dataListBenefit.append(dictBenefit)
    else:
        dataListActual = []
        dataListRecomender = []
        dataListBenefit = []

    return dataListActual, dataListRecomender, dataListBenefit


async def info_recomender(cluster,namespace):
    
    urlapi = os.getenv("API_RECOMENDER_URL") #set api url where the information will be extracted
    path = os.getenv("API_RECOMENDER_PATH") #set api path

    body = {
        "cluster": cluster,
        "namespace": namespace
        }
    async with aiohttp.ClientSession() as session:
        async with session.post(urlapi+path, json=body, ssl=False) as resp:
            logger.debug(f"API {urlapi+path} with response status: {resp.status}, cluster: {cluster}, namespace: {namespace}")
            if resp.status == 200:
                data = await resp.text()
                return json.loads(data)
            else:
                return None
            

async def maxRAM(microservice,dc,memory_Limit,memLimG):
    """
    Calculate the maximum RAM percentage based on the given parameters.
    Parameters:
    - microservice (str): The name of the microservice.
    - dc (dict): The dictionary containing the deployment configuration.
    - memory_Limit (str): The memory limit of the microservice.
    - memLimG (str): The memory limit in gigabytes.
    Returns:
    - maxR (int): The maximum RAM percentage.
    Raises:
    - KeyError: If the required keys are not found in the deployment configuration.
    Notes:
    - This function determines whether the microservice is a Java microservice based on its name and the deployment configuration.
    - If the microservice is not a Java microservice, the function returns "N/A" and provides a comment explaining the reason.
    - If the microservice is a Java microservice, the function checks the environment variable "JAVA_OPTS_EXT" in the deployment configuration to find the "MaxRAMPercentage" value.
    - The function compares the "MaxRAMPercentage" value with the memory limit and provides a comment indicating whether it is configured correctly or not.
    - If the "MaxRAMPercentage" value is not found or the environment variable is not configured, the function returns "N/A" and provides a comment explaining the reason.
    - If the "JAVA_OPTS_EXT" environment variable is empty, the function returns "N/A" and provides a comment indicating that it is empty.
    - If the "JAVA_OPTS_EXT" environment variable does not exist, the function returns "N/A" and provides a comment indicating that it does not exist.
    - If the "MaxRAMPercentage" value is not standard according to the ARQ recommendations, the function provides a comment indicating that it is not standard.
    """
    if "java" in microservice or 'gateway' in microservice:
        java = True
    else:
        try:
            template = dc["metadata"]["labels"]["template"]
            if template == "nginx" or "nginx" in template:
                java = False
            else:
                java = True
            votokpiptype = "N/A"
        except:
            try:
                votokpiptype = dc["metadata"]["labels"]["vostok-pipeline-type"]
                if votokpiptype == "ANGULAR-APPLICATION":
                    java = False
                else:
                    java = True
                template = "N/A"
            except:
                template = ""
                votokpiptype = ""
                java = False

    if java == False:
        if template == "nginx" or votokpiptype == "ANGULAR-APPLICATION" or "nginx" in template:
            maxR = "N/A"
            maxRAMComment = f'{microservice} is not a java microservice'
        else: 
            maxR = "N/A"
            maxRAMComment = f'{microservice} could not identify if it is a java microservice'
    else:       
        try:
            env = dc["spec"]['template']['spec']['containers'][0]['env']
        except KeyError:
            env = None
        
        if env != None:
            for elem in env:
                try:
                    if elem["name"] == "JAVA_OPTS_EXT":
                        #MAXRAM
                        dato = elem["value"]
                        result = dato.rfind("MaxRAMPercentage")

                        if result != -1:
                            maxRAM=dato[dato.rfind("MaxRAMPercentage")-4:dato.rfind("MaxRAMPercentage")+len("MaxRAMPercentage")+3]
                            maxR = int(maxRAM[maxRAM.find("=")+1:])
                            
                            if maxR == 50:
                                if memory_Limit == "1G" or memory_Limit == "1Gi" or memory_Limit == "1000M" or memory_Limit == "1000Mi" or memory_Limit == "1024M" or memory_Limit == "1024Mi":
                                    maxRAMComment = f'MaxRAMPercentage is configured OK according to the memory limit ({memLimG})'
                                else:
                                    maxRAMComment = f'MaxRAMPercentage {maxR} is NOT configured OK according to the memory limit ({memLimG})'
                            elif maxR == 65 or maxR == 60:
                                if memory_Limit == "1.5G" or memory_Limit == "1.5Gi" or memory_Limit == "1500M" or memory_Limit == "1500Mi" or memory_Limit == "1536M" or memory_Limit == "1536Mi":
                                    maxRAMComment = f'MaxRAMPercentage is configured OK according to the memory limit ({memLimG})'
                                else:
                                    maxRAMComment = f'MaxRAMPercentage {maxR} is NOT configured OK according to the memory limit ({memLimG})'
                            elif maxR == 70:
                                if memory_Limit == "2G" or memory_Limit == "2Gi" or memory_Limit == "2000M" or memory_Limit == "2000Mi" or memory_Limit == "2048M" or memory_Limit == "2048Mi":
                                    maxRAMComment = f'MaxRAMPercentage is configured OK according to the memory limit ({memLimG})'
                                else:
                                    maxRAMComment = f'MaxRAMPercentage {maxR} is NOT configured OK according to the memory limit ({memLimG})'
                            else:
                                maxRAMComment = f'MaxRAMPercentage {maxR} is NOT standard according to the ARQ recommendations'
                            break
                        else:
                            maxR = "N/A"
                            maxRAMComment = f'MaxRAMPercentage parameters is not configured on JAVA_OPTS_EXT'
                                                 
                        break
                    else:
                        maxR = "N/A"
                        maxRAMComment = f'Environment variable JAVA_OPTS_EXT does not exist'
                except KeyError:
                    maxR = "N/A"
                    maxRAMComment = f'The JAVA_OPTS_EXT environment variable is empty' 
                    break
        else:
            maxR = "N/A"
            maxRAMComment = f'Environment variable JAVA_OPTS_EXT does not exist' 

    return maxR, maxRAMComment


async def get_max_ram_percentage(maxram_string):
    """
    Extracts the maximum RAM percentage from a given string.
    Args:
        maxram_string (str): The string containing the maximum RAM percentage.
    Returns:
        int or str: The maximum RAM percentage as an integer if it is a number, otherwise the original string.
    """
    inicio = 0
    try:
        maxram = int(maxram_string)
    except:
        for i, char in enumerate(maxram_string):
 
            if inicio == 0 and char.isdigit():
                inicio = i
            elif inicio != 0 and not char.isdigit():
                fin = i
                break
        else:
            fin = len(maxram_string)            
 
        if inicio != 0:
            try: maxram = int(maxram_string[inicio:fin])
            except: maxram = maxram_string
        else:
            maxram = maxram_string
   
    return maxram


async def exportdifferentrecommendation(namespace, cluster=None):
    """
    Retrieves and exports different between actual configuration and recommendations for microservices in a given namespace and cluster.
 
    Args:
        namespace (str): The namespace to retrieve recommendations for.
        cluster (str, optional): The cluster to retrieve recommendations for. Defaults to None.
 
    Returns:
        list: A list of dictionaries representing the different recommendations for microservices.
    """
    mg.change_collection(os.getenv("COLLECTION_RECOMENDER"))
    myquery = {"namespace": namespace}
    if cluster is not None:
        myquery["cluster"] = cluster
    querydbresult = mg.find(myquery)
    recodblist = list(querydbresult)
    listmicrosdiff = []
    retries = 3
    delay = 1
   
    if len(recodblist) == 0:
        return {"No data found in the recomender database"}
 
    for clust in recodblist:
        logger.info(f"*******Starting to check data from {cluster}-{namespace}*******")
        microactual = None
        microreco = None
        for micro in clust["microservices"]:
            logger.info(f"*******Starting to check data from {micro['microservice']}*******")
           
            for _ in range(retries):
                try:
                    conflist, recolist, benefit = await configOnline(clust["cluster"],namespace,micro["microservice"])
                    if len(conflist) > 0 and len(recolist) > 0:
                        conf = conflist[0]
                        reco = recolist[0]
 
                        del conf["indicator"]
                        del conf["microservice"]
                        del conf["memoryRequestString"]
                        del conf["memoryLimitString"]
                        del conf["hpaImplemented"]
                        del conf["targetString"]
                        conf["maxRAM"] = await get_max_ram_percentage(conf["maxRAM"])
           
                        del reco["indicator"]
                        del reco["microservice"]
                       
                        if micro["commentMEM"] is None :
                            maxram = 'N/A'
                        else:
                            maxram = await get_max_ram_percentage(micro["commentMEM"])
                        reco["maxRAM"] = maxram
 
                        microactual = {"cluster" : clust["cluster"], "namespace" : namespace, "microservice" : micro["microservice"], "indicator" : "actual"}
                        microactual.update(conf)
   
                        microreco = {"cluster" : clust["cluster"], "namespace" : namespace, "microservice" : micro["microservice"], "indicator" : "recommendation"}
                        microreco.update(reco)
 
                        break
                    else:
                        await asyncio.sleep(delay)
                except:
                    await asyncio.sleep(delay)
            else:
                microactual = {"cluster" : clust["cluster"], "namespace" : namespace, "microservice" : micro["microservice"], "indicator" : "Problem to get actual configuration, check your self"}
 
                if micro["commentMEM"] is None :
                    maxram = 'N/A'
                else:
                    maxram = await get_max_ram_percentage(micro["commentMEM"])
                microreco = {
                    "cluster" : clust["cluster"],
                    "namespace" : namespace,
                    "microservice" : micro["microservice"],
                    "indicator" : "recommendation",
                    "replicas": micro["replicasBase"],
                    "cpuRequest": micro["recomenderCPURequest"],
                    "cpuLimit": micro["recomenderCPULimit"],
                    "memoryRequest": micro["recomenderMEMRequestInt"],
                    "memoryLimit": micro["recomenderMEMLimitInt"],
                    "maxRAM": maxram,
                    "minReplicas": micro["recomenderMINReplicas"],
                    "maxReplicas": micro["recomenderMAXReplicas"],
                    "target": micro["recomenderTarget"]
                    }
 
            microuse = {
                "cluster" : clust["cluster"],
                "namespace" : namespace,
                "microservice" : micro["microservice"],
                "indicator" : "use",
                "replicas": "N/A",
                "cpuRequest": micro["useCPU(95Percentil))"],
                "cpuLimit": "N/A",
                "memoryRequest": micro["useMEM(Max+cache))"],
                "memoryLimit": "N/A",
                "maxRAM": "N/A",
                "minReplicas": "N/A",
                "maxReplicas": "N/A",
                "target": "N/A"
            }
 
            listmicrosdiff.append(microuse)
            listmicrosdiff.append(microactual)
            listmicrosdiff.append(microreco)
                                               
    return listmicrosdiff