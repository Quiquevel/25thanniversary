from shuttlelib.helper.keys import get_enviroment
from shuttlelib.utils.logger import logger
import os, aiohttp
import datetime
from src.services.Estructural import traductorcluster,elastic,hpass,blockproductive,calcularTotalNamespace,control_errores,formatearcpu,formatearmemory,totalusomicro,client,mg,elastic_gpw,get_event_week,get_pod_lifetime,totalusomicro_maxhpa,get_clusters,extraer_cluster
from src.services.Recomender import maxRAM, info_recomender


async def get_capacity_week(cluster,region=None,namespace=None):
    environment = os.getenv("ENVIRONMENT")
    cpumemoryList = []
    nsSinDatos = []

    fecha = datetime.datetime.now()
    print(f"Inicio {cluster}: ", fecha)
    match region:
        case None:
            clustlist, clusterlistcomplete = await get_clusters()
            reg = next((diccionario['region'] for diccionario in clustlist if cluster in diccionario.values()), None)
            
            '''
            if cluster == 'sgt01.sgt.pro':
                reg = {'sgt01.sgt.pro':['cn1','cn2']}
            elif cluster == 'sgt01.sgt.dmzb':
                reg = {'sgt01.sgt.dmzb':['cn1','cn2']}
            elif cluster == 'gsc04.gsc.pro':
                reg = {'gsc04.gsc.pro':['cn1','cn2']}
            elif cluster == 'gsc04.gsc.dmzb':
                reg = {'gsc04.gsc.dmzb':['cn1','cn2']}
            elif cluster == 'ocppro01.gsc.pro':
                reg = {'ocppro01.gsc.pro':['weu']}
            elif cluster == 'ocpgnr.gsc.pro':
                reg = {'ocpgnr.gsc.pro':['weu1']}
            elif cluster == 'csa02.csa.pro':
                reg = {'csa02.csa.pro':['mx1','mx2']}
            elif cluster == 'gluon01.mex.pro':
                reg = {'gluon01.mex.pro':['mx1','mx2']}
            elif cluster == 'grav01.mex.pro':
                reg = {'grav01.mex.pro':['mx1','mx2']}
            elif cluster == 'mex02.mex.pro':
                reg = {'mex02.mex.pro':['mx1','mx2']}
            elif cluster == 'mex02.mex.dmzb':
                reg = {'mex02.mex.dmzb':['mx1','mx2']}
            elif cluster == 'ocp01.mex.pro':
                reg = {'ocp01.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp02.mex.pro':
                reg = {'ocp02.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp03.mex.pro':
                reg = {'ocp03.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp04.mex.pro':
                reg = {'ocp04.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp05.mex.pro':
                reg = {'ocp05.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp06.mex.pro':
                reg = {'ocp06.mex.pro':['mx1','mx2']}
            elif cluster == 'plard01.mex.pro':
                reg = {'plard01.mex.pro':['mx1','mx2']}
            elif cluster == 'str01.mex.pro':
                reg = {'str01.mex.pro':['mx1','mx2']}
            elif cluster == 'gscmx01.gscmx.pro':
                reg = {'gscmx01.gscmx.pro':['mx1','mx2']}
            elif cluster == 'scg01.scg.pro':
                reg = {'scg01.scg.pro':['bo1','bo2']}
            elif cluster == 'scg01.scg.dmzb':
                reg = {'scg01.scg.dmzb':['bo1','bo2']}
            else:
                reg = get_enviroment(environment)
            '''
            #for rg in reg[cluster]:
            for rg in reg:
                url = next((dic['url'] for dic in clusterlistcomplete if cluster in dic.values() and rg in dic.values()), None)
                machine = await extraer_cluster(url)

                nsSinConexion = []
                nsSinDCoDeploy = []
                nsSinReplicas = []
                match namespace:
                    case None:
                        try:
                            ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=rg)
                            for i in ns[rg]["items"]:
                                try:
                                    nmspace = i["metadata"]["name"]
                                    uid = i["metadata"]["uid"]
                                    logger.info(f"*******Starting to extract data from {cluster}-{nmspace}-{rg}*******")
                                    dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=rg)
                                    deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=rg)
                                    statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=nmspace,region=rg)
                                    hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=rg)
                                    pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=rg)

                                    if dc[rg] == 403 or deployments[rg] == 403 or hpas[rg] == 403 or pods[rg] == 403:
                                        cpumemoryList = [[],0,[]]
                                        nsSinConexion.append(nmspace)
                                    elif len(dc[rg]["items"]) == 0 and len(deployments[rg]["items"]) == 0:
                                        cpumemoryList = [[],0,[]]
                                        nsSinDCoDeploy.append(nmspace)
                                    else:
                                        if len(pods[rg]["items"]) == 0:
                                            cpumemoryList = [[],0,[]]
                                            nsSinReplicas.append(nmspace)
                                        else:
                                            cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=nmspace,region=rg,cluster=cluster,maquine=machine)

                                    if len(cpumemoryList[0]) == 0:
                                        cpumemoryList = f"All namespace microservices {nmspace}, they are off"
                                        nsSinReplicas.append(nmspace)
                                    else:
                                        await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=rg,namespace=nmspace,uid=uid)
                                        logger.info(f"******* Extraction completed for {cluster}---{nmspace}---{rg} *******")
                                except:
                                    logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                                    continue
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against {environment+cluster+rg} ")
                            continue
                        except:
                            logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                            continue
                    case _:
                        try:
                            ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=rg)
                            for i in ns[rg]["items"]:
                                nmspace = i["metadata"]["name"]
                                if nmspace==namespace:
                                    uid = i["metadata"]["uid"]
                                    break

                            logger.info(f"******* Starting to extract data from {cluster}---{namespace}---{rg} *******")
                            dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=rg)
                            deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=rg)
                            statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=namespace,region=rg)
                            hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=rg)
                            pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=rg)

                            if dc[rg] == 403 or deployments[rg] == 403 or hpas[rg] == 403 or pods[rg] == 403:
                                cpumemoryList = [[],0,[]]
                                nsSinConexion.append(namespace)
                            elif len(dc[rg]["items"]) == 0 and len(deployments[rg]["items"]) == 0:
                                cpumemoryList = [[],0,[]]
                                nsSinDCoDeploy.append(namespace)
                            else:
                                if len(pods[rg]["items"]) == 0:
                                    cpumemoryList = [[],0,[]]
                                    nsSinReplicas.append(namespace)
                                else:
                                    cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=namespace,region=rg,cluster=cluster,maquine=machine)

                            if len(cpumemoryList[0]) == 0:
                                cpumemoryList = f"All namespace microservices {namespace}, they are off"
                                nsSinReplicas.append(namespace)
                            else:
                                logger.info(f"Saving data")
                                await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=rg,namespace=namespace,uid=uid)
                                logger.info(f"******* Extraction completed for {cluster}---{namespace}---{rg} *******")
                            
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against {environment+cluster+rg} ")
                            continue
                        except:
                            logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                            continue
                nsSinDCoDeployUnicos = list(set(nsSinDCoDeploy))
                nsSinConexionUnicos = list(set(nsSinConexion)) 
                nsSinReplicasUnicos = list(set(nsSinReplicas))   
                namesSinDat = {
                    "cluster": cluster,
                    "region": rg,
                    "namespacesSinDcoDeploy": nsSinDCoDeployUnicos,
                    "namespaceSinConexion": nsSinConexionUnicos,
                    "namespaceSinReplicas": nsSinReplicasUnicos
                }
                nsSinDatos.append(namesSinDat)
        case _:
            clustlist, clusterlistcomplete = await get_clusters()
            url = next((dic['url'] for dic in clusterlistcomplete if cluster in dic.values() and region in dic.values()), None)
            machine = await extraer_cluster(url)
            nsSinConexion = []
            nsSinDCoDeploy = []
            nsSinReplicas = []
            match namespace:
                case None:
                    await control_errores(region,cluster,environment) 
                    try:
                        ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=region)
                        for i in ns[region]["items"]:
                            try:
                                nmspace = i["metadata"]["name"]
                                if nmspace == 'knative-eventing':
                                    continue
                                else:
                                    uid = i["metadata"]["uid"]
                                    logger.info(f"******* Starting to extract data from {cluster}---{nmspace}---{region} *******")
                                    dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=region)
                                    deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=region)
                                    statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=nmspace,region=region)
                                    hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=region)
                                    pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=region)

                                    if dc[region] == 403 or deployments[region] == 403 or hpas[region] == 403 or pods[region] == 403:
                                        cpumemoryList = [[],0,[]]
                                        nsSinConexion.append(nmspace)
                                    elif len(dc[region]["items"]) == 0 and len(deployments[region]["items"]) == 0:
                                        cpumemoryList = [[],0,[]]
                                        nsSinDCoDeploy.append(nmspace)
                                    else:
                                        if len(pods[region]["items"]) == 0:
                                            cpumemoryList = [[],0,[]]
                                            nsSinReplicas.append(nmspace)
                                        else:
                                            cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=nmspace,region=region,cluster=cluster,maquine=machine)

                                    if len(cpumemoryList[0]) == 0:
                                        cpumemoryList = f"All namespace microservices {namespace}, they are off"
                                        nsSinReplicas.append(nmspace)
                                    else:
                                        await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=region,namespace=nmspace,uid=uid)
                                        logger.info(f"******* Extraction completed for {cluster}---{nmspace}---{region} *******")
                            except:
                                logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                                continue
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {environment+cluster+region} ")
                        next
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        next
                case _:
                    try:
                        ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=region)
                        for i in ns[region]["items"]:
                            nmspace = i["metadata"]["name"]
                            if nmspace==namespace:
                                uid = i["metadata"]["uid"]
                                break
                        logger.info(f"******* Starting to extract data from {cluster}---{namespace}---{region} *******")
                        dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=region)
                        deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=region)
                        statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=namespace,region=region)
                        hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=region)
                        pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=region)

                        if dc[region] == 403 or deployments[region] == 403 or hpas[region] == 403 or pods[region] == 403:
                            cpumemoryList = [[],0,[]]
                            nsSinConexion.append(namespace)
                        elif len(dc[region]["items"]) == 0 and len(deployments[region]["items"]) == 0:
                            cpumemoryList = [[],0,[]]
                            nsSinDCoDeploy.append(namespace)
                        else:
                            if len(pods[region]["items"]) == 0:
                                cpumemoryList = [[],0,[]]
                                nsSinReplicas.append(namespace)
                            else:
                                cpumemoryList = await get_data_week(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=namespace,region=region,cluster=cluster,maquine=machine)

                        if len(cpumemoryList[0]) == 0:
                            cpumemoryList = f"All namespace microservices {namespace}, they are off"
                            nsSinReplicas.append(namespace)
                        else:
                            logger.info(f"Saving data")
                            await guardarMongoWeek(datgen=cpumemoryList,environment=environment,cluster=cluster,region=region,namespace=namespace,uid=uid)
                            logger.info(f"******* Extraction completed for {cluster}---{namespace}---{region} *******")
                        
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {environment+cluster+region} ")
                        next
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        next
            nsSinDCoDeployUnicos = list(set(nsSinDCoDeploy))
            nsSinConexionUnicos = list(set(nsSinConexion)) 
            nsSinReplicasUnicos = list(set(nsSinReplicas))
            namesSinDat = {
                "cluster": cluster,
                "region": region,
                "namespacesSinDcoDeploy": nsSinDCoDeploy,
                "namespaceSinConexion": nsSinConexion,
                "namespaceSinReplicas": nsSinReplicas
            }
            nsSinDatos.append(namesSinDat)
    fecha2 = datetime.datetime.now()
    print(f"Fin {cluster}: ", fecha2)
    return nsSinDatos


async def get_data_week(hpas,environment,deploymentconfigs,deployments,statefulsets,pods,namespace,region,cluster,maquine):
    mcList = []
    identificador = "week"
    entity = os.getenv("ENTITY_ID")
    #Traducimos el cluster para poder pasarle a elastic el formato correcto
    #clustertraduc = await traductorcluster(environment=environment,region=region,cluster=cluster)

    #Llamamos a elastic para trear los datos de uso que necesitamos
    Ps = await elastic(identificador=identificador,environment=environment,clustertraduc=maquine,namespace=namespace)
    ps_event = await get_event_week(environment=environment,clustertraduc=maquine,namespace=namespace)

    if len(deploymentconfigs[region]["items"]) == 0:
        next
        totalName = ['',0,'']
    else:
        logger.info(f"########################## Extracting deploymentconfigs  ##########################")
        if len(deploymentconfigs[region]["items"]) == 0:
            next
        else:
            for deco in deploymentconfigs[region]["items"]:
                mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))
                #Recogemos el namespace y el microservicio del deploy config
                microservice = deco["metadata"]["name"]
                try:
                    replicas = deco["status"]["replicas"]
                except:
                    replicas = deco["spec"]["replicas"]

                if replicas == 0:
                    next
                else:
                    logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                    logger.info("------ Starting data extraction ------")
                    hpasNam = await hpass(region,deco,hpas)
                    infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                    #infonamesp = "production"
                    if entity == 'spain' and environment == "pro":
                        if cluster != 'confluent':
                            if infonamesp == "production":
                                mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deco,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador, ps_event=ps_event,maquine=maquine))
                            else:
                                continue
                        else:
                            mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deco,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador, ps_event=ps_event,maquine=maquine))
                    else:
                        mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deco,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador, ps_event=ps_event,maquine=maquine))
        logger.info(f"########################## Deploymentconfigs extraction completed  ##########################")

    if len(deployments[region]["items"]) == 0:
        next
        totalName = ['',0,'']
    else:
        logger.info(f"########################## Extracting deployments  ##########################")
        for deploy in deployments[region]["items"]:
            mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))
            #Recogemos el namespace y el microservicio del deploy config
            microservice = deploy["metadata"]["name"]
            try:
                replicas = deploy["status"]["replicas"]
            except:
                replicas = deploy["spec"]["replicas"]

            if replicas == 0:
                next
            else:
                logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                logger.info("------ Starting data extraction ------")
                hpasNam = await hpass(region,deploy,hpas)
                #Extraccion de datos y calculo de totales a nivel microservicio
                infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                if entity == 'spain' and environment == "pro":
                    if cluster != 'confluent':
                        if infonamesp == "production":
                            mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deploy,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador, ps_event=ps_event,maquine=maquine))
                        else:
                            continue
                    else:
                        mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deploy,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador, ps_event=ps_event,maquine=maquine))
                else:
                    mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=deploy,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador, ps_event=ps_event,maquine=maquine))
                
        logger.info(f"########################## Deployments extraction completed  ##########################")

    if len(statefulsets[region]["items"]) == 0:
        next
        totalName = ['',0,'']
    else:
        logger.info(f"########################## Extracting statefulsets  ##########################")
        for statef in statefulsets[region]["items"]:
            mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))
            #Recogemos el namespace y el microservicio del deploy config
            microservice = statef["metadata"]["name"]
            try:
                replicas = statef["status"]["replicas"]
            except:
                replicas = statef["spec"]["replicas"]

            if replicas == 0:
                next
            else:
                logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                logger.info("------ Starting data extraction ------")
                hpasNam = await hpass(region,statef,hpas)
                #Extraccion de datos y calculo de totales a nivel microservicio
                infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                if entity == 'spain' and environment == "pro":
                    if cluster != 'confluent':
                        if infonamesp == "production":
                            mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=statef,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador, ps_event=ps_event,maquine=maquine))
                        else:
                            continue
                    else:
                        mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=statef,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador, ps_event=ps_event,maquine=maquine))
                else:
                    mcList.extend(await week_data_processing(environment=environment,hpa=hpasNam,cluster=cluster,region=region,namespace=namespace,dc=statef,blocProd=infonamesp,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador, ps_event=ps_event,maquine=maquine))
                
        logger.info(f"########################## Deployments extraction completed  ##########################")

    totalName = await calcularTotalNamespace(mcList,identificador)


    if cluster == 'confluent':
        blueList = []
        greenList = []
        for dat1 in totalName[2]:
            microblue = dat1['microservice']
            if '-blue' in microblue or microblue[-2] == '-' and microblue[-1] == 'b':
                blue = {
                    'microservice': dat1['microservice'],
                    'replicas': dat1['replicasMicroservice'],
                    'useMEM': dat1['totalUseMicroserviceMEM']
                }
                blueList.append(blue)
        blueListsort = sorted(blueList, key=lambda registro: registro['microservice'])
        for dat1 in totalName[2]:
            microgreen = dat1['microservice']
            if '-green' in dat1['microservice'] or microgreen[-2] == '-' and microgreen[-1] == 'g':
                green = {
                    'microservice': dat1['microservice'],
                    'replicas': dat1['replicasMicroservice'],
                    'useMEM': dat1['totalUseMicroserviceMEM']
                }
                greenList.append(green)
        greenListsort = sorted(greenList, key=lambda registro: registro['microservice'])

        if len(blueListsort) == 0 and len(greenListsort) == 0:
            bp = ''
        elif len(blueListsort) != 0 and len(greenListsort) == 0:
            bp = 'blue'
        elif len(blueListsort) == 0 and len(greenListsort) != 0:
            bp = 'green'
        else:
            for b in blueListsort:
                microb = b['microservice']
                if "-green" in microb:
                    microBSinSufijo = microb[:-6]
                elif "-g" in microb:
                    microBSinSufijo = microb[:-2]
                elif "-blue" in microb:
                    microBSinSufijo = microb[:-5]
                elif "-b" in microb:
                    microBSinSufijo = microb[:-2]
                else:
                    microBSinSufijo = microb["microservice"]

                for g in greenListsort:
                    microg = g['microservice']
                    if "-green" in microg:
                        microGSinSufijo = microg[:-6]
                    elif "-g" in microg:
                        microGSinSufijo = microg[:-2]
                    elif "-blue" in microg:
                        microGSinSufijo = microg[:-5]
                    elif "-b" in microg:
                        microGSinSufijo = microg[:-2]
                    else:
                        microGSinSufijo = microg["microservice"]
                    
                    if microBSinSufijo == microGSinSufijo:
                        replicasb = b['replicas']
                        replicasg = g['replicas']
                        if replicasb > replicasg:
                            bp = 'blue'
                        elif replicasb < replicasg:
                            bp = 'green'
                        else:
                            useMemB = b['useMEM']
                            useMemG = g['useMEM']
                            if useMemB > useMemG:
                                bp = 'blue'
                            elif useMemB < useMemG:
                                bp = 'green'

        
        listBorrar = []
        if bp == 'green':
            for dat1 in totalName[2]:
                microblue = dat1['microservice']
                if '-blue' in microblue or microblue[-2] == '-' and microblue[-1] == 'b':
                    dat1['blockProduction'] = 'ocu'
                    listBorrar.append(dat1)
                else:
                    dat1['blockProduction'] = 'production'

            for borrar in listBorrar:
                micBorrar = borrar['microservice']
                for dat1 in totalName[2]:
                    microse = dat1['microservice']
                    if micBorrar == microse:
                        totalName[2].remove(dat1)

        elif bp == 'blue':
            for dat1 in totalName[2]:
                microgreen = dat1['microservice']
                if '-green' in microgreen or microgreen[-2] == '-' and microgreen[-1] == 'g':
                    dat1['blockProduction'] = 'ocu'
                    listBorrar.append(dat1)
                else:
                    dat1['blockProduction'] = 'production'

            for borrar in listBorrar:
                micBorrar = borrar['microservice']
                for dat1 in totalName[2]:
                    microse = dat1['microservice']
                    if micBorrar == microse:
                        totalName[2].remove(dat1)
        else:
            pass
        
    return totalName


async def week_data_processing(environment,hpa,cluster,region,namespace,dc,blocProd,microservice,pods,Ps,identificador,ps_event,maquine):
    total_lifetime_time = datetime.timedelta(0)
    mcList = [] #List que contendra de microservicios
    pds = {}
    podNameList = [] #Lista que contendra los pods
    #Recogemos CPU Request
    try:
        cpu_Request = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["cpu"]
    except:
        cpu_Request = None

    #Recogemos CPU Limit
    try:
        cpu_Limit = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["cpu"]
    except:
        cpu_Limit = None

    #Formateo de datos a milicores
    cpuReq = await formatearcpu(cpu_Request)
    cpuLim = await formatearcpu(cpu_Limit)

    #Recogemos MEMORY Request
    try:
        memory_Request = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["memory"]
    except:
        memory_Request = None

    #Recogemos MEMORY Limit
    try:
        memory_Limit = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["memory"]
    except:
        memory_Limit = None

    #Formateo de datos a MiB-GiB
    if memory_Request == None:
        memReqformat = None
    else:
        #Convertimos los datos en bytes
        memReq = await formatearmemory(memory_Request)
         #Convertimos los datos en MiB
        memReqformat = int(memReq/1048576)

    if memory_Limit == None:
        memLimformat = None
    else:
        #Convertimos los datos en bytes
        memLim = await formatearmemory(memory_Limit)
        #Convertimos los datos en MiB
        memLimformat = int(memLim/1048576)

    logger.info(f"Openshift extraction completed")

    try:
        uid = dc["metadata"]["uid"]  
    except:
        uid = None 

    replicas = dc["spec"]["replicas"] #Comprobamos si hay replicas
    availablereplicas = 0
    unavailableReplicas = 0
    try:
        availablereplicas = dc["status"]["availableReplicas"]  #Comprobamos si estan disponibles
    except:
        unavailableReplicas = dc["status"]["unavailableReplicas"]  #Comprobamos si estan disponibles

    try:
        unavailableReplicas = dc["status"]["unavailableReplicas"]  #Comprobamos si estan disponibles
    except:
        availablereplicas = dc["status"]["availableReplicas"]  #Comprobamos si estan disponibles

    if availablereplicas == 0 or unavailableReplicas != 0:
        next
    else:
        cont = 0
        for pod in pods[region]["items"]:
            try:
                podName = pod["metadata"]["name"]
            except KeyError:
                podName = None

            try:
                referenceName = pod["metadata"]["ownerReferences"][0]["name"]
            except KeyError:
                referenceName = None
            

            if pod["metadata"]["ownerReferences"][0]["kind"] == "StatefulSet":
                microPodName = podName[:podName.rfind('-')]
            else:
                if referenceName != None:
                    microPodName = referenceName[:referenceName.rfind('-')]
                else:
                    microPodName = None

            if "-deploy" in podName:
                next
            else:
                #Comparamos nombre del microservicio del pod con el nombre del microservicio del namespace
                if microservice == microPodName:
                    cont = 1                    
                    try:
                        cpu_pod_Request = pod["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                    except:
                        cpu_pod_Request = None
                    try:
                        cpu_pod_Limit = pod["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                    except:
                        cpu_pod_Limit = None

                    #Formatemos los datos a milicores
                    cpuPodReq = await formatearcpu(cpu_pod_Request)
                    cpuPodLim = await formatearcpu(cpu_pod_Limit)

                    #Si no tiene configurado Request coge la configuración por defecto
                    if cpu_Request == None:
                        cpupodr = cpuPodReq  #Volcamos el valor para luego proceder al calculo o formateo, ya que despues al llevar la coletilla "por defecto" y ser str no se puede hacer calculos
                        #cpuPodReq = str(cpuPodReq) + " (Default configuration)"
                    
                    #Si no tiene configurado Limit coge la configuración por defecto
                    if cpu_Limit == None:
                        cpupodl = cpuPodLim  #Volcamos el valor para luego proceder al calculo o formateo, ya que despues al llevar la coletilla "por defecto" y ser str no se puede hacer calculos
                        #cpuPodLim = str(cpuPodLim) + " (Default configuration)"

                    try:
                        memory_pod_Request = pod["spec"]["containers"][0]["resources"]["requests"]["memory"]
                    except:
                        memory_pod_Request = None
                    try:
                        memory_pod_Limit = pod["spec"]["containers"][0]["resources"]["limits"]["memory"]
                    except:
                        memory_pod_Limit = None
                    
                    memPodReq = await formatearmemory(memory_pod_Request)
                    memPodReqformat = int(memPodReq/1048576)
                    memPodLim = await formatearmemory(memory_pod_Limit)
                    memPodLimformat = int(memPodLim/1048576)

                    if memory_Request == None:
                        memPodr = memPodReqformat
                        #memPodReqformat = str(memPodReqformat) + " (Default configuration)"
                    
                    if memory_Limit == None:
                        memPodl = memPodLimformat
                        #memPodLimformat = str(memPodLimformat) + " (Default configuration)"

                    try:
                        restartPod = pod['status']['containerStatuses'][0]['restartCount']
                    except:
                        restartPod = None

                    if len(Ps) == 0:
                        #clustertraduc = await traductorcluster(environment=environment,region=region,cluster=cluster)
                        Ps = await elastic(identificador=identificador,environment=environment,clustertraduc=maquine,namespace=namespace)

                    if len(Ps) == 0:
                        next
                    else:            
                        use = [] 
                        usage = {}
                        conta = 0
                        max = 0
                        maxMem = 0
                        logger.info(f"Processing elastic data from {podName}")

                        for n in Ps: #Recorremos los datos que hemos traido de elastic para tratarlos.
                            conta = conta + 1
                            try:
                                #pod_name = n['_source']['kubernetes']['pod']['name'] #Nombre del pod de elastic
                                pod_name = n['key']
                            except:
                                pod_name = ''
                            
                            if podName == pod_name: #Comprobamos que le pod de openshift y el pod de elastic es el mismo
                                try:
                                    cpu_usage = round(n['1']['values'][0]['value'],3) #Extraermos el uso
                                except:
                                    cpu_usage = 0

                                #if cp_usage == None:
                                    #cpu_usage = 0
                                #else:
                                    #cpu_usage = round(cp_usage / 1000000) #El uso en nanocores lo pasamos a milicores y redondeamos para quitar decimales

                                #if cpu_usage > max:
                                    #max = cpu_usage
                                
                                #Calulamos el ahorro (request-uso)
                                #if "Default" in str(cpuPodReq):
                                    #ahorrocpu = int(cpupodr) - cpu_usage
                                #else:
                                ahorrocpu = int(cpuPodReq) - cpu_usage

                                #Calulamos el riesgo (limit-uso)
                                #if "Default" in str(cpuPodLim):
                                    #riesgocpu = int(cpupodl) - cpu_usage
                                #else:
                                riesgocpu = int(cpuPodLim) - cpu_usage                               
                                    

                                #logger.info(f"Extrayendo el uso de MEMORIA del pod {podName}")
                                try:
                                    memory_working_setformat = int(n['13']['value'])
                                except:
                                    memory_working_setformat = 0

                                #if mem_working_set == 0:
                                    #memory_working_setformat = 0
                                #else:
                                    #if mem_working_set == None:
                                        #memory_working_setformat = 0
                                    #else:
                                        #memory_working_setformat = int(mem_working_set/1048576)

                                    #if memory_working_setformat > maxMem:
                                        #maxMem = memory_working_setformat

                                #Calulamos el ahorro (request-uso)
                                #if "Default" in str(memPodReqformat):
                                    #ahorromemavg = int(memPodr - memory_working_setformat)
                                #else:
                                ahorromemavg = int(memPodReqformat - memory_working_setformat)

                                #Calulamos el riesgo (limit-uso)
                                #if "Default" in str(memPodLimformat):
                                    #riesgomemavg = int(memPodl - memory_working_setformat)
                                #else:
                                riesgomemavg = int(memPodLimformat - memory_working_setformat)

                                #Montamos el diccionario de uso del pod
                                usage = {
                                    "CPUUsage": cpu_usage,
                                    "OptimizationCPUPod": ahorrocpu,
                                    "RiskCPUPod": riesgocpu,
                                    "MemoryUsage+Cache": memory_working_setformat,
                                    "OptimizationMemoryPod": ahorromemavg,
                                    "RiskMemoryPod": riesgomemavg,
                                }

                                #Lo añadimos a una lista, esta contiene todos los usos encontrados en elastic de un unico pod
                                use.append(usage)
                                
                        cpuPoReq = await formatearcpu(cpu_pod_Request)
                        cpuPoLim = await formatearcpu(cpu_pod_Limit)

                        '''
                        if len(use) == 0:
                            cpu_usage = 0
                            max = cpu_usage

                            ahorrocpu = int(cpuPoReq - cpu_usage)
                            riesgocpu = int(cpuPoLim - cpu_usage)

                            memory_working_setformat = 0
                            ahorro_avg = int(memPodReqformat - memory_working_setformat)
                            riesgo_avg = int(memPodLimformat - memory_working_setformat)

                            usage = {
                                    "CPUUsage": cpu_usage,
                                    "OptimizationCPUPod": ahorrocpu,
                                    "RiskCPUPod": riesgocpu,
                                    "MemoryUsage+Cache": memory_working_setformat,
                                    "OptimizationMemoryPod": ahorro_avg,
                                    "RiskMemoryPod": riesgo_avg,
                                }
                            use.append(usage)
                            for d in use:
                                resultado = d
                        else:    
                            for d in use:
                                if d["CPUUsage"] >= max:
                                    usage_cpu = d["CPUUsage"]
                                    ahorro_cpu = d["OptimizationCPUPod"]
                                    risk_cpu = d["RiskCPUPod"]
                            
                            for d in use:
                                if d["MemoryUsage+Cache"] >= maxMem:
                                    usage_mem = d["MemoryUsage+Cache"]
                                    ahorro_mem = d["OptimizationMemoryPod"]
                                    risk_mem = d["RiskMemoryPod"]

                            usage = {
                                    "CPUUsage": usage_cpu,
                                    "OptimizationCPUPod": ahorro_cpu,
                                    "RiskCPUPod": risk_cpu,
                                    "MemoryUsage+Cache": usage_mem,
                                    "OptimizationMemoryPod": ahorro_mem,
                                    "RiskMemoryPod": risk_mem,
                                }
                        '''

                        podlifetime = await get_pod_lifetime(podname=podName, pod_list=ps_event)
                        total_lifetime_time += podlifetime
                        pds = {
                            "Pod": podName,
                            "restartPod": restartPod, 
                            "lifeTimePod": str(podlifetime),
                            "cpuRequestPod": cpuPodReq,
                            "cpuLimitPod": cpuPodLim,
                            "memoryRequestPod": memPodReqformat,
                            "memoryLimitPod": memPodLimformat,
                            "use":usage
                            }
                        
                        if podlifetime >= datetime.timedelta(hours=1):
                            podNameList.append(pds)
                            
                        logger.info("Processing data completed")
                else:
                    if cont == 1:
                        cont = 0
                        break
                    else:
                        next

        
        if len(Ps) == 0:
            next
        else:
            logger.info("Calculating microservice CPU totals")
            #Calcular los totales del microservicio
            if hpa == None:
                hpaMaxReplicas = replicas
            else:
                hpaMaxReplicas = hpa['maxReplicas']
            #usoTotal = await totalusomicro(podDict=podNameList)
            usoTotal = await totalusomicro_maxhpa(poddict=podNameList,hpa=hpaMaxReplicas)
            usoTotalMicCPU = usoTotal[0]
            usoMedioCPU = int(usoTotalMicCPU / replicas)
            if cpuReq == None:
                requestTotalCPU = int(cpupodr * replicas)
                OpCPUmic = int(requestTotalCPU - usoTotalMicCPU)
            else:
                requestTotalCPU = int(cpuReq * replicas)
                OpCPUmic = int(requestTotalCPU - usoTotalMicCPU)
                
            if cpuLim == None:
                limitTotalCPU = int(cpupodl * replicas)
                RiskCPUmic = int(limitTotalCPU - usoTotalMicCPU)
            else:
                limitTotalCPU = int(cpuLim * replicas)
                RiskCPUmic = int(limitTotalCPU - usoTotalMicCPU)
            
            #Calcular los totales del microservicio
            logger.info("Calculating microservice MEMORY totals")
    
            if availablereplicas == 0:
                usoTotalMic = 0
                usoMedioMicro = 0
                opMemMicc = 0
                riskMemMicc = 0
                requestTotal = 0
                limitTotal = 0
            else:
                if "we cannot extract information" in podNameList:
                    usoTotalMic = 0
                    usoMedioMicro = 0
                    requestTotal = 0
                    limitTotal = 0
                    opMemMicc = 0
                    riskMemMicc = 0
                else:
                    usoTotalMic = usoTotal[3]
                    if usoTotalMic == 0:
                        usoTotalMic = 0
                        usoMedioMicro = 0
                        opMemMicc = 0
                        riskMemMicc = 0
                        requestTotal = 0
                        limitTotal = 0
                    else:
                        usoMedioMicro = int(usoTotalMic / replicas)
                    if memReqformat == None:
                        requestTotal = int(memPodr) * int(replicas)
                        opMemMicc = int(requestTotal - usoTotalMic)
                    else:
                        requestTotal = int(memReqformat * replicas)
                        opMemMicc = int(requestTotal - usoTotalMic)
                        
                    if memLimformat == None:
                        limitTotal = int(memPodl * replicas)
                        riskMemMicc = int(limitTotal - usoTotalMic)
                    else:
                        limitTotal = int(memLimformat * replicas)
                        riskMemMicc = int(limitTotal - usoTotalMic)

            logger.info("Calculating microservice average running pods")
            average_pods = round((total_lifetime_time.total_seconds() / (8*60*60)), 1)

            mc = {
                "uid": uid,
                "microservice": microservice,
                "blockProduction": blocProd,
                "replicasMicroservice": replicas,
                "cpuRequestMicroservice": cpuPoReq,
                "cpuLimitMicroservice": cpuPoLim,
                "totalUseMicroserviceCPU": usoTotalMicCPU,
                "AverageUseMicroserviceCPU": usoMedioCPU,
                "totalRequestMicroserviceCPU": requestTotalCPU,
                "totalLimitMicroserviceCPU": limitTotalCPU,
                "totalOptimizationCPUMicroservice": OpCPUmic,
                "totalRiskCPUMicroservice": RiskCPUmic,
                "memoryRequestMicroservice": memPodReqformat,
                "memoryLimitMicroservice": memPodLimformat,
                "totalUseMicroserviceMEM": usoTotalMic,
                "averageUseMicroserviceMEM": usoMedioMicro,
                "totalRequestMicroserviceMEM": requestTotal,
                "totalLimitMicroserviceMEM": limitTotal,
                "totalOptimizationMemoryMicroservice": opMemMicc,
                "totalRiskMemoryMicroservice": riskMemMicc,
                "averageLivePod": average_pods,
                "hpa": hpa,
                "pods": podNameList
            }

            if memory_Limit == None:
                memory_Limit = memory_pod_Limit

            if os.getenv("ENTITY_ID") == "spain":
                await possible_problems(namespace,cluster,region,dc,mc,memory_Limit)

            mcList.append(mc)
    logger.info("------ Data extraction completed ------")
    return mcList


async def guardarMongoWeek(datgen,environment,namespace,cluster,region,uid):
    dateList = []
    mm = datgen[0]
    totrep = datgen[1]

    datosgen = {
        "uid": uid,
        "environment": environment,
        "cluster": cluster,
        "region": region,
        "namespace": namespace,
        "totalReplicasNamespace": totrep,
        "date": mm
    }

    #Inserccion Mongo
    mg.change_collection(os.getenv("COLLECTION_WEEK"))
    querydbresultsmemory = mg.find({f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" })
    findnamespacememory = [x for x in querydbresultsmemory]
    if len(findnamespacememory) == 0:                                
        mg.add_data(data=datosgen)
    else:

        dateList = findnamespacememory[0]["date"]
        nameday = mm[0]["nameday"]

        for n in dateList:
            if n["nameday"] == nameday:
                cont = 0
                n["date"] = mm[0]["date"]
                n["totalUseNamespaceCPU"] = mm[0]["totalUseNamespaceCPU"]
                n["totalRequestNamespaceCPU"] = mm[0]["totalRequestNamespaceCPU"]
                n["totalAverageNamespaceCPU"] = mm[0]["totalAverageNamespaceCPU"]
                n["totalLimitNamespaceCPU"] = mm[0]["totalLimitNamespaceCPU"]
                n["totalOptimizationCPUNamespace"] = mm[0]["totalOptimizationCPUNamespace"]
                n["totalRiskCPUNamespace"] = mm[0]["totalRiskCPUNamespace"]
                n["totalUseNamespaceMEM"] = mm[0]["totalUseNamespaceMEM"]
                n["totalAverageNamespaceMEM"] = mm[0]["totalAverageNamespaceMEM"]
                n["totalRequestNamespaceMEM"] = mm[0]["totalRequestNamespaceMEM"]
                n["totalLimitNamespaceMEM"] = mm[0]["totalLimitNamespaceMEM"]
                n["totalOptimizationMemoryNamespace"] = mm[0]["totalOptimizationMemoryNamespace"]
                n["totalRiskMemoryNamespace"] = mm[0]["totalRiskMemoryNamespace"]
                n["microservices"] = mm[0]["microservices"]
                break
            else:
                cont = 1

        if cont == 1:
            dateList.extend(mm)

        mg.update_one(
            { f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" },
            
            { '$set': {
                f"date" : dateList }
            }
            )
        mg.update_one(
            { f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" },
            
            { '$set': {
                f"totalReplicasNamespace" : totrep }
            }
            )


async def possible_problems(namespace,cluster,region,dc,mc,memory_Limit):
    logger.info("Generating possible problems")
    #GC
    logger.info("Garbage Collector")
    mg.change_collection(os.getenv("COLLECTION_SRE_MICROSERVICES"))
    documen = list(mg.find({f"namespace": namespace, f"cluster": cluster, f"region": region, f"name": mc['microservice']}))
    if documen:
        for doc in documen:
            Java = doc["javadict"]
            try:
                isJava = Java['isjava']
            except:
                isJava = Java['is_java']
            if isJava == True:
                isJavaVersion = Java['javaversion']
                envVar = doc["envVar"]
                try:
                    javaOpts = envVar['JAVA_OPTS_EXT']
                    if javaOpts == None:
                        javaOpts = '.'
                except:
                    javaOpts = '.'

                GCParameters = os.getenv("GC_PARAMETERS").split(",")
                if isJavaVersion.startswith("21"):
                    if any(javaOpts.rfind(GC) != -1 for GC in GCParameters):
                        commentGC = "GC configured incorrectly - Parameter 'UseParallelGC' or 'UseG1GC' set to JAVA_OPTS_EXT is incorrect for the java version " + str(isJavaVersion) + ". Please review and correct the type of GC you need to have configured based on your current Java version before applying new configurations."
                    else:
                        if "-XX:ActiveProcessorCount=2" not in javaOpts:
                            commentGC = "GC configured incorrectly - Parameter 'ActiveProcessorCount=2' not found in JAVA_OPTS_EXT for the java version " + str(isJavaVersion) + ". Please review and correct the type of GC you need to have configured based on your current Java version before applying new configurations."
                        else:
                            commentGC = None
                elif isJavaVersion.startswith("17"):
                    try:
                        result = javaOpts.rfind("-XX:+UseParallelGC")
                    except AttributeError:
                        result = -1
                    
                    if result != -1:
                        if "-XX:ActiveProcessorCount=2" not in javaOpts:
                            commentGC = "GC configured incorrectly - Parameter 'ActiveProcessorCount=2' not found in JAVA_OPTS_EXT for the java version " + str(isJavaVersion) + ". Please review and correct the type of GC you need to have configured based on your current Java version before applying new configurations."
                        else:
                            commentGC = None
                    else:
                        commentGC = "GC configured incorrectly - Parameter 'UseParallelGC' not found in JAVA_OPTS_EXT for the java version " + str(isJavaVersion) + ". Please review and correct the type of GC you need to have configured based on your current Java version before applying new configurations."  
                else:
                    if any(javaOpts.rfind(GC) != -1 for GC in GCParameters):
                        commentGC = "GC configured incorrectly - Parameter 'UseParallelGC' or 'UseG1GC' set to JAVA_OPTS_EXT is incorrect for the java version " + str(isJavaVersion) + ". Please review and correct the type of GC you need to have configured based on your current Java version before applying new configurations."
                    else:
                        commentGC = None
            else:
                commentGC = None
    #Restarts
    logger.info("Restarts")
    pods = mc["pods"]
    for pd in pods:
        pod = pd["Pod"]
        restarts = pd["restartPod"]
        if restarts > 0:
            #commentRestarts = f"Pod {pod} has had {restarts} restarts in the last 24 hours. Please review the logs to determine the cause of the restarts."
            commentRestarts = f"Problem for restarts - Pod: {pod}, has had {restarts} restarts. Please review and correct the causes of reboots before applying settings"
        else:
            commentRestarts = None

    #MemoryLeak
    logger.info("MemoryLeak")
    microservice = mc["microservice"]
    averageUseMEM = mc["averageUseMicroserviceMEM"]
    if averageUseMEM >= 1400:
        #commentMemoryLeak = f"Memory leak detected in {microservice}. The average memory usage is {averageUseMEM} MiB. Please review the logs to determine the cause of the memory leak."
        commentMemoryLeak = f"Possible MEM Leak - The average memory usage is {averageUseMEM} MiB. Before changing the settings, check the cause of the consumption"
    else:
        commentMemoryLeak = None

    #LowResorcesSetting
    logger.info("LowResorcesSetting")
    limitMEM = mc["memoryLimitMicroservice"]
    if limitMEM < 1906:
        #commentLowResources = f"Low resource limit detected in {microservice}. The memory limit is {limitMEM} MiB. Please review and apply the recommended settings."
        commentLowResources = "Low resource settings - Apply the recommended settings in Memory and check the actual usage after that to configure the rest of the resources"
    else:
        commentLowResources = None

    #MaxRam
    logger.info("MaxRAM")
    maxRamActual, commentMR = await maxRAM(microservice,dc,memory_Limit,mc['memoryLimitMicroservice'])

    if "MaxRAMPercentage is configured OK according to the memory limit" in commentMR:
        commentMaxRam = None
    else:
        commentMaxRam = commentMR

    '''
    lastChar = microservice[-2] + microservice[-1]
    if "-green" in microservice:
        microSinSufijo = microservice[:-6]
    elif lastChar == '-b' or lastChar == '-g':
        microSinSufijo = microservice[:-2]
    elif "-blue" in microservice:
        microSinSufijo = microservice[:-5]
    else:
        microSinSufijo = microservice

    dataRecomender = await info_recomender(cluster,namespace)
    mics = dataRecomender[0]['microservices']
    for m in mics:
        if microSinSufijo == m['microservice']:
            recomenderMaxRam = m['commentMEM'][7:]
            if recomenderMaxRam != "N/A":
                recomenderMaxRam = int(recomenderMaxRam)
            minReplicasRecommended = m["recomenderMINReplicas"]
            maxReplicasRecommended = m["recomenderMAXReplicas"]
            targetRecommended = m["recomenderTarget"]
            break
    
    if maxRamActual != recomenderMaxRam:
        commentMaxRam = f"MaxRAM configured for {microservice} is {maxRamActual}. The recommended MaxRAM is {recomenderMaxRam}. Please applies the recommended settings for MaxRAM based on its Limit and checks the actual usage after that to configure the rest of the resources ."
        #commentMaxRam = "MaxRAMPercentage KO - Applies the recommended settings for MaxRAM based on its Limit and checks the actual usage after that to configure the rest of the resources"
    else:
        commentMaxRam = None
    '''

    #HPANotRecommended
    logger.info("HPANotRecommended")
    recomenderminReplicas = 'N/A'
    recomendermaxReplicas = 'N/A'
    recomendertarget = 'N/A'
    if mc["hpa"] == None:
        if isJava == False:
            commentHPA = None
            commentBadHPA = None
        else:
            if "config" in microservice or "datagrid" in microservice:
                commentHPA = None
                commentBadHPA = None
            else:
                #commentHPA = f"HPA not implemented for {microservice}. Please review the resource usage and consider implementing HPA to optimize resource usage."
                commentHPA = "HPA not implemented - Review the resource usage and consider implementing HPA to optimize resource usage"
                #commentBadHPA = f"HPA not implemented for {microservice}. Please review the resource usage and consider implementing HPA to optimize resource usage."
                commentBadHPA = "HPA not implemented - Review the resource usage and consider implementing HPA to optimize resource usage"
    else:
        if isJava == False:
            commentHPA = "HPA not recommended - Removes the HPA for this technology and applies the recommended configuration with fixed replicas"
            commentBadHPA = None
        else:
            if "config" in microservice or "datagrid" in microservice:
                commentHPA = "HPA not recommended - Removes the HPA for this technology and applies the recommended configuration with fixed replicas"
            else:
                requestCPU = mc["cpuRequestMicroservice"]
                usoCPUTotal = mc["totalUseMicroserviceCPU"]

                lastChar = microservice[-2] + microservice[-1]
                if "-green" in microservice:
                    microSinSufijo = microservice[:-6]
                elif lastChar == '-b' or lastChar == '-g':
                    microSinSufijo = microservice[:-2]
                elif "-blue" in microservice:
                    microSinSufijo = microservice[:-5]
                else:
                    microSinSufijo = microservice

                dataRecomender = await info_recomender(cluster,namespace)

                try:
                    mics = dataRecomender[0]['microservices']
                except:
                    mics = []

                for m in mics:
                    if microSinSufijo == m['microservice']:
                        recomenderminReplicas = m['recomenderMINReplicas']
                        recomendermaxReplicas = m['recomenderMAXReplicas']
                        recomendertarget = m['recomenderTarget']
                        break
                    else:
                        recomenderminReplicas = 'N/A'
                        recomendermaxReplicas = 'N/A'
                        recomendertarget = 'N/A'
  
                minReplicasActual = mc["hpa"]["minReplicas"]
                maxReplicasActual = mc["hpa"]["maxReplicas"]
                targetActual = mc["hpa"]["targetCPUUtilizationPercentage"]

                if recomenderminReplicas == 'N/A' and recomendermaxReplicas == 'N/A' and recomendertarget == 'N/A':
                    commentHPA = "Recomender HPA Config not found"
                else:
                    if minReplicasActual != recomenderminReplicas or maxReplicasActual != recomendermaxReplicas or targetActual != recomendertarget:
                        commentHPA = f"HPA configured is not recommended. The recommended settings are minReplicas: {recomenderminReplicas}, maxReplicas: {recomendermaxReplicas}, and targetCPU: {recomendertarget}. Please review and apply the recommended settings."
                        #commentHPA = "HPA not recommended - Removes the HPA for this technology and applies the recommended configuration with fixed replicas"
                    else:
                        commentHPA = None

            #BadHPAConfig
            requestActual = mc["cpuRequestMicroservice"]
            averageUseCPU = mc["AverageUseMicroserviceCPU"]

            if requestActual <= 50 and averageUseCPU > 50:
                #commentBadHPA = f"HPA configured for {microservice} is not recommended. The requestCPU is too low. The average CPU usage is {averageUseCPU}. Please review and apply the recommended settings."
                commentBadHPA = "Bad HPA Config - Before changing the settings, check the actual consumption of the application"
            else:
                commentBadHPA = None


    #LowResorcesSetting
    logger.info("LowResorcesSetting")
    limitMEM = mc["memoryLimitMicroservice"]
    if limitMEM < 1906:
        #commentLowResources = f"Low resource limit detected in {microservice}. The memory limit is {limitMEM} MiB. Please review and apply the recommended settings."
        commentLowResources = "Low resource settings - Apply the recommended settings in Memory and check the actual usage after that to configure the rest of the resources"
    else:
        commentLowResources = None

    #GenericCauseNotIdentified
    logger.info("GenericCauseNotIdentified")
    if commentGC == None and commentMemoryLeak == None and commentMaxRam == None and commentLowResources == None and commentRestarts == None:
        commentGenericMEM = "Generic cause not identified - Apply the recommendation and subsequently check if consumption remains stable"
    else:
        commentGenericMEM = None

    if commentHPA == None and commentBadHPA == None and commentRestarts == None:
        commentGenericCPU = "Generic cause not identified - Apply the recommendation and subsequently check if consumption remains stable"
    else:
        commentGenericCPU = None

    possibleCasesDictMEM = {
        "commentGC": commentGC,
        "commentMemoryLeak": commentMemoryLeak,
        "commentMaxRam": commentMaxRam,
        "commentLowResources": commentLowResources,
        "commentRestarts": commentRestarts,
        "commentGenericMEM": commentGenericMEM
    }

    possibleCasesDictCPU = {
        "commentHPA": commentHPA,
        "commentBadHPA": commentBadHPA,
        "commentRestarts": commentRestarts,
        "commentGenericCPU": commentGenericCPU
    }

    mc["possibleCasesMEM"] = possibleCasesDictMEM
    mc["possibleCasesCPU"] = possibleCasesDictCPU

    logger.info("Fin generating possible problems")

