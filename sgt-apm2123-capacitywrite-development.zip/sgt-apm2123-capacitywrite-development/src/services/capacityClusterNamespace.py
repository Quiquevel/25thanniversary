from shuttlelib.utils.logger import logger
import os, aiohttp
import json
import asyncio
from src.services.Estructural import client,mg,hpass,formatearcpu,formatearmemory,services,elastic,traductorcluster,get_clusters,extraer_cluster


async def capacity_cluster():
    environment = os.getenv("ENVIRONMENT")
    identificador = "online"
    namespace = None

    clusters = await client.get_resource(resource="clusters",functional_environment=environment,cluster=None)

    for cluster in clusters:

        clustlist, clusterlistcomplete = await get_clusters()
        reg = next((diccionario['region'] for diccionario in clustlist if cluster in diccionario.values()), None)

        #for cluster in clusters:
            #if cluster == "azure" or cluster == "ocp05azure" or cluster == "dmzbazure":
                #regionlist = ['weu1', 'weu2']
            #elif cluster == 'ocppro01.gsc.pro':
                #regionlist = ['weu']
            #elif cluster == 'ocpgnr.gsc.pro':
                #regionlist = ['weu1']
            #elif cluster == "sgt01.sgt.pro" or cluster == "gsc04.gsc.pro":
                #regionlist = ['cn1', 'cn2']
            #elif cluster == 'csa02.csa.pro':
                #regionlist = ['mx1','mx2']
            #else:
                #regionlist = ['bo1', 'bo2']

        for region in reg:
            #clustertraduc = await traductorcluster(environment,region,cluster)
            
            url = next((dic['url'] for dic in clusterlistcomplete if cluster in dic.values() and region in dic.values()), None)
            machine = await extraer_cluster(url)

            iden = "allocatable-cpu"
            allocatablecpu = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)
            iden = "allocatable-memory"
            allocatablememory = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)
            iden = "request-cpu-cluster"
            requestcpu = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)
            iden = "use-cpu-cluster"
            usecpu = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)
            iden = "request-memory-cluster"
            requestmemory = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)
            iden = "use-memory-cluster"
            usememory = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)

            ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=region)
            for i in ns[region]["items"]:
                namespace = i["metadata"]["name"]
                iden = "request-cpu-namespace"
                requestcpunamespace = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)
                iden = "use-cpu-namespace"
                usecpunamespace = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)
                iden = "request-memory-namespace"
                requestmemorynamespace = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)
                iden = "use-memory-namespace"
                usememorynamespace = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace,iden=iden)

                


            



async def configOnline(cluster,nmspace,microservice):
    environment = os.getenv("ENVIRONMENT")
    deployConfig = False
    deployment = False
    data1 = {}
    data2 = {}
    dataListBenefit = []
    dataListActual = []
    dataListRecomender = []
    #namespace = nmspace + '-pro'

    if cluster == "azure" or cluster == "ocp05azure" or cluster == "dmzbazure":
        regionlist = ['weu1', 'weu2']
    elif cluster == "sgt01.sgt.pro" or cluster == "gsc04.gsc.pro":
        regionlist = ['cn1', 'cn2']
    elif cluster == 'csa02.csa.pro':
        regionlist = ['mx1','mx2']
    else:
        regionlist = ['bo1', 'bo2']

    dataOnline = []
    for rlist in regionlist:
        logger.info(f"*******Starting to extract data from {cluster}-{nmspace}-{rlist}*******")
        dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=rlist)
        deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=rlist)
        hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=rlist)
        pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=rlist)
        
        service = await services(environment,cluster,nmspace,microservice)

        micr = service[0]
        micro = service[1]
        microb = service[2]
        microg = service[3]

        if len(dc[rlist]["items"]) == 0:
            next
        else:
            logger.info(f"########################## Extracting deploymentconfigs ##########################")
            for deco in dc[rlist]["items"]:
                replicas = 0
                deployConfig = True
                microdc = deco["metadata"]["name"]
                marcador = True
                if cluster == 'confluent':
                    micr = microdc
                    micro = microdc
                    microb = microdc
                    microg = microdc
                if micro == microdc or microb == microdc or microg == microdc or micr == microdc:
                    logger.info(f"++++++++++++ Namespace: {nmspace} --- Microservice {microdc} ++++++++++++")
                    hpasMic = await hpass(rlist,deco,hpas)
                    if hpasMic != None:
                        del hpasMic['hpaName']
                        del hpasMic['lastScaleTime']
                        del hpasMic['currentReplicas']
                        del hpasMic['desiredReplicas']
                        del hpasMic['currentCPUUsage']
                        del hpasMic['scalingActive']
                        del hpasMic['messageScalingActive']
                        del hpasMic['ableToScale']
                        del hpasMic['messageAbleToScale']

                    cpu_RequestPod = 0
                    cpu_LimitPod = 0
                    memory_RequestPod = 0
                    memory_LimitPod = 0
                    for pod in pods[rlist]["items"]:
                        try:
                            referenceName = pod["metadata"]["ownerReferences"][0]["name"]
                        except KeyError:
                            referenceName = None
                        
                        if referenceName != None:
                            microPodName = referenceName[:referenceName.rfind('-')]
                        else:
                            microPodName = None

                        if microPodName == microdc:
                            try:
                                cpu_RequestPod = pod["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                            except:
                                cpu_RequestPod = 0

                            #Recogemos CPU Limit
                            try:
                                cpu_LimitPod = pod["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                            except:
                                cpu_LimitPod = 0

                            try:
                                memory_RequestPod = pod["spec"]["containers"][0]["resources"]["requests"]["memory"]
                            except:
                                memory_RequestPod = 0

                            #Recogemos MEMORY Limit
                            try:
                                memory_LimitPod = pod["spec"]["containers"][0]["resources"]["limits"]["memory"]
                            except:
                                memory_LimitPod = 0

                            break

                    try:
                        replicas = deco["status"]["replicas"]
                    except:
                        replicas = deco["spec"]["replicas"]

                    try:
                        cpu_Request = deco["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                    except:
                        cpu_Request = cpu_RequestPod

                    #Recogemos CPU Limit
                    try:
                        cpu_Limit = deco["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                    except:
                        cpu_Limit = cpu_LimitPod

                    #Formateo de datos a milicores
                    cpuReq = await formatearcpu(cpu_Request)
                    cpuLim = await formatearcpu(cpu_Limit)

                    #Recogemos MEMORY Request
                    try:
                        memory_Request = deco["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["memory"]
                    except:
                        memory_Request = memory_RequestPod

                    #Recogemos MEMORY Limit
                    try:
                        memory_Limit = deco["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["memory"]
                    except:
                        memory_Limit = memory_LimitPod

                    #Formateo de datos a MiB-GiB
                    if memory_Request == 0:
                        memReqformat = 0
                    else:
                        #Convertimos los datos en bytes
                        memReq = await formatearmemory(memory_Request)
                        #Convertimos los datos en MiB
                        memReqformat = int(memReq/1048576)

                    if memory_Limit == 0:
                        memLimformat = 0
                    else:
                        #Convertimos los datos en bytes
                        memLim = await formatearmemory(memory_Limit)
                        #Convertimos los datos en MiB
                        memLimformat = int(memLim/1048576)
                    
                    maxRam = await maxRAM(micro,deco,memory_Limit,memLimformat)

                    break
                else:
                    try:
                        replicas = deco["status"]["replicas"]
                    except:
                        replicas = deco["spec"]["replicas"]

                    if replicas != 0:
                        marcador = True    

            logger.info(f"########################## Deploymentconfigs extraction completed ##########################")


        if len(deployments[rlist]["items"]) == 0:
            next
        else:
            logger.info(f"########################## Extracting deployments ##########################")
            for deploy in deployments[rlist]["items"]:
                replicas = 0
                marcador = True
                microdeploy = deploy["metadata"]["name"]
                if cluster == 'confluent':
                    micr = microdeploy
                    micro = microdeploy
                    microb = microdeploy
                    microg = microdeploy
                if micro == microdeploy or microb == microdeploy or microg == microdeploy or micr == microdeploy:
                    logger.info(f"++++++++++++ Namespace: {nmspace} --- Microservice {microdeploy} ++++++++++++")
                    hpasMic = await hpass(rlist,deploy,hpas)
                    if hpasMic != None:
                        del hpasMic['hpaName']
                        del hpasMic['lastScaleTime']
                        del hpasMic['currentReplicas']
                        del hpasMic['desiredReplicas']
                        del hpasMic['currentCPUUsage']
                        del hpasMic['ableToScale']
                        del hpasMic['messageAbleToScale']
                        del hpasMic['scalingActive']
                        del hpasMic['messageScalingActive']
                        del hpasMic['minMaxReplicas']

                    cpu_RequestPod = 0
                    cpu_LimitPod = 0
                    memory_RequestPod = 0
                    memory_LimitPod = 0
                    for pod in pods[rlist]["items"]:
                        try:
                            referenceName = pod["metadata"]["ownerReferences"][0]["name"]
                        except KeyError:
                            referenceName = None
                        
                        if referenceName != None:
                            microPodName = referenceName[:referenceName.rfind('-')]
                        else:
                            microPodName = None

                        if microPodName == microdeploy:
                            try:
                                cpu_RequestPod = pod["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                            except:
                                cpu_RequestPod = 0

                            #Recogemos CPU Limit
                            try:
                                cpu_LimitPod = pod["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                            except:
                                cpu_LimitPod = 0

                            try:
                                memory_RequestPod = pod["spec"]["containers"][0]["resources"]["requests"]["memory"]
                            except:
                                memory_RequestPod = 0

                            #Recogemos MEMORY Limit
                            try:
                                memory_LimitPod = pod["spec"]["containers"][0]["resources"]["limits"]["memory"]
                            except:
                                memory_LimitPod = 0

                            break

                    try:
                        replicas = deploy["status"]["replicas"]
                    except:
                        replicas = deploy["spec"]["replicas"]

                    try:
                        cpu_Request = deploy["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                    except:
                        #cpu_Request = None
                        cpu_Request = cpu_RequestPod

                    #Recogemos CPU Limit
                    try:
                        cpu_Limit = deploy["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                    except:
                        #cpu_Limit = None
                        cpu_Limit = cpu_LimitPod

                    #Formateo de datos a milicores
                    cpuReq = await formatearcpu(cpu_Request)
                    cpuLim = await formatearcpu(cpu_Limit)

                    #Recogemos MEMORY Request
                    try:
                        memory_Request = deploy["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["memory"]
                    except:
                        #memory_Request = None
                        memory_Request = memory_RequestPod

                    #Recogemos MEMORY Limit
                    try:
                        memory_Limit = deploy["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["memory"]
                    except:
                        #memory_Limit = None
                        memory_Limit = memory_LimitPod

                    #Formateo de datos a MiB-GiB
                    #if memory_Request == None:
                        #memReqformat = None
                    if memory_Request == 0:
                        memReqformat = 0
                    else:
                        #Convertimos los datos en bytes
                        memReq = await formatearmemory(memory_Request)
                        #Convertimos los datos en MiB
                        memReqformat = int(memReq/1048576)

                    #if memory_Limit == None:
                        #memLimformat = None
                    if memory_Limit == 0:
                        memLimformat = 0
                    else:
                        #Convertimos los datos en bytes
                        memLim = await formatearmemory(memory_Limit)
                        #Convertimos los datos en MiB
                        memLimformat = int(memLim/1048576)

                    maxRam, commentMaxRAM = await maxRAM(micro,deploy,memory_Limit,memLimformat)
                    break
                else:
                    try:
                        replicas = deploy["status"]["replicas"]
                    except:
                        replicas = deploy["spec"]["replicas"]

                    if replicas != 0:
                        marcador = True
                logger.info(f"########################## Deployments extraction completed ##########################")

        if marcador != False:
            if rlist == 'bo1' or rlist == 'weu1' or rlist == 'cn1':
                data1 = {
                    "cluster": cluster,
                    "region": rlist,
                    "namespace": nmspace,
                    "microservice": micro,
                    "replicas": replicas,
                    "cpuRequest": cpuReq,
                    "cpuLimit": cpuLim,
                    "memoryRequest": memReqformat,
                    "memoryLimit": memLimformat,
                    "maxRam": maxRam,
                    "hpa": hpasMic
                }
                dataOnline.append(data1)

            if rlist == 'bo2' or rlist == 'weu2' or rlist == 'cn2':
                data2 = {
                    "cluster": cluster,
                    "region": rlist,
                    "namespace": nmspace,
                    "microservice": micro,
                    "replicas": replicas,
                    "cpuRequest": cpuReq,
                    "cpuLimit": cpuLim,
                    "memoryRequest": memReqformat,
                    "memoryLimit": memLimformat,
                    "maxRam": maxRam,
                    "hpa": hpasMic
                }
                dataOnline.append(data2)

        if len(data1) != 0 and len(data2) != 0:
            for dat1 in dataOnline:
                if dat1['region'] == "bo1" or dat1['region'] == "weu1" or dat1['region'] == "cn1":
                    replicas1 = dat1['replicas']
                    cpuRequest1 = dat1['cpuRequest']
                    cpuLimit1 = dat1['cpuLimit']
                    memoryRequest1 = dat1['memoryRequest']
                    memoryLimit1 = dat1['memoryLimit']
                    maxRam1 = dat1['maxRam']
                    hpa1 = dat1['hpa']
                else:
                    replicas2 = dat1['replicas']
                    cpuRequest2 = dat1['cpuRequest']
                    cpuLimit2 = dat1['cpuLimit']
                    memoryRequest2 = dat1['memoryRequest']
                    memoryLimit2 = dat1['memoryLimit']
                    maxRam2 = dat1['maxRam']
                    hpa2 = dat1['hpa']

                    if replicas1 == replicas2:
                        replicas = True
                    else:
                        replicas = False

                    if cpuRequest1 == cpuRequest2:
                        cpuRequest = True
                    else:
                        cpuRequest = False
                    if cpuLimit1 == cpuLimit2:
                        cpuLimit = True
                    else:
                        cpuLimit = False
                    if memoryRequest1 == memoryRequest2:
                        memoryRequest = True
                    else:
                        memoryRequest = False
                    if memoryLimit1 == memoryLimit2:
                        memoryLimit = True
                    else:
                        memoryLimit = False
                    if maxRam1 == maxRam2:
                        maxRam = True
                    else:
                        maxRam = False
                    if hpa1 == hpa2:
                        hpa = True
                    else:
                        hpa = False
            
            if replicas == True and cpuRequest == True and cpuLimit == True and memoryRequest == True and memoryLimit == True and maxRam == True and hpa == True:
                iguales = True
            else:
                iguales = False

            if iguales == True:
                lastChar = micro[-2] + micro[-1]
                if "-green" in micro:
                    microSinSufijo = micro[:-6]
                elif lastChar == '-b' or lastChar == '-g':
                    microSinSufijo = micro[:-2]
                elif "-blue" in micro:
                    microSinSufijo = micro[:-5]
                else:
                    microSinSufijo = micro

                if hpa1 == None:
                    hpaImplemented = "NO"
                    minReplicas = "N/A"
                    maxReplicas = "N/A"
                    target = "N/A"
                    targetString = "N/A"
                else:
                    hpaImplemented = "YES"
                    minReplicas = hpa1['minReplicas']
                    maxReplicas = hpa1['maxReplicas']
                    target = hpa1['targetCPUUtilizationPercentage']
                    targetString = str(target) + '%'
                    #if minReplicas == maxReplicas:
                    replicas1 = minReplicas
                    #else:
                        #replicas1 = "N/A"

                configActual = {
                    "indicator": "actual",
                    "microservice": microSinSufijo,
                    "replicas": replicas1,
                    "cpuRequest": cpuRequest1,
                    "cpuLimit": cpuLimit1,
                    "memoryRequest": memoryRequest1,
                    "memoryRequestString": str(memoryRequest1) + ' MiB',
                    "memoryLimit": memoryLimit1,
                    "memoryLimitString": str(memoryLimit1) + ' MiB',
                    "maxRAM": 'MaxRAM ' + str(maxRam1),
                    "hpaImplemented": hpaImplemented,
                    "minReplicas": minReplicas,
                    "maxReplicas": maxReplicas,
                    "target": target,
                    "targetString": targetString
                }
                dataListActual.append(configActual)
            else:
                lastChar = micro[-2] + micro[-1]
                if "-green" in micro:
                    microSinSufijo = micro[:-6]
                elif lastChar == '-b' or lastChar == '-g':
                    microSinSufijo = micro[:-2]
                elif "-blue" in micro:
                    microSinSufijo = micro[:-5]
                else:
                    microSinSufijo = micro

                if replicas1 <= replicas2:
                    replicas = replicas2
                else:
                    replicas = replicas1

                if cpuRequest1 <= cpuRequest2:
                    cpuRequest = cpuRequest2
                else:
                    cpuRequest = cpuRequest1

                if cpuLimit1 <= cpuLimit2:
                    cpuLimit = cpuLimit2
                else:
                    cpuLimit = cpuLimit1

                if memoryRequest1 <= memoryRequest2:
                    memoryRequest = memoryRequest2
                else:
                    memoryRequest = memoryRequest1

                if memoryLimit1 <= memoryLimit2:
                    memoryLimit = memoryLimit2
                    maxRam = maxRam2
                else:
                    memoryLimit = memoryLimit1
                    maxRam = maxRam1

                if hpa1 == None and hpa2 == None:
                    hpaImplemented = "NO"
                    minReplicas = "N/A"
                    maxReplicas = "N/A"
                    target = "N/A"
                    targetString = "N/A"
                elif hpa1 == hpa2:
                    hpaImplemented = "YES"
                    minReplicas = hpa2['minReplicas']
                    maxReplicas = hpa2['maxReplicas']
                    target = hpa2['targetCPUUtilizationPercentage']
                    targetString = str(target) + '%'
                else:
                    hpaImplemented = "YES"
                    if hpa1 == None and hpa2 != None:
                        minReplicas = hpa2['minReplicas']
                        maxReplicas = hpa2['maxReplicas']
                        target = hpa2['targetCPUUtilizationPercentage']
                        targetString = str(target) + '%'
                    elif hpa1 != None and hpa2 == None:
                        minReplicas = hpa1['minReplicas']
                        maxReplicas = hpa1['maxReplicas']
                        target = hpa1['targetCPUUtilizationPercentage']
                        targetString = str(target) + '%'
                    else:
                        if hpa1['minReplicas'] <= hpa2['minReplicas']:
                            minReplicas = hpa2['minReplicas']
                        else:
                            minReplicas = hpa1['minReplicas']

                        if hpa1['maxReplicas'] <= hpa2['maxReplicas']:
                            maxReplicas = hpa2['maxReplicas']
                        else:
                            maxReplicas = hpa1['maxReplicas']
                        
                        if hpa1['targetCPUUtilizationPercentage'] <= hpa2['targetCPUUtilizationPercentage']:
                            target = hpa2['targetCPUUtilizationPercentage']
                            targetString = str(target) + '%'
                        else:
                            target = hpa1['targetCPUUtilizationPercentage']
                            targetString = str(target) + '%'

                configActual = {
                    "indicator": "actual",
                    "microservice": microSinSufijo,
                    "replicas": replicas,
                    "cpuRequest": cpuRequest,
                    "cpuLimit": cpuLimit,
                    "memoryRequest": memoryRequest,
                    "memoryRequestString": str(memoryRequest) + ' MiB',
                    "memoryLimit": memoryLimit,
                    "memoryLimitString": str(memoryLimit) + ' MiB',
                    "maxRAM": 'MaxRAM ' + str(maxRam),
                    "hpaImplemented": hpaImplemented,
                    "minReplicas": minReplicas,
                    "maxReplicas": maxReplicas,
                    "target": target,
                    "targetString": targetString
                }
                dataListActual.append(configActual)

            dataRecomender = await info_recomender(cluster,nmspace)
            #mg.change_collection(os.getenv("COLLECTION_RECOMENDER"))
            #dataRecomender = mg.find_one({f"namespace": nmspace, f"cluster": cluster})
        

            #for dataR in dataRecomender:
            mics = dataRecomender[0]['microservices']
            for m in mics:
                if microSinSufijo == m['microservice']:
                    recomenderCPURequest = m['recomenderCPURequest']
                    recomenderCPULimit = m['recomenderCPULimit']
                    recomenderMEMRequest = m['recomenderMEMRequest']
                    recomenderMEMLimit = m['recomenderMEMLimit']
                    if recomenderMEMRequest == 'Problem':
                        recomenderMEMRequestInt = 'Problem'
                    else:
                        recomenderMEMRequestInt = m['recomenderMEMRequestInt']

                    if recomenderMEMLimit == 'Problem':
                        recomenderMEMLimitInt = 'Problem'
                    else:
                        recomenderMEMLimitInt = m['recomenderMEMLimitInt']

                    recomenderMaxRam = m['commentMEM']
                    if recomenderMaxRam == "MaxRAM 50":
                        recomenderMaxRamInt = 50
                    elif recomenderMaxRam == "MaxRAM 65":
                        recomenderMaxRamInt = 65
                    elif recomenderMaxRam == "MaxRAM 70":
                        recomenderMaxRamInt = 70
                    elif recomenderMaxRam == "MaxRAM 70 + review replicas":
                        recomenderMaxRamInt = 70
                    else:
                        recomenderMaxRam = "N/A"
                        recomenderMaxRamInt = "N/A"
                    recomenderReplicasBase = m['replicasBase']
                    recomenderReplicasMin = m['recomenderMINReplicas']
                    recomenderReplicasMax = m['recomenderMAXReplicas']
                    recomenderTarget = m['recomenderTarget']
                    if recomenderTarget == "100%":
                        recomenderTargetInt = 100
                    elif recomenderTarget == "120%":
                        recomenderTargetInt = 120
                    else:
                        recomenderTarget = "N/A"
                        recomenderTargetInt = "N/A"

                    recomenderActual = {
                        "indicator": "recomendado",
                        "microservice": m['microservice'],
                        "replicas": m['replicasBase'],
                        "cpuRequest": m['recomenderCPURequest'],
                        "cpuLimit": m['recomenderCPULimit'],
                        "memoryRequest": recomenderMEMRequestInt,
                        "memoryLimit": recomenderMEMLimitInt,
                        "maxRAM": recomenderMaxRamInt,
                        "minReplicas": m['recomenderMINReplicas'],
                        "maxReplicas": m['recomenderMAXReplicas'],
                        "target": recomenderTargetInt
                    }
                    dataListRecomender.append(recomenderActual)
                    break

            for dataa in dataListActual:
                #if data['indicator'] == "actual":
                replicasActual = dataa['replicas']
                cpuRequestActual = dataa['cpuRequest']
                cpuLimitActual = dataa['cpuLimit']
                memoryRequestActual = dataa['memoryRequest']
                memoryLimitActual = dataa['memoryLimit']
                maxRamActual = dataa['maxRAM']
                minReplicasActual = dataa['minReplicas']
                maxReplicasActual = dataa['maxReplicas']
                targetActual = dataa['target']
                #else:
            
            for datar in dataListRecomender:
                recoReplicas = datar.get(datar['replicas'], 'N/A')
                recoCpuRequest = datar['cpuRequest']
                recoCpuLimit = datar['cpuLimit']
                recoMemoryRequest = datar['memoryRequest']
                recoMemoryLimit = datar['memoryLimit']
                recoMaxRam = datar['maxRAM']
                recoMinReplicas = datar['minReplicas']
                recoMaxReplicas = datar['maxReplicas']
                recoTarget = datar['target']

            if recoReplicas != "N/A":
                requestCPUrecomen = recoCpuRequest * recoReplicas
                if recoMemoryRequest == 'Problem':
                    requestMEMrecomen = 'N/A'
                else:
                    requestMEMrecomen = recoMemoryRequest * recoReplicas
                limitCPUrecomen = recoCpuLimit * recoReplicas
                if recoMemoryLimit == 'Problem':
                    limitMEMrecomen = 'N/A'
                else:
                    limitMEMrecomen = recoMemoryLimit * recoReplicas
            else:
                if recoCpuRequest == 'Problem':
                    requestCPUrecomen = 'N/A'
                else:
                    if recoMinReplicas == 'N/A':
                        requestCPUrecomen = 'N/A'
                    else:
                        requestCPUrecomen = recoCpuRequest * recoMinReplicas
                if recoMemoryRequest == 'Problem':
                    requestMEMrecomen = 'N/A'
                else:
                    if recoMinReplicas == 'N/A':
                        requestMEMrecomen = 'N/A'
                    else:
                        requestMEMrecomen = recoMemoryRequest * recoMinReplicas

                if recoCpuLimit == 'Problem':
                    limitCPUrecomen = 'N/A'
                else:
                    if recoMinReplicas == 'N/A':
                        limitCPUrecomen = 'N/A'
                    else:
                        limitCPUrecomen = recoCpuLimit * recoMinReplicas

                if recoMemoryLimit == 'Problem':
                    limitMEMrecomen = 'N/A'
                else:
                    if recoMinReplicas == 'N/A':
                        limitMEMrecomen = 'N/A'
                    else:
                        limitMEMrecomen = recoMemoryLimit * recoMinReplicas

            if cpuRequestActual == None:
                requestCPUactual = 'N/A'
            else:
                if minReplicasActual != "N/A":
                    requestCPUactual = cpuRequestActual * minReplicasActual
                else:
                    requestCPUactual = cpuRequestActual * replicasActual
            
            if memoryRequestActual == None:
                requestMEMactual = 'N/A'
            else:
                if minReplicasActual != "N/A":
                    requestMEMactual = memoryRequestActual * minReplicasActual
                else:
                    requestMEMactual = memoryRequestActual * replicasActual

            if cpuLimitActual == None:
                limitCPUactual = 'N/A'
            else:
                if minReplicasActual != "N/A":
                    limitCPUactual = cpuLimitActual * minReplicasActual
                else:
                    limitCPUactual = cpuLimitActual * replicasActual

            if memoryLimitActual == None:
                limitMEMactual = 'N/A'
            else:
                if minReplicasActual != "N/A":
                    limitMEMactual = memoryLimitActual * minReplicasActual
                else:
                    limitMEMactual = memoryLimitActual * replicasActual

            if requestCPUrecomen == 'N/A':
                beneficioRequestCPU = 'N/A'
            else:
                if requestCPUactual == 'N/A':
                    beneficioRequestCPU = 'N/A'
                else:
                    beneficioRequestCPU = requestCPUrecomen - requestCPUactual

            if requestMEMrecomen == 'N/A':
                beneficioRequestMEM = 'N/A'
            else:
                if requestMEMactual == 'N/A':
                    beneficioRequestMEM = 'N/A'
                else:
                    if 'Check' in str(requestMEMrecomen) or 'Possible' in str(requestMEMrecomen):
                        beneficioRequestMEM = 'N/A'
                    else:
                        beneficioRequestMEM = requestMEMrecomen - requestMEMactual
                        #beneficioRequestMEM = str(beneficioRequestMEMInt) + ' MiB'

            if limitCPUrecomen == 'N/A':
                beneficioLimitCPU = 'N/A'
            else:
                if limitCPUactual == 'N/A':
                    beneficioLimitCPU = 'N/A'
                else:
                    beneficioLimitCPU = limitCPUrecomen - limitCPUactual

            if limitMEMrecomen == 'N/A':
                beneficoLimitMEM = 'N/A'
            else:
                if limitMEMactual == 'N/A':
                    beneficoLimitMEM = 'N/A'
                else:
                    if 'Check' in str(limitMEMrecomen) or 'Possible' in str(limitMEMrecomen):
                        beneficoLimitMEM = 'N/A'
                    else:
                        beneficoLimitMEM = limitMEMrecomen - limitMEMactual
                    #beneficoLimitMEM = str(beneficoLimitMEMInt) + ' MiB'

            if recoReplicas != 'N/A':
                if replicasActual != 'N/A':
                    beneficioReplicasBase = recoReplicas - replicasActual
                else:
                    replicasActual = 0
                    beneficioReplicasBase = recoReplicas - replicasActual
            else:
                beneficioReplicasBase = "N/A"
            
            if recoMinReplicas == "N/A" or recoMaxReplicas == "N/A" or recoTarget == "N/A":
                beneficioMinReplicas = "N/A"
                beneficioMaxReplicas = "N/A"
                beneficioTarget = "N/A"
                beneficioTargetString = "N/A"
                '''
                if minReplicasActual == 'N/A' or maxReplicasActual == 'N/A' or targetActual == 'N/A':
                    beneficioMinReplicas = "N/A"
                    beneficioMaxReplicas = "N/A"
                    beneficioTarget = "N/A"
                    beneficioTargetString = "N/A"
                else:
                    beneficioMinReplicas = recoMinReplicas - minReplicasActual
                    beneficioMaxReplicas = recoMaxReplicas - maxReplicasActual
                    beneficioTarget = recoTarget - targetActual
                    beneficioTargetString = str(beneficioTarget) + '%'
                    '''
            else:
                if minReplicasActual == 'N/A' or maxReplicasActual == 'N/A' or targetActual == 'N/A':
                    minReplicasActual = 0
                    maxReplicasActual = 0
                    targetActual = 0
                
                beneficioMinReplicas = recoMinReplicas - minReplicasActual
                beneficioMaxReplicas = recoMaxReplicas - maxReplicasActual
                beneficioTarget = recoTarget - targetActual
                beneficioTargetString = str(beneficioTarget) + '%'
            
            dictBenefit = {
                "beneficioRequestCPU": beneficioRequestCPU,
                "beneficioRequestMEM": beneficioRequestMEM,
                "beneficioLimitCPU": beneficioLimitCPU,
                "beneficoLimitMEM": beneficoLimitMEM,
                "beneficioReplicasBase": beneficioReplicasBase,
                "beneficioMinReplicas": beneficioMinReplicas,
                "beneficioMaxReplicas": beneficioMaxReplicas,
                "beneficioTarget": beneficioTargetString
            }
            dataListBenefit.append(dictBenefit)
        else:
            dataListActual = []
            dataListRecomender = []
            dataListBenefit = []

    return dataListActual, dataListRecomender, dataListBenefit


async def info_recomender(cluster,namespace):
    
    urlapi = os.getenv("API_RECOMENDER_URL") #set api url where the information will be extracted
    path = os.getenv("API_RECOMENDER_PATH") #set api path

    body = {
        "cluster": cluster,
        "namespace": namespace
        }
    async with aiohttp.ClientSession() as session:
        async with session.post(urlapi+path, json=body, ssl=False) as resp:
            logger.debug(f"API {urlapi+path} with response status: {resp.status}, cluster: {cluster}, namespace: {namespace}")
            if resp.status == 200:
                data = await resp.text()
                return json.loads(data)
            else:
                return None
            

async def maxRAM(microservice,dc,memory_Limit,memLimG):
    """
    Calculate the maximum RAM percentage based on the given parameters.
    Parameters:
    - microservice (str): The name of the microservice.
    - dc (dict): The dictionary containing the deployment configuration.
    - memory_Limit (str): The memory limit of the microservice.
    - memLimG (str): The memory limit in gigabytes.
    Returns:
    - maxR (int): The maximum RAM percentage.
    Raises:
    - KeyError: If the required keys are not found in the deployment configuration.
    Notes:
    - This function determines whether the microservice is a Java microservice based on its name and the deployment configuration.
    - If the microservice is not a Java microservice, the function returns "N/A" and provides a comment explaining the reason.
    - If the microservice is a Java microservice, the function checks the environment variable "JAVA_OPTS_EXT" in the deployment configuration to find the "MaxRAMPercentage" value.
    - The function compares the "MaxRAMPercentage" value with the memory limit and provides a comment indicating whether it is configured correctly or not.
    - If the "MaxRAMPercentage" value is not found or the environment variable is not configured, the function returns "N/A" and provides a comment explaining the reason.
    - If the "JAVA_OPTS_EXT" environment variable is empty, the function returns "N/A" and provides a comment indicating that it is empty.
    - If the "JAVA_OPTS_EXT" environment variable does not exist, the function returns "N/A" and provides a comment indicating that it does not exist.
    - If the "MaxRAMPercentage" value is not standard according to the ARQ recommendations, the function provides a comment indicating that it is not standard.
    """
    if "java" in microservice or 'gateway' in microservice:
        java = True
    else:
        try:
            template = dc["metadata"]["labels"]["template"]
            if template == "nginx" or "nginx" in template:
                java = False
            else:
                java = True
            votokpiptype = "N/A"
        except:
            try:
                votokpiptype = dc["metadata"]["labels"]["vostok-pipeline-type"]
                if votokpiptype == "ANGULAR-APPLICATION":
                    java = False
                else:
                    java = True
                template = "N/A"
            except:
                template = ""
                votokpiptype = ""
                java = False

    if java == False:
        if template == "nginx" or votokpiptype == "ANGULAR-APPLICATION" or "nginx" in template:
            maxR = "N/A"
            maxRAMComment = f'{microservice} is not a java microservice'
        else: 
            maxR = "N/A"
            maxRAMComment = f'{microservice} could not identify if it is a java microservice'
    else:       
        try:
            env = dc["spec"]['template']['spec']['containers'][0]['env']
        except KeyError:
            env = None
        
        if env != None:
            for elem in env:
                try:
                    if elem["name"] == "JAVA_OPTS_EXT":
                        #MAXRAM
                        dato = elem["value"]
                        result = dato.rfind("MaxRAMPercentage")

                        if result != -1:
                            maxRAM=dato[dato.rfind("MaxRAMPercentage")-4:dato.rfind("MaxRAMPercentage")+len("MaxRAMPercentage")+3]
                            maxR = int(maxRAM[maxRAM.find("=")+1:])
                            
                            if maxR == 50:
                                if memory_Limit == "1G" or memory_Limit == "1Gi" or memory_Limit == "1000M" or memory_Limit == "1000Mi" or memory_Limit == "1024M" or memory_Limit == "1024Mi":
                                    maxRAMComment = f'MaxRAMPercentage is configured OK according to the memory limit ({memLimG})'
                                else:
                                    maxRAMComment = f'MaxRAMPercentage {maxR} is NOT configured OK according to the memory limit ({memLimG})'
                            elif maxR == 65 or maxR == 60:
                                if memory_Limit == "1.5G" or memory_Limit == "1.5Gi" or memory_Limit == "1500M" or memory_Limit == "1500Mi" or memory_Limit == "1536M" or memory_Limit == "1536Mi":
                                    maxRAMComment = f'MaxRAMPercentage is configured OK according to the memory limit ({memLimG})'
                                else:
                                    maxRAMComment = f'MaxRAMPercentage {maxR} is NOT configured OK according to the memory limit ({memLimG})'
                            elif maxR == 70:
                                if memory_Limit == "2G" or memory_Limit == "2Gi" or memory_Limit == "2000M" or memory_Limit == "2000Mi" or memory_Limit == "2048M" or memory_Limit == "2048Mi":
                                    maxRAMComment = f'MaxRAMPercentage is configured OK according to the memory limit ({memLimG})'
                                else:
                                    maxRAMComment = f'MaxRAMPercentage {maxR} is NOT configured OK according to the memory limit ({memLimG})'
                            else:
                                maxRAMComment = f'MaxRAMPercentage {maxR} is NOT standard according to the ARQ recommendations'
                            break
                        else:
                            maxR = "N/A"
                            maxRAMComment = f'MaxRAMPercentage parameters is not configured on JAVA_OPTS_EXT'
                                                 
                        break
                    else:
                        maxR = "N/A"
                        maxRAMComment = f'Environment variable JAVA_OPTS_EXT does not exist'
                except KeyError:
                    maxR = "N/A"
                    maxRAMComment = f'The JAVA_OPTS_EXT environment variable is empty' 
                    break
        else:
            maxR = "N/A"
            maxRAMComment = f'Environment variable JAVA_OPTS_EXT does not exist' 

    return maxR, maxRAMComment


async def get_max_ram_percentage(maxram_string):
    """
    Extracts the maximum RAM percentage from a given string.
    Args:
        maxram_string (str): The string containing the maximum RAM percentage.
    Returns:
        int or str: The maximum RAM percentage as an integer if it is a number, otherwise the original string.
    """
    inicio = 0
    try:
        maxram = int(maxram_string)
    except:
        for i, char in enumerate(maxram_string):
 
            if inicio == 0 and char.isdigit():
                inicio = i
            elif inicio != 0 and not char.isdigit():
                fin = i
                break
        else:
            fin = len(maxram_string)            
 
        if inicio != 0:
            try: maxram = int(maxram_string[inicio:fin])
            except: maxram = maxram_string
        else:
            maxram = maxram_string
   
    return maxram
