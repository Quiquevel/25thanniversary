from shuttlelib.helper.keys import get_enviroment
from shuttlelib.utils.logger import logger
import os, aiohttp
import datetime
import asyncio
from src.services.Estructural import traductorcluster,elastic,hpass,blockproductive,calcularTotalNamespace,control_errores,formatearcpu,formatearmemory,totalusomicro,get_clusters,extraer_cluster,client,mg
       

async def get_updateOnlineWS(websocket,cluster,region,namespace):
    environment = os.getenv("ENVIRONMENT")
    identificador = "online"
    await websocket.accept()
    while True:
        #await websocket.send_text(f'Conexion abierta')
        registro = 0
        totalregistros = 0
        dict_counter = {}

        dpcf=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace)
        dpf=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace)
        for deconf in dpcf:
            totalregdpcf = len(dpcf[deconf]["items"])
            totalregistros = totalregistros + totalregdpcf
        for depl in dpf:
            totalregdpf = len(dpf[depl]["items"])
            totalregistros = totalregistros + totalregdpf
        
        match region:
            case "both":
                clustlist, clusterlistcomplete = await get_clusters()
                reg = next((diccionario['region'] for diccionario in clustlist if cluster in diccionario.values()), None)
                '''
                if cluster == "azure" or cluster == "ocp05azure" or cluster == "dmzbazure":
                    reg = ['weu1', 'weu2']
                elif cluster == 'ocppro01.gsc.pro':
                    reg = ['weu']
                elif cluster == 'ocpgnr.gsc.pro':
                    reg = ['weu1']
                elif cluster == "sgt01.sgt.pro" or cluster == "gsc04.gsc.pro":
                    reg = ['cn1', 'cn2']
                elif cluster == 'csa02.csa.pro' or cluster == "gluon01.mex.pro" or cluster == "grav01.mex.pro" or cluster == "mex02.mex.pro" or cluster == "mex02.mex.dmzb" or cluster == "ocp01.mex.pro" or cluster == "ocp02.mex.pro" or cluster == "ocp03.mex.pro" or cluster == "ocp04.mex.pro" or cluster == "ocp05.mex.pro" or cluster == "ocp06.mex.pro" or cluster == "plard01.mex.pro" or cluster == "str01.mex.pro":
                    reg = ['mx1', 'mx2']
                else:
                    reg = ['bo1', 'bo2']
                '''
                for rg in reg:
                    url = next((dic['url'] for dic in clusterlistcomplete if cluster in dic.values() and rg in dic.values()), None)
                    machine = await extraer_cluster(url)
                    mcListado = []
                    mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))
                    #clustertraduc = await traductorcluster(environment=environment,region=rg, cluster=cluster)
                    Ps = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace)
                    dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=rg)
                    deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=rg)
                    hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=rg)
                    pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=rg)
                    
                    if len(dc[rg]["items"]) == 0:
                        next
                    else:
                        logger.info(f"########################## Extracting deploymentconfigs  ##########################")
                        for deco in dc[rg]["items"]:
                            #Recogemos el namespace y el microservicio del deploy config
                            microservice = deco["metadata"]["name"]
                            uidMicro = deco["metadata"]["uid"]
                            try:
                                replicas = deco["status"]["replicas"]
                            except:
                                replicas = deco["spec"]["replicas"]

                            if replicas == 0:
                                next
                            else:
                                logger.info(f"++++++++++ Microservice: {microservice} ++++++++++")
                                await websocket.send_text(f"{microservice}")
                                hpasNam = await hpass(rg,deco,hpas)

                                #Extraccion de datos y calculo de totales a nivel microservicio
                                infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=rg,microservice=microservice)
                                mcList = await online_data_processing(environment=environment,hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=rg,namespace=namespace,dc=deco,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador,uidMicro=uidMicro,machine=machine)
                                if len(mcList) == 0:
                                    #pass
                                    await websocket.send_json({"There is nothing to update"})
                                else:
                                    await websocket.send_json(mcList[0])
                                    mcListado.append(mcList[0])
                            registro += 1
                            dict_counter = {"total": totalregistros, "current": registro}
                            await websocket.send_json(dict_counter)
                        logger.info(f"########################## Deploymentconfigs extraction completed  ##########################")

                    if len(deployments[rg]["items"]) == 0:
                        next
                    else:
                        logger.info(f"########################## Extracting deployments  ##########################")
                        for deploy in deployments[rg]["items"]:
                            #Recogemos el namespace y el microservicio del deploy config
                            microservice = deploy["metadata"]["name"]
                            uidMicro = deploy["metadata"]["uid"]
                            try:
                                replicas = deploy["status"]["replicas"]
                            except:
                                replicas = deploy["spec"]["replicas"]

                            if replicas == 0:
                                next
                            else:
                                logger.info(f"++++++++++ Microservice: {microservice} ++++++++++")
                                await websocket.send_text(f"{microservice}")
                                hpasNam = await hpass(rg,deploy,hpas)

                                #Extraccion de datos y calculo de totales a nivel microservicio
                                infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=rg,microservice=microservice)
                                mcList = await online_data_processing(environment=environment,hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=rg,namespace=namespace,dc=deploy,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador,kind=kind,uidMicro=uidMicro,machine=machine)
                                if len(mcList) == 0:
                                    #pass
                                    await websocket.send_json({"There is nothing to update"})
                                else:
                                    await websocket.send_json(mcList[0])
                                    mcListado.append(mcList[0])
                            registro += 1
                            dict_counter = {"total": totalregistros, "current": registro}
                            await websocket.send_json(dict_counter)
                        logger.info(f"########################## Deployments extraction completed  ##########################")

                    totalName = await calcularTotalNamespace(mcListado,identificador)

                    await guardarMongoOnline(totalName,environment,namespace,cluster,rg)

            case _:
                clustlist, clusterlistcomplete = await get_clusters()
                url = next((dic['url'] for dic in clusterlistcomplete if cluster in dic.values() and region in dic.values()), None)
                machine = await extraer_cluster(url)
                mcListado = []
                mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))
                #clustertraduc = await traductorcluster(environment=environment,region=region, cluster=cluster)
                Ps = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace)            
                dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=region)
                deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=region)
                hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=region)
                pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=region)
                
                if len(dc[region]["items"]) == 0:
                    next
                else:
                    registro = 0
                    totalreg = len(dc[region]["items"]) + len(deployments[region]["items"])
                    logger.info(f"########################## Extracting deploymentconfigs  ##########################")
                    for deco in dc[region]["items"]:
                        #Recogemos el namespace y el microservicio del deploy config
                        microservice = deco["metadata"]["name"]
                        uidMicro = deco["metadata"]["uid"]
                        try:
                            replicas = deco["status"]["replicas"]
                        except:
                            replicas = deco["spec"]["replicas"]
                        if replicas == 0:
                            next
                        else:
                            logger.info(f"++++++++++ Microservice: {microservice} ++++++++++")
                            await websocket.send_text(f"{microservice}")
                            hpasNam = await hpass(region,deco,hpas)

                            #Extraccion de datos y calculo de totales a nivel microservicio
                            infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                            mcList = await online_data_processing(environment=environment,hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deco,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador,uidMicro=uidMicro,machine=machine)
                            if len(mcList) == 0:
                                #pass
                                await websocket.send_json(f"There is nothing to update")
                            else:
                                await websocket.send_json(mcList[0])
                                mcListado.append(mcList[0])
                        registro = registro + 1
                        dict_counter = {"total": totalreg, "current": registro}
                        await websocket.send_json(dict_counter)
                    logger.info(f"########################## Deploymentconfigs extraction completed  ##########################")

                if len(deployments[region]["items"]) == 0:
                    next
                else:
                    kind = deployments[region]["kind"]
                    registro = 0
                    totalreg = len(dc[region]["items"]) + len(deployments[region]["items"])
                    logger.info(f"########################## Extracting deployments  ##########################")
                    for deploy in deployments[region]["items"]:
                        #Recogemos el namespace y el microservicio del deploy config
                        microservice = deploy["metadata"]["name"]
                        uidMicro = deploy["metadata"]["uid"]
                        try:
                            replicas = deploy["status"]["replicas"]
                        except:
                            replicas = deploy["spec"]["replicas"]
                        if replicas == 0:
                            next
                        else:
                            logger.info(f"++++++++++ Microservice: {microservice} ++++++++++")
                            await websocket.send_text(f"{microservice}")
                            hpasNam = await hpass(region,deploy,hpas)

                            #Extraccion de datos y calculo de totales a nivel microservicio
                            infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                            mcList = await online_data_processing(environment=environment,hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deploy,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador,uidMicro=uidMicro,machine=machine)
                            if len(mcList) == 0:
                                #pass
                                await websocket.send_json(f"There is nothing to update")
                            else:
                                await websocket.send_json(mcList[0])
                                mcListado.append(mcList[0])
                        registro = registro + 1
                        dict_counter = {"total": totalreg, "current": registro}
                        await websocket.send_json(dict_counter)
                    logger.info(f"########################## Deployments extraction completed  ##########################")

                totalName = await calcularTotalNamespace(mcListado,identificador)

                await guardarMongoOnline(totalName,environment,namespace,cluster,region)

        #await websocket.send_text(f'Cerrando conexion')

        await asyncio.sleep(5)

        await websocket.close(code=1000, reason=None)
        break


async def get_capacity_online(cluster,region=None,namespace=None):
    environment = os.getenv("ENVIRONMENT")
    cpumemoryList = []

    fecha = datetime.datetime.now()
    print(f"Inicio {cluster}: ", fecha)
    match region:
        case None:
            clustlist, clusterlistcomplete = await get_clusters()
            reg = next((diccionario['region'] for diccionario in clustlist if cluster in diccionario.values()), None)

            '''
            if cluster == 'sgt01.sgt.pro':
                reg = {'sgt01.sgt.pro':['cn1','cn2']}
            elif cluster == 'sgt01.sgt.dmzb':
                reg = {'sgt01.sgt.dmzb':['cn1','cn2']}
            elif cluster == 'gsc04.gsc.pro':
                reg = {'gsc04.gsc.pro':['cn1','cn2']}
            elif cluster == 'gsc04.gsc.dmzb':
                reg = {'gsc04.gsc.dmzb':['cn1','cn2']}
            elif cluster == 'ocppro01.gsc.pro':
                reg = {'ocppro01.gsc.pro':['weu']}
            elif cluster == 'ocpgnr.gsc.pro':
                reg = {'ocpgnr.gsc.pro':['weu1']}
            elif cluster == 'csa02.csa.pro':
                reg = {'csa02.csa.pro':['mx1','mx2']}
            elif cluster == 'gluon01.mex.pro':
                reg = {'gluon01.mex.pro':['mx1','mx2']}
            elif cluster == 'grav01.mex.pro':
                reg = {'grav01.mex.pro':['mx1','mx2']}
            elif cluster == 'mex02.mex.pro':
                reg = {'mex02.mex.pro':['mx1','mx2']}
            elif cluster == 'mex02.mex.dmzb':
                reg = {'mex02.mex.dmzb':['mx1','mx2']}
            elif cluster == 'ocp01.mex.pro':
                reg = {'ocp01.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp02.mex.pro':
                reg = {'ocp02.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp03.mex.pro':
                reg = {'ocp03.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp04.mex.pro':
                reg = {'ocp04.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp05.mex.pro':
                reg = {'ocp05.mex.pro':['mx1','mx2']}
            elif cluster == 'ocp06.mex.pro':
                reg = {'ocp06.mex.pro':['mx1','mx2']}
            elif cluster == 'plard01.mex.pro':
                reg = {'plard01.mex.pro':['mx1','mx2']}
            elif cluster == 'str01.mex.pro':
                reg = {'str01.mex.pro':['mx1','mx2']}
            elif cluster == 'gscmx01.gscmx.pro':
                reg = {'gscmx01.gscmx.pro':['mx1','mx2']}
            elif cluster == 'scg01.scg.pro':
                reg = {'scg01.scg.pro':['bo1','bo2']}
            elif cluster == 'scg01.scg.dmzb':
                reg = {'scg01.scg.dmzb':['bo1','bo2']}
            else:
                reg = get_enviroment(environment)
            '''
            #for rg in reg[cluster]:
            for rg in reg:
                url = next((dic['url'] for dic in clusterlistcomplete if cluster in dic.values() and rg in dic.values()), None)
                machine = await extraer_cluster(url)
                match namespace:
                    case None:
                        try:
                            ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=rg)
                            for i in ns[rg]["items"]:
                                try:
                                    nmspace = i["metadata"]["name"]
                                    logger.info(f"*******Starting to extract data from {cluster}-{nmspace}-{rg}*******")
                                    dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=rg)
                                    deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=rg)
                                    statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=nmspace,region=rg)
                                    hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=rg)
                                    pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=rg)
                                    cpumemoryList = await get_data_online(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=nmspace,region=rg,cluster=cluster,machine=machine)

                                    if len(cpumemoryList[0]) == 0:
                                        cpumemoryList = f"All namespace microservices {nmspace}, they are off"
                                    else:
                                        await guardarMongoOnline(datgen=cpumemoryList,environment=environment,cluster=cluster,region=rg,namespace=nmspace)
                                        logger.info(f"******* Extraction completed for {cluster}---{nmspace}---{rg} *******")
                                except:
                                    logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                                    continue
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against {environment+cluster+rg} ")
                            continue
                        except:
                            logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                            continue
                    case _:
                        try:
                            logger.info(f"******* Starting to extract data from {cluster}---{namespace}---{rg} *******")
                            dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=rg)
                            deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=rg)
                            statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=namespace,region=rg)
                            hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=rg)
                            pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=rg)
                            cpumemoryList = await get_data_online(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=namespace,region=rg,cluster=cluster,machine=machine)

                            if len(cpumemoryList[0]) == 0:
                                cpumemoryList = f"All namespace microservices {namespace}, they are off"
                            else:
                                logger.info(f"Saving data")
                                await guardarMongoOnline(datgen=cpumemoryList,environment=environment,cluster=cluster,region=rg,namespace=namespace)
                                logger.info(f"******* Extraction completed for {cluster}---{namespace}---{rg} *******")
                        except aiohttp.client_exceptions.ServerTimeoutError:
                            logger.error(f"Timeout detected against {environment+cluster+rg} ")
                            continue
                        except:
                            logger.error(f"Namespaces of {cluster}-{rg} could not be retrieved. Skipping...")
                            continue          
        case _:
            clustlist, clusterlistcomplete = await get_clusters()
            url = next((dic['url'] for dic in clusterlistcomplete if cluster in dic.values() and region in dic.values()), None)
            machine = await extraer_cluster(url)
            match namespace:
                case None:
                    await control_errores(region,cluster,environment) 
                    try:
                        ns= await client.get_resource(functional_environment=environment,cluster=cluster,resource="namespaces",region=region)
                        for i in ns[region]["items"]:
                            try:
                                nmspace = i["metadata"]["name"]
                                logger.info(f"******* Starting to extract data from {cluster}---{nmspace}---{region} *******")
                                dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=nmspace,region=region)
                                deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=nmspace,region=region)
                                statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=nmspace,region=region)
                                hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=nmspace,region=region)
                                pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=nmspace,region=region)
                                cpumemoryList = await get_data_online(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=nmspace,region=region,cluster=cluster,machine=machine)

                                if len(cpumemoryList[0]) == 0:
                                    cpumemoryList = f"All namespace microservices {namespace}, they are off"
                                else:
                                    await guardarMongoOnline(datgen=cpumemoryList,environment=environment,cluster=cluster,region=region,namespace=nmspace)
                                    logger.info(f"******* Extraction completed for {cluster}---{nmspace}---{region} *******")
                            except:
                                logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                                continue
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {environment+cluster+region} ")
                        next
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        next
                case _:
                    try:
                        logger.info(f"******* Starting to extract data from {cluster}---{namespace}---{region} *******")
                        dc=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deploymentconfigs",namespace=namespace,region=region)
                        deployments=await client.get_resource(functional_environment=environment,cluster=cluster,resource="deployments",namespace=namespace,region=region)
                        statefulsets=await client.get_resource(functional_environment=environment,cluster=cluster,resource="statefulsets",namespace=namespace,region=region)
                        hpas=await client.get_resource(functional_environment=environment,cluster=cluster,resource="hpas",namespace=namespace,region=region)
                        pods= await client.get_resource(functional_environment=environment,cluster=cluster,resource="pods",namespace=namespace,region=region)
                        cpumemoryList = await get_data_online(hpas=hpas,environment=environment,deploymentconfigs=dc,deployments=deployments,statefulsets=statefulsets,pods=pods,namespace=namespace,region=region,cluster=cluster,machine=machine)

                        if len(cpumemoryList[0]) == 0:
                            cpumemoryList = f"All namespace microservices {namespace}, they are off"
                        else:
                            logger.info(f"Saving data")
                            await guardarMongoOnline(datgen=cpumemoryList,environment=environment,cluster=cluster,region=region,namespace=namespace)
                            logger.info(f"******* Extraction completed for {cluster}---{namespace}---{region} *******")
                    except aiohttp.client_exceptions.ServerTimeoutError:
                        logger.error(f"Timeout detected against {environment+cluster+region} ")
                        next
                    except:
                        logger.error(f"Namespaces of {cluster}-{region} could not be retrieved. Skipping...")
                        next
    fecha2 = datetime.datetime.now()
    print(f"Fin {cluster}: ", fecha2)
    return cpumemoryList


async def get_data_online(hpas,environment,deploymentconfigs,deployments,statefulsets,pods,namespace,region,cluster,machine):
    mcList = []
    identificador = "online"
    #Traducimos el cluster para poder pasarle a elastic el formato correcto
    #clustertraduc = await traductorcluster(environment=environment,region=region,cluster=cluster)

    #Llamamos a elastic para trear los datos de uso que necesitamos
    Ps = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace)
    
    mg.change_collection(os.getenv("COLLECTION_INFONAMESPACES"))

    if len(deploymentconfigs[region]["items"]) == 0:
        next
        totalName = ['',0,'']
    else:
        if len(deploymentconfigs[region]["items"]) == 0:
            next
        else:
            logger.info(f"########################## Extracting deploymentconfigs  ##########################")
            for deco in deploymentconfigs[region]["items"]:
                #Recogemos el namespace y el microservicio del deploy config
                microservice = deco["metadata"]["name"]
                uidMicro = deco['metadata']['uid']
                try:
                    replicas = deco["status"]["replicas"]
                except:
                    replicas = deco["spec"]["replicas"]

                if replicas == 0:
                    next
                else:
                    logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                    #if microservice =="s-java-50063600-nwe-gw-19-api-g":
                        #pass
                    logger.info("------ Starting data extraction ------")
                    hpasNam = await hpass(region,deco,hpas)
                    #Extraccion de datos y calculo de totales a nivel microservicio
                    infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                    mcList.extend(await online_data_processing(environment=environment,hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deco,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador,uidMicro=uidMicro,machine=machine))
            logger.info(f"########################## Deploymentconfigs extraction completed  ##########################")

    if len(deployments[region]["items"]) == 0:
        next
        totalName = ['',0,'']
    else:
        kind = deployments[region]["kind"]
        logger.info(f"########################## Extracting deployments  ##########################")
        for deploy in deployments[region]["items"]:
            #Recogemos el namespace y el microservicio del deploy config
            microservice = deploy["metadata"]["name"]
            uidMicro = deploy['metadata']['uid']
            try:
                replicas = deploy["status"]["replicas"]
            except:
                replicas = deploy["spec"]["replicas"]

            if replicas == 0:
                next
            else:
                logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                #if microservice =="s-java-50063600-nwe-gw-19-api-g":
                    #pass
                logger.info("------ Starting data extraction ------")
                hpasNam = await hpass(region,deploy,hpas)
                #Extraccion de datos y calculo de totales a nivel microservicio
                infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                mcList.extend(await online_data_processing(environment=environment,hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=deploy,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador,uidMicro=uidMicro,machine=machine))
        logger.info(f"########################## Deployments extraction completed  ##########################")


    if len(statefulsets[region]["items"]) == 0:
        next
        totalName = ['',0,'']
    else:
        if len(statefulsets[region]["items"]) == 0:
            next
        else:
            logger.info(f"########################## Extracting statefulsets  ##########################")
            for statef in statefulsets[region]["items"]:
                #Recogemos el namespace y el microservicio del deploy config
                microservice = statef["metadata"]["name"]
                uidMicro = statef['metadata']['uid']
                try:
                    replicas = statef["status"]["replicas"]
                except:
                    replicas = statef["spec"]["replicas"]

                if replicas == 0:
                    next
                else:
                    logger.info(f"++++++++++ Microservice: {microservice} - {namespace} - {region} ++++++++++")
                    #if microservice =="s-java-50063600-nwe-gw-19-api-g":
                        #pass
                    logger.info("------ Starting data extraction ------")
                    hpasNam = await hpass(region,statef,hpas)
                    #Extraccion de datos y calculo de totales a nivel microservicio
                    infonamesp = await blockproductive(mg=mg,namespace=namespace,cluster=cluster,region=region,microservice=microservice)
                    mcList.extend(await online_data_processing(environment=environment,hpa=hpasNam,blockprod=infonamesp,cluster=cluster,region=region,namespace=namespace,dc=statef,microservice=microservice,pods=pods,Ps=Ps,identificador=identificador,uidMicro=uidMicro,machine=machine))
            logger.info(f"########################## Statefulsets extraction completed  ##########################")

    totalName = await calcularTotalNamespace(mcList,identificador)

    return totalName


async def online_data_processing(environment,hpa,blockprod,cluster,region,namespace,dc,microservice,pods,Ps,identificador,uidMicro,machine):
    mcList = [] #List que contendra de microservicios
    pds = {}
    podNameList = [] #Lista que contendra los pods
    commentHPA = None
    #Recogemos CPU Request
    try:
        cpu_Request = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["cpu"]
    except:
        cpu_Request = None

    #Recogemos CPU Limit
    try:
        cpu_Limit = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["cpu"]
    except:
        cpu_Limit = None

    #Formateo de datos a milicores
    cpuReq = await formatearcpu(cpu_Request)
    cpuLim = await formatearcpu(cpu_Limit)

    #Recogemos MEMORY Request
    try:
        memory_Request = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["requests"]["memory"]
    except:
        memory_Request = None

    #Recogemos MEMORY Limit
    try:
        memory_Limit = dc["spec"]["template"]["spec"]["containers"][0]["resources"]["limits"]["memory"]
    except:
        memory_Limit = None

    if memory_Request == None:
        memReqformat = None
    else:
        #Convertimos los datos en bytes
        memReq = await formatearmemory(memory_Request)
        #Convertimos los datos en MiB
        memReqformat = int(memReq/1048576)

    if memory_Limit == None:
        memLimformat = None
    else:
        #Convertimos los datos en bytes
        memLim = await formatearmemory(memory_Limit)
        #Convertimos los datos en MiB
        memLimformat = int(memLim/1048576)

    logger.info(f"Openshift extraction completed")

    replicas = dc["spec"]["replicas"]  #Comprobamos si hay replicas

    if hpa == None:
        currentReplicas = replicas
    else:
        for hp in hpa.items():
            if hp[0] == 'currentReplicas':
                currentReplicas = hp[1]
            if hp[0] == 'scalingActive':
                if hp[1] == 'False':
                    if commentHPA == None:
                        commentHPA = hpa['messageScalingActive']
                    else:
                        commentHPA = commentHPA + ', ' + hpa['messageScalingActive']
            if hp[0] == 'ableToScale':
                if hp[1] == 'False':
                    if commentHPA == None:
                        commentHPA = hpa['messageAbleToScale']
                    else:
                        commentHPA = commentHPA + ', ' + hpa['messageAbleToScale']
                    

    availablereplicas = 0
    unavailableReplicas = 0
    try:
        availablereplicas = dc["status"]["availableReplicas"]  #Comprobamos si estan disponibles
    except:
        unavailableReplicas = dc["status"]["unavailableReplicas"]  #Comprobamos si estan disponibles

    try:
        unavailableReplicas = dc["status"]["unavailableReplicas"]  #Comprobamos si estan disponibles
    except:
        availablereplicas = dc["status"]["availableReplicas"]  #Comprobamos si estan disponibles
    
    if availablereplicas == 0 or unavailableReplicas != 0:
        next
    else:
        cont = 0
        for pod in pods[region]["items"]:
            try:
                podName = pod["metadata"]["name"]
            except KeyError:
                podName = None

            try:
                referenceName = pod["metadata"]["ownerReferences"][0]["name"]
            except KeyError:
                referenceName = None
            
            if pod["metadata"]["ownerReferences"][0]["kind"] == "StatefulSet":
                microPodName = podName[:podName.rfind('-')]
            else:
                if referenceName != None:
                    microPodName = referenceName[:referenceName.rfind('-')]
                else:
                    microPodName = None

            if "-deploy" in podName:
                next
            else:
                #Comparamos nombre del microservicio del pod con el nombre del microservicio del namespace
                if microservice == microPodName:
                    cont = 1
                    try:
                        cpu_pod_Request = pod["spec"]["containers"][0]["resources"]["requests"]["cpu"]
                    except:
                        cpu_pod_Request = None
                    try:
                        cpu_pod_Limit = pod["spec"]["containers"][0]["resources"]["limits"]["cpu"]
                    except:
                        cpu_pod_Limit = None

                    #Formatemos los datos a milicores
                    cpuPodReq = await formatearcpu(cpu_pod_Request)
                    cpuPodLim = await formatearcpu(cpu_pod_Limit)

                    #Si no tiene configurado Request coge la configuración por defecto
                    if cpu_Request == None:
                        cpupodr = cpuPodReq  #Volcamos el valor para luego proceder al calculo o formateo, ya que despues al llevar la coletilla "por defecto" y ser str no se puede hacer calculos
                    
                    #Si no tiene configurado Limit coge la configuración por defecto
                    if cpu_Limit == None:
                        cpupodl = cpuPodLim  #Volcamos el valor para luego proceder al calculo o formateo, ya que despues al llevar la coletilla "por defecto" y ser str no se puede hacer calculos

                    try:
                        memory_pod_Request = pod["spec"]["containers"][0]["resources"]["requests"]["memory"]
                    except:
                        memory_pod_Request = None
                    try:
                        memory_pod_Limit = pod["spec"]["containers"][0]["resources"]["limits"]["memory"]
                    except:
                        memory_pod_Limit = None

                    memPodReq = await formatearmemory(memory_pod_Request)
                    memPodReqformat = int(memPodReq/1048576)
                    memPodLim = await formatearmemory(memory_pod_Limit)
                    memPodLimformat = int(memPodLim/1048576)

                    if memory_Request == None:
                        memPodr = memPodReqformat
                    
                    if memory_Limit == None:
                        memPodl = memPodLimformat

                    if len(Ps) == 0:
                        #clustertraduc = await traductorcluster(environment=environment,region=region,cluster=cluster)
                        Ps = await elastic(identificador=identificador,environment=environment,clustertraduc=machine,namespace=namespace)

                    if len(Ps) == 0:
                        next
                    else:                   
                        use = [] 
                        usage = {}
                        max = 0
                        logger.info(f"Processing elastic data from {podName}")

                        for n in Ps: #Recorremos los datos que hemos traido de elastic para tratarlos.
                            try:
                                pod_name = n['_source']['kubernetes']['pod']['name'] #Nombre del pod de elastic
                            except:
                                pod_name = ''
                            
                            if podName == pod_name: #Comprobamos que le pod de openshift y el pod de elastic es el mismo
                                try:
                                    #cp_usage = n['_source']['kubernetes']['pod']['cpu']['usage']['nanocores']['percentiles']['95'] #Extraermos el uso
                                    cp_usage = n['_source']['kubernetes']['container']['cpu']['usage']['nanocores'] #Extraermos el uso
                                except:
                                    try:
                                        cp_usage = n['_source']['kubernetes']['pod']['cpu']['usage']['nanocores'] #Extraermos el uso
                                    except:
                                        cp_usage = 0 #Sino encontramos uso lo marcamos como uso 0

                                if cp_usage == None:
                                    cpu_usage = 0
                                else:
                                    cpu_usage = int(cp_usage / 1000000) #El uso en nanocores lo pasamos a milicores y redondeamos para quitar decimales

                                if cpu_usage > max:
                                    max = cpu_usage

                                #Calulamos el ahorro (request-uso)
                                ahorrocpu = int(cpuPodReq) - cpu_usage

                                #Calulamos el riesgo (limit-uso)
                                riesgocpu = int(cpuPodLim) - cpu_usage                               
                                    
                                try:
                                    #mem_working_set = n['_source']['kubernetes']['pod']['memory']['usage']['bytes']['total']['max']
                                    #mem_working_setUsage = n['_source']['kubernetes']['container']['memory']['usage']['bytes']
                                    mem_working_set = n['_source']['kubernetes']['container']['memory']['workingset']['bytes']
                                except:
                                    try:
                                        #mem_working_setUsage = n['_source']['kubernetes']['pod']['memory']['usage']['bytes']
                                        mem_working_set = n['_source']['kubernetes']['pod']['memory']['working_set']['bytes']
                                    except:
                                        mem_working_set = 0
                                        #mem_working_setUsage = 0

                                if mem_working_set == 0:
                                    memory_working_setformat = 0
                                    #memory_working_setformatUsage = 0
                                else:
                                    if mem_working_set == None:
                                        memory_working_setformat = 0
                                        #memory_working_setformatUsage = 0
                                    else:
                                        memory_working_setformat = int(mem_working_set/1048576)
                                        #memory_working_setformatUsage = int(mem_working_setUsage/1048576)                              

                                #Calulamos el ahorro (request-uso)
                                ahorro_avgPod = int(memPodReqformat - memory_working_setformat)

                                #Calulamos el riesgo (limit-uso)
                                riesgo_avgPod = int(memPodLimformat - memory_working_setformat)

                                #Montamos el diccionario de uso del pod
                                usage = {
                                    "CPUUsage": cpu_usage,
                                    "OptimizationCPUPod": ahorrocpu,
                                    "RiskCPUPod": riesgocpu,
                                    "MemoryUsage+Cache": memory_working_setformat,
                                    #"MemoryUsage+CacheUSAGE": memory_working_setformatUsage,
                                    "OptimizationMemoryPod": ahorro_avgPod,
                                    "RiskMemoryPod": riesgo_avgPod,
                                }

                                #Lo añadimos a una lista, esta contiene todos los usos encontrados en elastic de un unico pod
                                use.append(usage)

                        cpuPoReq = await formatearcpu(cpu_pod_Request)
                        cpuPoLim = await formatearcpu(cpu_pod_Limit)
                        if len(use) == 0:
                            cpu_usage = 0
                            max = cpu_usage

                            ahorrocpu = int(cpuPoReq - cpu_usage)
                            riesgocpu = int(cpuPoLim - cpu_usage)

                            memory_working_setformat = 0
                            ahorro_avg = int(memPodReqformat - memory_working_setformat)
                            riesgo_avg = int(memPodLimformat - memory_working_setformat)

                            usage = {
                                    "CPUUsage": cpu_usage,
                                    "OptimizationCPUPod": ahorrocpu,
                                    "RiskCPUPod": riesgocpu,
                                    "MemoryUsage+Cache": memory_working_setformat,
                                    #"MemoryUsage+CacheUSAGE": memory_working_setformatUsage,
                                    "OptimizationMemoryPod": ahorro_avg,
                                    "RiskMemoryPod": riesgo_avg,
                                }
                            use.append(usage)
                            for d in use:
                                resultado = d
                        else:    
                            for d in use:
                                if d["CPUUsage"] >= max:
                                    resultado = d

                        pds = {
                            "Pod": podName,     
                            "cpuRequestPod": cpuPodReq,
                            "cpuLimitPod": cpuPodLim,
                            "memoryRequestPod": memPodReqformat,
                            "memoryLimitPod": memPodLimformat,
                            "use":resultado
                            }
                        podNameList.append(pds)
                        logger.info("Processing data from elastic completed")
                else:
                    if cont == 1:
                        cont = 0
                        break
                    else:
                        next

        
        if len(Ps) == 0:
            next
        else:
            logger.info("Calculating microservice CPU totals")
            #Calcular los totales del microservicio

            usoTotal = await totalusomicro(pod_dict=podNameList)
            usoTotalMicCPU = int(usoTotal[0])
            usoMedioCPU = int(usoTotalMicCPU / replicas)
            if cpuReq == None:
                requestTotalCPU = int(cpupodr * replicas)
                OpCPUmic = int(requestTotalCPU - usoTotalMicCPU)
            else:
                requestTotalCPU = int(cpuReq * replicas)
                OpCPUmic = int(requestTotalCPU - usoTotalMicCPU)
                
            if cpuLim == None:
                limitTotalCPU = int(cpupodl * replicas)
                RiskCPUmic = int(limitTotalCPU - usoTotalMicCPU)
            else:
                limitTotalCPU = int(cpuLim * replicas)
                RiskCPUmic = int(limitTotalCPU - usoTotalMicCPU)
            
            #Calcular los totales del microservicio
            logger.info("Calculating microservice MEMORY totals")
    
            if availablereplicas == 0:
                usoTotalMic = 0
                usoMedioMicro = 0
                opMemMicc = 0
                riskMemMicc = 0
                requestTotal = 0
                limitTotal = 0
            else:
                if "we cannot extract information" in podNameList:
                    usoTotalMic = 0
                    usoMedioMicro = 0
                    requestTotal = 0
                    limitTotal = 0
                    opMemMicc = 0
                    riskMemMicc = 0
                else:
                    usoTotalMic = int(usoTotal[3])
                    if usoTotalMic == 0:
                        usoTotalMic = 0
                        usoMedioMicro = 0
                        opMemMicc = 0
                        riskMemMicc = 0
                        requestTotal = 0
                        limitTotal = 0
                    else:
                        usoMedioMicro = int(usoTotalMic / replicas)
                    if memReqformat == None:
                        requestTotal = int(memPodr * replicas)
                        opMemMicc = int(requestTotal - usoTotalMic)
                    else:
                        requestTotal = int(memReqformat * replicas)
                        opMemMicc = int(requestTotal - usoTotalMic)
                        
                    if memLimformat == None:
                        limitTotal = int(memPodl * replicas)
                        riskMemMicc = int(limitTotal - usoTotalMic)
                    else:
                        limitTotal = int(memLimformat * replicas)
                        riskMemMicc = int(limitTotal - usoTotalMic)

                

            mc = {
                "microservice": microservice,
                "uid": uidMicro,
                "blockProduction": blockprod,
                "replicasMicroservice": replicas,
                "currentReplicas": currentReplicas,
                "cpuRequestMicroservice": cpuPoReq,
                "cpuLimitMicroservice": cpuPoLim,
                "totalUseMicroserviceCPU": usoTotalMicCPU,
                "AverageUseMicroserviceCPU": usoMedioCPU,
                "totalRequestMicroserviceCPU": requestTotalCPU,
                "totalLimitMicroserviceCPU": limitTotalCPU,
                "totalOptimizationCPUMicroservice": OpCPUmic,
                "totalRiskCPUMicroservice": RiskCPUmic,
                "memoryRequestMicroservice": memPodReqformat,
                "memoryLimitMicroservice": memPodLimformat,
                "totalUseMicroserviceMEM": usoTotalMic,
                "averageUseMicroserviceMEM": usoMedioMicro,
                "totalRequestMicroserviceMEM": requestTotal,
                "totalLimitMicroserviceMEM": limitTotal,
                "totalOptimizationMemoryMicroservice": opMemMicc,
                "totalRiskMemoryMicroservice": riskMemMicc,
                "hpa": hpa,
                "commentHPA":commentHPA,
                "pods": podNameList
            }

            mcList.append(mc)
    logger.info("------ Data extraction completed ------")
    return mcList


async def guardarMongoOnline(datgen,environment,namespace,cluster,region):
    mm = datgen[0]
    totrep = datgen[1]

    datosgen = {
        "environment": environment,
        "cluster": cluster,
        "region": region,
        "namespace": namespace,
        "totalReplicasNamespace": totrep,
        "spec": mm
    }

    #Inserccion Mongo
    mg.change_collection(os.getenv("COLLECTION_ONLINE"))
    querydbresultsmemory = mg.find({f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" })
    findnamespacememory = [x for x in querydbresultsmemory]
    if len(findnamespacememory) == 0:                                
        mg.add_data(data=datosgen)
    else:
        mg.update_one(
            { f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" },
            
            { '$set': {
                f"spec" : mm }
            }
            )
        mg.update_one(
            { f"namespace": namespace, f"cluster":f"{cluster}", f"region":f"{region}" },
            
            { '$set': {
                f"totalReplicasNamespace" : totrep }
            }
            )


async def getDescriptionOnline():
    logger.debug(f'Getting descriptions for Online')

    DescriptionsOnline = [
        {
            "nametoshow": "CPU Usage",
            "description": f"Total CPU used per microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "Memory Usage",
            "description": f"Total memory used per microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "CPU Request",
            "description": f"Total CPU reservation per microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "Memory Request",
            "description": f"Total memory reservation per microservice.",
            "subdescription": ""   
        },{
            "nametoshow": "CPU Limit",
            "description": "Total limit CPU per microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "Memory Limit",
            "description": "Total limit memory per microservice.",
            "subdescription": "" 
        },{
            "nametoshow": "CPU optimization",
            "description": "Total theoretical CPU savings that could be achieved at the microservice level if the reserve is optimized versus use. Subtract usage from request.",
            "subdescription": "CPU Optimization column in red when the value is less than -100 and greater than 100.",
        },{
            "nametoshow": "Memory optimization",
            "description": "Total theoretical memory savings that could be achieved at the microservice level if the reservation is optimized versus use. Subtract usage from request.",
            "subdescription": "Memory Optimization column in red when the value is less than -750 and greater than 750.",
        },{
            "nametoshow": "CPU Risk",
            "description": "Indicates the total amount of CPU limit that we have left before exhausting all resources at the microservice level. Subtract usage from limit.",
            "subdescription": "CPU Risk column in red when the value is less than 400.",
        },{
            "nametoshow": "Memory Risk",
            "description": "Indicates the total amount of memory limit that we have left before exhausting all resources at the microservice level. Subtract usage from limit.",
            "subdescription": "Memory Risk column in red when the value is less than 250.",
        },{
            "nametoshow": "HPA Implemented",
            "description": "Indicates if you have HPA configured.",
            "subdescription": ""      
        },{
            "nametoshow": "HPA Current Replicas",
            "description": "Indicates the current replicas.",
            "subdescription": "HPA Current Replicas column in red when the value is equal than HPA Max Replicas.",    
        },{
            "nametoshow": "HPA Max Replicas",
            "description": "Indicates the maximum configured replicas.",
            "subdescription": "HPA Max Replicas column in red when the value is equal than HPA Current Replicas.",      
        },{
            "nametoshow": "HPA Current Use",
            "description": "Indicates the percentage of current HPA usage.",  
            "subdescription": ""      
        },{
            "nametoshow": "HPA Target",
            "description": "Indicates the percentage at which the HPA begins to escalate.",
            "subdescription": ""     
        }
    ]

    return DescriptionsOnline
