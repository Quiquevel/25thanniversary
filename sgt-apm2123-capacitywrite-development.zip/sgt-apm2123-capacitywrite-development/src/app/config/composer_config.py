from version import __version__
from ..config import global_config

description = """
CAPACITY WRITE

### DESCRIPTION
    Microservice that measures online and weekly capacity and, based on the data, gives a trend, recommends or indicates usage peaks.

### ENTITYS
    Spain:
        Cluster: prodarwin - Region: bo1, bo2
        Cluster: dmzbdarwin - Region: bo1, bo2
        Cluster: probks - Region: bo1, bo2
        Cluster: dmzbbks - Region: bo1, bo2
        Cluster: ocp05azure - Region: wue1, weu2
        Cluster: confluent - Region: bo1, bo2
        Cluster: dmz2bmov - Region: bo1, bo2
     Sgt:
        Cluster: sgt01.sgt.pro - Region: cn1, cn2 
     Corp:
        Cluster: gsc04.gsc.pro - Region: cn1, cn2

### REPO 
* [sgt-apm2123-capacitywrite](https://github.com/santander-group-sds-gln/sgt-apm2123-capacitywrite#)
"""

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "Capacity Write",
          "description": description,
          "contact": {
               "name": "Javier Fuentes"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
