from shuttlelib.utils.logger import logger
from datetime import datetime
import shuttlelib.db.mongo as mongolib
import os

mg = mongolib.MongoClient()

def update_mongo(micro, micronameotherblock, key, value):
    logger.debug(f'[DEBUG] -   Micro {micronameotherblock}: Updating {key} {value} ')
    try:
        updated_data = mg.update_one({'cluster': micro.get("cluster"), 
        'region': micro.get("region"), 
        'namespace': micro.get("namespace"), 
        'name': micronameotherblock},
        {"$set": {key: value}})

        if updated_data.modified_count == 1:
            logger.info(f'[INFO] - OK!!! {micro.get("namespace")}: Micro {micronameotherblock} of {micro.get("cluster")}-{micro.get("region")}: {key} updated')
            mg.update_one({'cluster': micro.get("cluster"), 'region': micro.get("region"), 'namespace': micro.get("namespace")}, {"$set": {"timestamp": datetime.utcnow()}})
        else:
            logger.debug(f'[DEBUG] - KO!!! {micro.get("namespace")}: Micro {micronameotherblock} of {micro.get("cluster")}-{micro.get("region")}: {key} NOT updated')
    except Exception as e:
        logger.error(f"[ERROR] - Failed to update MongoDB for micro {micronameotherblock}: {e}")

def create_mongo_query(cluster=None, region=None, namespaceslist=None):
    query = [{}]

    if region != None:
        query.append({"region": region})

    if cluster != None:
        query.append({"cluster": cluster})

    if namespaceslist != None:
        query.append({"namespace": {"$in": namespaceslist}})

    return query

def get_micro_name_other_block(micro_name):
    micronameotherblock = ""
    if micro_name.endswith('-g'):
        micronameotherblock = micro_name.removesuffix("-g") + "-b"
    elif micro_name.endswith('-green'):
        micronameotherblock = micro_name.removesuffix("-green") + "-blue"
    elif micro_name.endswith('-b'):
        micronameotherblock = micro_name.removesuffix("-b") + "-g"
    elif micro_name.endswith('-blue'):
        micronameotherblock = micro_name.removesuffix("-blue") + "-green"

    return micronameotherblock

async def check_technology_other_block(cluster=None, region=None, namespaceslist=None):
    mongocollection = os.getenv("COLLECTION","sre_microservices")
    mg.change_collection(collection=mongocollection)

    query = create_mongo_query(cluster, region, namespaceslist)

    fullquery = {"$and": query}

    try:
        all_microsmongo = list(mg.find(fullquery))
    except Exception as e:
        logger.error(f"[ERROR] - Failed to fetch all micros from MongoDB: {e}")
        return

    technology_dict_to_search =  {"$and": [{"technology_dict.technology": {"$ne": None}},{"technology_dict.version": {"$ne": None}}]}
    query.append(technology_dict_to_search)
    fullquery = {"$and": query}
    
    try:
        microsmongo_tech = list(mg.find(fullquery))
    except Exception as e:
        logger.error(f"[ERROR] - Failed to fetch tech micros from MongoDB: {e}")
        return

    micros_all_dict = {
        micro["name"]: {
            "technology_dict": micro["technology_dict"],
            "image": micro["image"]["name"]+":"+micro["image"]["tag"]
            }
         for micro in all_microsmongo}

    for micro in microsmongo_tech:
        try:
            micro_name = micro.get("name", "")
            micro_technology_dict = micro.get("technology_dict", {})
            micro_version = micro_technology_dict.get("version")
            
            image_info = micro.get("image", {})
            micro_image = f"{image_info.get('name', '')}:{image_info.get('tag', '')}"
            
            micro_status = micro.get("micro_status", {})
            micro_status_block = micro_status.get("block")
            
            if not micro_name or not micro_version:
                logger.debug(f"[DEBUG] - Skipping micro with missing name or version: {micro.get('name', 'unknown')}")
                continue
        except Exception as e:
            logger.error(f"[ERROR] - Error processing micro data: {e}")
            continue
        
        logger.info(f'[INFO] - Checking version for hidden block on {micro["cluster"]}-{micro["region"]}-{micro["namespace"]}')
        
        logger.info(f'[INFO] -     Checking micro {micro_name}')
        micronameotherblock = get_micro_name_other_block(micro_name)

        if micronameotherblock != "":
            logger.debug(f'[DEBUG] -     Micro: {micro_name}. MicroOtherBlock: {micronameotherblock}')
            other_block_data = micros_all_dict.get(micronameotherblock, None)
            if other_block_data is None:
                logger.debug(f'[DEBUG] - Micro {micronameotherblock} not found in dictionary')
                continue
            try:
                technology_dict = other_block_data.get("technology_dict", {})
                other_block_version = technology_dict.get("version")
                other_block_image = other_block_data.get("image", "")
            except Exception as e:
                logger.error(f"[ERROR] - Error accessing other block data for {micronameotherblock}: {e}")
                continue

            if other_block_version != micro_version and (other_block_version == None or (micro_status_block != "Hidden" and other_block_image == micro_image)):
                
                update_mongo(micro,micronameotherblock,key="technology_dict",value=micro_technology_dict)

async def check_javadict_other_block(cluster=None, region=None, namespaceslist=None):
    mongocollection = os.getenv("COLLECTION","sre_microservices")
    mg.change_collection(collection=mongocollection)

    query = create_mongo_query(cluster, region, namespaceslist)

    fullquery = {"$and": query}

    try:
        all_microsmongo = list(mg.find(fullquery))
    except Exception as e:
        logger.error(f"[ERROR] - Failed to fetch all micros from MongoDB: {e}")
        return

    java_dict_to_search =  {"javadict.version": {"$ne": None}}
    query.append(java_dict_to_search)
    fullquery = {"$and": query}
    
    try:
        microsmongo_java = list(mg.find(fullquery))
    except Exception as e:
        logger.error(f"[ERROR] - Failed to fetch java micros from MongoDB: {e}")
        return

    micros_all_dict = {
        micro["name"]: {
            "javadict": micro["javadict"],
            "image": micro["image"]["name"]+":"+micro["image"]["tag"]
            }
         for micro in all_microsmongo}

    for micro in microsmongo_java:
        try:
            micro_name = micro.get("name", "")
            micro_javadict = micro.get("javadict", {})
            micro_version = micro_javadict.get("version")
            
            image_info = micro.get("image", {})
            micro_image = f"{image_info.get('name', '')}:{image_info.get('tag', '')}"
            
            micro_status = micro.get("micro_status", {})
            micro_status_block = micro_status.get("block")
            
            if not micro_name or not micro_version:
                logger.debug(f"[DEBUG] - Skipping micro with missing name or version: {micro.get('name', 'unknown')}")
                continue
        except Exception as e:
            logger.error(f"[ERROR] - Error processing micro data: {e}")
            continue
        
        logger.info(f'[INFO] - Checking version for hidden block on {micro["cluster"]}-{micro["region"]}-{micro["namespace"]}')
        
        logger.info(f'[INFO] -     Checking micro {micro_name}')
        
        micronameotherblock = get_micro_name_other_block(micro_name)     

        if micronameotherblock != "":
            logger.debug(f'[DEBUG] -     Micro: {micro_name}. MicroOtherBlock: {micronameotherblock}')
            other_block_data = micros_all_dict.get(micronameotherblock, None)
            if other_block_data is None:
                logger.debug(f'[DEBUG] - Micro {micronameotherblock} not found in dictionary')
                continue
            try:
                javadict = other_block_data.get("javadict", {})
                other_block_version = javadict.get("version")
                other_block_image = other_block_data.get("image", "")
            except Exception as e:
                logger.error(f"[ERROR] - Error accessing other block data for {micronameotherblock}: {e}")
                continue

            if other_block_version != micro_version and (other_block_version == None or (micro_status_block != "Hidden" and other_block_image == micro_image)):
                
                update_mongo(micro,micronameotherblock,key="javadict",value=micro_javadict)
