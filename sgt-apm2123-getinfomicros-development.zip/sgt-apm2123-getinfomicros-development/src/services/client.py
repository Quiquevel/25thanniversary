from shuttlelib.openshift.client import OpenshiftClient
import os

client = OpenshiftClient(os.getenv("ENTITY_ID","spain"))