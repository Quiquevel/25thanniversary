from shuttlelib.utils.logger import logger
import aiohttp
import json
import requests
import urllib, websocket, ssl
import shuttlelib.db.mongo as mongolib
from datetime import datetime, timezone
import os
from src.services.client import client
import re
import difflib
from packaging import version

mg = mongolib.MongoClient()
APPLICATION_JSON = "application/json"

async def  delete_nonexisting_namespaces(openshift_namespacesid,clusterparam,regionparam,namespaceslist):   

    mongodata = mg.find({})

    mongo_namespacesids = set()
    for element in mongodata:
        mongo_namespacesids.add(element["namespaceid"])

    if clusterparam is None and regionparam is None and namespaceslist is None:
        for id in mongo_namespacesids:
            if id not in openshift_namespacesid:
                logger.info(f'Namespace {id} deleted from mongo since it is not on Openshift anymore.')
                mg._collection.delete_many({"namespaceid": id}) #For deleting namespaces that not exists anymore on Openshift

async def save_data_into_database(micro_dict,micro_id,micro_name,micro_kind,mongo_microsid_list):
    mongocollection = os.getenv("COLLECTION")
    mg.change_collection(collection=mongocollection)
    if micro_id+"-"+micro_kind not in mongo_microsid_list:
        mg.add_data(micro_dict)
    else:
        logger.info(f'Checking changes in Microservice {micro_name}')
        valueschangedflag = False
        mongoupdated = False
        mongomicro = mg.find_one({"$and": [{"id": micro_id},{"kind": micro_kind}]})
        mongomicroforcomparison = mongomicro.copy()
        del mongomicroforcomparison["_id"]
        del mongomicroforcomparison["timestamp"]
        valueschangedflag = await compare_info(openshiftvalues=micro_dict,mongovalues=mongomicroforcomparison)
        if valueschangedflag:
            #Change existing keys
            mongoupdated = await update_mongo_data(id=mongomicro["id"],kind=micro_kind,collection=mongocollection,datakey=None,datavalue=micro_dict)
            #Delete not-existing-anymore keys
            deletedkeys = [key for key in mongomicroforcomparison.keys() if key not in str(micro_dict.keys())]
            for keytodelete in deletedkeys:
                mongoupdated = await update_mongo_data(id=mongomicro["id"],kind=micro_kind,collection=mongocollection,datakey=keytodelete,datavalue=None,action="unset")
        if mongoupdated == True:
            logger.info('Mongo updated')

async def get_paused_rollouts(micro):
    try:
        pausedrollouts = micro["spec"]["paused"]
    except KeyError:
        pausedrollouts = False

    return pausedrollouts

async def get_wrong_routing_from_config_maps(micro, namespaceid):
    wrong_routing = []
    configmap_name = None
    mg.change_collection("sre_configmaps")
    volumes = micro.get("spec", {}).get("template", {}).get("spec", {}).get("volumes", [])
    configmap_name = get_configmap_name(volumes)
    if configmap_name:
        configmap_mongo = mg.find_one({"id": f'{namespaceid}-{configmap_name}'})
        if configmap_mongo:
            wrong_routing = process_configmap_mongo(configmap_mongo)
    return wrong_routing

async def get_wrong_routing(hasconfigmap,micro_status,micro,namespaceid):
    if hasconfigmap["useconfigmap"] == True and \
        (micro_status["block"] == "Real" or \
            micro_status["block"] == "Unknown" and micro_status["status"] == "OK"):
        wrong_routing = await get_wrong_routing_from_config_maps(micro, namespaceid)
        if wrong_routing == []: 
            wrong_routing = None
    else:
        #CHECK GITHUBCONF PERO DE MOMENTO PONGO NONE
        wrong_routing = None

    return wrong_routing

def get_configmap_name(volumes):
    for elem in volumes:
        for key, value in elem.items():
            if key == "configMap":
                return value["name"]
    return None

def process_configmap_mongo(configmap_mongo):
    wrong_routing = []
    for elem in configmap_mongo["pathslist"]:
        ocudevprupathslist = get_ocudevprupathslist(elem["pathslist"])
        if ocudevprupathslist:
            wrong_routing.append({"file": elem["file"], "ocudevpru": ocudevprupathslist})
    return wrong_routing

def get_ocudevprupathslist(pathslist):
    ocudevprupathslist = []
    for path in pathslist:
        if "ocu." in str(path) or "pru." in str(path) or "dev." in str(path):
            variable_name = path["variable"]
            variable_value = path["value"]
            if is_valid_path(variable_name, variable_value):
                ocudevprupathslist.append(path)
    return ocudevprupathslist

def is_valid_path(variable_name, variable_value):
    return (
        "document" not in variable_name.lower()
        and not variable_value.startswith("#")
        and "cors-origins" not in variable_name.lower()
        and not variable_name.startswith("allowedOrigins")
    )

async def check_mismatched_variables(microname,env):
    mismatched_variables = []
    
    if microname.endswith("-g") or microname.endswith("-green"):
        patternlisttosearch = ["-b:","-blue:","blue"]
        patternlisttofinish = ["-b","-blue"]
    elif microname.endswith("-b") or microname.endswith("-blue"):
        patternlisttosearch = ["-g:","-green:","green"]
        patternlisttofinish = ["-g","-green"]
    else:
        patternlisttofinish = []
        patternlisttosearch = []

    if patternlisttosearch != [] and patternlisttofinish != []:
        for key,value in env.items():
            if value != None and (any(value.endswith(pattern) for pattern in patternlisttofinish) or any(pattern in value for pattern in patternlisttosearch)):
                mismatched_variables.append({key:value})
    
    return mismatched_variables

async def get_namespace_objects(functional_environment,cluster,region,namespace,resource):

    try:
        k8s_objects = await client.get_resource(resource=resource,functional_environment=functional_environment,cluster=cluster,region=region,namespace=namespace)
        objectitems = k8s_objects[region]["items"]
    except Exception as e:
        logger.error(f'{resource} couldn\'t be obtained: {e}')
        objectitems = []

    return objectitems

async def normalize_units(measure):

    if measure.endswith("Ki"):
        measure = int(measure[:-2])*2**10                
    elif measure.endswith("Mi"):
        measure = int(measure[:-2])*2**20
    elif measure.endswith("Gi"):
        measure = int(measure[:-2])* 2**30
    elif measure.endswith("Ti"):
        measure = int(measure[:-2])* 2**40                    
    elif measure.endswith("K") or measure.endswith("k"):
        measure = int(measure[:-1])*1000
    elif measure.endswith("M") or measure.endswith("m"):
        measure = int(measure[:-1])*1000*1000
    elif measure.endswith("G") or measure.endswith("g"):
        measure = int(measure[:-1])*1000*1000*1000
    elif measure.endswith("T") or measure.endswith("t"):
        measure = int(measure[:-1])*1000*1000*1000*1000
    else:
        measure = int(measure)

    return measure

async def get_usage(quota, element):
    
    percentage = 0

    try:
        elementnow = quota["status"]["used"][element]
    except KeyError:
        elementnow = None
    
    try:
        elementmax = quota["spec"]["hard"][element]
    except KeyError:
        elementmax = None

    if elementmax != None and elementnow != None:
        elementmax = await normalize_units(elementmax)
        elementnow = await normalize_units(elementnow)

        percentage = round(elementnow/elementmax*100, 2)

    return percentage, elementnow, elementmax

async def get_same_unit(element, unit):

    match unit:
        case "Ki":
            element = str(round(element/2**10,2))+"Ki"
        case "Mi":
            element = str(round(element/2**20,2))+"Mi"
        case "Gi":
            element = str(round(element/2**30,2))+"Gi"
        case "Ti":
            element = str(round(element/2**40,2))+"Ti"
        case "K":
            element = str(round(element/1000,2))+"K"
        case "M":
            element = str(round(element/1000/1000,2))+"M"
        case "G":
            element = str(round(element/1000/1000/1000,2))+"G"
        case "T":
            element = str(round(element/1000/1000/1000/1000,2))+"T"
        case _:
            return element

    return element

async def get_micro_status(microname,microsonline,microsoffline):

    if microname in microsonline:
        micro_status = "real"
    elif microname in microsoffline:
        micro_status = "hidden"
    else:
        micro_status = "unknown"

    return micro_status

async def get_micro_suffix(microname):
    if microname.endswith("-b") or microname.endswith("-blue"):
        microsuffix = "blue"
    elif microname.endswith("-g") or microname.endswith("-green"):
        microsuffix = "green"
    else:
        microsuffix = "no_suffix"

    return microsuffix
 
async def get_pods_of_micro(microname,pods):
    pods_of_micro = []

    for pod in pods:
        try:
            owner_reference_full = pod["metadata"]["ownerReferences"][0]["name"]
            owner_reference = owner_reference_full[:owner_reference_full.rfind("-")]
            owner_reference_no_block = owner_reference[:owner_reference.rfind("-")]
        except Exception as e:
            owner_reference_no_block = None
            logger.error(f'Error getting ownerReference of pod {pod["metadata"]["name"]}: {e}')

        if microname[:microname.rfind("-")] == owner_reference_no_block:
            pods_of_micro.append(pod["metadata"]["name"])    

    return pods_of_micro

async def get_pods_blue_green(pods_of_micro):
    pods_blue = 0
    pods_green = 0
    for pod in pods_of_micro:
        if pod.__contains__("-b-") or pod.__contains__("-blue-"):
            pods_blue = pods_blue + 1
        elif pod.__contains__("-g-") or pod.__contains__("-green-"):
            pods_green = pods_green + 1

    return pods_blue,pods_green

async def get_micro_pods_status(pods_of_micro,pods_blue, pods_green, microsuffix):
    if pods_blue > pods_green:
        return await handle_more_blue_pods(microsuffix, pods_green)
    elif pods_blue < pods_green:
        return await handle_more_green_pods(microsuffix, pods_blue)
    else:
        return await handle_equal_pods(pods_of_micro)

async def handle_more_blue_pods(microsuffix, pods_green):
    if microsuffix == "blue":
        return "real"
    elif microsuffix == "green":
        return "off" if pods_green == 0 else "hidden"
    else:
        return "unknown"

async def handle_more_green_pods(microsuffix, pods_blue):
    if microsuffix == "blue":
        return "off" if pods_blue == 0 else "hidden"
    elif microsuffix == "green":
        return "real"
    else:
        return "off" if pods_blue == 0 else "unknown"

async def handle_equal_pods(pods_of_micro):
    return "off" if pods_of_micro == 0 else "unknown"

async def get_real_micro_status(micro_status,cluster):
    if micro_status == "hidden":
        block = "Hidden"
        status = "KO"
        reason = "This micro has more running pods than the real one"
    elif micro_status == "unknown":
        if cluster == "confluent":
            block = "Unknown"
            status = "OK"
            reason = "No services apply but this micro has more running pods than the one on the other block"
        else:
            block = "Unknown"
            status = "OK"
            reason = "This micro has no service b-g/g-b routing to it but this is the one with more running pods"
    else:
        block = "Real"
        status = "OK"
        reason = None

    micro_status_dict = {
        "block": block,
        "status": status,
        "reason": reason
    }

    return micro_status_dict

async def get_hidden_micro_status(micro_status,cluster):
    if micro_status == "real":
        block = "Real"
        status = "KO"
        reason = "This micro has less running pods than the hidden one"
    elif micro_status == "unknown":
        if cluster == "confluent":
            block = "Unknown"
            status = "OK"
            reason = "No services apply but this micro has less running pods than the one on the other block"                    
        else:
            block = "Unknown"
            status = "OK"
            reason = "This micro has no service b-g/g-b routing to it but this is the one with less running pods"                       
    else:
        block = "Hidden"
        status = "CHECK"
        reason = "This micro has running pods"   

    micro_status_dict = {
        "block": block,
        "status": status,
        "reason": reason
    }

    return micro_status_dict

async def get_unknown_micro_status(micro_status,cluster):
    if micro_status == "real":
        block = "Real"
        status = "KO"
        reason = "This micro has the same running pods number than the hidden one (> 0)"
    elif micro_status == "hidden":
        block = "Hidden"
        status = "KO"
        reason = "This micro has the same running pods number than the real one (> 0)"
    else:
        if cluster == "confluent":
            block = "On"
            status = "OK"
            reason = "No services apply but the micro has running pods"                    
        else:
            block = "On"
            status = "CHECK"
            reason = "This micro has no service b-g/g-b routing to it but the micro has running pods" 

    micro_status_dict = {
        "block": block,
        "status": status,
        "reason": reason
    }

    return micro_status_dict
    
async def get_off_micro_status(micro_status,cluster):
    if micro_status == "real":
        block = "Real"
        status = "KO"
        reason = "This micro has no running pods"                 
    elif micro_status == "hidden":
        block = "Hidden"
        status = "OK"
        reason = "This micro has no running pods"                 
    else:
        if cluster == "confluent":
            block = "Off"
            status = "OK"
            reason = "No services apply and the micro has no running pods"                       
        else:
            block = "Off"
            status = "OK"
            reason = "This micro has no service b-g/g-b routing to it"        

    micro_status_dict = {
        "block": block,
        "status": status,
        "reason": reason
    }

    return micro_status_dict

async def get_final_micro_status_dict(micro_pods_status,micro_status,cluster):

    match micro_pods_status:
        case "real":
            micro_status_dict = await get_real_micro_status(micro_status,cluster)
        case "hidden":
            micro_status_dict = await get_hidden_micro_status(micro_status,cluster)                 
        case "unknown":
            micro_status_dict = await get_unknown_micro_status(micro_status,cluster)                          
        case "off":
            micro_status_dict = await get_off_micro_status(micro_status,cluster)

    return micro_status_dict

async def confirm_real_hidden_block(microname,pods,microsonline,microsoffline,cluster,servicesselectors):
    
    if microname not in servicesselectors:
        
        final_micro_status_dict = {
            "block": "Unknown",
            "status": "KO",
            "reason": "No services routing to this microservice"
        }

    else:
        micro_status = await get_micro_status(microname,microsonline,microsoffline)
        microsuffix = await get_micro_suffix(microname)

        pods_of_micro = await get_pods_of_micro(microname,pods)

        pods_blue, pods_green = await get_pods_blue_green(pods_of_micro)
        
        micro_pods_status = await get_micro_pods_status(len(pods_of_micro),pods_blue,pods_green,microsuffix)
        
        final_micro_status_dict = await get_final_micro_status_dict(micro_pods_status, micro_status,cluster)
    
    return final_micro_status_dict

async def get_full_darwin_info(entity_id,functional_environment,bkstoken,namespace,cluster,region):
    user=(os.getenv("USERSHUTTLE"))
    passwd=(os.getenv("USERSHUTTLEPASSWD"))
    darwinversionsdictslist = []
    darwinindexdict = {}
    if bkstoken != False:

        arqresponse = await get_darwin_versions(entity_id,functional_environment,bkstoken,namespace)
        if arqresponse != None:
            darwinversionsdictslist = await create_darwin_dict(namespace,arqresponse,cluster,region)
        else:
            #quick solution just for retry getting reponse if 401 http status code error was got.
            jwt_token = await get_jwt_token(functional_environment,user,passwd)
            bkstoken = await get_bks_token(functional_environment,jwt_token)
            arqresponse = await get_darwin_versions(entity_id,functional_environment,bkstoken,namespace)
            if arqresponse != None:
                darwinversionsdictslist = await create_darwin_dict(namespace,arqresponse,cluster,region)

        darwinindexlist = [{"microname": elem["deployment"],"position": index} for index,elem in enumerate(darwinversionsdictslist)]

        for elem in darwinindexlist:
            darwinindexdict.update({elem["microname"]: elem["position"]})

    return darwinversionsdictslist, darwinindexdict

async def create_services_dict(service, namespaceinfo):
    
    servicesdict = {}
    try:
        labels = service["metadata"]["labels"]
    except KeyError:
        labels = None
    
    try:
        selectors = service["spec"]["selector"]
    except KeyError:
        selectors = None

    try:
        cluster_ip = service["spec"]["clusterIP"]
    except KeyError:
        cluster_ip = None
    
    try:
        internal_traffic_policy = service["spec"]["internalTrafficPolicy"]
    except KeyError:
        internal_traffic_policy = None

    try:
        service_type = service["spec"]["type"]
    except KeyError:
        service_type = None
    
    try:
        ip_family_policy = service["spec"]["ipFamilyPolicy"]
    except KeyError:
        ip_family_policy = None

    try:
        session_affinity = service["spec"]["sessionAffinity"]
    except KeyError:
        session_affinity = None

    servicesdict = {
        "name": service["metadata"]["name"],
        "creationTimestamp": service["metadata"]["creationTimestamp"],
        "labels": labels,
        "selectors": selectors,
        "clusterIP": cluster_ip,
        "internalTrafficPolicy": internal_traffic_policy,
        "type": service_type,
        "ipFamilyPolicy": ip_family_policy,
        "sessionAffinity": session_affinity
    }

    #servicelist.append(servicesresult)

    servicesdict.update(namespaceinfo)

    return servicesdict

async def create_configmaps_dict(configmap, namespaceinfo):
    datalist = []
    
    try:
        labels = configmap["metadata"]["labels"]
    except KeyError:
        labels = None


    configmapsdict = {
        "name": configmap["metadata"]["name"],
        "labels": labels,
        "creationTimestamp": configmap["metadata"]["creationTimestamp"]
    }

    try:
        configmapdata = configmap['data']
    except KeyError:
        try:
            configmapdata = configmap['binaryData']
        except KeyError:
            configmapdata = None
    except Exception as e:
        logger.info(f'Error getting configmap data: {e}')
        configmapdata = None


    if configmapdata != None:
        for k,v in configmapdata.items():
            datalist.append({k: v})
    else:
        datalist = None

    configmapsdict.update({"data": datalist})
    configmapsdict.update(namespaceinfo)

    return configmapsdict

async def get_real_hidden_agreement(entity_id):
    match entity_id:
        case "spain":
            real = "b-g-"
            hidden = "g-b-"
        case _:
            real = "pro"
            hidden = "ocu"

    return real, hidden

async def get_selector_agreement(entity_id):
    match entity_id:
        case "spain":
            selector = "app_name"
        case _:
            selector = "app_name"

    return selector

async def get_services_selector(services):
    selectorslist = set()
    for svc in services:

        try:
            selectors = svc["spec"]["selector"]
        except KeyError:
            selectors = None
        
        if selectors != None:
            for selectorvalue in selectors.values():
                selectorslist.add(selectorvalue)

    return selectorslist

async def get_micros_online(entity_id,services):

    microsonline = []
    microsoffline = []

    real, hidden = await get_real_hidden_agreement(entity_id)
    selector_name = await get_selector_agreement(entity_id)

    for svc in services:

        svc_name = svc["metadata"]["name"]

        try:
            selectors = svc["spec"]["selector"]
        except KeyError:
            selectors = None

        if real in svc_name:
            try:
                microsonline.append(selectors[selector_name])
            except KeyError:
                logger.error(f'Service {svc_name} of {svc["metadata"]["namespace"]} is not using {selector_name} as selector')

        elif hidden in svc_name:
            try:
                microsoffline.append(selectors[selector_name])
            except KeyError:
                logger.error(f'Service {svc_name} of {svc["metadata"]["namespace"]} is not using {selector_name} as selector')     

    return microsonline,microsoffline

async def get_darwin_versions(entity_id,functional_environment,tokenbks,namespace):
    
    logger.debug('[DEBUG]- Getting Darwin versions...')
    headers= {
        "Content-Type": APPLICATION_JSON,
        "x-clientId" : "crasto",
        "Authorization" : f'Bearer {tokenbks}'
              }
    if functional_environment == "pro":
        url = "https://janssen.corp.bsch/web/graphql"
    elif functional_environment == "pre":
        url = "https://janssen.pru.bsch/web/graphql"        
    elif functional_environment == "dev":
        url = "https://janssen.santander.dev.corp/web/graphql"

    querystring = """
        query getInfoNamespace($project: String!){
            infoDeployments(ocpProject: $project){
                environmentName, 
                regions {
                    name, 
                    deploymentsBG {
                        real {
                            name, 
                            fullName, 
                            type, 
                            technology, 
                            technologyVersion, 
                            framework, 
                            frameworkVersion, 
                            obsolescenceLight, 
                            image, 
                            gitRepo, 
                            jenkinsPipe, 
                            healthCheckReadiness, 
                            healthCheckLiveness, 
                            kibanaLogs, 
                            isJob, 
                            microfront, 
                            microfrontVersion, 
                            environmentVars {
                                key, 
                                value
                            }
                        } 
                        hidden {
                            name, 
                            fullName, 
                            type, 
                            technology, 
                            technologyVersion, 
                            framework, 
                            frameworkVersion, 
                            obsolescenceLight, 
                            image, 
                            gitRepo, 
                            jenkinsPipe, 
                            healthCheckReadiness, 
                            healthCheckLiveness, 
                            kibanaLogs, 
                            isJob, 
                            microfront, 
                            microfrontVersion
                        }
                    }
                }
            }
        }
    """

    variables = {"project": namespace}

    request_body = {
        "query": querystring,
        "variables": variables
    }
    logger.debug(f'Querying Arq using graphql for obtaining micros info of {entity_id}-{namespace}...')

    async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers,data=json.dumps(request_body) ,verify_ssl=True,timeout=aiohttp.ClientTimeout(total=15,connect=10)) as r:
                try:
                    response = await r.json()
                    return response
                except Exception as e:
                    logger.error(f'Error getting janssen data: {e}')
                    return None
    

async def create_darwin_dict(namespace,arqinfogot,cluster,region):
    deploymentsdictslist = []

    logger.debug(f'Getting deploymentsBG of {namespace}...')
    
    try:
        deployments_blue_green = []
        for regiondict in arqinfogot["data"]["infoDeployments"][0]["regions"]:
            clusterregion = regiondict["name"].split("-")
            regionjanssen = clusterregion[0].strip()
            clusterjanssen = clusterregion[1].strip()
            # Verificar si coinciden con los parámetros deseados
            if clusterjanssen.lower() == cluster and regionjanssen.lower() == region:
                deployments_blue_green = regiondict["deploymentsBG"]
                break
    except Exception as e:
        deployments_blue_green = []
        logger.debug(f'[DEBUG] - Exception occurred: {e}')

    logger.debug(f'Getting final dictionaries list of namespace {namespace}...')

    for deployment in deployments_blue_green:
        if "name" in str(deployment["real"]):
            name = deployment["real"]["name"]
        elif "name" in str(deployment["hidden"]):
            name = deployment["hidden"]["name"]
        else:
            name = None

        if "fullName" in str(deployment["real"]):
            full_name_real = deployment["real"]["fullName"]
            if not full_name_real.endswith("-g") and not full_name_real.endswith('-b') and not full_name_real.endswith("-green") and not full_name_real.endswith('-blue'):
                name = name+'-no-bg-suffix'            
        else:
            full_name_real = None

        if "type" in str(deployment["real"]):
            typereal = deployment["real"]["type"]
        else:
            typereal = None

        if "technology" in str(deployment["real"]):
            technologyreal = deployment["real"]["technology"]
        else:
            technologyreal = None

        if "framework" in str(deployment["real"]):
            frameworkreal = deployment["real"]["framework"]
        else:
            frameworkreal = None

        if "frameworkVersion" in str(deployment["real"]):
            framework_version_real = deployment["real"]["frameworkVersion"]
        else:
            framework_version_real = None

        if "obsolescenceLight" in str(deployment["real"]):
            obsolescence_light_real = deployment["real"]["obsolescenceLight"]
        else:
            obsolescence_light_real = None

        if "fullName" in str(deployment["hidden"]):
            full_name_hidden = deployment["hidden"]["fullName"]
            if not full_name_hidden.endswith("-g") and not full_name_hidden.endswith('-b') and not full_name_hidden.endswith("-green") and not full_name_hidden.endswith('-blue'):
                name = name+'-no-bg-suffix'                        
        else:
            full_name_hidden = None

        if "type" in str(deployment["hidden"]):
            typehidden = deployment["hidden"]["type"]
        else:
            typehidden = None

        if "technology" in str(deployment["hidden"]):
            technologyhidden = deployment["hidden"]["technology"]
        else:
            technologyhidden = None

        if "framework" in str(deployment["hidden"]):
            frameworkhidden = deployment["hidden"]["framework"]
        else:
            frameworkhidden = None

        if "frameworkVersion" in str(deployment["hidden"]):
            framework_version_hidden = deployment["hidden"]["frameworkVersion"]
        else:
            framework_version_hidden = None

        if "obsolescenceLight" in str(deployment["hidden"]):
            obsolescence_light_hidden = deployment["hidden"]["obsolescenceLight"]
        else:
            obsolescence_light_hidden = None

        deploymentdict  =   {"deployment": name,
                                "real": {
                                    "deployment": full_name_real,
                                    "type": typereal,
                                    "technology": technologyreal,
                                    "framework": frameworkreal,
                                    "frameworkVersion": framework_version_real,
                                    "obsolescenceLight": obsolescence_light_real
                                },
                                "hidden": {
                                    "deployment": full_name_hidden,
                                    "type": typehidden,
                                    "technology": technologyhidden,
                                    "framework": frameworkhidden,
                                    "frameworkVersion": framework_version_hidden,
                                    "obsolescenceLight": obsolescence_light_hidden
                                }
                            }
        deploymentsdictslist.append(deploymentdict)

    return deploymentsdictslist

async def select_most_similar_container(pod_name, container_names):
        
        similarities = [
            (c["name"], difflib.SequenceMatcher(None, pod_name, c["name"]).ratio())
            for c in container_names
        ]
        best_match = max(similarities, key=lambda x: x[1])
        return best_match[0]

async def analyze_java_output(data_lines):
    cleaned = [line.lstrip("\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09") for line in data_lines]
    output = "\n".join(cleaned)

    if "java: not found" in output.lower() or "command terminated with non-zero exit code" in output.lower():
        return {}

    info = {
        "javaversion": None,
        "jvm_impl": None,
        "vendor": None,
        "build_info": None,
        "cgroups_v2_compatible": None
    }

    match = re.search(r'(?:java|openjdk) version\s+"([\d._]+)"', output, re.IGNORECASE)
    if match:
        info["javaversion"] = match.group(1)

    match = re.search(r'java\.vendor\s*=\s*(.*)', output)
    if match:
        info["vendor"] = match.group(1).strip()
    elif "IBM" in output:
        info["vendor"] = "IBM"
    elif "OpenJDK" in output:
        info["vendor"] = "OpenJDK"
    elif "Oracle" in output:
        info["vendor"] = "Oracle"

    match = re.search(r'java\.vm\.name\s*=\s*(.*)', output)
    if match:
        info["jvm_impl"] = match.group(1).strip()
    elif "OpenJ9" in output:
        info["jvm_impl"] = "OpenJ9"
    elif "IBM J9" in output:
        info["jvm_impl"] = "IBM J9"
    elif re.search(r'HotSpot|64-Bit Server VM', output):
        info["jvm_impl"] = "HotSpot"

    match = re.search(r'build\s+(openj9-[\d.]+)', output, re.IGNORECASE)
    if match:
        info["build_info"] = match.group(1)

    jvm = (info.get("jvm_impl") or "").lower()
    version = info.get("javaversion") or ""
    build = info.get("build_info") or ""

    async def parse_major_minor_patch(v):
        if "_" in v:
            match = re.search(r'1\.8\.0_(\d+)', v)
            return (8, 0, int(match.group(1))) if match else (8, 0, 0)
        
        parts = re.split(r"[._\-+]", v)
        numbers = [int(p) for p in parts if p.isdigit()]
        if len(numbers) >= 3:
            return tuple(numbers[:3])
        elif len(numbers) == 2:
            return (numbers[0], numbers[1], 0)
        elif len(numbers) == 1:
            return (numbers[0], 0, 0)
        return (0, 0, 0)

    # minimum threshold for cgroupsv2 compatibilty
    MIN_HOTSPOT = {8: (8, 0, 372), 11: (11, 0, 16), 17: (17, 0, 4)}
    MIN_IBM_J9 = {8: (8, 0, 291)} 
    MIN_OPENJ9 = {0: (0, 29)}
    
    try:
        major, minor, patch = await parse_major_minor_patch(version)
    except Exception:
        major = minor = patch = 0

    if jvm == "openj9":
        match = re.search(r'openj9-(\d+)\.(\d+)', build)
        if match:
            build_major, build_minor = int(match.group(1)), int(match.group(2))
            baseline = MIN_OPENJ9.get(build_major)
            if baseline:
                info["cgroups_v2_compatible"] = (build_major, build_minor) >= baseline
            else:
                info["cgroups_v2_compatible"] = build_major > 0
        else:
            info["cgroups_v2_compatible"] = "unknown"
    
    elif "ibm j9" in jvm:
        # BKS/IBM J9: compatible only is version >= 1.8.0_291
        baseline = MIN_IBM_J9.get(major)
        if baseline:
            info["cgroups_v2_compatible"] = (major, minor, patch) >= baseline
        elif major > 8:
            info["cgroups_v2_compatible"] = True
        else:
            info["cgroups_v2_compatible"] = False
    
    elif "hotspot" in jvm or "server vm" in jvm:
        # HotSpot/OpenJDK: specifics thresholds 
        baseline = MIN_HOTSPOT.get(major)
        if baseline:
            info["cgroups_v2_compatible"] = (major, minor, patch) >= baseline
        elif major >= 18:
            info["cgroups_v2_compatible"] = True
        elif major < 8:
            info["cgroups_v2_compatible"] = False
        else:
            info["cgroups_v2_compatible"] = "unknown"
    
    else:
        info["cgroups_v2_compatible"] = "unknown"

    return info

async def get_java(clusterinfo,namespace,pod,container_names):

    url = clusterinfo["url"]
    token = clusterinfo["token"]

    headers = {
        "Authorization": "Bearer " + token,
        "Connection": "upgrade",
        "Upgrade": "SPDY/4.8",
        "X-Stream-Protocol-Version": "channel.k8s.io",
        "charset": "utf-8"
    }

    java_version_command = "java -XshowSettings:all -version"
    java_version_command_encoded = urllib.parse.quote(java_version_command, safe='')

    selected_container = await select_most_similar_container(pod, container_names)

    # Ejecutar el comando en el pod de destino
    request_url = f'{url}/api/v1/namespaces/{namespace}/pods/{pod}/exec?'
    endpoint = f'command=/bin/bash&command=-c&command={java_version_command_encoded}&container={selected_container}'
    extraoptions = '&stdin=true&stderr=true&stdout=true&tty=false'
    
    full_url = request_url + endpoint + extraoptions

    data = []
    
    logger.debug(f'[INFO] - Getting version of {pod} from {namespace}')
    try:
        ws = websocket.WebSocket(sslopt={"cert_reqs": ssl.CERT_NONE})
        ws.connect(full_url.replace("https", "wss"), header=headers, timeout=5)
        while ws.connected != False:
            recv = ws.recv()
            if recv != '':
                data.append(recv.decode("utf-8"))
    
        # Cerrar la conexión WebSocket con el pod de destino
        ws.close()
    
        javaversion = await analyze_java_output(data)

    except Exception as e:
        logger.error(f'[ERROR] - Error getting Java version: {e}')
        javaversion = {}

    
    return javaversion

async def analyze_node_output(data_lines):
    cleaned = [line.lstrip("\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09") for line in data_lines]
    output = "\n".join(cleaned)

    if "node: command not found" in output.lower() or "command terminated with non-zero exit code" in output.lower():
        return {}

    info = {
        "nodeversion": None,
        "cgroups_v2_compatible": None
    }

    nodeversion = None
    match = re.search(r'^v(\d+\.\d+\.\d+)', output, re.MULTILINE)
    if match:
        nodeversion = match.group(1)

    if nodeversion:
        info["nodeversion"] = nodeversion.strip()
        try:
            v = version.parse(nodeversion)

            if v >= version.parse("20.3.0"):
                info["cgroups_v2_compatible"] = True
            # elif v >= version.parse("16.0.0"):
            #     info["cgroups_v2_compatible"] = "partial"
            else:
                info["cgroups_v2_compatible"] = False
        except Exception:
            info["cgroups_v2_compatible"] = "unknown"
    else:
        info["cgroups_v2_compatible"] = "unknown"
    
    return info

async def get_node(clusterinfo,namespace,pod,container_names):
    url = clusterinfo["url"]
    token = clusterinfo["token"]

    headers = {
        "Authorization": "Bearer " + token,
        "Connection": "upgrade",
        "Upgrade": "SPDY/4.8",
        "X-Stream-Protocol-Version": "channel.k8s.io",
        "charset": "utf-8"
    }

    node_version_command = "node -v"
    node_version_command_encoded = urllib.parse.quote(node_version_command, safe='')

    selected_container = await select_most_similar_container(pod, container_names)

    # Ejecutar el comando en el pod de destino
    request_url = f'{url}/api/v1/namespaces/{namespace}/pods/{pod}/exec?'
    endpoint = f'command=/bin/bash&command=-c&command={node_version_command_encoded}&container={selected_container}'
    extraoptions = '&stdin=true&stderr=true&stdout=true&tty=false'
    
    full_url = request_url + endpoint + extraoptions

    data = []
    
    logger.debug(f'[INFO] - Getting version of {pod} from {namespace}')
    try:
        ws = websocket.WebSocket(sslopt={"cert_reqs": ssl.CERT_NONE})
        ws.connect(full_url.replace("https", "wss"), header=headers, timeout=5)
        while ws.connected != False:
            recv = ws.recv()
            if recv != '':
                data.append(recv.decode("utf-8"))
    
        # Cerrar la conexión WebSocket con el pod de destino
        ws.close()
    
        nodeversion = await analyze_node_output(data)

    except Exception as e:
        logger.error(f'[ERROR] - Error getting Node version: {e}')
        nodeversion = {}
    
    return nodeversion

async def get_python(clusterinfo,namespace,pod,container_names):

    url = clusterinfo["url"]
    token = clusterinfo["token"]

    headers = {
        "Authorization": "Bearer " + token,
        "Connection": "upgrade",
        "Upgrade": "SPDY/4.8",
        "X-Stream-Protocol-Version": "channel.k8s.io",
        "charset": "utf-8"
    }

    python_version_command = "python --version"
    python_version_command_encoded = urllib.parse.quote(python_version_command, safe='')

    selected_container = await select_most_similar_container(pod, container_names)

    # Ejecutar el comando en el pod de destino
    request_url = f'{url}/api/v1/namespaces/{namespace}/pods/{pod}/exec?'
    endpoint = f'command=/bin/bash&command=-c&command={python_version_command_encoded}&container={selected_container}'
    extraoptions = '&stdin=true&stderr=true&stdout=true&tty=false'
    
    full_url = request_url + endpoint + extraoptions

    data = []
    
    logger.debug(f'[INFO] - Getting version of {pod} from {namespace}')
    try:
        ws = websocket.WebSocket(sslopt={"cert_reqs": ssl.CERT_NONE})
        ws.connect(full_url.replace("https", "wss"), header=headers, timeout=5)
        while ws.connected != False:
            recv = ws.recv()
            if recv != '':
                data.append(recv.decode("utf-8"))
    
        # Cerrar la conexión WebSocket con el pod de destino
        ws.close()
    
        pythonversion = None
        for line in data:
            line = line.replace("\x01","").replace("\n","")
            if re.match(r"^Python \d+", line):

                pythonversion = line[7:]
    except Exception as e:
        logger.error(f'[ERROR] - Error getting Python version: {e}')
        pythonversion = None
    
    return pythonversion

async def get_micro_versions(clusterinfo,namespace,microname,microsonline,micro_block,podslist,option):
    
    podtocheck = None
    
    javaversion_dict = {}
    match option:
        case "javaversion":

            java_whitelist = os.getenv("JAVA_WHITELIST")
            whitelist = java_whitelist.split(",")

            #whitelist = ["mongodb", "rabbit", "f-ng-","catprodsan","s-node"]

            logger.debug(f'[DEBUG] - Getting pod to check JavaVersion')
            for pod in podslist:
                pod_name = pod["metadata"]["name"] 
                if microname in pod_name:
                    logger.debug(f'[DEBUG] - pod_name: {pod_name}, microname: {microname}')
                    if micro_block != "Unknown":
                        if not any(p in pod_name for p in whitelist) and "-deploy" not in pod_name and (microname in microsonline or micro_block == "Real"):
                            podtocheck = pod_name
                            container_names = pod["spec"]["containers"]
                            break
                    else:
                        if not any(p in pod_name for p in whitelist) and "-deploy" not in pod_name:
                            podtocheck = pod_name
                            container_names = pod["spec"]["containers"]
                            break           

            logger.debug(f'[DEBUG] - podtocheck is {podtocheck}')
            if podtocheck != None:
                logger.debug(f'[DEBUG] - Checking JavaVersion...')
                
                javaversion_dict = await get_java(clusterinfo,namespace,podtocheck,container_names)
                logger.debug(f'[DEBUG] - javaversion_dict got is {javaversion_dict}')
            else:
                javaversion_dict = {}
                logger.debug(f'[DEBUG] - podtocheck is {podtocheck}, so javaversion is None')
            
           
            if javaversion_dict != {}:
                if javaversion_dict["javaversion"] is None:
                    javaversion_dict.update({"isjava": False})
                else:
                    javaversion_dict.update({"isjava": True})

                logger.debug(f'[DEBUG] - isjava is {javaversion_dict["isjava"]}')
                versionsdict = javaversion_dict
            else:
                versionsdict = {
                    "javaversion": None,
                    "cgroups_v2_compatible": False,
                    "isjava": False
                }


        case "nodeversion":


            whitelist = ["mongodb", "rabbit", "f-ng-","catprodsan", "s-java-","s-py"]

            logger.debug(f'[DEBUG] - Getting pod to check Version')
            for pod in podslist:
                pod_name = pod["metadata"]["name"] 
                if microname in pod_name:
                    logger.debug(f'[DEBUG] - pod_name: {pod_name}, microname: {microname}')
                    if micro_block != "Unknown":
                        if not any(p in pod_name for p in whitelist) and "-deploy" not in pod_name and (microname in microsonline or micro_block == "Real"):
                            podtocheck = pod_name
                            container_names = pod["spec"]["containers"]
                            break
                    else:
                        if not any(p in pod_name for p in whitelist) and "-deploy" not in pod_name:
                            podtocheck = pod_name
                            container_names = pod["spec"]["containers"]
                            break           



            logger.debug(f'[DEBUG] - podtocheck is {podtocheck}')
            if podtocheck != None:
                logger.debug(f'[DEBUG] - Checking Version...')
                versionsdict = await get_node(clusterinfo,namespace,podtocheck,container_names)
                logger.debug(f'[DEBUG] - version got is {versionsdict}')
            else:
                versionsdict = {}
                logger.debug(f'[DEBUG] - podtocheck is {podtocheck}, so version is {versionsdict}')
            
            if versionsdict != {}:
                if versionsdict["nodeversion"] is None:
                    versionsdict.update({"isnode": False})
                else:
                    versionsdict.update({"isnode": True})
            else:
                versionsdict = {
                    "nodeversion": None,
                    "cgroups_v2_compatible": False,
                    "isnode": False
                }

            logger.debug(f'[DEBUG] - version is {versionsdict}')
            
        case "pythonversion":

            whitelist = ["mongodb", "rabbit", "f-ng-","catprodsan", "s-java-","s-node"]

            logger.debug(f'[DEBUG] - Getting pod to check Version')
            for pod in podslist:
                pod_name = pod["metadata"]["name"] 
                if microname in pod_name:
                    logger.debug(f'[DEBUG] - pod_name: {pod_name}, microname: {microname}')
                    if micro_block != "Unknown":
                        if not any(p in pod_name for p in whitelist) and "-deploy" not in pod_name and (microname in microsonline or micro_block == "Real"):
                            podtocheck = pod_name
                            container_names = pod["spec"]["containers"]
                            break
                    else:
                        if not any(p in pod_name for p in whitelist) and "-deploy" not in pod_name:
                            podtocheck = pod_name
                            container_names = pod["spec"]["containers"]
                            break           

            logger.debug(f'[DEBUG] - podtocheck is {podtocheck}')
            if podtocheck != None:
                logger.debug(f'[DEBUG] - Checking Version...')
                version = await get_python(clusterinfo,namespace,podtocheck,container_names)
                logger.debug(f'[DEBUG] - version got is {version}')
            else:
                version = None
                logger.debug(f'[DEBUG] - podtocheck is {podtocheck}, so version is {version}')
            
            logger.debug(f'[DEBUG] - version is {version}')
            
            versionsdict = {
                "technology": "PYTHON",
                "version": version
            }
            
        case _:
            versionsdict = {}
            
            
    logger.debug(f'[DEBUG] - versionsdict is {versionsdict}')
    return versionsdict

async def run_command_on_pod(clusterinfo,namespace,pod,commandtorun):

    url = clusterinfo["url"]
    token = clusterinfo["token"]

    headers = {
        "Authorization": "Bearer " + token,
        "Connection": "upgrade",
        "Upgrade": "SPDY/4.8",
        "X-Stream-Protocol-Version": "channel.k8s.io",
        "charset": "utf-8"
    }

    
    command_encoded = urllib.parse.quote(commandtorun, safe='')

    # Ejecutar el comando en el pod de destino
    request_url = f'{url}/api/v1/namespaces/{namespace}/pods/{pod}/exec?'
    endpoint = f'command=/bin/bash&command=-c&command={command_encoded}'
    extraoptions = '&stdin=true&stderr=true&stdout=true&tty=false'
    
    full_url = request_url + endpoint + extraoptions

    data = []
    
    try:
        ws = websocket.WebSocket(sslopt={"cert_reqs": ssl.CERT_NONE})
        ws.connect(full_url.replace("https", "wss"), header=headers, timeout=5)
        while ws.connected != False:
            recv = ws.recv()
            if recv != '':
                data.append(recv.decode("utf-8"))
    
        # Cerrar la conexión WebSocket con el pod de destino
        ws.close()
    
    except Exception as e:
        logger.info(f'Error running command on pod {pod}: {e}')
        data = []
    
    return data

async def get_darwin_dict(entity_id,microname, darwinversionsdictslist, darwinindexdict,micro_block):

    darwindict = {
        "type": None,
        "technology": None,
        "framework": None,
        "frameworkVersion": None,
        "obsolescenceLight": None
    }

    if entity_id=='spain':
        if microname.endswith("-g") or microname.endswith("-b") or microname.endswith("-green") or microname.endswith("-blue"):
            deploy_name_with_no_block = microname[:microname.rfind("-")]
            try:
                darwinversion = darwinversionsdictslist[darwinindexdict[deploy_name_with_no_block]]
            except Exception as e:
                logger.info(f'Error getting darwinversion of {deploy_name_with_no_block}: {e}')
                darwinversion = {}
            
            if darwinversion != {}:
                #if darwinversion["real"]["deployment"] == microname: ## Arq spain is returning wrongly a dot after the microname.
                if darwinversion["real"]["deployment"] == microname or darwinversion["real"]["deployment"] == microname+".":
                    darwindict = {"type": darwinversion["real"]["type"],
                                "technology": darwinversion["real"]["technology"],
                                "framework": darwinversion["real"]["framework"],
                                "frameworkVersion": darwinversion["real"]["frameworkVersion"],
                                "obsolescenceLight": darwinversion["real"]["obsolescenceLight"]}
                #elif darwinversion["hidden"]["deployment"] == microname: ## Arq spain is returning wrongly a dot after the microname.
                elif darwinversion["hidden"]["deployment"] == microname or darwinversion["hidden"]["deployment"] == microname+".":
                    darwindict = {"type": darwinversion["hidden"]["type"],
                                "technology": darwinversion["hidden"]["technology"],
                                "framework": darwinversion["hidden"]["framework"],
                                "frameworkVersion": darwinversion["hidden"]["frameworkVersion"],
                                "obsolescenceLight": darwinversion["hidden"]["obsolescenceLight"]}
        else:
            deploy_name_with_no_block = microname+"-no-bg-suffix"
            
            try:
                darwinversion = darwinversionsdictslist[darwinindexdict[deploy_name_with_no_block]]
            except Exception as e:
                darwinversion = None
            
            if darwinversion != None:
                if darwinversion["real"]["deployment"] == microname:
                    darwindict = {"type": darwinversion["real"]["type"],
                                "technology": darwinversion["real"]["technology"],
                                "framework": darwinversion["real"]["framework"],
                                "frameworkVersion": darwinversion["real"]["frameworkVersion"],
                                "obsolescenceLight": darwinversion["real"]["obsolescenceLight"]}
                elif darwinversion["hidden"]["deployment"] == microname:
                    darwindict = {"type": darwinversion["hidden"]["type"],
                                "technology": darwinversion["hidden"]["technology"],
                                "framework": darwinversion["hidden"]["framework"],
                                "frameworkVersion": darwinversion["hidden"]["frameworkVersion"],
                                "obsolescenceLight": darwinversion["hidden"]["obsolescenceLight"]}

    return darwindict

async def get_health_check(micro,hcprobe=None):

    match hcprobe:
        case "liveness":
            probekind = "livenessProbe"
        case "readiness":
            probekind = "readinessProbe"

    try:
        probe = micro["spec"]['template']['spec']['containers'][0][probekind]
    except KeyError:
        probe = None
    
    if probe != None:
        if 'httpGet' in probe:
            probe_type = 'httpGet'
            try:
                probe_hc = probe['httpGet']['path']+":"+str(probe['httpGet']['port'])
            except KeyError:
                probe_hc = None
        elif "tcpSocket" in probe:
            probe_type = 'tcpSocket'
            try: 
                probe_hc = str(probe['tcpSocket']['port'])
            except KeyError:
                probe_hc = None
        elif "exec" in probe:
            probe_type = 'exec command'
            try: 
                probe_hc = " ".join(probe['exec']['command'])
            except KeyError:
                probe_hc = None
        else:
            probe_type = 'other'
            probe_hc = "other"

        try:
            probedelay = probe['initialDelaySeconds']
        except KeyError:
            probedelay = None
        
        try:
            probefailure_threshold = probe['failureThreshold']
        except KeyError:
            probefailure_threshold = None

        try:
            probeperiod_seconds = probe['periodSeconds']
        except KeyError:
            probeperiod_seconds = None

        try:
            probetimeout_seconds = probe['timeoutSeconds']
        except KeyError:
            probetimeout_seconds = None

        try:
            probesuccess_threshold = probe['successThreshold']
        except KeyError:
            probesuccess_threshold = None

    else:
        probe_type = None
        probe_hc = None
        probedelay = None
        probefailure_threshold = None
        probeperiod_seconds = None
        probetimeout_seconds = None
        probesuccess_threshold = None

    healthcheck_dict = {
        hcprobe: {
            "type": probe_type,
            "probe": probe_hc,
            "delay": probedelay,
            "failureThreshold": probefailure_threshold,
            "successThreshold": probesuccess_threshold,
            "periodSeconds": probeperiod_seconds,
            "timeoutSeconds": probetimeout_seconds
        }
    }
    return healthcheck_dict

async def get_selectors(micro):
    match micro["kind"]:
        case "Deployment"|"StatefulSet":
            try:
                selectors = micro["spec"]["selector"]["matchLabels"]
            except KeyError:
                selectors = None

        case "DeploymentConfig":
            try:
                selectors = micro["spec"]["selector"]
            except KeyError:
                selectors = None

    return selectors


async def get_labels(micro):
    try:
        labels = micro["metadata"]['labels']
    except KeyError:
        labels = None
    
    return labels

async def get_template_labels(micro):
    try:
        template_labels = micro["spec"]["template"]["metadata"]['labels']
    except KeyError:
        template_labels = None
    
    return template_labels

async def get_env_var(micro):
    newenvdict = {}
    try:
        env = micro["spec"]['template']['spec']['containers'][0]['env']
    except KeyError:
        env = None
    
    if env != None:
        for elem in env:
            try:
                newenvdict[elem["name"]] = elem["value"]
            except KeyError:
                newenvdict[elem["name"]] = None

    return newenvdict

async def get_image(micro):
    try:
        image = micro["spec"]['template']['spec']['containers'][0]['image']
    except KeyError:
        image = None

    imagetag = image[image.rfind(":")+1:]
    imagename = image[image.rfind("/")+1:image.rfind(":")]

    ini = image.find("/")
    end = image.rfind("/")

    if ini == end:
        imageproject = image[:end]
        imageregistry = None
    else:
        imageproject = image[ini+1:end]
        imageregistry = image[:ini]

    imagedict = {
        "registry": imageregistry,
        "project": imageproject,
        "name": imagename,
        "tag": imagetag,
    }

    return imagedict

async def get_resources(micro,resource):
    
    try:
        limit = micro["spec"]['template']['spec']['containers'][0]['resources']['limits'][resource]
    except KeyError:
        limit = None
    try:
        request = micro["spec"]['template']['spec']['containers'][0]['resources']['requests'][resource]
    except KeyError:
        request = None

    resource_configuration = {
        resource: {
            "request": request,
            "limit": limit
        }
    }
    return (resource_configuration)

async def get_nexus_artifact(env):
    artifact_url = []
    has_nexus_artifact = False
    for key,value in env.items():
        if "ARTIFACT" in key:
            try:
                artifact_url.append({key: value})
            except Exception as e:
                logger.info(f'Error getting artifact_url: {e}')
                artifact_url.append({key: "No value"})
            
            has_nexus_artifact = True

    nexusartifactdict = {
        "has_nexus_artifact": has_nexus_artifact,
        "artifacts": artifact_url
    }

    return nexusartifactdict

async def get_bks_token(functional_environment,jwt_token):
    # get the tokenBKS for the user
    logger.debug('[DEBUG]- Getting BKS Token...')
    match functional_environment:
        case "pro":
            url = "https://srvnuarintra.santander.corp.bsch/sts/tokens/bks/personal"
        case "pre":
            url = "https://srvnuarintra.santander.pru.bsch/sts/tokens/bks/personal"
        case "dev":
            url = "https://srvnuarintra.santander.dev.corp/sts/tokens/bks/personal"
    
    headers={
        "credentialType": "TOKEN",
        "Content-Type":APPLICATION_JSON
    }
    
    if jwt_token != False:
        body={
            "token": f"{jwt_token}"
        }
        
        async with aiohttp.ClientSession() as session:
                async with session.post(url, headers=headers,data=json.dumps(body) ,verify_ssl=True,timeout=aiohttp.ClientTimeout(total=15,connect=10)) as r:
                    response = await r.json()
                    if "token" in str(response):
                        logger.debug('[DEBUG]- BKS token response correctly gotten')
                        return response["token"]
                    else:
                        logger.error('[ERROR]- BKS token response not gotten')

    
    return False
            
async def get_jwt_token(functional_environment,uid,passwd):
    
    logger.debug(f'[DEBUG]- Getting JWT Token for uid {uid}')
    # get the token for the user
    match functional_environment:
        case "pro":
            url = "https://srvnuarintra.santander.corp.bsch/sas/authenticate/credentials"
        case "pre":
            url = "https://srvnuarintra.santander.pru.bsch/sas/authenticate/credentials"
        case "dev":
            url = "https://srvnuarintra.santander.dev.corp/sas/authenticate/credentials"

    header = {"Content-type": APPLICATION_JSON}

    body = {
        "credentialType": [
        "JWT"
    ],
        "idAttributes": {
            "uid": uid
        },
        "password": passwd,
        "realm": "CorpIntranet"
    }

    async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=header,data=json.dumps(body) ,verify_ssl=True,timeout=aiohttp.ClientTimeout(total=15,connect=10)) as r:
                response = await r.json()
                if "jwt" in str(response):
                    logger.debug('[DEBUG]- jwt Token was correctly gotten')
                    return response['jwt']
                else:
                    logger.debug('[ERROR]- jwt Token was not gotten')
                    return False

async def check_delete_keys(micro_dict,mongomicroforcomparison):
    deletedkeys = []
    for key in micro_dict.keys():
        if key not in str(mongomicroforcomparison.keys()):
            deletedkeys.append(key)
    
    deletedkeys2 = [key for key in micro_dict.keys() if key not in str(mongomicroforcomparison.keys())]

    return deletedkeys, deletedkeys2

async def update_mongo_data(id,kind,collection,datakey,datavalue,action=None):

    logger.info(f'Changing to mongo collection  {collection} to update info')
    mg.change_collection(collection=collection)

    if action == "unset":
        updated_data = mg.update_one({"$and": [{'id': id},{'kind': kind}]},
                                        {"$unset": {datakey: ""}})
    else:
        if datakey==None:
            updated_data = mg.update_one({"$and": [{'id': id},{'kind': kind}]},
                                        {"$set": datavalue})
        else:
            updated_data = mg.update_one({"$and": [{'id': id},{'kind': kind}]},
                                        {"$set": {datakey: datavalue}})
        
    if updated_data.modified_count == 1:
        logger.info(f'{id} updated')
        mg.update_one({"$and": [{'id': id},{'kind': kind}]}, {"$set": {"timestamp": datetime.now(timezone.utc)}})
        return True
    else:
        logger.info(f'{id} was not updated')
        return False
    
async def compare_lists(openshiftinfo,mongoinfo):
    differences_flag = False
    
    for index,openshiftelem in enumerate(openshiftinfo):
        if openshiftelem != mongoinfo[index]:
            differences_flag = True
    
    return differences_flag

async def compare_info(openshiftvalues,mongovalues):
    
    differences_flag = False

    if isinstance(type(openshiftvalues),list) and isinstance(type(mongovalues),list):
        if len(openshiftvalues) != len(mongovalues):
            differences_flag = True
        else:
            differences_flag = await compare_lists(openshiftvalues,mongovalues)
    
    else:
        #await compareDicts(openshiftvalues,mongovalues)

        if openshiftvalues != None and mongovalues != None:
            if len(openshiftvalues) != len(mongovalues):
                differences_flag = True
            else:
                #ordeno las claves primero.
                openshiftvalueskeyssorted = sorted(openshiftvalues)
                mongovalueskeyssorted = sorted(mongovalues)

                openshiftvaluessorted = {key: openshiftvalues[key] for key in openshiftvalueskeyssorted}
                mongovaluessorted = {key: mongovalues[key] for key in mongovalueskeyssorted}

                for item1,item2 in zip(openshiftvaluessorted,mongovaluessorted):
                    if openshiftvaluessorted[item1] != mongovaluessorted[item2]:
                        differences_flag = True
                        break
        elif openshiftvalues == None and mongovalues == None:
        # mongovalues != None:
            differences_flag = False
        else:
            differences_flag = True
    
    return differences_flag 

async def get_same_unit_resources(resource,data,unit=None):
    
    match resource:
        case "memory":
            mem_req = data["memory"]["request"]
            mem_lim = data["memory"]["limit"]            
                    
            if mem_req != None:
                mem_req_normal = await normalize_units(mem_req)
                request_memory_gigas = float((await get_same_unit(element=mem_req_normal,unit=unit))[:-2]) #El [:-2] es porque lo tengo hardcodeado a Gi
            else:
                request_memory_gigas = None
            
            if mem_lim != None:
                mem_lim_normal = await normalize_units(mem_lim)
                limit_memory_gigas = float((await get_same_unit(element=mem_lim_normal,unit=unit))[:-2])
            else:
                limit_memory_gigas = None

            outputdict = {
                "request_Gi":request_memory_gigas,
                "limit_Gi": limit_memory_gigas
            }
    
        case "cpu":
            cpu_req = data["cpu"]["request"]
            cpu_lim = data["cpu"]["limit"]
            
            if cpu_req != None:
                if cpu_req.endswith("m"): 
                    request_cpu_milicores = int(cpu_req[:-1])
                else:
                    try:
                        request_cpu_milicores = int(cpu_req) * 1000
                    except Exception as e:
                        request_cpu_milicores = 1000
                        logger.error(f'cpu request configured is {cpu_req}. Exception: {e}')
            else:
                request_cpu_milicores = None
            
            if cpu_lim != None:
                if cpu_lim.endswith("m"): 
                    limit_cpu_milicores = int(cpu_lim[:-1])
                else:
                    try:
                        limit_cpu_milicores = int(cpu_lim) * 1000
                    except Exception as e:
                        limit_cpu_milicores = 1000
                        logger.error(f'cpu limit configured is {cpu_lim}. Exception: {e}')
            else:
                limit_cpu_milicores = None

            outputdict = {
                "request_milicores": request_cpu_milicores,
                "limit_milicores": limit_cpu_milicores
            }
            
    return outputdict

async def delete_mongo_micros(cluster, region, namespace,mongomicros,openshiftmicros):

    openshiftmicrosid = [f'{cluster}-{region}-{namespace}-{micro["metadata"]["name"]}-{micro["kind"]}' for micro in openshiftmicros]

    for id in mongomicros:
        if id not in openshiftmicrosid:
            logger.debug(f'Mongo microservice {id} is not on Openshift anymore. Deleting...')
            id_to_delete = id[:id.rfind('-')]
            kind = id[id.rfind('-')+1:]
            mg.delete_one({"$and": [{"id": id_to_delete},{"kind": kind}]})

async def get_info_orchestrator(infotoget,entity_id='spain',services=None,microname=None,microkind=None,namespace=None,clusterinfo=None,micro=None,microsonline=None,micro_block=None,pods=None,darwinobjectlist=None,darwinindexdict=None,hpatargetrefs=None,template_labels=None):

    match infotoget:
        case "javadict":
            outputdict = await get_micro_versions(clusterinfo,namespace,microname,microsonline,micro_block,pods,option="javaversion")
        case "nodedict":
            outputdict = await get_micro_versions(clusterinfo,namespace,microname,microsonline,micro_block,pods,option="nodeversion")            
        case "pythondict":
            outputdict = await get_micro_versions(clusterinfo,namespace,microname,microsonline,micro_block,pods,option="pythonversion")                        
        case "darwin_dict":
            outputdict = await get_darwin_dict(entity_id,microname,darwinobjectlist,darwinindexdict,micro_block)
        case "labels":
            outputdict = await get_labels(micro)
        case "templatelabels":
            outputdict = await get_template_labels(micro)            
        case "selectors":
            outputdict = await get_selectors(micro)            
        case "environment_variables":
            outputdict = await get_env_var(micro)
        case "healthchecks":
            hc_liveness = await get_health_check(micro,hcprobe="liveness")
            hc_readiness = await get_health_check(micro,hcprobe="readiness")
            outputdict = {}
            outputdict.update(hc_readiness)
            outputdict.update(hc_liveness)
        case "image":
            outputdict = await get_image(micro)
        case "resources":
            sameunit = os.getenv("SAME_UNIT_MEM_RESOURCE")
            memoryresources = await get_resources(micro,"memory")
            cpuresources = await get_resources(micro,"cpu")
           
            memoryresources["memory"].update(await get_same_unit_resources(resource="memory",data=memoryresources,unit=sameunit))
            cpuresources["cpu"].update(await get_same_unit_resources(resource="cpu",data=cpuresources))

            outputdict = {}
            outputdict.update(memoryresources)
            outputdict.update(cpuresources)
        case "nexusartifact":
            environment_variables = await get_env_var(micro)
            outputdict = await get_nexus_artifact(environment_variables)
        case "replicas_status":
            desiredreplicas = micro["spec"]["replicas"]
            try:
                actualreplicas = micro["status"]["readyReplicas"]
            except KeyError:
                podsformicro = []
                for pod in pods:
                    try:
                        reference_name = pod["metadata"]["ownerReferences"][0]["name"]
                    except KeyError:
                        reference_name = None
                    
                    try:
                        reference_kind = pod["metadata"]["ownerReferences"][0]["kind"]
                    except KeyError:
                        reference_kind = None

                    if reference_name != None and (microname == reference_name[:reference_name.rfind('-')] and "-deploy" not in pod["metadata"]["name"]):
                        if (micro["kind"] == "Deployment" and reference_kind == "ReplicaSet") or (micro["kind"] == "DeploymentConfig" and reference_kind == "ReplicationController") or micro["kind"] == "StatefulSet" and reference_kind == "StatefulSet":
                            podsformicro.append(pod)
                
                actualreplicas = len(podsformicro)

            outputdict = {
                "desiredreplicas": desiredreplicas,
                "actualreplicas": actualreplicas,         
            }

        case "services_routing_to":

            serviceroutingtolist = []

            for svc in services:
                servicename = svc["metadata"]["name"]
                selectors = svc.get("spec", {}).get("selector")

                if selectors and any(template_labels.get(k) == v for k, v in selectors.items()):
                    serviceroutingtolist.append(servicename)
            
            outputdict = {
                "servicesroutingto": list(set(serviceroutingtolist))
            }
        case "hpa":
            hpaflag = False
            for elem in hpatargetrefs:
                if elem["targetkind"] == microkind and elem["targetname"] == microname:   
                    hpaflag = True
                    break
            
            outputdict= {
                "hpaexists": hpaflag
            }

        case "configmap":
            environment_variables = await get_env_var(micro)
            configmap_flag = False
            try:
                config_enabled = environment_variables["SPRING_CLOUD_CONFIG_ENABLED"]
            except KeyError:
                config_enabled = "Unknown"
            
            try:
                configmaplocation = environment_variables["SPRING_CONFIG_ADDITIONAL_LOCATION"]
            except KeyError:
                configmaplocation = "Unknown"

            if config_enabled.lower() == "false" and configmaplocation != "Unknown":
                configmap_flag = True

            outputdict = {
                "useconfigmap": configmap_flag
            }

        case "logtraces":
            environment_variables = await get_env_var(micro)
            tracestypelist = ["FATAL","ERROR","WARN","INFO","DEBUG","TRACE","ALL"]
            logging_name_list = ["ROOT_LOG","TECH_LOG","PACKAGES_LOG","LOG_LEVEL","DARWIN_LOGGING_LOG_LEVEL_ROOT","LOGGING_LEVEL_ORG_SPRINGFRAMEWORK_CLOUD_CONFIG","GRAVITY_LOG","LOGGING_LEVEL_ROOT","DARWIN_LOGGING_LOGLEVEL_ROOT","DARWIN_LOGGING_LOGLEVEL_PRODUCT","MONGO_LOGGING_LOGLEVEL","DARWIN_LOG_ROOT","DARWIN_LOG_PACKAGE","DARWIN_LOG_HOST","LOG_LEVEL","WEBCLIENT_LOG","MONGO_LOG","CACHE_LOG","RISK_WEBCLIENT_LOG","LOGGER_LEVEL","LOGGING_LEVEL_GATEWAYAPPLICATION"]
            logtraceslist = []
            has_bad_performance_traces = False
            for key,value in environment_variables.items():
                if "log" in key.lower():
                    try:
                        if value.upper() in tracestypelist:
                            logtraceslist.append({key: value})
                    except AttributeError:
                        if key.upper() in logging_name_list:
                            logtraceslist.append({key: "No value"})
                    
            if "DEBUG" in str(logtraceslist) or "TRACE" in str(logtraceslist):
                has_bad_performance_traces = True

            outputdict = {
                "has_bad_performance_traces": has_bad_performance_traces,
                "logtraces": logtraceslist
            }

        case _:
            outputdict = {}

    return outputdict