from shuttlelib.utils.logger import logger
import time
import aiohttp
import shuttlelib.db.mongo as mongolib
import aiohttp
import os
from src.services.commonfunctions import get_bks_token, get_jwt_token,get_namespace_objects, get_micros_online, update_mongo_data, compare_info, get_info_orchestrator, get_full_darwin_info, confirm_real_hidden_block, get_services_selector, delete_mongo_micros, check_mismatched_variables, get_wrong_routing,get_paused_rollouts,save_data_into_database,delete_nonexisting_namespaces
from src.services.client import client

mg = mongolib.MongoClient()

async def get_info_microservices(entity_id="spain",functional_environment="pro",clusterparam=None,regionparam=None,namespaceslist=None):
    t1 = time.time()

    openshift_namespacesid = set()

    #if entity_id != "spain":
        #client.change_entity(entity_id=entity_id)

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)
    
    clusterslist = await get_clusters_list(clusterparam, clusters)

    for cluster in clusterslist:
        await process_cluster(cluster, entity_id, functional_environment, regionparam, namespaceslist, openshift_namespacesid, clusters)

    await delete_nonexisting_namespaces(openshift_namespacesid,clusterparam,regionparam,namespaceslist)
   
    t2 = time.time()
    total_time = t2-t1

    logger.info(f'Total time: {total_time}')

async def process_cluster(cluster, entity_id, functional_environment, regionparam, namespaceslist, openshift_namespacesid, clusters):
    logger.info(f'Getting info of cluster {cluster}')

    janssen_entities = os.getenv("JANSSEN_ENTITIES").split(",")

    if entity_id in janssen_entities:
        user=(os.getenv("USERSHUTTLE"))
        passwd=(os.getenv("USERSHUTTLEPASSWD"))
        jwttoken = await get_jwt_token(functional_environment,user,passwd)
        bkstoken = await get_bks_token(functional_environment,jwttoken)        
    else:
        jwttoken = ""
        bkstoken = ""
    regionlist = await get_regions_list(regionparam, clusters, cluster)

    for region in regionlist:
        await process_region(region, cluster, functional_environment, namespaceslist, openshift_namespacesid, bkstoken, entity_id, clusters)

async def process_region(region, cluster, functional_environment, namespaceslist, openshift_namespacesid, bkstoken, entity_id, clusters):
    logger.info(f'Getting info of region {region}')

    namespaces = await get_namespaces(functional_environment, cluster, region)

    if namespaces != []:
        namespacesdictlist = namespaces[region]["items"]
    else:
        namespacesdictlist = []

    if namespaceslist != None:
        namespacesdictlist = [namespacedict for namespacedict in namespacesdictlist if namespacedict["metadata"]["name"] in namespaceslist]
    
    for namespacedict in namespacesdictlist:
        await process_namespace(namespacedict, cluster, region, functional_environment, openshift_namespacesid, bkstoken, entity_id, clusters)

async def process_namespace(namespacedict, cluster, region, functional_environment, openshift_namespacesid, bkstoken, entity_id, clusters):
    namespace = namespacedict["metadata"]["name"]

    if namespace.startswith("sanes-zzz") or namespace.startswith("sanes-autoz"):
        return

    namespaceid = cluster+"-"+region+"-"+namespace
    openshift_namespacesid.add(namespaceid) #For comparing to mongo info and drop mongo object if project doesn't exist anymore
    logger.info(f'[INFO] - Getting info of {namespaceid}')

    namespaceinfo = {
        "cluster": cluster,
        "region": region,
        "namespace": namespace,
        "namespaceid": namespaceid,
    }

    services = await get_namespace_objects(functional_environment,cluster,region,namespace,resource="services")
    servicesselectors = await get_services_selector(services)
    if functional_environment == "pro":
        microsonline, microsoffline = await get_micros_online(entity_id,services)
    else:
        microsonline = []
        microsoffline = []

    janssen_entities = os.getenv("JANSSEN_ENTITIES").split(",")

    darwinversionsdictslist = []
    darwinindexdict = {}

    if entity_id in janssen_entities:
        darwinversionsdictslist, darwinindexdict = await get_full_darwin_info(entity_id,functional_environment,bkstoken,namespace,cluster,region)

    hpas = await get_namespace_objects(functional_environment,cluster,region,namespace,"hpas")
    
    #get HPA targetrefs
    try:
        hpatargetrefs = [{"targetkind": hpa["spec"]["scaleTargetRef"]["kind"], "targetname": hpa["spec"]["scaleTargetRef"]["name"]} for hpa in hpas]
    except KeyError as e:
        logger.error(f'Error getting hpatargetrefs: {e}')
        hpatargetrefs = []
    #     #hpatargetmicroname = []

    microslist = await get_micros_list(functional_environment,cluster,region,namespace)
    podslist = await get_namespace_objects(functional_environment,cluster,region,namespace,"pods")

    mongo_microsid_list = await get_mongo_micros(namespaceid)
    await delete_mongo_micros(cluster,region,namespace,mongo_microsid_list,microslist)

    for micro in microslist:
        await process_micro(micro, cluster, region, namespace, podslist, services, servicesselectors, microsonline, microsoffline, darwinversionsdictslist, darwinindexdict, hpatargetrefs, namespaceinfo, mongo_microsid_list, clusters,namespaceid)

async def process_micro(micro, cluster, region, namespace, podslist, services, servicesselectors, microsonline, microsoffline, darwinversionsdictslist, darwinindexdict, hpatargetrefs, namespaceinfo, mongo_microsid_list, clusters,namespaceid):
    entity_id = os.getenv("ENTITY_ID")
    janssen_entities = os.getenv("JANSSEN_ENTITIES").split(",")
    
    micro_name = micro["metadata"]["name"]
    micro_id = cluster+"-"+region+"-"+namespace+"-"+micro_name
    micro_kind = micro["kind"]
    cluster_url_token = clusters[cluster][region]

    if entity_id in janssen_entities:
        darwin_dict = await get_info_orchestrator(microname=micro_name,darwinobjectlist=darwinversionsdictslist,darwinindexdict=darwinindexdict,infotoget="darwin_dict")
    else: 
        darwin_dict = {
            "type": None,
            "technology": None,
            "framework": None,
            "frameworkVersion": None,
            "obsolescenceLight": None
        }

    micro_status = await confirm_real_hidden_block(micro_name,podslist,microsonline,microsoffline,cluster,servicesselectors)

    java_dict = {"javaversion": None, "isjava": False}
    darwintechnology = darwin_dict["technology"]
    technology_dict = {}
    logger.debug(f'[DEBUG] - Getting technology version for {micro_id}...')
    match darwintechnology:
        
        case "JAVA"|"FRONTLOGGER"|"DATAGRID"|"GATEWAY"|"CONFIG_SERVICE"|"ZUUL":
            java_dict = await get_info_orchestrator(clusterinfo=cluster_url_token,namespace=namespace,microname=micro_name,microsonline=microsonline,micro_block=micro_status["block"],pods=podslist,infotoget="javadict")
            #javadict = getVersions(clusterinfo,micro,microsonline,microsoffline,pods,productionBlock,option="javaversion")
            technology_dict = {"technology": "JAVA", "version": java_dict["javaversion"],"cgroups_v2_compatible": java_dict["cgroups_v2_compatible"]}
        case "NODE":
            node_dict = await get_info_orchestrator(clusterinfo=cluster_url_token,namespace=namespace,microname=micro_name,microsonline=microsonline,micro_block=micro_status["block"],pods=podslist,infotoget="nodedict")
            #getVersions(clusterinfo,micro,microsonline,microsoffline,pods,productionBlock,option="nodeversion")
            technology_dict = {"technology": "NODE", "version": node_dict["nodeversion"],"cgroups_v2_compatible":node_dict["cgroups_v2_compatible"]}
        case "PYTHON":
            #technology_dict = getVersions(clusterinfo,micro,microsonline,microsoffline,pods,productionBlock,option="pythonversion")
            technology_dict = await get_info_orchestrator(clusterinfo=cluster_url_token,namespace=namespace,microname=micro_name,microsonline=microsonline,micro_block=micro_status["block"],pods=podslist,infotoget="pythondict")
        case "ANGULAR":
            technology_dict = {"technology": darwin_dict["technology"], "version": darwin_dict["frameworkVersion"]}
        case _:
            java_dict = await get_info_orchestrator(clusterinfo=cluster_url_token,namespace=namespace,microname=micro_name,microsonline=microsonline,micro_block=micro_status["block"],pods=podslist,infotoget="javadict")
            #javadict = getVersions(clusterinfo,micro,microsonline,microsoffline,pods,productionBlock,option="javaversion")
            if java_dict["javaversion"] != None:
                technology_dict = {"technology": "JAVA", "version": java_dict["javaversion"],"cgroups_v2_compatible":java_dict["cgroups_v2_compatible"]}
            if technology_dict == {} or technology_dict["version"] is None:
                node_dict = await get_info_orchestrator(clusterinfo=cluster_url_token,namespace=namespace,microname=micro_name,microsonline=microsonline,micro_block=micro_status["block"],pods=podslist,infotoget="nodedict")
                #nodedict = getVersions(clusterinfo,micro,microsonline,microsoffline,pods,productionBlock,option="nodeversion")
                if node_dict["nodeversion"] != None:
                    technology_dict = {"technology": "NODE", "version": node_dict["nodeversion"],"cgroups_v2_compatible":node_dict["cgroups_v2_compatible"]}
            if technology_dict == {} or technology_dict["version"] is None:
                technology_dict = await get_info_orchestrator(clusterinfo=cluster_url_token,namespace=namespace,microname=micro_name,microsonline=microsonline,micro_block=micro_status["block"],pods=podslist,infotoget="pythondict")
                #getVersions(clusterinfo,micro,microsonline,microsoffline,pods,productionBlock,option="pythonversion")
            if technology_dict == {} or technology_dict["version"] is None:
                technology_dict = {
                    "technology": None,
                    "version": None
                }
            
    logger.debug(f'[DEBUG] - Technology version fuera del match case: {technology_dict["version"]}')



    template_labels = await get_info_orchestrator(micro=micro,infotoget="templatelabels")
    labels = await get_info_orchestrator(micro=micro,infotoget="labels")
    selectors = await get_info_orchestrator(micro=micro,infotoget="selectors")
    environment_variables = await get_info_orchestrator(micro=micro,infotoget="environment_variables")
    health_checks = await get_info_orchestrator(micro=micro,infotoget="healthchecks")
    imagedict = await get_info_orchestrator(micro=micro,infotoget="image")
    resources = await get_info_orchestrator(micro=micro,infotoget="resources")
    nexus_artifact = await get_info_orchestrator(micro=micro,infotoget="nexusartifact")
    replicas_status_dict = await get_info_orchestrator(microname=micro_name,micro=micro,pods=podslist,infotoget="replicas_status")
    services_routing_to_dict = await get_info_orchestrator(template_labels=template_labels,services=services,infotoget="services_routing_to")
    hashpa = await get_info_orchestrator(microname=micro_name,microkind=micro_kind,hpatargetrefs=hpatargetrefs,infotoget="hpa")
    hasconfigmap = await get_info_orchestrator(microname=micro_name,micro=micro,infotoget="configmap")
    env_logtraces = await get_info_orchestrator(microname=micro_name,micro=micro,infotoget="logtraces")
    mismatched_variables = await check_mismatched_variables(micro_name,environment_variables)
    wrong_routing = await get_wrong_routing(hasconfigmap,micro_status,micro,namespaceid)
    pausedrollouts = await get_paused_rollouts(micro)
    gluon_labels = os.getenv("GLUON_LABELS").split(",")
    #gluon_labels = ["santander.com/","helm.sh"]
    if labels is not None and all(label in str(labels) for label in gluon_labels):
        isgluon = True
    else:
        isgluon = False

    micro_dict = {
        "name": micro_name,
        "kind": micro_kind,
        "labels": labels,
        "template_labels": template_labels,
        "selectors": selectors,
        "envVar": environment_variables,
        "healthchecks": health_checks,
        "image": imagedict,
        "resources": resources,
        "javadict": java_dict,
        "technology_dict": technology_dict,
        "darwin_dict": darwin_dict,
        "artifactdict": nexus_artifact,
        "replicas": replicas_status_dict,
        "micro_status": micro_status,
        "env_logtraces": env_logtraces,
        "mismatchedVariables": mismatched_variables,
        "wrongRouting": wrong_routing,
        "pausedrollouts": pausedrollouts,
        "isgluon": isgluon
    }

    micro_dict.update(services_routing_to_dict)
    micro_dict.update(hashpa)
    micro_dict.update(hasconfigmap)
        
    micro_dict.update(namespaceinfo)
    micro_dict.update({"id":micro_id})

    await save_data_into_database(micro_dict,micro_id,micro_name,micro_kind,mongo_microsid_list)

async def get_clusters_list(clusterparam, clusters):
    if clusterparam != None:
        clusterslist = [clusterparam]
    else:
        clusterslist = list(clusters.keys())
    return clusterslist

async def get_regions_list(regionparam, clusters, cluster):
    if regionparam != None:
        regionlist = [regionparam]
    else:
        regionlist = list(clusters[cluster].keys())
    return regionlist

async def get_namespaces(functional_environment, cluster, region):
    try:
        namespaces = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
        namespaces_error = False
        if namespaces[region] == 401:
            namespaces_error = True
    except aiohttp.client_exceptions.ServerTimeoutError:
        logger.error(f"Timeout detected against {functional_environment+cluster+region} ")
        namespaces_error = True
    except Exception as e:
        logger.error(f"An error ocurred getting namespaces: {e}")
        namespaces_error = True
    
    if namespaces_error:
        namespaces = []
    
    return namespaces


async def get_micros_list(functional_environment,cluster,region,namespace):
    deployments = await get_namespace_objects(functional_environment,cluster,region,namespace,"deployments")
    deploymentconfigs = await get_namespace_objects(functional_environment,cluster,region,namespace,"deploymentconfigs")
    statefulsets = await get_namespace_objects(functional_environment,cluster,region,namespace,"statefulsets")

    for item in deployments:
        item["kind"] = "Deployment"
    
    for item in deploymentconfigs:
        item["kind"] = "DeploymentConfig"

    for item in statefulsets:
        item["kind"] = "StatefulSet"

    microslist = deployments + deploymentconfigs + statefulsets

    return microslist

async def get_mongo_micros(namespaceid):
    mongocollection = os.getenv("COLLECTION")
    mg.change_collection(collection=mongocollection)
    mongo_micros = mg.find({"namespaceid": namespaceid})
            
    mongo_microsid_list = [f'{mongo_micro["id"]}-{mongo_micro["kind"]}' for mongo_micro in mongo_micros]

    return mongo_microsid_list