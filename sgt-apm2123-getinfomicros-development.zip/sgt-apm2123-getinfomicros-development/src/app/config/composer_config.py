from version import __version__
from ..config import global_config

description = '''##GET MICROSERVICES INFO

### SUMMARY
Microservice for getting microservices info and save it in mongoDB:
- micros info:
    - java versions
    - darwin versions
    - image
    - environment variables
    - health checks
    - resource configuration
    - labels
    - hpa
    - replicas
    - microservice status


### ENDPOINTS
* **/extractinfo/microservices:** get all the info from every cluster and namespace


### PARAMETERS
For getting the info:
* **functional_environment**: dev, pre, pro

For updating the info:
For getting or updating the info:
* **entity_id**: spain, xxxxxx
* **functional_environment**: dev, pre, pro
* **cluster (optional)**: ohe (only for dev & pre), bks (only for dev & pre), probks, dmzbbks, dmzbazure, azure, prodarwin, dmzbdarwin, confluent
* **region (optional)**: bo1, bo2, weu1, weu2
* **namespacesList (optional)**: list of namespaces to get and update microservices info (it should be on the selected cluster)

### REPO 
* [sgt-apm2123-getinfomicros](https://github.com/santander-group-sds-gln/sgt-apm2123-getinfomicros#)
'''

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "Get info micros",
          "description": description,
          "contact": {
               "name": "Carlos Murcia",
               "url": "myurl"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
