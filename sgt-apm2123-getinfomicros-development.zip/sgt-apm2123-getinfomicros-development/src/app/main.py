from fastapi import FastAPI,responses
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers
from src.app.config.composer_config import config as composer_config

app = FastAPI(
                docs_url="/api/v1/docs",
                title="sgt-apm2123-getinfomicros",
                version="1.0",
                openapi_url="/api/v1/openapi.json",
                contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"},
              )

DarwinComposer(app, config=composer_config, routers=routers)
