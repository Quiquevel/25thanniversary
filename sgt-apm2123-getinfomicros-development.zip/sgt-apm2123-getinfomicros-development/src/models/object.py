

from pydantic import BaseModel
from typing import Optional, List

class ObjectsModel(BaseModel):
    entity_id: str
    functional_environment: str
    cluster: Optional[str] = None
    region: Optional[str] = None
    namespaceslist: Optional[List[str]] = None

class HiddenBlockModel(BaseModel):
    cluster: Optional[str] = None
    region: Optional[str] = None
    namespaceslist: Optional[List[str]] = None