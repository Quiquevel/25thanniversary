from shuttlelib.utils.logger import logger
from fastapi import APIRouter, responses
from src.services.extractinfo import get_info_microservices
from src.services.hidden_block import check_technology_other_block, check_javadict_other_block
import urllib3
from starlette.middleware.cors import CORSMiddleware as CORSMiddleware
from src.models.object import ObjectsModel, HiddenBlockModel

urllib3.disable_warnings()

extracting = APIRouter(tags=["v1"],prefix="/api/v1/getinfo")

@extracting.post("/microservices", tags=["v1"], description="GET MICROSERVICES DATA AND SAVE IT IN SRE_MICROSERVICES MONGO COLLECTION", response_description="JSON", status_code=200)
async def extractinfo(target: ObjectsModel):

    #TODO
    # Validate input data
    return await get_info_microservices(entity_id=target.entity_id,functional_environment=target.functional_environment,clusterparam=target.cluster,regionparam=target.region,namespaceslist=target.namespaceslist)

@extracting.post("/update_hidden_block", tags=["v1"], description="GET MICROSERVICES DATA AND SAVE IT IN SRE_MICROSERVICES MONGO COLLECTION", response_description="JSON", status_code=200)
async def extractinfo_hidden_block(target: HiddenBlockModel):

    #TODO
    # Validate input data
    logger.debug(f"[DEBUG] - Checking technology other block")
    await check_technology_other_block(cluster=target.cluster,region=target.region,namespaceslist=target.namespaceslist)
    logger.debug(f"[DEBUG] - Checking java other block")
    await check_javadict_other_block(cluster=target.cluster,region=target.region,namespaceslist=target.namespaceslist)
