from src.app.config.composer_config import config
from fastapi import FastAPI
from darwin_composer.DarwinComposer import DarwinComposer
from src.resources.routers import routers

description = """
##MICRO FOR CALCULATE PERCENTAGES AND SAVE THEM IN TECHNICAL DEBT MONGO COLLECTION

### SUMMARY
Microservice for getting info from mongoDB and show it on a Dashboard:

### ENDPOINTS

* **/refreshdata:** update percentages for domain

### PARAMETERS
* **functionalEnvironment**: dev, pro
* **domainlist**: list of domains to update


### REPO 
* [sgt-apm2123-techdebtwriter](https://github.com/santander-group-sds-gln/sgt-apm2123-techdebtwriter)
"""

app = FastAPI(
                docs_url="/api/v1/docs",
                title="sgt-apm2123-techdebtwriter",
                description = description,
                version="1.0",
                openapi_url="/api/v1/openapi.json",
                contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"},
              )

DarwinComposer(app, config=config, routers=routers)
