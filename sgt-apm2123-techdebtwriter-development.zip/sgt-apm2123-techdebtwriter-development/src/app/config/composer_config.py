from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "Some App",
          "description": "It does some cool stuff",
          "contact": {
               "name": "myName",
               "url": "myurl"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
