import os
from shuttlelib.utils.logger import logger
from packaging.version import Version, parse

async def getNodeVersion(micro,min_versions):

    try:
        nodeversion = micro["technology_dict"]["version"]
    except KeyError:
        nodeversion = None
    
    NODE_MIN_VERSION = min_versions["Node"]

    min_version_for_scoring = parse(NODE_MIN_VERSION)

    if nodeversion != None:
        
        if parse(nodeversion) < min_version_for_scoring:
            nodeversion_status = "ko"
        else:
            nodeversion_status = "ok"
        
    else:
        nodeversion_status = "ok"

    return nodeversion_status


async def getNodeVersionCompliance(nodeversionlist,microsnode,ponderation,sumtotalvalues):

    NODE_OK = float(os.getenv("NODE_OK_SCORE"))
    NODE_KO = float(os.getenv("NODE_KO_SCORE"))

    node_version_ok = nodeversionlist.count("ok")
    node_version_ko = nodeversionlist.count("ko")

    nodeversionsum = node_version_ok*NODE_OK + node_version_ko*NODE_KO

    totcompliance = round((nodeversionsum)/microsnode*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict