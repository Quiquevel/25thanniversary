import os

async def getArtifactsCompliance(list,nummicros,ponderation,sumtotalvalues):
    
    set = list.count(True)
    totcompliance = round((nummicros - set)/nummicros*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict

async def getDeploymentsCompliance(list,nummicros,ponderation,sumtotalvalues):
    
    set = list.count("DeploymentConfig") #Lo que no es deploymentconfig debe ser Deployment...
    totcompliance = round((nummicros - set)/nummicros*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict

async def get_hc_compliance(hc_list,nummicros,ponderation,sumtotalvalues):
    
    hc_ok = hc_list.count(1)
    hc_set = hc_list.count(0.5)
    hc_ko = hc_list.count(0)

    hc_sum = hc_ko*0 + hc_set*0.5 + hc_ok*1

    totcompliance = round((hc_sum)/nummicros*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict

async def getCompliance(list,nummicros,ponderation,sumtotalvalues):
    
    noset = list.count(None)
    set_to_0 = list.count(0)
    totcompliance = round((nummicros - noset - set_to_0)/nummicros*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict

async def getQuotasCompliance(quota,metric, threshold, ponderation, totalponderation):
    
    try:
        quota = quota[metric]
    except KeyError:
        quota = None
    
    if quota == None or quota > threshold:
        totquotacompliance = 0
    else:
        totquotacompliance = 100

    relquotacompliance = round((ponderation/totalponderation)*totquotacompliance,2)
    relnotrounded = (ponderation/totalponderation)*totquotacompliance
    compliancedict = {"total": totquotacompliance, "relative": relquotacompliance, "relnotrounded": relnotrounded}    

    return compliancedict

async def getHPACompliance(hpaslist,nummicros,ponderation,sumtotalvalues):
    
    hpa_ok = hpaslist.count(1)
    hpa_set = hpaslist.count(0.5)
    hpa_ko = hpaslist.count(0)

    hpa_sum = hpa_ko*0 + hpa_set*0.5 + hpa_ok*1

    totcompliance = round((hpa_sum)/nummicros*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict

async def getJavasCompliance(list,microsjava, ponderation, sumtotalvalues):
    
    settofalse = list.count(False)
    totcompliance = round((microsjava - settofalse)/microsjava*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict

async def getJavaVersionCompliance(javaversionlist,microsjava,ponderation,sumtotalvalues):

    JAVASCORE_KO = float(os.getenv("JAVASCORE_KO"))
    JAVASCORE_OK_KO = float(os.getenv("JAVASCORE_OK_KO"))
    JAVASCORE_OK = float(os.getenv("JAVASCORE_OK"))

    javaversion_ok = javaversionlist.count("KO")
    javaversion_ok_ko = javaversionlist.count("OK_KO")
    javaversion_ko = javaversionlist.count("OK")

    javaversionsum = javaversion_ok*JAVASCORE_KO + javaversion_ok_ko*JAVASCORE_OK_KO + javaversion_ko*JAVASCORE_OK

    totcompliance = round((javaversionsum)/microsjava*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict

async def getLogTracesCompliance(logtraceslist,micros,ponderation,sumtotalvalues):

    GOOD_LOGLEVEL = float(os.getenv("GOOD_LOGLEVEL"))
    MEDIUMHIGH_LOGLEVEL = float(os.getenv("MEDIUMHIGH_LOGLEVEL"))
    MEDIUMLOW_LOGLEVEL = float(os.getenv("MEDIUMLOW_LOGLEVEL"))
    BAD_LOGLEVEL = float(os.getenv("BAD_LOGLEVEL"))

    goodtracelevel = logtraceslist.count(GOOD_LOGLEVEL)
    mediumhightracelevel = logtraceslist.count(MEDIUMHIGH_LOGLEVEL)
    mediumlowtracelevel = logtraceslist.count(MEDIUMLOW_LOGLEVEL)
    badtracelevel = logtraceslist.count(BAD_LOGLEVEL)
    
    logtracessum = goodtracelevel*GOOD_LOGLEVEL + mediumhightracelevel*MEDIUMHIGH_LOGLEVEL + mediumlowtracelevel*MEDIUMLOW_LOGLEVEL + badtracelevel*BAD_LOGLEVEL

    totcompliance = round((logtracessum)/micros*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict

async def getCgroupsv2CompatibilityCompliance(cgroupscompatibilitylist,micros,ponderation,sumtotalvalues):

    nocompatible = cgroupscompatibilitylist.count(False)
    noaply = cgroupscompatibilitylist.count(None)
    totcompliance = round((micros - nocompatible - noaply)/(micros - noaply)*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict

async def getDarwinVersionCompliance(darwinversionlist,microsdarwin,ponderation,sumtotalvalues):
    
    DARWINREDSCORE = float(os.getenv("DARWINREDSCORE"))
    DARWINYELLOWSCORE = float(os.getenv("DARWINYELLOWSCORE"))
    DARWINGREENSCORE = float(os.getenv("DARWINGREENSCORE"))

    darwinRED = darwinversionlist.count(DARWINREDSCORE)
    darwinYELLOW = darwinversionlist.count(DARWINYELLOWSCORE)
    darwinGREEN = darwinversionlist.count(DARWINGREENSCORE)

    darwinversionsum = darwinRED*DARWINREDSCORE + darwinYELLOW*DARWINYELLOWSCORE + darwinGREEN*DARWINGREENSCORE

    try:
        totcompliance = round((darwinversionsum)/microsdarwin*100,2)
        relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
        relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    except:
        totcompliance = 0.0
        relcompliance = 0.0
        relnotrounded = 0.0
    
    
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict
