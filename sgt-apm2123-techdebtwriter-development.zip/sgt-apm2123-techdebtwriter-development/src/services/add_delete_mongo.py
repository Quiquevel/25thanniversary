from datetime import datetime
from shuttlelib.utils.logger import logger
import shuttlelib.db.mongo as mongolib
import os

mg = mongolib.MongoClient() 

async def checkNamespacesInMongo(namespacesdomainmongo,namespacesknowledge,namespacesactives,domain):

    for namespace in namespacesdomainmongo:
        if namespace["namespace"] not in namespacesknowledge:
            logger.debug(f'Namespace {namespace["namespace"]} was sometime saved in mongo {os.getenv("COLLECTION_PERCENTAGES")} for domain {domain} but it\'s not in it anymore. Deleting...')
            mg.delete_one({"id": f'{namespace["id"]}', "domain": domain})
            logger.info(f'Namespace {namespace["id"]} deleted from {os.getenv("COLLECTION_PERCENTAGES")} collection for domain {domain}')
        
        elif namespace["id"] not in namespacesactives:
            logger.debug(f'Namespace {namespace["id"]} was sometime saved in mongo {os.getenv("COLLECTION_PERCENTAGES")} for domain {domain} but it doesn\t exist anymore in this cluster. Deleting...')
            mg.delete_one({"id": f'{namespace["id"]}', "domain": domain})
            logger.info(f'Namespace {namespace["id"]} deleted from {os.getenv("COLLECTION_PERCENTAGES")}')

async def savePercentages(namespacedict):
    logger.info(f'Changing collection to {os.getenv("COLLECTION_PERCENTAGES")}')        
    mg.change_collection(os.getenv("COLLECTION_PERCENTAGES"))  

    mongodict = mg.find_one({"id": namespacedict["id"]})

    if mongodict != None:
        outputdict = await checkChangesAndUpdate(mongodict, namespacedict)
    else:
        logger.info(f'Saving percentages of {namespacedict["id"]} to mongo collection {mg._collection.name}')
        mg.add_data(namespacedict)
        outputdict = {
                        "namespace": namespacedict["id"],
                        "statusMongo": "Added"
                    }

    return outputdict

async def comparedict1dict2(dictopenshift,dictmongo):
    newdict = {}
    for item1,item2 in zip(dictopenshift,dictmongo):
        if dictopenshift[item1] != dictmongo[item2]:
            newdict[item1] = dictopenshift[item1]
    
    return newdict

async def checkChangesAndUpdate(mongodict,namespacedict):
    logger.info(f'Changing collection to {os.getenv("COLLECTION_PERCENTAGES")}')        
    mg.change_collection(os.getenv("COLLECTION_PERCENTAGES"))  
    newdict = {}
    for key,value in namespacedict.items():
        if namespacedict[key] != mongodict[key]:
            newdict[key] = value
            logger.debug(f'Changes detected in {key} for namespace {namespacedict["namespace"]}')

    projectsupdated = {}
    
    logger.debug(f'Updating changes in mongo')
    for key,value in newdict.items():
        if key == "domain":
            logger.debug(f'Updating changes in domain')
            updatedData = mg.update_one({"id": namespacedict["id"]},{"$set": {"domain": newdict["domain"]}})

            if updatedData.modified_count == 1:
                logger.info(f'Domain of {namespacedict["id"]} updated in {mg._collection.name}')                
                updateResult = {
                    "domainupdated": True
                }
            else:
                logger.debug(f'Domain of {namespacedict["id"]} not updated in {mg._collection.name}')
                updateResult = {
                    "domainupdated": False
                }                    
        elif key == "namespacescorerel":
            logger.debug(f'Updating changes in namespace relative score')
            updatedData = mg.update_one({"id": namespacedict["id"]},{"$set": {"namespacescorerel": newdict["namespacescorerel"]}})

            if updatedData.modified_count == 1:
                logger.info(f'Namespace {namespacedict["id"]} relative score updated in {mg._collection.name}')                
                updateResult = {
                    "namespacescorerelupdated": True
                }
            else:
                logger.debug(f'Namespace {namespacedict["id"]} relative score not updated in {mg._collection.name}')
                updateResult = {
                    "namespacescorerelupdated": False
                }
        elif key == "namespacescoretot":
            logger.debug(f'Updating changes in namespace total score')
            updatedData = mg.update_one({"id": namespacedict["id"]},{"$set": {"namespacescoretot": newdict["namespacescoretot"]}})

            if updatedData.modified_count == 1:
                logger.info(f'Namespace {namespacedict["id"]} total score updated in {mg._collection.name}')                
                updateResult = {
                    "namespacescoretotupdated": True
                }
            else:
                logger.debug(f'Namespace {namespacedict["id"]} total score not updated in {mg._collection.name}')
                updateResult = {
                    "namespacescoretotupdated": False
                }
        elif key == "namespacescorerelnotrounded":
            logger.debug(f'Updating changes in namespace rel not rounded score')
            updatedData = mg.update_one({"id": namespacedict["id"]},{"$set": {"namespacescorerelnotrounded": newdict["namespacescorerelnotrounded"]}})

            if updatedData.modified_count == 1:
                logger.info(f'Namespace {namespacedict["id"]} relative score updated in {mg._collection.name}')                
                updateResult = {
                    "namespacescorerelnotroundedupdated": True
                }
            else:
                logger.debug(f'Namespace {namespacedict["id"]} relative not rounded score not updated in {mg._collection.name}')
                updateResult = {
                    "namespacescoretotupdated": False
                }                  
        elif key == "percentages":
            logger.debug(f'Updating changes in percentages')
            try:
                percentagesnew = namespacedict["percentages"]
            except KeyError:
                logger.debug(f'New percentages could not be retrieved. Continuing...')
                continue

            try:
                percentagesmongo = mongodict["percentages"]
            except KeyError:
                logger.debug(f'Mongo percentages could not be retrieved. Continuing...')
                continue

            percentagesupdated = {}
            updateResult = {
                "percentagesupdated": False
            }  
            
            logger.debug(f'Checking changes in percentages')
            for key in percentagesnew.keys():
                if key in percentagesmongo.keys():
                    logger.debug(f'The key {key} is in mongo. Checking changes')
                    if percentagesnew[key] != percentagesmongo[key]:
                        logger.debug(f'The key {key} changed in openshift. Updating mongo')
                        updatedData = mg.update_one({"id": namespacedict["id"]}, {"$set": {f'percentages.{key}': percentagesnew[key]}})

                        if updatedData.modified_count == 1:
                            
                            logger.info(f'Namespace {namespacedict["id"]} percentages of {key} updated in {mg._collection.name}')
                            updateResult = {
                                "percentagesupdated": True
                            }
                        else:
                            logger.debug(f'Namespace {namespacedict["id"]} percentages of {key} not updated in {mg._collection.name}')
                            updateResult = {
                                "percentagesupdated": False
                            }  

                        percentagesupdated.update(updateResult)
                else:
                    logger.debug(f'The key {key} is not in mongo. Adding it')
                    updatedData = mg.update_one({"id": namespacedict["id"]}, {"$set": {f'percentages.{key}': percentagesnew[key]}})

                    if updatedData.modified_count == 1:
                        
                        logger.info(f'Namespace {namespacedict["id"]} percentages of {key} updated in {mg._collection.name}')
                        updateResult = {
                            "percentagesupdated": True
                        }
                    else:
                        logger.debug(f'Namespace {namespacedict["id"]} percentages of {key} not updated in {mg._collection.name}')
                        updateResult = {
                            "percentagesupdated": False
                        }  
                    percentagesupdated.update(updateResult)
            
            logger.debug(f'Updating changes in mongo if key is not in openshift info anymore')
            for key in percentagesmongo.keys():
                if key not in percentagesnew.keys():
                    logger.debug(f'Key {key} is in mongo but it doesn\'t exist in infonamespaces anymore. Deleting...')
                    updatedData = mg.update_one({"id": namespacedict["id"]}, {"$unset": {f'percentages.{key}': True}})

                    if updatedData.modified_count == 1:
                        
                        logger.info(f'Namespace {namespacedict["id"]}: key {key} in percentages dict deleted in {mg._collection.name}')
                        updateResult = {
                            "percentagesupdated": True
                        }
                    else:
                        logger.debug(f'Namespace {namespacedict["id"]}: key {key} in percentages dict not deleted in {mg._collection.name}')
                        updateResult = {
                            "percentagesupdated": False
                        }  
                    percentagesupdated.update(updateResult)

            projectsupdated.update(percentagesupdated)
    
        projectsupdated.update(updateResult) 

    if True in projectsupdated.values():
        logger.info(f'Updating namespace {namespacedict["id"]} timestamp in {mg._collection.name}')
        mg.update_one({"id": namespacedict["id"]}, {"$set": {"timestamp": datetime.utcnow()}})
        outputdict = {
                        "namespace": namespacedict["id"],
                        "statusMongo": "Updated"
                    }
    else:
        outputdict = {
                        "namespace": namespacedict["id"],
                        "statusMongo": "Not updated"
                    }
    
    return outputdict