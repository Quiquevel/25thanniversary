async def normalizeUnits(measure):

    if measure.endswith("Ki"):
        measure = int(measure[:-2])*2**10                
    elif measure.endswith("Mi"):
        measure = int(measure[:-2])*2**20
    elif measure.endswith("Gi"):
        measure = int(measure[:-2])* 2**30
    elif measure.endswith("Ti"):
        measure = int(measure[:-2])* 2**40                    
    elif measure.endswith("K") or measure.endswith("k"):
        measure = int(measure[:-1])*1000
    elif measure.endswith("M") or measure.endswith("m"):
        measure = int(measure[:-1])*1000*1000
    elif measure.endswith("G") or measure.endswith("g"):
        measure = int(measure[:-1])*1000*1000*1000
    elif measure.endswith("T") or measure.endswith("t"):
        measure = int(measure[:-1])*1000*1000*1000*1000
    else:
        measure = int(measure)

    return measure