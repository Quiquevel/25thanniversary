import os
from shuttlelib.utils.logger import logger
from packaging.version import Version, parse

async def getAngularVersion(micro):

    try:
        angularversion = micro["technology_dict"]["version"]
    except KeyError:
        angularversion = None
    
    ANGULAR_MIN_VERSION = os.getenv("ANGULAR_MIN_VERSION", "11.0.0")

    min_version_for_scoring = parse(ANGULAR_MIN_VERSION)

    if angularversion != None:
        
        if parse(angularversion) < min_version_for_scoring:
            angularversion = "ko"
        elif parse(angularversion) >= min_version_for_scoring:
            angularversion = "ok"
        
    else:
        angularversion = "ok"

    return angularversion


async def getAngularVersionCompliance(angularversionlist,microsangular,ponderation,sumtotalvalues):

    ANGULAR_OK = float(os.getenv("ANGULAR_OK_SCORE"))
    ANGULAR_KO = float(os.getenv("ANGULAR_KO_SCORE"))

    angular_version_ok = angularversionlist.count("ok")
    angular_version_ko = angularversionlist.count("ko")

    angularversionsum = angular_version_ok*ANGULAR_OK + angular_version_ko*ANGULAR_KO

    totcompliance = round((angularversionsum)/microsangular*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict