import os

async def getMinValidVersions():

    java_redhat_min_version_11 = os.getenv("MIN_VALID_VERSION_JAVA_REDHAT_11")
    java_ibm_min_version_11 = os.getenv("MIN_VALID_VERSION_JAVA_IBM_11")
    java_oracle_min_version_11 = os.getenv("MIN_VALID_VERSION_JAVA_ORACLE_11")
    java_openjdk_min_version_11 = os.getenv("MIN_VALID_VERSION_JAVA_OPENJDK_11")

    java_redhat_min_version_17 = os.getenv("MIN_VALID_VERSION_JAVA_REDHAT_17")
    java_ibm_min_version_17 = os.getenv("MIN_VALID_VERSION_JAVA_IBM_17")
    java_oracle_min_version_17 = os.getenv("MIN_VALID_VERSION_JAVA_ORACLE_17")
    java_openjdk_min_version_17 = os.getenv("MIN_VALID_VERSION_JAVA_OPENJDK_17")

    node_min_version = os.getenv("MIN_VALID_VERSION_NODE")

    min_valid_versions = {
        "Node": node_min_version,
        "Red Hat, Inc.": {
            "11": java_redhat_min_version_11,
            "17": java_redhat_min_version_17
        },
        "IBM Corporation": {
            "11": java_ibm_min_version_11,
            "17": java_ibm_min_version_17
        },
        "Oracle Corporation": {
            "11": java_oracle_min_version_11,
            "17": java_oracle_min_version_17
        },
        "OpenJDK Community": {
            "11": java_openjdk_min_version_11,
            "17": java_openjdk_min_version_17
        }
    }

    return min_valid_versions


async def getLabel(micro,labelfield):
    
    if micro["labels"] != None:
        try:
            label = micro["labels"][labelfield]
        except:
            label = None
    else:
        label = None
    
    return label


async def getNexusArtifacts(micro):
    try:
        artifact = micro["artifactdict"]["hasNexusArtifact"]
    except KeyError:
        artifact = None
    
    return artifact
        
async def getLogTraces(micro):
    try:
        logtraces = micro["envlogtracesdict"]["logtraces"]
    except KeyError:
        logtraces = None
    
    # for trace in logtraces:
    #     if "TRACE" in str(trace) or "DEBUG" in str(trace) or "ALL" in str():
    #         logtracescomplianceofmicro.append(0.0)
    #     elif "INFO" in str(trace):
    #         logtracescomplianceofmicro.append(0.5)
    #     elif "WARN" in str(trace):
    #         logtracescomplianceofmicro.append(0.9)
    #     elif "ERROR" in str(trace) or "FATAL" in str(trace):
    #         logtracescomplianceofmicro.append(1.0)
    
    if  "DEBUG" in str(logtraces) or "TRACE" in str(logtraces) or "ALL" in str(logtraces) :
        logtracescompliance = 0.0
    elif "INFO" in str(logtraces):
        logtracescompliance = 0.5
    elif "WARN" in str(logtraces):
        logtracescompliance = 0.9
    elif "ERROR" in str(logtraces) or "FATAL" in str(logtraces) or logtraces == None or logtraces == []:
        logtracescompliance = 1.0 #Le doy 1 de cumplimiento también si no tiene ninguna variable
    else:
        logtracescompliance = None

    return logtracescompliance

async def check_hpa_configuration(image,cpu_request,hpa_min,hpa_max,target_configuration):

    hpa_recommendation= [
        {"request":"50m", "min_replicas":1, "max_replicas":4, "target":100},
        {"request":"50m", "min_replicas":2, "max_replicas":8, "target":100},
        {"request":"100m","min_replicas":2, "max_replicas":10,"target":100},
        {"request":"120m","min_replicas":3, "max_replicas":10,"target":100},
        {"request":"150m","min_replicas":3, "max_replicas":12,"target":100},
        {"request":"200m","min_replicas":4, "max_replicas":16,"target":100},
        {"request":"250m","min_replicas":5, "max_replicas":20,"target":100},
        {"request":"300m","min_replicas":6, "max_replicas":24,"target":120},
        {"request":"350m","min_replicas":6, "max_replicas":24,"target":120},
        {"request":"450m","min_replicas":8, "max_replicas":30,"target":120},
        {"request":"500m","min_replicas":10,"max_replicas":40,"target":120},
        {"request":"600m","min_replicas":12,"max_replicas":50,"target":120}
    ]

    if "gateway" in image:
        hpa_recommendation[0]["min_replicas"] = 2

    flag_ok = False

    for recommendation in hpa_recommendation:
        if cpu_request == recommendation["request"]:

            if hpa_min == recommendation["min_replicas"]:
                if hpa_max == recommendation["max_replicas"]:
                    if target_configuration == recommendation["target"]:
                        flag_ok = True
                        break

    return flag_ok

async def get_hc_configuration(micro,hctype):
    
    hc_ok = False
    hc_set = False

    healthcheck = micro.get('healthchecks', {}).get(hctype, {})

    healthchecktype = healthcheck.get("type")
    healthcheckprobe = healthcheck.get("probe")
    failurethreshold = healthcheck.get("failureThreshold")
    
    if healthchecktype is not None and healthcheckprobe is not None:
        if isinstance(failurethreshold, (int,float)):
            if failurethreshold >= 3:
                hc_ok = True #hc set and ok
            else:
                hc_set = True #hc set but no ok
        else:
            hc_set = True

    if hc_ok == True:
        return 1
    elif hc_set == True:
        return 0.5
    else:
        return 0


async def get_hpa_configuration(micro):
    
    hpa_ok = False
    hpa_set = False

    try:
        hpa = micro["hpa"]
    except KeyError:
        hpa = None
     
    if hpa != None:
        cpu_request = micro["resources"]["cpu"]["cpuRequest"]
        hpa_min = micro["hpa"]["minReplicas"]
        hpa_max = micro["hpa"]["maxReplicas"]
        target_configuration = micro["hpa"]["targetCPUUtilizationPercentage"]
        able_to_scale = micro["hpa"]["ableToScale"]
        scaling_active = micro["hpa"]["scalingActive"]
        image=micro["image"]

        if able_to_scale == "True" and scaling_active == "True":
            if hpa_min == hpa_max:
                hpa_ok = False
            else:
                hpa_ok = await check_hpa_configuration(image=image,cpu_request=cpu_request,hpa_min=hpa_min,hpa_max=hpa_max,target_configuration=target_configuration)
                if hpa_ok == False:
                    hpa_set = True

        else:
            hpa_ok = False

    if hpa_ok == True:
        hpa_score = 1
    elif hpa_set == True:
        hpa_score = 0.5
    else:
        hpa_score = 0
    
    return hpa_score

async def getHpa(micro):
    
    try:
        hpa = micro["hpa"]
    except KeyError:
        hpa = None
    
    return hpa

async def getCgroupsv2Compatibility(micro):
    
    try:
        cgroups_v2_compatible = micro["technology_dict"]["cgroups_v2_compatible"]
    except KeyError:
        cgroups_v2_compatible = None

    return cgroups_v2_compatible


async def getDarwinVersionFlag(micro):

    try:
        darwinflag = micro["darwindict"]["obsolescenceLight"]
    except KeyError:
        darwinflag = None
    
    if darwinflag == "GREEN":
        darwinversioncompliance = 1
    elif darwinflag == "YELLOW":
        darwinversioncompliance = 0.5
    elif darwinflag == "RED":
        darwinversioncompliance = 0
    else:
        darwinversioncompliance = 1 # 100% if there is a problem with micro["darwindict"]["obsolescenceLight"]

    return darwinversioncompliance
