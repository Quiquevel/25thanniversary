import os
from shuttlelib.utils.logger import logger
from packaging.version import Version, parse

async def getPythonVersion(micro):

    try:
        pythonversion = micro["technology_dict"]["version"]
    except KeyError:
        pythonversion = None
    
    PYTHON_MIN_VERSION = os.getenv("PYTHON_MIN_VERSION", "3.10.0")

    min_version_for_scoring = parse(PYTHON_MIN_VERSION)

    if pythonversion != None:
        
        if parse(pythonversion) < min_version_for_scoring:
            pythonversion = "ko"
        elif parse(pythonversion) >= min_version_for_scoring:
            pythonversion = "ok"
        
    else:
        pythonversion = "ok"

    return pythonversion


async def getPythonVersionCompliance(pythonversionlist,microspython,ponderation,sumtotalvalues):

    PYTHON_OK = float(os.getenv("PYTHON_OK_SCORE"))
    PYTHON_KO = float(os.getenv("PYTHON_KO_SCORE"))

    python_version_ok = pythonversionlist.count("ok")
    python_version_ko = pythonversionlist.count("ko")

    pythonversionsum = python_version_ok*PYTHON_OK + python_version_ko*PYTHON_KO

    totcompliance = round((pythonversionsum)/microspython*100,2)
    relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
    relnotrounded = (ponderation/sumtotalvalues)*totcompliance
    compliancedict = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}

    return compliancedict