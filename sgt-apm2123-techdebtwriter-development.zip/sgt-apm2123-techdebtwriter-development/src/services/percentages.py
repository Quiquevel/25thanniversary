import os
from shuttlelib.utils.logger import logger
import shuttlelib.db.mongo as mongolib
from src.services.knowledge import getinfofromknowledge, getactivesnamespacesofdomain
from src.services.resources import getCPUResource, getMemResource
from src.services.microsjava import getJavaVersion, getHeapConfiguration, getGarbageCollector
from src.services.add_delete_mongo import checkNamespacesInMongo, savePercentages
from src.services.compliance import getCompliance, getQuotasCompliance, getJavasCompliance, getJavaVersionCompliance, getDarwinVersionCompliance, getArtifactsCompliance, getDeploymentsCompliance, getLogTracesCompliance, getHPACompliance,getCgroupsv2CompatibilityCompliance, get_hc_compliance
from src.services.otherelements import getLabel, get_hc_configuration, get_hpa_configuration, getDarwinVersionFlag, getNexusArtifacts, getLogTraces,getCgroupsv2Compatibility, getMinValidVersions
#from src.services.microsangular import getAngularVersionCompliance, getAngularVersion
from src.services.microsnode import getNodeVersion, getNodeVersionCompliance
#from src.services.microspython import getPythonVersion, getPythonVersionCompliance


mg = mongolib.MongoClient() 

async def setPonderationValues():
    logger.debug(f'Getting ponderationValues')
    #TODO
    #Sacar todo esto a fichero properties

    ValuesToCheck = {
        "PODS_QUOTA": float(os.getenv("PODS_QUOTA")),
        "RC_QUOTA": float(os.getenv("RC_QUOTA")),
        "RS_QUOTA": float(os.getenv("RS_QUOTA")),
        "MEMORY_QUOTA": float(os.getenv("MEMORY_QUOTA")),
        "ACTIVE_LABEL": float(os.getenv("ACTIVE_LABEL")),
        "CRITICAL_LABEL": float(os.getenv("CRITICAL_LABEL")),
        "CPU_REQUEST": float(os.getenv("CPU_REQUEST")),
        "CPU_LIMIT": float(os.getenv("CPU_LIMIT")),
        "MEM_REQUEST": float(os.getenv("MEM_REQUEST")),
        "MEM_LIMIT": float(os.getenv("MEM_LIMIT")),
        "HEAP": float(os.getenv("HEAP")),
        "HC_READINESS": float(os.getenv("HC_READINESS")),
        "HC_LIVENESS": float(os.getenv("HC_LIVENESS")),
        "AUTOSCALER": float(os.getenv("AUTOSCALER")),
        "JAVA_VERSION": float(os.getenv("JAVA_VERSION")),
        "NODE_VERSION": float(os.getenv("NODE_VERSION")),
        # "PYTHON_VERSION": float(os.getenv("PYTHON_VERSION")),
        # "ANGULAR_VERSION": float(os.getenv("ANGULAR_VERSION")),
        "DARWIN_VERSION": float(os.getenv("DARWIN_VERSION")),
        "LOG_TRACES": float(os.getenv("LOG_TRACES")),
        "ARTIFACTS": float(os.getenv("ARTIFACTS")),
        "DEPLOYMENTS": float(os.getenv("DEPLOYMENTS")),
        "GARBAGE_COLLECTOR": float(os.getenv("GARBAGE_COLLECTOR")),
        "CGROUPS_V2": float(os.getenv("CGROUPS_V2"))
    }

    TOTAL = sum(ValuesToCheck.values())

    ValuesToCheck.update({"TOTAL": TOTAL})
    logger.debug(f'Ponderation values: {ValuesToCheck}')
    return TOTAL,ValuesToCheck

async def getPercentages(functional_environment=None,domainslist=None):

    if functional_environment == None:
        functional_environment = os.getenv("ENVIRONMENT")
    entity_id = os.getenv("ENTITY_ID")
    possible_datagrid_names = os.getenv("POSSIBLE_DATAGRID_NAMES","datagrid,rhdg,data-grid").split(",")
    no_hpa_applies = os.getenv("MICROS_NO_HPA_APPLIES","datagrid,rhdg,data-grid,front-error-logger").split(",")
    logger.info(f'Changing collection to {os.getenv("COLLECTION_EXCEPTED")}')
    mg.change_collection(os.getenv("COLLECTION_EXCEPTED"))
    exceptedprojectsmongo = mg.find({})
    exceptedprojectsList = [f'{namespacedict["namespace"]}-{namespacedict["cluster"]}-{namespacedict["region"]}' for namespacedict in exceptedprojectsmongo]
    logger.debug(f'Excepted projects: {exceptedprojectsList}')

    environmentKnowledge = os.getenv("ENVIRONMENT_KNOWLEDGE")
    logger.debug(f'environment knowledge: {environmentKnowledge}')

    quotasthreshold = int(os.getenv("QUOTASTHRESHOLD"))
    logger.debug(f'Quota threshold from env: {quotasthreshold}')
    
    total, ponderValues = await setPonderationValues()
    logger.debug(f'Total of ponderation values: {total}')

    logger.debug(f'Domain list before if condition: {domainslist}')
    if domainslist == None:
        logger.info(f'Getting domains from knowledge')
        domainslist = await getinfofromknowledge(environmentKnowledge,"detaildomainlist")

    logger.debug(f'Domain list after if condition: {domainslist}')

    #mg = mongolib.MongoClient() 

    domainoutputlist = []
    for domain in domainslist:

        logger.info(f'Getting namespaces of {domain} from knowledge')
        namespacesclustersdictlist = await getactivesnamespacesofdomain(environmentKnowledge,domain)
        logger.debug(f'Namespaces obtained: {namespacesclustersdictlist}')
        
        logger.info(f'Changing collection to {os.getenv("COLLECTION_PERCENTAGES")}')
        mg.change_collection(os.getenv("COLLECTION_PERCENTAGES"))
        logger.debug(f'Getting namespaces for domain in mongo')
        namespacesdomainmongo = mg.find({"domain": domain})

        logger.debug(f'Selecting namespaces names of domain only, without cluster-region')
        namespacesknowledge = set([f'{namespace["name"]}-{functional_environment}' for namespace in namespacesclustersdictlist])
        
        namespacesactives = [f'{namespace["name"]}-{functional_environment}-{namespace["cluster"]}-{namespace["region"]}' for namespace in namespacesclustersdictlist]

        await checkNamespacesInMongo(namespacesdomainmongo,namespacesknowledge,namespacesactives,domain)
        
        namespacesoutputlist = []
        logger.info(f'Getting compliance percentages of domain {domain}')
        for namespacesclusterslist in namespacesclustersdictlist:
            namespace = f'{namespacesclusterslist["name"]}-{functional_environment}'
            cluster = namespacesclusterslist["cluster"]
            region = namespacesclusterslist["region"]            

            namespaceid = namespace+"-"+cluster+"-"+region

            metricsexcepted = []        
            if namespaceid in exceptedprojectsList:
                logger.debug(f'Namespace {namespaceid} is excepted')
                logger.info(f'Changing collection to {os.getenv("COLLECTION_EXCEPTED")}')
                mg.change_collection(os.getenv("COLLECTION_EXCEPTED"))
                document = mg.find_one({"id": namespaceid})
                
                if document["exception"] == "Full":
                    logger.debug(f'Namespace {namespaceid} is fully excepted. NamespaceScore: 100%')
                    namespaceScore = 100

                    namespacedict = {
                        "domain": domain,
                        "id": f'{namespace}-{cluster}-{region}',
                        "namespace": namespace,
                        "cluster": cluster,
                        "region": region,
                        "percentages": {},
                        "namespacescore": namespaceScore
                    }

                    logger.debug(f'Calling savePercentages function to add info in mongo')
                    namespacesoutputlist.append(await savePercentages(namespacedict))

                    continue

                elif document["exception"] == "Partial":
                    logger.debug(f'Namespace {namespaceid} is partially excepted')
                    
                    for elem in document["metricsexcepted"]:
                        if elem["excepted"] == True:
                            logger.debug(f'Namespace {namespaceid} is partially excepted for {elem["name"]}')
                            metricsexcepted.append(elem["name"])
                        

            logger.info(f'Changing collection to {os.getenv("COLLECTION")}')
            mg.change_collection(os.getenv("COLLECTION")) 
            logger.debug(f'Searching {namespace}-{cluster}-{region} in {os.getenv("COLLECTION")} mongo collection')
            object = mg.find_one({f'namespace': namespace, f'cluster': cluster, f'region': region})
            if object == None:
                logger.debug(f'Project {namespace}-{cluster}-{region} not found in {os.getenv("COLLECTION")} mongo collection')
                continue
            else:
                logger.info(f'Getting percentages of namespace {namespace}')
                
                metricsdict = {}
                #metricslist = []
                metricslistrel = []
                metricslisttot = []
                metricslistrelnotrounded=[]
                activelabelslist = []
                criticallabelslist = []
                cpurequestlist = []
                cpulimitlist = []
                memrequestlist = []
                memlimitlist = []
                hcreadinesslist = []
                hclivenesslist = []
                heapOklist = []
                hpalist = []
                garbagecollectorlist = []
                javaversionlist = []
                nodeversionlist = []
                # pythonversionlist = []
                # angularversionlist = []                
                darwinversionlist= []
                nexusartifactlist = []
                logtraceslist = []
                microkindlist = []
                cgroupscompatibilitylist = []

                logger.debug(f'Getting microserviceslist of {namespace}')
                microserviceslist = [micro for micro in object["microservices"] if micro["replicas"] > 0]
                logger.debug(f'microserviceslist: {microserviceslist}')
                
                logger.debug(f'Getting quotas of {namespace}')
                quotas = object["quotas"]

                nummicros = len(microserviceslist)
                logger.debug(f'nummicros is {nummicros}')

                microsdarwin = 0
                if nummicros == 0:
                    logger.debug(f'Namespace {namespace} has no microservices active for {cluster}-{region} in mongo {os.getenv("COLLECTION")}')
                    mongoid = f'{namespace}-{cluster}-{region}'
                    logger.info(f'Changing collection to {os.getenv("COLLECTION_PERCENTAGES")}')        
                    mg.change_collection(os.getenv("COLLECTION_PERCENTAGES"))  
                    mg.delete_one({"id": mongoid})
                    continue
                else:

                    microsjava = 0
                    microsnode = 0
                    # microspython = 0
                    # microsangular = 0                    
                    microsheap = 0
                    microshpa = 0
                    microsgarbagecollector = 0
                    microswithlogtraces = 0
                    darwinflagslist = []
                    
                    for micro in microserviceslist:
                        logger.debug(f'Getting label active of {micro["microservice"]}')
                        activelabelslist.append(await getLabel(micro,"active"))
                        logger.debug(f'Getting label critical of {micro["microservice"]}')
                        criticallabelslist.append(await getLabel(micro,"critical"))
                        logger.debug(f'Getting CPURequest of {micro["microservice"]}')
                        cpurequestlist.append(await getCPUResource(micro,'cpuRequest'))
                        logger.debug(f'Getting CPULimit of {micro["microservice"]}')
                        cpulimitlist.append(await getCPUResource(micro,'cpuLimit'))
                        logger.debug(f'Getting MemRequest of {micro["microservice"]}')
                        memrequestlist.append(await getMemResource(micro,'memRequest'))
                        logger.debug(f'Getting MemLimit of {micro["microservice"]}')
                        memlimitlist.append(await getMemResource(micro,'memLimit'))
                        logger.debug(f'Getting Readiness Path of {micro["microservice"]}')
                        hcreadinesslist.append(await get_hc_configuration(micro,'readiness'))
                        logger.debug(f'Getting Liveness Path of {micro["microservice"]}')
                        hclivenesslist.append(await get_hc_configuration(micro,'liveness'))
                        logger.debug(f'Getting Nexus artifacts of {micro["microservice"]}')
                        nexusartifactlist.append(await getNexusArtifacts(micro))
                        logger.debug(f'Getting Openshift Log traces of {micro["microservice"]}')
                        logtraceslist.append(await getLogTraces(micro))
                        logger.debug(f'Getting micro kind of {micro["microservice"]}')
                        microkindlist.append(micro["kind"])

                        if entity_id == 'spain':
                            logger.debug(f'Getting Darwin ObsolescenceLight of {micro["microservice"]}')
                            
                            arqnativeproductslist = os.getenv("ARQ_NATIVE_PRODUCTS_LIST", "").split(",")
                            
                            try:
                                if any(element in micro["image"] for element in arqnativeproductslist):
                                    darwinflag = "RED"
                                else:
                                    darwinflag = micro["darwindict"]["obsolescenceLight"]
                            except KeyError:
                                darwinflag = None

                            if darwinflag == "GREEN" or darwinflag == "YELLOW" or darwinflag == "RED":
                                logger.debug(f'Getting Darwin Flag of {micro["microservice"]}')
                                darwinversionlist.append(await getDarwinVersionFlag(micro))
                                microsdarwin = microsdarwin + 1
                            else:
                                darwinversionlist.append("whiteOrNone") #Para que no cuente en la cuenta de versiones Darwin

                        productionBlock = micro["productionBlock"]

                        logger.debug(f'Getting technology_dict of {micro["microservice"]}')
                        try:
                            technology = micro["technology_dict"]["technology"]
                        except:
                            technology = None

                        if productionBlock == "production":
                            minversions = await getMinValidVersions()
                            match technology:
                                case "JAVA":
                                    microsjava += 1
                                    logger.debug(f'Getting JavaVersion of {micro["microservice"]}')
                                    
                                    javaversionlist.append(await getJavaVersion(micro,minversions))

                                    logger.debug(f'Getting heap of {micro["microservice"]}')
                                    possible_datagrid_names = os.getenv("POSSIBLE_DATAGRID_NAMES","datagrid,rhdg,data-grid").split(",")

                                    if not any(name in micro["microservice"] for name in possible_datagrid_names):
                                        heapOklist.append(await getHeapConfiguration(micro))
                                        microsheap += 1
                                    
                                    if cluster != "confluent" and "bks" not in cluster:
                                        logger.debug(f'Getting HPA of {micro["microservice"]}')
                                        if ("config" not in micro["microservice"] or "serv" not in micro["microservice"]) and not any(name in micro["microservice"] for name in no_hpa_applies):
                                            #hpalist.append(await getHpa(micro))
                                            hpalist.append(await get_hpa_configuration(micro))
                                            microshpa += 1

                                    logger.debug(f'Getting GC of {micro["microservice"]}')
                                    if not any(name in micro["microservice"] for name in possible_datagrid_names):
                                        garbagecollectorlist.append(await getGarbageCollector(micro))
                                        microsgarbagecollector += 1
                                
                                case "NODE":
                                    microsnode +=1
                                    logger.debug(f'Getting NodeVersion of {micro["microservice"]}')
                                    nodeversionlist.append(await getNodeVersion(micro,minversions))
                                case "PYTHON":
                                #     microspython +=1
                                #     logger.debug(f'Getting PythonVersion of {micro["microservice"]}')
                                #     pythonversionlist.append(await getPythonVersion(micro))                                    
                                    logger.debug('Python is currently not controlled in compliance')
                                case "ANGULAR":
                                #     microsangular +=1
                                #     logger.debug(f'Getting AngularVersion of {micro["microservice"]}')
                                #     angularversionlist.append(await getAngularVersion(micro))                                                                                                    
                                    logger.debug('Angular is currently not controlled in compliance')
                                case _:
                                    logger.debug(f'{technology} is currently not controlled in compliance')

                            logger.debug(f'Getting cgroups compatibility of {micro["microservice"]}')
                            cgroupscompatibilitylist.append(await getCgroupsv2Compatibility(micro))

                        if len(micro["envlogtracesdict"]["logtraces"]) != 0:
                            microswithlogtraces += 1

                    sumtotalvalues = ponderValues["TOTAL"]
                    
                    technologies_count= [
                        {"key": "JAVA_VERSION", "count": microsjava},
                        {"key": "NODE_VERSION", "count": microsnode},
                        # {"key": "PYTHON_VERSION", "count": microspython},
                        # {"key": "ANGULAR_VERSION", "count": microsangular}
                    ]
                    
                    for tech in technologies_count:
                        if tech["count"] == 0:
                            sumtotalvalues -= ponderValues[tech["key"]]

                    cgroupsnoaply = cgroupscompatibilitylist.count(None)
                    if nummicros == cgroupsnoaply:
                        sumtotalvalues -= ponderValues["CGROUPS_V2"]

                    if entity_id != "spain":
                        sumtotalvalues -= ponderValues['DARWIN_VERSION']

                    if microsjava == 0:
                        #If there is no micros java, values of heap, hpa and javaversion are excluded
                        logger.debug(f'Getting SumTotalValues ponderation')
                        sumtotalvalues -= (ponderValues["HEAP"] + ponderValues["AUTOSCALER"] + ponderValues["JAVA_VERSION"] + ponderValues["GARBAGE_COLLECTOR"])

                    else:
                        if microshpa == 0: sumtotalvalues -= ponderValues["AUTOSCALER"]
                        if microsheap == 0: sumtotalvalues -= ponderValues["HEAP"]
                        if microsgarbagecollector == 0: sumtotalvalues -= ponderValues["GARBAGE_COLLECTOR"]
                                                
                        if microshpa != 0:
                            logger.debug(f'Getting HPA Compliance of namespace {namespaceid}')
                            #hpa = await getCompliance(hpalist,microshpa,ponderValues["AUTOSCALER"],sumtotalvalues)
                            hpa = await getHPACompliance(hpalist,microshpa,ponderValues["AUTOSCALER"],sumtotalvalues)
                            metricsdict.update({"hpa": hpa})

                        if microsheap != 0:
                            logger.debug(f'Getting heap Compliance of namespace {namespaceid}')
                            heap = await getJavasCompliance(heapOklist,microsheap,ponderValues["HEAP"],sumtotalvalues)
                            metricsdict.update({"heap": heap})
                       
                        if microsgarbagecollector != 0:
                            logger.debug(f'Getting GarbageCollector Compliance of namespace {namespaceid}')
                            garbagecollector = await getJavasCompliance(garbagecollectorlist,microsgarbagecollector,ponderValues["GARBAGE_COLLECTOR"],sumtotalvalues)
                            metricsdict.update({"garbagecollector": garbagecollector})

                        logger.debug(f'Getting Java Version Compliance of namespace {namespaceid}')
                        javaversion = await getJavaVersionCompliance(javaversionlist,microsjava,ponderValues["JAVA_VERSION"],sumtotalvalues)
                        metricsdict.update({"javaversion": javaversion})

                    if microsnode != 0:
                        logger.debug(f'Getting Node Version Compliance of namespace {namespaceid}')
                        nodeversion = await getNodeVersionCompliance(nodeversionlist, microsnode, ponderValues["NODE_VERSION"], sumtotalvalues)
                        metricsdict.update({"nodeversion": nodeversion})

                    # if microspython != 0:
                    #     logger.debug(f'Getting Python Version Compliance of namespace {namespaceid}')
                    #     pythonversion = await getPythonVersionCompliance(pythonversionlist, microspython, ponderValues["PYTHON_VERSION"], sumtotalvalues)
                    #     metricsdict.update({"pythonversion": pythonversion})

                    # if microsangular != 0:
                    #     logger.debug(f'Getting Angular Version Compliance of namespace {namespaceid}')
                    #     angularversion = await getAngularVersionCompliance(angularversionlist, microsangular, ponderValues["ANGULAR_VERSION"], sumtotalvalues)
                    #     metricsdict.update({"angularversion": angularversion})

                    if nummicros > cgroupsnoaply:
                        logger.debug(f'Getting Cgroups v2 Compatibility of namespace {namespaceid}')
                        cgroupscompatibility = await getCgroupsv2CompatibilityCompliance(cgroupscompatibilitylist,nummicros,ponderValues["CGROUPS_V2"],sumtotalvalues)
                        metricsdict.update({"cgroupscompatibility": cgroupscompatibility})

                    logger.debug(f'Getting PodsQuota of namespace {namespaceid}')
                    podsquota = await getQuotasCompliance(quotas,"usedPodsQuotaPerc", quotasthreshold, ponderValues["PODS_QUOTA"], sumtotalvalues)
                    metricsdict.update({"podsquota": podsquota})

                    logger.debug(f'Getting RCsQuota of namespace {namespaceid}')
                    rcquota = await getQuotasCompliance(quotas,"usedRcQuotaPerc", quotasthreshold, ponderValues["RC_QUOTA"], sumtotalvalues)
                    metricsdict.update({"rcsquota": rcquota})
                    
                    logger.debug(f'Getting RSsQuota of namespace {namespaceid}')
                    rsquota = await getQuotasCompliance(quotas,"usedRsQuotaPerc", quotasthreshold, ponderValues["RS_QUOTA"], sumtotalvalues)
                    metricsdict.update({"rssquota": rsquota})
                    
                    logger.debug(f'Getting MemoryQuota of namespace {namespaceid}')
                    memquota = await getQuotasCompliance(quotas,"usedMemoryPerc", quotasthreshold, ponderValues["MEMORY_QUOTA"], sumtotalvalues)
                    metricsdict.update({"memquota": memquota})
                    
                    if entity_id == 'spain':
                        logger.debug(f'Getting Darwin Version Compliance of namespace {namespaceid}')
                        if "RED" not in darwinflagslist and "GREEN" not in darwinflagslist and "YELLOW" not in darwinflagslist:
                            mg.change_collection(os.getenv("COLLECTION_PERCENTAGES"))
                            namespacedata = mg.find_one({"id": namespaceid})
                            if namespacedata == None:
                                totcompliance = 100
                                relcompliance = round((ponderValues["DARWIN_VERSION"]/sumtotalvalues)*totcompliance,2)
                                relnotrounded = (ponderValues["DARWIN_VERSION"]/sumtotalvalues)*totcompliance
                                darwinversion = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}
                            else:
                                darwinversion = {"total": namespacedata['percentages']['darwinversion']["total"], "relative": namespacedata['percentages']['darwinversion']["relative"], "relnotrounded": namespacedata['percentages']['darwinversion']["relnotrounded"]}
                        else:
                            darwinversion = await getDarwinVersionCompliance(darwinversionlist,microsdarwin,ponderValues["DARWIN_VERSION"],sumtotalvalues)
                        metricsdict.update({"darwinversion": darwinversion})

                    logger.debug(f'Getting label Active Compliance of namespace {namespaceid}')
                    labelactive = await getCompliance(activelabelslist,nummicros,ponderValues["ACTIVE_LABEL"],sumtotalvalues)
                    metricsdict.update({"labelactive": labelactive})

                    logger.debug(f'Getting label Critical Compliance of namespace {namespaceid}')
                    labelcritical = await getCompliance(criticallabelslist,nummicros,ponderValues["CRITICAL_LABEL"],sumtotalvalues)
                    metricsdict.update({"labelcritical": labelcritical})

                    logger.debug(f'Getting CPURequest Compliance of namespace {namespaceid}')
                    cpurequest = await getCompliance(cpurequestlist,nummicros,ponderValues["CPU_REQUEST"],sumtotalvalues)
                    metricsdict.update({"cpurequest": cpurequest})

                    logger.debug(f'Getting CPULimit Compliance of namespace {namespaceid}')
                    cpulimit = await getCompliance(cpulimitlist,nummicros,ponderValues["CPU_LIMIT"],sumtotalvalues)
                    metricsdict.update({"cpulimit": cpulimit})

                    logger.debug(f'Getting MemRequest Compliance of namespace {namespaceid}')
                    memrequest = await getCompliance(memrequestlist,nummicros,ponderValues["MEM_REQUEST"],sumtotalvalues)
                    metricsdict.update({"memrequest": memrequest})

                    logger.debug(f'Getting MemLimit Compliance of namespace {namespaceid}')
                    memlimit = await getCompliance(memlimitlist,nummicros,ponderValues["MEM_LIMIT"],sumtotalvalues)
                    metricsdict.update({"memlimit": memlimit})
                    
                    logger.debug(f'Getting HCReadiness Compliance of namespace {namespaceid}')
                    hcreadiness = await get_hc_compliance(hcreadinesslist,nummicros,ponderValues["HC_READINESS"],sumtotalvalues)
                    metricsdict.update({"hcreadiness": hcreadiness})

                    logger.debug(f'Getting HCLiveness Compliance of namespace {namespaceid}')
                    hcliveness = await get_hc_compliance(hclivenesslist,nummicros,ponderValues["HC_LIVENESS"],sumtotalvalues)
                    metricsdict.update({"hcliveness": hcliveness})

                    logger.debug(f'Getting NexusArtifact Compliance of namespace {namespaceid}')
                    nexusartifact = await getArtifactsCompliance(nexusartifactlist,nummicros,ponderValues["ARTIFACTS"],sumtotalvalues)
                    metricsdict.update({"nexusartifact": nexusartifact})

                    logger.debug(f'Getting Deployment Compliance of namespace {namespaceid}')
                    deployments = await getDeploymentsCompliance(microkindlist,nummicros, ponderValues["DEPLOYMENTS"], sumtotalvalues)
                    metricsdict.update({"deployments": deployments})

                    logger.debug(f'Getting Log Traces Compliance of namespace {namespaceid}')
                    if "1.0" not in str(logtraceslist) and "0.0" not in str(logtraceslist) and "0.5" not in str(logtraceslist) and "0.9" not in str(logtraceslist) or microswithlogtraces == 0:
                        totcompliance = 100
                        relcompliance = round((ponderValues["LOG_TRACES"]/sumtotalvalues)*totcompliance,2)
                        relnotrounded = (ponderValues["LOG_TRACES"]/sumtotalvalues)*totcompliance
                        environmentlogtraces = {"total": totcompliance, "relative": relcompliance, "relnotrounded": relnotrounded}
                    else:
                        environmentlogtraces = await getLogTracesCompliance(logtraceslist,nummicros,ponderValues["LOG_TRACES"],sumtotalvalues)

                    metricsdict.update({"environmentlogtraces": environmentlogtraces})

                    for metric in metricsexcepted:
                        logger.debug(f'Namespace {namespaceid}: Metric {metric} excepted. Relative score: 100%')
                        totcompliance = 100
                        match metric:
                            case 'podsquota':
                                ponderation=ponderValues['PODS_QUOTA']
                            case 'rcsquota':
                                ponderation=ponderValues['RC_QUOTA']
                            case 'rssquota':
                                ponderation=ponderValues['RS_QUOTA']
                            case 'memquota':
                                ponderation=ponderValues['MEMORY_QUOTA']
                            case 'labelactive':
                                ponderation=ponderValues['ACTIVE_LABEL']
                            case 'labelcritical':
                                ponderation=ponderValues['CRITICAL_LABEL']
                            case 'cpurequest':
                                ponderation=ponderValues['CPU_REQUEST']
                            case 'cpulimit':
                                ponderation=ponderValues['CPU_LIMIT']
                            case 'memrequest':
                                ponderation=ponderValues['MEM_REQUEST']
                            case 'memlimit':
                                ponderation=ponderValues['MEM_LIMIT']
                            case 'heap':
                                ponderation=ponderValues['HEAP']
                            case 'hcreadiness':
                                ponderation=ponderValues['HC_READINESS']
                            case 'hcliveness':
                                ponderation=ponderValues['HC_LIVENESS']
                            case 'hpa':
                                ponderation=ponderValues['AUTOSCALER']
                            case 'javaversion':
                                ponderation=ponderValues['JAVA_VERSION']                                
                            case 'darwinversion':
                                ponderation=ponderValues['DARWIN_VERSION']
                            case 'artifacts':
                                ponderation=ponderValues['ARTIFACTS']
                            case 'deployments':
                                ponderation=ponderValues['DEPLOYMENTS']
                            case 'logtraces':
                                ponderation=ponderValues['LOG_TRACES']
                            case 'garbagecollector':
                                ponderation=ponderValues['GARBAGE_COLLECTOR']                                
                            case _:
                                ponderation=0

                        if ponderation != 0:
                            relcompliance = round((ponderation/sumtotalvalues)*totcompliance,2)
                            relnotrounded = (ponderation/sumtotalvalues)*totcompliance
                            compliancedict = {"relative": relcompliance, "total": totcompliance, "relnotrounded": relnotrounded}
                            metricsdict[metric] = compliancedict

                    logger.debug(f'Getting metricslist total')
                    for key in metricsdict.keys():
                        metricslistrel.append(metricsdict[key]["relative"])
                        metricslisttot.append(metricsdict[key]["total"])
                        metricslistrelnotrounded.append(metricsdict[key]["relnotrounded"])

                    logger.debug(f'Getting namespaceScore')
                    #namespaceScore = round(sum(metricslist)/len(metricslist),2)
                    #namespacescorerel = round(sum(metricslistrel)/len(metricslistrel),2)
                    namespacescoretot = round(sum(metricslisttot)/len(metricslisttot),2)
                    #namespacescoretot = round(sum(metricslisttot),2)
                    namespacescorerel = round(sum(metricslistrel),2)
                    namespacescorerelnotrounded = round(sum(metricslistrelnotrounded),2)

                    #ÑAPA
                    if namespacescorerelnotrounded > 100:
                        namespacescorerelnotrounded = 100.00

                    #namespacescorerelnotroundednotrounded = sum(metricslistrelnotrounded)

                    namespacedict = {
                        "domain": domain,
                        "id": f'{namespace}-{cluster}-{region}',
                        "namespace": namespace,
                        "cluster": cluster,
                        "region": region,
                        "percentages": metricsdict,
                        #"namespacescore": namespaceScore,
                        "namespacescoretot": namespacescoretot,
                        "namespacescorerel": namespacescorerel,
                        "namespacescorerelnotrounded": namespacescorerelnotrounded,
                        #"namespacescorerelnotroundednotrounded": namespacescorerelnotroundednotrounded
                    }

                    if 'sanes-portes-pro-dmzbazure' in f'{namespace}-{cluster}':
                        namespacedict["domain"] = "Gluon"


                    logger.debug(f'Calling savePercentages function to add info in mongo')
                    namespacesoutputlist.append(await savePercentages(namespacedict))
            
        domainoutputlist.append({"domain": domain, "namespaceList": namespacesoutputlist})

    logger.info('[INFO] - Process finished')
    
    return domainoutputlist

async def getScore(percentages,metric, metricscore, metrictotal):
    
    try:
        metricdata = percentages[metric]["total"]
        metricscore += metricdata
        metrictotal += 1
    except KeyError:
        logger.info(f'[INFO] - No {metric} percentage found')

    return metricscore, metrictotal

async def getMetricsAverageCronJob():
    entity_id = os.getenv("ENTITY_ID")
    mg.expiration_manager()
    logger.info(f'Changing collection to {os.getenv("COLLECTION_PERCENTAGES")}')        
    mg.change_collection(os.getenv("COLLECTION_PERCENTAGES")) 

    objects = list(mg.find({}))

    hpascore = 0
    hpatotal = 0
    heapscore = 0
    heaptotal = 0
    javaversionscore = 0
    javaversiontotal = 0
    nodeversionscore = 0
    nodeversiontotal = 0    
    # pythonversionscore = 0
    # pythonversiontotal = 0    
    # angularversionscore = 0
    # angularversiontotal = 0            
    podsquotascore = 0
    podsquotatotal = 0
    rcsquotascore = 0
    rcsquotatotal = 0
    rssquotascore = 0
    rssquotatotal = 0    
    memquotascore = 0
    memquotatotal = 0
    darwinversionscore = 0
    darwinversiontotal = 0
    labelactivescore = 0
    labelactivetotal = 0
    labelcriticalscore = 0
    labelcriticaltotal = 0
    cpurequestscore = 0
    cpurequesttotal = 0
    cpulimitscore = 0
    cpulimittotal = 0
    memrequestscore = 0
    memrequesttotal = 0
    memlimitscore = 0
    memlimittotal = 0
    hcreadinessscore = 0
    hcreadinesstotal = 0
    hclivenessscore = 0
    hclivenesstotal = 0
    nexusartifactscore = 0
    nexusartifacttotal = 0
    deploymentsscore = 0
    deploymentstotal = 0
    envlogtracesscore = 0
    envlogtracestotal = 0 
    garbagecollectorscore = 0
    garbagecollectortotal = 0 
    cgroupsv2score = 0
    cgroupsv2total = 0

    for object in objects:

        logger.info(f'[INFO] - Getting info of {object["id"]}')
        hpascore, hpatotal = await getScore(percentages=object["percentages"], metric="hpa", metricscore=hpascore, metrictotal=hpatotal)
        heapscore, heaptotal = await getScore(percentages=object["percentages"], metric="heap", metricscore=heapscore, metrictotal=heaptotal)
        javaversionscore, javaversiontotal = await getScore(percentages=object["percentages"], metric="javaversion", metricscore=javaversionscore, metrictotal=javaversiontotal)
        nodeversionscore, nodeversiontotal = await getScore(percentages=object["percentages"], metric="nodeversion", metricscore=nodeversionscore, metrictotal=nodeversiontotal)
        # pythonversionscore, pythonversiontotal = await getScore(percentages=object["percentages"], metric="pythonversion", metricscore=pythonversionscore, metrictotal=pythonversiontotal)
        # angularversionscore, angularversiontotal = await getScore(percentages=object["percentages"], metric="angularversion", metricscore=angularversionscore, metrictotal=angularversiontotal)
        podsquotascore, podsquotatotal = await getScore(percentages=object["percentages"], metric="podsquota", metricscore=podsquotascore, metrictotal=podsquotatotal)
        rcsquotascore, rcsquotatotal = await getScore(percentages=object["percentages"], metric="rcsquota", metricscore=rcsquotascore, metrictotal=rcsquotatotal)
        rssquotascore, rssquotatotal = await getScore(percentages=object["percentages"], metric="rssquota", metricscore=rssquotascore, metrictotal=rssquotatotal)
        memquotascore, memquotatotal = await getScore(percentages=object["percentages"], metric="memquota", metricscore=memquotascore, metrictotal=memquotatotal)
        if entity_id == "spain": 
            darwinversionscore, darwinversiontotal = await getScore(percentages=object["percentages"], metric="darwinversion", metricscore=darwinversionscore, metrictotal=darwinversiontotal)
        labelactivescore, labelactivetotal = await getScore(percentages=object["percentages"], metric="labelactive", metricscore=labelactivescore, metrictotal=labelactivetotal)
        labelcriticalscore, labelcriticaltotal = await getScore(percentages=object["percentages"], metric="labelcritical", metricscore=labelcriticalscore, metrictotal=labelcriticaltotal)
        cpurequestscore, cpurequesttotal = await getScore(percentages=object["percentages"], metric="cpurequest", metricscore=cpurequestscore, metrictotal=cpurequesttotal)
        cpulimitscore, cpulimittotal, = await getScore(percentages=object["percentages"],metric="cpulimit", metricscore=cpulimitscore, metrictotal=cpulimittotal)
        memrequestscore, memrequesttotal, = await getScore(percentages=object["percentages"],metric="memrequest", metricscore=memrequestscore, metrictotal=memrequesttotal)
        memlimitscore, memlimittotal, = await getScore(percentages=object["percentages"],metric="memlimit", metricscore=memlimitscore, metrictotal=memlimittotal)
        hcreadinessscore, hcreadinesstotal, = await getScore(percentages=object["percentages"],metric="hcreadiness", metricscore=hcreadinessscore, metrictotal=hcreadinesstotal)
        hclivenessscore, hclivenesstotal, = await getScore(percentages=object["percentages"],metric="hcliveness", metricscore=hclivenessscore, metrictotal=hclivenesstotal)
        nexusartifactscore, nexusartifacttotal, = await getScore(percentages=object["percentages"],metric="nexusartifact", metricscore=nexusartifactscore, metrictotal=nexusartifacttotal)
        deploymentsscore, deploymentstotal, = await getScore(percentages=object["percentages"],metric="deployments", metricscore=deploymentsscore, metrictotal=deploymentstotal)
        envlogtracesscore,envlogtracestotal = await getScore(percentages=object["percentages"],metric="environmentlogtraces",metricscore=envlogtracesscore,metrictotal=envlogtracestotal)
        garbagecollectorscore,garbagecollectortotal = await getScore(percentages=object["percentages"],metric="garbagecollector",metricscore=garbagecollectorscore,metrictotal=garbagecollectortotal)
        cgroupsv2score,cgroupsv2total = await getScore(percentages=object["percentages"],metric="cgroupscompatibility",metricscore=cgroupsv2score,metrictotal=cgroupsv2total)

    hpafinalscore = round(hpascore/hpatotal, 2) if hpatotal != 0 else 0
    heapsfinalscore = round(heapscore/heaptotal, 2) if heaptotal != 0 else 0
    javaversionfinalscore = round(javaversionscore/javaversiontotal, 2) if javaversiontotal != 0 else 0
    nodeversionfinalscore = round(nodeversionscore/nodeversiontotal, 2) if nodeversiontotal != 0 else 0
    # pythonversionfinalscore = round(pythonversionscore/pythonversiontotal, 2) if pythonversiontotal != 0 else 0
    # angularversionfinalscore = round(angularversionscore/angularversiontotal, 2) if angularversiontotal != 0 else 0
    podsquotafinalscore = round(podsquotascore/podsquotatotal, 2) if podsquotatotal != 0 else 0
    rcsquotafinalscore = round(rcsquotascore/rcsquotatotal, 2) if rcsquotatotal != 0 else 0
    rssquotafinalscore = round(rssquotascore/rssquotatotal, 2) if rssquotatotal != 0 else 0
    memquotafinalscore = round(memquotascore/memquotatotal, 2) if memquotatotal != 0 else 0
    if entity_id == "spain": 
        darwinversionfinalscore = round(darwinversionscore/darwinversiontotal, 2) if darwinversiontotal != 0 else 0
    labelactivefinalscore = round(labelactivescore/labelactivetotal, 2) if labelactivetotal != 0 else 0
    labelcriticalfinalscore = round(labelcriticalscore/labelcriticaltotal, 2) if labelcriticaltotal != 0 else 0
    cpurequestfinalscore = round(cpurequestscore/cpurequesttotal, 2) if cpurequesttotal != 0 else 0
    cpulimitfinalscore = round(cpulimitscore/cpulimittotal, 2) if cpulimittotal != 0 else 0
    memrequestfinalscore = round(memrequestscore/memrequesttotal, 2) if memrequesttotal != 0 else 0
    memlimitfinalscore = round(memlimitscore/memlimittotal, 2) if memlimittotal != 0 else 0
    hcreadinessfinalscore = round(hcreadinessscore/hcreadinesstotal, 2) if hcreadinesstotal != 0 else 0
    hclivenessfinalscore = round(hclivenessscore/hclivenesstotal, 2) if hclivenesstotal != 0 else 0
    nexusartifactfinalscore = round(nexusartifactscore/nexusartifacttotal, 2) if nexusartifacttotal != 0 else 0
    deploymentsfinalscore = round(deploymentsscore/deploymentstotal, 2) if deploymentstotal != 0 else 0
    envlogtracesfinalscore = round(envlogtracesscore/envlogtracestotal, 2) if envlogtracestotal != 0 else 0
    garbagecollectorfinalscore = round(garbagecollectorscore/garbagecollectortotal, 2) if garbagecollectortotal != 0 else 0
    cgroupsfinalscore = round(cgroupsv2score/cgroupsv2total, 2) if cgroupsv2total != 0 else 0
        
    outputdict = {

        "nametoshow": "compliance",
        "detail": [
            {
                "nametoshow": "Horizontal Pod Autoscaler",
                "score": hpafinalscore
            },
            {
                "nametoshow": "Heap configuration",
                "score": heapsfinalscore
            },
            {
                "nametoshow": "Java version",
                "score": javaversionfinalscore
            },
            {
                "nametoshow": "Node version",
                "score": nodeversionfinalscore
            },
            # {
            #     "nametoshow": "Python version",
            #     "score": pythonversionfinalscore
            # },
            # {
            #     "nametoshow": "Angular version",
            #     "score": angularversionfinalscore
            # },                                    
            {
                "nametoshow": "GarbageCollector parameter",
                "score": garbagecollectorfinalscore
            },                  
            {
                "nametoshow": "Pods quota",
                "score": podsquotafinalscore
            },
            {
                "nametoshow": "Replication Controllers quota",
                "score": rcsquotafinalscore
            }, 
            {
                "nametoshow": "ReplicaSets quota",
                "score": rssquotafinalscore
            },
            {
                "nametoshow": "Memory quota",
                "score": memquotafinalscore
            },
            # {
            #     "nametoshow": "Darwin version",
            #     "score": darwinversionfinalscore
            # },
            {
                "nametoshow": "Label 'Active'",
                "score": labelactivefinalscore
            },                                    
            {
                "nametoshow": "Label 'Critical'",
                "score": labelcriticalfinalscore
            },
            {
                "nametoshow": "CPU Request configuration",
                "score": cpurequestfinalscore
            },
            {
                "nametoshow": "CPU Limit configuration",
                "score": cpulimitfinalscore
            },
            {
                "nametoshow": "Memory Request configuration",
                "score": memrequestfinalscore
            },                                    
            {
                "nametoshow": "Memory Limit configuration",
                "score": memlimitfinalscore
            },
            {
                "nametoshow": "HealthCheck Readiness",
                "score": hcreadinessfinalscore
            }, 
            {
                "nametoshow": "HealthCheck Liveness",
                "score": hclivenessfinalscore
            },
            {
                "nametoshow": "Nexus artifact",
                "score": nexusartifactfinalscore
            },
            {
                "nametoshow": "Deployments",
                "score": deploymentsfinalscore
            },
            {
                "nametoshow": "Environment Log Traces",
                "score": envlogtracesfinalscore
            },
            {
                "nametoshow": "Cgroups v2 Compatibility",
                "score": cgroupsfinalscore
            }
        ]
    }

    if entity_id == 'spain':
        outputdict["detail"].append({
                "nametoshow": "Darwin version",
                "score": darwinversionfinalscore
            })

    logger.info(f'Changing collection to {os.getenv("COLLECTION_METRICSAVERAGE")}')        
    mg.change_collection(os.getenv("COLLECTION_METRICSAVERAGE")) 

    mg.delete_all_data()
    mg.add_data(outputdict)

    logger.info('[INFO] - Process finished')