import os, re
from src.services.commonfunctions import normalizeUnits
from shuttlelib.utils.logger import logger
from packaging.version import Version, parse

async def normalize_java_version(version) -> Version:
    if version.startswith("1.8"):
        version = version[2:]
        version = version.replace("_",".")
    elif re.match(r"^\d+$",version):
        version = f"{version}.0.0"
    
    return parse(version)

async def getHeapConfiguration(micro):
    
    heapOK = True
    heapValue = None
    ONE_GIGA = 1* 2**30
    ONE_FIVE_GIGA = 1.5* 2**30
    TWO_GIGAS = 2* 2**30
    
    arqnativeproductslist = os.getenv("ARQ_NATIVE_PRODUCTS_LIST", "").split(",")

    if any(element in micro["image"] for element in arqnativeproductslist):
        heapparameter = "MaximumHeapSizePercent"
    else:
        heapparameter = "MaxRAMPercentage"

    try:
        javaopts=micro["envVar"]["JAVA_OPTS_EXT"]
        result = javaopts.rfind(heapparameter)
    except:
        result = -1

    if result != -1:
        if "-Xmx:" in javaopts: 
            heapOK = False
        else:
            heap=javaopts[javaopts.rfind(heapparameter)-4:javaopts.rfind(heapparameter)+len(heapparameter)+3]
            heapValue = int(heap[heap.find("=")+1:])

            memLimit = micro["resources"]["memory"]["memLimit"]

            memLimit_normalized = await normalizeUnits(memLimit)
            if memLimit_normalized <= ONE_GIGA:
                if heapValue != 50:
                    heapOK = False
            elif memLimit_normalized > ONE_GIGA and memLimit_normalized <= ONE_FIVE_GIGA:
                if heapValue != 65:
                    heapOK = False
            elif memLimit_normalized > ONE_FIVE_GIGA and memLimit_normalized <= TWO_GIGAS:
                if heapValue != 70:
                    heapOK = False
            else:
                if heapValue != 75:
                    heapOK = False
    else:
        heapOK = False

    return heapOK

async def getGarbageCollector(micro):
    GarbageCollectorOK = True

    javaversion = micro["javadict"]["javaversion"]
    try:
        javaopts = micro["envVar"]["JAVA_OPTS_EXT"]
    except KeyError:
        javaopts = None

    GCParameters = os.getenv("GC_PARAMETERS", "").split(",")
    try:
        if javaversion.startswith("21"):
            try:
                result = javaopts.rfind("-XX:+UseG1GC")
            except AttributeError:
                result = -1     

            if result != -1:
                if "-XX:+UseStringDeduplication" not in javaopts:
                    logger.debug(f'{micro["kind"]} {micro["microservice"]} is java 21 and has not G1GC nor StringDeduplication configured in javaopts (KO)')
                    GarbageCollectorOK = False
                else:
                    if "-XX:+UseParallelGC" in javaopts or "-XX:ActiveProcessorCount=2" in javaopts:
                        logger.debug(f'{micro["kind"]} {micro["microservice"]} is java 21 and has G1GC and StringDeduplication configured in javaopts (great!) but Parallel GC or ActiveProcessorCount=2 parameter is set (KO)')
                        GarbageCollectorOK = False
                    else:
                        GarbageCollectorOK = True
            else:
                GarbageCollectorOK = False

        elif javaversion.startswith("17"):
            
            try:
                result = javaopts.rfind("-XX:+UseParallelGC")
            except AttributeError:
                result = -1        

            if result != -1:
                if "-XX:ActiveProcessorCount=2" not in javaopts:
                    logger.debug(f'{micro["kind"]} {micro["microservice"]} is java 17 and has Parallel GC configured in javaopts (great!) but -XX:ActiveProcessorCount=2 parameter is not set (KO)')
                    GarbageCollectorOK = False
                else:
                    if "-XX:+UseG1GC" in javaopts or "-XX:UseStringDeduplication" in javaopts:
                        GarbageCollectorOK = False
                    else:
                        GarbageCollectorOK = True            
            else:
                GarbageCollectorOK = False

        else:
            try:
                result = any(javaopts.rfind(GC) != -1 for GC in GCParameters)
            except AttributeError:
                result = -1
            
            if result == -1:
                GarbageCollectorOK = False
            else:
                if result:
                    logger.debug(f'{micro["kind"]} {micro["microservice"]} has a GC configured in javaopts: {javaopts}. It is recommended not set any GC and let the VM autoconfigures itself (usually SerialGC)')
                    GarbageCollectorOK = False            
                else:
                    GarbageCollectorOK = True

    except Exception as e:
        logger.error(f'[ERROR] - Exception ocurred: {e}')
        GarbageCollectorOK = False

    return GarbageCollectorOK

async def getFailFast(micro):
    failfastlist = [micro["envVar"][var] for var in micro["envVar"].keys() if "failfast" in var.lower() or "fail_fast" in var.lower()]
    failfastok = True

    if len(failfastlist) > 0:
        if not "true" in failfastlist:
            failfastok = False
    else:
        failfastok = False
    
    return failfastok

async def parse_major_minor_patch(v):
    try:
        if "_" in v:
            match = re.search(r'1\.8\.0_(\d+)', v)
            return (8, 0, int(match.group(1))) if match else (8, 0, 0)
        
        parts = re.split(r"[._\-+]", v)
        numbers = [int(p) for p in parts if p.isdigit()]
        if len(numbers) >= 3:
            return tuple(numbers[:3])
        elif len(numbers) == 2:
            return (numbers[0], numbers[1], 0)
        elif len(numbers) == 1:
            return (numbers[0], 0, 0)
        return (0, 0, 0)
    except TypeError:
        return (0,0,0)
    except Exception as e:
        logger.error(f'Exception parsing version: {e}')
        return (0,0,0)

async def getJavaVersion(micro,min_versions):

    BAD_VERSION = "KO"
    REGULAR_VERSION = "OK_KO"
    GREAT_VERSION = "OK"

    try:
        techversion = micro["technology_dict"]["version"]
    except KeyError:
        techversion = None

    try:
        javaversion = micro["javadict"]["javaversion"]
    except KeyError:
        javaversion = None

    # try:
    #     technology = micro["technology_dict"]["technology"]
    # except KeyError:
    #     technology = None

    try:
        isjava = micro["javadict"]["isjava"]
    except KeyError:
        isjava = False
    
    if isjava == True:
        try:
            vendor = micro["javadict"]["vendor"]
        except KeyError:
            vendor = None

    else:
        vendor = None

    if vendor not in min_versions.keys():
        javaversion = GREAT_VERSION
    else:
        if techversion == None and javaversion != None:
            techversion = javaversion
        
        techversion = await parse_major_minor_patch(techversion)
        lower_version = await parse_major_minor_patch(min_versions[vendor]["11"])
        upper_version = await parse_major_minor_patch(min_versions[vendor]["17"])
        
        if techversion < lower_version:
            javaversion = BAD_VERSION
        elif techversion >= lower_version and techversion < upper_version:
            javaversion = REGULAR_VERSION
        else:
            javaversion = GREAT_VERSION

    return javaversion
