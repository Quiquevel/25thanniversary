async def getCPUResource(micro,resourcefield):
    
    try:
        resource = micro["resources"]["cpu"][resourcefield]
    except KeyError:
        resource = None
    
    return resource

async def getMemResource(micro,resourcefield):
    
    try:
        resource = micro["resources"]["memory"][resourcefield]
    except KeyError:
        resource = None
    
    return resource