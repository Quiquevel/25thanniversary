from shuttlelib.utils.logger import logger
import shuttlelib.db.mongo as mongolib
from datetime import datetime, timedelta
import os

mg = mongolib.MongoClient() 
now = datetime.now()

async def historify():
    
    currentmonth = (now - timedelta(days=now.day)).strftime("%B").lower()
    if currentmonth == 'december':
        currentyear = (now - timedelta(days=365)).strftime("%Y")
    else:
        currentyear = now.strftime("%Y")
        
    logger.debug(f'[DEBUG] - Changing collection to {os.getenv("COLLECTION_PERCENTAGES")}')
    mg.change_collection(os.getenv("COLLECTION_PERCENTAGES"))
    namespacesobjects= mg.find({})
    
    for object in namespacesobjects:
        logger.debug(f'[DEBUG] - Getting mongo info of {object["id"]}')
        try:
            percentages = object["percentages"]
        except KeyError:
            percentages = []

        currentmonthdict = {
            "percentages": percentages,
            "namespacescore": object["namespacescorerelnotrounded"]
        }

        monthsdict = {
            currentmonth: currentmonthdict
        }
        
        yeardict = {
            currentyear: monthsdict
        }

        historifydict = {
            "domain": object["domain"],
            "id": object["id"],
            "namespace": object["namespace"],
            "cluster": object["cluster"],
            "region": object["region"],
            "year": yeardict
        }

        logger.debug(f'[DEBUG] - Changing collection to {os.getenv("COLLECTION_HISTORICAL")}')
        mg.change_collection(os.getenv("COLLECTION_HISTORICAL"))
        logger.debug(f'[DEBUG] - Quering historical collection for getting info of {object["id"]}')
        mongonamespace = mg.find_one({"id": object["id"]})
        updatedict = {}
        if mongonamespace != None:
            if currentyear not in str(mongonamespace["year"].keys()):
                logger.info(f'[INFO] - {currentyear} is not in historical collection for {mongonamespace["id"]}. Updating mongo...')
                mongonamespace["year"].update(yeardict)
                updatedData = mg.update_one({"id": mongonamespace["id"]}, {"$set": {f'year': mongonamespace["year"]}})

                if updatedData.modified_count == 1:
                        
                    logger.info(f'[INFO] - Namespace {mongonamespace["id"]}: year {currentyear} added in {mg._collection.name}')
                    updateResult = {
                        "yearupdated": True
                    }
                else:
                    logger.error(f'[ERROR] - Namespace {mongonamespace["id"]}: year {currentyear} not added in {mg._collection.name}')
                    updateResult = {
                        "yearupdated": False
                    }
                
                updatedict.update(updateResult)


            elif currentmonth not in str(mongonamespace["year"][currentyear].keys()):
                logger.info(f'[INFO] - {currentmonth} is not in historical collection for {mongonamespace["id"]}. Updating mongo...')
                mongonamespace["year"][currentyear].update(monthsdict)
                updatedData = mg.update_one({"id": mongonamespace["id"]}, {"$set": {f'year.{currentyear}': mongonamespace["year"][currentyear]}})

                if updatedData.modified_count == 1:
                        
                    logger.info(f'[INFO] - Namespace {mongonamespace["id"]}: month {currentmonth} added in {mg._collection.name}')
                    updateResult = {
                        "monthupdated": True
                    }
                else:
                    logger.error(f'[ERROR] - Namespace {mongonamespace["id"]}: month {currentmonth} not added in {mg._collection.name}')
                    updateResult = {
                        "monthupdated": False
                    }
                
                updatedict.update(updateResult)

        else:
            logger.info(f'[INFO] - {object["id"]} is not in historical collection. Adding it to mongo...')
            mg.add_data(historifydict)
        
        if True in updatedict.values():
            mg.update_one({"id": mongonamespace["id"]}, {"$set": {"timestamp": datetime.utcnow()}})
            logger.info(f'[INFO] - Timestamp updated for {mongonamespace["id"]}')
            

async def historifyCronJob():
    
    today = now.strftime("%d")
    
    if today == os.getenv("HISTORIFYDAY"):
            
        currentmonth = (now - timedelta(days=now.day)).strftime("%B").lower()
        
        if currentmonth == 'december':
            currentyear = (now - timedelta(days=365)).strftime("%Y")
        else:
            currentyear = now.strftime("%Y")
            
        logger.debug(f'[DEBUG] - Changing collection to {os.getenv("COLLECTION_PERCENTAGES")}')
        mg.change_collection(os.getenv("COLLECTION_PERCENTAGES"))
        namespacesobjects= mg.find({})
        
        for object in namespacesobjects:
            logger.debug(f'[DEBUG] - Getting mongo info of {object["id"]}')
            try:
                percentages = object["percentages"]
            except KeyError:
                percentages = []

            currentmonthdict = {
                "percentages": percentages,
                "namespacescore": object["namespacescorerelnotrounded"]
            }

            monthsdict = {
                currentmonth: currentmonthdict
            }
            
            yeardict = {
                currentyear: monthsdict
            }

            historifydict = {
                "domain": object["domain"],
                "id": object["id"],
                "namespace": object["namespace"],
                "cluster": object["cluster"],
                "region": object["region"],
                "year": yeardict
            }

            logger.debug(f'[DEBUG] - Changing collection to {os.getenv("COLLECTION_HISTORICAL")}')
            mg.change_collection(os.getenv("COLLECTION_HISTORICAL"))
            logger.debug(f'[DEBUG] - Quering historical collection for getting info of {object["id"]}')
            mongonamespace = mg.find_one({"id": object["id"]})
            updatedict = {}
            if mongonamespace != None:
                if currentyear not in str(mongonamespace["year"].keys()):
                    logger.info(f'[INFO] - {currentyear} is not in historical collection for {mongonamespace["id"]}. Updating mongo...')
                    mongonamespace["year"].update(yeardict)
                    updatedData = mg.update_one({"id": mongonamespace["id"]}, {"$set": {f'year': mongonamespace["year"]}})

                    if updatedData.modified_count == 1:
                            
                        logger.info(f'[INFO] - Namespace {mongonamespace["id"]}: year {currentyear} added in {mg._collection.name}')
                        updateResult = {
                            "yearupdated": True
                        }
                    else:
                        logger.error(f'[ERROR] - Namespace {mongonamespace["id"]}: year {currentyear} not added in {mg._collection.name}')
                        updateResult = {
                            "yearupdated": False
                        }
                    
                    updatedict.update(updateResult)


                elif currentmonth not in str(mongonamespace["year"][currentyear].keys()):
                    logger.info(f'[INFO] - {currentmonth} is not in historical collection for {mongonamespace["id"]}. Updating mongo...')
                    mongonamespace["year"][currentyear].update(monthsdict)
                    updatedData = mg.update_one({"id": mongonamespace["id"]}, {"$set": {f'year.{currentyear}': mongonamespace["year"][currentyear]}})

                    if updatedData.modified_count == 1:
                            
                        logger.info(f'[INFO] - Namespace {mongonamespace["id"]}: month {currentmonth} added in {mg._collection.name}')
                        updateResult = {
                            "monthupdated": True
                        }
                    else:
                        logger.error(f'[ERROR] - Namespace {mongonamespace["id"]}: month {currentmonth} not added in {mg._collection.name}')
                        updateResult = {
                            "monthupdated": False
                        }
                    
                    updatedict.update(updateResult)

            else:
                logger.info(f'[INFO] - {object["id"]} is not in historical collection. Adding it to mongo...')
                mg.add_data(historifydict)
            
            if True in updatedict.values():
                mg.update_one({"id": mongonamespace["id"]}, {"$set": {"timestamp": datetime.utcnow()}})
                logger.info(f'[INFO] - Timestamp updated for {mongonamespace["id"]}')

        logger.info(f'[INFO] - Process finished')

    else:
        logger.info("[INFO] - Today is not the first day of the month. Historification process won't be run")