import json
import aiohttp
import os

async def getinfofromknowledge(functional_environment,optionparameter,uid=None,domain=None):
    url_api = os.getenv("API_KNOWLEDGE_URL","http://shuttle-openshift-knowledge:8080")

    endpoint = os.getenv("API_KNOWLEDGE_PATH","/api/v1/knowledge")

    
    option = f'/{optionparameter}'

    body=None

    match optionparameter:
        case 'detaildevops': 
            body = {
                'uiddevops': uid
            }
        case 'detaildomain': 
            body = {
                'domain': domain
            }

    async with aiohttp.ClientSession() as session:
        async with session.post(url_api+endpoint+option, json=body, ssl=False) as resp:
            data = await resp.text()
            return json.loads(data)

async def getactivesnamespacesofdomain(functional_environment,domain):
    domaindetail = await getinfofromknowledge(functional_environment,'detaildomain',domain=domain)

    namespaceslistofdobjects = [x for x in domaindetail if 'Active' in str(x["cluster"])]
    namespaceslistofdomain = []
    for namespaceobject in namespaceslistofdobjects:
        namespacesactives = [{"name": namespaceobject["namespace"], "cluster": cluster["cluster"], "region": cluster["region"]} for cluster in namespaceobject["cluster"] if cluster["projectstatus"] == 'Active']

        namespaceslistofdomain.extend(namespacesactives)

    return namespaceslistofdomain