from darwin_composer.DarwinComposer import RouteClass
from ..handler.external_requests import writing

routers = [
    RouteClass(writing, ["v1"])
]
