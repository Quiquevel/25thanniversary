from fastapi import APIRouter
from src.services.percentages import getPercentages, getPercentages, getMetricsAverageCronJob
from src.services.historical_compliance import historifyCronJob
import urllib3
from pydantic import BaseModel

urllib3.disable_warnings()

writing = APIRouter(tags=["v1"])

class UpdateModel(BaseModel):
    functional_environment: str
    domainslist: list = None

@writing.post("/refreshdata", tags=["v1"], description="Update percentages manually", response_description="JSON", status_code=200)
async def refreshData(target: UpdateModel):
    return await getPercentages(functional_environment=target.functional_environment, domainslist=target.domainslist)

@writing.post("/CronjobPercentages", tags=["v1"], description="CronJob CronjobPercentages", response_description="JSON", status_code=200)
async def refreshData():
    return await getPercentages()

@writing.post("/MetricsAverageCronJob", tags=["v1"], description="CronJob MetricsAverageCronJob", response_description="JSON", status_code=200)
async def MetricsAverageCronJob():
    return await getMetricsAverageCronJob()

@writing.post("/historifyCronJob", tags=["v1"], description="CronJob historifyCronJob", response_description="JSON", status_code=200)
async def historifyCJ():
    return await historifyCronJob()


