import setuptools
from version import __version__

setuptools.setup(
    name = "scalebyfactor",
    version = __version__,
    author = "Carlos Murcia",
    author_email = "carlosfernando.murcia@gruposantander.com",
    description = "Microservice for scaling microservice by a factor",
    long_description = "Microservice for scaling microservice by a factor", 
    long_description_content_type = "text/markdown",
    url = "http://mypythonpackage.com",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
    ],
    python_requires = '>=3.13',
)
