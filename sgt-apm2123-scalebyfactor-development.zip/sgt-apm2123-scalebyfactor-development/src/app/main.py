from fastapi import FastAPI, WebSocket
from src.services.scaleReplicas import scaleCriticalWS
from darwin_composer.DarwinComposer import DarwinComposer  
from src.app.config.composer_config import config as composer_config
from src.resources.routers import routers



app = FastAPI(
                docs_url="/api/v1/docs",
                title="sgt-apm2123-scalebyfactor",
                version="1.0",
                openapi_url="/api/v1/openapi.json",
                contact={ "name" : "SRE CoE DevSecOps","email" : "SRECoEDevSecOps@gruposantander.com"},
              )


DarwinComposer(app, config=composer_config, routers=routers)

""" 
HTML for ws testing purposes 
"""
html = """
<!DOCTYPE html>
<html>
    <head>
        <title>Chat</title>
    </head>
    <body>
        <h1>WebSocket Prueba</h1>
        <form action="" onsubmit="sendMessage(event)">
            <input type="text" id="messageText" autocomplete="off"/>
            <button>Send</button>
        </form>
        <ul id='messages'>
        </ul>
        <script>
            var ws = new WebSocket("ws://localhost:8080/ws");
            ws.onmessage = function(event) {
                var messages = document.getElementById('messages')
                var message = document.createElement('li')
                var content = document.createTextNode(event.data)
                message.appendChild(content)
                messages.appendChild(message)
            };
            function sendMessage(event) {
                var input = document.getElementById("messageText")
                ws.send(input.value)
                input.value = ''
                event.preventDefault()
            }
        </script>
    </body>
</html>
"""


@app.websocket("/ws")
async def scale_replicasWS(websocket: WebSocket, token: str):
    await scaleCriticalWS(websocket, token)
