from version import __version__
from ..config import global_config

description = """
SCALE REPLICAS BY FACTOR

### SUMMARY
Microservice for scaling replicas by factor on the specified namespaces. Only critical microservices by default.


### ENDPOINTS
* **/getreplicas:** get replicas before scaling
* **/scaleprojects:**  scale projects passes on a list of namespaces (See Websocket info above)
* **/ongoingscaling:** get info about a scale process in progress 
* **/historicalscaling:**  get historical scaling
* **/switchonoff:** switch off o on a project --> set replicas to 0 or 1 on the deploymentsconfig of a project
* **/scalemicros:**  scale by factor microservices of a namespace

### PARAMETERS 

##/replicas
* **functionalEnvironment (mandatory):** dev,pre,pro
* **cluster (mandatory):** ohe,bks,probks,dmzbbks,azure,prodarwin,dmzbdarwin,confluent,proohe,dmzbohe
* **region (optional):** bo1,bo2,weu1,weu2
* **factor (mandatory):** factor to scale up replicas. Could be float to scale down
* **critical (mandatory):** Set this parameter to true or false (string) for scaling the microservice with this label (true by default)
* **namespace (optional):** Namespaces to scale

##/scaleprojects
* **functionalEnvironment (mandatory):** dev,pre,pro
* **cluster (mandatory):** ohe,bks,probks,dmzbbks,azure,prodarwin,dmzbdarwin,confluent,proohe,dmzbohe
* **region (optional):** bo1,bo2,weu1,weu2
* **namespaceList (mandatory):** list of namespaces to scale
* **factor (mandatory):** factor to scale up replicas. Could be float to scale down
* **sleepNamespacesTime (optional):** Optional parameter (in seconds) for waiting between namespaces (default: 30)
* **sleepMicrosTime (optional):** Optional parameter (in seconds) for waiting between microservices (default: 30)
* **critical (mandatory):** Set this parameter to true or false (string) for scaling the microservice with this label (true by default)
* **ldap (mandatory):** user for scaling. Only a devops is allowed to scale
* **retry (mandatory):** "False" if no retry is done.

##/ongoingscaling
* **traceId (mandatory):** traceId returned by the websocket

##/historicalscaling
* No parameters needed

##/switchonoff
* **functionalEnvironment (mandatory):** dev,pre,pro
* **cluster (mandatory):** ohe,bks,probks,dmzbbks,azure,prodarwin,dmzbdarwin,confluent,proohe,dmzbohe
* **region (optional):** bo1,bo2,weu1,weu2
* **namespaceList (mandatory):** list of namespaces to scale
* **switch (mandatory):** "on" or "off" to set replicas to 0 or 1 on the deploymentsconfig of a project list
* **sleepNamespacesTime (optional):** Optional parameter (in seconds) for waiting between namespaces (default: 30)
* **sleepMicrosTime (optional):** Optional parameter (in seconds) for waiting between microservices (default: 30)
* **ldap (mandatory):** user for scaling. Only a devops is allowed to scale

##/scalemicros
* **functionalEnvironment (mandatory):** dev,pre,pro
* **cluster (mandatory):** ohe,bks,probks,dmzbbks,azure,prodarwin,dmzbdarwin,confluent,proohe,dmzbohe
* **region (optional):** bo1,bo2,weu1,weu2
* **namespace (mandatory):** namespaces to scale
* **microsList (mandatory):** microservices to scale (only if the active condition parameter matches the service b-g or g-b)
* **factor (mandatory):** factor to scale up replicas. Could be float to scale down
* **active (mandatory):** "online" or "offline" to scale production or ocu microservices
* **sleepMicrosTime (optional):** Optional parameter (in seconds) for waiting between microservices (default: 30)
* **ldap (mandatory):** user for scaling. Only a devops is allowed to scale

##/scale_if_memory_leak
* **cluster (mandatory):** ohe,bks,probks,dmzbbks,ocp05azure,prodarwin,dmzbdarwin,confluent
* **region (optional):** bo1,bo2,weu1,weu2
* **namespaces_list (mandatory):** namespaces to scale
* **factor (mandatory):** factor to scale up replicas. Could be float to scale down
* **ldap (mandatory):** user for scaling. Only a devops is allowed to scale


    Detail by functionalEnvironment/cluster/region:\n\n
    "dev":
        "bks" - {"bo1"}
        "ohe" - {"bo1"}
        "azure"- {"weu1"}
    "pre":
        "bks": {"bo1","bo2"}
        "ohe": {"bo1","bo2"}
        "azure": {"weu1","weu2"}
    "pro":
        "prodarwin": {"bo1","bo2"}
        "dmzbdarwin": {"bo1","bo2"}
        "azure": {"weu1","weu2"}
        "confluent": {"bo1","bo2"}
        "proohe": {"bo1","bo2"}
        "dmzbohe": {"bo1","bo2"}
        "probks": {"bo1","bo2"}
        "dmzbbks": {"bo1","bo2"}

### REPO 
* [shuttle-scaling](https://github.alm.europe.cloudcenter.corp/sanes-shuttle/shuttle-openshift-scalebyfactor)
"""


config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "Scale by factor",
          "description": description,
          "contact": {
               "name": "Carlos Murcia",
               "url": "carlosfernando.murcia@gruposantander.com"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
