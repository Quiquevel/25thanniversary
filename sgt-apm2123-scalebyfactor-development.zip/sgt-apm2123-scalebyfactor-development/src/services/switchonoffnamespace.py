from src.services.client import client
from shuttlelib.utils.logger import logger
from shuttlelib.middleware.authorization import is_authorized_user
from fastapi import HTTPException
import asyncio
from src.services.scaleReplicas import patchProject

async def getInfoAndScale(client,clusters,cluster,functional_environment,region,namespacesList,switch,sleepMicrosTime,sleepNamespacesTime):
    
    resultInfo = []
    
    for namespace in namespacesList:
        
        try:
            deployments =  await client.get_resource(resource="deploymentconfigs",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
        except:
            logger.error(f'deploymentconfigs couldn\'t be obtained')  

    

        resultMicros=[]
        anyMicroScaled = False
        for dc in deployments[region]["items"]:
            url = clusters[cluster][region]["url"]
            token = clusters[cluster][region]["token"]

            if switch == "on" and dc["spec"]["replicas"] == 0:
                replicasToBe = 1
                logger.info(f'switching on deploymentConfig {dc["metadata"]["name"]}')
                request_url=url+"/apis/apps.openshift.io/v1/namespaces/"+namespace+"/deploymentconfigs/"+dc["metadata"]["name"]
                headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close", "Content-Type": "application/merge-patch+json"}
                body = {
                    "spec": {
                        "replicas": replicasToBe }
                }                

            elif switch == "off":
                replicasToBe = 0
                logger.info(f'switching off deploymentConfig {dc["metadata"]["name"]}')
                request_url=url+"/apis/apps.openshift.io/v1/namespaces/"+namespace+"/deploymentconfigs/"+dc["metadata"]["name"]
                headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close", "Content-Type": "application/merge-patch+json"}
                body = {
                    "spec": {
                        "replicas": replicasToBe }
                }  
            
            answer=patchProject(request_url,headers,body)

            result = {
                "microservice": {dc["metadata"]["name"]},
                "answer": answer,
                "replicasToBe": replicasToBe
            }
            resultMicros.append(result)
            if answer == 200:
                anyMicroScaled = True
                if switch == "on" and sleepMicrosTime > 0 and dc != deployments[region]["items"][-1]:
                    logger.info(f'Waiting {sleepMicrosTime}s to continue with next micro...')
                    await asyncio.sleep(sleepMicrosTime)
            else:
                logger.debug(f'{cluster}{region}-{namespace}: {dc["metadata"]["name"]} not scaled.')

        if anyMicroScaled == True:
            resultInfo.append({"cluster": cluster,"region":region,"namespace": namespace, "microservices": resultMicros})
            if sleepNamespacesTime > 0 and switch == "on":
                logger.info(f'Waiting {sleepNamespacesTime}s to continue with next namespace...')
                await asyncio.sleep(sleepNamespacesTime)


    if resultInfo == []:
        resultInfo = [{
            "cluster": cluster+region,
            "result": "Namespaces not scaled"
        }]

    return resultInfo

        
async def switchOnOff(cluster,ldap,auth,namespacesList,switch="on",functional_environment="pro",region=None,sleepMicrosTime=0,sleepNamespacesTime=0):

    devops = await is_authorized_user(token=auth, uid=ldap, almteam="sanes_aiops")
    #Bypass test user
    if ldap == "x021096":
        devops == True
    if devops == False:
        return HTTPException(status_code=401, detail="User not authorized")    

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)

    resultList = []

    if region:
        resultList.extend(await getInfoAndScale(client,clusters,cluster,functional_environment,region,namespacesList,switch,sleepMicrosTime,sleepNamespacesTime))
    else:
        for region in list(clusters[cluster].keys()):
            resultList.extend(await getInfoAndScale(client,clusters,cluster,functional_environment,region,namespacesList,switch,sleepMicrosTime,sleepNamespacesTime))

    return resultList