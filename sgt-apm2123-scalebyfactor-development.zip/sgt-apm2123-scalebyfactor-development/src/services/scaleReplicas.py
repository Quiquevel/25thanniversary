from src.services.client import client
from shuttlelib.utils.logger import logger
from shuttlelib.db.mongo import MongoClient
from shuttlelib.middleware.authorization import is_authorized_user
import asyncio
import aiohttp
import uuid
import os

#loop = asyncio.get_event_loop()

async def patchProject(url,headers,body):
    try:
        async with aiohttp.ClientSession() as session:
                async with session.patch(url, headers=headers,json=body ,ssl=True,timeout=aiohttp.ClientTimeout(total=15,connect=10)) as r:
                    if r.status == 200:
                        return r.status
                    else: 
                        logger.error(f'Could not be scaled {r.status}')
                        return r.status
    except asyncio.TimeoutError:
        logger.error(f'Timeout patching data to {url}')
        return 408  # Request Timeout
    except aiohttp.ClientError as e:
        logger.error(f'Client error patching data: {e}')
        return 502  # Bad Gateway o lo que quieras mapear
    except Exception as e:
        logger.error(f'Unexpected error patching data: {e}')
        return 500

async def scaleReplicas(url,token,namespace,dc,factor,hpa=None):
    
    if hpa:
        hpaName=hpa["metadata"]["name"]
        minReplicasActual=hpa["spec"]["minReplicas"]
        minReplicasToBe=int(minReplicasActual*float(factor))
        
        if minReplicasToBe < 1:
            minReplicasToBe = 1

        maxReplicasActual=hpa["spec"]["maxReplicas"]
        maxReplicasToBe=int(minReplicasActual*float(factor))
        logger.info(f'Scaling replicas by factor x{factor} on hpa object {hpaName}')
        request_url=url+"/apis/autoscaling/v1/namespaces/"+namespace+"/horizontalpodautoscalers/"+hpaName
        headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close", "Content-Type": "application/merge-patch+json"}
        body = {
            "spec": {
                "minReplicas": minReplicasToBe,
                "maxReplicas": maxReplicasToBe,
            }
        }
        info = {
            "HPA": "True",
            "replicasMinBefore": minReplicasActual,
            "replicasMinAfter": minReplicasToBe,
            "replicasMaxBefore": maxReplicasActual,
            "replicasMaxAfter": maxReplicasToBe,
        }

    else:
        replicasActual=dc["spec"]["replicas"]
        replicasToBe=int(replicasActual*float(factor))
        
        if replicasToBe < 1:
            replicasToBe = 1

        logger.info(f'Scaling replicas by factor x{factor} on deploymentConfig {dc["metadata"]["name"]}')
        request_url=url+"/apis/apps.openshift.io/v1/namespaces/"+namespace+"/deploymentconfigs/"+dc["metadata"]["name"]
        headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close", "Content-Type": "application/merge-patch+json"}
        body = {
            "spec": {
                "replicas": replicasToBe }
        }
        info = {
            "HPA": "False",
            "replicasBefore": replicasActual,
            "replicasAfter": replicasToBe,
        }        
    
    answer=await patchProject(request_url,headers,body)
    return (answer, info)

def getMicrosOnline(region,services):

    microsonline = []
    microsoffline = []

    for svc in services[region]["items"]:
        svcName = svc["metadata"]["name"]
        match svcName[:3]:
            case "b-g":
                try:
                    microsonline.append(svc["spec"]["selector"]["app_name"])
                except KeyError:
                    try: 
                        microsonline.append(svc["spec"]["selector"]["deploymentconfig"])
                        logger.error(f'Service {svcName} is using deploymentconfig selector instead of app_name')
                    except KeyError:
                        logger.error(f'Service {svcName} is not using deploymentconfig selector nor app_name')

            case "g-b":
                try:
                    microsoffline.append(svc["spec"]["selector"]["app_name"])
                except KeyError:
                    try:
                        microsoffline.append(svc["spec"]["selector"]["deploymentconfig"])
                        logger.error(f'Service {svcName} is using deploymentconfig selector instead of app_name')
                    except KeyError:
                        logger.error(f'Service {svcName} is not using deploymentconfig selector nor app_name')     

    return microsonline,microsoffline

def getDCsWithHPA(region,hpas):
    try:
        hpasElements = hpas[region]["items"]
        DClistWithHPA = [hpa["spec"]["scaleTargetRef"]["name"] for hpa in hpasElements]
    except:
        hpasElements = []
        DClistWithHPA = []
    
    return hpasElements,DClistWithHPA

async def scaleByPriority(url,token,namespace,dc,factor,DClistWithHPA,hpasElements,microsonline,critical):
    try:
        labelCritical = dc["metadata"]["labels"]["critical"]
    except:
        labelCritical = "false"
    
    dcName = dc["metadata"]["name"]

    match critical:
        case "true":
            if labelCritical == "true" and dcName in microsonline and dc["spec"]["replicas"] > 0:

                if dcName in DClistWithHPA:
                    answer,infoscale = await scaleReplicas(url,token,namespace,dc,factor,hpasElements[DClistWithHPA.index(dcName)])
                else:
                    answer, infoscale = await scaleReplicas(url,token,namespace,dc,factor)
                
                info={
                        "namespace": namespace,
                        "microservice": dcName,
                }
                info.update(infoscale)
            else:
                answer = 100
                message = f'Microservice  {dcName} is not critical, no service is routing to this micro or it has no replicas to scale'
                info={
                        "namespace": namespace,
                        "microservice": dcName,
                }

        case "false":
            if labelCritical == "false" and dcName in microsonline and dc["spec"]["replicas"] > 0:
                if dcName in DClistWithHPA:
                    answer,infoscale = scaleReplicas(url,token,namespace,dc,factor,hpasElements[DClistWithHPA.index(dcName)])
                else:
                    answer,infoscale= scaleReplicas(url,token,namespace,dc,factor)
                
                info={
                        "namespace": namespace,
                        "microservice": dcName,
                }
                info.update(infoscale)
            else:
                answer = 100
                message = f'Microservice  {dcName} is critical, no service is routing to this micro or it has no replicas to scale'
                info={
                        "namespace": namespace,
                        "microservice": dcName,
                }
    infoTotalWS = {
        "namespace": namespace,
        "microservice": dcName,        
    }
    if answer == 200:
        infoWS = {
            "answer": answer,
            "result": "Scaled"
        }
    elif answer == 100:
         infoWS = {
            "answer": answer,
            "result": "Not scaled",
            "reason": message
        }
    else:
        infoWS = {
            #"answer": answer,
            "answer": 409,
            "result": "Microservice could not be scaled",
            "reason": "Some problem happened"
        }
    infoTotalWS.update(infoWS)

    return (answer, info, infoTotalWS)

async def getInfoAndScaleWS(regionsnumber,websocket,traceID,client,clusters,cluster,functional_environment,region,namespacesList,factor,sleepNamespacesTime,sleepMicrosTime,critical):

    mg = MongoClient()
    if mg.server_info():
        # scalebyfactor must set an expiration_time of 72h
        os.environ['MONGO_EXPIRATION_TIME'] = os.getenv("SCALEBYFACTOR_EXP_TIME")
        #Once the expiration time is set, the default collection is changed for using scalebyfactor
        logger.info(f'Changing collection to {os.getenv("COLLECTION_SCALEBYFACTOR")}')        
        mg.change_collection(os.getenv("COLLECTION_SCALEBYFACTOR"))
        mg.expiration_manager()
    
    resultInfo = []
        
    for namespace in namespacesList:
        
        microsonline = []
        microsoffline = []

        try:
            services = await client.get_resource(resource="services",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
        except:
            logger.error(f'Services couldn\'t be obtained')
            continue
            #raise WebSocketException("Error al obtener servicios")
    
        if services[region]["status_code"] != 200:
            logger.error(f'Services of {namespace} could not be obtained. Reason: {services[region]["status_reason"]} ')
            continue

        microsonline, microsoffline = getMicrosOnline(region,services) 

        try:
            hpas = await client.get_resource(resource="hpas",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
        except:
            logger.error(f'HPAs couldn\'t be obtained')
            continue

        if hpas[region]["status_code"] != 200:
            logger.error(f'HPAs of {namespace} could not be obtained. Reason: {hpas[region]["status_reason"]} ')
            continue

        hpasElements,DClistWithHPA = getDCsWithHPA(region,hpas)

        try:
            deployments =  await client.get_resource(resource="deployments",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
        except:
            logger.error(f'deployments couldn\'t be obtained')  

        if deployments[region]["status_code"] != 200:
            logger.error(f'Deployments of {namespace} could not be obtained. Reason: {deployments[region]["status_reason"]} ')
            continue

        anyMicroScaled = False
        anwersCodesList = set()
        namespaceInProgress={
            "cluster": cluster,
            "region": region,
            "namespace": namespace,
            "answer": 102,
            "result": "scaling",
            "retry": False
        }
        await websocket.send_json(namespaceInProgress)
        if mg.server_info():
            logger.info("saving data in mongo")
            namespaceInProgress.update({
                "namespaceID": cluster+"-"+namespace,
                "traceID": traceID,
                "factor": factor,
                "critical": critical,                
                "region": {
                    region: {
                        "microservices": [],
                        "answer": 102,
                        "result": "scaling"
                    }
                }
            })
            dataExists=mg.find({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID})
            #No tenemos el count() ni count_documents() en la librería de mongo
            if len(list(dataExists)) > 0:
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.region.{region}.microservices': [], f'{functional_environment}.region.{region}.answer': 102,f'{functional_environment}.region.{region}.result': "scaling"}})
                #mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace},{"$push": {f'pro.region.{region}.microservices': []}})
            else:
                mg.add_data(namespaceInProgress, legacy=True)
        else:
            print(f'failed mongo connection')

        microsList = []
        for dc in deployments[region]["items"]:
            url = clusters[cluster][region]["url"]
            token = clusters[cluster][region]["token"]

            answer, info, infoMicroWS = await scaleByPriority(url,token,namespace,dc,factor,DClistWithHPA,hpasElements,microsonline,critical)
            result = {
                "cluster": cluster,
                "region": region
            }
            result.update(info)
            result.update({"answer": answer})
            resultInfo.append(result)
            anwersCodesList.add(answer)
            infoMicroWS.update(result)
            microsList.append({"microservice": dc["metadata"]["name"], "answer": answer})
            await websocket.send_json(infoMicroWS)
            if answer == 200:
                if dc != deployments[region]["items"][-1]:
                    if sleepMicrosTime > 0:
                        logger.info(f'Waiting {sleepMicrosTime}s to continue with next micro...')
                        await websocket.send_text(f'Waiting {sleepMicrosTime}s to continue with next micro...')
                        await asyncio.sleep(sleepMicrosTime)
                anyMicroScaled = True

            if mg.server_info():
                logger.info(f'adding micro {dc["metadata"]["name"]} to mongo')
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$push": {functional_environment+".region."+region+".microservices": microsList[-1]}})

        infoTotalNamespaceWS = {
            "namespace": namespace,
            "cluster": cluster,
            "region": region,
            "retry": False            
        }

        if anyMicroScaled == True:
            infoNamespaceWS = {
                "answer": 200,
                "result": "Scaled"
            }
            mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.region.{region}.answer': 200}})
            infoTotalNamespaceWS.update(infoNamespaceWS)
            await websocket.send_json(infoTotalNamespaceWS)
            if mg.server_info():
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {functional_environment+".result": "Scaled"}})
            if sleepNamespacesTime > 0:
                if namespace != namespacesList[-1]:
                    logger.info(f'Waiting {sleepNamespacesTime}s to continue with next namespace...')
                    await websocket.send_text(f'Waiting {sleepNamespacesTime}s to continue with next namespace...')
                    await asyncio.sleep(sleepNamespacesTime)

        else:
            if any(x !=200 and x!=100 for x in anwersCodesList):
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.region.{region}.answer': 409}})
                infoNamespaceWS = {
                    #"answer": str(anwersCodesList),
                    "answer": 409,
                    "result": "Not scaled: Some problem happened"
                }
            elif len(anwersCodesList) == 1 and 100 in anwersCodesList:
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.region.{region}.answer': 100}})
                infoNamespaceWS = {
                    "answer": 100,
                    "result": "Not scaled: No microservices fulfilled the parameter conditions"
                }
            else:
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.region.{region}.answer': 409}})
                logger.error("Something horribly wrong happened")
                logger.debug("")
                infoNamespaceWS = {
                    #"answer": 500,
                    "answer": 409,
                    "result": "Not scaled: Something horribly wrong happened"
                }
        
            infoTotalNamespaceWS.update(infoNamespaceWS)

            await websocket.send_json(infoTotalNamespaceWS)

        mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.region.{region}.result': 'finished'}})
        if regionsnumber == 1:
            if 409 not in anwersCodesList:
                if anyMicroScaled == True:
                    mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 200}})
                else:
                    mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 100}})
            else:
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 409}})
        else:
            if region[-1] == '2':
                namespaceScaled=mg.find({"$and": [{functional_environment+".namespaceID": cluster+"-"+namespace}, {functional_environment+".traceID": traceID}, {"$or":[{f'{functional_environment}.region.{region[:-1]}1.answer': 409},{f'{functional_environment}.region.{region}.answer': 409}]}]})
                if len(list(namespaceScaled)) > 0:
                    mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 409}})
                else:
                    namespaceScaled=mg.find({"$and": [{functional_environment+".namespaceID": cluster+"-"+namespace}, {functional_environment+".traceID": traceID}, {"$or":[{f'{functional_environment}.region.{region[:-1]}1.answer': 200},{f'{functional_environment}.region.{region}.answer': 200}]}]})
                    if len(list(namespaceScaled)) > 0:
                        mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 200}})
                    else:
                        mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 100}})
                
        
    if resultInfo == []:
        resultInfo = [{
            "cluster": cluster,
            "region": region,
            "result": "No namespaces were scaled"
        }]
        await websocket.send_json({"cluster": cluster, "region": region, "result": "No namespaces were scaled"})

    return resultInfo

async def getInfoAndScaleMicrosWS(regionsnumber,websocket,traceID,client,clusters,cluster,functional_environment,region,namespace,microsretryList,factor,critical,sleepMicrosTime):

    mg = MongoClient()
    if mg.server_info():
        logger.info(f'Changing collection to {os.getenv("COLLECTION_SCALEBYFACTOR")}')        
        mg.change_collection(os.getenv("COLLECTION_SCALEBYFACTOR"))
    
    resultInfo = []
        
    try:
        hpas = await client.get_resource(resource="hpas",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
    except:
        logger.error(f'HPAs couldn\'t be obtained')

    if hpas[region]["status_code"] != 200:
        logger.error(f'HPAs of {namespace} could not be obtained. Reason: {hpas[region]["status_reason"]} ')

    hpasElements,DClistWithHPA = getDCsWithHPA(region,hpas)

    try:
        deployments =  await client.get_resource(resource="deployments",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
    except:
        logger.error(f'deployments couldn\'t be obtained')  

    if deployments[region]["status_code"] != 200:
        logger.error(f'Deployments of {namespace} could not be obtained. Reason: {deployments[region]["status_reason"]} ')

    anyMicroScaled = False
    anwersCodesList = set()
    namespaceInProgress={
        "cluster": cluster,
        "region": region,
        "namespace": namespace,
        "answer": 102,
        "result": "scaling",
        "retry": True    
    }
    await websocket.send_json(namespaceInProgress)
    if mg.server_info():
        mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.answer': 102, f'{functional_environment}.result': "scaling"}})
        mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.region.{region}.answer': 102,f'{functional_environment}.region.{region}.result': "scaling"}})

    else:
        logger.error(f'failed mongo connection')

    microsList = []
    for dc in deployments[region]["items"]:
        dcName=dc["metadata"]["name"]
        if any(dcName == x for x in microsretryList):
            url = clusters[cluster][region]["url"]
            token = clusters[cluster][region]["token"]

            answer, info, infoMicroWS = scaleByPriority(url,token,namespace,dc,factor,DClistWithHPA,hpasElements,microsretryList,critical)
            result = {
                "cluster": cluster,
                "region": region
            }
            result.update(info)
            result.update({"answer": answer})
            resultInfo.append(result)
            anwersCodesList.add(answer)
            infoMicroWS.update(result)
            microsList.append({"microservice": dcName, "answer": answer})
            await websocket.send_json(infoMicroWS)
            if answer == 200:
                if dcName != microsretryList[-1]:
                    if sleepMicrosTime > 0:
                        logger.info(f'Waiting {sleepMicrosTime}s to continue with next micro...')
                        await websocket.send_text(f'Waiting {sleepMicrosTime}s to continue with next micro...')
                        await asyncio.sleep(sleepMicrosTime)
                anyMicroScaled = True

            if mg.server_info():
                if answer != 409:
                    logger.info(f'Updating status code for micro {dcName}')
                    mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID, functional_environment+".region."+region+".microservices.microservice": dcName},{"$set": {functional_environment+".region."+region+".microservices.$.answer": answer}})

    infoTotalNamespaceWS = {
        "namespace": namespace,
        "cluster": cluster,
        "region": region
    }

    if anyMicroScaled == True and 409 not in anwersCodesList:
        infoNamespaceWS = {
            "answer": 200,
            "result": "Scaled",
            "retry": True
        }

        mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.region.{region}.answer': 200}})
        mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.region.{region}.result': "Scaled"}})        
        infoTotalNamespaceWS.update(infoNamespaceWS)
        await websocket.send_json(infoTotalNamespaceWS)

    else:
        if 409 in anwersCodesList:
            mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished',f'{functional_environment}.region.{region}.answer': 409}})
            infoNamespaceWS = {
                #"answer": str(anwersCodesList),
                "answer": 409,
                "result": "Not scaled: Some problem happened",
                "retry": True
            }
        elif len(anwersCodesList) == 1 and 100 in anwersCodesList:
            namespacemg = mg.find({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID})
            regionresponsecodesmg = set()
            for micro in namespacemg[functional_environment]["region"][region]["microservices"]:
                regionresponsecodesmg.add(micro["answer"])
                
            if any(x==200 for x in regionresponsecodesmg):
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished',f'{functional_environment}.region.{region}.answer': 200}})
                infoNamespaceWS = {
                    "answer": 200,
                    "result": "scaled",
                    "retry": True                
                }
            else:
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished',f'{functional_environment}.region.{region}.answer': 100}})
                infoNamespaceWS = {
                    "answer": 100,
                    "result": "Not scaled: No microservices fulfilled the parameter conditions",
                    "retry": True                
                }
        else:
            mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished',f'{functional_environment}.region.{region}.answer': 409}})
            logger.error("Something horribly wrong happened")
            logger.debug("")
            infoNamespaceWS = {
                #"answer": 500,
                "answer": 409,
                "result": "Not scaled: Something horribly wrong happened",
                "retry": True                
            }
    
        infoTotalNamespaceWS.update(infoNamespaceWS)

        await websocket.send_json(infoTotalNamespaceWS)

    namespacemg = mg.find({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID})
    namespaceresponsecodesmg = set()
    for objectmg in namespacemg:
        for regionmg in objectmg[functional_environment]["region"]:
            for micromg in objectmg[functional_environment]["region"][regionmg]["microservices"]:
                namespaceresponsecodesmg.add(micromg["answer"])

    if regionsnumber == 1:
        if 409 not in namespaceresponsecodesmg:
            if anyMicroScaled == True:
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 200}})
            else:
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 100}})
        else:
            mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 409}})
    else:
        if region[-1] == '2':
            namespaceScaled=mg.find({"$and": [{functional_environment+".namespaceID": cluster+"-"+namespace}, {functional_environment+".traceID": traceID}, {"$or":[{f'{functional_environment}.region.{region[:-1]}1.answer': 409},{f'{functional_environment}.region.{region}.answer': 409}]}]})
            if len(list(namespaceScaled)) > 0:
                mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 409}})
            else:
                namespaceScaled=mg.find({"$and": [{functional_environment+".namespaceID": cluster+"-"+namespace}, {functional_environment+".traceID": traceID}, {"$or":[{f'{functional_environment}.region.{region[:-1]}1.answer': 200},{f'{functional_environment}.region.{region}.answer': 200}]}]})
                if len(list(namespaceScaled)) > 0:
                    mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 200}})
                else:
                    mg.update_one({functional_environment+".namespaceID": cluster+"-"+namespace, functional_environment+".traceID": traceID},{"$set": {f'{functional_environment}.result': 'finished', f'{functional_environment}.answer': 100}})
            
    
    if resultInfo == []:
        resultInfo = [{
            "cluster": cluster,
            "region": region,
            "result": "No namespaces were scaled"
        }]
        await websocket.send_json({"cluster": cluster, "region": region, "result": "No namespaces were scaled"})

    return resultInfo

async def getInfoAndScale(client,clusters,cluster,functional_environment,region,namespacesList,factor,sleepNamespacesTime,sleepMicrosTime,critical):
    
    resultInfo = []
    
    if namespacesList == None:
        try:
            namespaces = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
            namespacesList = namespaces[region]["items"]
        except aiohttp.client_exceptions.ServerTimeoutError:
            logger.error(f"Timeout detected against {functional_environment+cluster+region}")
        except:
            logger.error(f"Error different from Timeout")
        
    for namespace in namespacesList:
        
        microsonline = []
        microsoffline = []

        try:
            services = await client.get_resource(resource="services",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
        except:
            logger.error(f'Services couldn\'t be obtained')
            continue
    
       
        microsonline, microsoffline = getMicrosOnline(region,services) 

        try:
            hpas = await client.get_resource(resource="hpas",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
        except:
            logger.error(f'HPAs couldn\'t be obtained')
            continue

      
        hpasElements,DClistWithHPA = getDCsWithHPA(region,hpas)

        try:
            deployments =  await client.get_resource(resource="deploymentconfigs",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
        except:
            logger.error(f'deploymentconfigs couldn\'t be obtained')  

        anyMicroScaled = False
        resultMicros=[]
        for dc in deployments[region]["items"]:
            url = clusters[cluster][region]["url"]
            token = clusters[cluster][region]["token"]

            answer, info, infoTotalWS = scaleByPriority(url,token,namespace,dc,factor,DClistWithHPA,hpasElements,microsonline,critical)
            result = {
                "cluster": cluster,
                "region": region
            }
            result.update(info)
            result.update({"answer": answer})
            del result["cluster"], result ["namespace"]
            resultMicros.append(result)
            if answer == 200:
                anyMicroScaled = True
                if sleepMicrosTime > 0 and dc != deployments[region]["items"][-1]:
                    logger.info(f'Waiting {sleepMicrosTime}s to continue with next micro...')
                    await asyncio.sleep(sleepMicrosTime)
            else:
                logger.debug(f'{cluster}{region}-{namespace}: {dc["metadata"]["name"]} not scaled.')
                    
        if anyMicroScaled == True:
            resultInfo.append({"cluster": cluster,"region":region,"namespace": namespace, "microservices": resultMicros})
            if sleepNamespacesTime > 0:
                logger.info(f'Waiting {sleepNamespacesTime}s to continue with next namespace...')
                await asyncio.sleep(sleepNamespacesTime)

    if resultInfo == []:
        resultInfo = [{
            "cluster": cluster,
            "region": region,
            "result": "No namespaces were scaled"
        }]

    return resultInfo

'''
        await manager.connect(websocket: WebSocket)
        try:
            while True:
                data = await websocket.receive_text()
        except WebSocketDisconnect:
            manager.disconnect(websocket)
        
        #DEVOLVER POR WEBSOCKET EL RESULTADO DEL ESCALADO DEL NAMESPACE
'''
        
async def scaleCriticalAPI(cluster,ldap,auth,functional_environment="pro",region=None,namespacesList=None,factor=2,sleepNamespacesTime=0,sleepMicrosTime=0,critical="true"):

    devops = await is_authorized_user(token=auth, uid=ldap, almteam="sanes_aiops")
    #Bypass test user
    if ldap == "x021096":
        devops == True
    if devops == False:
        return HTTPException(status_code=401, detail="User not authorized")    

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)

    resultList = []

    if region:
        resultList.extend(await getInfoAndScale(client,clusters,cluster,functional_environment,region,namespacesList,factor,sleepNamespacesTime,sleepMicrosTime,critical))
    else:
        for region in list(clusters[cluster].keys()):
            resultList.extend(await getInfoAndScale(client,clusters,cluster,functional_environment,region,namespacesList,factor,sleepNamespacesTime,sleepMicrosTime,critical))

    return resultList

async def retryscalemicrosWS(websocket,traceID,namespace):

    functional_environment = "pro"
    sleepMicrosTime="3"

    mg = MongoClient()
    if mg.server_info():
        logger.info(f'Changing collection to {os.getenv("COLLECTION_SCALEBYFACTOR")}')        
        mg.change_collection(os.getenv("COLLECTION_SCALEBYFACTOR"))

    datastored=mg.find({f'{functional_environment}.traceID': traceID, f'{functional_environment}.namespace': namespace})

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)

    resultList = []
    microstoretry=[]
    for object in datastored:
        regionnumbers = len(object[functional_environment]["region"].keys())
        for regionmg in object[functional_environment]["region"]:
            for micro in object[functional_environment]["region"][regionmg]["microservices"]:
                if micro["answer"] == 409:
                    microstoretry.append(micro["microservice"])

            resultList.extend(await getInfoAndScaleMicrosWS(regionnumbers,websocket,traceID,client,clusters,object[functional_environment]["cluster"],functional_environment,regionmg,namespace,microstoretry,object[functional_environment]["factor"],object[functional_environment]["critical"],sleepMicrosTime))

    return resultList
class ScalingModel(BaseModel):
    functional_environment: str
    cluster: str
    region: str = None
    namespacesList: list
    factor: float
    sleepNamespacesTime: int = None
    sleepMicrosTime: int = None
    critical: str = None
    ldap: str

    @validator("functional_environment")
    def validate_environment(cls, v):
        if not any(x == v for x in ["dev","pre","pro"]):
            raise WebSocketException(code=status.WS_1003_UNSUPPORTED_DATA,reason=f'{v} is not a valid value for functional_environment')
        return v
    
    @validator("cluster")
    def validate_cluster(cls, v):
        if not any(x == v for x in ["ohe","bks","probks","dmzbbks","ohe","probks","dmzbbks","azure","prodarwin","dmzbdarwin","proohe","dmzbohe","confluent"]):
            raise WebSocketException(code=status.WS_1003_UNSUPPORTED_DATA,reason=f'{v} is not a valid value for cluser')
        return v

    @validator("critical")
    def validate_critical(cls, v):
        if not any(x == v for x in ["true","false"]):
            raise WebSocketException(code=status.WS_1003_UNSUPPORTED_DATA,reason=f'{v} is not a valid value for critical')
        return v

async def scaleCriticalWS(websocket, token):

    await websocket.accept()
    while True:
        
        entrydata = await websocket.receive_json()
        if entrydata["retry"] == "False":
            traceID = uuid.uuid4().hex
            await websocket.send_json({"traceID": traceID})        
            data = ScalingModel.parse_obj(entrydata)

            devops = await is_sre_coe_devsecops(token=token, uid=data.ldap)
            #Bypass test user
            if data.ldap == "x021096":
                devops == True
            if devops == False:
                logger.error(f'User {data.ldap} is not an authorized user for scaling')
                raise WebSocketException(code=status.WS_1008_POLICY_VIOLATION,reason=f'User {data.ldap} not authorized for scaling replicas')

            clusters = await client.get_resource(resource="clusters",functional_environment=data.functional_environment,cluster=None)

            resultList = []
            
            if data.region:
                regionsnumber=1
                resultList.extend(await getInfoAndScaleWS(regionsnumber,websocket,traceID,client,clusters,data.cluster,data.functional_environment,data.region,data.namespacesList,data.factor,data.sleepNamespacesTime,data.sleepMicrosTime,data.critical))
            else:
                regionsnumber=2
                for region in list(clusters[data.cluster].keys()):
                    resultList.extend(await getInfoAndScaleWS(regionsnumber,websocket,traceID,client,clusters,data.cluster,data.functional_environment,region,data.namespacesList,data.factor,data.sleepNamespacesTime,data.sleepMicrosTime,data.critical)) 
            
            logger.info(f'scaling process finished!')
            await websocket.send_text(f'Finished')

        elif entrydata["retry"] == "True":
            await retryscalemicrosWS(websocket,entrydata["traceID"],entrydata["namespace"])
            
            logger.info(f'scaling process finished!')
            await websocket.send_text(f'Finished')


            #IDLE-TIMEOUT PARA CERRAR WEBSOCKET