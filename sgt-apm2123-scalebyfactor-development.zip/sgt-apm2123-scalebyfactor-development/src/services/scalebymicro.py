from src.services.client import client
from shuttlelib.utils.logger import logger
from shuttlelib.middleware.authorization import is_authorized_user
from fastapi import HTTPException
import asyncio
from src.services.scaleReplicas import getDCsWithHPA, getMicrosOnline, scaleReplicas

def scaleByPriority(url,token,namespace,dc,factor,DClistWithHPA,hpasElements,microsToScale):
    
    dcName = dc["metadata"]["name"]

    if dcName in microsToScale and dc["spec"]["replicas"] > 0:

        if dcName in DClistWithHPA:
            answer,infoscale = scaleReplicas(url,token,namespace,dc,factor,hpasElements[DClistWithHPA.index(dcName)])
        else:
            answer, infoscale = scaleReplicas(url,token,namespace,dc,factor)
        
        info={
                "namespace": namespace,
                "microservice": dcName,
        }
        info.update(infoscale)
    else:
        answer = 100
        message = f'Microservice  {dcName} has no replicas to scale'
        info={
                "namespace": namespace,
                "microservice": dcName,
        }


    infoTotalWS = {
        "namespace": namespace,
        "microservice": dcName,        
    }
    if answer == 200:
        infoWS = {
            "answer": answer,
            "result": "Scaled"
        }
    elif answer == 100:
         infoWS = {
            "answer": answer,
            "result": "Not scaled",
            "reason": message
        }
    else:
        infoWS = {
            "answer": answer,
            "result": "Microservice could not be scaled",
            "reason": "Some problem happened"
        }
    infoTotalWS.update(infoWS)

    return (answer, info, infoTotalWS)


async def getInfoAndScale(client,clusters,cluster,functional_environment,region,namespace,microsList,active,factor,sleepMicrosTime):
    
    microsonline = []
    microsoffline = []

    try:
        services = await client.get_resource(resource="services",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
    except:
        logger.error(f'Services couldn\'t be obtained')


    microsonline, microsoffline = getMicrosOnline(region,services) 

    try:
        hpas = await client.get_resource(resource="hpas",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
    except:
        logger.error(f'HPAs couldn\'t be obtained')

    hpasElements,DClistWithHPA = getDCsWithHPA(region,hpas)

    try:
        deployments =  await client.get_resource(resource="deploymentconfigs",functional_environment=functional_environment,cluster=cluster,namespace=namespace,region=region)
    except:
        logger.error(f'deploymentconfigs couldn\'t be obtained')  



    resultMicros=[]

    for micro in microsList:
    
        for dc in deployments[region]["items"]:
            if dc['metadata']['name'] == micro:
                url = clusters[cluster][region]["url"]
                token = clusters[cluster][region]["token"]

                if active == "online":
                    answer, info, infoTotalWS = scaleByPriority(url,token,namespace,dc,factor,DClistWithHPA,hpasElements,microsonline)
                elif active == "offline":
                        answer, info, infoTotalWS = scaleByPriority(url,token,namespace,dc,factor,DClistWithHPA,hpasElements,microsoffline)
                
                result = {
                    "cluster": cluster+region
                }
                result.update(info)
                result.update({"answer": answer})
                del result["cluster"], result ["namespace"]
                resultMicros.append(result)
                if answer == 200:
                    if sleepMicrosTime > 0 and dc != deployments[region]["items"][-1]:
                        logger.info(f'Waiting {sleepMicrosTime}s to continue with next micro...')
                        await asyncio.sleep(sleepMicrosTime)
                else:
                    logger.debug(f'{cluster}{region}-{namespace}: {dc["metadata"]["name"]} not scaled.')
                
    if resultMicros == []:
        resultMicros = [{
            "cluster": cluster+region,
            "result": "Namespaces not scaled"
        }]

    return resultMicros

        
async def scalemicrosAPI(cluster,ldap,auth,namespace,microsList,active,functional_environment="pro",region=None,factor=2,sleepMicrosTime=0):

    devops = await is_authorized_user(token=auth, uid=ldap, almteam="sanes_aiops")
    #Bypass test user
    if ldap == "x021096":
        devops == True
    if devops == False:
        return HTTPException(status_code=401, detail="User not authorized")    

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)

    resultList = []

    if region:
        resultList.extend(await getInfoAndScale(client,clusters,cluster,functional_environment,region,namespace,microsList,active,factor,sleepMicrosTime))
    else:
        for region in list(clusters[cluster].keys()):
            resultList.extend(await getInfoAndScale(client,clusters,cluster,functional_environment,region,namespace,microsList,active,factor,sleepMicrosTime))

    return resultList