from shuttlelib.utils.logger import logger
from shuttlelib.db.mongo import MongoClient
from src.services.scalebymicro import getInfoAndScaleMicrosWS
from src.services.client import client

async def retryscalemicrosWS(traceID):

    functional_environment = "pro"
    sleepMicrosTime="3"

    mg = MongoClient()
    datastored=mg.find({f'{functional_environment}.traceID': traceID})

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)

    resultList = []
    microstoretry=[]
    for object in datastored:
        for regionmg in object[functional_environment]["region"]:
            for micro in object[functional_environment]["region"][regionmg]["microservices"]:
                if micro["answer"] == "409":
                    microstoretry.append(micro["microservice"])

            resultList.extend(await getInfoAndScaleMicrosWS(client,clusters,object[functional_environment]["cluster"],functional_environment,regionmg,object[functional_environment]["namespace"],microstoretry,object[functional_environment]["factor"],object[functional_environment]["critical"],sleepMicrosTime))

    return resultList