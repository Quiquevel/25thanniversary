from shuttlelib.utils.logger import logger
import aiohttp, json, os, asyncio
from shuttlelib.middleware.authorization import is_authorized_user
from src.services.client import client
from src.services.mail import create_mail, sendemailnotification
from collections import defaultdict

async def patch_project(url,headers,body):

    try:
        async with aiohttp.ClientSession() as session:
                async with session.patch(url, headers=headers,json=body ,ssl=True,timeout=aiohttp.ClientTimeout(total=15,connect=10)) as r:
                    if r.status == 200:
                        return r.status
                    else: 
                        logger.error(f'Could not be scaled {r.status}')
                        return r.status
    except asyncio.TimeoutError:
        logger.error(f'Timeout patching data to {url}')
        return 408  # Request Timeout
    except aiohttp.ClientError as e:
        logger.error(f'Client error patching data: {e}')
        return 502  # Bad Gateway o lo que quieras mapear
    except Exception as e:
        logger.error(f'Unexpected error patching data: {e}')
        return 500

async def scale_replicas(info_cluster,namespace,micro,factor):

    url = info_cluster["url"]
    token = info_cluster["token"]

    outputdict = {
        "namespace": namespace,
        "micro": micro["microservice"]
    }

    if micro["base_replicas"] != None:
        replicas_actual=micro["base_replicas"]
        replicas_to_be=int(replicas_actual*float(factor))
        
        if replicas_to_be < 1:
            replicas_to_be = 1

        logger.info(f'Scaling replicas by factor x{factor} on deployments {micro["microservice"]}')
        request_url=url+"/apis/apps/v1/namespaces/"+namespace+"/deployments/"+micro["microservice"]
        headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close", "Content-Type": "application/merge-patch+json"}
        body = {
            "spec": {
                "replicas": replicas_to_be }
        }
        
        replicas_dict = {
            "HPA": False,
            "replicas_before": replicas_actual,
            "replicas_after": replicas_to_be
        }

    else:
        #response = await duplicate_min_max_replicas(cluster,namespace,micro)
    
        hpa_name=micro["HPA_Name"]
        min_replicas_actual=micro["HPA_MINReplicas"]
        max_replicas_actual=micro["HPA_MAXReplicas"]
        min_replicas_to_be=int(min_replicas_actual*float(factor))
        max_replicas_to_be=int(max_replicas_actual*float(factor))
        
        if min_replicas_to_be < 1:
            min_replicas_to_be = 1

        logger.info(f'Scaling replicas by factor x{factor} on hpa object {hpa_name}')
        request_url=url+"/apis/autoscaling/v2/namespaces/"+namespace+"/horizontalpodautoscalers/"+hpa_name
        headers = {"Authorization": "Bearer " + token, "Accept": "application/json", "Connection": "close", "Content-Type": "application/merge-patch+json"}
        body = {
            "spec": {
                "minReplicas": min_replicas_to_be,
                "maxReplicas": max_replicas_to_be,
            }
        }

        replicas_dict = {
            "HPA": True,
            "hpa_name": hpa_name,
            "replicas_min_before": min_replicas_actual,
            "replicas_max_before": max_replicas_actual,
            "replicas_min_after": min_replicas_to_be,
            "replicas_max_after": max_replicas_to_be,
        }
    
    answer= await patch_project(request_url,headers,body)

    outputdict.update(replicas_dict)
    outputdict.update({"status_code": answer})

    return outputdict


async def get_memory_leak_micros(cluster,region,namespace=None):
    
    flag = os.getenv("B_G_MODEL_BOOL_FLAG", "false").lower()
    b_g_model = flag in ("1", "true", "yes")
   
    url_api = os.getenv("API_URL")
    endpoint = os.getenv("API_ENDPOINT")
    path = os.getenv("API_MEMORY_LEAK_PATH")

    body = {
        "cluster": cluster,
        "region": region,
        "b_g_model": b_g_model
    }

    if namespace != None:
        body.update({"namespace": namespace})

    async with aiohttp.ClientSession() as session:
        async with session.post(url_api+endpoint+path, json=body, ssl=False) as resp:
            if resp.status == 200:
                data = await resp.text()
                formatted_data = json.loads(data)
                return resp.status,formatted_data
            else:
                logger.error(f'Error getting memoryleak micros: {resp.status}')
                return resp.status, None

async def register_actions(ldap,environment,cluster,region,namespace,microservices_list,up_down,factor,final_status_code):
    
    url_api = os.getenv("API_HISTORICAL_TRACE_URL")
    endpoint = os.getenv("API_HISTORICAL_TRACE_ENDPOINT")
    path = os.getenv("API_HISTORICAL_TRACE_PATH")

    body = {
        "environment": environment,
        "ldap": ldap,
        "cluster": cluster,
        "namespace": namespace,
        "application": "scalebyfactor",
        "http_status": str(final_status_code),
        "operation": f'scale {up_down} replicas',
        "detail_text": f'Replicas were scaled by a factor of {factor} due to a Memory Leak',
        "openshift_detail": [
            {
            "data": microservices_list,
            "region": region,
            }
        ]
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url_api+endpoint+path, json=body, ssl=False) as resp:
            if resp.status == 200:
                data = await resp.text()
                formatted_data = json.loads(data)
                return resp.status,formatted_data
            else:
                logger.error(f'Error registering actions: {resp.status}')
                return resp.status, None

async def group_data_by_namespace(microservices):
    
    grouped = defaultdict(lambda: {"microservices": []})

    for item in microservices:
        key = item["namespace"]

        grouped[key]["namespace"] = item["namespace"]

        if item["HPA"]:
            micro = {
                "micro_name": item["micro"],
                'hpa': True,
                'hpa_name': item['hpa_name'],
                'replicas_min_before': item["replicas_min_before"],
                'replicas_max_before': item["replicas_max_before"],
                'replicas_min_after': item["replicas_min_after"],
                'replicas_max_after': item["replicas_max_after"],
                'status': item["status_code"]
            }
        else:
            micro = {
                "micro_name": item["micro"],
                'hpa': False,
                'replicas_before': item["replicas_before"],
                'replicas_after': item["replicas_after"],
                'status': item["status_code"]
            }            


        grouped[key]["microservices"].append(micro)

    return list(grouped.values())

async def get_final_status(response_set):
    if not response_set:
        final_status_code = 204
    else:
        if response_set == {200}:
            final_status_code = 200
        elif 200 in response_set:
            final_status_code = 206
        else:
            final_status_code = max(response_set)
    
    return final_status_code

async def send_mail_and_register_actions(data,ldap,environment,cluster,region,factor,final_status_code):
    html_mail_content = await create_mail(cluster,region,factor,data)
    up_down = "up" if factor >= 1 else "down"
    mail_subject = f'[{environment.upper()}] {cluster.upper()}-{region.upper()}: Replicas scaled {up_down}: x{factor}'
    
    logger.debug('Sending mail notification')
    await sendemailnotification(subject=mail_subject,htmlcontent=html_mail_content)

    data_grouped = await group_data_by_namespace(data)
    
    for namespace in data_grouped:
        namespace_name = namespace["namespace"]
        microservices = namespace["microservices"]

        logger.debug('Registering data in historical trace database')
        await register_actions(ldap=ldap,environment=environment,namespace=namespace_name,cluster=cluster,region=region,microservices_list=microservices,up_down=up_down,factor=factor,final_status_code=final_status_code)

async def scale_micros_memory_leak(cluster,region,factor,ldap,auth,namespaces_list=None):

    logger.debug(f'Checking if user {ldap} is authorized')
    #Bypass test user
    if ldap != "x021096":
        is_sre = await is_authorized_user(token=auth.credentials, uid=ldap, almteam="sanes_aiops")

        if is_sre == False:
            raise HTTPException(status_code=403, detail="User not authorized")

    outputlist = []

    functional_environment = os.getenv("ENVIRONMENT")

    info_all_clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)
    info_cluster = info_all_clusters[cluster][region]
    
    api_data = []

    if namespaces_list: 
        logger.debug(f'There is a list of namespaces, so we get memory leak micros only for them: {namespaces_list}')
        for namespace in namespaces_list:
            response_code, response_info = await get_memory_leak_micros(cluster=cluster,region=region,namespace=namespace)
            if response_code != 200:
                raise HTTPException(status_code=response_code, detail="There was a problem getting memory leak microservices")

            api_data.extend(response_info)

    else:
        logger.debug('Getting memory leak micros for every namespace in cluster')
        response_code, api_data = await get_memory_leak_micros(cluster=cluster,region=region)
        if response_code != 200:
            raise HTTPException(status_code=response_code, detail="There was a problem getting memory leak microservices")
    
    memory_leak_microservices = [{
        "namespace": element.get("namespace"),
        "microservice": element.get("microservice"),
        "base_replicas": element.get("replicasBase"),
        "HPA_Name": element.get("HPA_Name"),
        "HPA_MINReplicas": element.get("HPA_MINReplicas"),
        "HPA_MAXReplicas": element.get("HPA_MAXReplicas")
    } for element in api_data]
    
    response_set = set()
    for micro in memory_leak_microservices:
        namespace = micro["namespace"]
        response = await scale_replicas(info_cluster,namespace,micro,factor)
        response_set.add(response["status_code"])
        outputlist.append(response)

    final_status_code = await get_final_status(response_set)
       
    if outputlist != []:

        await send_mail_and_register_actions(data=outputlist,ldap=ldap,environment=functional_environment,cluster=cluster,region=region,factor=factor,final_status_code=final_status_code)

    return outputlist
        







