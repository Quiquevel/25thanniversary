from shuttlelib.utils.logger import logger
import shuttlelib.db.mongo as mongolib
from datetime import datetime

def getMemory(memory):
    if memory != None:
        if "Ki" in memory:
            memory = int(memory[:-2])*2**10                
        elif "Mi" in memory:
            memory = int(memory[:-2])*2**20
        elif "Gi" in memory:
            memory = int(memory[:-2])* 2**30
        elif "Ti" in memory:
            memory = int(memory[:-2])* 2**40           
        elif "K" in memory or "k" in memory:
            memory = int(memory[:-1])*1000
        elif "M" in memory or "m" in memory:
            memory = int(memory[:-1])*1000*1000
        elif "G" in memory or "g" in memory:
            memory = int(memory[:-1])*1000*1000*1000
        elif "T" in memory:
            memory = int(memory[:-1])*1000*1000*1000*1000
        else:
            memory = int(memory)
    else:
        memory = 512000000

    return memory

async def getReplicasAPI(functional_environment,cluster,critical,factor,region=None,namespace=None):
    mg = mongolib.MongoClient()

    if namespace != None:
        if region == None:
            dataToCheck= mg.find({f'{functional_environment}.cluster': cluster, f'{functional_environment}.namespace': namespace, f'{functional_environment}.microservices.labels.critical': critical, f'{functional_environment}.microservices.productionBlock': 'production'})
        else:
            dataToCheck= mg.find({f'{functional_environment}.cluster': cluster, f'{functional_environment}.namespace': namespace, f'{functional_environment}.region': region, f'{functional_environment}.microservices.labels.critical': critical, f'{functional_environment}.microservices.productionBlock': 'production'})        
    else:    
        if region == None:
            dataToCheck= mg.find({f'{functional_environment}.cluster': cluster, f'{functional_environment}.microservices.labels.critical': critical, f'{functional_environment}.microservices.productionBlock': 'production'})
        else:
            dataToCheck= mg.find({f'{functional_environment}.cluster': cluster, f'{functional_environment}.region': region, f'{functional_environment}.microservices.labels.critical': critical, f'{functional_environment}.microservices.productionBlock': 'production'})

    infoToReturn = []
    for data in dataToCheck:
        lastUpdate = datetime.strftime(data["timestamp"],'%Y-%m-%d %H:%M:%S')
        infoBeforeList = []
        infoBeforeDict = {}
        replicaCounterAsIs=0
        minReplicaCounterToBe=0
        maxReplicaCounterToBe=0
        replicasNotScalables=0
        minMemoryInBytes=0
        maxMemoryInBytes=0
        memoryNotScalable=0
        for micro in data[functional_environment]["microservices"]:
            try:
                labelCritical = micro["labels"]["critical"]
            except:
                labelCritical = "false"
            
            memory=getMemory(micro["resources"]["memory"]["memLimit"])
            if labelCritical == critical and micro["productionBlock"] == "production":
                microservice={}
                if micro["hpa"] != None:
                    minReplicasAsIs = micro["hpa"]["minReplicas"]
                    maxReplicasAsIs = micro["hpa"]["maxReplicas"]
                    if minReplicasAsIs != 0:
                        microservice = {
                            "name": micro["microservice"],
                            "HPA": "true",
                            "minReplicasAsIs": minReplicasAsIs,
                            "minReplicasToBe": int(minReplicasAsIs*float(factor)),
                            "maxReplicasAsIs": maxReplicasAsIs,
                            "maxReplicasToBe": int(maxReplicasAsIs*float(factor)),
                        }
                        replicaCounterAsIs+=minReplicasAsIs
                        minReplicaCounterToBe+=int(minReplicasAsIs*float(factor))
                        maxReplicaCounterToBe+=int(maxReplicasAsIs*float(factor))

                        if memory != None:
                            minMemoryInBytes += int(memory*minReplicasAsIs*float(factor))
                            maxMemoryInBytes += int(memory*maxReplicasAsIs*float(factor))

                        else:
                            minMemoryInBytes += int(512000000*minReplicasAsIs*float(factor))
                            maxMemoryInBytes += int(512000000*maxReplicasAsIs*float(factor))


                else:
                    replicasAsIs = micro["replicas"]

                    if replicasAsIs != 0:
                        microservice = {
                            "name": micro["microservice"],
                            "HPA": "false",
                            "replicasAsIs": replicasAsIs,
                            "replicasToBe": int(replicasAsIs*float(factor)),
                        }
                        replicaCounterAsIs+=replicasAsIs
                        minReplicaCounterToBe+=int(replicasAsIs*float(factor))
                        maxReplicaCounterToBe=minReplicaCounterToBe #no hay autoescalado. lo mín y máx será igual.

                        memory=getMemory(micro["resources"]["memory"]["memLimit"])
                        if memory != None:
                            minMemoryInBytes += int(memory*replicasAsIs*float(factor))
                            maxMemoryInBytes += int(memory*replicasAsIs*float(factor))

                        else:
                            minMemoryInBytes += int(512000000*replicasAsIs*float(factor))
                            maxMemoryInBytes += int(512000000*replicasAsIs*float(factor))

                if microservice:
                    infoBeforeList.append(microservice)
                
            else:
                replicasNotScalables += micro["replicas"]
                if memory != None:
                    memoryNotScalable += memory*micro["replicas"]
                else:
                    memoryNotScalable += 512000000*micro["replicas"] #Default cluster value for undefined request memory

        bestCaseQuotaPercentageToBe = round((replicasNotScalables+minReplicaCounterToBe-replicaCounterAsIs+data[functional_environment]["quotas"]["podsNow"])/data[functional_environment]["quotas"]["podsMax"]*100)
        worstCaseQuotaPercentageToBe = round((replicasNotScalables+maxReplicaCounterToBe-replicaCounterAsIs+data[functional_environment]["quotas"]["podsNow"])/data[functional_environment]["quotas"]["podsMax"]*100)

        if bestCaseQuotaPercentageToBe > 100:
            enoughPodsQuota = False
            PodsFlag = "KO"
            PodsQuotaMessage = "Not enough Pods quota to scale"
        elif bestCaseQuotaPercentageToBe <= 100 and worstCaseQuotaPercentageToBe > 100:
            enoughPodsQuota = True
            PodsFlag = "Caution"
            PodsQuotaMessage = "CAUTION: Not enough Pods quota if hpa max scaling is needed"
        elif bestCaseQuotaPercentageToBe <= 100  and worstCaseQuotaPercentageToBe <= 100:
            enoughPodsQuota = True
            PodsFlag = "OK"
            PodsQuotaMessage = "Enough Pods quota to scale"            
        else:
            enoughPodsQuota = True

        namespacePodsQuota = {
            "currentPods": data[functional_environment]["quotas"]["podsNow"],
            "minTotalPodsToBe": replicasNotScalables+minReplicaCounterToBe-replicaCounterAsIs+data[functional_environment]["quotas"]["podsNow"],
            "maxTotalPodsToBe": replicasNotScalables+maxReplicaCounterToBe-replicaCounterAsIs+data[functional_environment]["quotas"]["podsNow"],
            "limitPods": data[functional_environment]["quotas"]["podsMax"],
            "quotaPercentagePodsAsIs": f'{data[functional_environment]["quotas"]["usedPodsQuotaPerc"]}%',
            "bestCaseQuotaPercentageToBe": f'{bestCaseQuotaPercentageToBe}%',
            "worstCaseQuotaPercentageToBe": f'{worstCaseQuotaPercentageToBe}%',
            "enoughPodsQuota": enoughPodsQuota,
            "AbleToScalePods": PodsFlag,
            "PodsQuotaMessage": PodsQuotaMessage
        }

        namespaceRCQuota ={
            "rcNow": data[functional_environment]["quotas"]["rcNow"],
            "rcMax": data[functional_environment]["quotas"]["rcMax"],
            "usedRcQuotaPerc": f'{data[functional_environment]["quotas"]["usedRcQuotaPerc"]}%'
        }

        memoryNow = getMemory(data[functional_environment]["quotas"]["memNowToShow"])
        memoryMax = getMemory(data[functional_environment]["quotas"]["memMaxToShow"])
        bestCaseMemQuotaPercentageToBe = round((memoryNow+memoryNotScalable+minMemoryInBytes)/memoryMax*100)
        worstCaseMemQuotaPercentageToBe = round((memoryNow+memoryNotScalable+maxMemoryInBytes)/memoryMax*100)

        if bestCaseMemQuotaPercentageToBe > 100:
            enoughMemQuota = False
            MemFlag = "KO"
            MemQuotaMessage = "Not enough Memory quota to scale"
        elif bestCaseMemQuotaPercentageToBe < 100 and worstCaseMemQuotaPercentageToBe > 100:
            enoughMemQuota = True
            MemFlag = "Caution"
            MemQuotaMessage = "CAUTION: Not enough Memory quota if hpa max scaling is needed"
        elif bestCaseMemQuotaPercentageToBe <= 100  and worstCaseMemQuotaPercentageToBe <= 100:
            enoughMemQuota = True
            MemFlag = "OK"
            MemQuotaMessage = "Enough Memory quota to scale"            
        else:
            enoughMemQuota = True

        namespaceMemQuota = {
            "usedMemory": data[functional_environment]["quotas"]["memNowToShow"],
            "limitMemory": data[functional_environment]["quotas"]["memMaxToShow"],
            "minMemoryToBe": str(round((memoryNow+memoryNotScalable+minMemoryInBytes) /2**30))+"Gi",
            "maxMemoryToBe": str(round((memoryNow+memoryNotScalable+maxMemoryInBytes) /2**30))+"Gi",
            "quotaPercentageMemAsIs": f'{data[functional_environment]["quotas"]["usedMemoryPerc"]}%',
            "bestCaseMemQuotaPercentageToBe": f'{bestCaseMemQuotaPercentageToBe}%',
            "worstCaseMemQuotaPercentageToBe": f'{worstCaseMemQuotaPercentageToBe}%',
            "enoughMemQuota": enoughMemQuota,
            "AbleToScaleMem": MemFlag,
            "MemQuotaMessage": MemQuotaMessage            
        }

        if infoBeforeList:
            infoBeforeDict.update({"id": data[functional_environment]["namespace"]+data[functional_environment]["region"]+cluster,"cluster": cluster, "region": data[functional_environment]["region"], "namespace": data[functional_environment]["namespace"], "infoBefore": infoBeforeList, "replicasNamespaceAsIs": replicaCounterAsIs, "minReplicasNamespaceToBe": minReplicaCounterToBe, "maxReplicasNamespaceToBe": maxReplicaCounterToBe, "namespacePodsQuota": namespacePodsQuota, "namespaceRCQuota": namespaceRCQuota, "namespaceMemQuota": namespaceMemQuota, "lastUpdate": lastUpdate})
            infoToReturn.append(infoBeforeDict)        

    return(infoToReturn)
    
