from shuttlelib.utils.logger import logger
from shuttlelib.db.mongo import MongoClient
import os

async def retrieve_ongoing_scaling(trace_id):

    mg = MongoClient()
    logger.info(f'Changing collection to {os.getenv("COLLECTION_SCALEBYFACTOR")}')        
    mg.change_collection(os.getenv("COLLECTION_SCALEBYFACTOR"))
    mongo_data = mg.read_data()

    scaling_objects = []
    for object in mongo_data:
        if trace_id == object["register"]["traceID"]:
            scaling_objects.append(object["register"])

    if scaling_objects == []:
        return {"No scaling process in progress"}
    else:
        return scaling_objects

async def retrieve_historical_scaling():

    mg = MongoClient()
    logger.info(f'Changing collection to {os.getenv("COLLECTION_SCALEBYFACTOR")}')
    mg.change_collection(os.getenv("COLLECTION_SCALEBYFACTOR"))
    mongo_data = mg.read_data(legacy=True)
           
    return mongo_data