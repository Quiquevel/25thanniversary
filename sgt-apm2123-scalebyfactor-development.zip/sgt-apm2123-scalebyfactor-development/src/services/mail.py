from shuttlelib.middleware.emailnotification import send_mail
from shuttlelib.utils.logger import logger
import os
import pandas as pd


async def create_mail(cluster,region,factor,outputlist):

    hpa_true = [minidict for minidict in outputlist if minidict.get("HPA")]
    hpa_false = [minidict for minidict in outputlist if not minidict.get("HPA")]

    html_parts = []

    if hpa_true:
        df_hpa = pd.DataFrame(hpa_true)[[
            "namespace", "micro", "hpa_name",
            "replicas_min_before", "replicas_max_before",
            "replicas_min_after", "replicas_max_after",
            "status_code"
        ]]
        html_parts.append("<h4>Microservices with HPA</h3>")
        html_parts.append(df_hpa.to_html(index=False, escape=False))

    if hpa_false:
        df_nohpa = pd.DataFrame(hpa_false)[[
            "namespace", "micro",
            "replicas_before", "replicas_after",
            "status_code"
        ]]
        html_parts.append("<h4>Microservices without HPA</h3>")
        html_parts.append(df_nohpa.to_html(index=False, escape=False))

    ouputdata = "<p>".join(html_parts)
    
    htmlcontent = f"""
    <p>Hi!</p>
    <p>
    Below is a list of microservices from namespaces in {cluster}-{region} whose replicas were scaled by a factor of {factor} due to a Memory Leak:
    </p>
    {ouputdata}
    <p>Kind regards</p>
    """
    return htmlcontent

async def sendemailnotification(subject,htmlcontent):
    '''Send an email notification with the given subject and HTML content.
    Args:
        subject (str): The subject of the email.
        htmlcontent (str): The HTML content of the email.
    '''
    from_user = 'SRECoEDevSecOps@gruposantander.com'
    env_recipients=os.getenv("SRE_RECIPIENT_LIST")
    env_cc_recipients = os.getenv("SRE_CC_RECIPIENT_LIST")
    msg_to_user = env_recipients.split(",")
    msg_cc_user = env_cc_recipients.split(",")
    msg_subject = subject

    content = f"""
        {htmlcontent}

    """
    logger.info(f'Sending email with subject: {msg_subject} to {msg_to_user} with CC to {msg_cc_user}')
    await send_mail(msg_from=from_user,msg_to_user=msg_to_user,msg_cc_user=msg_cc_user,msg_subject=msg_subject,msg_content=content)