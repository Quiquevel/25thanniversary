from src.handler.external_requests import scaling
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(scaling, ["v1"])
]
