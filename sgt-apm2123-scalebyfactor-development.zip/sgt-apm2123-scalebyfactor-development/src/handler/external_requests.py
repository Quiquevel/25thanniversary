from shuttlelib.utils.logger import logger
from fastapi import APIRouter, Header, Depends
from fastapi.security import HTTPBearer
from fastapi.responses import JSONResponse
from src.services.scaleReplicas import scaleCriticalAPI, scaleCriticalWS
from src.services.switchonoffnamespace import switchOnOff
from src.services.scalebymicro import scalemicrosAPI
from src.services.getReplicas import getReplicasAPI
from src.services.readMongo import retrieve_ongoing_scaling, retrieve_historical_scaling
from src.services.scale_micros_memoryleak import scale_micros_memory_leak
from src.models.models import ReplicasModel, SwitchOnOffModel, ScalingModel, ScalingMicrosModel, ScalingMemoryLeak
import urllib3

urllib3.disable_warnings()

scaling = APIRouter(tags=["v1"],prefix='/api/v1/scaling')

bearer = HTTPBearer()  

@scaling.post("/replicas", tags=["v1"], description="GET REPLICAS BEFORE SCALING", response_description="JSON", status_code=200)
async def get_replicas(target: ReplicasModel):
    """
    Handles the POST request to retrieve the number of replicas before scaling.

    This endpoint interacts with the `getReplicasAPI` function to fetch the current
    replica count based on the provided target parameters.

    Args:
        target (ReplicasModel): A model containing the following attributes:
            - functionalEnvironment (str): The functional environment of the target.
            - cluster (str): The cluster name.
            - region (str): The region of the cluster.
            - factor (float): The scaling factor.
            - critical (bool): Indicates if the scaling is critical.
            - namespace (str): The namespace of the target.

    Returns:
        JSON: A JSON response containing the replica information.

    Status Codes:
        200: Successfully retrieved the replica information.
    """
    logger.info("Calling get replicas before scaling")
    result = await getReplicasAPI(functional_environment=target.functionalEnvironment,cluster=target.cluster,region=target.region,factor=target.factor,critical=target.critical,namespace=target.namespace)
    return  JSONResponse(content={
                                "result": result
                            }, status_code=200)

@scaling.post("/scaleprojects", tags=["v1"], description="SCALE REPLICAS BY FACTOR", response_description="JSON", status_code=200)
async def scale_replicas(target: ScalingModel, authorization: str = Header(default=None)):
    """
    Endpoint to scale replicas of projects by a specified factor.

    This endpoint allows scaling of replicas for projects in specified namespaces
    and clusters based on the provided scaling factor. It interacts with the 
    `scaleCriticalAPI` function to perform the scaling operation.

    Args:
        target (ScalingModel): The scaling model containing the details of the 
            functional environment, cluster, region, namespaces list, scaling factor, 
            sleep times, critical flag, and LDAP information.
        authorization (str, optional): The authorization token for the request, 
            provided in the header.

    Returns:
        JSONResponse: A JSON response containing the result of the scaling operation 
            with a status code of 200.

    Raises:
        HTTPException: If there is an issue with the scaling operation or invalid 
            input parameters.
    """
    result = await scaleCriticalAPI(functional_environment=target.functionalEnvironment,cluster=target.cluster,region=target.region,namespacesList=target.namespacesList,factor=target.factor,sleepNamespacesTime=target.sleepNamespacesTime,sleepMicrosTime=target.sleepMicrosTime,critical=target.critical,ldap=target.ldap,auth=authorization)
    return  JSONResponse(content={
                            "result": result
                        }, status_code=200)

@scaling.post("/ongoingscaling", tags=["v1"], description="GET ONGOING SCALING PROCESS", response_description="JSON", status_code=200)
async def get_trace_id_info(trace_id):
    """
    Asynchronously retrieves information about a trace ID and returns it as a JSON response.

    Args:
        traceId (str): The unique identifier for the trace whose information is to be retrieved.

    Returns:
        JSONResponse: A JSON response containing the result of the ongoing scaling retrieval
        and an HTTP status code of 200.
    """
    result =  await retrieve_ongoing_scaling(trace_id)
    return  JSONResponse(content={
                            "result": result
                        }, status_code=200)

@scaling.post("/historicalscaling", tags=["v1"], description="GET HISTORICAL SCALING (last 72H)", response_description="JSON", status_code=200)
async def get_historical():
    """
    Asynchronous function to retrieve historical scaling data and return it as a JSON response.

    This function calls the `retrieve_historical_scaling` coroutine to fetch historical scaling data
    and wraps the result in a JSON response with a status code of 200.

    Returns:
        JSONResponse: A JSON response containing the historical scaling data with a status code of 200.
    """
    result =  await retrieve_historical_scaling()
    return  JSONResponse(content={
                            "result": result
                        }, status_code=200)

@scaling.post("/switchonoff", tags=["v1"], description="SWITCH ON/OFF MICROSERVICES", response_description="JSON", status_code=200)
async def switch_micros(target: SwitchOnOffModel, authorization: str = Header(default=None)):
    """
    Asynchronous function to switch the state of microsystems.

    This function interacts with the `switchOnOff` utility to toggle the state of microsystems
    based on the provided parameters. It returns a JSON response with the result of the operation.

    Args:
        target (SwitchOnOffModel): An instance of `SwitchOnOffModel` containing the details
            of the microsystems to be switched, including functional environment, cluster,
            region, namespaces list, switch state, sleep times, and LDAP information.
        authorization (str, optional): The authorization token passed as a header for
            authentication. Defaults to None.

    Returns:
        JSONResponse: A JSON response containing the result of the `switchOnOff` operation
            and an HTTP status code of 200.
    """
    result =  await switchOnOff(functional_environment=target.functionalEnvironment,cluster=target.cluster,region=target.region,namespacesList=target.namespacesList,switch=target.switch,sleepNamespacesTime=target.sleepNamespacesTime,sleepMicrosTime=target.sleepMicrosTime,ldap=target.ldap,auth=authorization)
    return  JSONResponse(content={
                            "result": result
                        }, status_code=200)

@scaling.post("/scalemicros", tags=["v1"], description="SCALE MICROS BY FACTOR", response_description="JSON", status_code=200)
async def scale_replicas(target: ScalingMicrosModel, authorization: str = Header(default=None)):
    """
    Scales the replicas of microservices based on the provided scaling model.

    Args:
        target (ScalingMicrosModel): An object containing the scaling parameters, including 
            functional environment, cluster, region, namespace, list of microservices, scaling 
            factor, sleep time between scaling operations, active status, and LDAP information.
        authorization (str, optional): authorization token passed in the request header. Defaults to None.

    Returns:
        JSONResponse: A JSON response containing the result of the scaling operation and a status code of 200.
    """
    result =  await scalemicrosAPI(functional_environment=target.functionalEnvironment,cluster=target.cluster,region=target.region,namespace=target.namespace,microsList=target.microsList,factor=target.factor,sleepMicrosTime=target.sleepMicrosTime,active=target.active,ldap=target.ldap,auth=authorization)
    return  JSONResponse(content={
                            "result": result
                        }, status_code=200)

@scaling.post("/scale_if_memory_leak", tags=["v1"], description="SCALE MICROS IF MEMORY LEAK", response_description="JSON", status_code=200)
async def scale_replicas_memory_leak(target: ScalingMemoryLeak, authorization: str = Depends(bearer)):    
    """
    Scales the replicas of microservices based on the provided scaling model.

    Args:
        target (ScalingMemoryLeak): An object containing the scaling parameters, including 
            cluster, region, namespaces_list, scaling 
            factor and LDAP information.
        authorization (str, mandatory): authorization token passed in the request header. Defaults to None.

    Returns:
        JSONResponse: A JSON response containing the result of the scaling operation and a status code of 200.
    """    
    return await scale_micros_memory_leak(cluster=target.cluster,region=target.region,factor=target.factor,ldap=target.ldap,auth=authorization,namespaces_list=target.namespaces_list)