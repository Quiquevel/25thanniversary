"""
This module contains the data model for user accounts.
"""
from pydantic import BaseModel, Field
from typing import Optional, List
ENVIROMENT = "Functional environment of the target"
CLUSTER = "Cluster name of the target"
REGION = "Region of the target"
FACTOR = "Factor to scale up replicas. Could be float to scale down"
SLEEPMICROSTIME = "Optional parameter (in seconds) for waiting between microservices (default: 30)"
LDAP = "LDAP user for scaling. Only a devops is allowed to scale"

class ReplicasModel(BaseModel):
    functionalEnvironment: str = Field(json_schema_extra={"description":ENVIROMENT,'examples': ['dev','pre','pro']})
    cluster: str = Field(json_schema_extra={"description":CLUSTER,'examples': ['prodarwin']})
    region: Optional[str] = Field(default=None, json_schema_extra={"description":REGION,'examples': ['bo1']})
    factor: float = Field(json_schema_extra={"description":FACTOR,'examples': [1.5]})
    critical: str = Field(json_schema_extra={"description":"Set this parameter to true or false (string) for scaling the microservice with this label (true by default)",'examples': ['true', 'false']})
    namespace: Optional[str] = Field(default=None, json_schema_extra={"description":"Namespaces to scale",'examples': ['namespace1']})

class SwitchOnOffModel(BaseModel):
    functionalEnvironment: str = Field(json_schema_extra={"description":ENVIROMENT,'examples': ['dev','pre','pro']})
    cluster: str = Field(json_schema_extra={"description":CLUSTER,'examples': ['prodarwin']})
    region: Optional[str] = Field(default=None, json_schema_extra={"description":REGION,'examples': ['bo1']})
    namespacesList: list = Field(json_schema_extra={"description":"List of namespaces to switch on/off",'examples': [['namespace1', 'namespace2']]})
    switch: str = Field(json_schema_extra={"description":"on or off to set replicas to 0 or 1 on the deploymentsconfig of a project list",'examples': ['on', 'off']})
    sleepNamespacesTime: Optional[int] = Field(default=None, json_schema_extra={"description":"Optional parameter (in seconds) for waiting between namespaces (default: 30)",'examples': [30]})
    sleepMicrosTime: Optional[int] = Field(default=None, json_schema_extra={"description":SLEEPMICROSTIME,'examples': [30]})
    ldap: str = Field(json_schema_extra={"description":LDAP ,'examples': ['n457541']})

class ScalingModel(BaseModel):
    functionalEnvironment: str = Field(json_schema_extra={"description":ENVIROMENT,'examples': ['dev','pre','pro']})
    cluster: str = Field(json_schema_extra={"description":CLUSTER,'examples': ['prodarwin']})
    region: Optional[str] = Field(default=None, json_schema_extra={"description":REGION,'examples': ['bo1']})
    namespacesList: list = Field(json_schema_extra={"description":"List of namespaces to scale",'examples': [['namespace1', 'namespace2']]})
    factor: float = Field(json_schema_extra={"description":FACTOR,'examples': [1.5]})
    sleepNamespacesTime: Optional[int] = Field(default=None, json_schema_extra={"description":"Optional parameter (in seconds) for waiting between namespaces (default: 30)",'examples': [30]})
    sleepMicrosTime: Optional[int] = Field(default=None, json_schema_extra={"description":SLEEPMICROSTIME,'examples': [30]})
    critical: str = Field(json_schema_extra={"description":"Set this parameter to true or false (string) for scaling the microservice with this label (true by default)",'examples': ['true', 'false']})
    ldap: str = Field(json_schema_extra={"description":LDAP,'examples': ['n457541']})

class ScalingMicrosModel(BaseModel):
    functionalEnvironment: str = Field(json_schema_extra={"description":ENVIROMENT,'examples': ['dev','pre','pro']})
    cluster: str = Field(json_schema_extra={"description":CLUSTER,'examples': ['prodarwin']})
    region: Optional[str] = Field(default=None, json_schema_extra={"description":REGION,'examples': ['bo1']})
    namespace: str = Field(json_schema_extra={"description":"Namespace of the target",'examples': ['namespace1']})
    microsList: List = Field(json_schema_extra={"description":"List of microservices to scale",'examples': [['microservice1', 'microservice2']]})
    factor: float = Field(json_schema_extra={"description":FACTOR,'examples': [1.5]})
    active: str = Field(json_schema_extra={"description":"online or offline to scale production or ocu microservices",'examples': ['online', 'offline']})
    sleepMicrosTime: Optional[int] = Field(default=None, json_schema_extra={"description":SLEEPMICROSTIME,'examples': [30]})
    ldap: str = Field(json_schema_extra={"description":LDAP,'examples': ['n457541']})

class ScalingMemoryLeak(BaseModel):
    cluster: str = Field(json_schema_extra={"description":CLUSTER,'examples': ['prodarwin']})
    region: str = Field(default=None, json_schema_extra={"description":REGION,'examples': ['bo1']})
    namespaces_list: Optional[List] = Field(json_schema_extra={"description":"List of namespaces to scale",'examples': [['namespace1', 'namespace2']]})
    factor: float = Field(json_schema_extra={"description":FACTOR,'examples': [1.5]})
    ldap: str = Field(json_schema_extra={"description":LDAP,'examples': ['n457541']})  