#!/bin/bash

# run Streamlit
streamlit run app_streamlit.py --server.port 8502 --server.baseUrlPath shuttledump --theme.backgroundColor "#eff6f9" &

# run FastAPI
gunicorn asgi:app -c gunicorn_config.py