"""Configuration for the Composer application."""
from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "JVM Dump API",
          "description": "Interface for JVM Dump operations",
          "contact": {
               "name": "Enrique Velasco Martín",
               "url": "mailto:enrique.velasco@servexternos.gruposantander.com"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
