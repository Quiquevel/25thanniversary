"""
This module contains the main FastAPI application for the microservice.
"""
import urllib3, sys, os
from src.services.javadump import do_dump_project

os.environ['LOGLEVEL'] = os.getenv('LOGLEVEL', 'ERROR')

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

sys.path.insert(0, './src/services')

async def get_data_api():
    """Fetches data from the API and returns it in a structured format."""
    styles = {
        "container": {"margin-top": "0px !important", "padding": "0!important",
                      "align-items": "stretch", "background-color": "#fafafa"},
        #"icon": {"color": "black", "font-size": "0px"},
        "nav-link": {"font-size": "20px", "text-align": "left", "margin-top":"0px",
                     "--hover-color": "#eee"},
        #"nav-link-selected": {"background-color": "lightblue", "font-size": "20px",
        #  "font-weight": "normal", "color": "black"}
        }

    print("Starting Java Dump Service with styles:", styles)

    await do_dump_project()
