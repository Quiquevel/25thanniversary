"""
This module handles external requests for the microservice.
"""
