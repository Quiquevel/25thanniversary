"""This module provides functions to interact with the SGT APM API for JVM dumps and Dynatrace alerts.
It includes functions to make API requests for various operations such as fetching environment lists, cluster lists,"""
import json, requests, os
from shuttlelib.utils.logger import logger

application_json = "application/json"
bearer_prefix = "Bearer "
dumps_heap = "/dumps/heapdump"
url_api = os.getenv("URL_API", "http://sgt-apm2123-jvmdumps.sanes-shuttle-pro.svc.cluster.local:8080")
url_api2 = os.getenv("URL_API2", "http://sgt-apm2123-alerts.sanes-shuttle-pro.svc.cluster.local:8080")	

def make_request(endpoint, idtoken, body, timeout=120):
    """
    Sends a POST request to the specified API endpoint with the given body and authorization token.
    Args:
        endpoint (str): The API endpoint to send the request to (relative to the base URL).
        idtoken (str): The authorization token to include in the request headers.
        body (dict): The request payload to be sent as JSON.
        timeout (int, optional): Timeout for the request in seconds. Defaults to 120.
    Returns:
        dict or bytes: The parsed JSON response, raw content (for heapdump endpoints), or an error dictionary
        if the request fails.
    """
    request_url = f"{url_api}/api/v1{endpoint}"
    headers = {
        "Accept": application_json,
        "Authorization": bearer_prefix + str(idtoken),
        "x-clientid": "darwin"
    }

    response = requests.post(url=request_url, headers=headers, data=json.dumps(body), timeout=timeout)
    if response.status_code == 200:
        # For endpoints that return raw content (like heapdumps), return content directly
        if "check_if_live" in endpoint:
            return response.json()
        return response.content if "heapdump" in endpoint else json.loads(response.text)

    error_message = f"Error: {response.status_code} - {response.text}"
    logger.debug(error_message)
    return {"error": error_message}

def tokenparameter(env=None, cluster=None, region=None, do_api=None, namespace=None, microservice=None,
        pod=None, delete=False, idtoken=False, ldap=False):
    """
    Handles various API requests related to environment, cluster, region, namespace, microservice, and pod management,
    as well as heap and thread dump operations.
    Parameters:
        env (str, optional): The functional environment name.
        cluster (str, optional): The cluster identifier.
        region (str, optional): The region identifier.
        do_api (str, optional): The API operation to perform. Supported values include:
            - 'environmentlist': List environments.
            - 'clusterlist': List clusters.
            - 'regionlist': List regions.
            - 'namespacelist': List namespaces.
            - 'microservicelist': List microservices in a namespace.
            - 'podlist': List pods in a microservice.
            - 'check_if_live': Check if a pod is live.
            - 'heapdump': Trigger a heap dump.
            - 'heapdump_datagrid': Trigger a heap dump for datagrid.
            - 'threaddump': Trigger a thread dump.
            - 'threaddump_datagrid': Trigger a thread dump for datagrid.
        namespace (str, optional): The namespace name, required for some operations.
        microservice (str, optional): The microservice name, required for some operations.
        pod (str, optional): The pod name, required for some operations.
        delete (bool, optional): Whether to delete the dump after operation (default: False).
        idtoken (bool, optional): Whether to use an ID token for authentication (default: False).
        ldap (bool, optional): Whether to use LDAP authentication (default: False).
    Returns:
        Any: The result of the API request, or None if the operation is not recognized.
    """
    body_common = {"functionalenvironment": env, "cluster": cluster, "region": region, "ldap": ldap}

    match do_api:
        case 'environmentlist':
            return make_request("/dumps/environment_list", idtoken, body_common)

        case 'clusterlist':
            return make_request("/dumps/cluster_list", idtoken, body_common)

        case 'regionlist':
            return make_request("/dumps/region_list", idtoken, body_common)

        case 'namespacelist':
            return make_request("/dumps/namespace_list", idtoken, body_common)

        case 'microservicelist':
            body_common["namespace"] = namespace
            clean_body = {k: v for k, v in body_common.items() if v is not None}
            return make_request("/dumps/microservices_list", idtoken, clean_body)

        case 'podlist':
            body_common.update({"namespace": namespace, "microservices": microservice})
            clean_body = {k: v for k, v in body_common.items() if v is not None}
            return make_request("/dumps/pod_list", idtoken, clean_body)

        case 'check_if_live':
            body_common.update({"namespace": namespace, "pod": [pod]})
            clean_body = {k: v for k, v in body_common.items() if v is not None}
            return make_request("/dumps/check_if_live", idtoken, clean_body)

        case 'heapdump':
            return make_request(dumps_heap, idtoken, {**body_common, "namespace": namespace,
                                                          "pod": [pod], "action": "1", "delete": delete}, timeout=200)

        case 'heapdump_datagrid':
            return make_request(dumps_heap, idtoken, {**body_common, "namespace": namespace,
                                                          "pod": [pod], "action": "3", "delete": delete}, timeout=200)

        case 'threaddump':
            return make_request(dumps_heap, idtoken, {**body_common, "namespace": namespace,
                                                          "pod": [pod], "action": "2", "delete": delete})

        case 'threaddump_datagrid':
            return make_request(dumps_heap, idtoken, {**body_common, "namespace": namespace,
                                                          "pod": [pod], "action": "4", "delete": delete})

    return None

def make_request_dyna(endpoint, body, idtoken, timeout=120):
    """
    Sends a POST request to the Dynatrace API with the specified endpoint and body.
    Args:
        endpoint (str): The API endpoint to call (appended to the base URL).
        body (dict): The request payload to send in the POST body.
        idtoken (str): The authorization token to include in the request headers.
        timeout (int, optional): The request timeout in seconds. Defaults to 120.
    Returns:
        dict or None: The parsed JSON response if the request is successful (HTTP 200), otherwise None.
    """
    request_url = f"{url_api2}/api/v1{endpoint}"
    headers = {
        "Accept": application_json,
        "Authorization": bearer_prefix + str(idtoken),
        "x-clientid": "darwin"
    }

    logger.debug(f"Calling Dynatrace API endpoint: {endpoint}")

    response = requests.post(url=request_url, headers=headers, data=json.dumps(body), timeout=timeout)
    if response.status_code == 200:
        return json.loads(response.text)
    logger.debug(f"Error: {response.status_code} - {response.text}")
    return None

def tokenparameter_dyna(env=None, do_api=None, idtoken=False):
    """
    Generates and sends a request to the Dynatrace API based on the specified environment and API type.
    Args:
        env (str, optional): The functional environment to use in the request body.
        do_api (str, optional): The API operation to perform. Currently supports 'dyna_problems'.
        idtoken (bool, optional): Whether to include an ID token in the request.
    Returns:
        Any: The response from the Dynatrace API if the operation is supported; otherwise, None.
    """
    body_common = {"functionalEnvironment": env, "timedyna": "now-24h"}

    match do_api:
        case 'dyna_problems':
            return make_request_dyna("/alerting/data/dynatracealertsmemory", body_common, idtoken)

    return None
