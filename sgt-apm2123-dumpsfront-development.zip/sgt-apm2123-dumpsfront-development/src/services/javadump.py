""" Java Dump Service
This module provides functionality to perform Java dumps
on selected microservices within a Kubernetes environment."""
import streamlit as st
import os

from src.services.commonfunctions import execute_dump, get_jvm_dump
from src.services.tokenparameter import tokenparameter, tokenparameter_dyna
from streamlit_javascript import st_javascript
from typing import Optional

st.markdown(
    """
    <style>
    .stMainBlockContainer {
        padding: 0.5rem !important;
        background-color: #f0f0f0;
    }
    .block-container {
        padding-top: 0.5rem !important;
        margin-top: 0rem !important;
    }
    header {
        min-height: 0px !important;
        height: 0px !important;
        visibility: hidden;
    }
    .stSelectbox {
        max-width: 300px !important;
        min-width: 200px !important;
    }
    .stSelectbox label {
        font-weight: bold;
        font-size: 1.1rem;
    }
    </style>
    """,
    unsafe_allow_html=True
)

def update_selected_problem():
    """
    Updates the Streamlit session state by setting the 'selected_problem' key to the current value
    of the 'problem_selectbox' in the session state.

    This function is intended to synchronize the selected problem from a selectbox widget
    with a dedicated session state variable for further use in the application.
    """
    st.session_state.update({"selected_problem": st.session_state.problem_selectbox})

def get_environment_list(idtoken: str, ldap: str) -> Optional[dict]:
    """
    Retrieves a list of environments using the provided ID token and LDAP.

    Args:
        idtoken (str): The authentication token used for API access.
        ldap (str): The LDAP identifier for the user.

    Returns:
        Optional[dict]: A dictionary containing the list of environments if successful,
        or None if retrieval fails.
    """
    environment_list = tokenparameter(do_api='environmentlist', idtoken=idtoken, ldap=ldap)
    if not environment_list or 'environments' not in environment_list:
        st.error("Failed to retrieve environments")
        return None
    return environment_list

def get_clusters(env: str, idtoken: str, ldap: str) -> list:
    """
    Retrieves a list of clusters for the specified environment using authentication parameters.

    Args:
        env (str): The environment identifier (e.g., 'dev', 'prod').
        idtoken (str): The authentication token for API access.
        ldap (str): The LDAP username or identifier.

    Returns:
        list: A list of clusters retrieved from the API, or an empty list if none are found.
    """
    clusters = tokenparameter(env=env, do_api='clusterlist', idtoken=idtoken, ldap=ldap)
    return clusters.get('clusters', []) if clusters else []

def get_regions(env: str, cluster: str, idtoken: str, ldap: str) -> list:
    """
    Retrieves a list of regions for a given environment and cluster.

    Args:
        env (str): The environment identifier (e.g., 'dev', 'prod').
        cluster (str): The cluster name or identifier.
        idtoken (str): The authentication token for API access.
        ldap (str): The LDAP username or identifier.

    Returns:
        list: A list of region names or identifiers. Returns an empty list if no regions are found or on failure.
    """
    regions = tokenparameter(env=env, cluster=cluster, do_api='regionlist', idtoken=idtoken, ldap=ldap)
    return regions.get('regions', []) if regions else []

def get_namespaces(env: str, cluster: str, region: str, idtoken: str, ldap: str) -> list:
    """
    Retrieves a list of namespaces for a given environment, cluster, and region.

    Args:
        env (str): The environment identifier (e.g., 'dev', 'prod').
        cluster (str): The name of the cluster to query.
        region (str): The region where the cluster is located.
        idtoken (str): The authentication token for API access.
        ldap (str): The LDAP username or identifier.

    Returns:
        list: A list of namespaces if available; otherwise, an empty list.
    """
    namespaces = tokenparameter(
        env=env, cluster=cluster, region=region,
        do_api='namespacelist', idtoken=idtoken, ldap=ldap
    )
    return list(namespaces) if namespaces else []

def get_microservices(env: str, cluster: str, region: str, namespace: str, idtoken: str, ldap: str) -> list:
    """
    Retrieves a list of microservices for a specified environment, cluster, region, and namespace.

    Args:
        env (str): The environment name (e.g., 'dev', 'prod').
        cluster (str): The cluster identifier.
        region (str): The region where the cluster is located.
        namespace (str): The Kubernetes namespace.
        idtoken (str): The authentication token for API access.
        ldap (str): The LDAP username or identifier.

    Returns:
        list: A list of microservices if available; otherwise, an empty list.
    """
    services = tokenparameter(
        env=env, cluster=cluster, region=region,
        namespace=namespace, do_api='microservicelist',
        idtoken=idtoken, ldap=ldap
    )
    return list(services) if services else []

def get_pods(env: str, cluster: str, region: str, namespace: str, microservice: str, idtoken: str, ldap: str) -> list:
    """
    Retrieve a list of pods for a specified microservice in a Kubernetes cluster.

    Args:
        env (str): The environment (e.g., 'dev', 'prod') to query.
        cluster (str): The name of the Kubernetes cluster.
        region (str): The region where the cluster is located.
        namespace (str): The Kubernetes namespace to search in.
        microservice (str): The name of the microservice whose pods are to be listed.
        idtoken (str): The authentication token for API access.
        ldap (str): The LDAP identifier for user authentication.

    Returns:
        list: A list of pods matching the specified criteria, or an empty list if none are found.
    """
    pods = tokenparameter(
        env=env, cluster=cluster, region=region,
        namespace=namespace, microservice=microservice,
        do_api='podlist', idtoken=idtoken, ldap=ldap
    )
    return list(pods) if pods else []

def get_problems(idtoken: str) -> list:
    """
    Fetches a list of problems associated with the given idtoken.

    Args:
        idtoken (str): The identification token used for authentication.

    Returns:
        list: A list of problems retrieved from the dynamic API. Returns an empty list if no problems
        are found or if the response format is unexpected.
    """
    env_dyna = os.getenv("ENVIRONMENT", "pro")
    response = tokenparameter_dyna(env=env_dyna, do_api='dyna_problems', idtoken=idtoken)
    if isinstance(response, dict) and 'problems' in response:
        return response['problems']
    elif isinstance(response, list):
        return response
    else:
        return []

def display_selector(label: str, options: list, key: str, add_empty: bool = True, on_change: callable = None) -> str:
    """
    Displays a select box widget using Streamlit with the given label and options.

    Args:
        label (str): The label to display above the select box.
        options (list): The list of options to display in the select box.
        key (str): A unique key to identify the select box widget.
        add_empty (bool, optional): If True, adds an empty option at the beginning of
        the options list. Defaults to True.
        on_change (callable, optional): A callback function to execute when the value changes.
    Returns:
        str: The selected option from the select box.
    """
    items = [''] + options if add_empty else options
    return st.selectbox(label, items, key=key, on_change=on_change)

def display_dump_type() -> str:
    """
    Displays a select box for choosing the type of Java dump.

    Returns:
        str: The selected dump type, which can be '', 'HeapDump', or 'ThreadDump'.
    """
    return st.selectbox('Select type', ('', 'HeapDump', 'ThreadDump'), key="opt_restart_r")

def display_help_button():
    """
    Displays a help button in the Streamlit app that links to the analysis documentation.

    This function adds spacing and a clickable button labeled "Help for analysis"
    which redirects users to the specified documentation URL for guidance on analysis tools and procedures.
    """
    st.text('')
    st.text('')
    st.link_button(
        "Help for analysis",
        "https://sanes.atlassian.net/wiki/x/oABatAU",
        help="Go to documentation with tools and help to do the analysis"
    )

def handle_problem_selection(problems_list: list, idtoken: str, ldap: str):
    """Handles the logic for selecting and executing dumps from a Dynatrace problem."""
    problem_options = [
        f"{p.get('problemId', '')} | {p.get('status', '')} | {p.get('pods', [{}])[0].get('pod', 'no pod')}"
        for p in problems_list
    ]

    display_selector(
        '🌎 Dyna Problems',
        problem_options,
        key="problem_selectbox",
        on_change=update_selected_problem
    )
    selected_option = st.session_state.get("problem_selectbox", "")
    selected_problem_id = selected_option.split(" | ")[0] if selected_option else ""
    selected_problem = next((p for p in problems_list if p.get("problemId", "") == selected_problem_id), None)

    if not selected_problem: return None

    pod_info = selected_problem.get("pods", [{}])[0]
    select_pod = pod_info.get("pod", "")
    select_cluster = pod_info.get("cluster", "")
    select_region = pod_info.get("region", "")
    select_namespace = selected_problem.get("namespace", "")

    is_live = tokenparameter(env="pro", cluster=select_cluster, region=select_region,
        namespace=select_namespace, pod=select_pod, do_api="check_if_live",
        idtoken=idtoken, ldap=ldap)

    if is_live:
        if st.button("Execute Dump"):
            st.info("Executing dump...")
            try:
                get_jvm_dump(
                    optionenv="pro", optioncluster=select_cluster, optionregion=select_region,
                    selectnamespace=select_namespace, selectpod=select_pod,
                    type=["heapdump"], delete=False, idtoken=idtoken, ldap=ldap
                )
            except Exception as e:
                st.error(f"Error executing the dump: {e}")
    else:
        st.warning("The pod associated with this problem no longer exists.")

def handle_manual_selection(idtoken: str, ldap: str):
    """Handles the logic for manual environment, service, and pod selection."""
    st.markdown("#### Select the environment and service to generate the dump")

    # First row: Environment, Cluster, Region
    col1, col2, col3 = st.columns([1, 1, 1], gap="small")
    with col1:
        environment_list = get_environment_list(idtoken, ldap)
        if not environment_list: 
            return None
        env_flat_list = environment_list['environments']
        optionenv = display_selector('🌎 Environment', env_flat_list, "optionenv")
    with col2:
        clusters_list = get_clusters(optionenv, idtoken, ldap)
        optioncluster = display_selector('🗄️ Cluster', clusters_list, "optioncluster1")
    with col3:
        regions_list = get_regions(optionenv, optioncluster, idtoken, ldap)
        optionregion = display_selector('📍 Region', regions_list, "optionregion", False)

    if not all([optionenv, optioncluster, optionregion]):
        return None

    st.markdown("---")

    # Second row: Namespace, Microservice, Pod
    col4, col5, col6 = st.columns([1, 1, 1])
    with col4:
        namespaces = get_namespaces(optionenv, optioncluster, optionregion, idtoken, ldap)
        selectnamespace = display_selector('📦 Namespace', namespaces, "selectnamespace1")
    with col5:
        microservices = get_microservices(optionenv, optioncluster, optionregion, selectnamespace, idtoken, ldap)
        selectmicroservice = display_selector('🧩 Microservice', microservices, "selectmicroservice1")
    with col6:
        pods = get_pods(optionenv, optioncluster, optionregion, selectnamespace, selectmicroservice, idtoken, ldap)
        selectpod = display_selector('🐳 Pod', pods, "pod1")

    if not all([selectnamespace, selectmicroservice, selectpod]):
        return None

    # Third row: Dump Configuration
    st.markdown("---")
    st.markdown("##### Dump Configuration")
    col7, col8, _ = st.columns(3)
    with col7:
        selectedheap = display_dump_type()
    with col8:
        delete = st.checkbox('🗑️ Delete pod after dump?')

    if selectedheap:
        execute_dump(
            optionenv=optionenv, optioncluster=optioncluster, optionregion=optionregion,
            namespace=selectnamespace, pod=selectpod, delete=delete,
            idtoken=idtoken, ldap=ldap, do_execute=selectedheap
        )

async def do_dump_project():
    """Main function that renders the Dump Tool UI."""
    # Authentication is currently retrieved from localStorage via st_javascript; ideally, this would come from st.session_state
    idtoken = st_javascript("localStorage.getItem('idToken');")
    ldap = st_javascript("localStorage.getItem('ldap');")

    if not idtoken or not ldap:
        st.error("Failed to retrieve idToken or ldap from localStorage.")
        return None

    # Title and restart button
    col_title, col_button = st.columns([4, 1])
    with col_title:
        st.title('🚨 JAVA Dump Tool')
    with col_button:
        if st.button("Restart"):
            st.rerun()

    # Logic to show/hide the Dynatrace problems section
    if "show_dyna_problems" not in st.session_state:
        st.session_state["show_dyna_problems"] = False

    if st.session_state["show_dyna_problems"]:
        problems_list = get_problems(idtoken)
        handle_problem_selection(problems_list, idtoken, ldap)
    else:
        if st.button("Open Dyna problem's"):
            st.session_state["show_dyna_problems"] = True
            st.rerun()

    # Logic for manual selection
    handle_manual_selection(idtoken, ldap)

    display_help_button()
