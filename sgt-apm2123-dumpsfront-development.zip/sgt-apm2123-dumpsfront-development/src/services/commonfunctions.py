""" Common functions for the application.
This module provides utility functions for handling date formatting,"""
import urllib3, datetime, time
import streamlit as st

from src.services.tokenparameter import tokenparameter

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def get_date():
    """
    Returns the current date and time as a string formatted as 'YYYYMMDD_HHMM'.

    Returns:
        str: The current date and time in 'YYYYMMDD_HHMM' format.
    """
    now = datetime.datetime.now()
    return now.strftime("%Y%m%d_%H%M")

def get_gc():
    """
    Retrieves or initializes global variables `token_1` and `url`.

    This function uses the `global` keyword to access or modify the global variables
    `token_1` and `url`. The specific logic for retrieving or initializing these variables
    should be implemented within the function body.

    Returns:
        None
    """
    global token_1, url

def get_jvm_dump(optionenv, optioncluster, optionregion, selectnamespace, selectpod, type, delete, idtoken, ldap):
    """
    Generates and provides a download for a JVM dump file from a selected Kubernetes pod.
    This function interacts with the backend to generate a JVM dump (or similar diagnostic file) from a specified pod,
    providing a progress bar during the operation and a download button for the resulting file. If the dump cannot be
    generated (e.g., due to missing tools in the pod), a warning is displayed.
    Args:
        optionenv (str): The environment in which the pod is running.
        optioncluster (str): The Kubernetes cluster name.
        optionregion (str): The region of the cluster.
        selectnamespace (str): The Kubernetes namespace of the pod.
        selectpod (str): The name of the pod to generate the dump from.
        type (str): The type of dump or operation to perform.
        delete (bool): Whether to delete the dump after generation.
        idtoken (str): The authentication token for API access.
        ldap (str): The LDAP identifier for user authentication.
    Returns:
        None. Displays UI elements for progress, download, and status messages using Streamlit.
    """
    date = get_date()
    file_content = tokenparameter(env=optionenv, cluster=optioncluster, region=optionregion,
        namespace=selectnamespace, pod=selectpod, do_api=type, delete=delete, idtoken=idtoken, ldap=ldap)

    if file_content is None:
        st.warning("Error generating dump. The selected pod has not the necessary tools for generating dumps." \
                " Please contact Domain.")
    else:
        progress_text = "⏳ Operation in progress. Please wait."
        my_bar = st.progress(0, text=progress_text)
        for percent_complete in range(100):
            time.sleep(0.1)
            my_bar.progress(percent_complete + 1, text=progress_text)

        st.download_button(
            label="Download dump file 🔽",
            data=file_content,
            file_name=f'{type}-{selectpod}-{date}.gz',
            mime='application/octet-stream',
        )
        st.success('Done!')

def execute_dump(optionenv, optioncluster, optionregion, namespace, pod, delete, idtoken, ldap, do_execute=None):
    """
    Executes a JVM dump operation based on the specified dump type and user options.
    Parameters:
        optionenv (str): The environment option selected by the user.
        optioncluster (str): The cluster option selected by the user.
        optionregion (str): The region option selected by the user.
        namespace (str): The Kubernetes namespace of the target pod.
        pod (str): The name of the pod to perform the dump on.
        delete (bool): Whether to delete the dump file after download.
        idtoken (str): The authentication token for API access.
        ldap (str): The LDAP user identifier.
        do_execute (str, optional): The type of dump to execute. Must be one of the keys in dump_types.
    Behavior:
        - Displays an 'Execute Dump' button in the Streamlit UI for the selected dump type.
        - When the button is pressed, attempts to execute the corresponding JVM dump operation.
        - Handles and displays errors that occur during the dump process.
    Raises:
        Exception: If an error occurs during the dump execution, the error message is displayed in the Streamlit UI.
    """
    dump_types = {
        "HeapDump": "heapdump",
        "HeapDump DataGrid": "heapdump_datagrid",
        "ThreadDump": "threaddump",
        "ThreadDump DataGrid": "threaddump_datagrid"
    }

    if do_execute in dump_types:
        execute_button = st.button('🚀 Execute Dump', key=f'execute_{do_execute}')
        if execute_button:
            try:
                get_jvm_dump(optionenv, optioncluster, optionregion, namespace, pod,
                             dump_types[do_execute], delete, idtoken, ldap)
            except Exception as e:
                st.write(f'Error downloading file: {e}')

if __name__ == '__main__':
	token_1 = 'oBSioZKCTXi0-bwwtTftN'
	get_gc()
