import setuptools
from version import __version__

setuptools.setup(
    name = "sgt-apm2123-dumpsfront",
    version = __version__,
    author = "Enrique Velasco",
    author_email = "enrique.velasco@servexternos.gruposantander.com",
    description = "generating jvm dumps from pods",
    long_description = "generating jvm dumps from pods",
    long_description_content_type = "text/markdown",
    url = "sgt-apm2123-dumpsfront",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
    ],
    python_requires = '>=3.13.0',
)
