""" This module contains the test cases for the microservice health check. """

def test_simple():
    assert 1 + 1 == 2, "1 + 1 should equal 2"
