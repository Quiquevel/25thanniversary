import asyncio
from src.app.main import get_data_api
import streamlit as st


if __name__ == "__main__":
    st.set_page_config(
        page_title="Historical JAVA DUMP´s",
        page_icon="chart_with_upwards_trend",
        layout="wide",
        initial_sidebar_state="auto",
    )
  
    hide_streamlit_style = """
            <style>
            #MainMenu {visibility: hidden;}
            footer {visibility: hidden;}
            </style>
            """
    st.markdown(hide_streamlit_style, unsafe_allow_html=True)

    hide_decoration_bar_style = '''
    <style>
        header {visibility: hidden;}
    </style>
    '''
    st.markdown(hide_decoration_bar_style, unsafe_allow_html=True)
    
    asyncio.run(get_data_api())