"""docstring for composer_config.py"""
from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": False
     },
     "openapi": {
          "enable": True,
          "title": "Historical Dumps API",
          "description": "This API provides access to historical JVM dumps from pods.",
          "contact": {
               "name": "Enrique Velasco Martín",
               "url": "enrique.velasco@servexternos.gruposantander.com"
          }
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
