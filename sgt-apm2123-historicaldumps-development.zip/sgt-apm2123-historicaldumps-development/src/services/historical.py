""" Streamlit app for downloading JVM historical dumps from Kubernetes namespaces."""
import streamlit as st
from src.services.utils import tokenparameter, recover_dumps
import asyncio, requests, json
from streamlit_javascript import st_javascript
# -------------------- UI Helpers --------------------
st.markdown(
    """
    <style>
    .stMainBlockContainer {
        padding: 0.5rem !important;
        background-color: #f0f0f0;
    }
    .block-container {
        padding-top: 0.5rem !important;
        margin-top: 0rem !important;
    }
    header {
        min-height: 0px !important;
        height: 0px !important;
        visibility: hidden;
    }
    .stSelectbox {
        max-width: 300px !important;
        min-width: 200px !important;
    }
    .stSelectbox label {
        font-weight: bold;
        font-size: 1.1rem;
    }
    </style>
    """,
    unsafe_allow_html=True
)

select_region = "📍 Select Region"

def render_header():
    """ Renders the header of the Streamlit app."""
    st.markdown("## 🧠 JVM Historical Dumps Downloader.")
    st.markdown("Use this tool to retrieve and download JVM dumps from Kubernetes namespaces.")

def render_environment_selector():
    """ Renders a select box for choosing the environment."""
    return st.selectbox("🌍 Select Environment", ("pro", "pre", "dev"), key="env")

def render_cluster_selector(env):
    """ Renders a select box for choosing a cluster based on the selected environment."""
    clusters = {
        "pro": ['prodarwin', 'dmzbdarwin', 'confluent', 'dmz2bmov', 'probks', 'dmzbbks', "dmzbazure", "ocp05azure"],
        "pre": ['azure', 'bks', 'ocp05azure'],
        "dev": ['azure', 'bks', 'ocp05azure']
}
    return st.selectbox("🧩 Select Cluster", [""] + clusters.get(env, []), key="cluster")

def render_region_selector(env, cluster):
    """ Renders a select box for choosing a region based on the selected environment and cluster."""
    if env == "dev":
        return st.selectbox(select_region, ["", "weu1"] if "azure" in cluster else ["", "bo1"], key="region")
    elif cluster in ["dmzbazure", "ocp05azure"]:
        return st.selectbox(select_region, ["", "weu1", "weu2"], key="region")
    else:
        return st.selectbox(select_region, ["", "bo1", "bo2"], key="region")

def render_namespace_selector(namespaces):
    """ Renders a select box for choosing a namespace from the available namespaces."""
    return st.selectbox("📦 Select Namespace", [""] + list(namespaces), key="namespace")

def render_dump_selector(dumps):
    """ Renders a select box for choosing a JVM dump file from the available dumps."""
    return st.selectbox("🧾 Select Dump File", [""] + list(dumps), key="dump")

# -------------------- Download Handler --------------------

async def handle_download(namespace, dump, token, ldap):
    """ Handles the download of the selected JVM dump file."""
    if st.button("🔗 Generate Download Link"):
        st.info("⏳ Generating download link...")
        url = "http://sgt-apm2123-jvmdumps:8080"
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "x-clientid": "darwin"
}
        body = {"namespace": namespace, "file_name": dump, "ldap": ldap}
        response = requests.post(url, headers=headers, data=json.dumps(body), timeout=200)

        if response.status_code == 200:
            my_bar = st.progress(0, text="📥 Downloading...")
            for i in range(100):
                await asyncio.sleep(0.01)
                my_bar.progress(i + 1)
            st.success("✅ Download ready!")
            st.download_button(
                "⬇️ Download Dump",
                data=response.content,
                file_name=dump,
                mime="application/octet-stream"
            )
        else:
            st.error(f"❌ Error: {response.status_code}")

# -------------------- Main App Logic --------------------

def _handle_namespace_and_dumps(namespaces, idtoken, ldap):
    """Handles the logic for selecting namespace and dump, and triggering download."""
    namespace = render_namespace_selector(namespaces)
    if not namespace:
        return None

    dumps = recover_dumps(namespace=namespace, token=idtoken, ldap=ldap)
    if not dumps:
        st.warning("⚠️ No dumps available in this namespace.")
        return None

    dump = render_dump_selector(dumps)
    if dump:
        asyncio.run(handle_download(namespace, dump, idtoken, ldap))

async def do_dump_project():
    """ Main function to run the Streamlit app for downloading JVM dumps."""
    render_header()

    idtoken = st_javascript("localStorage.getItem('idToken');")
    ldap = st_javascript("localStorage.getItem('ldap');")

    # Step 1: Select environment, cluster, region
    env = render_environment_selector()
    cluster = render_cluster_selector(env)
    region = render_region_selector(env, cluster)

    namespaces = tokenparameter(env=env, cluster=cluster, region=region, do_api="namespacelist",
                                idtoken=idtoken, ldap=ldap)
    if namespaces:
        _handle_namespace_and_dumps(namespaces, idtoken, ldap)
    else:
        st.error("❌ Could not retrieve namespaces.")

if __name__ == "__main__":
    asyncio.run(do_dump_project())
