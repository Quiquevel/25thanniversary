""" This script is designed to run in a Streamlit environment and provides a user interface for downloading"""
import requests, json, urllib3
import streamlit as st

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def tokenparameter(env=None, cluster=None,region=None,do_api=None,namespace=None,microservice=None,
                   idtoken=False, ldap=False):
    """ This function retrieves the necessary parameters for the API request based on the provided environment,
    cluster, region, and other parameters."""
    content_type_json = "application/json"
    auth_scheme_bearer = "Bearer "
    #PRO URL API
    urlapi = "http://sgt-apm2123-jvmdumps:8080"

    match do_api:
        case 'namespacelist':
            request_url = f"{urlapi}/api/v1/dumps/namespace_list"
            headers = {"Accept": content_type_json, "Authorization": auth_scheme_bearer + str(idtoken),
                       "x-clientid": "darwin"}
            body = {
                "functionalenvironment": env,
                "cluster": cluster,
                "region": region,
                "ldap": ldap
            }
            return execute_api_request(request_url, headers, body)
        case 'podlist':
            request_url = f"{urlapi}/api/v1/dumps/pod_list"
            headers = {"Accept": content_type_json, "Authorization": auth_scheme_bearer + str(idtoken),
                       "x-clientid": "darwin"}
            body = {
                "functionalenvironment": env,
                "cluster": cluster,
                "region": region,
                "namespace": namespace,
                "microservices": microservice,
                "ldap": ldap
            }
            return execute_api_request(request_url, headers, body)

def execute_api_request(request_url, headers, body):
    """ This function executes the API request and returns the response data."""
    response = requests.post(url=request_url, headers=headers, data=json.dumps(body), timeout=120)
    if response.status_code == 200:
        datos = response.text
        return json.loads(datos)
    else:
        st.write(f"The error is: {response.status_code}")
        st.write(f"Response content: {response.content}")
        return None

def recover_dumps(namespace, token, ldap):
    """ This function retrieves historical JVM dumps for a given namespace using the provided token and
        LDAP information."""
    urlapi = "http://sgt-apm2123-jvmdumps:8080"
    request_url = f"{urlapi}/api/v1/dumps/historical_dumps"
    headers = {"Accept": "application/json","Authorization":'Bearer '+str(token),"x-clientid":"darwin"}
    body = {"namespace": namespace,"ldap": ldap}

    response = requests.post(url=request_url,headers=headers,data=json.dumps(body), timeout=200)

    if response.status_code == 200:
        file_list = json.loads(response.content.decode('utf-8'))
        return file_list

if __name__ == '__main__':
	token_1 = 'oBSioZKCTXi0-bwwtTftN'
