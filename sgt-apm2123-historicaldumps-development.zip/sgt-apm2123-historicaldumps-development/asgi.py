from fastapi import FastAPI
import uvicorn

# create FastAPI app
app = FastAPI()

@app.get("/health", tags=["healthcheck"])
async def healthcheck():
    return "SERVER OK"

# run FastAPI
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8080)
