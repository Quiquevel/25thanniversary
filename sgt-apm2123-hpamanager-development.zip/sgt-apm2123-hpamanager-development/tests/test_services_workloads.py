import sys
from unittest.mock import AsyncMock, MagicMock
# Custom dict with keys method for workloads tests
class DictWithKeys(dict):
    def keys(self):
        return super().keys()
def make_dict():
    return DictWithKeys({
        'item1': {'items': []},
        'item2': {'items': []},
        'item3': {'items': []},
        'item4': {'items': []}
    })
mock_client = AsyncMock()
mock_client.get_resource = AsyncMock(side_effect=[make_dict() for _ in range(25)])
sys.modules['shuttlelib.openshift.client'] = MagicMock(OpenshiftClient=MagicMock(return_value=mock_client))

import unittest
import src.services.workloads as workloads_mod

class TestWorkloads(unittest.IsolatedAsyncioTestCase):
    async def test_get_workloads(self):
        w = workloads_mod.Workloads('env', 'cl', 'ns')
        await w.get_workloads()
        # Check for dict type and expected keys instead of local DictWithKeys class
        for obj in [w.deployments, w.deploymentconfigs, w.services, w.hpas]:
            self.assertIsInstance(obj, dict)
            for k in ['item1', 'item2', 'item3', 'item4']:
                self.assertIn(k, obj)
                self.assertIn('items', obj[k])

if __name__ == '__main__':
    unittest.main()
