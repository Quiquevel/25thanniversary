import sys
from unittest.mock import MagicMock
mock_client = MagicMock()
sys.modules['shuttlelib.openshift.client'] = MagicMock(OpenshiftClient=MagicMock(return_value=mock_client))

import unittest
from unittest.mock import patch, AsyncMock
from fastapi import HTTPException
import src.middleware.authorization as authorization

class TestAuthorization(unittest.IsolatedAsyncioTestCase):
    @patch('src.middleware.authorization.verify_token', new_callable=AsyncMock)
    @patch('src.middleware.authorization.get_alm_teams', new_callable=AsyncMock)
    async def test_is_devops_success(self, mock_get_alm_teams, mock_verify_token):
        mock_verify_token.return_value = True
        mock_get_alm_teams.return_value = ['devops']
        token = type('Token', (), {'scheme': 'Bearer', 'credentials': 'token'})()
        result = await authorization.is_devops(token, 'user')
        self.assertTrue(result)

    @patch('src.middleware.authorization.verify_token', new_callable=AsyncMock)
    async def test_is_devops_invalid_token(self, mock_verify_token):
        mock_verify_token.return_value = False
        token = type('Token', (), {'scheme': 'Bearer', 'credentials': 'token'})()
        with self.assertRaises(HTTPException):
            await authorization.is_devops(token, 'user')

if __name__ == '__main__':
    unittest.main()
