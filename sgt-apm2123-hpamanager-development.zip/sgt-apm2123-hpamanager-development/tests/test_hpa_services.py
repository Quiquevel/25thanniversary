import sys
from unittest.mock import AsyncMock, MagicMock
# Patch OpenshiftClient before any other imports
mock_client = MagicMock()
mock_client.get_resource = AsyncMock(return_value=[{"name": "svc1"}])
sys.modules['shuttlelib.openshift.client'] = MagicMock(OpenshiftClient=MagicMock(return_value=mock_client))

import pytest
import src.services.hpa as hpa_services

@pytest.mark.asyncio
def test_set_activation_enable(monkeypatch):
    monkeypatch.setattr(hpa_services, 'get_configuration', AsyncMock(return_value={
        "deployments": [{"cluster": "c1", "items": [{"name": "svc1", "hpa": [{"sourceConfig": "shuttle.hpa.manager"}]}]}],
        "deploymentconfigs": []
    }))
    monkeypatch.setattr(hpa_services, 'update_hpa_conf', AsyncMock(return_value={"status": "ok", "response": "done"}))
    # Call the function directly instead of pytest.run
    result = hpa_services.set_activation(
        functionalEnvironment="dev", cluster="c1", namespace="ns", enable=True, data=["svc1"], ldap="x021096"
    )
    # If set_activation is async, await it
    if hasattr(result, '__await__'):
        import asyncio
        result = asyncio.get_event_loop().run_until_complete(result)
    assert result["hpa"] is True
    assert result["reason"] == "HPA enabled"
