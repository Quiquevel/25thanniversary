import sys
from unittest.mock import AsyncMock, MagicMock
# Patch OpenshiftClient before importing Workloads
mock_client = MagicMock()
mock_client.get_resource = AsyncMock(return_value=[{"name": "svc1"}])
sys.modules['shuttlelib.openshift.client'] = MagicMock(OpenshiftClient=MagicMock(return_value=mock_client))

import pytest
from src.services.workloads import Workloads

@pytest.mark.asyncio
def test_get_workloads():
    w = Workloads(functionalEnvironment="dev", cluster="c1", namespace="ns")
    import asyncio
    asyncio.get_event_loop().run_until_complete(w.get_workloads())
    assert hasattr(w, 'deployments')
    assert hasattr(w, 'deploymentconfigs')
    assert hasattr(w, 'services')
    assert hasattr(w, 'hpas')
