""" This module contains the test cases for the microservice health check. """
from version import __version__ as version_id


def test_service_health(client, mock_openshift_client):
    """
    Test case for the service health check.
    """

    response = client.get("/health")
    assert response.status_code == 200
    response = response.json()
    assert response['description'] == f"health of {version_id} service"
    assert response['releaseId'] == version_id
    assert response['status'] == "pass"
