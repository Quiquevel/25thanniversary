import sys
from unittest.mock import MagicMock
mock_client = MagicMock()
sys.modules['shuttlelib.openshift.client'] = MagicMock(OpenshiftClient=MagicMock(return_value=mock_client))

import unittest
from unittest.mock import patch, AsyncMock
from fastapi import HTTPException
import pytest

import src.services.hpa as hpa


class TestHpaService(unittest.IsolatedAsyncioTestCase):
    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    async def test_set_activation_microservice_not_found(self, mock_get_configuration):
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': []}],
            'deploymentconfigs': []
        }
        with self.assertRaises(Exception):
            await hpa.set_activation('env', 'cl', 'ns', True, ['notfound'], 'ldap')

    @patch('src.services.hpa.Workloads')
    async def test_get_configuration_success(self, mock_workloads):
        # Mock the Workloads instance and its methods/attributes
        mock_instance = mock_workloads.return_value
        mock_instance.get_workloads = AsyncMock()
        mock_instance.deploymentconfigs = {'cl': {'items': [{'metadata': {'name': 'svc', 'uid': 'uid', 'annotations': {}}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        mock_instance.deployments = {'cl': {'items': [{'metadata': {'name': 'svc', 'uid': 'uid', 'annotations': {}}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        mock_instance.hpas = {'cl': {'items': []}}
        result = await hpa.get_configuration('env', 'cl', 'ns', 'ldap')
        self.assertIn('deploymentconfigs', result)
        self.assertIn('deployments', result)

    @patch('src.services.hpa.api_update_annotations', new_callable=AsyncMock)
    async def test_update_hpa_conf_annotations(self, mock_api_update_annotations):
        mock_api_update_annotations.return_value = {'status': 'ok', 'response': 'updated'}
        microservice = MagicMock()
        microservice.hpa = MagicMock(minReplicas=1, maxReplicas=2, targetCPUUtilizationPercentage=50)
        microservice.name = 'svc'
        microservice.type = 'deployment'
        microservice.region = 'cl'
        result = await hpa.update_hpa_conf(microservice, 'annotations', {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}, 'ldap')  # noqa: E501
        self.assertEqual(result['status'], 'ok')

    @patch('src.services.hpa.api_update_hpa', new_callable=AsyncMock)
    async def test_update_hpa_conf_apiserver(self, mock_api_update_hpa):
        mock_api_update_hpa.return_value = {'status': 'ok', 'response': 'updated'}
        microservice = MagicMock()
        microservice.hpa = MagicMock(minReplicas=1, maxReplicas=2, targetCPUUtilizationPercentage=50)
        microservice.name = 'svc'
        microservice.type = 'deployment'
        microservice.region = 'cl'
        result = await hpa.update_hpa_conf(microservice, 'apiserver', {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}, 'ldap')  # noqa: E501
        self.assertEqual(result['status'], 'ok')

    @patch('src.services.hpa.api_delete_hpa', new_callable=AsyncMock)
    @patch('src.services.hpa.update_hpa_conf', new_callable=AsyncMock)
    async def test_delete_hpa_conf_success(self, mock_update_hpa_conf, mock_api_delete_hpa):
        mock_update_hpa_conf.return_value = {'status': 'ok'}
        mock_api_delete_hpa.return_value = {'status': 'ok'}
        microservice = MagicMock()
        microservice.name = 'svc'
        microservice.region = 'cl'
        result = await hpa.delete_hpa_conf(microservice, {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}, 'ldap')  # noqa: E501
        self.assertEqual(result['status'], 'ok')

    @patch('src.services.hpa.api_delete_hpa', new_callable=AsyncMock)
    @patch('src.services.hpa.update_hpa_conf', new_callable=AsyncMock)
    async def test_delete_hpa_conf_failure(self, mock_update_hpa_conf, mock_api_delete_hpa):
        mock_update_hpa_conf.return_value = {'status': 'ok'}
        mock_api_delete_hpa.return_value = {'status': 'ko'}
        microservice = MagicMock()
        microservice.name = 'svc'
        microservice.region = 'cl'
        result = await hpa.delete_hpa_conf(microservice, {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}, 'ldap')  # noqa: E501
        self.assertEqual(result['status'], 'ko')

    @patch('src.services.hpa.Workloads')
    async def test_get_configuration_empty(self, mock_workloads):
        mock_instance = mock_workloads.return_value
        mock_instance.get_workloads = AsyncMock()
        mock_instance.deploymentconfigs = {}
        mock_instance.deployments = {}
        mock_instance.hpas = {}
        result = await hpa.get_configuration('env', 'cl', 'ns', 'ldap')
        self.assertIn('deploymentconfigs', result)
        self.assertIn('deployments', result)

    @patch('src.services.hpa.Workloads')
    @patch('src.services.hpa.check_service', new_callable=AsyncMock)
    @patch('src.services.hpa.update_hpa_conf', new_callable=AsyncMock)
    @patch('src.services.hpa.get_hpa_conf', new_callable=AsyncMock)
    async def test_update_configuration_success(self, mock_get_hpa_conf, mock_update_hpa_conf, mock_check_service, mock_workloads):
        mock_instance = mock_workloads.return_value
        mock_instance.get_workloads = AsyncMock()
        mock_instance.deployments = {'cl': {'items': [{'metadata': {'name': 'svc', 'uid': 'uid'}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        mock_instance.deploymentconfigs = {'cl': {'items': [{'metadata': {'name': 'svc', 'uid': 'uid'}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        mock_instance.hpas = {'cl': {'items': []}}
        mock_check_service.return_value = {'cl': {'bg_services': [{'selector': 'svc'}], 'gb_services': []}}
        mock_update_hpa_conf.return_value = {'status': 'ok', 'response': {}}
        mock_get_hpa_conf.return_value = {}
        class Element:
            type = 'deployment'
            name = 'svc'
            region = 'cl'
        data = [Element()]
        result = await hpa.update_configuration('env', 'cl', 'ns', 'ldap', data)
        self.assertEqual(result['status'], 'ok')

    @patch('src.services.hpa.Workloads')
    @patch('src.services.hpa.check_service', new_callable=AsyncMock)
    async def test_update_configuration_type_invalid(self, mock_check_service, mock_workloads):
        # element.type not deployment or deploymentconfig
        mock_instance = mock_workloads.return_value
        mock_instance.get_workloads = AsyncMock()
        mock_instance.deployments = {'cl': {'items': []}}
        mock_instance.deploymentconfigs = {'cl': {'items': []}}
        mock_instance.hpas = {'cl': {'items': []}}
        mock_check_service.return_value = {'cl': {'bg_services': [], 'gb_services': []}}
        class Element:
            type = 'invalid'
            name = 'svc'
            region = 'cl'
        data = [Element()]
        with self.assertRaises(HTTPException) as ctx:
            await hpa.update_configuration('env', 'cl', 'ns', 'ldap', data)
        self.assertIn('not found in invalids', str(ctx.exception.detail))

    @patch('src.services.hpa.Workloads')
    @patch('src.services.hpa.check_service', new_callable=AsyncMock)
    async def test_update_configuration_element_not_found(self, mock_check_service, mock_workloads):
        # element not found in workloads
        mock_instance = mock_workloads.return_value
        mock_instance.get_workloads = AsyncMock()
        mock_instance.deployments = {'cl': {'items': []}}
        mock_instance.deploymentconfigs = {'cl': {'items': []}}
        mock_instance.hpas = {'cl': {'items': []}}
        mock_check_service.return_value = {'cl': {'bg_services': [], 'gb_services': []}}
        class Element:
            type = 'deployment'
            name = 'svc'
            region = 'cl'
        data = [Element()]
        with self.assertRaises(HTTPException) as ctx:
            await hpa.update_configuration('env', 'cl', 'ns', 'ldap', data)
        self.assertIn('not found in deployments', str(ctx.exception.detail))

    @patch('src.services.hpa.Workloads')
    @patch('src.services.hpa.check_service', new_callable=AsyncMock)
    async def test_update_configuration_both_selectors(self, mock_check_service, mock_workloads):
        # Service in both bg and gb selectors
        mock_instance = mock_workloads.return_value
        mock_instance.get_workloads = AsyncMock()
        mock_instance.deployments = {'cl': {'items': [{'metadata': {'name': 'svc', 'uid': 'uid'}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        mock_instance.deploymentconfigs = {'cl': {'items': []}}
        mock_instance.hpas = {'cl': {'items': []}}
        mock_check_service.return_value = {'cl': {'bg_services': [{'selector': 'svc'}], 'gb_services': [{'selector': 'svc'}]}}  # noqa: E501
        class Element:
            type = 'deployment'
            name = 'svc'
            region = 'cl'
        data = [Element()]
        with self.assertRaises(HTTPException) as ctx:
            await hpa.update_configuration('env', 'cl', 'ns', 'ldap', data)
        self.assertIn('is in both gb and bg services', str(ctx.exception.detail))

    @patch('src.services.hpa.Workloads')
    @patch('src.services.hpa.check_service', new_callable=AsyncMock)
    async def test_update_configuration_no_selector(self, mock_check_service, mock_workloads):
        # Service in neither selector
        mock_instance = mock_workloads.return_value
        mock_instance.get_workloads = AsyncMock()
        mock_instance.deployments = {'cl': {'items': [{'metadata': {'name': 'svc', 'uid': 'uid'}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        mock_instance.deploymentconfigs = {'cl': {'items': []}}
        mock_instance.hpas = {'cl': {'items': []}}
        mock_check_service.return_value = {'cl': {'bg_services': [], 'gb_services': []}}
        class Element:
            type = 'deployment'
            name = 'svc'
            region = 'cl'
        data = [Element()]
        with self.assertRaises(HTTPException) as ctx:
            await hpa.update_configuration('env', 'cl', 'ns', 'ldap', data)
        self.assertIn('not found in services', str(ctx.exception.detail))

    async def test_get_hpa_conf_none(self):
        # hpa_conf is empty, should return None or [result]
        microservice = {'json': {'metadata': {'name': 'svc', 'annotations': {}}}, 'type': 'deployment'}
        hpa_list = []
        result = await hpa.get_hpa_conf(microservice, hpa_list)
        self.assertTrue(result is None or isinstance(result, list))

    async def test_get_hpa_conf_with_annotations(self):
        microservice = {'json': {'metadata': {'name': 'svc', 'annotations': {'shuttle.hpa.manager': "{'minReplicas': 1, 'maxReplicas': 2, 'targetCPUUtilizationPercentage': 50}"}}}, 'type': 'deployment'}
        hpa_list = []
        result = await hpa.get_hpa_conf(microservice, hpa_list)
        self.assertIsInstance(result, list)

    @patch('aiohttp.ClientSession')
    async def test_api_update_annotations_success(self, mock_aiohttp_cls):
        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={'result': 'ok'})
        mock_ctx_mgr = MagicMock()
        mock_ctx_mgr.__aenter__ = AsyncMock(return_value=mock_response)
        mock_ctx_mgr.__aexit__ = AsyncMock(return_value=None)
        mock_session = MagicMock()
        mock_session.patch.return_value = mock_ctx_mgr
        mock_aiohttp_cls.return_value.__aenter__.return_value = mock_session
        client_map = {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}
        body = {}
        microservice = MagicMock()
        microservice.type = 'deployment'
        microservice.name = 'svc'
        microservice.region = 'cl'
        result = await hpa.api_update_annotations(client_map, body, microservice)
        self.assertEqual(result['status'], 'ok')

    @patch('aiohttp.ClientSession')
    async def test_api_update_hpa_success(self, mock_aiohttp_cls):
        mock_response = MagicMock()
        mock_response.status = 201
        mock_response.json = AsyncMock(return_value={'result': 'ok'})
        mock_ctx_mgr = MagicMock()
        mock_ctx_mgr.__aenter__ = AsyncMock(return_value=mock_response)
        mock_ctx_mgr.__aexit__ = AsyncMock(return_value=None)
        mock_session = MagicMock()
        mock_session.post.return_value = mock_ctx_mgr
        mock_aiohttp_cls.return_value.__aenter__.return_value = mock_session
        client_map = {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}
        body = {}
        microservice = MagicMock()
        microservice.name = 'svc'
        microservice.region = 'cl'
        result = await hpa.api_update_hpa(client_map, body, microservice)
        self.assertEqual(result['status'], 'ok')

    @patch('aiohttp.ClientSession')
    async def test_api_delete_hpa_success(self, mock_aiohttp_cls):
        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={'result': 'ok'})
        mock_ctx_mgr = MagicMock()
        mock_ctx_mgr.__aenter__ = AsyncMock(return_value=mock_response)
        mock_ctx_mgr.__aexit__ = AsyncMock(return_value=None)
        mock_session = MagicMock()
        mock_session.delete.return_value = mock_ctx_mgr
        mock_aiohttp_cls.return_value.__aenter__.return_value = mock_session
        client_map = {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}
        microservice = MagicMock()
        microservice.name = 'svc'
        microservice.region = 'cl'
        result = await hpa.api_delete_hpa(client_map, microservice)
        self.assertEqual(result['status'], 'ok')

    @patch('aiohttp.ClientSession')
    async def test_api_get_hpa_success(self, mock_aiohttp_cls):
        mock_response = MagicMock()
        mock_response.status = 200
        mock_response.json = AsyncMock(return_value={'result': 'ok'})
        mock_ctx_mgr = MagicMock()
        mock_ctx_mgr.__aenter__ = AsyncMock(return_value=mock_response)
        mock_ctx_mgr.__aexit__ = AsyncMock(return_value=None)
        mock_session = MagicMock()
        mock_session.get.return_value = mock_ctx_mgr
        mock_aiohttp_cls.return_value.__aenter__.return_value = mock_session
        client_map = {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}
        microservice = MagicMock()
        microservice.name = 'svc'
        microservice.region = 'cl'
        result = await hpa.api_get_hpa(client_map, microservice)
        self.assertEqual(result['result'], 'ok')

    async def test_check_service(self):
        # Provide test data that does NOT trigger the duplicate selector error
        clusterServices = {
            'cl': {
                'items': [
                    {'metadata': {'name': 'b-g-svc'}, 'spec': {'selector': {'app_name': 'svc1'}}},
                    {'metadata': {'name': 'g-b-svc'}, 'spec': {'selector': {'app.kubernetes.io/name': 'svc2'}}}
                ]
            }
        }
        result = await hpa.check_service(clusterServices)
        self.assertIn('cl', result)

    async def test_check_service_missing_selector(self):
        # Should raise HTTPException for missing selector
        clusterServices = {'cl': {'items': [{'metadata': {'name': 'b-g-svc'}, 'spec': {'selector': {}}}]}}  # noqa: E501
        with self.assertRaises(HTTPException) as ctx:
            await hpa.check_service(clusterServices)
        self.assertIn('not found in selector', str(ctx.exception.detail))

    async def test_check_service_duplicate_selector(self):
        # Should raise HTTPException for duplicate selector
        clusterServices = {'cl': {'items': [
            {'metadata': {'name': 'b-g-svc'}, 'spec': {'selector': {'app_name': 'svc'}}},
            {'metadata': {'name': 'g-b-svc'}, 'spec': {'selector': {'app_name': 'svc'}}}
        ]}}  # noqa: E501
        with self.assertRaises(HTTPException) as ctx:
            await hpa.check_service(clusterServices)
        self.assertIn('same selector', str(ctx.exception.detail))

    async def test_check_deployments(self):
        deployments = {'cl': {'items': [{'metadata': {'name': 'svc'}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        deploymentcongfigs = {'cl': {'items': [{'metadata': {'name': 'svc'}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        services = {'cl': {'bg_services': [{'selector': 'svc'}], 'gb_services': []}}
        hpas = {'cl': {'items': []}}
        result = await hpa.check_deployments(deployments, deploymentcongfigs, services, hpas)
        self.assertIn('cl', result)

    @patch('src.services.hpa.Workloads')
    @patch('src.services.hpa.check_service', new_callable=AsyncMock)
    @patch('src.services.hpa.update_hpa_conf', new_callable=AsyncMock)
    @patch('src.services.hpa.get_hpa_conf', new_callable=AsyncMock)
    async def test_replicate_configuration(self, mock_get_hpa_conf, mock_update_hpa_conf, mock_check_service, mock_workloads):
        mock_instance = mock_workloads.return_value
        mock_instance.get_workloads = AsyncMock()
        # Add 'uid' to metadata
        mock_instance.deploymentconfigs = {'cl': {'items': [{
            'name': 'svc',
            'metadata': {'name': 'svc', 'uid': 'uid1'},
            'spec': {'replicas': 1},
            'hpa': [{'sourceConfig': 'HorizontalPodAutoscaler'}]
        }]}}  # noqa: E501
        mock_instance.deployments = {'cl': {'items': []}}
        mock_instance.hpas = {'cl': {'items': []}}
        mock_check_service.return_value = {'cl': {'bg_services': [{'selector': 'svc'}], 'gb_services': []}}
        mock_update_hpa_conf.return_value = {'status': 'ok', 'response': {}}
        mock_get_hpa_conf.return_value = [{'sourceConfig': 'HorizontalPodAutoscaler'}]
        result = await hpa.replicate_configuration('env', 'cl', 'ns', 'ldap')
        self.assertEqual(result['status'], 'ok')

    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    async def test_set_activation_both_deployment_and_deploymentconfig(self, mock_get_configuration):
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': [{'name': 'svc', 'hpa': None}]}],
            'deploymentconfigs': [{'cluster': 'cl', 'items': [{'name': 'svc', 'hpa': None}]}]
        }
        with self.assertRaises(HTTPException) as exc:
            await hpa.set_activation('env', 'cl', 'ns', True, ['svc'], 'ldap')
        self.assertEqual(exc.exception.status_code, 400)

    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    async def test_set_activation_microservice_not_found_in_any(self, mock_get_configuration):
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': []}],
            'deploymentconfigs': [{'cluster': 'cl', 'items': []}]
        }
        with self.assertRaises(HTTPException) as exc:
            await hpa.set_activation('env', 'cl', 'ns', True, ['notfound'], 'ldap')
        self.assertEqual(exc.exception.status_code, 404)

    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    @patch('src.services.hpa.update_hpa_conf', new_callable=AsyncMock)
    async def test_set_activation_enable_hpa_not_found(self, mock_update_hpa_conf, mock_get_configuration):
        # Covers: hpa["hpa"] is None, triggers HTTPException for activation
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': [{'name': 'svc', 'hpa': None}]}],
            'deploymentconfigs': []
        }
        with self.assertRaises(HTTPException) as ctx:
            await hpa.set_activation('env', 'cl', 'ns', True, ['svc'], 'ldap')
        self.assertIn('has not HPA in cl region for activation', str(ctx.exception.detail))

    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    @patch('src.services.hpa.delete_hpa_conf', new_callable=AsyncMock)
    async def test_set_activation_disable_hpa_not_found(self, mock_delete_hpa_conf, mock_get_configuration):
        # Covers: hpa["hpa"] is None, triggers HTTPException for deactivation
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': [{'name': 'svc', 'hpa': None}]}],
            'deploymentconfigs': []
        }
        with self.assertRaises(HTTPException) as ctx:
            await hpa.set_activation('env', 'cl', 'ns', False, ['svc'], 'ldap')
        self.assertIn('has not HPA in cl region for deactivation', str(ctx.exception.detail))

    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    async def test_set_activation_microservice_not_in_any(self, mock_get_configuration):
        # Covers: microservice not in deployments or deploymentconfigs
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': []}],
            'deploymentconfigs': [{'cluster': 'cl', 'items': []}]
        }
        with self.assertRaises(HTTPException) as ctx:
            await hpa.set_activation('env', 'cl', 'ns', True, ['svc'], 'ldap')
        self.assertIn('not found in HPAs in cl region', str(ctx.exception.detail))

    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    @patch('src.services.hpa.update_hpa_conf', new_callable=AsyncMock)
    async def test_set_activation_enable_hpa_wrong_source(self, mock_update_hpa_conf, mock_get_configuration):
        # Covers: hpa["hpa"] exists but no sourceConfig == 'shuttle.hpa.manager'
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': [{'name': 'svc', 'hpa': [{'sourceConfig': 'other'}]}]}],
            'deploymentconfigs': []
        }
        with self.assertRaises(HTTPException) as ctx:
            await hpa.set_activation('env', 'cl', 'ns', True, ['svc'], 'ldap')
        self.assertIn('has not HPA in shuttle.hpa.manager in cl region for activation', str(ctx.exception.detail))

    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    @patch('src.services.hpa.delete_hpa_conf', new_callable=AsyncMock)
    async def test_set_activation_disable_hpa_wrong_source(self, mock_delete_hpa_conf, mock_get_configuration):
        # Covers: hpa["hpa"] exists but no sourceConfig == 'HorizontalPodAutoscaler', should log and continue
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': [{'name': 'svc', 'hpa': [{'sourceConfig': 'other'}]}]}],
            'deploymentconfigs': []
        }
        # Should not raise, just skip
        result = await hpa.set_activation('env', 'cl', 'ns', False, ['svc'], 'ldap')
        self.assertEqual(result['hpa'], True)
        self.assertEqual(result['reason'], 'HPA disabled')

    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    @patch('src.services.hpa.update_hpa_conf', new_callable=AsyncMock)
    async def test_set_activation_enable_update_hpa_conf_fail(self, mock_update_hpa_conf, mock_get_configuration):
        # Covers: update_hpa_conf returns status != ok
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': [{'name': 'svc', 'hpa': [{'sourceConfig': 'shuttle.hpa.manager'}]}]}],
            'deploymentconfigs': []
        }
        mock_update_hpa_conf.return_value = {'status': 'fail', 'response': 'error'}
        result = await hpa.set_activation('env', 'cl', 'ns', True, ['svc'], 'ldap')
        self.assertEqual(result['hpa'], False)
        self.assertEqual(result['reason'], 'error')
        self.assertIn('svc', result['microservice'])

    @patch('src.services.hpa.get_configuration', new_callable=AsyncMock)
    @patch('src.services.hpa.delete_hpa_conf', new_callable=AsyncMock)
    async def test_set_activation_disable_delete_hpa_conf_fail(self, mock_delete_hpa_conf, mock_get_configuration):
        # Covers: delete_hpa_conf returns status != ok
        mock_get_configuration.return_value = {
            'deployments': [{'cluster': 'cl', 'items': [{'name': 'svc', 'hpa': [{'sourceConfig': 'HorizontalPodAutoscaler'}]}]}],
            'deploymentconfigs': []
        }
        mock_delete_hpa_conf.return_value = {'status': 'fail', 'response': 'error'}
        result = await hpa.set_activation('env', 'cl', 'ns', False, ['svc'], 'ldap')
        self.assertEqual(result['hpa'], False)
        self.assertEqual(result['reason'], 'error')
        self.assertIn('svc', result['microservice'])

    async def test_get_hpa_conf_missing_keys(self):
        # Should return None if keys are missing
        microservice = {'json': {'metadata': {}}, 'type': 'deployment'}
        hpa_list = []
        result = await hpa.get_hpa_conf(microservice, hpa_list)
        self.assertIsNone(result)

    async def test_get_hpa_conf_invalid_annotations(self):
        # Should return None if annotations missing
        microservice = {'json': {'metadata': {'annotations': {}}}, 'type': 'deployment'}
        hpa_list = []
        result = await hpa.get_hpa_conf(microservice, hpa_list)
        self.assertIsNone(result)

    @patch('src.services.hpa.api_update_annotations', new_callable=AsyncMock)
    async def test_update_hpa_conf_invalid_mode(self, mock_api_update_annotations):
        microservice = MagicMock()
        microservice.hpa = MagicMock(minReplicas=1, maxReplicas=2, targetCPUUtilizationPercentage=50)
        microservice.name = 'svc'
        microservice.type = 'deployment'
        microservice.region = 'cl'
        with self.assertRaises(ValueError):
            await hpa.update_hpa_conf(microservice, 'invalid_mode', {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}, 'ldap')

    @patch('src.services.hpa.aiohttp.ClientSession', autospec=True)
    @patch('src.services.hpa.client')
    async def test_api_update_annotations_invalid_type(self, mock_client, mock_aiohttp_cls):
        # Should raise HTTPException for invalid type
        microservice = MagicMock()
        microservice.type = 'invalidtype'
        microservice.name = 'svc'
        microservice.region = 'cl'
        client_map = {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}
        mock_client.clusters = {'env': {'cl': {'cl': {'url': 'http://test', 'token': 'token'}}}}
        with self.assertRaises(HTTPException) as ctx:
            await hpa.api_update_annotations(client_map, {}, microservice)
        self.assertIn('not valid/found', str(ctx.exception.detail))

    @patch('src.services.hpa.aiohttp.ClientSession', autospec=True)
    @patch('src.services.hpa.client')
    async def test_api_update_annotations_http_error(self, mock_client, mock_aiohttp_cls):
        microservice = MagicMock()
        microservice.type = 'deployment'
        microservice.name = 'svc'
        microservice.region = 'cl'
        client_map = {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}
        mock_client.clusters = {'env': {'cl': {'cl': {'url': 'http://test', 'token': 'token'}}}}
        mock_response = MagicMock()
        mock_response.status = 400
        mock_response.json = AsyncMock(return_value={'error': 'fail'})
        mock_ctx_mgr = MagicMock()
        mock_ctx_mgr.__aenter__ = AsyncMock(return_value=mock_response)
        mock_ctx_mgr.__aexit__ = AsyncMock(return_value=None)
        mock_session = MagicMock()
        mock_session.patch.return_value = mock_ctx_mgr
        mock_aiohttp_cls.return_value.__aenter__.return_value = mock_session
        with self.assertRaises(HTTPException) as ctx:
            await hpa.api_update_annotations(client_map, {}, microservice)
        self.assertIn('Error updating annotations', str(ctx.exception.detail))

    @patch('src.services.hpa.aiohttp.ClientSession')
    @patch('src.services.hpa.client')
    async def test_api_delete_hpa_http_error(self, mock_client, mock_aiohttp_cls):
        microservice = MagicMock()
        microservice.type = 'deployment'
        microservice.name = 'svc'
        microservice.region = 'cl'
        client_map = {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}
        mock_client.clusters = {'env': {'cl': {'cl': {'url': 'http://test', 'token': 'token'}}}}
        mock_response = MagicMock()
        mock_response.status = 400
        mock_response.json = AsyncMock(return_value={'error': 'fail'})
        mock_ctx_mgr = MagicMock()
        mock_ctx_mgr.__aenter__ = AsyncMock(return_value=mock_response)
        mock_ctx_mgr.__aexit__ = AsyncMock(return_value=None)
        mock_session = MagicMock()
        mock_session.delete.return_value = mock_ctx_mgr
        mock_aiohttp_cls.return_value.__aenter__.return_value = mock_session
        with self.assertRaises(HTTPException) as ctx:
            await hpa.api_delete_hpa(client_map, microservice)
        self.assertIn('Error creating HPA', str(ctx.exception.detail))

    @patch('src.services.hpa.aiohttp.ClientSession')
    @patch('src.services.hpa.client')
    async def test_api_get_hpa_http_error(self, mock_client, mock_aiohttp_cls):
        microservice = MagicMock()
        microservice.type = 'deployment'
        microservice.name = 'svc'
        microservice.region = 'cl'
        client_map = {'functionalEnvironment': 'env', 'cluster': 'cl', 'namespace': 'ns'}
        mock_client.clusters = {'env': {'cl': {'cl': {'url': 'http://test', 'token': 'token'}}}}
        mock_response = MagicMock()
        mock_response.status = 400
        mock_response.json = AsyncMock(return_value={'error': 'fail'})
        mock_ctx_mgr = MagicMock()
        mock_ctx_mgr.__aenter__ = AsyncMock(return_value=mock_response)
        mock_ctx_mgr.__aexit__ = AsyncMock(return_value=None)
        mock_session = MagicMock()
        mock_session.get.return_value = mock_ctx_mgr
        mock_aiohttp_cls.return_value.__aenter__.return_value = mock_session
        with self.assertRaises(HTTPException) as ctx:
            await hpa.api_get_hpa(client_map, microservice)
        self.assertIn('Error creating HPA', str(ctx.exception.detail))

    @pytest.mark.asyncio
    async def test_update_configuration_type_invalid(self):
        from src.services import hpa
        class Dummy:
            def __init__(self):
                self.type = 'invalidtype'
                self.name = 'svc'
                self.region = 'cl1'
        data = [Dummy()]
        async def fake_check_service(_):
            return {'cl1': {'bg_services': [], 'gb_services': []}}
        monkeypatch = pytest.MonkeyPatch()
        monkeypatch.setattr(hpa, 'check_service', fake_check_service)
        monkeypatch.setattr(hpa, 'Workloads', MagicMock(return_value=MagicMock(get_workloads=AsyncMock(), deployments={'cl1': {'items': []}}, deploymentconfigs={'cl1': {'items': []}}, hpas={'cl1': {'items': []}}, services={'cl1': {'items': []}})))
        with pytest.raises(HTTPException) as excinfo:
            await hpa.update_configuration('env', 'cl1', 'ns', 'ldap', data)
        assert 'not found' in str(excinfo.value.detail)
        monkeypatch.undo()

    @pytest.mark.asyncio
    async def test_update_configuration_element_not_found(self):
        from src.services import hpa
        class Dummy:
            def __init__(self):
                self.type = 'deployment'
                self.name = 'svc-notfound'
                self.region = 'cl1'
        data = [Dummy()]
        async def fake_check_service(_):
            return {'cl1': {'bg_services': [], 'gb_services': []}}
        monkeypatch = pytest.MonkeyPatch()
        monkeypatch.setattr(hpa, 'check_service', fake_check_service)
        monkeypatch.setattr(hpa, 'Workloads', MagicMock(return_value=MagicMock(get_workloads=AsyncMock(), deployments={'cl1': {'items': []}}, deploymentconfigs={'cl1': {'items': []}}, hpas={'cl1': {'items': []}}, services={'cl1': {'items': []}})))
        with pytest.raises(HTTPException) as excinfo:
            await hpa.update_configuration('env', 'cl1', 'ns', 'ldap', data)
        assert 'not found' in str(excinfo.value.detail)
        monkeypatch.undo()

    @pytest.mark.asyncio
    async def test_update_configuration_both_selectors(self):
        from src.services import hpa
        class Dummy:
            def __init__(self):
                self.type = 'deployment'
                self.name = 'svc'
                self.region = 'cl1'
        data = [Dummy()]
        async def fake_check_service(_):
            return {'cl1': {'bg_services': [{'selector': 'svc'}], 'gb_services': [{'selector': 'svc'}]}}
        monkeypatch = pytest.MonkeyPatch()
        monkeypatch.setattr(hpa, 'check_service', fake_check_service)
        monkeypatch.setattr(hpa, 'Workloads', MagicMock(return_value=MagicMock(get_workloads=AsyncMock(), deployments={'cl1': {'items': [{'metadata': {'name': 'svc', 'uid': 'uid'}, 'spec': {'replicas': 1}}]}}, deploymentconfigs={'cl1': {'items': []}}, hpas={'cl1': {'items': []}}, services={'cl1': {'items': []}})))
        with pytest.raises(HTTPException) as excinfo:
            await hpa.update_configuration('env', 'cl1', 'ns', 'ldap', data)
        assert 'is in both gb and bg services' in str(excinfo.value.detail)
        monkeypatch.undo()

    @pytest.mark.asyncio
    async def test_update_configuration_no_selector(self):
        from src.services import hpa
        class Dummy:
            def __init__(self):
                self.type = 'deployment'
                self.name = 'svc'
                self.region = 'cl1'
        data = [Dummy()]
        async def fake_check_service(_):
            return {'cl1': {'bg_services': [], 'gb_services': []}}
        monkeypatch = pytest.MonkeyPatch()
        monkeypatch.setattr(hpa, 'check_service', fake_check_service)
        monkeypatch.setattr(hpa, 'Workloads', MagicMock(return_value=MagicMock(get_workloads=AsyncMock(), deployments={'cl1': {'items': [{'metadata': {'name': 'svc', 'uid': 'uid'}, 'spec': {'replicas': 1}}]}}, deploymentconfigs={'cl1': {'items': []}}, hpas={'cl1': {'items': []}}, services={'cl1': {'items': []}})))
        with pytest.raises(HTTPException) as excinfo:
            await hpa.update_configuration('env', 'cl1', 'ns', 'ldap', data)
        assert 'not found in services' in str(excinfo.value.detail)
        monkeypatch.undo()

    @pytest.mark.asyncio
    async def test_get_hpa_conf_invalid_annotations(self):
        from src.services import hpa
        microservice = {'json': {'metadata': {'name': 'svc', 'annotations': {'shuttle.hpa.manager': "{'minReplicas': 1, 'maxReplicas': 2}"}}}, 'type': 'deployment'}
        hpa_list = []
        result = await hpa.get_hpa_conf(microservice, hpa_list)
        assert isinstance(result, list) or result is None

    @pytest.mark.asyncio
    async def test_get_hpa_conf_keyerror_and_metrics(self):
        from src.services import hpa
        microservice = {'json': {'metadata': {'name': 'svc', 'annotations': {}}}, 'type': 'deployment'}
        hpa_list = [{'spec': {'scaleTargetRef': {'name': 'svc', 'kind': 'deployment'}, 'minReplicas': 1, 'maxReplicas': 2, 'metrics': [{'resource': {'target': {'averageUtilization': 50}}}]}}]
        result = await hpa.get_hpa_conf(microservice, hpa_list)
        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_get_hpa_conf_keyerror_and_no_metrics(self):
        from src.services import hpa
        microservice = {'json': {'metadata': {'name': 'svc', 'annotations': {}}}, 'type': 'deployment'}
        hpa_list = [{'spec': {'scaleTargetRef': {'name': 'svc', 'kind': 'deployment'}, 'minReplicas': 1, 'maxReplicas': 2}}]
        result = await hpa.get_hpa_conf(microservice, hpa_list)
        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_get_hpa_conf_missing_keys(self):
        from src.services import hpa
        microservice = {'json': {'metadata': {'name': 'svc'}}, 'type': 'deployment'}
        hpa_list = []
        result = await hpa.get_hpa_conf(microservice, hpa_list)
        assert result is None

    @pytest.mark.asyncio
    async def test_check_service_missing_selector(self):
        from src.services import hpa
        clusterServices = {'cl': {'items': [{'metadata': {'name': 'b-g-svc'}, 'spec': {'selector': {}}}]}}  # noqa: E501
        with pytest.raises(HTTPException) as excinfo:
            await hpa.check_service(clusterServices)
        assert 'not found in selector' in str(excinfo.value.detail)

    @pytest.mark.asyncio
    async def test_check_service_duplicate_selector(self):
        from src.services import hpa
        clusterServices = {'cl': {'items': [
            {'metadata': {'name': 'b-g-svc'}, 'spec': {'selector': {'app_name': 'svc'}}},
            {'metadata': {'name': 'g-b-svc'}, 'spec': {'selector': {'app_name': 'svc'}}},
        ]}}  # noqa: E501
        with pytest.raises(HTTPException) as excinfo:
            await hpa.check_service(clusterServices)
        assert 'b-g-service with the same selector' in str(excinfo.value.detail)

    async def test_check_deployments_no_match(self):
        from src.services import hpa
        deployments = {'cl': {'items': [{'metadata': {'name': 'svc1'}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        deploymentconfigs = {'cl': {'items': [{'metadata': {'name': 'svc2'}, 'spec': {'replicas': 1}}]}}  # noqa: E501
        services = {'cl': {'bg_services': [{'selector': 'svc3'}], 'gb_services': [{'selector': 'svc4'}]}}  # noqa: E501
        hpas = {'cl': {'items': []}}
        result = await hpa.check_deployments(deployments, deploymentconfigs, services, hpas)
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_replicate_configuration_no_hpa(self):
        from src.services import hpa
        hpaConfig = {'deploymentconfigs': [{'cluster': 'cl', 'items': [{'name': 'svc', 'replicas': 1, 'uid': 'uid', 'hpa': []}]}], 'deployments': [{'cluster': 'cl', 'items': [{'name': 'svc', 'replicas': 1, 'uid': 'uid', 'hpa': []}]}]}
        async def fake_get_configuration(*args, **kwargs):
            return hpaConfig
        async def fake_update_hpa_conf(*args, **kwargs):
            return {'status': 'ok'}
        monkeypatch = pytest.MonkeyPatch()
        monkeypatch.setattr(hpa, 'get_configuration', fake_get_configuration)
        monkeypatch.setattr(hpa, 'update_hpa_conf', fake_update_hpa_conf)
        monkeypatch.setattr(hpa, 'Workloads', MagicMock(return_value=MagicMock(get_workloads=AsyncMock(), services={'cl': {'items': []}})))
        result = await hpa.replicate_configuration('env', 'cl', 'ns', 'ldap')
        assert result['status'] == 'ok' or result['status'] == 'ko'
        monkeypatch.undo()
if __name__ == '__main__':
    unittest.main()
