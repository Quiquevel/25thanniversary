import pytest
from unittest.mock import AsyncMock, patch
import src.middleware.authorization as auth

@pytest.mark.asyncio
async def test_is_devops_valid(monkeypatch):
    monkeypatch.setattr(auth, 'verify_token', AsyncMock(return_value=True))
    monkeypatch.setattr(auth, 'get_alm_teams', AsyncMock(return_value=True))
    class Token:
        scheme = "Bearer"
        credentials = "token"
    result = await auth.is_devops(Token(), "x021096")
    assert result is None or result is True
