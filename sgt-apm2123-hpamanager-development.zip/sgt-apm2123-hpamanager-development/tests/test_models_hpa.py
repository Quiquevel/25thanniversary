from src.models.hpa import HpaData, UpdateData, HpaActivation, HpaConfiguration, UpdateHpaConfiguration

def test_hpa_data_model():
    hpa = HpaData(minReplicas=1, maxReplicas=5, targetCPUUtilizationPercentage=80, sourceConfig="test")
    assert hpa.minReplicas == 1
    assert hpa.maxReplicas == 5
    assert hpa.targetCPUUtilizationPercentage == 80
    assert hpa.sourceConfig == "test"

def test_update_data_model():
    hpa = HpaData(minReplicas=1, maxReplicas=5, targetCPUUtilizationPercentage=80)
    upd = UpdateData(name="svc", hpa=hpa, type="test-type")
    assert upd.name == "svc"
    assert upd.hpa == hpa

def test_hpa_activation_model():
    act = HpaActivation(functionalEnvironment="dev", cluster="c1", namespace="ns", enable=True, microservices=["svc"], ldap="x021096")
    assert act.enable is True
    assert act.microservices == ["svc"]

def test_hpa_configuration_model():
    conf = HpaConfiguration(functionalEnvironment="dev", cluster="c1", namespace="ns", ldap="x021096")
    assert conf.cluster == "c1"
    assert conf.ldap == "x021096"

def test_update_hpa_configuration_model():
    upd = UpdateHpaConfiguration(functionalEnvironment="dev", cluster="c1", namespace="ns", data=[], ldap="x021096")
    assert upd.data == []
