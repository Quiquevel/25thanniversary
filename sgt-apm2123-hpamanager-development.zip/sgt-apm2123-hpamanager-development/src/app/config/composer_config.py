from version import __version__
from ..config import global_config

config = {
     "version": __version__,
     "cors": {
          "enable": True
     },
     "openapi": {
          "enable": True,
          "title": "Shuttle Openshift HPA Manager",
          "description": "Microservice to manage HPA in Shuttle Openshift",
     },
     "i18n": {
          "enable": False,
          "fallback": "en",
     }
}
