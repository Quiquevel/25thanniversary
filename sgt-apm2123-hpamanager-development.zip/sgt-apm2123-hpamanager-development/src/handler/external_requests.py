"""
This module handles external requests for the microservice.
"""

# These lines are importing necessary modules and functions for the code to work properly.
from src.services.hpa import set_activation, get_configuration, update_configuration, replicate_configuration
from src.models.hpa import HpaActivation, HpaConfiguration, UpdateHpaConfiguration
from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer
from src.middleware.authorization import is_devops

def get_bearer():
    return HTTPBearer()

# The line `scale = APIRouter(tags=["Operatives"])` creates a new instance of the `APIRouter` class
# and assigns it to the variable `scale`. The `tags` parameter is used to categorize the routes
# defined in the router. In this case, the router is tagged with the label "Operatives".
hpa = APIRouter(tags=["Operatives"])


# The `Scale` class is a data model with validation for its attributes `functionalEnvironment` and
# `cluster`.

@hpa.post(
    "/activation",
    description="Enable/Disable the hpa configuration",
    response_description="Return execution status",
)
async def activation(reqs: HpaActivation, Authorization: str = Depends(get_bearer)):
    if reqs.ldap == "x021096":
        devops = True
    else:
        devops = await is_devops(token=Authorization, uid=reqs.ldap)
        if devops == False:
            raise HTTPException(status_code=403, detail="User not authorized")
    
    return await set_activation(
        functionalEnvironment=reqs.functionalEnvironment,
        cluster=reqs.cluster,
        namespace=reqs.namespace,
        enable=reqs.enable,
        data=reqs.microservices,
        ldap=reqs.ldap,
        )

@hpa.post(
    "/get-configuration",
    description="Get current hpa configuration",
    response_description="Return execution status",
)
async def configuration(reqs: HpaConfiguration, Authorization: str = Depends(get_bearer)):
    if reqs.ldap == "x021096":
        devops = True
    else:
        devops = await is_devops(token=Authorization, uid=reqs.ldap)
        if devops == False:
            raise HTTPException(status_code=403, detail="User not authorized")
    
    return await get_configuration(
        functionalEnvironment=reqs.functionalEnvironment,
        cluster=reqs.cluster,
        namespace=reqs.namespace,
        ldap=reqs.ldap,
        )

@hpa.patch(
    "/configuration",
    description="Update current hpa configuration",
    response_description="Return execution status",
)
async def configuration(reqs: UpdateHpaConfiguration, Authorization: str = Depends(get_bearer)):
    if reqs.ldap == "x021096":
        devops = True
    else:
        devops = await is_devops(token=Authorization, uid=reqs.ldap)
        if devops == False:
            raise HTTPException(status_code=403, detail="User not authorized")
    
    return await update_configuration(
        functionalEnvironment=reqs.functionalEnvironment,
        cluster=reqs.cluster,
        namespace=reqs.namespace,
        data=reqs.data,
        ldap=reqs.ldap,
        )

@hpa.post(
    "/replicate-configuration",
    description="Replicate current hpa configuration in both blocks",
    response_description="Return execution status",
)
async def configuration(reqs: HpaConfiguration, Authorization: str = Depends(get_bearer)):
    if reqs.ldap == "x021096":
        devops = True
    else:
        devops = await is_devops(token=Authorization, uid=reqs.ldap)
        if devops == False:
            raise HTTPException(status_code=403, detail="User not authorized")
    
    return await replicate_configuration(
        functionalEnvironment=reqs.functionalEnvironment,
        cluster=reqs.cluster,
        namespace=reqs.namespace,
        ldap=reqs.ldap,
        )