from src.handler.external_requests import hpa
from darwin_composer.DarwinComposer import RouteClass

routers = [
    RouteClass(hpa, ["HPA"]),
]
