from pydantic import BaseModel


class HpaData(BaseModel):
    
    minReplicas: int
    maxReplicas: int
    targetCPUUtilizationPercentage: int
    sourceConfig: str = None

class UpdateData(BaseModel):
    
    name: str
    region: str = None
    type: str
    hpa: HpaData

class HpaActivation(BaseModel):
    
    functionalEnvironment: str
    cluster: str
    region: str = None
    namespace: str
    enable: bool
    microservices: list
    ldap: str

class HpaConfiguration(BaseModel):
    
    functionalEnvironment: str
    cluster: str
    region: str = None
    namespace: str
    ldap: str

class UpdateHpaConfiguration(BaseModel):
    
    functionalEnvironment: str
    cluster: str
    namespace: str
    data: list[UpdateData]
    ldap: str