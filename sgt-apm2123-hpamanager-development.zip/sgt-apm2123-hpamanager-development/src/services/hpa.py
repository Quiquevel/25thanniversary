import aiohttp, datetime
from fastapi import HTTPException
from src.services.workloads import Workloads, client
import logging as logger
from src.models.hpa import *


async def set_activation(functionalEnvironment, cluster, namespace, enable, data, ldap):
    
    client_map = {
        "functionalEnvironment": functionalEnvironment,
        "cluster": cluster,
        "namespace": namespace
    }
    hpaConfig = await get_configuration(
        functionalEnvironment=functionalEnvironment,
        cluster=cluster,
        namespace=namespace,
        ldap=ldap
        )
    
    targetHpaConfig = {}

    region_keys = [k["cluster"] for k in hpaConfig["deployments"]]
    for k in region_keys:
        targetHpaConfig[k] = {}
        for target_microservice in data:
            if target_microservice in str(hpaConfig["deployments"]) and target_microservice in str(hpaConfig["deploymentconfigs"]):
                raise HTTPException(status_code=400, detail=f"Microservice {target_microservice} is in both Deployment and DeploymentConfig HPAs in {k} region")
            elif target_microservice not in str(hpaConfig["deployments"]) and target_microservice not in str(hpaConfig["deploymentconfigs"]):
                raise HTTPException(status_code=404, detail=f"Microservice {target_microservice} not found in HPAs in {k} region")
            
            if target_microservice in str(hpaConfig["deployments"]):
                for hpa in hpaConfig["deployments"]:
                    if hpa["cluster"] == k:
                        targetHpaConfig[k][target_microservice] = [hpa for hpa in hpa["items"] if target_microservice == hpa["name"]]
                        if len(targetHpaConfig[k][target_microservice]) == 0:
                            raise HTTPException(status_code=404, detail=f"Microservice {target_microservice} not found in HPAs in {k} region")
            elif target_microservice in str(hpaConfig["deploymentconfigs"]):
                for hpa in hpaConfig["deploymentconfigs"]:
                    if hpa["cluster"] == k:
                        targetHpaConfig[k][target_microservice] = [hpa for hpa in hpa["items"] if target_microservice == hpa["name"]]
                        if len(targetHpaConfig[k][target_microservice]) == 0:
                            raise HTTPException(status_code=404, detail=f"Microservice {target_microservice} not found in HPAs in {k} region")
            else:
                raise HTTPException(status_code=404, detail=f"Microservice {target_microservice} not found in HPAs in {k} region")

    if enable:
        for k in region_keys:
            target_result = {
                "hpa": True,
                "reason": "HPA enabled",
                "microservice": []
            }
            for target_microservice in data:
                for hpa in targetHpaConfig[k][target_microservice]:
                    if isinstance(hpa["hpa"], dict):
                        hpa["hpa"] = [hpa["hpa"]]
                    if hpa["hpa"] is not None:
                        if not any(hpaConfig["sourceConfig"] == "shuttle.hpa.manager" for hpaConfig in hpa["hpa"]):
                            raise HTTPException(status_code=404, detail=f"Microservice {target_microservice} has not HPA in shuttle.hpa.manager in {k} region for activation")
                        
                        managerConfig = [hpaConfig for hpaConfig in hpa["hpa"] if hpaConfig["sourceConfig"] == "shuttle.hpa.manager"][0]
                        hpa["hpa"] = managerConfig
                        response = await update_hpa_conf(microservice=hpa, hpa_mode="apiserver", client_map=client_map, ldap=ldap)
                        if response["status"] != "ok":
                            target_result["hpa"] = False
                            target_result["reason"] = response["response"]
                            target_result["microservice"].append(target_microservice)
                    else:
                        raise HTTPException(status_code=404, detail=f"Microservice {target_microservice} has not HPA in {k} region for activation")
        if target_result["hpa"]:
            del(target_result["microservice"])
            return target_result
        else:
            return target_result
    else:
        for k in region_keys:
            target_result = {
                "hpa": True,
                "reason": "HPA disabled",
                "microservice": []
            }
            for target_microservice in data:
                for hpa in targetHpaConfig[k][target_microservice]:
                    if hpa["hpa"] is not None:
                        if not any(hpaConfig["sourceConfig"] == "HorizontalPodAutoscaler" for hpaConfig in hpa["hpa"]):
                            logger.info(f"Microservice {target_microservice} has not HPA in HorizontalPodAutoscaler in {k} region for deactivation")
                            continue
                        
                        hpaConfig = [hpaConfig for hpaConfig in hpa["hpa"] if hpaConfig["sourceConfig"] == "HorizontalPodAutoscaler"][0]
                        hpa["hpa"] = hpaConfig
                        response = await delete_hpa_conf(microservice=hpa, client_map=client_map, ldap=ldap)
                        if response["status"] != "ok":
                            target_result["hpa"] = False
                            target_result["reason"] = response["response"]
                            target_result["microservice"].append(target_microservice)
                    else:
                        raise HTTPException(status_code=404, detail=f"Microservice {target_microservice} has not HPA in {k} region for deactivation")
        if target_result["hpa"]:
            del(target_result["microservice"])
            return target_result
        else:
            return target_result

async def get_configuration(functionalEnvironment, cluster, namespace, ldap):

    workloads = Workloads(
        functionalEnvironment=functionalEnvironment,
        cluster=cluster,
        namespace=namespace,
    )

    await workloads.get_workloads()

    response = {"project": namespace, "deploymentconfigs": [], "deployments": []}

    for k in workloads.deploymentconfigs.keys():
        deploymentconfigs = {"cluster": k, "items": []}
        for i in workloads.deploymentconfigs[k]["items"]:
            hpa = await get_hpa_conf({"json": i, "type": "deploymentconfig"}, workloads.hpas[k]["items"])
            if hpa is None:
                deploymentconfigs["items"].append(
                    {
                        "name": i["metadata"]["name"],
                        "replicas": i["spec"]["replicas"],
                        "region": k,
                        "uid": i["metadata"]["uid"],
                        "hpa": None,
                        "type": "deploymentconfig"
                    }
                )
            else:
                deploymentconfigs["items"].append(
                    {
                        "name": i["metadata"]["name"],
                        "replicas": i["spec"]["replicas"],
                        "region": k,
                        "uid": i["metadata"]["uid"],
                        "hpa": hpa,
                        "type": "deploymentconfig"
                    }
                )
        response["deploymentconfigs"].append(deploymentconfigs)

        deployments = {"cluster": k, "items": []}
        for i in workloads.deployments[k]["items"]:
            hpa = await get_hpa_conf({"json": i, "type": "deployment"}, workloads.hpas[k]["items"])
            if hpa is None:
                deployments["items"].append(
                    {
                        "name": i["metadata"]["name"],
                        "replicas": i["spec"]["replicas"],
                        "region": k,
                        "uid": i["metadata"]["uid"],
                        "hpa": None,
                        "type": "deployment"
                    }
                )
            else:
                deployments["items"].append(
                    {
                        "name": i["metadata"]["name"],
                        "replicas": i["spec"]["replicas"],
                        "region": k,
                        "uid": i["metadata"]["uid"],
                        "hpa": hpa,
                        "type": "deployment"
                    }
                )

        response["deployments"].append(deployments)

    return response

async def update_configuration(functionalEnvironment, cluster, namespace,ldap, data):
    
    workloads = Workloads(
        functionalEnvironment=functionalEnvironment,
        cluster=cluster,
        namespace=namespace
    )

    client_map = {
        "functionalEnvironment": functionalEnvironment,
        "cluster": cluster,
        "namespace": namespace
    }

    await workloads.get_workloads()

    services = await check_service(workloads.services)
    bg_selectors = {}
    gb_selectors = {}
    for k in services.keys():
        bg_selectors[k] = [service["selector"] for service in services[k]["bg_services"]]
        gb_selectors[k] = [service["selector"] for service in services[k]["gb_services"]]
 
    response = {"status": "ok", "response": []}
    for element in data:
        try:
            if element.type == 'deployment':
                type_plural = 'deployments'
                response[type_plural] = []
                deployment = [deployment for deployment in workloads.deployments[element.region]['items'] if deployment['metadata']['name'] == element.name][0]
            elif element.type == 'deploymentconfig':
                type_plural = 'deploymentconfigs'
                response[type_plural] = []
                deployment = [deployment for deployment in workloads.deploymentconfigs[element.region]['items'] if deployment['metadata']['name'] == element.name][0]
            else:
                raise HTTPException(status_code=404, detail=f"Type {element.type} not valid")
        except:
            raise HTTPException(status_code=404, detail=f"{element.name} not found in {element.type}s")
        if element.name in bg_selectors[element.region] and not element.name in gb_selectors[element.region]:
            result = await update_hpa_conf(microservice=element, hpa_mode="annotations", client_map=client_map, ldap=ldap)
            if result["status"] == "ok":
                response["response"].append(f"Microservice {element.name} updated")
                if element.type == 'deployment':
                    hpa = await get_hpa_conf({"json": result['response'], "type": "deployment"}, workloads.hpas[element.region]["items"])
                elif element.type == 'deploymentconfig':
                    hpa = await get_hpa_conf({"json": result['response'], "type": "deploymentconfig"}, workloads.hpas[element.region]["items"])
            else:
                response["status"] = "ko"
                response["response"].append(result["response"])
                if element.type == 'deployment':
                    hpa = await get_hpa_conf({"json": deployment, "type": "deployment"}, workloads.hpas[element.region]["items"])
                elif element.type == 'deploymentconfig':
                    hpa = await get_hpa_conf({"json": deployment, "type": "deploymentconfig"}, workloads.hpas[element.region]["items"])
                
        elif element.name in gb_selectors[element.region] and not element.name in bg_selectors[element.region]:
            result = await update_hpa_conf(microservice=element, hpa_mode="apiserver", client_map=client_map, ldap=ldap)
            if result["status"] == "ok":
                response["response"].append(f"Microservice {element.name} updated")
                
                if element.type == 'deployment':
                    hpa = await get_hpa_conf({"json": deployment, "type": "deployment"}, [result['response']])
                elif element.type == 'deploymentconfig':
                    hpa = await get_hpa_conf({"json": deployment, "type": "deploymentconfig"}, [result['response']])
            else:
                response["status"] = "ko"
                response["response"].append(result["response"])
                if element.type == 'deployment':
                    hpa = await get_hpa_conf({"json": deployment, "type": "deployment"}, workloads.hpas[element.region]["items"])
                elif element.type == 'deploymentconfig':
                    hpa = await get_hpa_conf({"json": deployment, "type": "deploymentconfig"}, workloads.hpas[element.region]["items"])
                
        elif element.name in bg_selectors[element.region] and element.name in gb_selectors[element.region]:
            raise HTTPException(status_code=400, detail=f"Service {element.name} is in both gb and bg services")
        else:
            raise HTTPException(status_code=404, detail=f"Service for {element.name} not found in services")
        if hpa is None:
            response[type_plural].append(
                {
                    "name": deployment["metadata"]["name"],
                    "replicas": deployment["spec"]["replicas"],
                    "region": element.region,
                    "uid": deployment["metadata"]["uid"],
                    "hpa": None,
                    "type": element.type
                }
            )
        else:
            response[type_plural].append(
                {
                    "name": deployment["metadata"]["name"],
                    "replicas": deployment["spec"]["replicas"],
                    "region": element.region,
                    "uid": deployment["metadata"]["uid"],
                    "hpa": hpa,
                    "type": element.type
                }
            )
    if response["status"] != "ok":
        response["response"] = ', '.join(response["response"])

    return response
        
async def get_hpa_conf (microservice, hpa):
    hpa_conf = [hpa_conf for hpa_conf in hpa if hpa_conf['spec']['scaleTargetRef']['name'] == microservice["json"]["metadata"]["name"] and str(hpa_conf['spec']['scaleTargetRef']['kind']).lower() == microservice["type"]]
    if len(hpa_conf) == 1:
        result = []
        try:
            hpaApi = {
                "minReplicas": hpa_conf[0]["spec"]["minReplicas"],
                "maxReplicas": hpa_conf[0]["spec"]["maxReplicas"],
                "targetCPUUtilizationPercentage": hpa_conf[0]['spec']['targetCPUUtilizationPercentage'],
                "sourceConfig":"HorizontalPodAutoscaler"
            }
        except KeyError:
            try:
                targetCPUUtilizationPercentage = hpa_conf[0]["spec"]["metrics"][0]['resource']['target']['averageUtilization']
            except:
                targetCPUUtilizationPercentage= None

            hpaApi = {
                "minReplicas": hpa_conf[0]["spec"]["minReplicas"],
                "maxReplicas": hpa_conf[0]["spec"]["maxReplicas"],
                "targetCPUUtilizationPercentage": targetCPUUtilizationPercentage,
                "sourceConfig":"HorizontalPodAutoscaler"
            }

        if "annotations" in microservice["json"]["metadata"].keys():
            if "shuttle.hpa.manager" in microservice['json']['metadata']['annotations'].keys():
                hpaManager = eval(microservice['json']['metadata']['annotations']['shuttle.hpa.manager'])
                hpaManager["sourceConfig"] = "shuttle.hpa.manager"
                hpaManager = HpaData.model_validate(hpaManager).model_dump()
                return [hpaApi,hpaManager]
        
        result.append(hpaApi)
        return result
    else:
        try:
            annotations = microservice["json"]["metadata"]["annotations"].keys()
            if "shuttle.hpa.manager" in annotations:
                hpa_conf = microservice["json"]["metadata"]["annotations"]["shuttle.hpa.manager"]
                hpa_conf = eval(hpa_conf)
                result = {
                    "minReplicas": hpa_conf["minReplicas"],
                    "maxReplicas": hpa_conf["maxReplicas"],
                    "targetCPUUtilizationPercentage": hpa_conf["targetCPUUtilizationPercentage"],
                    "sourceConfig":"shuttle.hpa.manager"
                }
                result = HpaData.model_validate(result).model_dump()
                return [result]
            else:
                return None
        except KeyError:
            return None

async def update_hpa_conf (microservice, hpa_mode, client_map, ldap):

    if type(microservice) is dict:
        microservice = UpdateData.model_validate(microservice)
    if hpa_mode == "annotations":
        body = {
            "metadata": {
                "annotations": {
                    "shuttle.hpa.manager": str({"minReplicas": str(microservice.hpa.minReplicas), "maxReplicas": str(microservice.hpa.maxReplicas),"targetCPUUtilizationPercentage": str(microservice.hpa.targetCPUUtilizationPercentage)}),
                    "shuttle.hpa.last-execution": str({"userID": ldap, "action": "update", "timestamp": datetime.datetime.now().isoformat()})
                }
            }
        }
        result = await api_update_annotations(client_map, body, microservice)
        return result
    elif hpa_mode == "apiserver":
        aux_param = {
            "deploymentconfig":{
                "kind": "DeploymentConfig",
                "apiVersion": "apps.openshift.io/v1"
            },
            "deployment":{
                "kind": "Deployment",
                "apiVersion": "apps/v1"
            }
        }
        body = {
            "kind": "HorizontalPodAutoscaler",
            "apiVersion": "autoscaling/v2",
            "metadata": {
                "name": microservice.name,
                "namespace": client_map["namespace"],
                "annotations": {
                    "shuttle.hpa.last-execution": str({"userID": ldap, "action": "update", "timestamp": datetime.datetime.now().isoformat()}),
                }
            },
            "spec": {
                "scaleTargetRef": {
                "kind": aux_param[microservice.type]["kind"],
                "name": microservice.name,
                "apiVersion": aux_param[microservice.type]["apiVersion"]
                },
                "minReplicas": microservice.hpa.minReplicas,
                "maxReplicas": microservice.hpa.maxReplicas,
                "metrics": [
                    {
                        "type": "Resource",
                        "resource": {
                            "name": "cpu",
                            "target": {
                                "type": "Utilization",
                                "averageUtilization": microservice.hpa.targetCPUUtilizationPercentage
                            }
                        }
                    }
                ]
            }
        }

        result = await api_update_hpa(client_map, body, microservice)
        return result
    else:
        raise ValueError(f"Invalid hpa_mode: {hpa_mode}")

async def delete_hpa_conf (microservice, client_map, ldap):

    if type(microservice) is dict:
        microservice = UpdateData.model_validate(microservice)
    
    update_result = await update_hpa_conf(microservice, hpa_mode="annotations", client_map=client_map, ldap=ldap)
    
    delete_result = await api_delete_hpa(client_map, microservice)

    if update_result["status"] == "ok" and delete_result["status"] == "ok":
        return {"status": "ok", "response": "HPA deleted"}
    else:
        return {"status": "ko", "response": f"Error deleting HPA for {microservice.name}"}

async def api_update_annotations(client_map, body, microservice):

    url = client.clusters[client_map["functionalEnvironment"]][client_map["cluster"]][microservice.region]["url"]
    token = client.clusters[client_map["functionalEnvironment"]][client_map["cluster"]][microservice.region]["token"]
    
    if microservice.type == "deployment":
        request_url = f"{url}/apis/apps/v1/namespaces/{client_map['namespace']}/deployments/{microservice.name}"
    elif microservice.type == "deploymentconfig":
        request_url = f"{url}/apis/apps.openshift.io/v1/namespaces/{client_map['namespace']}/deploymentconfigs/{microservice.name}"
    else:
        raise HTTPException(status_code=404, detail=f"Type {microservice.type} not valid/found for {microservice.name}")
        
    headers = {"Authorization": "Bearer " + token, "Accept": "application/json",
                "Content-type": "application/merge-patch+json"}
    async with aiohttp.ClientSession() as session:
        async with session.patch(request_url, headers=headers, verify_ssl=False, json=body) as r:
            answer = await r.json()
            if r.status != 200:
                logger.error(f"Error updating annotations for {microservice.name}: {answer}")
                raise HTTPException(status_code=400, detail=f"Error updating annotations for {microservice.name}: {answer}")
            else:
                logger.info(f"Annotations updated for {microservice.name} of {client_map['namespace']}")
                logger.debug(f"Annotations updated for {microservice.name} of {client_map['namespace']} with {body}: {answer}")
                return {"status": "ok", "response": answer}

async def api_update_hpa(client_map, body, microservice):

    url = client.clusters[client_map["functionalEnvironment"]][client_map["cluster"]][microservice.region]["url"]
    token = client.clusters[client_map["functionalEnvironment"]][client_map["cluster"]][microservice.region]["token"]
    
    request_url = f"{url}/apis/autoscaling/v2/namespaces/{client_map['namespace']}/horizontalpodautoscalers"
        
    headers = {"Authorization": "Bearer " + token, "Accept": "application/json","Content-type": "application/json"}
    
    async with aiohttp.ClientSession() as session:
        async with session.post(request_url, headers=headers, verify_ssl=False, json=body) as r:
            answer = await r.json()
            if r.status != 201:
                if r.status == 409:
                    logger.error(f"Error creating HPA for {microservice.name}: {answer}")
                    return {"status": "ko", "response": answer["message"]}
                logger.error(f"Error creating HPA for {microservice.name}: {answer}")
                raise HTTPException(status_code=400, detail=f"Error creating HPA for {microservice.name}: {answer}")
            else:
                logger.info(f"HPA updated for {microservice.name} of {client_map['namespace']}")
                logger.debug(f"HPA updated for {microservice.name} of {client_map['namespace']} with {body}: {answer}")
                return {"status": "ok", "response": answer}

async def api_delete_hpa(client_map, microservice):

    url = client.clusters[client_map["functionalEnvironment"]][client_map["cluster"]][microservice.region]["url"]
    token = client.clusters[client_map["functionalEnvironment"]][client_map["cluster"]][microservice.region]["token"]
    
    request_url = f"{url}/apis/autoscaling/v1/namespaces/{client_map['namespace']}/horizontalpodautoscalers/{microservice.name}"
        
    headers = {"Authorization": "Bearer " + token, "Accept": "application/json","Content-type": "application/json"}
    
    async with aiohttp.ClientSession() as session:
        async with session.delete(request_url, headers=headers, verify_ssl=False) as r:
            answer = await r.json()
            if r.status != 200:
                logger.error(f"Error deleting HPA for {microservice.name}: {answer}")
                raise HTTPException(status_code=400, detail=f"Error creating HPA for {microservice.name}: {answer}")
            else:
                logger.info(f"HPA deleted for {microservice.name} of {client_map['namespace']}")
                logger.debug(f"HPA deleted for {microservice.name} of {client_map['namespace']}: {answer}")
                return {"status": "ok", "response": answer}

async def api_get_hpa(client_map, microservice):

    url = client.clusters[client_map["functionalEnvironment"]][client_map["cluster"]][microservice.region]["url"]
    token = client.clusters[client_map["functionalEnvironment"]][client_map["cluster"]][microservice.region]["token"]
    
    request_url = f"{url}/apis/autoscaling/v1/namespaces/{client_map['namespace']}/horizontalpodautoscalers/{microservice.name}"
        
    headers = {"Authorization": "Bearer " + token, "Accept": "application/json","Content-type": "application/json"}
    
    async with aiohttp.ClientSession() as session:
        async with session.get(request_url, headers=headers, verify_ssl=False) as r:
            answer = await r.json()
            if r.status != 200:
                logger.error(f"Error getting HPA for {microservice.name}: {answer}")
                raise HTTPException(status_code=400, detail=f"Error creating HPA for {microservice.name}: {answer}")
            else:
                logger.info(f"HPA obtained for {microservice.name} of {client_map['namespace']}")
                logger.debug(f"HPA obtained for {microservice.name} of {client_map['namespace']}: {answer}")
                return answer

async def check_service(clusterServices):
    response = {}
    for k in clusterServices.keys():
        bg_services = []
        gb_services = []
        for i in clusterServices[k]["items"]:
            if i["metadata"]["name"].startswith("b-g-"):
                name = i["metadata"]["name"]
                try:
                    if i["spec"]["selector"]["app_name"] != "":
                        selector = i["spec"]["selector"]["app_name"]
                except KeyError:
                    try:
                        if i["spec"]["selector"]["app.kubernetes.io/name"] != "":
                            selector = i["spec"]["selector"]["app.kubernetes.io/name"]
                    except KeyError:
                        raise HTTPException(
                            status_code=404,
                            detail=f"app_name or app.kubernetes.io/name not found in selector for service {i['metadata']['name']}",
                        )

                bg_services.append({"name": name, "selector": selector})

            elif i["metadata"]["name"].startswith("g-b-"):
                name = i["metadata"]["name"]
                try:
                    if i["spec"]["selector"]["app_name"] != "":
                        selector = i["spec"]["selector"]["app_name"]
                except KeyError:
                    try:
                        if i["spec"]["selector"]["app.kubernetes.io/name"] != "":
                            selector = i["spec"]["selector"]["app.kubernetes.io/name"]
                    except KeyError:
                        raise HTTPException(
                            status_code=404,
                            detail=f"app_name or app.kubernetes.io/name not found in selector for service {i['metadata']['name']}",
                        )

                gb_services.append({"name": name, "selector": selector})

        response[k] = {"bg_services": bg_services, "gb_services": gb_services}

        gb_selectors = [service["selector"] for service in gb_services]
        bg_selectors = [service["selector"] for service in bg_services]

        if any(selector in bg_selectors for selector in gb_selectors):
            raise HTTPException(
                status_code=400,
                detail=f"There is a b-g-service with the same selector that his g-b-service",
            )

    return response

async def check_deployments(deployments, deploymentcongfigs, services, hpas):
    selected_items = {}

    for k in services.keys():
        selected_items[k] = {}
        selected_items[k]["bg_deployments"] = []
        selected_items[k]["gb_deployments"] = []

        suffixes = [service.get("selector", "").split("-")[-1] for service in services[k]["gb_services"]]
        same_suffix = all(suffix == suffixes[0] for suffix in suffixes)
        if same_suffix:
            pass
            ##TODO get config service name
        for i in services[k]["gb_services"]:
            selector = i["selector"]
            for j in deployments[k]["items"]:
                if selector == j["metadata"]["name"]:
                    #Recover HPA configuration from metadata
                    hpa_config = [hpa_conf for hpa_conf in hpas[k]['items'] if hpa_conf['spec']['scaleTargetRef']['name'] == j["metadata"]["name"] and hpa_conf['spec']['scaleTargetRef']['kind'] == "Deployment"]
                    if len(hpa_config) == 1:
                        selected_items[k]["gb_deployments"].append(
                            {
                                "type": "deployment",
                                "name": j["metadata"]["name"],
                                "replicas": j["spec"]["replicas"],
                                "hpa": hpa_config[0]
                            }
                        )
                    else:
                        selected_items[k]["gb_deployments"].append(
                            {
                                "type": "deployment",
                                "name": j["metadata"]["name"],
                                "replicas": j["spec"]["replicas"],
                            }
                        )
                    break
            for l in deploymentcongfigs[k]["items"]:
                if selector == l["metadata"]["name"]:
                    hpa_config = [hpa_conf for hpa_conf in hpas[k]['items'] if hpa_conf['spec']['scaleTargetRef']['name'] == l["metadata"]["name"] and hpa_conf['spec']['scaleTargetRef']['kind'] == "DeploymentConfig"]
                    if len(hpa_config) == 1:
                        selected_items[k]["gb_deployments"].append(
                            {
                                "type": "deploymentconfig",
                                "name": l["metadata"]["name"],
                                "replicas": l["spec"]["replicas"],
                                "hpa": hpa_config[0]
                            }
                        )
                    else:
                        selected_items[k]["gb_deployments"].append(
                            {
                                "type": "deploymentconfig",
                                "name": l["metadata"]["name"],
                                "replicas": l["spec"]["replicas"],
                            }
                        )
                    break

        for i in services[k]["bg_services"]:
            selector = i["selector"]
            for j in deployments[k]["items"]:
                if selector == j["metadata"]["name"]:
                    hpa_config = [hpa_conf for hpa_conf in hpas[k]['items'] if hpa_conf['spec']['scaleTargetRef']['name'] == j["metadata"]["name"] and hpa_conf['spec']['scaleTargetRef']['kind'] == "Deployment"]
                    if len(hpa_config) == 1:
                        selected_items[k]["bg_deployments"].append(
                            {
                                "type": "deployment",
                                "name": j["metadata"]["name"],
                                "replicas": j["spec"]["replicas"],
                                "hpa": hpa_config[0]
                            }
                        )
                    else:
                        selected_items[k]["bg_deployments"].append(
                            {
                                "type": "deployment",
                                "name": j["metadata"]["name"],
                                "replicas": j["spec"]["replicas"],
                            }
                        )
                    break
            for l in deploymentcongfigs[k]["items"]:
                if selector == l["metadata"]["name"]:
                    hpa_config = [hpa_conf for hpa_conf in hpas[k]['items'] if hpa_conf['spec']['scaleTargetRef']['name'] == l["metadata"]["name"] and hpa_conf['spec']['scaleTargetRef']['kind'] == "DeploymentConfig"]
                    if len(hpa_config) == 1:
                        selected_items[k]["bg_deployments"].append(
                            {
                                "type": "deploymentconfig",
                                "name": l["metadata"]["name"],
                                "replicas": l["spec"]["replicas"],
                                "hpa": hpa_config[0]
                            }
                        )
                    else:
                        selected_items[k]["bg_deployments"].append(
                            {
                                "type": "deploymentconfig",
                                "name": l["metadata"]["name"],
                                "replicas": l["spec"]["replicas"],
                            }
                        )
                    break

    return selected_items


async def replicate_configuration(functionalEnvironment, cluster,  namespace, ldap):
    
    client_map = {
        "functionalEnvironment": functionalEnvironment,
        "cluster": cluster,
        "namespace": namespace
    }

    hpaConfig = await get_configuration(
        functionalEnvironment=functionalEnvironment,
        cluster=cluster,
        namespace=namespace,
        ldap=ldap
        )
    
    workloads = Workloads(
        functionalEnvironment=functionalEnvironment,
        cluster=cluster,
        namespace=namespace
    )

    await workloads.get_workloads()

    services = await check_service(workloads.services)
    bg_selectors = {}
    for k in services.keys():
        bg_selectors[k] = [service["selector"] for service in services[k]["bg_services"]]


    response = {"status": "ok", "response": []}

    for k in services.keys():
        for bg_selector in bg_selectors[k]:
            cluster = [cluster for cluster in hpaConfig["deploymentconfigs"] if cluster["cluster"] == k][0]
            for deploymentconfig in cluster["items"]:
                if deploymentconfig["name"] == bg_selector:
                    del(deploymentconfig["replicas"])
                    del(deploymentconfig["uid"])
                    try:
                        deploymentconfig["hpa"] = [hpa for hpa in deploymentconfig["hpa"] if hpa["sourceConfig"] == "HorizontalPodAutoscaler"][0]
                    except Exception:
                        response["status"] = "ko"
                        response["response"].append(f"Microservice real {bg_selector} does not have hpa")
                        continue
                    
                    result = await update_hpa_conf(microservice=deploymentconfig, hpa_mode="annotations", client_map=client_map, ldap=ldap)
                    if result["status"] == "ok":
                        response["response"].append(f"Microservice {bg_selector} updated on {k}")
                    else:
                        response["status"] = "ko"
                        response["response"].append(result["response"])

                    if bg_selector.endswith("g"):
                        oculto =  bg_selector[:-2] + "-b"
                    else:
                        oculto =  bg_selector[:-2] + "-g"
                    for deploymentconfigoculto in cluster["items"]:
                        if deploymentconfigoculto["name"] == oculto:
                            del(deploymentconfigoculto["replicas"])
                            del(deploymentconfigoculto["uid"])
                            deploymentconfigoculto["hpa"] = deploymentconfig["hpa"]

                            result = await update_hpa_conf(microservice=deploymentconfigoculto, hpa_mode="annotations", client_map=client_map, ldap=ldap)
                            if result["status"] == "ok":
                                response["response"].append(f"Microservice {oculto} updated on {k}")
                            else:
                                response["status"] = "ko"
                                response["response"].append(result["response"])
                                        
            cluster = [cluster for cluster in hpaConfig["deployments"] if cluster["cluster"] == k][0]
            for deployment in cluster["items"]:
                if deployment["name"] == bg_selector :
                    del(deployment["replicas"])
                    del(deployment["uid"])
                    try:
                        deployment["hpa"] = [hpa for hpa in deployment["hpa"] if hpa["sourceConfig"] == "HorizontalPodAutoscaler"][0]
                    except Exception:
                        response["status"] = "ko"
                        response["response"].append(f"Microservice real {bg_selector} does not have hpa")
                        continue

                    result = await update_hpa_conf(microservice=deployment, hpa_mode="annotations", client_map=client_map, ldap=ldap)
                    if result["status"] == "ok":
                        response["response"].append(f"Microservice {bg_selector} updated on {k}")
                    else:
                        response["status"] = "ko"
                        response["response"].append(result["response"])

                    if bg_selector.endswith("g"):
                        oculto =  bg_selector[:-2] + "-b"
                    else:
                        oculto =  bg_selector[:-2] + "-g"
                    for deploymentoculto in cluster["items"]:
                        if deploymentoculto["name"] == oculto:
                            del(deploymentoculto["replicas"])
                            del(deploymentoculto["uid"])
                            deploymentoculto["hpa"] = deployment["hpa"]

                            result = await update_hpa_conf(microservice=deploymentoculto, hpa_mode="annotations", client_map=client_map, ldap=ldap)
                            if result["status"] == "ok":
                                response["response"].append(f"Microservice {oculto} updated on {k}")
                            else:
                                response["status"] = "ko"
                                response["response"].append(result["response"])
            
        
    return response