import os
from shuttlelib.openshift.client import OpenshiftClient

client = OpenshiftClient(entity_id=os.getenv("ENTITY_ID", "spain"))

class Workloads:
    def __init__(self, functionalEnvironment, cluster, namespace) -> None:
        self.functional_environment = functionalEnvironment
        self.cluster = cluster
        self.namespace = namespace
    
    async def get_workloads(self):
        self.deployments = await client.get_resource(
            functional_environment=self.functional_environment,
            cluster=self.cluster,
            resource="deployments",
            namespace=self.namespace
            )
        self.deploymentconfigs = await client.get_resource(
            functional_environment=self.functional_environment,
            cluster=self.cluster,
            resource="deploymentconfigs",
            namespace=self.namespace
            )
        self.services = await client.get_resource(
            functional_environment=self.functional_environment,
            cluster=self.cluster,
            resource="services",
            namespace=self.namespace
            )
        
        self.hpas = await client.get_resource(
            functional_environment=self.functional_environment,
            cluster=self.cluster,
            resource="hpas",
            namespace=self.namespace
            )
