import setuptools
from version import __version__

setuptools.setup(
    name = "getinfoservices",
    version = __version__,
    author = "Carlos Murcia",
    author_email = "carlosfernando.murcia@gruposantander.com",
    description = "Microservice for getting information of services on PaaS and store it in a Database",
    long_description = "Microservice for getting information of services on PaaS like selectors, servicetype, etc and store it in a Database",
    long_description_content_type = "text/markdown",
    url = "http://mypythonpackage.com",
    packages = setuptools.find_packages(),
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
    ],
    python_requires = '>=3.9',
)
