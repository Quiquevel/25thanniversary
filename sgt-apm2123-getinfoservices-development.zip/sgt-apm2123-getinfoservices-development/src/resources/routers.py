from darwin_composer.DarwinComposer import RouteClass
from ..handler.external_requests import extracting

routers = [
    RouteClass(extracting, ["extracting"])
]
