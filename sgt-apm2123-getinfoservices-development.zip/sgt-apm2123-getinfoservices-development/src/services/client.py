from shuttlelib.openshift.client import OpenshiftClient
import os

entity_id = os.getenv("ENTITY_ID").lower()
client = OpenshiftClient(entity_id=entity_id)