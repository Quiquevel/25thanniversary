from shuttlelib.utils.logger import logger
import time
import aiohttp
import shuttlelib.db.mongo as mongolib
import aiohttp
import os
from src.services.commonfunctions import getNamespaceObjects,updateMongoInfo, deleteMongoServices
from src.services.client import client


mg = mongolib.MongoClient()

async def get_info_services(entity_id="spain",functional_environment="pro",clusterparam=None,regionparam=None,namespaceslist=None):

    t1 = time.time()

    mongocollection = os.getenv("COLLECTION")

    query = []

    if clusterparam != None:
        query.append({"cluster": clusterparam})

    if regionparam != None:
        query.append({"region": regionparam})

    if namespaceslist != None:
        query.append({"namespace": {"$in": namespaceslist}})

    if query != []:
        fullquery = {"$and": query}
        logger.debug(f'Getting mongo data for query {fullquery}')
        mongodata = mg.find(fullquery)
    else:
        logger.debug("Getting ALL mongo data")
        mongodata = mg.find({})

    mongo_namespacesids = set()
    for element in mongodata:
        mongo_namespacesids.add(element["namespaceid"])

    #mongo_namespacesids = [element["namespaceid"] for element in mongodata]
    #logger.debug(f'Length of mongo data: {len(mongo_namespacesids)}')
    openshift_namespacesid = set()

    #if entity_id != "spain":
        #client.change_entity(entity_id=entity_id)

    clusters = await client.get_resource(resource="clusters",functional_environment=functional_environment,cluster=None)
    
    if clusterparam != None:
        clusterslist = [clusterparam]
    else:
        clusterslist = list(clusters.keys())

    for cluster in clusterslist:

        clustersinfo = []

        if regionparam != None:
            regionlist = [regionparam]
        else:
            regionlist = list(clusters[cluster].keys())

        for region in regionlist:

            try:
                namespaces = await client.get_resource(resource="namespaces",functional_environment=functional_environment,cluster=cluster,region=region)
                if namespaces[region] == 401:
                    continue
            except aiohttp.client_exceptions.ServerTimeoutError:
                logger.error(f"Timeout detected against {functional_environment+cluster+region} ")
                continue
            except:
                logger.error(f"Error que no es un timeout")
                continue

            if namespaces != []:
                namespacesdictlist = namespaces[region]["items"]
            else:
                namespacesdictlist = []

            if namespaceslist != None:
                namespacesdictlist = [namespacedict for namespacedict in namespacesdictlist if namespacedict["metadata"]["name"] in namespaceslist]

            for namespacedict in namespacesdictlist:

                namespace = namespacedict["metadata"]["name"]
                
                if namespaceslist != None:
                    if namespace not in namespaceslist:
                        continue

                # if namespace != "sanes-bizuid-pro":
                #     continue

                if namespace.startswith("sanes-zzz") or namespace.startswith("sanes-autoz"):
                    continue

                namespaceid = cluster+"-"+region+"-"+namespace
                openshift_namespacesid.add(namespaceid) #For comparing to mongo info and drop mongo object if project doesn't exist anymore
                logger.info(f'[INFO] - Getting info of {namespaceid}')

                namespaceinfo = {
                    "cluster": cluster,
                    "region": region,
                    "namespace": namespace,
                    "namespaceid": namespaceid,
                }
                
                services = await getNamespaceObjects(functional_environment,cluster,region,namespace,resource='services')

                mongo_services = mg.find({"namespaceid": namespaceid})
                mongo_services_list = [f'{mongo_service["id"]}' for mongo_service in mongo_services]
                
                await deleteMongoServices(cluster,region,namespace,mongo_services_list,services)

                if services != []:
                    await updateMongoInfo(cluster=cluster,region=region,namespace=namespace,namespaceinfo=namespaceinfo,commonobjectid=namespaceid,collection=mongocollection,ksobject='services',ksobject_list=services)

    if clusterparam == None and regionparam == None and namespaceslist == None:
        for id in mongo_namespacesids:
            if id not in openshift_namespacesid:
                mg._collection.delete_many({"namespaceid": id})

    t2 = time.time()
    totalTime = t2-t1

    logger.info(f'Total time: {totalTime}')
