from shuttlelib.utils.logger import logger
import shuttlelib.db.mongo as mongolib
from datetime import datetime
import os
from src.services.client import client

mg = mongolib.MongoClient()

async def deleteMongoServices(cluster, region, namespace,mongoservices,openshiftservices):

    openshiftservicesid = [f'{cluster}-{region}-{namespace}-{service["metadata"]["name"]}' for service in openshiftservices]

    for id in mongoservices:
        if id not in openshiftservicesid:
            logger.debug(f'Mongo service {id} is not on Openshift anymore. Deleting...')
            mg.delete_one({"id": id})

async def getNamespaceObjects(functional_environment,cluster,region,namespace,resource):

    #TODO
    # AÑADIR CAMBIO DE ENTIDAD, RECIBIÉNDOLA POR PARÁMETRO...
    
    try:
        object = await client.get_resource(resource=resource,functional_environment=functional_environment,cluster=cluster,region=region,namespace=namespace)
        objectitems = object[region]["items"]
    except:
        logger.error(f'{resource} couldn\'t be obtained')
        objectitems = []

    return objectitems

async def service_selector_matches_micro_template(service_selector: dict, micro_labels: dict) -> bool:

    if not service_selector or not micro_labels:
        return False
    return all(micro_labels.get(k) == v for k, v in service_selector.items())

async def createServicesDict(service: dict, namespaceinfo: dict) -> dict:

    service_selector = service.get("spec", {}).get("selector", {})
    namespace_id = namespaceinfo["namespaceid"]

    microscollection = os.getenv('COLLECTION_MICROSERVICES')
    mg.change_collection(collection=microscollection)

    query = {"namespaceid": namespace_id}
    all_micros = list(mg.find(query))

    matching_micros = [micro for micro in all_micros
        if await service_selector_matches_micro_template(service_selector, micro.get("template_labels", {}))
    ]

    #The service should route to pods whose labels match exactly with the service spec.selector

    if not service_selector:
        selector_status = {
            "status": "KO",
            "reason": "Service has no selectors"
        }
    elif not matching_micros:
            selector_status = {
                "status": "KO",
                "reason": "No microservice exists whose pod labels match ALL service selectors"
            }
    elif len(matching_micros) > 1:
        logger.info(f'Service {service["metadata"]["name"]} matches multiple microservices:')
        for micro in matching_micros:
            logger.info(f'microservice: {micro.get("name")}')
        selector_status = {
            "status": "KO",
            "reason": "There are more than one microservice matching the Service"
        }
    else:
        selector_status = {
            "status": "OK",
            "reason": None
        }

    servicesdict = {
        "name": service["metadata"]["name"],
        "creationTimestamp": service["metadata"].get("creationTimestamp"),
        "labels": service["metadata"].get("labels"),
        "selectors": service_selector,
        "selector_status": selector_status,
        "clusterIP": service.get("spec", {}).get("clusterIP"),
        "internalTrafficPolicy": service.get("spec", {}).get("internalTrafficPolicy"),
        "type": service.get("spec", {}).get("type"),
        "ipFamilyPolicy": service.get("spec", {}).get("ipFamilyPolicy"),
        "sessionAffinity": service.get("spec", {}).get("sessionAffinity")
    }

    servicesdict.update(namespaceinfo)

    return servicesdict

async def getRealHiddenAgreement(entity_id):
    match entity_id:
        case "spain":
            real = "b-g-"
            hidden = "g-b-"
        case _:
            real = "pro"
            hidden = "ocu"

    return real, hidden

async def getSelectorAgreement(entity_id):
    match entity_id:
        case "spain":
            selector = "app_name"
        case _:
            selector = "app_name"

    return selector

async def getMicrosOnline(entity_id,services,cluster):

    microsonline = []
    microsoffline = []

    BGgreenblock = 0
    BGblueblock = 0

    real, hidden = await getRealHiddenAgreement(entity_id)
    selector_name = await getSelectorAgreement(entity_id)

    for svc in services:

        svcName = svc["metadata"]["name"]

        try:
            selectors = svc["spec"]["selector"]
        except KeyError:
            selectors = None

        if real in svcName:
            try:
                microsonline.append(selectors[selector_name])
                if selectors[selector_name].endswith("-b"):
                    BGblueblock += 1
                elif selectors[selector_name].endswith("-g"):
                    BGgreenblock += 1    

            except KeyError:
                try: 
                    microsonline.append(selectors["deploymentconfig"])
                    logger.error(f'Service {svcName} is using deploymentconfig selector instead of app_name')
                except KeyError:
                    logger.error(f'Service {svcName} is not using deploymentconfig selector nor app_name')

        elif hidden in svcName:
                try:
                    microsoffline.append(selectors[selector_name])
                except KeyError:
                    try:
                        microsoffline.append(svc["spec"]["selector"]["deploymentconfig"])
                        logger.error(f'Service {svcName} is using deploymentconfig selector instead of app_name')
                    except KeyError:
                        logger.error(f'Service {svcName} is not using deploymentconfig selector nor app_name')     

    if BGgreenblock > BGblueblock:
        productionBlock = "green"
    elif BGgreenblock < BGblueblock:
        productionBlock = "blue"
    else:
        productionBlock = None
        
    if "bks" in cluster:
        productionBlock = "Block strategy is not used"
    elif "confluent" in cluster:
        productionBlock = "Block strategy is not used"
        microsonline = []
        microsoffline = []

    return microsonline,microsoffline,productionBlock

async def checkDeleteKeys(micro_dict,mongomicroforcomparison):
    deletedkeys = []
    for key in micro_dict.keys():
        if key not in str(mongomicroforcomparison.keys()):
            deletedkeys.append(key)
    
    deletedkeys2 = [key for key in micro_dict.keys() if key not in str(mongomicroforcomparison.keys())]

    return deletedkeys, deletedkeys2

async def updateMongoData(id,collection,datakey,datavalue,action=None):

    logger.info(f'Changing to mongo collection  {collection} to update info')
    mg.change_collection(collection=collection)

    if action == "unset":
        updatedData = mg.update_one({'id': id},
                                        {"$unset": {datakey: ""}})
    else:
        if datakey==None:
            updatedData = mg.update_one({'id': id},
                                        {"$set": datavalue})
        else:
            updatedData = mg.update_one({'id': id},
                                        {"$set": {datakey: datavalue}})
        
    if updatedData.modified_count == 1:
        logger.info(f'{id} updated')
        mg.update_one({'id': id}, {"$set": {"timestamp": datetime.utcnow()}})
        return True
    else:
        logger.info(f'{id} was not updated')
        return False
    
async def compareLists(openshiftinfo,mongoinfo):
    differencesFlag = False
    
    for index,openshiftelem in enumerate(openshiftinfo):
        if openshiftelem != mongoinfo[index]:
            differencesFlag = True
    
    return differencesFlag

async def compareInfo(openshiftvalues,mongovalues):
    
    differencesFlag = False

    if type(openshiftvalues) == list and type(mongovalues) == list:
        if len(openshiftvalues) != len(mongovalues):
            differencesFlag = True
        else:
            differencesFlag = await compareLists(openshiftvalues,mongovalues)
    
    else:
        #await compareDicts(openshiftvalues,mongovalues)

        if openshiftvalues != None and mongovalues != None:
            #ordeno las claves primero.
            openshiftvalueskeyssorted = sorted(openshiftvalues)
            mongovalueskeyssorted = sorted(mongovalues)

            openshiftvaluessorted = {key: openshiftvalues[key] for key in openshiftvalueskeyssorted}
            mongovaluessorted = {key: mongovalues[key] for key in mongovalueskeyssorted}

            for item1,item2 in zip(openshiftvaluessorted,mongovaluessorted):
                if openshiftvaluessorted[item1] != mongovaluessorted[item2]:
                    differencesFlag = True
                    break
        elif openshiftvalues == None and mongovalues == None:
        # mongovalues != None:
            differencesFlag = False
        else:
            differencesFlag = True
    
    return differencesFlag 

async def createDictOrchestrator(ksobject, ksobjectelem, namespaceinfo):
    match ksobject:
        case "services":
            dictionary = await createServicesDict(ksobjectelem, namespaceinfo)
        # case "replicationcontrollers":
        #     dictionary = await createRepliContrDict(ksobjectelem, namespaceinfo)
        # case "replicasets":
        #     dictionary = await createReplicaSetsDict(ksobjectelem, namespaceinfo)
        # case "configmaps":
        #     dictionary = await createConfigMapsDict(ksobjectelem, namespaceinfo)
        # case "hpas":
        #     dictionary = await createHPAsDict(ksobjectelem, namespaceinfo)
    
    return dictionary

async def updateMongoInfo(cluster,region,namespace,namespaceinfo,commonobjectid,collection,ksobject,ksobject_list):

    mg.change_collection(collection=collection)
    mongosdocs = mg.find({"namespaceid": commonobjectid})
    mongoidslist = [object["id"] for object in mongosdocs]

    for ksobjectelem in ksobject_list:
        info = await createDictOrchestrator(ksobject, ksobjectelem, namespaceinfo)
        id = cluster+"-"+region+"-"+namespace+"-"+ksobjectelem["metadata"]["name"]
        info.update({"id": id})

        mg.change_collection(collection=collection)
        if id not in mongoidslist:
            mg.add_data(info)
        else:
            logger.info(f'Checking changes in kubernetes object {ksobjectelem["metadata"]["name"]} ({ksobject})')
            valueschangedflag = False
            mongoupdated = False
            mongoobject = mg.find_one({"id": id})
            mongoinfoforcomparison = mongoobject.copy()
            del mongoinfoforcomparison["_id"]
            del mongoinfoforcomparison["timestamp"]
            valueschangedflag = await compareInfo(info,mongoinfoforcomparison)
            if valueschangedflag:
                mongoupdated = await updateMongoData(id=mongoobject["id"],collection=collection,datakey=None,datavalue=info)
            
            if mongoupdated == True:
                logger.info(f'Mongo updated')

    return ksobject_list